; ModuleID = '/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c'
source_filename = "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

%struct.x86_sim_xdp_abi = type { ptr, ptr, [5 x i32] }
%union.x86_sim_gpr = type { ptr }
%union.anon = type { [1 x i64] }
%union.anon.0 = type { ptr }
%union.anon.1 = type { ptr }

@LICENSE = dso_local global [4 x i8] c"GPL\00", section "license", align 1, !dbg !0
@llvm.compiler.used = appending global [2 x ptr] [ptr @trusted_x86_x86_sim_xdp, ptr @LICENSE], section "llvm.metadata"

; Function Attrs: noinline nounwind
define dso_local i32 @trusted_x86_x86_sim_xdp(ptr noundef %0) #0 section "xdp" !dbg !131 {
  %2 = alloca i8, align 1
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  %6 = alloca i8, align 1
  %7 = alloca i8, align 1
  %8 = alloca i8, align 1
  %9 = alloca i8, align 1
  %10 = alloca i8, align 1
  %11 = alloca i8, align 1
  %12 = alloca i8, align 1
  %13 = alloca i8, align 1
  %14 = alloca i8, align 1
  %15 = alloca ptr, align 8
  %16 = alloca i8, align 1
  %17 = alloca i64, align 8
  %18 = alloca ptr, align 8
  %19 = alloca i8, align 1
  %20 = alloca i64, align 8
  %21 = alloca i8, align 1
  %22 = alloca i8, align 1
  %23 = alloca i8, align 1
  %24 = alloca i8, align 1
  %25 = alloca i8, align 1
  %26 = alloca i64, align 8
  %27 = alloca i8, align 1
  %28 = alloca i32, align 4
  %29 = alloca ptr, align 8
  %30 = alloca %struct.x86_sim_xdp_abi, align 8
  %31 = alloca ptr, align 8
  %32 = alloca i8, align 1
  %33 = alloca i8, align 1
  %34 = alloca ptr, align 8
  %35 = alloca i8, align 1
  %36 = alloca ptr, align 8
  %37 = alloca ptr, align 8
  %38 = alloca %union.x86_sim_gpr, align 8
  %39 = alloca i64, align 8
  %40 = alloca i64, align 8
  %41 = alloca i8, align 1
  %42 = alloca %union.x86_sim_gpr, align 8
  %43 = alloca i64, align 8
  %44 = alloca i64, align 8
  %45 = alloca i8, align 1
  %46 = alloca %union.x86_sim_gpr, align 8
  %47 = alloca i64, align 8
  %48 = alloca i64, align 8
  %49 = alloca i8, align 1
  %50 = alloca %union.x86_sim_gpr, align 8
  %51 = alloca i64, align 8
  %52 = alloca i64, align 8
  %53 = alloca i8, align 1
  %54 = alloca %union.x86_sim_gpr, align 8
  %55 = alloca i8, align 1
  %56 = alloca %union.x86_sim_gpr, align 8
  %57 = alloca i64, align 8
  %58 = alloca i64, align 8
  %59 = alloca i8, align 1
  %60 = alloca %union.x86_sim_gpr, align 8
  %61 = alloca i64, align 8
  %62 = alloca i64, align 8
  %63 = alloca i8, align 1
  %64 = alloca %union.x86_sim_gpr, align 8
  %65 = alloca i64, align 8
  %66 = alloca i64, align 8
  %67 = alloca i8, align 1
  %68 = alloca %union.x86_sim_gpr, align 8
  %69 = alloca i64, align 8
  %70 = alloca i64, align 8
  %71 = alloca i8, align 1
  %72 = alloca %union.x86_sim_gpr, align 8
  %73 = alloca i64, align 8
  %74 = alloca i64, align 8
  %75 = alloca i8, align 1
  %76 = alloca %union.x86_sim_gpr, align 8
  %77 = alloca i64, align 8
  %78 = alloca i64, align 8
  %79 = alloca i8, align 1
  %80 = alloca %union.x86_sim_gpr, align 8
  %81 = alloca i64, align 8
  %82 = alloca i64, align 8
  %83 = alloca i8, align 1
  %84 = alloca %union.x86_sim_gpr, align 8
  %85 = alloca i64, align 8
  %86 = alloca i64, align 8
  %87 = alloca i8, align 1
  %88 = alloca %union.x86_sim_gpr, align 8
  %89 = alloca i64, align 8
  %90 = alloca i64, align 8
  %91 = alloca i8, align 1
  %92 = alloca %union.x86_sim_gpr, align 8
  %93 = alloca i64, align 8
  %94 = alloca i64, align 8
  %95 = alloca i8, align 1
  %96 = alloca %union.x86_sim_gpr, align 8
  %97 = alloca i64, align 8
  %98 = alloca i64, align 8
  %99 = alloca i8, align 1
  %100 = alloca i64, align 8
  %101 = alloca i8, align 1
  %102 = alloca i64, align 8
  %103 = alloca i64, align 8
  %104 = alloca i8, align 1
  %105 = alloca i64, align 8
  %106 = alloca i64, align 8
  %107 = alloca i8, align 1
  %108 = alloca i64, align 8
  %109 = alloca i64, align 8
  %110 = alloca i8, align 1
  %111 = alloca i64, align 8
  %112 = alloca i64, align 8
  %113 = alloca i8, align 1
  %114 = alloca i64, align 8
  %115 = alloca i64, align 8
  %116 = alloca i8, align 1
  %117 = alloca i64, align 8
  %118 = alloca i64, align 8
  %119 = alloca i64, align 8
  %120 = alloca i64, align 8
  %121 = alloca i64, align 8
  %122 = alloca i64, align 8
  %123 = alloca i64, align 8
  %124 = alloca i64, align 8
  %125 = alloca i64, align 8
  %126 = alloca %union.anon, align 8
  %127 = alloca i64, align 8
  %128 = alloca i64, align 8
  %129 = alloca i8, align 1
  %130 = alloca i8, align 1
  %131 = alloca i8, align 1
  %132 = alloca i64, align 8
  %133 = alloca i64, align 8
  %134 = alloca i64, align 8
  %135 = alloca ptr, align 8
  %136 = alloca i64, align 8
  %137 = alloca i64, align 8
  %138 = alloca i64, align 8
  %139 = alloca i64, align 8
  %140 = alloca i32, align 4
  %141 = alloca i32, align 4
  %142 = alloca i64, align 8
  %143 = alloca i64, align 8
  %144 = alloca i32, align 4
  %145 = alloca i64, align 8
  %146 = alloca i8, align 1
  %147 = alloca i64, align 8
  %148 = alloca i64, align 8
  %149 = alloca i64, align 8
  %150 = alloca i8, align 1
  %151 = alloca i8, align 1
  %152 = alloca i8, align 1
  %153 = alloca i64, align 8
  %154 = alloca i64, align 8
  %155 = alloca i64, align 8
  %156 = alloca i64, align 8
  %157 = alloca ptr, align 8
  %158 = alloca i64, align 8
  %159 = alloca i64, align 8
  %160 = alloca i64, align 8
  %161 = alloca i64, align 8
  %162 = alloca i64, align 8
  %163 = alloca i64, align 8
  %164 = alloca i64, align 8
  %165 = alloca i64, align 8
  %166 = alloca i64, align 8
  %167 = alloca i64, align 8
  %168 = alloca i64, align 8
  %169 = alloca i64, align 8
  %170 = alloca i64, align 8
  %171 = alloca i64, align 8
  %172 = alloca i64, align 8
  %173 = alloca i64, align 8
  %174 = alloca i64, align 8
  %175 = alloca i64, align 8
  %176 = alloca i64, align 8
  %177 = alloca i64, align 8
  %178 = alloca i64, align 8
  %179 = alloca i64, align 8
  %180 = alloca i8, align 1
  %181 = alloca i8, align 1
  %182 = alloca i64, align 8
  %183 = alloca i64, align 8
  %184 = alloca i64, align 8
  %185 = alloca i64, align 8
  %186 = alloca ptr, align 8
  %187 = alloca i8, align 1
  %188 = alloca i64, align 8
  %189 = alloca ptr, align 8
  %190 = alloca i8, align 1
  %191 = alloca i8, align 1
  %192 = alloca i64, align 8
  %193 = alloca i64, align 8
  %194 = alloca i64, align 8
  %195 = alloca i8, align 1
  %196 = alloca i8, align 1
  %197 = alloca ptr, align 8
  %198 = alloca i8, align 1
  %199 = alloca i64, align 8
  %200 = alloca ptr, align 8
  %201 = alloca i8, align 1
  %202 = alloca i8, align 1
  %203 = alloca i8, align 1
  %204 = alloca i8, align 1
  %205 = alloca i64, align 8
  %206 = alloca i64, align 8
  %207 = alloca i64, align 8
  %208 = alloca i64, align 8
  %209 = alloca i8, align 1
  %210 = alloca i8, align 1
  %211 = alloca i32, align 4
  %212 = alloca i32, align 4
  %213 = alloca i64, align 8
  %214 = alloca i8, align 1
  %215 = alloca i8, align 1
  %216 = alloca i8, align 1
  %217 = alloca ptr, align 8
  %218 = alloca i8, align 1
  %219 = alloca i8, align 1
  %220 = alloca i8, align 1
  %221 = alloca i8, align 1
  %222 = alloca i64, align 8
  %223 = alloca i64, align 8
  %224 = alloca i64, align 8
  %225 = alloca %union.anon.0, align 8
  %226 = alloca i64, align 8
  %227 = alloca i64, align 8
  %228 = alloca %union.anon.1, align 8
  %229 = alloca i8, align 1
  %230 = alloca i8, align 1
  %231 = alloca i8, align 1
  %232 = alloca i8, align 1
  %233 = alloca ptr, align 8
  %234 = alloca i64, align 8
  %235 = alloca i8, align 1
  %236 = alloca i8, align 1
  %237 = alloca i64, align 8
  %238 = alloca i64, align 8
  %239 = alloca i64, align 8
  %240 = alloca i8, align 1
  %241 = alloca i8, align 1
  %242 = alloca i8, align 1
  %243 = alloca i8, align 1
  %244 = alloca ptr, align 8
  %245 = alloca i64, align 8
  %246 = alloca i8, align 1
  %247 = alloca i8, align 1
  %248 = alloca i64, align 8
  %249 = alloca i64, align 8
  %250 = alloca i64, align 8
  store ptr %0, ptr %29, align 8
  call void @llvm.dbg.declare(metadata ptr %29, metadata !144, metadata !DIExpression()), !dbg !145
  call void @llvm.dbg.declare(metadata ptr %30, metadata !146, metadata !DIExpression()), !dbg !153
  call void @llvm.memset.p0.i64(ptr align 8 %30, i8 0, i64 40, i1 false), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %31, metadata !154, metadata !DIExpression()), !dbg !153
  store ptr null, ptr %31, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %32, metadata !155, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %32, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %33, metadata !156, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %33, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %34, metadata !157, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %35, metadata !158, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %35, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %36, metadata !159, metadata !DIExpression()), !dbg !153
  store ptr null, ptr %36, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %37, metadata !160, metadata !DIExpression()), !dbg !153
  store ptr null, ptr %37, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %38, metadata !161, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %39, metadata !170, metadata !DIExpression()), !dbg !172
  %251 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !172, !srcloc !173
  store i64 %251, ptr %39, align 8, !dbg !172
  %252 = load i64, ptr %39, align 8, !dbg !172
  store i64 %252, ptr %40, align 8, !dbg !172
  %253 = load i64, ptr %40, align 8, !dbg !172
  %254 = inttoptr i64 %253 to ptr, !dbg !153
  store ptr %254, ptr %38, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %41, metadata !174, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %41, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %42, metadata !175, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %43, metadata !176, metadata !DIExpression()), !dbg !178
  %255 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !178, !srcloc !179
  store i64 %255, ptr %43, align 8, !dbg !178
  %256 = load i64, ptr %43, align 8, !dbg !178
  store i64 %256, ptr %44, align 8, !dbg !178
  %257 = load i64, ptr %44, align 8, !dbg !178
  %258 = inttoptr i64 %257 to ptr, !dbg !153
  store ptr %258, ptr %42, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %45, metadata !180, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %45, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %46, metadata !181, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %47, metadata !182, metadata !DIExpression()), !dbg !184
  %259 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !184, !srcloc !185
  store i64 %259, ptr %47, align 8, !dbg !184
  %260 = load i64, ptr %47, align 8, !dbg !184
  store i64 %260, ptr %48, align 8, !dbg !184
  %261 = load i64, ptr %48, align 8, !dbg !184
  %262 = inttoptr i64 %261 to ptr, !dbg !153
  store ptr %262, ptr %46, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %49, metadata !186, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %49, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %50, metadata !187, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %51, metadata !188, metadata !DIExpression()), !dbg !190
  %263 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !190, !srcloc !191
  store i64 %263, ptr %51, align 8, !dbg !190
  %264 = load i64, ptr %51, align 8, !dbg !190
  store i64 %264, ptr %52, align 8, !dbg !190
  %265 = load i64, ptr %52, align 8, !dbg !190
  %266 = inttoptr i64 %265 to ptr, !dbg !153
  store ptr %266, ptr %50, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %53, metadata !192, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %53, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %54, metadata !193, metadata !DIExpression()), !dbg !153
  call void @llvm.memset.p0.i64(ptr align 8 %54, i8 0, i64 8, i1 false), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %55, metadata !194, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %55, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %56, metadata !195, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %57, metadata !196, metadata !DIExpression()), !dbg !198
  %267 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !198, !srcloc !199
  store i64 %267, ptr %57, align 8, !dbg !198
  %268 = load i64, ptr %57, align 8, !dbg !198
  store i64 %268, ptr %58, align 8, !dbg !198
  %269 = load i64, ptr %58, align 8, !dbg !198
  %270 = inttoptr i64 %269 to ptr, !dbg !153
  store ptr %270, ptr %56, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %59, metadata !200, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %59, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %60, metadata !201, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %61, metadata !202, metadata !DIExpression()), !dbg !204
  %271 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !204, !srcloc !205
  store i64 %271, ptr %61, align 8, !dbg !204
  %272 = load i64, ptr %61, align 8, !dbg !204
  store i64 %272, ptr %62, align 8, !dbg !204
  %273 = load i64, ptr %62, align 8, !dbg !204
  %274 = inttoptr i64 %273 to ptr, !dbg !153
  store ptr %274, ptr %60, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %63, metadata !206, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %63, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %64, metadata !207, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %65, metadata !208, metadata !DIExpression()), !dbg !210
  %275 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !210, !srcloc !211
  store i64 %275, ptr %65, align 8, !dbg !210
  %276 = load i64, ptr %65, align 8, !dbg !210
  store i64 %276, ptr %66, align 8, !dbg !210
  %277 = load i64, ptr %66, align 8, !dbg !210
  %278 = inttoptr i64 %277 to ptr, !dbg !153
  store ptr %278, ptr %64, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %67, metadata !212, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %67, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %68, metadata !213, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %69, metadata !214, metadata !DIExpression()), !dbg !216
  %279 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !216, !srcloc !217
  store i64 %279, ptr %69, align 8, !dbg !216
  %280 = load i64, ptr %69, align 8, !dbg !216
  store i64 %280, ptr %70, align 8, !dbg !216
  %281 = load i64, ptr %70, align 8, !dbg !216
  %282 = inttoptr i64 %281 to ptr, !dbg !153
  store ptr %282, ptr %68, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %71, metadata !218, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %71, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %72, metadata !219, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %73, metadata !220, metadata !DIExpression()), !dbg !222
  %283 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !222, !srcloc !223
  store i64 %283, ptr %73, align 8, !dbg !222
  %284 = load i64, ptr %73, align 8, !dbg !222
  store i64 %284, ptr %74, align 8, !dbg !222
  %285 = load i64, ptr %74, align 8, !dbg !222
  %286 = inttoptr i64 %285 to ptr, !dbg !153
  store ptr %286, ptr %72, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %75, metadata !224, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %75, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %76, metadata !225, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %77, metadata !226, metadata !DIExpression()), !dbg !228
  %287 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !228, !srcloc !229
  store i64 %287, ptr %77, align 8, !dbg !228
  %288 = load i64, ptr %77, align 8, !dbg !228
  store i64 %288, ptr %78, align 8, !dbg !228
  %289 = load i64, ptr %78, align 8, !dbg !228
  %290 = inttoptr i64 %289 to ptr, !dbg !153
  store ptr %290, ptr %76, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %79, metadata !230, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %79, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %80, metadata !231, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %81, metadata !232, metadata !DIExpression()), !dbg !234
  %291 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !234, !srcloc !235
  store i64 %291, ptr %81, align 8, !dbg !234
  %292 = load i64, ptr %81, align 8, !dbg !234
  store i64 %292, ptr %82, align 8, !dbg !234
  %293 = load i64, ptr %82, align 8, !dbg !234
  %294 = inttoptr i64 %293 to ptr, !dbg !153
  store ptr %294, ptr %80, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %83, metadata !236, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %83, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %84, metadata !237, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %85, metadata !238, metadata !DIExpression()), !dbg !240
  %295 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !240, !srcloc !241
  store i64 %295, ptr %85, align 8, !dbg !240
  %296 = load i64, ptr %85, align 8, !dbg !240
  store i64 %296, ptr %86, align 8, !dbg !240
  %297 = load i64, ptr %86, align 8, !dbg !240
  %298 = inttoptr i64 %297 to ptr, !dbg !153
  store ptr %298, ptr %84, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %87, metadata !242, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %87, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %88, metadata !243, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %89, metadata !244, metadata !DIExpression()), !dbg !246
  %299 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !246, !srcloc !247
  store i64 %299, ptr %89, align 8, !dbg !246
  %300 = load i64, ptr %89, align 8, !dbg !246
  store i64 %300, ptr %90, align 8, !dbg !246
  %301 = load i64, ptr %90, align 8, !dbg !246
  %302 = inttoptr i64 %301 to ptr, !dbg !153
  store ptr %302, ptr %88, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %91, metadata !248, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %91, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %92, metadata !249, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %93, metadata !250, metadata !DIExpression()), !dbg !252
  %303 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !252, !srcloc !253
  store i64 %303, ptr %93, align 8, !dbg !252
  %304 = load i64, ptr %93, align 8, !dbg !252
  store i64 %304, ptr %94, align 8, !dbg !252
  %305 = load i64, ptr %94, align 8, !dbg !252
  %306 = inttoptr i64 %305 to ptr, !dbg !153
  store ptr %306, ptr %92, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %95, metadata !254, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %95, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %96, metadata !255, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %97, metadata !256, metadata !DIExpression()), !dbg !258
  %307 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !258, !srcloc !259
  store i64 %307, ptr %97, align 8, !dbg !258
  %308 = load i64, ptr %97, align 8, !dbg !258
  store i64 %308, ptr %98, align 8, !dbg !258
  %309 = load i64, ptr %98, align 8, !dbg !258
  %310 = inttoptr i64 %309 to ptr, !dbg !153
  store ptr %310, ptr %96, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %99, metadata !260, metadata !DIExpression()), !dbg !153
  store i8 0, ptr %99, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %100, metadata !261, metadata !DIExpression()), !dbg !153
  store i64 0, ptr %100, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %101, metadata !262, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %102, metadata !263, metadata !DIExpression()), !dbg !265
  %311 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !265, !srcloc !266
  store i64 %311, ptr %102, align 8, !dbg !265
  %312 = load i64, ptr %102, align 8, !dbg !265
  store i64 %312, ptr %103, align 8, !dbg !265
  %313 = load i64, ptr %103, align 8, !dbg !265
  %314 = and i64 %313, 1, !dbg !153
  %315 = trunc i64 %314 to i8, !dbg !153
  store i8 %315, ptr %101, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %104, metadata !267, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %105, metadata !268, metadata !DIExpression()), !dbg !270
  %316 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !270, !srcloc !271
  store i64 %316, ptr %105, align 8, !dbg !270
  %317 = load i64, ptr %105, align 8, !dbg !270
  store i64 %317, ptr %106, align 8, !dbg !270
  %318 = load i64, ptr %106, align 8, !dbg !270
  %319 = and i64 %318, 1, !dbg !153
  %320 = trunc i64 %319 to i8, !dbg !153
  store i8 %320, ptr %104, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %107, metadata !272, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %108, metadata !273, metadata !DIExpression()), !dbg !275
  %321 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !275, !srcloc !276
  store i64 %321, ptr %108, align 8, !dbg !275
  %322 = load i64, ptr %108, align 8, !dbg !275
  store i64 %322, ptr %109, align 8, !dbg !275
  %323 = load i64, ptr %109, align 8, !dbg !275
  %324 = and i64 %323, 1, !dbg !153
  %325 = trunc i64 %324 to i8, !dbg !153
  store i8 %325, ptr %107, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %110, metadata !277, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %111, metadata !278, metadata !DIExpression()), !dbg !280
  %326 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !280, !srcloc !281
  store i64 %326, ptr %111, align 8, !dbg !280
  %327 = load i64, ptr %111, align 8, !dbg !280
  store i64 %327, ptr %112, align 8, !dbg !280
  %328 = load i64, ptr %112, align 8, !dbg !280
  %329 = and i64 %328, 1, !dbg !153
  %330 = trunc i64 %329 to i8, !dbg !153
  store i8 %330, ptr %110, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %113, metadata !282, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %114, metadata !283, metadata !DIExpression()), !dbg !285
  %331 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !285, !srcloc !286
  store i64 %331, ptr %114, align 8, !dbg !285
  %332 = load i64, ptr %114, align 8, !dbg !285
  store i64 %332, ptr %115, align 8, !dbg !285
  %333 = load i64, ptr %115, align 8, !dbg !285
  %334 = and i64 %333, 1, !dbg !153
  %335 = trunc i64 %334 to i8, !dbg !153
  store i8 %335, ptr %113, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %116, metadata !287, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %117, metadata !288, metadata !DIExpression()), !dbg !290
  %336 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !290, !srcloc !291
  store i64 %336, ptr %117, align 8, !dbg !290
  %337 = load i64, ptr %117, align 8, !dbg !290
  store i64 %337, ptr %118, align 8, !dbg !290
  %338 = load i64, ptr %118, align 8, !dbg !290
  %339 = and i64 %338, 1, !dbg !153
  %340 = trunc i64 %339 to i8, !dbg !153
  store i8 %340, ptr %116, align 1, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %119, metadata !292, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %120, metadata !293, metadata !DIExpression()), !dbg !295
  %341 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !295, !srcloc !296
  store i64 %341, ptr %120, align 8, !dbg !295
  %342 = load i64, ptr %120, align 8, !dbg !295
  store i64 %342, ptr %121, align 8, !dbg !295
  %343 = load i64, ptr %121, align 8, !dbg !295
  store i64 %343, ptr %119, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %122, metadata !297, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %123, metadata !298, metadata !DIExpression()), !dbg !300
  %344 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #5, !dbg !300, !srcloc !301
  store i64 %344, ptr %123, align 8, !dbg !300
  %345 = load i64, ptr %123, align 8, !dbg !300
  store i64 %345, ptr %124, align 8, !dbg !300
  %346 = load i64, ptr %124, align 8, !dbg !300
  store i64 %346, ptr %122, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %125, metadata !302, metadata !DIExpression()), !dbg !153
  store i64 0, ptr %125, align 8, !dbg !153
  call void @llvm.dbg.declare(metadata ptr %126, metadata !303, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.declare(metadata ptr %127, metadata !313, metadata !DIExpression()), !dbg !315
  %347 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590037175) #5, !dbg !315, !srcloc !316
  store i64 %347, ptr %127, align 8, !dbg !315
  %348 = load i64, ptr %127, align 8, !dbg !315
  store i64 %348, ptr %128, align 8, !dbg !315
  %349 = load i64, ptr %128, align 8, !dbg !315
  store i64 %349, ptr %100, align 8, !dbg !153
  store i8 1, ptr %35, align 1, !dbg !153
  %350 = load ptr, ptr %29, align 8, !dbg !153
  store ptr %350, ptr %36, align 8, !dbg !153
  %351 = load ptr, ptr %29, align 8, !dbg !153
  store ptr %351, ptr %37, align 8, !dbg !153
  %352 = load ptr, ptr %29, align 8, !dbg !153
  store ptr %352, ptr %64, align 8, !dbg !153
  store i8 1, ptr %67, align 1, !dbg !153
  br label %353, !dbg !153

353:                                              ; preds = %1
  call void @llvm.dbg.label(metadata !317), !dbg !318
  br label %354, !dbg !319

354:                                              ; preds = %353
  call void @llvm.dbg.declare(metadata ptr %129, metadata !320, metadata !DIExpression()), !dbg !322
  call void @llvm.dbg.declare(metadata ptr %130, metadata !323, metadata !DIExpression()), !dbg !325
  store i8 8, ptr %130, align 1, !dbg !325
  %355 = load i8, ptr %130, align 1, !dbg !325
  store i8 %355, ptr %131, align 1, !dbg !325
  %356 = load i8, ptr %131, align 1, !dbg !325
  store i8 %356, ptr %129, align 1, !dbg !322
  call void @llvm.dbg.declare(metadata ptr %132, metadata !326, metadata !DIExpression()), !dbg !322
  call void @llvm.dbg.declare(metadata ptr %133, metadata !327, metadata !DIExpression()), !dbg !329
  store i64 0, ptr %133, align 8, !dbg !329
  %357 = load i64, ptr %133, align 8, !dbg !329
  store i64 %357, ptr %134, align 8, !dbg !329
  %358 = load i64, ptr %134, align 8, !dbg !329
  store i64 %358, ptr %132, align 8, !dbg !322
  call void @llvm.dbg.declare(metadata ptr %135, metadata !330, metadata !DIExpression()), !dbg !322
  store ptr null, ptr %135, align 8, !dbg !322
  call void @llvm.dbg.declare(metadata ptr %136, metadata !331, metadata !DIExpression()), !dbg !322
  call void @llvm.dbg.declare(metadata ptr %137, metadata !332, metadata !DIExpression()), !dbg !334
  %359 = load i8, ptr %129, align 1, !dbg !334
  %360 = zext i8 %359 to i32, !dbg !334
  %361 = icmp eq i32 %360, 8, !dbg !334
  br i1 %361, label %362, label %363, !dbg !334

362:                                              ; preds = %354
  br label %363

363:                                              ; preds = %362, %354
  %364 = phi i1 [ false, %354 ], [ false, %362 ], !dbg !335
  %365 = zext i1 %364 to i64, !dbg !334
  %366 = select i1 %364, i64 -4294967296, i64 0, !dbg !334
  store i64 %366, ptr %137, align 8, !dbg !334
  %367 = load i64, ptr %137, align 8, !dbg !334
  store i64 %367, ptr %138, align 8, !dbg !334
  %368 = load i64, ptr %138, align 8, !dbg !334
  store i64 %368, ptr %136, align 8, !dbg !322
  call void @llvm.dbg.declare(metadata ptr %139, metadata !336, metadata !DIExpression()), !dbg !338
  %369 = load i64, ptr %136, align 8, !dbg !338
  call void @llvm.dbg.declare(metadata ptr %140, metadata !339, metadata !DIExpression()), !dbg !341
  store i32 0, ptr %140, align 4, !dbg !341
  %370 = load i32, ptr %140, align 4, !dbg !341
  store i32 %370, ptr %141, align 4, !dbg !341
  %371 = load i32, ptr %141, align 4, !dbg !341
  %372 = zext i32 %371 to i64, !dbg !338
  %373 = lshr i64 %369, %372, !dbg !338
  store i64 %373, ptr %139, align 8, !dbg !338
  %374 = load i64, ptr %139, align 8, !dbg !338
  store i64 %374, ptr %142, align 8, !dbg !338
  %375 = load i64, ptr %142, align 8, !dbg !338
  store i64 %375, ptr %136, align 8, !dbg !322
  call void @llvm.dbg.declare(metadata ptr %143, metadata !342, metadata !DIExpression()), !dbg !344
  %376 = load i64, ptr %132, align 8, !dbg !344
  store i64 %376, ptr %143, align 8, !dbg !344
  call void @llvm.dbg.declare(metadata ptr %144, metadata !345, metadata !DIExpression()), !dbg !344
  store i32 0, ptr %144, align 4, !dbg !344
  call void @llvm.dbg.declare(metadata ptr %145, metadata !346, metadata !DIExpression()), !dbg !344
  %377 = load i64, ptr %143, align 8, !dbg !344
  store i64 %377, ptr %145, align 8, !dbg !344
  %378 = load i32, ptr %144, align 4, !dbg !347
  %379 = icmp ne i32 %378, 0, !dbg !347
  br i1 %379, label %380, label %395, !dbg !344

380:                                              ; preds = %363
  call void @llvm.dbg.declare(metadata ptr %146, metadata !349, metadata !DIExpression()), !dbg !351
  store i8 0, ptr %146, align 1, !dbg !351
  call void @llvm.dbg.declare(metadata ptr %147, metadata !352, metadata !DIExpression()), !dbg !351
  store i64 0, ptr %147, align 8, !dbg !351
  %381 = load i8, ptr %146, align 1, !dbg !351
  %382 = zext i8 %381 to i32, !dbg !351
  %383 = icmp ult i32 %382, 64, !dbg !351
  br i1 %383, label %384, label %390, !dbg !351

384:                                              ; preds = %380
  %385 = load i64, ptr %147, align 8, !dbg !351
  %386 = load i8, ptr %146, align 1, !dbg !351
  %387 = zext i8 %386 to i32, !dbg !351
  %388 = zext i32 %387 to i64, !dbg !351
  %389 = shl i64 %385, %388, !dbg !351
  br label %391, !dbg !351

390:                                              ; preds = %380
  br label %391, !dbg !351

391:                                              ; preds = %390, %384
  %392 = phi i64 [ %389, %384 ], [ 0, %390 ], !dbg !351
  %393 = load i64, ptr %145, align 8, !dbg !351
  %394 = add i64 %393, %392, !dbg !351
  store i64 %394, ptr %145, align 8, !dbg !351
  br label %395, !dbg !351

395:                                              ; preds = %391, %363
  %396 = load i64, ptr %145, align 8, !dbg !344
  store i64 %396, ptr %148, align 8, !dbg !347
  %397 = load i64, ptr %148, align 8, !dbg !344
  store i64 %397, ptr %132, align 8, !dbg !322
  call void @llvm.dbg.declare(metadata ptr %149, metadata !353, metadata !DIExpression()), !dbg !322
  %398 = load i64, ptr %132, align 8, !dbg !322
  store i64 %398, ptr %149, align 8, !dbg !322
  %399 = load ptr, ptr %54, align 8, !dbg !354
  store ptr %399, ptr %135, align 8, !dbg !354
  %400 = load i8, ptr %32, align 1, !dbg !356
  %401 = zext i8 %400 to i32, !dbg !356
  %402 = icmp eq i32 %401, 1, !dbg !356
  br i1 %402, label %403, label %812, !dbg !356

403:                                              ; preds = %395
  call void @llvm.dbg.declare(metadata ptr %150, metadata !358, metadata !DIExpression()), !dbg !360
  store i8 0, ptr %150, align 1, !dbg !360
  %404 = load i8, ptr %55, align 1, !dbg !360
  store i8 %404, ptr %150, align 1, !dbg !360
  %405 = load i8, ptr %150, align 1, !dbg !360
  store i8 %405, ptr %151, align 1, !dbg !360
  %406 = load i8, ptr %151, align 1, !dbg !360
  %407 = zext i8 %406 to i32, !dbg !356
  %408 = icmp eq i32 %407, 1, !dbg !356
  br i1 %408, label %409, label %812, !dbg !322

409:                                              ; preds = %403
  br label %410, !dbg !356

410:                                              ; preds = %409
  call void @llvm.dbg.declare(metadata ptr %152, metadata !361, metadata !DIExpression()), !dbg !363
  %411 = load i8, ptr %129, align 1, !dbg !363
  store i8 %411, ptr %152, align 1, !dbg !363
  call void @llvm.dbg.declare(metadata ptr %153, metadata !364, metadata !DIExpression()), !dbg !363
  %412 = load ptr, ptr %54, align 8, !dbg !363
  %413 = ptrtoint ptr %412 to i64, !dbg !363
  %414 = load ptr, ptr %37, align 8, !dbg !363
  %415 = ptrtoint ptr %414 to i64, !dbg !363
  %416 = sub i64 %413, %415, !dbg !363
  %417 = load i64, ptr %132, align 8, !dbg !363
  %418 = add i64 %416, %417, !dbg !363
  store i64 %418, ptr %153, align 8, !dbg !363
  call void @llvm.dbg.declare(metadata ptr %154, metadata !365, metadata !DIExpression()), !dbg !363
  %419 = load i64, ptr %136, align 8, !dbg !363
  %420 = load i8, ptr %129, align 1, !dbg !363
  store i64 %419, ptr %26, align 8
  call void @llvm.dbg.declare(metadata ptr %26, metadata !366, metadata !DIExpression()), !dbg !371
  store i8 %420, ptr %27, align 1
  call void @llvm.dbg.declare(metadata ptr %27, metadata !373, metadata !DIExpression()), !dbg !374
  %421 = load i64, ptr %26, align 8, !dbg !375
  %422 = load i8, ptr %27, align 1, !dbg !375
  %423 = zext i8 %422 to i32, !dbg !375
  %424 = icmp eq i32 %423, 1, !dbg !375
  br i1 %424, label %425, label %426, !dbg !375

425:                                              ; preds = %410
  br label %439, !dbg !375

426:                                              ; preds = %410
  %427 = load i8, ptr %27, align 1, !dbg !375
  %428 = zext i8 %427 to i32, !dbg !375
  %429 = icmp eq i32 %428, 2, !dbg !375
  br i1 %429, label %430, label %431, !dbg !375

430:                                              ; preds = %426
  br label %437, !dbg !375

431:                                              ; preds = %426
  %432 = load i8, ptr %27, align 1, !dbg !375
  %433 = zext i8 %432 to i32, !dbg !375
  %434 = icmp eq i32 %433, 4, !dbg !375
  %435 = zext i1 %434 to i64, !dbg !375
  %436 = select i1 %434, i64 4294967295, i64 -1, !dbg !375
  br label %437, !dbg !375

437:                                              ; preds = %431, %430
  %438 = phi i64 [ 65535, %430 ], [ %436, %431 ], !dbg !375
  br label %439, !dbg !375

439:                                              ; preds = %425, %437
  %440 = phi i64 [ 255, %425 ], [ %438, %437 ], !dbg !375
  %441 = and i64 %421, %440, !dbg !375
  store i64 %441, ptr %154, align 8, !dbg !363
  %442 = load i64, ptr %153, align 8, !dbg !376
  %443 = icmp sge i64 %442, 48, !dbg !376
  br i1 %443, label %444, label %606, !dbg !376

444:                                              ; preds = %439
  %445 = load i64, ptr %153, align 8, !dbg !376
  %446 = load i8, ptr %129, align 1, !dbg !376
  %447 = zext i8 %446 to i64, !dbg !376
  %448 = sub nsw i64 68, %447, !dbg !376
  %449 = icmp sle i64 %445, %448, !dbg !376
  br i1 %449, label %450, label %606, !dbg !363

450:                                              ; preds = %444
  call void @llvm.dbg.declare(metadata ptr %155, metadata !378, metadata !DIExpression()), !dbg !380
  %451 = load i64, ptr %153, align 8, !dbg !380
  %452 = sub nsw i64 %451, 48, !dbg !380
  %453 = add i64 %452, 48, !dbg !380
  store i64 %453, ptr %155, align 8, !dbg !380
  br label %454, !dbg !380

454:                                              ; preds = %450
  call void @llvm.dbg.declare(metadata ptr %156, metadata !381, metadata !DIExpression()), !dbg !383
  %455 = load i64, ptr %155, align 8, !dbg !384
  %456 = call i1 @llvm.is.constant.i64(i64 %455), !dbg !384
  br i1 %456, label %457, label %523, !dbg !383

457:                                              ; preds = %454
  %458 = load i8, ptr %129, align 1, !dbg !386
  %459 = zext i8 %458 to i32, !dbg !386
  %460 = icmp eq i32 %459, 8, !dbg !386
  br i1 %460, label %461, label %481, !dbg !389

461:                                              ; preds = %457
  %462 = load ptr, ptr %36, align 8, !dbg !386
  %463 = load i64, ptr %154, align 8, !dbg !386
  %464 = load i64, ptr %155, align 8, !dbg !386
  %465 = add nsw i64 %464, 0, !dbg !386
  %466 = load i64, ptr %155, align 8, !dbg !386
  %467 = add nsw i64 %466, 1, !dbg !386
  %468 = load i64, ptr %155, align 8, !dbg !386
  %469 = add nsw i64 %468, 2, !dbg !386
  %470 = load i64, ptr %155, align 8, !dbg !386
  %471 = add nsw i64 %470, 3, !dbg !386
  %472 = load i64, ptr %155, align 8, !dbg !386
  %473 = add nsw i64 %472, 4, !dbg !386
  %474 = load i64, ptr %155, align 8, !dbg !386
  %475 = add nsw i64 %474, 5, !dbg !386
  %476 = load i64, ptr %155, align 8, !dbg !386
  %477 = add nsw i64 %476, 6, !dbg !386
  %478 = load i64, ptr %155, align 8, !dbg !386
  %479 = add nsw i64 %478, 7, !dbg !386
  %480 = call i64 asm sideeffect "$0 = $2\0A*(u8 *)($1 + $3) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $4) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $5) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $6) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $7) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $8) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $9) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $10) = $0", "=&r,r,r,i,i,i,i,i,i,i,i,~{memory}"(ptr %462, i64 %463, i64 %465, i64 %467, i64 %469, i64 %471, i64 %473, i64 %475, i64 %477, i64 %479) #5, !dbg !386, !srcloc !390
  store i64 %480, ptr %156, align 8, !dbg !386
  br label %522, !dbg !386

481:                                              ; preds = %457
  %482 = load i8, ptr %129, align 1, !dbg !391
  %483 = zext i8 %482 to i32, !dbg !391
  %484 = icmp eq i32 %483, 4, !dbg !391
  br i1 %484, label %485, label %497, !dbg !386

485:                                              ; preds = %481
  %486 = load ptr, ptr %36, align 8, !dbg !391
  %487 = load i64, ptr %154, align 8, !dbg !391
  %488 = load i64, ptr %155, align 8, !dbg !391
  %489 = add nsw i64 %488, 0, !dbg !391
  %490 = load i64, ptr %155, align 8, !dbg !391
  %491 = add nsw i64 %490, 1, !dbg !391
  %492 = load i64, ptr %155, align 8, !dbg !391
  %493 = add nsw i64 %492, 2, !dbg !391
  %494 = load i64, ptr %155, align 8, !dbg !391
  %495 = add nsw i64 %494, 3, !dbg !391
  %496 = call i64 asm sideeffect "$0 = $2\0A*(u8 *)($1 + $3) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $4) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $5) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $6) = $0", "=&r,r,r,i,i,i,i,~{memory}"(ptr %486, i64 %487, i64 %489, i64 %491, i64 %493, i64 %495) #5, !dbg !391, !srcloc !393
  store i64 %496, ptr %156, align 8, !dbg !391
  br label %521, !dbg !391

497:                                              ; preds = %481
  %498 = load i8, ptr %129, align 1, !dbg !394
  %499 = zext i8 %498 to i32, !dbg !394
  %500 = icmp eq i32 %499, 2, !dbg !394
  br i1 %500, label %501, label %509, !dbg !391

501:                                              ; preds = %497
  %502 = load ptr, ptr %36, align 8, !dbg !394
  %503 = load i64, ptr %154, align 8, !dbg !394
  %504 = load i64, ptr %155, align 8, !dbg !394
  %505 = add nsw i64 %504, 0, !dbg !394
  %506 = load i64, ptr %155, align 8, !dbg !394
  %507 = add nsw i64 %506, 1, !dbg !394
  %508 = call i64 asm sideeffect "$0 = $2\0A*(u8 *)($1 + $3) = $0\0A$0 >>= 8\0A*(u8 *)($1 + $4) = $0", "=&r,r,r,i,i,~{memory}"(ptr %502, i64 %503, i64 %505, i64 %507) #5, !dbg !394, !srcloc !396
  store i64 %508, ptr %156, align 8, !dbg !394
  br label %520, !dbg !394

509:                                              ; preds = %497
  %510 = load i8, ptr %129, align 1, !dbg !397
  %511 = zext i8 %510 to i32, !dbg !397
  %512 = icmp eq i32 %511, 1, !dbg !397
  br i1 %512, label %513, label %519, !dbg !394

513:                                              ; preds = %509
  %514 = load ptr, ptr %36, align 8, !dbg !397
  %515 = load i64, ptr %154, align 8, !dbg !397
  %516 = load i64, ptr %155, align 8, !dbg !397
  %517 = add nsw i64 %516, 0, !dbg !397
  %518 = call i64 asm sideeffect "$0 = $2\0A*(u8 *)($1 + $3) = $0", "=&r,r,r,i,~{memory}"(ptr %514, i64 %515, i64 %517) #5, !dbg !397, !srcloc !399
  store i64 %518, ptr %156, align 8, !dbg !397
  br label %519, !dbg !397

519:                                              ; preds = %513, %509
  br label %520

520:                                              ; preds = %519, %501
  br label %521

521:                                              ; preds = %520, %485
  br label %522

522:                                              ; preds = %521, %461
  br label %604, !dbg !389

523:                                              ; preds = %454
  br label %524, !dbg !384

524:                                              ; preds = %523
  call void @llvm.dbg.declare(metadata ptr %157, metadata !400, metadata !DIExpression()), !dbg !402
  %525 = load ptr, ptr %36, align 8, !dbg !402
  %526 = load i64, ptr %155, align 8, !dbg !402
  %527 = getelementptr inbounds i8, ptr %525, i64 %526, !dbg !402
  store ptr %527, ptr %157, align 8, !dbg !402
  call void @llvm.dbg.declare(metadata ptr %158, metadata !403, metadata !DIExpression()), !dbg !402
  %528 = load i64, ptr %154, align 8, !dbg !402
  store i64 %528, ptr %158, align 8, !dbg !402
  %529 = load i64, ptr %158, align 8, !dbg !402
  %530 = trunc i64 %529 to i8, !dbg !402
  %531 = load ptr, ptr %157, align 8, !dbg !402
  %532 = getelementptr inbounds i8, ptr %531, i64 0, !dbg !402
  store volatile i8 %530, ptr %532, align 1, !dbg !402
  %533 = load i8, ptr %129, align 1, !dbg !404
  %534 = zext i8 %533 to i32, !dbg !404
  %535 = icmp uge i32 %534, 2, !dbg !404
  br i1 %535, label %536, label %542, !dbg !402

536:                                              ; preds = %524
  %537 = load i64, ptr %158, align 8, !dbg !404
  %538 = lshr i64 %537, 8, !dbg !404
  %539 = trunc i64 %538 to i8, !dbg !404
  %540 = load ptr, ptr %157, align 8, !dbg !404
  %541 = getelementptr inbounds i8, ptr %540, i64 1, !dbg !404
  store volatile i8 %539, ptr %541, align 1, !dbg !404
  br label %542, !dbg !404

542:                                              ; preds = %536, %524
  %543 = load i8, ptr %129, align 1, !dbg !406
  %544 = zext i8 %543 to i32, !dbg !406
  %545 = icmp uge i32 %544, 4, !dbg !406
  br i1 %545, label %546, label %552, !dbg !402

546:                                              ; preds = %542
  %547 = load i64, ptr %158, align 8, !dbg !406
  %548 = lshr i64 %547, 16, !dbg !406
  %549 = trunc i64 %548 to i8, !dbg !406
  %550 = load ptr, ptr %157, align 8, !dbg !406
  %551 = getelementptr inbounds i8, ptr %550, i64 2, !dbg !406
  store volatile i8 %549, ptr %551, align 1, !dbg !406
  br label %552, !dbg !406

552:                                              ; preds = %546, %542
  %553 = load i8, ptr %129, align 1, !dbg !408
  %554 = zext i8 %553 to i32, !dbg !408
  %555 = icmp uge i32 %554, 4, !dbg !408
  br i1 %555, label %556, label %562, !dbg !402

556:                                              ; preds = %552
  %557 = load i64, ptr %158, align 8, !dbg !408
  %558 = lshr i64 %557, 24, !dbg !408
  %559 = trunc i64 %558 to i8, !dbg !408
  %560 = load ptr, ptr %157, align 8, !dbg !408
  %561 = getelementptr inbounds i8, ptr %560, i64 3, !dbg !408
  store volatile i8 %559, ptr %561, align 1, !dbg !408
  br label %562, !dbg !408

562:                                              ; preds = %556, %552
  %563 = load i8, ptr %129, align 1, !dbg !410
  %564 = zext i8 %563 to i32, !dbg !410
  %565 = icmp uge i32 %564, 8, !dbg !410
  br i1 %565, label %566, label %572, !dbg !402

566:                                              ; preds = %562
  %567 = load i64, ptr %158, align 8, !dbg !410
  %568 = lshr i64 %567, 32, !dbg !410
  %569 = trunc i64 %568 to i8, !dbg !410
  %570 = load ptr, ptr %157, align 8, !dbg !410
  %571 = getelementptr inbounds i8, ptr %570, i64 4, !dbg !410
  store volatile i8 %569, ptr %571, align 1, !dbg !410
  br label %572, !dbg !410

572:                                              ; preds = %566, %562
  %573 = load i8, ptr %129, align 1, !dbg !412
  %574 = zext i8 %573 to i32, !dbg !412
  %575 = icmp uge i32 %574, 8, !dbg !412
  br i1 %575, label %576, label %582, !dbg !402

576:                                              ; preds = %572
  %577 = load i64, ptr %158, align 8, !dbg !412
  %578 = lshr i64 %577, 40, !dbg !412
  %579 = trunc i64 %578 to i8, !dbg !412
  %580 = load ptr, ptr %157, align 8, !dbg !412
  %581 = getelementptr inbounds i8, ptr %580, i64 5, !dbg !412
  store volatile i8 %579, ptr %581, align 1, !dbg !412
  br label %582, !dbg !412

582:                                              ; preds = %576, %572
  %583 = load i8, ptr %129, align 1, !dbg !414
  %584 = zext i8 %583 to i32, !dbg !414
  %585 = icmp uge i32 %584, 8, !dbg !414
  br i1 %585, label %586, label %592, !dbg !402

586:                                              ; preds = %582
  %587 = load i64, ptr %158, align 8, !dbg !414
  %588 = lshr i64 %587, 48, !dbg !414
  %589 = trunc i64 %588 to i8, !dbg !414
  %590 = load ptr, ptr %157, align 8, !dbg !414
  %591 = getelementptr inbounds i8, ptr %590, i64 6, !dbg !414
  store volatile i8 %589, ptr %591, align 1, !dbg !414
  br label %592, !dbg !414

592:                                              ; preds = %586, %582
  %593 = load i8, ptr %129, align 1, !dbg !416
  %594 = zext i8 %593 to i32, !dbg !416
  %595 = icmp uge i32 %594, 8, !dbg !416
  br i1 %595, label %596, label %602, !dbg !402

596:                                              ; preds = %592
  %597 = load i64, ptr %158, align 8, !dbg !416
  %598 = lshr i64 %597, 56, !dbg !416
  %599 = trunc i64 %598 to i8, !dbg !416
  %600 = load ptr, ptr %157, align 8, !dbg !416
  %601 = getelementptr inbounds i8, ptr %600, i64 7, !dbg !416
  store volatile i8 %599, ptr %601, align 1, !dbg !416
  br label %602, !dbg !416

602:                                              ; preds = %596, %592
  br label %603, !dbg !402

603:                                              ; preds = %602
  br label %604

604:                                              ; preds = %603, %522
  br label %605, !dbg !383

605:                                              ; preds = %604
  br label %810, !dbg !380

606:                                              ; preds = %444, %439
  %607 = load i64, ptr %153, align 8, !dbg !418
  %608 = icmp sge i64 %607, 134, !dbg !418
  br i1 %608, label %609, label %662, !dbg !418

609:                                              ; preds = %606
  %610 = load i64, ptr %153, align 8, !dbg !418
  %611 = load i8, ptr %152, align 1, !dbg !418
  %612 = zext i8 %611 to i32, !dbg !418
  %613 = sub nsw i32 136, %612, !dbg !418
  %614 = sext i32 %613 to i64, !dbg !418
  %615 = icmp sle i64 %610, %614, !dbg !418
  br i1 %615, label %616, label %662, !dbg !376

616:                                              ; preds = %609
  call void @llvm.dbg.declare(metadata ptr %159, metadata !420, metadata !DIExpression()), !dbg !422
  call void @llvm.dbg.declare(metadata ptr %160, metadata !423, metadata !DIExpression()), !dbg !425
  %617 = load ptr, ptr %36, align 8, !dbg !425
  %618 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %617, i64 44) #5, !dbg !425, !srcloc !426
  store i64 %618, ptr %160, align 8, !dbg !425
  %619 = load i64, ptr %160, align 8, !dbg !425
  store i64 %619, ptr %161, align 8, !dbg !425
  %620 = load i64, ptr %161, align 8, !dbg !425
  %621 = and i64 %620, 65535, !dbg !422
  store i64 %621, ptr %159, align 8, !dbg !422
  call void @llvm.dbg.declare(metadata ptr %162, metadata !427, metadata !DIExpression()), !dbg !422
  %622 = load i64, ptr %153, align 8, !dbg !422
  %623 = sub nsw i64 %622, 134, !dbg !422
  %624 = mul nsw i64 %623, 8, !dbg !422
  store i64 %624, ptr %162, align 8, !dbg !422
  call void @llvm.dbg.declare(metadata ptr %163, metadata !428, metadata !DIExpression()), !dbg !422
  %625 = load i8, ptr %152, align 1, !dbg !422
  store i8 %625, ptr %21, align 1
  call void @llvm.dbg.declare(metadata ptr %21, metadata !429, metadata !DIExpression()), !dbg !433
  %626 = load i8, ptr %21, align 1, !dbg !435
  %627 = zext i8 %626 to i32, !dbg !435
  %628 = icmp eq i32 %627, 1, !dbg !435
  br i1 %628, label %629, label %630, !dbg !435

629:                                              ; preds = %616
  br label %643, !dbg !435

630:                                              ; preds = %616
  %631 = load i8, ptr %21, align 1, !dbg !435
  %632 = zext i8 %631 to i32, !dbg !435
  %633 = icmp eq i32 %632, 2, !dbg !435
  br i1 %633, label %634, label %635, !dbg !435

634:                                              ; preds = %630
  br label %641, !dbg !435

635:                                              ; preds = %630
  %636 = load i8, ptr %21, align 1, !dbg !435
  %637 = zext i8 %636 to i32, !dbg !435
  %638 = icmp eq i32 %637, 4, !dbg !435
  %639 = zext i1 %638 to i64, !dbg !435
  %640 = select i1 %638, i64 4294967295, i64 -1, !dbg !435
  br label %641, !dbg !435

641:                                              ; preds = %635, %634
  %642 = phi i64 [ 65535, %634 ], [ %640, %635 ], !dbg !435
  br label %643, !dbg !435

643:                                              ; preds = %629, %641
  %644 = phi i64 [ 255, %629 ], [ %642, %641 ], !dbg !435
  %645 = load i64, ptr %162, align 8, !dbg !422
  %646 = shl i64 %644, %645, !dbg !422
  store i64 %646, ptr %163, align 8, !dbg !422
  call void @llvm.dbg.declare(metadata ptr %164, metadata !436, metadata !DIExpression()), !dbg !422
  %647 = load i64, ptr %159, align 8, !dbg !422
  %648 = load i64, ptr %163, align 8, !dbg !422
  %649 = xor i64 %648, -1, !dbg !422
  %650 = and i64 %647, %649, !dbg !422
  %651 = load i64, ptr %154, align 8, !dbg !422
  %652 = load i64, ptr %162, align 8, !dbg !422
  %653 = shl i64 %651, %652, !dbg !422
  %654 = load i64, ptr %163, align 8, !dbg !422
  %655 = and i64 %653, %654, !dbg !422
  %656 = or i64 %650, %655, !dbg !422
  store i64 %656, ptr %164, align 8, !dbg !422
  br label %657, !dbg !422

657:                                              ; preds = %643
  call void @llvm.dbg.declare(metadata ptr %165, metadata !437, metadata !DIExpression()), !dbg !439
  %658 = load i64, ptr %164, align 8, !dbg !439
  store i64 %658, ptr %165, align 8, !dbg !439
  %659 = load ptr, ptr %36, align 8, !dbg !439
  %660 = load i64, ptr %165, align 8, !dbg !439
  call void asm sideeffect "*(u32 *)($0 + $1) = $2", "r,i,r,~{memory}"(ptr %659, i64 44, i64 %660) #5, !dbg !439, !srcloc !440
  br label %661, !dbg !439

661:                                              ; preds = %657
  br label %809, !dbg !422

662:                                              ; preds = %609, %606
  %663 = load i64, ptr %153, align 8, !dbg !441
  %664 = icmp sge i64 %663, 144, !dbg !441
  br i1 %664, label %665, label %718, !dbg !441

665:                                              ; preds = %662
  %666 = load i64, ptr %153, align 8, !dbg !441
  %667 = load i8, ptr %152, align 1, !dbg !441
  %668 = zext i8 %667 to i32, !dbg !441
  %669 = sub nsw i32 148, %668, !dbg !441
  %670 = sext i32 %669 to i64, !dbg !441
  %671 = icmp sle i64 %666, %670, !dbg !441
  br i1 %671, label %672, label %718, !dbg !418

672:                                              ; preds = %665
  call void @llvm.dbg.declare(metadata ptr %166, metadata !443, metadata !DIExpression()), !dbg !445
  call void @llvm.dbg.declare(metadata ptr %167, metadata !446, metadata !DIExpression()), !dbg !448
  %673 = load ptr, ptr %36, align 8, !dbg !448
  %674 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %673, i64 32) #5, !dbg !448, !srcloc !449
  store i64 %674, ptr %167, align 8, !dbg !448
  %675 = load i64, ptr %167, align 8, !dbg !448
  store i64 %675, ptr %168, align 8, !dbg !448
  %676 = load i64, ptr %168, align 8, !dbg !448
  %677 = and i64 %676, 4294967295, !dbg !445
  store i64 %677, ptr %166, align 8, !dbg !445
  call void @llvm.dbg.declare(metadata ptr %169, metadata !450, metadata !DIExpression()), !dbg !445
  %678 = load i64, ptr %153, align 8, !dbg !445
  %679 = sub nsw i64 %678, 144, !dbg !445
  %680 = mul nsw i64 %679, 8, !dbg !445
  store i64 %680, ptr %169, align 8, !dbg !445
  call void @llvm.dbg.declare(metadata ptr %170, metadata !451, metadata !DIExpression()), !dbg !445
  %681 = load i8, ptr %152, align 1, !dbg !445
  store i8 %681, ptr %22, align 1
  call void @llvm.dbg.declare(metadata ptr %22, metadata !429, metadata !DIExpression()), !dbg !452
  %682 = load i8, ptr %22, align 1, !dbg !454
  %683 = zext i8 %682 to i32, !dbg !454
  %684 = icmp eq i32 %683, 1, !dbg !454
  br i1 %684, label %685, label %686, !dbg !454

685:                                              ; preds = %672
  br label %699, !dbg !454

686:                                              ; preds = %672
  %687 = load i8, ptr %22, align 1, !dbg !454
  %688 = zext i8 %687 to i32, !dbg !454
  %689 = icmp eq i32 %688, 2, !dbg !454
  br i1 %689, label %690, label %691, !dbg !454

690:                                              ; preds = %686
  br label %697, !dbg !454

691:                                              ; preds = %686
  %692 = load i8, ptr %22, align 1, !dbg !454
  %693 = zext i8 %692 to i32, !dbg !454
  %694 = icmp eq i32 %693, 4, !dbg !454
  %695 = zext i1 %694 to i64, !dbg !454
  %696 = select i1 %694, i64 4294967295, i64 -1, !dbg !454
  br label %697, !dbg !454

697:                                              ; preds = %691, %690
  %698 = phi i64 [ 65535, %690 ], [ %696, %691 ], !dbg !454
  br label %699, !dbg !454

699:                                              ; preds = %685, %697
  %700 = phi i64 [ 255, %685 ], [ %698, %697 ], !dbg !454
  %701 = load i64, ptr %169, align 8, !dbg !445
  %702 = shl i64 %700, %701, !dbg !445
  store i64 %702, ptr %170, align 8, !dbg !445
  call void @llvm.dbg.declare(metadata ptr %171, metadata !455, metadata !DIExpression()), !dbg !445
  %703 = load i64, ptr %166, align 8, !dbg !445
  %704 = load i64, ptr %170, align 8, !dbg !445
  %705 = xor i64 %704, -1, !dbg !445
  %706 = and i64 %703, %705, !dbg !445
  %707 = load i64, ptr %154, align 8, !dbg !445
  %708 = load i64, ptr %169, align 8, !dbg !445
  %709 = shl i64 %707, %708, !dbg !445
  %710 = load i64, ptr %170, align 8, !dbg !445
  %711 = and i64 %709, %710, !dbg !445
  %712 = or i64 %706, %711, !dbg !445
  store i64 %712, ptr %171, align 8, !dbg !445
  br label %713, !dbg !445

713:                                              ; preds = %699
  call void @llvm.dbg.declare(metadata ptr %172, metadata !456, metadata !DIExpression()), !dbg !458
  %714 = load i64, ptr %171, align 8, !dbg !458
  store i64 %714, ptr %172, align 8, !dbg !458
  %715 = load ptr, ptr %36, align 8, !dbg !458
  %716 = load i64, ptr %172, align 8, !dbg !458
  call void asm sideeffect "*(u32 *)($0 + $1) = $2", "r,i,r,~{memory}"(ptr %715, i64 32, i64 %716) #5, !dbg !458, !srcloc !459
  br label %717, !dbg !458

717:                                              ; preds = %713
  br label %808, !dbg !445

718:                                              ; preds = %665, %662
  %719 = load i64, ptr %153, align 8, !dbg !460
  %720 = icmp sge i64 %719, 168, !dbg !460
  br i1 %720, label %721, label %774, !dbg !460

721:                                              ; preds = %718
  %722 = load i64, ptr %153, align 8, !dbg !460
  %723 = load i8, ptr %152, align 1, !dbg !460
  %724 = zext i8 %723 to i32, !dbg !460
  %725 = sub nsw i32 172, %724, !dbg !460
  %726 = sext i32 %725 to i64, !dbg !460
  %727 = icmp sle i64 %722, %726, !dbg !460
  br i1 %727, label %728, label %774, !dbg !441

728:                                              ; preds = %721
  call void @llvm.dbg.declare(metadata ptr %173, metadata !462, metadata !DIExpression()), !dbg !464
  call void @llvm.dbg.declare(metadata ptr %174, metadata !465, metadata !DIExpression()), !dbg !467
  %729 = load ptr, ptr %36, align 8, !dbg !467
  %730 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %729, i64 8) #5, !dbg !467, !srcloc !468
  store i64 %730, ptr %174, align 8, !dbg !467
  %731 = load i64, ptr %174, align 8, !dbg !467
  store i64 %731, ptr %175, align 8, !dbg !467
  %732 = load i64, ptr %175, align 8, !dbg !467
  %733 = and i64 %732, 4294967295, !dbg !464
  store i64 %733, ptr %173, align 8, !dbg !464
  call void @llvm.dbg.declare(metadata ptr %176, metadata !469, metadata !DIExpression()), !dbg !464
  %734 = load i64, ptr %153, align 8, !dbg !464
  %735 = sub nsw i64 %734, 168, !dbg !464
  %736 = mul nsw i64 %735, 8, !dbg !464
  store i64 %736, ptr %176, align 8, !dbg !464
  call void @llvm.dbg.declare(metadata ptr %177, metadata !470, metadata !DIExpression()), !dbg !464
  %737 = load i8, ptr %152, align 1, !dbg !464
  store i8 %737, ptr %23, align 1
  call void @llvm.dbg.declare(metadata ptr %23, metadata !429, metadata !DIExpression()), !dbg !471
  %738 = load i8, ptr %23, align 1, !dbg !473
  %739 = zext i8 %738 to i32, !dbg !473
  %740 = icmp eq i32 %739, 1, !dbg !473
  br i1 %740, label %741, label %742, !dbg !473

741:                                              ; preds = %728
  br label %755, !dbg !473

742:                                              ; preds = %728
  %743 = load i8, ptr %23, align 1, !dbg !473
  %744 = zext i8 %743 to i32, !dbg !473
  %745 = icmp eq i32 %744, 2, !dbg !473
  br i1 %745, label %746, label %747, !dbg !473

746:                                              ; preds = %742
  br label %753, !dbg !473

747:                                              ; preds = %742
  %748 = load i8, ptr %23, align 1, !dbg !473
  %749 = zext i8 %748 to i32, !dbg !473
  %750 = icmp eq i32 %749, 4, !dbg !473
  %751 = zext i1 %750 to i64, !dbg !473
  %752 = select i1 %750, i64 4294967295, i64 -1, !dbg !473
  br label %753, !dbg !473

753:                                              ; preds = %747, %746
  %754 = phi i64 [ 65535, %746 ], [ %752, %747 ], !dbg !473
  br label %755, !dbg !473

755:                                              ; preds = %741, %753
  %756 = phi i64 [ 255, %741 ], [ %754, %753 ], !dbg !473
  %757 = load i64, ptr %176, align 8, !dbg !464
  %758 = shl i64 %756, %757, !dbg !464
  store i64 %758, ptr %177, align 8, !dbg !464
  call void @llvm.dbg.declare(metadata ptr %178, metadata !474, metadata !DIExpression()), !dbg !464
  %759 = load i64, ptr %173, align 8, !dbg !464
  %760 = load i64, ptr %177, align 8, !dbg !464
  %761 = xor i64 %760, -1, !dbg !464
  %762 = and i64 %759, %761, !dbg !464
  %763 = load i64, ptr %154, align 8, !dbg !464
  %764 = load i64, ptr %176, align 8, !dbg !464
  %765 = shl i64 %763, %764, !dbg !464
  %766 = load i64, ptr %177, align 8, !dbg !464
  %767 = and i64 %765, %766, !dbg !464
  %768 = or i64 %762, %767, !dbg !464
  store i64 %768, ptr %178, align 8, !dbg !464
  br label %769, !dbg !464

769:                                              ; preds = %755
  call void @llvm.dbg.declare(metadata ptr %179, metadata !475, metadata !DIExpression()), !dbg !477
  %770 = load i64, ptr %178, align 8, !dbg !477
  store i64 %770, ptr %179, align 8, !dbg !477
  %771 = load ptr, ptr %36, align 8, !dbg !477
  %772 = load i64, ptr %179, align 8, !dbg !477
  call void asm sideeffect "*(u32 *)($0 + $1) = $2", "r,i,r,~{memory}"(ptr %771, i64 8, i64 %772) #5, !dbg !477, !srcloc !478
  br label %773, !dbg !477

773:                                              ; preds = %769
  br label %807, !dbg !464

774:                                              ; preds = %721, %718
  br label %775, !dbg !460

775:                                              ; preds = %774
  br label %776, !dbg !479

776:                                              ; preds = %775
  store i8 0, ptr %33, align 1, !dbg !481
  br label %777, !dbg !481

777:                                              ; preds = %776
  %778 = load ptr, ptr %54, align 8, !dbg !479
  %779 = load i64, ptr %132, align 8, !dbg !479
  %780 = getelementptr inbounds i8, ptr %778, i64 %779, !dbg !479
  %781 = load i8, ptr %129, align 1, !dbg !479
  %782 = load i64, ptr %154, align 8, !dbg !479
  store ptr %780, ptr %15, align 8
  call void @llvm.dbg.declare(metadata ptr %15, metadata !483, metadata !DIExpression()), !dbg !488
  store i8 %781, ptr %16, align 1
  call void @llvm.dbg.declare(metadata ptr %16, metadata !490, metadata !DIExpression()), !dbg !491
  store i64 %782, ptr %17, align 8
  call void @llvm.dbg.declare(metadata ptr %17, metadata !492, metadata !DIExpression()), !dbg !493
  %783 = load i8, ptr %16, align 1, !dbg !494
  %784 = zext i8 %783 to i32, !dbg !494
  %785 = icmp ne i32 %784, 0, !dbg !494
  br i1 %785, label %786, label %789, !dbg !494

786:                                              ; preds = %777
  %787 = load i8, ptr %16, align 1, !dbg !495
  %788 = zext i8 %787 to i32, !dbg !495
  br label %790, !dbg !494

789:                                              ; preds = %777
  br label %790, !dbg !494

790:                                              ; preds = %789, %786
  %791 = phi i32 [ %788, %786 ], [ 8, %789 ], !dbg !494
  switch i32 %791, label %804 [
    i32 1, label %792
    i32 2, label %795
    i32 4, label %798
    i32 8, label %801
  ], !dbg !496

792:                                              ; preds = %790
  %793 = load ptr, ptr %15, align 8, !dbg !497
  %794 = load i64, ptr %17, align 8, !dbg !499
  call void asm sideeffect "*(u8 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %793, i64 %794) #5, !dbg !500, !srcloc !501
  br label %805, !dbg !502

795:                                              ; preds = %790
  %796 = load ptr, ptr %15, align 8, !dbg !503
  %797 = load i64, ptr %17, align 8, !dbg !504
  call void asm sideeffect "*(u16 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %796, i64 %797) #5, !dbg !505, !srcloc !506
  br label %805, !dbg !507

798:                                              ; preds = %790
  %799 = load ptr, ptr %15, align 8, !dbg !508
  %800 = load i64, ptr %17, align 8, !dbg !509
  call void asm sideeffect "*(u32 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %799, i64 %800) #5, !dbg !510, !srcloc !511
  br label %805, !dbg !512

801:                                              ; preds = %790
  %802 = load ptr, ptr %15, align 8, !dbg !513
  %803 = load i64, ptr %17, align 8, !dbg !514
  call void asm sideeffect "*(u64 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %802, i64 %803) #5, !dbg !515, !srcloc !516
  br label %805, !dbg !517

804:                                              ; preds = %790
  call void @llvm.trap(), !dbg !518
  br label %805, !dbg !519

805:                                              ; preds = %792, %795, %798, %801, %804
  br label %806, !dbg !479

806:                                              ; preds = %805
  br label %807

807:                                              ; preds = %806, %773
  br label %808

808:                                              ; preds = %807, %717
  br label %809

809:                                              ; preds = %808, %661
  br label %810

810:                                              ; preds = %809, %605
  br label %811, !dbg !363

811:                                              ; preds = %810
  br label %1605, !dbg !363

812:                                              ; preds = %403, %395
  call void @llvm.dbg.declare(metadata ptr %180, metadata !520, metadata !DIExpression()), !dbg !522
  store i8 0, ptr %180, align 1, !dbg !523
  %813 = load i8, ptr %180, align 1, !dbg !522
  store i8 %813, ptr %181, align 1, !dbg !523
  %814 = load i8, ptr %181, align 1, !dbg !522
  %815 = zext i8 %814 to i32, !dbg !356
  switch i32 %815, label %1160 [
    i32 0, label %816
  ], !dbg !356

816:                                              ; preds = %812
  br label %817, !dbg !525

817:                                              ; preds = %816
  call void @llvm.dbg.declare(metadata ptr %182, metadata !527, metadata !DIExpression()), !dbg !529
  %818 = load ptr, ptr %135, align 8, !dbg !529
  %819 = ptrtoint ptr %818 to i64, !dbg !529
  %820 = load i64, ptr %149, align 8, !dbg !529
  %821 = add nsw i64 %819, %820, !dbg !529
  %822 = add i64 %821, 1, !dbg !529
  store i64 %822, ptr %182, align 8, !dbg !529
  call void @llvm.dbg.declare(metadata ptr %183, metadata !530, metadata !DIExpression()), !dbg !529
  %823 = load i8, ptr %129, align 1, !dbg !529
  store i8 %823, ptr %2, align 1
  call void @llvm.dbg.declare(metadata ptr %2, metadata !531, metadata !DIExpression()), !dbg !535
  %824 = load i8, ptr %2, align 1, !dbg !537
  %825 = zext i8 %824 to i32, !dbg !537
  %826 = icmp ne i32 %825, 0, !dbg !537
  br i1 %826, label %827, label %830, !dbg !537

827:                                              ; preds = %817
  %828 = load i8, ptr %2, align 1, !dbg !537
  %829 = zext i8 %828 to i32, !dbg !537
  br label %831, !dbg !537

830:                                              ; preds = %817
  br label %831, !dbg !537

831:                                              ; preds = %827, %830
  %832 = phi i32 [ %829, %827 ], [ 8, %830 ], !dbg !537
  %833 = trunc i32 %832 to i8, !dbg !537
  %834 = zext i8 %833 to i64, !dbg !529
  store i64 %834, ptr %183, align 8, !dbg !529
  br label %835, !dbg !529

835:                                              ; preds = %831
  call void @llvm.dbg.declare(metadata ptr %184, metadata !538, metadata !DIExpression()), !dbg !540
  store i64 0, ptr %184, align 8, !dbg !540
  %836 = load i64, ptr %182, align 8, !dbg !541
  %837 = load i64, ptr %184, align 8, !dbg !541
  %838 = sub i64 %836, %837, !dbg !541
  %839 = icmp ult i64 %838, 8, !dbg !541
  br i1 %839, label %846, label %840, !dbg !541

840:                                              ; preds = %835
  %841 = load i64, ptr %184, align 8, !dbg !541
  %842 = load i64, ptr %182, align 8, !dbg !541
  %843 = sub i64 %841, %842, !dbg !541
  %844 = load i64, ptr %183, align 8, !dbg !541
  %845 = icmp ult i64 %843, %844, !dbg !541
  br i1 %845, label %846, label %847, !dbg !540

846:                                              ; preds = %840, %835
  store i8 0, ptr %33, align 1, !dbg !541
  br label %847, !dbg !541

847:                                              ; preds = %846, %840
  br label %848, !dbg !540

848:                                              ; preds = %847
  br label %849, !dbg !529

849:                                              ; preds = %848
  br label %850, !dbg !525

850:                                              ; preds = %849
  call void @llvm.dbg.declare(metadata ptr %185, metadata !543, metadata !DIExpression()), !dbg !545
  %851 = load ptr, ptr %135, align 8, !dbg !545
  %852 = ptrtoint ptr %851 to i64, !dbg !545
  %853 = load i64, ptr %132, align 8, !dbg !545
  %854 = add nsw i64 %852, %853, !dbg !545
  %855 = add i64 %854, 1, !dbg !545
  store i64 %855, ptr %185, align 8, !dbg !545
  store i8 8, ptr %3, align 1
  call void @llvm.dbg.declare(metadata ptr %3, metadata !531, metadata !DIExpression()), !dbg !546
  %856 = load i8, ptr %3, align 1, !dbg !549
  %857 = zext i8 %856 to i32, !dbg !549
  %858 = icmp ne i32 %857, 0, !dbg !549
  br i1 %858, label %859, label %862, !dbg !549

859:                                              ; preds = %850
  %860 = load i8, ptr %3, align 1, !dbg !549
  %861 = zext i8 %860 to i32, !dbg !549
  br label %863, !dbg !549

862:                                              ; preds = %850
  br label %863, !dbg !549

863:                                              ; preds = %859, %862
  %864 = phi i32 [ %861, %859 ], [ 8, %862 ], !dbg !549
  %865 = trunc i32 %864 to i8, !dbg !549
  store i8 %865, ptr %4, align 1
  call void @llvm.dbg.declare(metadata ptr %4, metadata !531, metadata !DIExpression()), !dbg !550
  %866 = load i8, ptr %4, align 1, !dbg !552
  %867 = zext i8 %866 to i32, !dbg !552
  %868 = icmp ne i32 %867, 0, !dbg !552
  br i1 %868, label %869, label %872, !dbg !552

869:                                              ; preds = %863
  %870 = load i8, ptr %4, align 1, !dbg !552
  %871 = zext i8 %870 to i32, !dbg !552
  br label %873, !dbg !552

872:                                              ; preds = %863
  br label %873, !dbg !552

873:                                              ; preds = %869, %872
  %874 = phi i32 [ %871, %869 ], [ 8, %872 ], !dbg !552
  %875 = trunc i32 %874 to i8, !dbg !552
  %876 = zext i8 %875 to i32, !dbg !553
  %877 = icmp eq i32 %876, 8, !dbg !553
  br i1 %877, label %878, label %885, !dbg !553

878:                                              ; preds = %873
  %879 = load i64, ptr %185, align 8, !dbg !553
  %880 = and i64 %879, 7, !dbg !553
  %881 = icmp eq i64 %880, 0, !dbg !553
  %882 = zext i1 %881 to i64, !dbg !553
  %883 = select i1 %881, i32 1, i32 0, !dbg !553
  %884 = icmp ne i32 %883, 0, !dbg !553
  br label %885

885:                                              ; preds = %878, %873
  %886 = phi i1 [ false, %873 ], [ %884, %878 ], !dbg !554
  %887 = zext i1 %886 to i64, !dbg !553
  %888 = select i1 %886, i32 1, i32 0, !dbg !553
  %889 = trunc i32 %888 to i8, !dbg !553
  %890 = icmp ne i8 %889, 0, !dbg !553
  br i1 %890, label %891, label %896, !dbg !545

891:                                              ; preds = %885
  %892 = load i64, ptr %136, align 8, !dbg !555
  %893 = load i64, ptr %185, align 8, !dbg !555
  %894 = lshr i64 %893, 3, !dbg !555
  %895 = getelementptr inbounds [1 x i64], ptr %126, i64 0, i64 %894, !dbg !555
  store volatile i64 %892, ptr %895, align 8, !dbg !555
  br label %1158, !dbg !555

896:                                              ; preds = %885
  br label %897, !dbg !557

897:                                              ; preds = %896
  call void @llvm.dbg.declare(metadata ptr %186, metadata !559, metadata !DIExpression()), !dbg !561
  %898 = load i64, ptr %185, align 8, !dbg !561
  %899 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 %898, !dbg !561
  store ptr %899, ptr %186, align 8, !dbg !561
  call void @llvm.dbg.declare(metadata ptr %187, metadata !562, metadata !DIExpression()), !dbg !561
  store i8 8, ptr %5, align 1
  call void @llvm.dbg.declare(metadata ptr %5, metadata !531, metadata !DIExpression()), !dbg !563
  %900 = load i8, ptr %5, align 1, !dbg !565
  %901 = zext i8 %900 to i32, !dbg !565
  %902 = icmp ne i32 %901, 0, !dbg !565
  br i1 %902, label %903, label %906, !dbg !565

903:                                              ; preds = %897
  %904 = load i8, ptr %5, align 1, !dbg !565
  %905 = zext i8 %904 to i32, !dbg !565
  br label %907, !dbg !565

906:                                              ; preds = %897
  br label %907, !dbg !565

907:                                              ; preds = %903, %906
  %908 = phi i32 [ %905, %903 ], [ 8, %906 ], !dbg !565
  %909 = trunc i32 %908 to i8, !dbg !565
  store i8 %909, ptr %6, align 1
  call void @llvm.dbg.declare(metadata ptr %6, metadata !531, metadata !DIExpression()), !dbg !566
  %910 = load i8, ptr %6, align 1, !dbg !568
  %911 = zext i8 %910 to i32, !dbg !568
  %912 = icmp ne i32 %911, 0, !dbg !568
  br i1 %912, label %913, label %916, !dbg !568

913:                                              ; preds = %907
  %914 = load i8, ptr %6, align 1, !dbg !568
  %915 = zext i8 %914 to i32, !dbg !568
  br label %917, !dbg !568

916:                                              ; preds = %907
  br label %917, !dbg !568

917:                                              ; preds = %913, %916
  %918 = phi i32 [ %915, %913 ], [ 8, %916 ], !dbg !568
  %919 = trunc i32 %918 to i8, !dbg !568
  store i8 %919, ptr %187, align 1, !dbg !561
  call void @llvm.dbg.declare(metadata ptr %188, metadata !569, metadata !DIExpression()), !dbg !561
  %920 = load i64, ptr %136, align 8, !dbg !561
  %921 = load i8, ptr %187, align 1, !dbg !561
  store i8 %921, ptr %24, align 1
  call void @llvm.dbg.declare(metadata ptr %24, metadata !429, metadata !DIExpression()), !dbg !570
  %922 = load i8, ptr %24, align 1, !dbg !572
  %923 = zext i8 %922 to i32, !dbg !572
  %924 = icmp eq i32 %923, 1, !dbg !572
  br i1 %924, label %925, label %926, !dbg !572

925:                                              ; preds = %917
  br label %939, !dbg !572

926:                                              ; preds = %917
  %927 = load i8, ptr %24, align 1, !dbg !572
  %928 = zext i8 %927 to i32, !dbg !572
  %929 = icmp eq i32 %928, 2, !dbg !572
  br i1 %929, label %930, label %931, !dbg !572

930:                                              ; preds = %926
  br label %937, !dbg !572

931:                                              ; preds = %926
  %932 = load i8, ptr %24, align 1, !dbg !572
  %933 = zext i8 %932 to i32, !dbg !572
  %934 = icmp eq i32 %933, 4, !dbg !572
  %935 = zext i1 %934 to i64, !dbg !572
  %936 = select i1 %934, i64 4294967295, i64 -1, !dbg !572
  br label %937, !dbg !572

937:                                              ; preds = %931, %930
  %938 = phi i64 [ 65535, %930 ], [ %936, %931 ], !dbg !572
  br label %939, !dbg !572

939:                                              ; preds = %925, %937
  %940 = phi i64 [ 255, %925 ], [ %938, %937 ], !dbg !572
  %941 = and i64 %920, %940, !dbg !561
  store i64 %941, ptr %188, align 8, !dbg !561
  %942 = load i64, ptr %188, align 8, !dbg !561
  %943 = lshr i64 %942, 0, !dbg !561
  %944 = trunc i64 %943 to i8, !dbg !561
  %945 = load ptr, ptr %186, align 8, !dbg !561
  %946 = getelementptr inbounds i8, ptr %945, i64 0, !dbg !561
  store volatile i8 %944, ptr %946, align 1, !dbg !561
  %947 = load i8, ptr %187, align 1, !dbg !573
  %948 = zext i8 %947 to i32, !dbg !573
  %949 = icmp eq i32 %948, 1, !dbg !573
  br i1 %949, label %950, label %951, !dbg !573

950:                                              ; preds = %939
  br label %964, !dbg !573

951:                                              ; preds = %939
  %952 = load i8, ptr %187, align 1, !dbg !573
  %953 = zext i8 %952 to i32, !dbg !573
  %954 = icmp eq i32 %953, 2, !dbg !573
  br i1 %954, label %955, label %956, !dbg !573

955:                                              ; preds = %951
  br label %962, !dbg !573

956:                                              ; preds = %951
  %957 = load i8, ptr %187, align 1, !dbg !573
  %958 = zext i8 %957 to i32, !dbg !573
  %959 = icmp eq i32 %958, 4, !dbg !573
  %960 = zext i1 %959 to i64, !dbg !573
  %961 = select i1 %959, i32 15, i32 255, !dbg !573
  br label %962, !dbg !573

962:                                              ; preds = %956, %955
  %963 = phi i32 [ 3, %955 ], [ %961, %956 ], !dbg !573
  br label %964, !dbg !573

964:                                              ; preds = %962, %950
  %965 = phi i32 [ 1, %950 ], [ %963, %962 ], !dbg !573
  %966 = lshr i32 %965, 1, !dbg !573
  %967 = and i32 %966, 1, !dbg !573
  %968 = trunc i32 %967 to i8, !dbg !573
  %969 = icmp ne i8 %968, 0, !dbg !573
  br i1 %969, label %970, label %976, !dbg !561

970:                                              ; preds = %964
  %971 = load i64, ptr %188, align 8, !dbg !573
  %972 = lshr i64 %971, 8, !dbg !573
  %973 = trunc i64 %972 to i8, !dbg !573
  %974 = load ptr, ptr %186, align 8, !dbg !573
  %975 = getelementptr inbounds i8, ptr %974, i64 1, !dbg !573
  store volatile i8 %973, ptr %975, align 1, !dbg !573
  br label %976, !dbg !573

976:                                              ; preds = %970, %964
  %977 = load i8, ptr %187, align 1, !dbg !575
  %978 = zext i8 %977 to i32, !dbg !575
  %979 = icmp eq i32 %978, 1, !dbg !575
  br i1 %979, label %980, label %981, !dbg !575

980:                                              ; preds = %976
  br label %994, !dbg !575

981:                                              ; preds = %976
  %982 = load i8, ptr %187, align 1, !dbg !575
  %983 = zext i8 %982 to i32, !dbg !575
  %984 = icmp eq i32 %983, 2, !dbg !575
  br i1 %984, label %985, label %986, !dbg !575

985:                                              ; preds = %981
  br label %992, !dbg !575

986:                                              ; preds = %981
  %987 = load i8, ptr %187, align 1, !dbg !575
  %988 = zext i8 %987 to i32, !dbg !575
  %989 = icmp eq i32 %988, 4, !dbg !575
  %990 = zext i1 %989 to i64, !dbg !575
  %991 = select i1 %989, i32 15, i32 255, !dbg !575
  br label %992, !dbg !575

992:                                              ; preds = %986, %985
  %993 = phi i32 [ 3, %985 ], [ %991, %986 ], !dbg !575
  br label %994, !dbg !575

994:                                              ; preds = %992, %980
  %995 = phi i32 [ 1, %980 ], [ %993, %992 ], !dbg !575
  %996 = lshr i32 %995, 2, !dbg !575
  %997 = and i32 %996, 1, !dbg !575
  %998 = trunc i32 %997 to i8, !dbg !575
  %999 = icmp ne i8 %998, 0, !dbg !575
  br i1 %999, label %1000, label %1006, !dbg !561

1000:                                             ; preds = %994
  %1001 = load i64, ptr %188, align 8, !dbg !575
  %1002 = lshr i64 %1001, 16, !dbg !575
  %1003 = trunc i64 %1002 to i8, !dbg !575
  %1004 = load ptr, ptr %186, align 8, !dbg !575
  %1005 = getelementptr inbounds i8, ptr %1004, i64 2, !dbg !575
  store volatile i8 %1003, ptr %1005, align 1, !dbg !575
  br label %1006, !dbg !575

1006:                                             ; preds = %1000, %994
  %1007 = load i8, ptr %187, align 1, !dbg !577
  %1008 = zext i8 %1007 to i32, !dbg !577
  %1009 = icmp eq i32 %1008, 1, !dbg !577
  br i1 %1009, label %1010, label %1011, !dbg !577

1010:                                             ; preds = %1006
  br label %1024, !dbg !577

1011:                                             ; preds = %1006
  %1012 = load i8, ptr %187, align 1, !dbg !577
  %1013 = zext i8 %1012 to i32, !dbg !577
  %1014 = icmp eq i32 %1013, 2, !dbg !577
  br i1 %1014, label %1015, label %1016, !dbg !577

1015:                                             ; preds = %1011
  br label %1022, !dbg !577

1016:                                             ; preds = %1011
  %1017 = load i8, ptr %187, align 1, !dbg !577
  %1018 = zext i8 %1017 to i32, !dbg !577
  %1019 = icmp eq i32 %1018, 4, !dbg !577
  %1020 = zext i1 %1019 to i64, !dbg !577
  %1021 = select i1 %1019, i32 15, i32 255, !dbg !577
  br label %1022, !dbg !577

1022:                                             ; preds = %1016, %1015
  %1023 = phi i32 [ 3, %1015 ], [ %1021, %1016 ], !dbg !577
  br label %1024, !dbg !577

1024:                                             ; preds = %1022, %1010
  %1025 = phi i32 [ 1, %1010 ], [ %1023, %1022 ], !dbg !577
  %1026 = lshr i32 %1025, 3, !dbg !577
  %1027 = and i32 %1026, 1, !dbg !577
  %1028 = trunc i32 %1027 to i8, !dbg !577
  %1029 = icmp ne i8 %1028, 0, !dbg !577
  br i1 %1029, label %1030, label %1036, !dbg !561

1030:                                             ; preds = %1024
  %1031 = load i64, ptr %188, align 8, !dbg !577
  %1032 = lshr i64 %1031, 24, !dbg !577
  %1033 = trunc i64 %1032 to i8, !dbg !577
  %1034 = load ptr, ptr %186, align 8, !dbg !577
  %1035 = getelementptr inbounds i8, ptr %1034, i64 3, !dbg !577
  store volatile i8 %1033, ptr %1035, align 1, !dbg !577
  br label %1036, !dbg !577

1036:                                             ; preds = %1030, %1024
  %1037 = load i8, ptr %187, align 1, !dbg !579
  %1038 = zext i8 %1037 to i32, !dbg !579
  %1039 = icmp eq i32 %1038, 1, !dbg !579
  br i1 %1039, label %1040, label %1041, !dbg !579

1040:                                             ; preds = %1036
  br label %1054, !dbg !579

1041:                                             ; preds = %1036
  %1042 = load i8, ptr %187, align 1, !dbg !579
  %1043 = zext i8 %1042 to i32, !dbg !579
  %1044 = icmp eq i32 %1043, 2, !dbg !579
  br i1 %1044, label %1045, label %1046, !dbg !579

1045:                                             ; preds = %1041
  br label %1052, !dbg !579

1046:                                             ; preds = %1041
  %1047 = load i8, ptr %187, align 1, !dbg !579
  %1048 = zext i8 %1047 to i32, !dbg !579
  %1049 = icmp eq i32 %1048, 4, !dbg !579
  %1050 = zext i1 %1049 to i64, !dbg !579
  %1051 = select i1 %1049, i32 15, i32 255, !dbg !579
  br label %1052, !dbg !579

1052:                                             ; preds = %1046, %1045
  %1053 = phi i32 [ 3, %1045 ], [ %1051, %1046 ], !dbg !579
  br label %1054, !dbg !579

1054:                                             ; preds = %1052, %1040
  %1055 = phi i32 [ 1, %1040 ], [ %1053, %1052 ], !dbg !579
  %1056 = lshr i32 %1055, 4, !dbg !579
  %1057 = and i32 %1056, 1, !dbg !579
  %1058 = trunc i32 %1057 to i8, !dbg !579
  %1059 = icmp ne i8 %1058, 0, !dbg !579
  br i1 %1059, label %1060, label %1066, !dbg !561

1060:                                             ; preds = %1054
  %1061 = load i64, ptr %188, align 8, !dbg !579
  %1062 = lshr i64 %1061, 32, !dbg !579
  %1063 = trunc i64 %1062 to i8, !dbg !579
  %1064 = load ptr, ptr %186, align 8, !dbg !579
  %1065 = getelementptr inbounds i8, ptr %1064, i64 4, !dbg !579
  store volatile i8 %1063, ptr %1065, align 1, !dbg !579
  br label %1066, !dbg !579

1066:                                             ; preds = %1060, %1054
  %1067 = load i8, ptr %187, align 1, !dbg !581
  %1068 = zext i8 %1067 to i32, !dbg !581
  %1069 = icmp eq i32 %1068, 1, !dbg !581
  br i1 %1069, label %1070, label %1071, !dbg !581

1070:                                             ; preds = %1066
  br label %1084, !dbg !581

1071:                                             ; preds = %1066
  %1072 = load i8, ptr %187, align 1, !dbg !581
  %1073 = zext i8 %1072 to i32, !dbg !581
  %1074 = icmp eq i32 %1073, 2, !dbg !581
  br i1 %1074, label %1075, label %1076, !dbg !581

1075:                                             ; preds = %1071
  br label %1082, !dbg !581

1076:                                             ; preds = %1071
  %1077 = load i8, ptr %187, align 1, !dbg !581
  %1078 = zext i8 %1077 to i32, !dbg !581
  %1079 = icmp eq i32 %1078, 4, !dbg !581
  %1080 = zext i1 %1079 to i64, !dbg !581
  %1081 = select i1 %1079, i32 15, i32 255, !dbg !581
  br label %1082, !dbg !581

1082:                                             ; preds = %1076, %1075
  %1083 = phi i32 [ 3, %1075 ], [ %1081, %1076 ], !dbg !581
  br label %1084, !dbg !581

1084:                                             ; preds = %1082, %1070
  %1085 = phi i32 [ 1, %1070 ], [ %1083, %1082 ], !dbg !581
  %1086 = lshr i32 %1085, 5, !dbg !581
  %1087 = and i32 %1086, 1, !dbg !581
  %1088 = trunc i32 %1087 to i8, !dbg !581
  %1089 = icmp ne i8 %1088, 0, !dbg !581
  br i1 %1089, label %1090, label %1096, !dbg !561

1090:                                             ; preds = %1084
  %1091 = load i64, ptr %188, align 8, !dbg !581
  %1092 = lshr i64 %1091, 40, !dbg !581
  %1093 = trunc i64 %1092 to i8, !dbg !581
  %1094 = load ptr, ptr %186, align 8, !dbg !581
  %1095 = getelementptr inbounds i8, ptr %1094, i64 5, !dbg !581
  store volatile i8 %1093, ptr %1095, align 1, !dbg !581
  br label %1096, !dbg !581

1096:                                             ; preds = %1090, %1084
  %1097 = load i8, ptr %187, align 1, !dbg !583
  %1098 = zext i8 %1097 to i32, !dbg !583
  %1099 = icmp eq i32 %1098, 1, !dbg !583
  br i1 %1099, label %1100, label %1101, !dbg !583

1100:                                             ; preds = %1096
  br label %1114, !dbg !583

1101:                                             ; preds = %1096
  %1102 = load i8, ptr %187, align 1, !dbg !583
  %1103 = zext i8 %1102 to i32, !dbg !583
  %1104 = icmp eq i32 %1103, 2, !dbg !583
  br i1 %1104, label %1105, label %1106, !dbg !583

1105:                                             ; preds = %1101
  br label %1112, !dbg !583

1106:                                             ; preds = %1101
  %1107 = load i8, ptr %187, align 1, !dbg !583
  %1108 = zext i8 %1107 to i32, !dbg !583
  %1109 = icmp eq i32 %1108, 4, !dbg !583
  %1110 = zext i1 %1109 to i64, !dbg !583
  %1111 = select i1 %1109, i32 15, i32 255, !dbg !583
  br label %1112, !dbg !583

1112:                                             ; preds = %1106, %1105
  %1113 = phi i32 [ 3, %1105 ], [ %1111, %1106 ], !dbg !583
  br label %1114, !dbg !583

1114:                                             ; preds = %1112, %1100
  %1115 = phi i32 [ 1, %1100 ], [ %1113, %1112 ], !dbg !583
  %1116 = lshr i32 %1115, 6, !dbg !583
  %1117 = and i32 %1116, 1, !dbg !583
  %1118 = trunc i32 %1117 to i8, !dbg !583
  %1119 = icmp ne i8 %1118, 0, !dbg !583
  br i1 %1119, label %1120, label %1126, !dbg !561

1120:                                             ; preds = %1114
  %1121 = load i64, ptr %188, align 8, !dbg !583
  %1122 = lshr i64 %1121, 48, !dbg !583
  %1123 = trunc i64 %1122 to i8, !dbg !583
  %1124 = load ptr, ptr %186, align 8, !dbg !583
  %1125 = getelementptr inbounds i8, ptr %1124, i64 6, !dbg !583
  store volatile i8 %1123, ptr %1125, align 1, !dbg !583
  br label %1126, !dbg !583

1126:                                             ; preds = %1120, %1114
  %1127 = load i8, ptr %187, align 1, !dbg !585
  %1128 = zext i8 %1127 to i32, !dbg !585
  %1129 = icmp eq i32 %1128, 1, !dbg !585
  br i1 %1129, label %1130, label %1131, !dbg !585

1130:                                             ; preds = %1126
  br label %1144, !dbg !585

1131:                                             ; preds = %1126
  %1132 = load i8, ptr %187, align 1, !dbg !585
  %1133 = zext i8 %1132 to i32, !dbg !585
  %1134 = icmp eq i32 %1133, 2, !dbg !585
  br i1 %1134, label %1135, label %1136, !dbg !585

1135:                                             ; preds = %1131
  br label %1142, !dbg !585

1136:                                             ; preds = %1131
  %1137 = load i8, ptr %187, align 1, !dbg !585
  %1138 = zext i8 %1137 to i32, !dbg !585
  %1139 = icmp eq i32 %1138, 4, !dbg !585
  %1140 = zext i1 %1139 to i64, !dbg !585
  %1141 = select i1 %1139, i32 15, i32 255, !dbg !585
  br label %1142, !dbg !585

1142:                                             ; preds = %1136, %1135
  %1143 = phi i32 [ 3, %1135 ], [ %1141, %1136 ], !dbg !585
  br label %1144, !dbg !585

1144:                                             ; preds = %1142, %1130
  %1145 = phi i32 [ 1, %1130 ], [ %1143, %1142 ], !dbg !585
  %1146 = lshr i32 %1145, 7, !dbg !585
  %1147 = and i32 %1146, 1, !dbg !585
  %1148 = trunc i32 %1147 to i8, !dbg !585
  %1149 = icmp ne i8 %1148, 0, !dbg !585
  br i1 %1149, label %1150, label %1156, !dbg !561

1150:                                             ; preds = %1144
  %1151 = load i64, ptr %188, align 8, !dbg !585
  %1152 = lshr i64 %1151, 56, !dbg !585
  %1153 = trunc i64 %1152 to i8, !dbg !585
  %1154 = load ptr, ptr %186, align 8, !dbg !585
  %1155 = getelementptr inbounds i8, ptr %1154, i64 7, !dbg !585
  store volatile i8 %1153, ptr %1155, align 1, !dbg !585
  br label %1156, !dbg !585

1156:                                             ; preds = %1150, %1144
  br label %1157, !dbg !561

1157:                                             ; preds = %1156
  br label %1158

1158:                                             ; preds = %1157, %891
  br label %1159, !dbg !545

1159:                                             ; preds = %1158
  br label %1604, !dbg !525

1160:                                             ; preds = %812
  call void @llvm.dbg.declare(metadata ptr %189, metadata !587, metadata !DIExpression()), !dbg !525
  %1161 = load ptr, ptr %135, align 8, !dbg !525
  %1162 = ptrtoint ptr %1161 to i64, !dbg !525
  %1163 = load i64, ptr %132, align 8, !dbg !525
  %1164 = add i64 %1162, %1163, !dbg !525
  %1165 = inttoptr i64 %1164 to ptr, !dbg !525
  store ptr %1165, ptr %189, align 8, !dbg !525
  call void @llvm.dbg.declare(metadata ptr %190, metadata !588, metadata !DIExpression()), !dbg !591
  store i8 0, ptr %190, align 1, !dbg !591
  %1166 = load i8, ptr %55, align 1, !dbg !591
  store i8 %1166, ptr %190, align 1, !dbg !591
  %1167 = load i8, ptr %190, align 1, !dbg !591
  store i8 %1167, ptr %191, align 1, !dbg !591
  %1168 = load i8, ptr %191, align 1, !dbg !591
  %1169 = zext i8 %1168 to i32, !dbg !592
  %1170 = icmp eq i32 %1169, 4, !dbg !592
  br i1 %1170, label %1171, label %1205, !dbg !525

1171:                                             ; preds = %1160
  br label %1172, !dbg !592

1172:                                             ; preds = %1171
  call void @llvm.dbg.declare(metadata ptr %192, metadata !593, metadata !DIExpression()), !dbg !595
  %1173 = load ptr, ptr %189, align 8, !dbg !595
  %1174 = ptrtoint ptr %1173 to i64, !dbg !595
  %1175 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !595
  %1176 = ptrtoint ptr %1175 to i64, !dbg !595
  %1177 = sub i64 %1174, %1176, !dbg !595
  store i64 %1177, ptr %192, align 8, !dbg !595
  call void @llvm.dbg.declare(metadata ptr %193, metadata !596, metadata !DIExpression()), !dbg !595
  %1178 = load i8, ptr %129, align 1, !dbg !595
  store i8 %1178, ptr %7, align 1
  call void @llvm.dbg.declare(metadata ptr %7, metadata !531, metadata !DIExpression()), !dbg !597
  %1179 = load i8, ptr %7, align 1, !dbg !599
  %1180 = zext i8 %1179 to i32, !dbg !599
  %1181 = icmp ne i32 %1180, 0, !dbg !599
  br i1 %1181, label %1182, label %1185, !dbg !599

1182:                                             ; preds = %1172
  %1183 = load i8, ptr %7, align 1, !dbg !599
  %1184 = zext i8 %1183 to i32, !dbg !599
  br label %1186, !dbg !599

1185:                                             ; preds = %1172
  br label %1186, !dbg !599

1186:                                             ; preds = %1182, %1185
  %1187 = phi i32 [ %1184, %1182 ], [ 8, %1185 ], !dbg !599
  %1188 = trunc i32 %1187 to i8, !dbg !599
  %1189 = zext i8 %1188 to i64, !dbg !595
  store i64 %1189, ptr %193, align 8, !dbg !595
  br label %1190, !dbg !595

1190:                                             ; preds = %1186
  call void @llvm.dbg.declare(metadata ptr %194, metadata !600, metadata !DIExpression()), !dbg !602
  store i64 0, ptr %194, align 8, !dbg !602
  %1191 = load i64, ptr %192, align 8, !dbg !603
  %1192 = load i64, ptr %194, align 8, !dbg !603
  %1193 = sub i64 %1191, %1192, !dbg !603
  %1194 = icmp ult i64 %1193, 8, !dbg !603
  br i1 %1194, label %1201, label %1195, !dbg !603

1195:                                             ; preds = %1190
  %1196 = load i64, ptr %194, align 8, !dbg !603
  %1197 = load i64, ptr %192, align 8, !dbg !603
  %1198 = sub i64 %1196, %1197, !dbg !603
  %1199 = load i64, ptr %193, align 8, !dbg !603
  %1200 = icmp ult i64 %1198, %1199, !dbg !603
  br i1 %1200, label %1201, label %1202, !dbg !602

1201:                                             ; preds = %1195, %1190
  store i8 0, ptr %33, align 1, !dbg !603
  br label %1202, !dbg !603

1202:                                             ; preds = %1201, %1195
  br label %1203, !dbg !602

1203:                                             ; preds = %1202
  br label %1204, !dbg !595

1204:                                             ; preds = %1203
  br label %1205, !dbg !595

1205:                                             ; preds = %1204, %1160
  call void @llvm.dbg.declare(metadata ptr %195, metadata !605, metadata !DIExpression()), !dbg !608
  store i8 0, ptr %195, align 1, !dbg !608
  %1206 = load i8, ptr %55, align 1, !dbg !608
  store i8 %1206, ptr %195, align 1, !dbg !608
  %1207 = load i8, ptr %195, align 1, !dbg !608
  store i8 %1207, ptr %196, align 1, !dbg !608
  %1208 = load i8, ptr %196, align 1, !dbg !608
  %1209 = zext i8 %1208 to i32, !dbg !609
  %1210 = icmp eq i32 %1209, 4, !dbg !609
  br i1 %1210, label %1211, label %1463, !dbg !525

1211:                                             ; preds = %1205
  br label %1212, !dbg !609

1212:                                             ; preds = %1211
  call void @llvm.dbg.declare(metadata ptr %197, metadata !610, metadata !DIExpression()), !dbg !612
  %1213 = load ptr, ptr %189, align 8, !dbg !612
  store ptr %1213, ptr %197, align 8, !dbg !612
  call void @llvm.dbg.declare(metadata ptr %198, metadata !613, metadata !DIExpression()), !dbg !612
  %1214 = load i8, ptr %129, align 1, !dbg !612
  store i8 %1214, ptr %8, align 1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !531, metadata !DIExpression()), !dbg !614
  %1215 = load i8, ptr %8, align 1, !dbg !616
  %1216 = zext i8 %1215 to i32, !dbg !616
  %1217 = icmp ne i32 %1216, 0, !dbg !616
  br i1 %1217, label %1218, label %1221, !dbg !616

1218:                                             ; preds = %1212
  %1219 = load i8, ptr %8, align 1, !dbg !616
  %1220 = zext i8 %1219 to i32, !dbg !616
  br label %1222, !dbg !616

1221:                                             ; preds = %1212
  br label %1222, !dbg !616

1222:                                             ; preds = %1218, %1221
  %1223 = phi i32 [ %1220, %1218 ], [ 8, %1221 ], !dbg !616
  %1224 = trunc i32 %1223 to i8, !dbg !616
  store i8 %1224, ptr %198, align 1, !dbg !612
  call void @llvm.dbg.declare(metadata ptr %199, metadata !617, metadata !DIExpression()), !dbg !612
  %1225 = load i64, ptr %136, align 8, !dbg !612
  %1226 = load i8, ptr %198, align 1, !dbg !612
  store i8 %1226, ptr %25, align 1
  call void @llvm.dbg.declare(metadata ptr %25, metadata !429, metadata !DIExpression()), !dbg !618
  %1227 = load i8, ptr %25, align 1, !dbg !620
  %1228 = zext i8 %1227 to i32, !dbg !620
  %1229 = icmp eq i32 %1228, 1, !dbg !620
  br i1 %1229, label %1230, label %1231, !dbg !620

1230:                                             ; preds = %1222
  br label %1244, !dbg !620

1231:                                             ; preds = %1222
  %1232 = load i8, ptr %25, align 1, !dbg !620
  %1233 = zext i8 %1232 to i32, !dbg !620
  %1234 = icmp eq i32 %1233, 2, !dbg !620
  br i1 %1234, label %1235, label %1236, !dbg !620

1235:                                             ; preds = %1231
  br label %1242, !dbg !620

1236:                                             ; preds = %1231
  %1237 = load i8, ptr %25, align 1, !dbg !620
  %1238 = zext i8 %1237 to i32, !dbg !620
  %1239 = icmp eq i32 %1238, 4, !dbg !620
  %1240 = zext i1 %1239 to i64, !dbg !620
  %1241 = select i1 %1239, i64 4294967295, i64 -1, !dbg !620
  br label %1242, !dbg !620

1242:                                             ; preds = %1236, %1235
  %1243 = phi i64 [ 65535, %1235 ], [ %1241, %1236 ], !dbg !620
  br label %1244, !dbg !620

1244:                                             ; preds = %1230, %1242
  %1245 = phi i64 [ 255, %1230 ], [ %1243, %1242 ], !dbg !620
  %1246 = and i64 %1225, %1245, !dbg !612
  store i64 %1246, ptr %199, align 8, !dbg !612
  %1247 = load i64, ptr %199, align 8, !dbg !612
  %1248 = lshr i64 %1247, 0, !dbg !612
  %1249 = trunc i64 %1248 to i8, !dbg !612
  %1250 = load ptr, ptr %197, align 8, !dbg !612
  %1251 = getelementptr inbounds i8, ptr %1250, i64 0, !dbg !612
  store volatile i8 %1249, ptr %1251, align 1, !dbg !612
  %1252 = load i8, ptr %198, align 1, !dbg !621
  %1253 = zext i8 %1252 to i32, !dbg !621
  %1254 = icmp eq i32 %1253, 1, !dbg !621
  br i1 %1254, label %1255, label %1256, !dbg !621

1255:                                             ; preds = %1244
  br label %1269, !dbg !621

1256:                                             ; preds = %1244
  %1257 = load i8, ptr %198, align 1, !dbg !621
  %1258 = zext i8 %1257 to i32, !dbg !621
  %1259 = icmp eq i32 %1258, 2, !dbg !621
  br i1 %1259, label %1260, label %1261, !dbg !621

1260:                                             ; preds = %1256
  br label %1267, !dbg !621

1261:                                             ; preds = %1256
  %1262 = load i8, ptr %198, align 1, !dbg !621
  %1263 = zext i8 %1262 to i32, !dbg !621
  %1264 = icmp eq i32 %1263, 4, !dbg !621
  %1265 = zext i1 %1264 to i64, !dbg !621
  %1266 = select i1 %1264, i32 15, i32 255, !dbg !621
  br label %1267, !dbg !621

1267:                                             ; preds = %1261, %1260
  %1268 = phi i32 [ 3, %1260 ], [ %1266, %1261 ], !dbg !621
  br label %1269, !dbg !621

1269:                                             ; preds = %1267, %1255
  %1270 = phi i32 [ 1, %1255 ], [ %1268, %1267 ], !dbg !621
  %1271 = lshr i32 %1270, 1, !dbg !621
  %1272 = and i32 %1271, 1, !dbg !621
  %1273 = trunc i32 %1272 to i8, !dbg !621
  %1274 = icmp ne i8 %1273, 0, !dbg !621
  br i1 %1274, label %1275, label %1281, !dbg !612

1275:                                             ; preds = %1269
  %1276 = load i64, ptr %199, align 8, !dbg !621
  %1277 = lshr i64 %1276, 8, !dbg !621
  %1278 = trunc i64 %1277 to i8, !dbg !621
  %1279 = load ptr, ptr %197, align 8, !dbg !621
  %1280 = getelementptr inbounds i8, ptr %1279, i64 1, !dbg !621
  store volatile i8 %1278, ptr %1280, align 1, !dbg !621
  br label %1281, !dbg !621

1281:                                             ; preds = %1275, %1269
  %1282 = load i8, ptr %198, align 1, !dbg !623
  %1283 = zext i8 %1282 to i32, !dbg !623
  %1284 = icmp eq i32 %1283, 1, !dbg !623
  br i1 %1284, label %1285, label %1286, !dbg !623

1285:                                             ; preds = %1281
  br label %1299, !dbg !623

1286:                                             ; preds = %1281
  %1287 = load i8, ptr %198, align 1, !dbg !623
  %1288 = zext i8 %1287 to i32, !dbg !623
  %1289 = icmp eq i32 %1288, 2, !dbg !623
  br i1 %1289, label %1290, label %1291, !dbg !623

1290:                                             ; preds = %1286
  br label %1297, !dbg !623

1291:                                             ; preds = %1286
  %1292 = load i8, ptr %198, align 1, !dbg !623
  %1293 = zext i8 %1292 to i32, !dbg !623
  %1294 = icmp eq i32 %1293, 4, !dbg !623
  %1295 = zext i1 %1294 to i64, !dbg !623
  %1296 = select i1 %1294, i32 15, i32 255, !dbg !623
  br label %1297, !dbg !623

1297:                                             ; preds = %1291, %1290
  %1298 = phi i32 [ 3, %1290 ], [ %1296, %1291 ], !dbg !623
  br label %1299, !dbg !623

1299:                                             ; preds = %1297, %1285
  %1300 = phi i32 [ 1, %1285 ], [ %1298, %1297 ], !dbg !623
  %1301 = lshr i32 %1300, 2, !dbg !623
  %1302 = and i32 %1301, 1, !dbg !623
  %1303 = trunc i32 %1302 to i8, !dbg !623
  %1304 = icmp ne i8 %1303, 0, !dbg !623
  br i1 %1304, label %1305, label %1311, !dbg !612

1305:                                             ; preds = %1299
  %1306 = load i64, ptr %199, align 8, !dbg !623
  %1307 = lshr i64 %1306, 16, !dbg !623
  %1308 = trunc i64 %1307 to i8, !dbg !623
  %1309 = load ptr, ptr %197, align 8, !dbg !623
  %1310 = getelementptr inbounds i8, ptr %1309, i64 2, !dbg !623
  store volatile i8 %1308, ptr %1310, align 1, !dbg !623
  br label %1311, !dbg !623

1311:                                             ; preds = %1305, %1299
  %1312 = load i8, ptr %198, align 1, !dbg !625
  %1313 = zext i8 %1312 to i32, !dbg !625
  %1314 = icmp eq i32 %1313, 1, !dbg !625
  br i1 %1314, label %1315, label %1316, !dbg !625

1315:                                             ; preds = %1311
  br label %1329, !dbg !625

1316:                                             ; preds = %1311
  %1317 = load i8, ptr %198, align 1, !dbg !625
  %1318 = zext i8 %1317 to i32, !dbg !625
  %1319 = icmp eq i32 %1318, 2, !dbg !625
  br i1 %1319, label %1320, label %1321, !dbg !625

1320:                                             ; preds = %1316
  br label %1327, !dbg !625

1321:                                             ; preds = %1316
  %1322 = load i8, ptr %198, align 1, !dbg !625
  %1323 = zext i8 %1322 to i32, !dbg !625
  %1324 = icmp eq i32 %1323, 4, !dbg !625
  %1325 = zext i1 %1324 to i64, !dbg !625
  %1326 = select i1 %1324, i32 15, i32 255, !dbg !625
  br label %1327, !dbg !625

1327:                                             ; preds = %1321, %1320
  %1328 = phi i32 [ 3, %1320 ], [ %1326, %1321 ], !dbg !625
  br label %1329, !dbg !625

1329:                                             ; preds = %1327, %1315
  %1330 = phi i32 [ 1, %1315 ], [ %1328, %1327 ], !dbg !625
  %1331 = lshr i32 %1330, 3, !dbg !625
  %1332 = and i32 %1331, 1, !dbg !625
  %1333 = trunc i32 %1332 to i8, !dbg !625
  %1334 = icmp ne i8 %1333, 0, !dbg !625
  br i1 %1334, label %1335, label %1341, !dbg !612

1335:                                             ; preds = %1329
  %1336 = load i64, ptr %199, align 8, !dbg !625
  %1337 = lshr i64 %1336, 24, !dbg !625
  %1338 = trunc i64 %1337 to i8, !dbg !625
  %1339 = load ptr, ptr %197, align 8, !dbg !625
  %1340 = getelementptr inbounds i8, ptr %1339, i64 3, !dbg !625
  store volatile i8 %1338, ptr %1340, align 1, !dbg !625
  br label %1341, !dbg !625

1341:                                             ; preds = %1335, %1329
  %1342 = load i8, ptr %198, align 1, !dbg !627
  %1343 = zext i8 %1342 to i32, !dbg !627
  %1344 = icmp eq i32 %1343, 1, !dbg !627
  br i1 %1344, label %1345, label %1346, !dbg !627

1345:                                             ; preds = %1341
  br label %1359, !dbg !627

1346:                                             ; preds = %1341
  %1347 = load i8, ptr %198, align 1, !dbg !627
  %1348 = zext i8 %1347 to i32, !dbg !627
  %1349 = icmp eq i32 %1348, 2, !dbg !627
  br i1 %1349, label %1350, label %1351, !dbg !627

1350:                                             ; preds = %1346
  br label %1357, !dbg !627

1351:                                             ; preds = %1346
  %1352 = load i8, ptr %198, align 1, !dbg !627
  %1353 = zext i8 %1352 to i32, !dbg !627
  %1354 = icmp eq i32 %1353, 4, !dbg !627
  %1355 = zext i1 %1354 to i64, !dbg !627
  %1356 = select i1 %1354, i32 15, i32 255, !dbg !627
  br label %1357, !dbg !627

1357:                                             ; preds = %1351, %1350
  %1358 = phi i32 [ 3, %1350 ], [ %1356, %1351 ], !dbg !627
  br label %1359, !dbg !627

1359:                                             ; preds = %1357, %1345
  %1360 = phi i32 [ 1, %1345 ], [ %1358, %1357 ], !dbg !627
  %1361 = lshr i32 %1360, 4, !dbg !627
  %1362 = and i32 %1361, 1, !dbg !627
  %1363 = trunc i32 %1362 to i8, !dbg !627
  %1364 = icmp ne i8 %1363, 0, !dbg !627
  br i1 %1364, label %1365, label %1371, !dbg !612

1365:                                             ; preds = %1359
  %1366 = load i64, ptr %199, align 8, !dbg !627
  %1367 = lshr i64 %1366, 32, !dbg !627
  %1368 = trunc i64 %1367 to i8, !dbg !627
  %1369 = load ptr, ptr %197, align 8, !dbg !627
  %1370 = getelementptr inbounds i8, ptr %1369, i64 4, !dbg !627
  store volatile i8 %1368, ptr %1370, align 1, !dbg !627
  br label %1371, !dbg !627

1371:                                             ; preds = %1365, %1359
  %1372 = load i8, ptr %198, align 1, !dbg !629
  %1373 = zext i8 %1372 to i32, !dbg !629
  %1374 = icmp eq i32 %1373, 1, !dbg !629
  br i1 %1374, label %1375, label %1376, !dbg !629

1375:                                             ; preds = %1371
  br label %1389, !dbg !629

1376:                                             ; preds = %1371
  %1377 = load i8, ptr %198, align 1, !dbg !629
  %1378 = zext i8 %1377 to i32, !dbg !629
  %1379 = icmp eq i32 %1378, 2, !dbg !629
  br i1 %1379, label %1380, label %1381, !dbg !629

1380:                                             ; preds = %1376
  br label %1387, !dbg !629

1381:                                             ; preds = %1376
  %1382 = load i8, ptr %198, align 1, !dbg !629
  %1383 = zext i8 %1382 to i32, !dbg !629
  %1384 = icmp eq i32 %1383, 4, !dbg !629
  %1385 = zext i1 %1384 to i64, !dbg !629
  %1386 = select i1 %1384, i32 15, i32 255, !dbg !629
  br label %1387, !dbg !629

1387:                                             ; preds = %1381, %1380
  %1388 = phi i32 [ 3, %1380 ], [ %1386, %1381 ], !dbg !629
  br label %1389, !dbg !629

1389:                                             ; preds = %1387, %1375
  %1390 = phi i32 [ 1, %1375 ], [ %1388, %1387 ], !dbg !629
  %1391 = lshr i32 %1390, 5, !dbg !629
  %1392 = and i32 %1391, 1, !dbg !629
  %1393 = trunc i32 %1392 to i8, !dbg !629
  %1394 = icmp ne i8 %1393, 0, !dbg !629
  br i1 %1394, label %1395, label %1401, !dbg !612

1395:                                             ; preds = %1389
  %1396 = load i64, ptr %199, align 8, !dbg !629
  %1397 = lshr i64 %1396, 40, !dbg !629
  %1398 = trunc i64 %1397 to i8, !dbg !629
  %1399 = load ptr, ptr %197, align 8, !dbg !629
  %1400 = getelementptr inbounds i8, ptr %1399, i64 5, !dbg !629
  store volatile i8 %1398, ptr %1400, align 1, !dbg !629
  br label %1401, !dbg !629

1401:                                             ; preds = %1395, %1389
  %1402 = load i8, ptr %198, align 1, !dbg !631
  %1403 = zext i8 %1402 to i32, !dbg !631
  %1404 = icmp eq i32 %1403, 1, !dbg !631
  br i1 %1404, label %1405, label %1406, !dbg !631

1405:                                             ; preds = %1401
  br label %1419, !dbg !631

1406:                                             ; preds = %1401
  %1407 = load i8, ptr %198, align 1, !dbg !631
  %1408 = zext i8 %1407 to i32, !dbg !631
  %1409 = icmp eq i32 %1408, 2, !dbg !631
  br i1 %1409, label %1410, label %1411, !dbg !631

1410:                                             ; preds = %1406
  br label %1417, !dbg !631

1411:                                             ; preds = %1406
  %1412 = load i8, ptr %198, align 1, !dbg !631
  %1413 = zext i8 %1412 to i32, !dbg !631
  %1414 = icmp eq i32 %1413, 4, !dbg !631
  %1415 = zext i1 %1414 to i64, !dbg !631
  %1416 = select i1 %1414, i32 15, i32 255, !dbg !631
  br label %1417, !dbg !631

1417:                                             ; preds = %1411, %1410
  %1418 = phi i32 [ 3, %1410 ], [ %1416, %1411 ], !dbg !631
  br label %1419, !dbg !631

1419:                                             ; preds = %1417, %1405
  %1420 = phi i32 [ 1, %1405 ], [ %1418, %1417 ], !dbg !631
  %1421 = lshr i32 %1420, 6, !dbg !631
  %1422 = and i32 %1421, 1, !dbg !631
  %1423 = trunc i32 %1422 to i8, !dbg !631
  %1424 = icmp ne i8 %1423, 0, !dbg !631
  br i1 %1424, label %1425, label %1431, !dbg !612

1425:                                             ; preds = %1419
  %1426 = load i64, ptr %199, align 8, !dbg !631
  %1427 = lshr i64 %1426, 48, !dbg !631
  %1428 = trunc i64 %1427 to i8, !dbg !631
  %1429 = load ptr, ptr %197, align 8, !dbg !631
  %1430 = getelementptr inbounds i8, ptr %1429, i64 6, !dbg !631
  store volatile i8 %1428, ptr %1430, align 1, !dbg !631
  br label %1431, !dbg !631

1431:                                             ; preds = %1425, %1419
  %1432 = load i8, ptr %198, align 1, !dbg !633
  %1433 = zext i8 %1432 to i32, !dbg !633
  %1434 = icmp eq i32 %1433, 1, !dbg !633
  br i1 %1434, label %1435, label %1436, !dbg !633

1435:                                             ; preds = %1431
  br label %1449, !dbg !633

1436:                                             ; preds = %1431
  %1437 = load i8, ptr %198, align 1, !dbg !633
  %1438 = zext i8 %1437 to i32, !dbg !633
  %1439 = icmp eq i32 %1438, 2, !dbg !633
  br i1 %1439, label %1440, label %1441, !dbg !633

1440:                                             ; preds = %1436
  br label %1447, !dbg !633

1441:                                             ; preds = %1436
  %1442 = load i8, ptr %198, align 1, !dbg !633
  %1443 = zext i8 %1442 to i32, !dbg !633
  %1444 = icmp eq i32 %1443, 4, !dbg !633
  %1445 = zext i1 %1444 to i64, !dbg !633
  %1446 = select i1 %1444, i32 15, i32 255, !dbg !633
  br label %1447, !dbg !633

1447:                                             ; preds = %1441, %1440
  %1448 = phi i32 [ 3, %1440 ], [ %1446, %1441 ], !dbg !633
  br label %1449, !dbg !633

1449:                                             ; preds = %1447, %1435
  %1450 = phi i32 [ 1, %1435 ], [ %1448, %1447 ], !dbg !633
  %1451 = lshr i32 %1450, 7, !dbg !633
  %1452 = and i32 %1451, 1, !dbg !633
  %1453 = trunc i32 %1452 to i8, !dbg !633
  %1454 = icmp ne i8 %1453, 0, !dbg !633
  br i1 %1454, label %1455, label %1461, !dbg !612

1455:                                             ; preds = %1449
  %1456 = load i64, ptr %199, align 8, !dbg !633
  %1457 = lshr i64 %1456, 56, !dbg !633
  %1458 = trunc i64 %1457 to i8, !dbg !633
  %1459 = load ptr, ptr %197, align 8, !dbg !633
  %1460 = getelementptr inbounds i8, ptr %1459, i64 7, !dbg !633
  store volatile i8 %1458, ptr %1460, align 1, !dbg !633
  br label %1461, !dbg !633

1461:                                             ; preds = %1455, %1449
  br label %1462, !dbg !612

1462:                                             ; preds = %1461
  br label %1544, !dbg !612

1463:                                             ; preds = %1205
  br label %1464, !dbg !609

1464:                                             ; preds = %1463
  call void @llvm.dbg.declare(metadata ptr %200, metadata !635, metadata !DIExpression()), !dbg !637
  %1465 = load ptr, ptr %189, align 8, !dbg !637
  store ptr %1465, ptr %200, align 8, !dbg !637
  call void @llvm.dbg.declare(metadata ptr %201, metadata !638, metadata !DIExpression()), !dbg !637
  %1466 = load i8, ptr %129, align 1, !dbg !637
  store i8 %1466, ptr %201, align 1, !dbg !637
  call void @llvm.dbg.declare(metadata ptr %202, metadata !639, metadata !DIExpression()), !dbg !637
  call void @llvm.dbg.declare(metadata ptr %203, metadata !640, metadata !DIExpression()), !dbg !642
  store i8 0, ptr %203, align 1, !dbg !642
  %1467 = load i8, ptr %55, align 1, !dbg !642
  store i8 %1467, ptr %203, align 1, !dbg !642
  %1468 = load i8, ptr %203, align 1, !dbg !642
  store i8 %1468, ptr %204, align 1, !dbg !642
  %1469 = load i8, ptr %204, align 1, !dbg !642
  store i8 %1469, ptr %202, align 1, !dbg !637
  call void @llvm.dbg.declare(metadata ptr %205, metadata !643, metadata !DIExpression()), !dbg !637
  %1470 = load i64, ptr %136, align 8, !dbg !637
  store i64 %1470, ptr %205, align 8, !dbg !637
  %1471 = load i8, ptr %202, align 1, !dbg !644
  %1472 = zext i8 %1471 to i32, !dbg !644
  %1473 = icmp eq i32 %1472, 4, !dbg !644
  br i1 %1473, label %1474, label %1508, !dbg !637

1474:                                             ; preds = %1464
  br label %1475, !dbg !644

1475:                                             ; preds = %1474
  call void @llvm.dbg.declare(metadata ptr %206, metadata !646, metadata !DIExpression()), !dbg !648
  %1476 = load ptr, ptr %200, align 8, !dbg !648
  %1477 = ptrtoint ptr %1476 to i64, !dbg !648
  %1478 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !648
  %1479 = ptrtoint ptr %1478 to i64, !dbg !648
  %1480 = sub i64 %1477, %1479, !dbg !648
  store i64 %1480, ptr %206, align 8, !dbg !648
  call void @llvm.dbg.declare(metadata ptr %207, metadata !649, metadata !DIExpression()), !dbg !648
  %1481 = load i8, ptr %201, align 1, !dbg !648
  store i8 %1481, ptr %9, align 1
  call void @llvm.dbg.declare(metadata ptr %9, metadata !531, metadata !DIExpression()), !dbg !650
  %1482 = load i8, ptr %9, align 1, !dbg !652
  %1483 = zext i8 %1482 to i32, !dbg !652
  %1484 = icmp ne i32 %1483, 0, !dbg !652
  br i1 %1484, label %1485, label %1488, !dbg !652

1485:                                             ; preds = %1475
  %1486 = load i8, ptr %9, align 1, !dbg !652
  %1487 = zext i8 %1486 to i32, !dbg !652
  br label %1489, !dbg !652

1488:                                             ; preds = %1475
  br label %1489, !dbg !652

1489:                                             ; preds = %1485, %1488
  %1490 = phi i32 [ %1487, %1485 ], [ 8, %1488 ], !dbg !652
  %1491 = trunc i32 %1490 to i8, !dbg !652
  %1492 = zext i8 %1491 to i64, !dbg !648
  store i64 %1492, ptr %207, align 8, !dbg !648
  br label %1493, !dbg !648

1493:                                             ; preds = %1489
  call void @llvm.dbg.declare(metadata ptr %208, metadata !653, metadata !DIExpression()), !dbg !655
  store i64 0, ptr %208, align 8, !dbg !655
  %1494 = load i64, ptr %206, align 8, !dbg !656
  %1495 = load i64, ptr %208, align 8, !dbg !656
  %1496 = sub i64 %1494, %1495, !dbg !656
  %1497 = icmp ult i64 %1496, 8, !dbg !656
  br i1 %1497, label %1504, label %1498, !dbg !656

1498:                                             ; preds = %1493
  %1499 = load i64, ptr %208, align 8, !dbg !656
  %1500 = load i64, ptr %206, align 8, !dbg !656
  %1501 = sub i64 %1499, %1500, !dbg !656
  %1502 = load i64, ptr %207, align 8, !dbg !656
  %1503 = icmp ult i64 %1501, %1502, !dbg !656
  br i1 %1503, label %1504, label %1505, !dbg !655

1504:                                             ; preds = %1498, %1493
  store i8 0, ptr %33, align 1, !dbg !656
  br label %1505, !dbg !656

1505:                                             ; preds = %1504, %1498
  br label %1506, !dbg !655

1506:                                             ; preds = %1505
  br label %1507, !dbg !648

1507:                                             ; preds = %1506
  br label %1516, !dbg !648

1508:                                             ; preds = %1464
  %1509 = load i8, ptr %202, align 1, !dbg !658
  %1510 = zext i8 %1509 to i32, !dbg !658
  %1511 = icmp eq i32 %1510, 0, !dbg !658
  br i1 %1511, label %1512, label %1515, !dbg !644

1512:                                             ; preds = %1508
  br label %1513, !dbg !658

1513:                                             ; preds = %1512
  store i8 0, ptr %33, align 1, !dbg !660
  br label %1514, !dbg !660

1514:                                             ; preds = %1513
  br label %1515, !dbg !660

1515:                                             ; preds = %1514, %1508
  br label %1516

1516:                                             ; preds = %1515, %1507
  %1517 = load ptr, ptr %200, align 8, !dbg !637
  %1518 = load i8, ptr %201, align 1, !dbg !637
  %1519 = load i64, ptr %205, align 8, !dbg !637
  store ptr %1517, ptr %18, align 8
  call void @llvm.dbg.declare(metadata ptr %18, metadata !483, metadata !DIExpression()), !dbg !662
  store i8 %1518, ptr %19, align 1
  call void @llvm.dbg.declare(metadata ptr %19, metadata !490, metadata !DIExpression()), !dbg !664
  store i64 %1519, ptr %20, align 8
  call void @llvm.dbg.declare(metadata ptr %20, metadata !492, metadata !DIExpression()), !dbg !665
  %1520 = load i8, ptr %19, align 1, !dbg !666
  %1521 = zext i8 %1520 to i32, !dbg !666
  %1522 = icmp ne i32 %1521, 0, !dbg !666
  br i1 %1522, label %1523, label %1526, !dbg !666

1523:                                             ; preds = %1516
  %1524 = load i8, ptr %19, align 1, !dbg !667
  %1525 = zext i8 %1524 to i32, !dbg !667
  br label %1527, !dbg !666

1526:                                             ; preds = %1516
  br label %1527, !dbg !666

1527:                                             ; preds = %1526, %1523
  %1528 = phi i32 [ %1525, %1523 ], [ 8, %1526 ], !dbg !666
  switch i32 %1528, label %1541 [
    i32 1, label %1529
    i32 2, label %1532
    i32 4, label %1535
    i32 8, label %1538
  ], !dbg !668

1529:                                             ; preds = %1527
  %1530 = load ptr, ptr %18, align 8, !dbg !669
  %1531 = load i64, ptr %20, align 8, !dbg !670
  call void asm sideeffect "*(u8 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %1530, i64 %1531) #5, !dbg !671, !srcloc !501
  br label %1542, !dbg !672

1532:                                             ; preds = %1527
  %1533 = load ptr, ptr %18, align 8, !dbg !673
  %1534 = load i64, ptr %20, align 8, !dbg !674
  call void asm sideeffect "*(u16 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %1533, i64 %1534) #5, !dbg !675, !srcloc !506
  br label %1542, !dbg !676

1535:                                             ; preds = %1527
  %1536 = load ptr, ptr %18, align 8, !dbg !677
  %1537 = load i64, ptr %20, align 8, !dbg !678
  call void asm sideeffect "*(u32 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %1536, i64 %1537) #5, !dbg !679, !srcloc !511
  br label %1542, !dbg !680

1538:                                             ; preds = %1527
  %1539 = load ptr, ptr %18, align 8, !dbg !681
  %1540 = load i64, ptr %20, align 8, !dbg !682
  call void asm sideeffect "*(u64 *)($0 + 0) = $1", "r,r,~{memory}"(ptr %1539, i64 %1540) #5, !dbg !683, !srcloc !516
  br label %1542, !dbg !684

1541:                                             ; preds = %1527
  call void @llvm.trap(), !dbg !685
  br label %1542, !dbg !686

1542:                                             ; preds = %1529, %1532, %1535, %1538, %1541
  br label %1543, !dbg !637

1543:                                             ; preds = %1542
  br label %1544

1544:                                             ; preds = %1543, %1462
  call void @llvm.dbg.declare(metadata ptr %209, metadata !687, metadata !DIExpression()), !dbg !690
  store i8 0, ptr %209, align 1, !dbg !690
  %1545 = load i8, ptr %55, align 1, !dbg !690
  store i8 %1545, ptr %209, align 1, !dbg !690
  %1546 = load i8, ptr %209, align 1, !dbg !690
  store i8 %1546, ptr %210, align 1, !dbg !690
  %1547 = load i8, ptr %210, align 1, !dbg !690
  %1548 = zext i8 %1547 to i32, !dbg !691
  %1549 = icmp eq i32 %1548, 4, !dbg !691
  br i1 %1549, label %1550, label %1603, !dbg !691

1550:                                             ; preds = %1544
  br i1 false, label %1551, label %1603, !dbg !691

1551:                                             ; preds = %1550
  %1552 = load i8, ptr %129, align 1, !dbg !691
  %1553 = zext i8 %1552 to i32, !dbg !691
  %1554 = icmp eq i32 %1553, 8, !dbg !691
  br i1 %1554, label %1555, label %1603, !dbg !691

1555:                                             ; preds = %1551
  call void @llvm.dbg.declare(metadata ptr %211, metadata !692, metadata !DIExpression()), !dbg !694
  store i32 0, ptr %211, align 4, !dbg !694
  %1556 = load i32, ptr %211, align 4, !dbg !694
  store i32 %1556, ptr %212, align 4, !dbg !694
  %1557 = load i32, ptr %212, align 4, !dbg !694
  %1558 = icmp eq i32 %1557, 0, !dbg !691
  br i1 %1558, label %1559, label %1603, !dbg !525

1559:                                             ; preds = %1555
  br label %1560, !dbg !691

1560:                                             ; preds = %1559
  call void @llvm.dbg.declare(metadata ptr %213, metadata !695, metadata !DIExpression()), !dbg !697
  %1561 = load ptr, ptr %189, align 8, !dbg !697
  %1562 = ptrtoint ptr %1561 to i64, !dbg !697
  %1563 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !697
  %1564 = ptrtoint ptr %1563 to i64, !dbg !697
  %1565 = sub i64 %1562, %1564, !dbg !697
  store i64 %1565, ptr %213, align 8, !dbg !697
  call void @llvm.dbg.declare(metadata ptr %214, metadata !698, metadata !DIExpression()), !dbg !697
  call void @llvm.dbg.declare(metadata ptr %215, metadata !699, metadata !DIExpression()), !dbg !701
  store i8 0, ptr %215, align 1, !dbg !701
  %1566 = load i8, ptr %215, align 1, !dbg !701
  store i8 %1566, ptr %216, align 1, !dbg !701
  %1567 = load i8, ptr %216, align 1, !dbg !701
  %1568 = zext i8 %1567 to i32, !dbg !697
  %1569 = trunc i32 %1568 to i8, !dbg !697
  store i8 %1569, ptr %214, align 1, !dbg !697
  %1570 = load i8, ptr %129, align 1, !dbg !702
  store i8 %1570, ptr %10, align 1
  call void @llvm.dbg.declare(metadata ptr %10, metadata !531, metadata !DIExpression()), !dbg !704
  %1571 = load i8, ptr %10, align 1, !dbg !706
  %1572 = zext i8 %1571 to i32, !dbg !706
  %1573 = icmp ne i32 %1572, 0, !dbg !706
  br i1 %1573, label %1574, label %1577, !dbg !706

1574:                                             ; preds = %1560
  %1575 = load i8, ptr %10, align 1, !dbg !706
  %1576 = zext i8 %1575 to i32, !dbg !706
  br label %1578, !dbg !706

1577:                                             ; preds = %1560
  br label %1578, !dbg !706

1578:                                             ; preds = %1574, %1577
  %1579 = phi i32 [ %1576, %1574 ], [ 8, %1577 ], !dbg !706
  %1580 = trunc i32 %1579 to i8, !dbg !706
  %1581 = zext i8 %1580 to i32, !dbg !702
  %1582 = icmp eq i32 %1581, 8, !dbg !702
  br i1 %1582, label %1583, label %1601, !dbg !702

1583:                                             ; preds = %1578
  %1584 = load i8, ptr %214, align 1, !dbg !702
  %1585 = zext i8 %1584 to i32, !dbg !702
  %1586 = icmp ne i32 %1585, 0, !dbg !702
  br i1 %1586, label %1587, label %1601, !dbg !697

1587:                                             ; preds = %1583
  call void @llvm.dbg.declare(metadata ptr %217, metadata !707, metadata !DIExpression()), !dbg !709
  store ptr null, ptr %217, align 8, !dbg !709
  br label %1588, !dbg !709

1588:                                             ; preds = %1587
  %1589 = load i64, ptr %213, align 8, !dbg !710
  %1590 = icmp eq i64 %1589, 0, !dbg !710
  br i1 %1590, label %1591, label %1599, !dbg !713

1591:                                             ; preds = %1588
  %1592 = load i8, ptr %214, align 1, !dbg !714
  %1593 = zext i8 %1592 to i32, !dbg !714
  %1594 = icmp eq i32 %1593, 4, !dbg !714
  br i1 %1594, label %1595, label %1597, !dbg !717

1595:                                             ; preds = %1591
  %1596 = load ptr, ptr %217, align 8, !dbg !714
  store ptr %1596, ptr %34, align 8, !dbg !714
  br label %1597, !dbg !714

1597:                                             ; preds = %1595, %1591
  %1598 = load i8, ptr %214, align 1, !dbg !717
  store i8 %1598, ptr %33, align 1, !dbg !717
  br label %1599, !dbg !717

1599:                                             ; preds = %1597, %1588
  br label %1600, !dbg !713

1600:                                             ; preds = %1599
  br label %1601, !dbg !709

1601:                                             ; preds = %1600, %1583, %1578
  br label %1602, !dbg !697

1602:                                             ; preds = %1601
  br label %1603, !dbg !697

1603:                                             ; preds = %1602, %1555, %1551, %1550, %1544
  br label %1604, !dbg !525

1604:                                             ; preds = %1603, %1159
  br label %1605

1605:                                             ; preds = %1604, %811
  br label %1606, !dbg !322

1606:                                             ; preds = %1605
  br label %1607, !dbg !322

1607:                                             ; preds = %1606
  call void @llvm.dbg.label(metadata !718), !dbg !719
  br label %1608, !dbg !720

1608:                                             ; preds = %1607
  call void @llvm.dbg.declare(metadata ptr %218, metadata !721, metadata !DIExpression()), !dbg !723
  store i8 4, ptr %11, align 1
  call void @llvm.dbg.declare(metadata ptr %11, metadata !531, metadata !DIExpression()), !dbg !724
  %1609 = load i8, ptr %11, align 1, !dbg !726
  %1610 = zext i8 %1609 to i32, !dbg !726
  %1611 = icmp ne i32 %1610, 0, !dbg !726
  br i1 %1611, label %1612, label %1615, !dbg !726

1612:                                             ; preds = %1608
  %1613 = load i8, ptr %11, align 1, !dbg !726
  %1614 = zext i8 %1613 to i32, !dbg !726
  br label %1616, !dbg !726

1615:                                             ; preds = %1608
  br label %1616, !dbg !726

1616:                                             ; preds = %1612, %1615
  %1617 = phi i32 [ %1614, %1612 ], [ 8, %1615 ], !dbg !726
  %1618 = trunc i32 %1617 to i8, !dbg !726
  store i8 %1618, ptr %218, align 1, !dbg !723
  br label %1619, !dbg !723

1619:                                             ; preds = %1616
  call void @llvm.dbg.declare(metadata ptr %219, metadata !727, metadata !DIExpression()), !dbg !729
  %1620 = load i8, ptr %218, align 1, !dbg !729
  store i8 %1620, ptr %219, align 1, !dbg !729
  call void @llvm.dbg.declare(metadata ptr %220, metadata !730, metadata !DIExpression()), !dbg !729
  %1621 = load i8, ptr %219, align 1, !dbg !729
  store i8 %1621, ptr %12, align 1
  call void @llvm.dbg.declare(metadata ptr %12, metadata !531, metadata !DIExpression()), !dbg !731
  %1622 = load i8, ptr %12, align 1, !dbg !733
  %1623 = zext i8 %1622 to i32, !dbg !733
  %1624 = icmp ne i32 %1623, 0, !dbg !733
  br i1 %1624, label %1625, label %1628, !dbg !733

1625:                                             ; preds = %1619
  %1626 = load i8, ptr %12, align 1, !dbg !733
  %1627 = zext i8 %1626 to i32, !dbg !733
  br label %1629, !dbg !733

1628:                                             ; preds = %1619
  br label %1629, !dbg !733

1629:                                             ; preds = %1625, %1628
  %1630 = phi i32 [ %1627, %1625 ], [ 8, %1628 ], !dbg !733
  %1631 = trunc i32 %1630 to i8, !dbg !733
  store i8 %1631, ptr %220, align 1, !dbg !729
  call void @llvm.dbg.declare(metadata ptr %221, metadata !734, metadata !DIExpression()), !dbg !729
  store i8 0, ptr %221, align 1, !dbg !729
  call void @llvm.dbg.declare(metadata ptr %222, metadata !735, metadata !DIExpression()), !dbg !729
  store i64 2, ptr %222, align 8, !dbg !729
  %1632 = load i8, ptr %220, align 1, !dbg !736
  %1633 = zext i8 %1632 to i32, !dbg !736
  %1634 = icmp eq i32 %1633, 1, !dbg !736
  br i1 %1634, label %1635, label %1636, !dbg !736

1635:                                             ; preds = %1629
  br label %1649, !dbg !736

1636:                                             ; preds = %1629
  %1637 = load i8, ptr %220, align 1, !dbg !736
  %1638 = zext i8 %1637 to i32, !dbg !736
  %1639 = icmp eq i32 %1638, 2, !dbg !736
  br i1 %1639, label %1640, label %1641, !dbg !736

1640:                                             ; preds = %1636
  br label %1647, !dbg !736

1641:                                             ; preds = %1636
  %1642 = load i8, ptr %220, align 1, !dbg !736
  %1643 = zext i8 %1642 to i32, !dbg !736
  %1644 = icmp eq i32 %1643, 4, !dbg !736
  %1645 = zext i1 %1644 to i64, !dbg !736
  %1646 = select i1 %1644, i32 2, i32 3, !dbg !736
  br label %1647, !dbg !736

1647:                                             ; preds = %1641, %1640
  %1648 = phi i32 [ 1, %1640 ], [ %1646, %1641 ], !dbg !736
  br label %1649, !dbg !736

1649:                                             ; preds = %1647, %1635
  %1650 = phi i32 [ 0, %1635 ], [ %1648, %1647 ], !dbg !736
  %1651 = icmp eq i32 %1650, 0, !dbg !736
  br i1 %1651, label %1652, label %1707, !dbg !729

1652:                                             ; preds = %1649
  %1653 = load i8, ptr %41, align 1, !dbg !738
  %1654 = zext i8 %1653 to i32, !dbg !738
  %1655 = icmp eq i32 %1654, 4, !dbg !738
  br i1 %1655, label %1656, label %1672, !dbg !742

1656:                                             ; preds = %1652
  call void @llvm.dbg.declare(metadata ptr %223, metadata !743, metadata !DIExpression()), !dbg !745
  %1657 = load ptr, ptr %38, align 8, !dbg !745
  %1658 = ptrtoint ptr %1657 to i64, !dbg !745
  %1659 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !745
  %1660 = ptrtoint ptr %1659 to i64, !dbg !745
  %1661 = add i64 %1660, 1, !dbg !745
  %1662 = inttoptr i64 %1661 to ptr, !dbg !745
  %1663 = ptrtoint ptr %1662 to i64, !dbg !745
  %1664 = sub i64 %1658, %1663, !dbg !745
  store i64 %1664, ptr %223, align 8, !dbg !745
  %1665 = load i64, ptr %223, align 8, !dbg !745
  %1666 = call i64 asm sideeffect "", "=r,0"(i64 %1665) #5, !dbg !745, !srcloc !746
  store i64 %1666, ptr %223, align 8, !dbg !745
  %1667 = load i64, ptr %223, align 8, !dbg !745
  %1668 = load i64, ptr %100, align 8, !dbg !745
  %1669 = add i64 %1667, %1668, !dbg !745
  store i64 %1669, ptr %224, align 8, !dbg !745
  %1670 = load i64, ptr %224, align 8, !dbg !745
  %1671 = inttoptr i64 %1670 to ptr, !dbg !738
  store ptr %1671, ptr %38, align 8, !dbg !738
  br label %1672, !dbg !738

1672:                                             ; preds = %1656, %1652
  br label %1673, !dbg !747

1673:                                             ; preds = %1672
  %1674 = load i8, ptr %41, align 1, !dbg !748
  %1675 = zext i8 %1674 to i32, !dbg !748
  %1676 = icmp eq i32 %1675, 0, !dbg !748
  br i1 %1676, label %1677, label %1690, !dbg !751

1677:                                             ; preds = %1673
  %1678 = load i8, ptr %221, align 1, !dbg !752
  %1679 = zext i8 %1678 to i32, !dbg !752
  %1680 = icmp eq i32 %1679, 8, !dbg !752
  br i1 %1680, label %1681, label %1685, !dbg !755

1681:                                             ; preds = %1677
  %1682 = load i64, ptr %222, align 8, !dbg !752
  %1683 = trunc i64 %1682 to i8, !dbg !752
  %1684 = getelementptr inbounds [8 x i8], ptr %38, i64 0, i64 1, !dbg !752
  store i8 %1683, ptr %1684, align 1, !dbg !752
  br label %1689, !dbg !752

1685:                                             ; preds = %1677
  %1686 = load i64, ptr %222, align 8, !dbg !752
  %1687 = trunc i64 %1686 to i8, !dbg !752
  %1688 = getelementptr inbounds [8 x i8], ptr %38, i64 0, i64 0, !dbg !752
  store i8 %1687, ptr %1688, align 8, !dbg !752
  br label %1689

1689:                                             ; preds = %1685, %1681
  br label %1705, !dbg !755

1690:                                             ; preds = %1673
  call void @llvm.dbg.declare(metadata ptr %225, metadata !756, metadata !DIExpression()), !dbg !764
  %1691 = load ptr, ptr %38, align 8, !dbg !764
  store ptr %1691, ptr %225, align 8, !dbg !764
  %1692 = load i8, ptr %221, align 1, !dbg !765
  %1693 = zext i8 %1692 to i32, !dbg !765
  %1694 = icmp eq i32 %1693, 8, !dbg !765
  br i1 %1694, label %1695, label %1699, !dbg !764

1695:                                             ; preds = %1690
  %1696 = load i64, ptr %222, align 8, !dbg !765
  %1697 = trunc i64 %1696 to i8, !dbg !765
  %1698 = getelementptr inbounds [8 x i8], ptr %225, i64 0, i64 1, !dbg !765
  store volatile i8 %1697, ptr %1698, align 1, !dbg !765
  br label %1703, !dbg !765

1699:                                             ; preds = %1690
  %1700 = load i64, ptr %222, align 8, !dbg !765
  %1701 = trunc i64 %1700 to i8, !dbg !765
  %1702 = getelementptr inbounds [8 x i8], ptr %225, i64 0, i64 0, !dbg !765
  store volatile i8 %1701, ptr %1702, align 8, !dbg !765
  br label %1703

1703:                                             ; preds = %1699, %1695
  %1704 = load volatile ptr, ptr %225, align 8, !dbg !764
  store ptr %1704, ptr %38, align 8, !dbg !764
  br label %1705

1705:                                             ; preds = %1703, %1689
  store i8 0, ptr %41, align 1, !dbg !751
  br label %1706, !dbg !751

1706:                                             ; preds = %1705
  br label %1798, !dbg !747

1707:                                             ; preds = %1649
  %1708 = load i8, ptr %220, align 1, !dbg !767
  %1709 = zext i8 %1708 to i32, !dbg !767
  %1710 = icmp eq i32 %1709, 1, !dbg !767
  br i1 %1710, label %1711, label %1712, !dbg !767

1711:                                             ; preds = %1707
  br label %1725, !dbg !767

1712:                                             ; preds = %1707
  %1713 = load i8, ptr %220, align 1, !dbg !767
  %1714 = zext i8 %1713 to i32, !dbg !767
  %1715 = icmp eq i32 %1714, 2, !dbg !767
  br i1 %1715, label %1716, label %1717, !dbg !767

1716:                                             ; preds = %1712
  br label %1723, !dbg !767

1717:                                             ; preds = %1712
  %1718 = load i8, ptr %220, align 1, !dbg !767
  %1719 = zext i8 %1718 to i32, !dbg !767
  %1720 = icmp eq i32 %1719, 4, !dbg !767
  %1721 = zext i1 %1720 to i64, !dbg !767
  %1722 = select i1 %1720, i32 2, i32 3, !dbg !767
  br label %1723, !dbg !767

1723:                                             ; preds = %1717, %1716
  %1724 = phi i32 [ 1, %1716 ], [ %1722, %1717 ], !dbg !767
  br label %1725, !dbg !767

1725:                                             ; preds = %1723, %1711
  %1726 = phi i32 [ 0, %1711 ], [ %1724, %1723 ], !dbg !767
  %1727 = icmp eq i32 %1726, 1, !dbg !767
  br i1 %1727, label %1728, label %1763, !dbg !736

1728:                                             ; preds = %1725
  %1729 = load i8, ptr %41, align 1, !dbg !769
  %1730 = zext i8 %1729 to i32, !dbg !769
  %1731 = icmp eq i32 %1730, 4, !dbg !769
  br i1 %1731, label %1732, label %1748, !dbg !773

1732:                                             ; preds = %1728
  call void @llvm.dbg.declare(metadata ptr %226, metadata !774, metadata !DIExpression()), !dbg !776
  %1733 = load ptr, ptr %38, align 8, !dbg !776
  %1734 = ptrtoint ptr %1733 to i64, !dbg !776
  %1735 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !776
  %1736 = ptrtoint ptr %1735 to i64, !dbg !776
  %1737 = add i64 %1736, 1, !dbg !776
  %1738 = inttoptr i64 %1737 to ptr, !dbg !776
  %1739 = ptrtoint ptr %1738 to i64, !dbg !776
  %1740 = sub i64 %1734, %1739, !dbg !776
  store i64 %1740, ptr %226, align 8, !dbg !776
  %1741 = load i64, ptr %226, align 8, !dbg !776
  %1742 = call i64 asm sideeffect "", "=r,0"(i64 %1741) #5, !dbg !776, !srcloc !777
  store i64 %1742, ptr %226, align 8, !dbg !776
  %1743 = load i64, ptr %226, align 8, !dbg !776
  %1744 = load i64, ptr %100, align 8, !dbg !776
  %1745 = add i64 %1743, %1744, !dbg !776
  store i64 %1745, ptr %227, align 8, !dbg !776
  %1746 = load i64, ptr %227, align 8, !dbg !776
  %1747 = inttoptr i64 %1746 to ptr, !dbg !769
  store ptr %1747, ptr %38, align 8, !dbg !769
  br label %1748, !dbg !769

1748:                                             ; preds = %1732, %1728
  br label %1749, !dbg !778

1749:                                             ; preds = %1748
  %1750 = load i8, ptr %41, align 1, !dbg !779
  %1751 = zext i8 %1750 to i32, !dbg !779
  %1752 = icmp eq i32 %1751, 0, !dbg !779
  br i1 %1752, label %1753, label %1756, !dbg !782

1753:                                             ; preds = %1749
  %1754 = load i64, ptr %222, align 8, !dbg !783
  %1755 = trunc i64 %1754 to i16, !dbg !783
  store i16 %1755, ptr %38, align 8, !dbg !783
  br label %1761, !dbg !783

1756:                                             ; preds = %1749
  call void @llvm.dbg.declare(metadata ptr %228, metadata !785, metadata !DIExpression()), !dbg !793
  %1757 = load ptr, ptr %38, align 8, !dbg !793
  store ptr %1757, ptr %228, align 8, !dbg !793
  %1758 = load i64, ptr %222, align 8, !dbg !793
  %1759 = trunc i64 %1758 to i16, !dbg !793
  store volatile i16 %1759, ptr %228, align 8, !dbg !793
  %1760 = load volatile ptr, ptr %228, align 8, !dbg !793
  store ptr %1760, ptr %38, align 8, !dbg !793
  br label %1761

1761:                                             ; preds = %1756, %1753
  store i8 0, ptr %41, align 1, !dbg !782
  br label %1762, !dbg !782

1762:                                             ; preds = %1761
  br label %1797, !dbg !778

1763:                                             ; preds = %1725
  %1764 = load i8, ptr %220, align 1, !dbg !794
  %1765 = zext i8 %1764 to i32, !dbg !794
  %1766 = icmp eq i32 %1765, 1, !dbg !794
  br i1 %1766, label %1767, label %1768, !dbg !794

1767:                                             ; preds = %1763
  br label %1781, !dbg !794

1768:                                             ; preds = %1763
  %1769 = load i8, ptr %220, align 1, !dbg !794
  %1770 = zext i8 %1769 to i32, !dbg !794
  %1771 = icmp eq i32 %1770, 2, !dbg !794
  br i1 %1771, label %1772, label %1773, !dbg !794

1772:                                             ; preds = %1768
  br label %1779, !dbg !794

1773:                                             ; preds = %1768
  %1774 = load i8, ptr %220, align 1, !dbg !794
  %1775 = zext i8 %1774 to i32, !dbg !794
  %1776 = icmp eq i32 %1775, 4, !dbg !794
  %1777 = zext i1 %1776 to i64, !dbg !794
  %1778 = select i1 %1776, i32 2, i32 3, !dbg !794
  br label %1779, !dbg !794

1779:                                             ; preds = %1773, %1772
  %1780 = phi i32 [ 1, %1772 ], [ %1778, %1773 ], !dbg !794
  br label %1781, !dbg !794

1781:                                             ; preds = %1779, %1767
  %1782 = phi i32 [ 0, %1767 ], [ %1780, %1779 ], !dbg !794
  %1783 = icmp eq i32 %1782, 2, !dbg !794
  br i1 %1783, label %1784, label %1791, !dbg !767

1784:                                             ; preds = %1781
  br label %1785, !dbg !796

1785:                                             ; preds = %1784
  %1786 = load i64, ptr %222, align 8, !dbg !798
  %1787 = trunc i64 %1786 to i32, !dbg !798
  %1788 = zext i32 %1787 to i64, !dbg !798
  %1789 = inttoptr i64 %1788 to ptr, !dbg !798
  store ptr %1789, ptr %38, align 8, !dbg !798
  store i8 0, ptr %41, align 1, !dbg !798
  br label %1790, !dbg !798

1790:                                             ; preds = %1785
  br label %1796, !dbg !796

1791:                                             ; preds = %1781
  br label %1792, !dbg !800

1792:                                             ; preds = %1791
  %1793 = load i64, ptr %222, align 8, !dbg !802
  %1794 = inttoptr i64 %1793 to ptr, !dbg !802
  store ptr %1794, ptr %38, align 8, !dbg !802
  store i8 0, ptr %41, align 1, !dbg !802
  br label %1795, !dbg !802

1795:                                             ; preds = %1792
  br label %1796

1796:                                             ; preds = %1795, %1790
  br label %1797

1797:                                             ; preds = %1796, %1762
  br label %1798

1798:                                             ; preds = %1797, %1706
  br label %1799, !dbg !729

1799:                                             ; preds = %1798
  br label %1800, !dbg !723

1800:                                             ; preds = %1799
  br label %1801, !dbg !723

1801:                                             ; preds = %1800
  call void @llvm.dbg.label(metadata !804), !dbg !805
  br label %1802, !dbg !806

1802:                                             ; preds = %1801
  call void @llvm.dbg.declare(metadata ptr %229, metadata !807, metadata !DIExpression()), !dbg !810
  store i8 0, ptr %229, align 1, !dbg !810
  call void @llvm.dbg.declare(metadata ptr %230, metadata !811, metadata !DIExpression()), !dbg !810
  store i8 8, ptr %230, align 1, !dbg !810
  call void @llvm.dbg.declare(metadata ptr %231, metadata !812, metadata !DIExpression()), !dbg !810
  %1803 = load i8, ptr %230, align 1, !dbg !810
  store i8 %1803, ptr %13, align 1
  call void @llvm.dbg.declare(metadata ptr %13, metadata !531, metadata !DIExpression()), !dbg !813
  %1804 = load i8, ptr %13, align 1, !dbg !815
  %1805 = zext i8 %1804 to i32, !dbg !815
  %1806 = icmp ne i32 %1805, 0, !dbg !815
  br i1 %1806, label %1807, label %1810, !dbg !815

1807:                                             ; preds = %1802
  %1808 = load i8, ptr %13, align 1, !dbg !815
  %1809 = zext i8 %1808 to i32, !dbg !815
  br label %1811, !dbg !815

1810:                                             ; preds = %1802
  br label %1811, !dbg !815

1811:                                             ; preds = %1807, %1810
  %1812 = phi i32 [ %1809, %1807 ], [ 8, %1810 ], !dbg !815
  %1813 = trunc i32 %1812 to i8, !dbg !815
  store i8 %1813, ptr %231, align 1, !dbg !810
  call void @llvm.dbg.declare(metadata ptr %232, metadata !816, metadata !DIExpression()), !dbg !810
  store i8 0, ptr %232, align 1, !dbg !810
  call void @llvm.dbg.declare(metadata ptr %233, metadata !817, metadata !DIExpression()), !dbg !810
  %1814 = load i8, ptr %229, align 1, !dbg !810
  %1815 = zext i8 %1814 to i32, !dbg !810
  %1816 = icmp eq i32 %1815, 0, !dbg !810
  br i1 %1816, label %1817, label %1819, !dbg !810

1817:                                             ; preds = %1811
  %1818 = load ptr, ptr %38, align 8, !dbg !810
  br label %1940, !dbg !810

1819:                                             ; preds = %1811
  %1820 = load i8, ptr %229, align 1, !dbg !810
  %1821 = zext i8 %1820 to i32, !dbg !810
  %1822 = icmp eq i32 %1821, 1, !dbg !810
  br i1 %1822, label %1823, label %1825, !dbg !810

1823:                                             ; preds = %1819
  %1824 = load ptr, ptr %42, align 8, !dbg !810
  br label %1938, !dbg !810

1825:                                             ; preds = %1819
  %1826 = load i8, ptr %229, align 1, !dbg !810
  %1827 = zext i8 %1826 to i32, !dbg !810
  %1828 = icmp eq i32 %1827, 2, !dbg !810
  br i1 %1828, label %1829, label %1831, !dbg !810

1829:                                             ; preds = %1825
  %1830 = load ptr, ptr %46, align 8, !dbg !810
  br label %1936, !dbg !810

1831:                                             ; preds = %1825
  %1832 = load i8, ptr %229, align 1, !dbg !810
  %1833 = zext i8 %1832 to i32, !dbg !810
  %1834 = icmp eq i32 %1833, 3, !dbg !810
  br i1 %1834, label %1835, label %1837, !dbg !810

1835:                                             ; preds = %1831
  %1836 = load ptr, ptr %50, align 8, !dbg !810
  br label %1934, !dbg !810

1837:                                             ; preds = %1831
  %1838 = load i8, ptr %229, align 1, !dbg !810
  %1839 = zext i8 %1838 to i32, !dbg !810
  %1840 = icmp eq i32 %1839, 4, !dbg !810
  br i1 %1840, label %1841, label %1843, !dbg !810

1841:                                             ; preds = %1837
  %1842 = load ptr, ptr %54, align 8, !dbg !810
  br label %1932, !dbg !810

1843:                                             ; preds = %1837
  %1844 = load i8, ptr %229, align 1, !dbg !810
  %1845 = zext i8 %1844 to i32, !dbg !810
  %1846 = icmp eq i32 %1845, 5, !dbg !810
  br i1 %1846, label %1847, label %1849, !dbg !810

1847:                                             ; preds = %1843
  %1848 = load ptr, ptr %56, align 8, !dbg !810
  br label %1930, !dbg !810

1849:                                             ; preds = %1843
  %1850 = load i8, ptr %229, align 1, !dbg !810
  %1851 = zext i8 %1850 to i32, !dbg !810
  %1852 = icmp eq i32 %1851, 6, !dbg !810
  br i1 %1852, label %1853, label %1855, !dbg !810

1853:                                             ; preds = %1849
  %1854 = load ptr, ptr %60, align 8, !dbg !810
  br label %1928, !dbg !810

1855:                                             ; preds = %1849
  %1856 = load i8, ptr %229, align 1, !dbg !810
  %1857 = zext i8 %1856 to i32, !dbg !810
  %1858 = icmp eq i32 %1857, 7, !dbg !810
  br i1 %1858, label %1859, label %1861, !dbg !810

1859:                                             ; preds = %1855
  %1860 = load ptr, ptr %64, align 8, !dbg !810
  br label %1926, !dbg !810

1861:                                             ; preds = %1855
  %1862 = load i8, ptr %229, align 1, !dbg !810
  %1863 = zext i8 %1862 to i32, !dbg !810
  %1864 = icmp eq i32 %1863, 8, !dbg !810
  br i1 %1864, label %1865, label %1867, !dbg !810

1865:                                             ; preds = %1861
  %1866 = load ptr, ptr %68, align 8, !dbg !810
  br label %1924, !dbg !810

1867:                                             ; preds = %1861
  %1868 = load i8, ptr %229, align 1, !dbg !810
  %1869 = zext i8 %1868 to i32, !dbg !810
  %1870 = icmp eq i32 %1869, 9, !dbg !810
  br i1 %1870, label %1871, label %1873, !dbg !810

1871:                                             ; preds = %1867
  %1872 = load ptr, ptr %72, align 8, !dbg !810
  br label %1922, !dbg !810

1873:                                             ; preds = %1867
  %1874 = load i8, ptr %229, align 1, !dbg !810
  %1875 = zext i8 %1874 to i32, !dbg !810
  %1876 = icmp eq i32 %1875, 10, !dbg !810
  br i1 %1876, label %1877, label %1879, !dbg !810

1877:                                             ; preds = %1873
  %1878 = load ptr, ptr %76, align 8, !dbg !810
  br label %1920, !dbg !810

1879:                                             ; preds = %1873
  %1880 = load i8, ptr %229, align 1, !dbg !810
  %1881 = zext i8 %1880 to i32, !dbg !810
  %1882 = icmp eq i32 %1881, 11, !dbg !810
  br i1 %1882, label %1883, label %1885, !dbg !810

1883:                                             ; preds = %1879
  %1884 = load ptr, ptr %80, align 8, !dbg !810
  br label %1918, !dbg !810

1885:                                             ; preds = %1879
  %1886 = load i8, ptr %229, align 1, !dbg !810
  %1887 = zext i8 %1886 to i32, !dbg !810
  %1888 = icmp eq i32 %1887, 12, !dbg !810
  br i1 %1888, label %1889, label %1891, !dbg !810

1889:                                             ; preds = %1885
  %1890 = load ptr, ptr %84, align 8, !dbg !810
  br label %1916, !dbg !810

1891:                                             ; preds = %1885
  %1892 = load i8, ptr %229, align 1, !dbg !810
  %1893 = zext i8 %1892 to i32, !dbg !810
  %1894 = icmp eq i32 %1893, 13, !dbg !810
  br i1 %1894, label %1895, label %1897, !dbg !810

1895:                                             ; preds = %1891
  %1896 = load ptr, ptr %88, align 8, !dbg !810
  br label %1914, !dbg !810

1897:                                             ; preds = %1891
  %1898 = load i8, ptr %229, align 1, !dbg !810
  %1899 = zext i8 %1898 to i32, !dbg !810
  %1900 = icmp eq i32 %1899, 14, !dbg !810
  br i1 %1900, label %1901, label %1903, !dbg !810

1901:                                             ; preds = %1897
  %1902 = load ptr, ptr %92, align 8, !dbg !810
  br label %1912, !dbg !810

1903:                                             ; preds = %1897
  %1904 = load i8, ptr %229, align 1, !dbg !810
  %1905 = zext i8 %1904 to i32, !dbg !810
  %1906 = icmp eq i32 %1905, 15, !dbg !810
  br i1 %1906, label %1907, label %1909, !dbg !810

1907:                                             ; preds = %1903
  %1908 = load ptr, ptr %96, align 8, !dbg !810
  br label %1910, !dbg !810

1909:                                             ; preds = %1903
  br label %1910, !dbg !810

1910:                                             ; preds = %1909, %1907
  %1911 = phi ptr [ %1908, %1907 ], [ null, %1909 ], !dbg !810
  br label %1912, !dbg !810

1912:                                             ; preds = %1910, %1901
  %1913 = phi ptr [ %1902, %1901 ], [ %1911, %1910 ], !dbg !810
  br label %1914, !dbg !810

1914:                                             ; preds = %1912, %1895
  %1915 = phi ptr [ %1896, %1895 ], [ %1913, %1912 ], !dbg !810
  br label %1916, !dbg !810

1916:                                             ; preds = %1914, %1889
  %1917 = phi ptr [ %1890, %1889 ], [ %1915, %1914 ], !dbg !810
  br label %1918, !dbg !810

1918:                                             ; preds = %1916, %1883
  %1919 = phi ptr [ %1884, %1883 ], [ %1917, %1916 ], !dbg !810
  br label %1920, !dbg !810

1920:                                             ; preds = %1918, %1877
  %1921 = phi ptr [ %1878, %1877 ], [ %1919, %1918 ], !dbg !810
  br label %1922, !dbg !810

1922:                                             ; preds = %1920, %1871
  %1923 = phi ptr [ %1872, %1871 ], [ %1921, %1920 ], !dbg !810
  br label %1924, !dbg !810

1924:                                             ; preds = %1922, %1865
  %1925 = phi ptr [ %1866, %1865 ], [ %1923, %1922 ], !dbg !810
  br label %1926, !dbg !810

1926:                                             ; preds = %1924, %1859
  %1927 = phi ptr [ %1860, %1859 ], [ %1925, %1924 ], !dbg !810
  br label %1928, !dbg !810

1928:                                             ; preds = %1926, %1853
  %1929 = phi ptr [ %1854, %1853 ], [ %1927, %1926 ], !dbg !810
  br label %1930, !dbg !810

1930:                                             ; preds = %1928, %1847
  %1931 = phi ptr [ %1848, %1847 ], [ %1929, %1928 ], !dbg !810
  br label %1932, !dbg !810

1932:                                             ; preds = %1930, %1841
  %1933 = phi ptr [ %1842, %1841 ], [ %1931, %1930 ], !dbg !810
  br label %1934, !dbg !810

1934:                                             ; preds = %1932, %1835
  %1935 = phi ptr [ %1836, %1835 ], [ %1933, %1932 ], !dbg !810
  br label %1936, !dbg !810

1936:                                             ; preds = %1934, %1829
  %1937 = phi ptr [ %1830, %1829 ], [ %1935, %1934 ], !dbg !810
  br label %1938, !dbg !810

1938:                                             ; preds = %1936, %1823
  %1939 = phi ptr [ %1824, %1823 ], [ %1937, %1936 ], !dbg !810
  br label %1940, !dbg !810

1940:                                             ; preds = %1938, %1817
  %1941 = phi ptr [ %1818, %1817 ], [ %1939, %1938 ], !dbg !810
  store ptr %1941, ptr %233, align 8, !dbg !810
  call void @llvm.dbg.declare(metadata ptr %234, metadata !818, metadata !DIExpression()), !dbg !810
  %1942 = load ptr, ptr %233, align 8, !dbg !810
  %1943 = ptrtoint ptr %1942 to i64, !dbg !810
  store i64 %1943, ptr %234, align 8, !dbg !810
  %1944 = load i8, ptr %229, align 1, !dbg !819
  %1945 = zext i8 %1944 to i32, !dbg !819
  %1946 = icmp eq i32 %1945, 4, !dbg !819
  br i1 %1946, label %1947, label %1951, !dbg !810

1947:                                             ; preds = %1940
  %1948 = load i64, ptr %100, align 8, !dbg !819
  %1949 = load i64, ptr %234, align 8, !dbg !819
  %1950 = add i64 %1949, %1948, !dbg !819
  store i64 %1950, ptr %234, align 8, !dbg !819
  br label %2008, !dbg !819

1951:                                             ; preds = %1940
  call void @llvm.dbg.declare(metadata ptr %235, metadata !821, metadata !DIExpression()), !dbg !824
  store i8 0, ptr %235, align 1, !dbg !824
  %1952 = load i8, ptr %229, align 1, !dbg !824
  %1953 = zext i8 %1952 to i32, !dbg !824
  switch i32 %1953, label %1986 [
    i32 0, label %1954
    i32 1, label %1956
    i32 2, label %1958
    i32 3, label %1960
    i32 4, label %1962
    i32 5, label %1964
    i32 6, label %1966
    i32 7, label %1968
    i32 8, label %1970
    i32 9, label %1972
    i32 10, label %1974
    i32 11, label %1976
    i32 12, label %1978
    i32 13, label %1980
    i32 14, label %1982
    i32 15, label %1984
  ], !dbg !824

1954:                                             ; preds = %1951
  %1955 = load i8, ptr %41, align 1, !dbg !825
  store i8 %1955, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1956:                                             ; preds = %1951
  %1957 = load i8, ptr %45, align 1, !dbg !825
  store i8 %1957, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1958:                                             ; preds = %1951
  %1959 = load i8, ptr %49, align 1, !dbg !825
  store i8 %1959, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1960:                                             ; preds = %1951
  %1961 = load i8, ptr %53, align 1, !dbg !825
  store i8 %1961, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1962:                                             ; preds = %1951
  %1963 = load i8, ptr %55, align 1, !dbg !825
  store i8 %1963, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1964:                                             ; preds = %1951
  %1965 = load i8, ptr %59, align 1, !dbg !825
  store i8 %1965, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1966:                                             ; preds = %1951
  %1967 = load i8, ptr %63, align 1, !dbg !825
  store i8 %1967, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1968:                                             ; preds = %1951
  %1969 = load i8, ptr %67, align 1, !dbg !825
  store i8 %1969, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1970:                                             ; preds = %1951
  %1971 = load i8, ptr %71, align 1, !dbg !825
  store i8 %1971, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1972:                                             ; preds = %1951
  %1973 = load i8, ptr %75, align 1, !dbg !825
  store i8 %1973, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1974:                                             ; preds = %1951
  %1975 = load i8, ptr %79, align 1, !dbg !825
  store i8 %1975, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1976:                                             ; preds = %1951
  %1977 = load i8, ptr %83, align 1, !dbg !825
  store i8 %1977, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1978:                                             ; preds = %1951
  %1979 = load i8, ptr %87, align 1, !dbg !825
  store i8 %1979, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1980:                                             ; preds = %1951
  %1981 = load i8, ptr %91, align 1, !dbg !825
  store i8 %1981, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1982:                                             ; preds = %1951
  %1983 = load i8, ptr %95, align 1, !dbg !825
  store i8 %1983, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1984:                                             ; preds = %1951
  %1985 = load i8, ptr %99, align 1, !dbg !825
  store i8 %1985, ptr %235, align 1, !dbg !825
  br label %1987, !dbg !825

1986:                                             ; preds = %1951
  br label %1987, !dbg !825

1987:                                             ; preds = %1986, %1984, %1982, %1980, %1978, %1976, %1974, %1972, %1970, %1968, %1966, %1964, %1962, %1960, %1958, %1956, %1954
  %1988 = load i8, ptr %235, align 1, !dbg !824
  store i8 %1988, ptr %236, align 1, !dbg !825
  %1989 = load i8, ptr %236, align 1, !dbg !824
  %1990 = zext i8 %1989 to i32, !dbg !827
  %1991 = icmp eq i32 %1990, 4, !dbg !827
  br i1 %1991, label %1992, label %2007, !dbg !819

1992:                                             ; preds = %1987
  call void @llvm.dbg.declare(metadata ptr %237, metadata !828, metadata !DIExpression()), !dbg !830
  %1993 = load ptr, ptr %233, align 8, !dbg !830
  %1994 = ptrtoint ptr %1993 to i64, !dbg !830
  %1995 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !830
  %1996 = ptrtoint ptr %1995 to i64, !dbg !830
  %1997 = add i64 %1996, 1, !dbg !830
  %1998 = inttoptr i64 %1997 to ptr, !dbg !830
  %1999 = ptrtoint ptr %1998 to i64, !dbg !830
  %2000 = sub i64 %1994, %1999, !dbg !830
  store i64 %2000, ptr %237, align 8, !dbg !830
  %2001 = load i64, ptr %237, align 8, !dbg !830
  %2002 = call i64 asm sideeffect "", "=r,0"(i64 %2001) #5, !dbg !830, !srcloc !831
  store i64 %2002, ptr %237, align 8, !dbg !830
  %2003 = load i64, ptr %237, align 8, !dbg !830
  %2004 = load i64, ptr %100, align 8, !dbg !830
  %2005 = add i64 %2003, %2004, !dbg !830
  store i64 %2005, ptr %238, align 8, !dbg !830
  %2006 = load i64, ptr %238, align 8, !dbg !830
  store i64 %2006, ptr %234, align 8, !dbg !827
  br label %2007, !dbg !827

2007:                                             ; preds = %1992, %1987
  br label %2008

2008:                                             ; preds = %2007, %1947
  %2009 = load i64, ptr %234, align 8, !dbg !810
  %2010 = load i8, ptr %231, align 1, !dbg !810
  %2011 = zext i8 %2010 to i32, !dbg !810
  %2012 = icmp eq i32 %2011, 1, !dbg !810
  br i1 %2012, label %2013, label %2016, !dbg !810

2013:                                             ; preds = %2008
  %2014 = load i8, ptr %232, align 1, !dbg !810
  %2015 = zext i8 %2014 to i32, !dbg !810
  br label %2017, !dbg !810

2016:                                             ; preds = %2008
  br label %2017, !dbg !810

2017:                                             ; preds = %2016, %2013
  %2018 = phi i32 [ %2015, %2013 ], [ 0, %2016 ], !dbg !810
  %2019 = zext i32 %2018 to i64, !dbg !810
  %2020 = lshr i64 %2009, %2019, !dbg !810
  %2021 = load i8, ptr %231, align 1, !dbg !810
  %2022 = zext i8 %2021 to i32, !dbg !810
  %2023 = icmp eq i32 %2022, 1, !dbg !810
  br i1 %2023, label %2024, label %2025, !dbg !810

2024:                                             ; preds = %2017
  br label %2038, !dbg !810

2025:                                             ; preds = %2017
  %2026 = load i8, ptr %231, align 1, !dbg !810
  %2027 = zext i8 %2026 to i32, !dbg !810
  %2028 = icmp eq i32 %2027, 2, !dbg !810
  br i1 %2028, label %2029, label %2030, !dbg !810

2029:                                             ; preds = %2025
  br label %2036, !dbg !810

2030:                                             ; preds = %2025
  %2031 = load i8, ptr %231, align 1, !dbg !810
  %2032 = zext i8 %2031 to i32, !dbg !810
  %2033 = icmp eq i32 %2032, 4, !dbg !810
  %2034 = zext i1 %2033 to i64, !dbg !810
  %2035 = select i1 %2033, i64 4294967295, i64 -1, !dbg !810
  br label %2036, !dbg !810

2036:                                             ; preds = %2030, %2029
  %2037 = phi i64 [ 65535, %2029 ], [ %2035, %2030 ], !dbg !810
  br label %2038, !dbg !810

2038:                                             ; preds = %2036, %2024
  %2039 = phi i64 [ 255, %2024 ], [ %2037, %2036 ], !dbg !810
  %2040 = and i64 %2020, %2039, !dbg !810
  store i64 %2040, ptr %239, align 8, !dbg !819
  %2041 = load i64, ptr %239, align 8, !dbg !810
  %2042 = trunc i64 %2041 to i32, !dbg !832
  store i32 %2042, ptr %28, align 4, !dbg !832
  br label %2286, !dbg !832

2043:                                             ; No predecessors!
  br label %2044, !dbg !832

2044:                                             ; preds = %2043
  call void @llvm.dbg.label(metadata !833), !dbg !834
  br label %2045, !dbg !835

2045:                                             ; preds = %2044
  call void @llvm.dbg.declare(metadata ptr %240, metadata !836, metadata !DIExpression()), !dbg !839
  store i8 0, ptr %240, align 1, !dbg !839
  call void @llvm.dbg.declare(metadata ptr %241, metadata !840, metadata !DIExpression()), !dbg !839
  store i8 8, ptr %241, align 1, !dbg !839
  call void @llvm.dbg.declare(metadata ptr %242, metadata !841, metadata !DIExpression()), !dbg !839
  %2046 = load i8, ptr %241, align 1, !dbg !839
  store i8 %2046, ptr %14, align 1
  call void @llvm.dbg.declare(metadata ptr %14, metadata !531, metadata !DIExpression()), !dbg !842
  %2047 = load i8, ptr %14, align 1, !dbg !844
  %2048 = zext i8 %2047 to i32, !dbg !844
  %2049 = icmp ne i32 %2048, 0, !dbg !844
  br i1 %2049, label %2050, label %2053, !dbg !844

2050:                                             ; preds = %2045
  %2051 = load i8, ptr %14, align 1, !dbg !844
  %2052 = zext i8 %2051 to i32, !dbg !844
  br label %2054, !dbg !844

2053:                                             ; preds = %2045
  br label %2054, !dbg !844

2054:                                             ; preds = %2050, %2053
  %2055 = phi i32 [ %2052, %2050 ], [ 8, %2053 ], !dbg !844
  %2056 = trunc i32 %2055 to i8, !dbg !844
  store i8 %2056, ptr %242, align 1, !dbg !839
  call void @llvm.dbg.declare(metadata ptr %243, metadata !845, metadata !DIExpression()), !dbg !839
  store i8 0, ptr %243, align 1, !dbg !839
  call void @llvm.dbg.declare(metadata ptr %244, metadata !846, metadata !DIExpression()), !dbg !839
  %2057 = load i8, ptr %240, align 1, !dbg !839
  %2058 = zext i8 %2057 to i32, !dbg !839
  %2059 = icmp eq i32 %2058, 0, !dbg !839
  br i1 %2059, label %2060, label %2062, !dbg !839

2060:                                             ; preds = %2054
  %2061 = load ptr, ptr %38, align 8, !dbg !839
  br label %2183, !dbg !839

2062:                                             ; preds = %2054
  %2063 = load i8, ptr %240, align 1, !dbg !839
  %2064 = zext i8 %2063 to i32, !dbg !839
  %2065 = icmp eq i32 %2064, 1, !dbg !839
  br i1 %2065, label %2066, label %2068, !dbg !839

2066:                                             ; preds = %2062
  %2067 = load ptr, ptr %42, align 8, !dbg !839
  br label %2181, !dbg !839

2068:                                             ; preds = %2062
  %2069 = load i8, ptr %240, align 1, !dbg !839
  %2070 = zext i8 %2069 to i32, !dbg !839
  %2071 = icmp eq i32 %2070, 2, !dbg !839
  br i1 %2071, label %2072, label %2074, !dbg !839

2072:                                             ; preds = %2068
  %2073 = load ptr, ptr %46, align 8, !dbg !839
  br label %2179, !dbg !839

2074:                                             ; preds = %2068
  %2075 = load i8, ptr %240, align 1, !dbg !839
  %2076 = zext i8 %2075 to i32, !dbg !839
  %2077 = icmp eq i32 %2076, 3, !dbg !839
  br i1 %2077, label %2078, label %2080, !dbg !839

2078:                                             ; preds = %2074
  %2079 = load ptr, ptr %50, align 8, !dbg !839
  br label %2177, !dbg !839

2080:                                             ; preds = %2074
  %2081 = load i8, ptr %240, align 1, !dbg !839
  %2082 = zext i8 %2081 to i32, !dbg !839
  %2083 = icmp eq i32 %2082, 4, !dbg !839
  br i1 %2083, label %2084, label %2086, !dbg !839

2084:                                             ; preds = %2080
  %2085 = load ptr, ptr %54, align 8, !dbg !839
  br label %2175, !dbg !839

2086:                                             ; preds = %2080
  %2087 = load i8, ptr %240, align 1, !dbg !839
  %2088 = zext i8 %2087 to i32, !dbg !839
  %2089 = icmp eq i32 %2088, 5, !dbg !839
  br i1 %2089, label %2090, label %2092, !dbg !839

2090:                                             ; preds = %2086
  %2091 = load ptr, ptr %56, align 8, !dbg !839
  br label %2173, !dbg !839

2092:                                             ; preds = %2086
  %2093 = load i8, ptr %240, align 1, !dbg !839
  %2094 = zext i8 %2093 to i32, !dbg !839
  %2095 = icmp eq i32 %2094, 6, !dbg !839
  br i1 %2095, label %2096, label %2098, !dbg !839

2096:                                             ; preds = %2092
  %2097 = load ptr, ptr %60, align 8, !dbg !839
  br label %2171, !dbg !839

2098:                                             ; preds = %2092
  %2099 = load i8, ptr %240, align 1, !dbg !839
  %2100 = zext i8 %2099 to i32, !dbg !839
  %2101 = icmp eq i32 %2100, 7, !dbg !839
  br i1 %2101, label %2102, label %2104, !dbg !839

2102:                                             ; preds = %2098
  %2103 = load ptr, ptr %64, align 8, !dbg !839
  br label %2169, !dbg !839

2104:                                             ; preds = %2098
  %2105 = load i8, ptr %240, align 1, !dbg !839
  %2106 = zext i8 %2105 to i32, !dbg !839
  %2107 = icmp eq i32 %2106, 8, !dbg !839
  br i1 %2107, label %2108, label %2110, !dbg !839

2108:                                             ; preds = %2104
  %2109 = load ptr, ptr %68, align 8, !dbg !839
  br label %2167, !dbg !839

2110:                                             ; preds = %2104
  %2111 = load i8, ptr %240, align 1, !dbg !839
  %2112 = zext i8 %2111 to i32, !dbg !839
  %2113 = icmp eq i32 %2112, 9, !dbg !839
  br i1 %2113, label %2114, label %2116, !dbg !839

2114:                                             ; preds = %2110
  %2115 = load ptr, ptr %72, align 8, !dbg !839
  br label %2165, !dbg !839

2116:                                             ; preds = %2110
  %2117 = load i8, ptr %240, align 1, !dbg !839
  %2118 = zext i8 %2117 to i32, !dbg !839
  %2119 = icmp eq i32 %2118, 10, !dbg !839
  br i1 %2119, label %2120, label %2122, !dbg !839

2120:                                             ; preds = %2116
  %2121 = load ptr, ptr %76, align 8, !dbg !839
  br label %2163, !dbg !839

2122:                                             ; preds = %2116
  %2123 = load i8, ptr %240, align 1, !dbg !839
  %2124 = zext i8 %2123 to i32, !dbg !839
  %2125 = icmp eq i32 %2124, 11, !dbg !839
  br i1 %2125, label %2126, label %2128, !dbg !839

2126:                                             ; preds = %2122
  %2127 = load ptr, ptr %80, align 8, !dbg !839
  br label %2161, !dbg !839

2128:                                             ; preds = %2122
  %2129 = load i8, ptr %240, align 1, !dbg !839
  %2130 = zext i8 %2129 to i32, !dbg !839
  %2131 = icmp eq i32 %2130, 12, !dbg !839
  br i1 %2131, label %2132, label %2134, !dbg !839

2132:                                             ; preds = %2128
  %2133 = load ptr, ptr %84, align 8, !dbg !839
  br label %2159, !dbg !839

2134:                                             ; preds = %2128
  %2135 = load i8, ptr %240, align 1, !dbg !839
  %2136 = zext i8 %2135 to i32, !dbg !839
  %2137 = icmp eq i32 %2136, 13, !dbg !839
  br i1 %2137, label %2138, label %2140, !dbg !839

2138:                                             ; preds = %2134
  %2139 = load ptr, ptr %88, align 8, !dbg !839
  br label %2157, !dbg !839

2140:                                             ; preds = %2134
  %2141 = load i8, ptr %240, align 1, !dbg !839
  %2142 = zext i8 %2141 to i32, !dbg !839
  %2143 = icmp eq i32 %2142, 14, !dbg !839
  br i1 %2143, label %2144, label %2146, !dbg !839

2144:                                             ; preds = %2140
  %2145 = load ptr, ptr %92, align 8, !dbg !839
  br label %2155, !dbg !839

2146:                                             ; preds = %2140
  %2147 = load i8, ptr %240, align 1, !dbg !839
  %2148 = zext i8 %2147 to i32, !dbg !839
  %2149 = icmp eq i32 %2148, 15, !dbg !839
  br i1 %2149, label %2150, label %2152, !dbg !839

2150:                                             ; preds = %2146
  %2151 = load ptr, ptr %96, align 8, !dbg !839
  br label %2153, !dbg !839

2152:                                             ; preds = %2146
  br label %2153, !dbg !839

2153:                                             ; preds = %2152, %2150
  %2154 = phi ptr [ %2151, %2150 ], [ null, %2152 ], !dbg !839
  br label %2155, !dbg !839

2155:                                             ; preds = %2153, %2144
  %2156 = phi ptr [ %2145, %2144 ], [ %2154, %2153 ], !dbg !839
  br label %2157, !dbg !839

2157:                                             ; preds = %2155, %2138
  %2158 = phi ptr [ %2139, %2138 ], [ %2156, %2155 ], !dbg !839
  br label %2159, !dbg !839

2159:                                             ; preds = %2157, %2132
  %2160 = phi ptr [ %2133, %2132 ], [ %2158, %2157 ], !dbg !839
  br label %2161, !dbg !839

2161:                                             ; preds = %2159, %2126
  %2162 = phi ptr [ %2127, %2126 ], [ %2160, %2159 ], !dbg !839
  br label %2163, !dbg !839

2163:                                             ; preds = %2161, %2120
  %2164 = phi ptr [ %2121, %2120 ], [ %2162, %2161 ], !dbg !839
  br label %2165, !dbg !839

2165:                                             ; preds = %2163, %2114
  %2166 = phi ptr [ %2115, %2114 ], [ %2164, %2163 ], !dbg !839
  br label %2167, !dbg !839

2167:                                             ; preds = %2165, %2108
  %2168 = phi ptr [ %2109, %2108 ], [ %2166, %2165 ], !dbg !839
  br label %2169, !dbg !839

2169:                                             ; preds = %2167, %2102
  %2170 = phi ptr [ %2103, %2102 ], [ %2168, %2167 ], !dbg !839
  br label %2171, !dbg !839

2171:                                             ; preds = %2169, %2096
  %2172 = phi ptr [ %2097, %2096 ], [ %2170, %2169 ], !dbg !839
  br label %2173, !dbg !839

2173:                                             ; preds = %2171, %2090
  %2174 = phi ptr [ %2091, %2090 ], [ %2172, %2171 ], !dbg !839
  br label %2175, !dbg !839

2175:                                             ; preds = %2173, %2084
  %2176 = phi ptr [ %2085, %2084 ], [ %2174, %2173 ], !dbg !839
  br label %2177, !dbg !839

2177:                                             ; preds = %2175, %2078
  %2178 = phi ptr [ %2079, %2078 ], [ %2176, %2175 ], !dbg !839
  br label %2179, !dbg !839

2179:                                             ; preds = %2177, %2072
  %2180 = phi ptr [ %2073, %2072 ], [ %2178, %2177 ], !dbg !839
  br label %2181, !dbg !839

2181:                                             ; preds = %2179, %2066
  %2182 = phi ptr [ %2067, %2066 ], [ %2180, %2179 ], !dbg !839
  br label %2183, !dbg !839

2183:                                             ; preds = %2181, %2060
  %2184 = phi ptr [ %2061, %2060 ], [ %2182, %2181 ], !dbg !839
  store ptr %2184, ptr %244, align 8, !dbg !839
  call void @llvm.dbg.declare(metadata ptr %245, metadata !847, metadata !DIExpression()), !dbg !839
  %2185 = load ptr, ptr %244, align 8, !dbg !839
  %2186 = ptrtoint ptr %2185 to i64, !dbg !839
  store i64 %2186, ptr %245, align 8, !dbg !839
  %2187 = load i8, ptr %240, align 1, !dbg !848
  %2188 = zext i8 %2187 to i32, !dbg !848
  %2189 = icmp eq i32 %2188, 4, !dbg !848
  br i1 %2189, label %2190, label %2194, !dbg !839

2190:                                             ; preds = %2183
  %2191 = load i64, ptr %100, align 8, !dbg !848
  %2192 = load i64, ptr %245, align 8, !dbg !848
  %2193 = add i64 %2192, %2191, !dbg !848
  store i64 %2193, ptr %245, align 8, !dbg !848
  br label %2251, !dbg !848

2194:                                             ; preds = %2183
  call void @llvm.dbg.declare(metadata ptr %246, metadata !850, metadata !DIExpression()), !dbg !853
  store i8 0, ptr %246, align 1, !dbg !853
  %2195 = load i8, ptr %240, align 1, !dbg !853
  %2196 = zext i8 %2195 to i32, !dbg !853
  switch i32 %2196, label %2229 [
    i32 0, label %2197
    i32 1, label %2199
    i32 2, label %2201
    i32 3, label %2203
    i32 4, label %2205
    i32 5, label %2207
    i32 6, label %2209
    i32 7, label %2211
    i32 8, label %2213
    i32 9, label %2215
    i32 10, label %2217
    i32 11, label %2219
    i32 12, label %2221
    i32 13, label %2223
    i32 14, label %2225
    i32 15, label %2227
  ], !dbg !853

2197:                                             ; preds = %2194
  %2198 = load i8, ptr %41, align 1, !dbg !854
  store i8 %2198, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2199:                                             ; preds = %2194
  %2200 = load i8, ptr %45, align 1, !dbg !854
  store i8 %2200, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2201:                                             ; preds = %2194
  %2202 = load i8, ptr %49, align 1, !dbg !854
  store i8 %2202, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2203:                                             ; preds = %2194
  %2204 = load i8, ptr %53, align 1, !dbg !854
  store i8 %2204, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2205:                                             ; preds = %2194
  %2206 = load i8, ptr %55, align 1, !dbg !854
  store i8 %2206, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2207:                                             ; preds = %2194
  %2208 = load i8, ptr %59, align 1, !dbg !854
  store i8 %2208, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2209:                                             ; preds = %2194
  %2210 = load i8, ptr %63, align 1, !dbg !854
  store i8 %2210, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2211:                                             ; preds = %2194
  %2212 = load i8, ptr %67, align 1, !dbg !854
  store i8 %2212, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2213:                                             ; preds = %2194
  %2214 = load i8, ptr %71, align 1, !dbg !854
  store i8 %2214, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2215:                                             ; preds = %2194
  %2216 = load i8, ptr %75, align 1, !dbg !854
  store i8 %2216, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2217:                                             ; preds = %2194
  %2218 = load i8, ptr %79, align 1, !dbg !854
  store i8 %2218, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2219:                                             ; preds = %2194
  %2220 = load i8, ptr %83, align 1, !dbg !854
  store i8 %2220, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2221:                                             ; preds = %2194
  %2222 = load i8, ptr %87, align 1, !dbg !854
  store i8 %2222, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2223:                                             ; preds = %2194
  %2224 = load i8, ptr %91, align 1, !dbg !854
  store i8 %2224, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2225:                                             ; preds = %2194
  %2226 = load i8, ptr %95, align 1, !dbg !854
  store i8 %2226, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2227:                                             ; preds = %2194
  %2228 = load i8, ptr %99, align 1, !dbg !854
  store i8 %2228, ptr %246, align 1, !dbg !854
  br label %2230, !dbg !854

2229:                                             ; preds = %2194
  br label %2230, !dbg !854

2230:                                             ; preds = %2229, %2227, %2225, %2223, %2221, %2219, %2217, %2215, %2213, %2211, %2209, %2207, %2205, %2203, %2201, %2199, %2197
  %2231 = load i8, ptr %246, align 1, !dbg !853
  store i8 %2231, ptr %247, align 1, !dbg !854
  %2232 = load i8, ptr %247, align 1, !dbg !853
  %2233 = zext i8 %2232 to i32, !dbg !856
  %2234 = icmp eq i32 %2233, 4, !dbg !856
  br i1 %2234, label %2235, label %2250, !dbg !848

2235:                                             ; preds = %2230
  call void @llvm.dbg.declare(metadata ptr %248, metadata !857, metadata !DIExpression()), !dbg !859
  %2236 = load ptr, ptr %244, align 8, !dbg !859
  %2237 = ptrtoint ptr %2236 to i64, !dbg !859
  %2238 = getelementptr inbounds [1 x i8], ptr %126, i64 0, i64 0, !dbg !859
  %2239 = ptrtoint ptr %2238 to i64, !dbg !859
  %2240 = add i64 %2239, 1, !dbg !859
  %2241 = inttoptr i64 %2240 to ptr, !dbg !859
  %2242 = ptrtoint ptr %2241 to i64, !dbg !859
  %2243 = sub i64 %2237, %2242, !dbg !859
  store i64 %2243, ptr %248, align 8, !dbg !859
  %2244 = load i64, ptr %248, align 8, !dbg !859
  %2245 = call i64 asm sideeffect "", "=r,0"(i64 %2244) #5, !dbg !859, !srcloc !860
  store i64 %2245, ptr %248, align 8, !dbg !859
  %2246 = load i64, ptr %248, align 8, !dbg !859
  %2247 = load i64, ptr %100, align 8, !dbg !859
  %2248 = add i64 %2246, %2247, !dbg !859
  store i64 %2248, ptr %249, align 8, !dbg !859
  %2249 = load i64, ptr %249, align 8, !dbg !859
  store i64 %2249, ptr %245, align 8, !dbg !856
  br label %2250, !dbg !856

2250:                                             ; preds = %2235, %2230
  br label %2251

2251:                                             ; preds = %2250, %2190
  %2252 = load i64, ptr %245, align 8, !dbg !839
  %2253 = load i8, ptr %242, align 1, !dbg !839
  %2254 = zext i8 %2253 to i32, !dbg !839
  %2255 = icmp eq i32 %2254, 1, !dbg !839
  br i1 %2255, label %2256, label %2259, !dbg !839

2256:                                             ; preds = %2251
  %2257 = load i8, ptr %243, align 1, !dbg !839
  %2258 = zext i8 %2257 to i32, !dbg !839
  br label %2260, !dbg !839

2259:                                             ; preds = %2251
  br label %2260, !dbg !839

2260:                                             ; preds = %2259, %2256
  %2261 = phi i32 [ %2258, %2256 ], [ 0, %2259 ], !dbg !839
  %2262 = zext i32 %2261 to i64, !dbg !839
  %2263 = lshr i64 %2252, %2262, !dbg !839
  %2264 = load i8, ptr %242, align 1, !dbg !839
  %2265 = zext i8 %2264 to i32, !dbg !839
  %2266 = icmp eq i32 %2265, 1, !dbg !839
  br i1 %2266, label %2267, label %2268, !dbg !839

2267:                                             ; preds = %2260
  br label %2281, !dbg !839

2268:                                             ; preds = %2260
  %2269 = load i8, ptr %242, align 1, !dbg !839
  %2270 = zext i8 %2269 to i32, !dbg !839
  %2271 = icmp eq i32 %2270, 2, !dbg !839
  br i1 %2271, label %2272, label %2273, !dbg !839

2272:                                             ; preds = %2268
  br label %2279, !dbg !839

2273:                                             ; preds = %2268
  %2274 = load i8, ptr %242, align 1, !dbg !839
  %2275 = zext i8 %2274 to i32, !dbg !839
  %2276 = icmp eq i32 %2275, 4, !dbg !839
  %2277 = zext i1 %2276 to i64, !dbg !839
  %2278 = select i1 %2276, i64 4294967295, i64 -1, !dbg !839
  br label %2279, !dbg !839

2279:                                             ; preds = %2273, %2272
  %2280 = phi i64 [ 65535, %2272 ], [ %2278, %2273 ], !dbg !839
  br label %2281, !dbg !839

2281:                                             ; preds = %2279, %2267
  %2282 = phi i64 [ 255, %2267 ], [ %2280, %2279 ], !dbg !839
  %2283 = and i64 %2263, %2282, !dbg !839
  store i64 %2283, ptr %250, align 8, !dbg !848
  %2284 = load i64, ptr %250, align 8, !dbg !839
  %2285 = trunc i64 %2284 to i32, !dbg !861
  store i32 %2285, ptr %28, align 4, !dbg !861
  br label %2286, !dbg !861

2286:                                             ; preds = %2038, %2281
  %2287 = load i32, ptr %28, align 4, !dbg !862
  ret i32 %2287, !dbg !862
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #1

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i64(i64) #3

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #4

attributes #0 = { noinline nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="v4" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #5 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!126, !127, !128, !129}
!llvm.ident = !{!130}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !123, line: 24, type: !124, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !122, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "2f410a6102e6a32f9f4e10ae67f11082")
!4 = !{!5, !114, !115, !109, !84, !57, !10, !117, !118, !120, !121, !52}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__sk_buff", file: !7, line: 6347, size: 1536, elements: !8)
!7 = !DIFile(filename: "vendor/libbpf/include/uapi/linux/bpf.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "af3577c2b1c2566ad76f1bd2c69dbe37")
!8 = !{!9, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24, !28, !29, !30, !31, !32, !33, !34, !35, !36, !40, !41, !42, !43, !44, !83, !86, !87, !88, !111, !112, !113}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !6, file: !7, line: 6348, baseType: !10, size: 32)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !11, line: 27, baseType: !12)
!11 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "", checksumkind: CSK_MD5, checksum: "b810f270733e106319b67ef512c6246e")
!12 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "pkt_type", scope: !6, file: !7, line: 6349, baseType: !10, size: 32, offset: 32)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !6, file: !7, line: 6350, baseType: !10, size: 32, offset: 64)
!15 = !DIDerivedType(tag: DW_TAG_member, name: "queue_mapping", scope: !6, file: !7, line: 6351, baseType: !10, size: 32, offset: 96)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !6, file: !7, line: 6352, baseType: !10, size: 32, offset: 128)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_present", scope: !6, file: !7, line: 6353, baseType: !10, size: 32, offset: 160)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_tci", scope: !6, file: !7, line: 6354, baseType: !10, size: 32, offset: 192)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_proto", scope: !6, file: !7, line: 6355, baseType: !10, size: 32, offset: 224)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !6, file: !7, line: 6356, baseType: !10, size: 32, offset: 256)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !6, file: !7, line: 6357, baseType: !10, size: 32, offset: 288)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !6, file: !7, line: 6358, baseType: !10, size: 32, offset: 320)
!23 = !DIDerivedType(tag: DW_TAG_member, name: "tc_index", scope: !6, file: !7, line: 6359, baseType: !10, size: 32, offset: 352)
!24 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !6, file: !7, line: 6360, baseType: !25, size: 160, offset: 384)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 160, elements: !26)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "hash", scope: !6, file: !7, line: 6361, baseType: !10, size: 32, offset: 544)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "tc_classid", scope: !6, file: !7, line: 6362, baseType: !10, size: 32, offset: 576)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !6, file: !7, line: 6363, baseType: !10, size: 32, offset: 608)
!31 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !6, file: !7, line: 6364, baseType: !10, size: 32, offset: 640)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !6, file: !7, line: 6365, baseType: !10, size: 32, offset: 672)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !6, file: !7, line: 6368, baseType: !10, size: 32, offset: 704)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip4", scope: !6, file: !7, line: 6369, baseType: !10, size: 32, offset: 736)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip4", scope: !6, file: !7, line: 6370, baseType: !10, size: 32, offset: 768)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip6", scope: !6, file: !7, line: 6371, baseType: !37, size: 128, offset: 800)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 128, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 4)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip6", scope: !6, file: !7, line: 6372, baseType: !37, size: 128, offset: 928)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "remote_port", scope: !6, file: !7, line: 6373, baseType: !10, size: 32, offset: 1056)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "local_port", scope: !6, file: !7, line: 6374, baseType: !10, size: 32, offset: 1088)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !6, file: !7, line: 6377, baseType: !10, size: 32, offset: 1120)
!44 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6378, baseType: !45, size: 64, align: 64, offset: 1152)
!45 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6378, size: 64, align: 64, elements: !46)
!46 = !{!47}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "flow_keys", scope: !45, file: !7, line: 6378, baseType: !48, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_flow_keys", file: !7, line: 7436, size: 448, elements: !50)
!50 = !{!51, !54, !55, !56, !59, !60, !61, !62, !65, !66, !67, !81, !82}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "nhoff", scope: !49, file: !7, line: 7437, baseType: !52, size: 16)
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !11, line: 24, baseType: !53)
!53 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "thoff", scope: !49, file: !7, line: 7438, baseType: !52, size: 16, offset: 16)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "addr_proto", scope: !49, file: !7, line: 7439, baseType: !52, size: 16, offset: 32)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "is_frag", scope: !49, file: !7, line: 7440, baseType: !57, size: 8, offset: 48)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !11, line: 21, baseType: !58)
!58 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "is_first_frag", scope: !49, file: !7, line: 7441, baseType: !57, size: 8, offset: 56)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "is_encap", scope: !49, file: !7, line: 7442, baseType: !57, size: 8, offset: 64)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "ip_proto", scope: !49, file: !7, line: 7443, baseType: !57, size: 8, offset: 72)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "n_proto", scope: !49, file: !7, line: 7444, baseType: !63, size: 16, offset: 80)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !64, line: 32, baseType: !52)
!64 = !DIFile(filename: "/usr/include/linux/types.h", directory: "", checksumkind: CSK_MD5, checksum: "bf9fbc0e8f60927fef9d8917535375a6")
!65 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !49, file: !7, line: 7445, baseType: !63, size: 16, offset: 96)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !49, file: !7, line: 7446, baseType: !63, size: 16, offset: 112)
!67 = !DIDerivedType(tag: DW_TAG_member, scope: !49, file: !7, line: 7447, baseType: !68, size: 256, offset: 128)
!68 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !49, file: !7, line: 7447, size: 256, elements: !69)
!69 = !{!70, !76}
!70 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7448, baseType: !71, size: 64)
!71 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7448, size: 64, elements: !72)
!72 = !{!73, !75}
!73 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !71, file: !7, line: 7449, baseType: !74, size: 32)
!74 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !64, line: 34, baseType: !10)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !71, file: !7, line: 7450, baseType: !74, size: 32, offset: 32)
!76 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7452, baseType: !77, size: 256)
!77 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7452, size: 256, elements: !78)
!78 = !{!79, !80}
!79 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !77, file: !7, line: 7453, baseType: !37, size: 128)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !77, file: !7, line: 7454, baseType: !37, size: 128, offset: 128)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !49, file: !7, line: 7457, baseType: !10, size: 32, offset: 384)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "flow_label", scope: !49, file: !7, line: 7458, baseType: !74, size: 32, offset: 416)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp", scope: !6, file: !7, line: 6379, baseType: !84, size: 64, offset: 1216)
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !11, line: 31, baseType: !85)
!85 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "wire_len", scope: !6, file: !7, line: 6380, baseType: !10, size: 32, offset: 1280)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "gso_segs", scope: !6, file: !7, line: 6381, baseType: !10, size: 32, offset: 1312)
!88 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6382, baseType: !89, size: 64, align: 64, offset: 1344)
!89 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6382, size: 64, align: 64, elements: !90)
!90 = !{!91}
!91 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !89, file: !7, line: 6382, baseType: !92, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !93, size: 64)
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !7, line: 6451, size: 640, elements: !94)
!94 = !{!95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !93, file: !7, line: 6452, baseType: !10, size: 32)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !93, file: !7, line: 6453, baseType: !10, size: 32, offset: 32)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !93, file: !7, line: 6454, baseType: !10, size: 32, offset: 64)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !93, file: !7, line: 6455, baseType: !10, size: 32, offset: 96)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !93, file: !7, line: 6456, baseType: !10, size: 32, offset: 128)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !93, file: !7, line: 6457, baseType: !10, size: 32, offset: 160)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !93, file: !7, line: 6459, baseType: !10, size: 32, offset: 192)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !93, file: !7, line: 6460, baseType: !37, size: 128, offset: 224)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !93, file: !7, line: 6461, baseType: !10, size: 32, offset: 352)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !93, file: !7, line: 6462, baseType: !63, size: 16, offset: 384)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !93, file: !7, line: 6464, baseType: !10, size: 32, offset: 416)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !93, file: !7, line: 6465, baseType: !37, size: 128, offset: 448)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !93, file: !7, line: 6466, baseType: !10, size: 32, offset: 576)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !93, file: !7, line: 6467, baseType: !109, size: 32, offset: 608)
!109 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !11, line: 26, baseType: !110)
!110 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "gso_size", scope: !6, file: !7, line: 6383, baseType: !10, size: 32, offset: 1408)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp_type", scope: !6, file: !7, line: 6384, baseType: !57, size: 8, offset: 1440)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "hwtstamp", scope: !6, file: !7, line: 6386, baseType: !84, size: 64, offset: 1472)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!115 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s64", file: !11, line: 30, baseType: !116)
!116 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!117 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!118 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !119, size: 64)
!119 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !57)
!120 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!121 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!122 = !{!0}
!123 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "2f410a6102e6a32f9f4e10ae67f11082")
!124 = !DICompositeType(tag: DW_TAG_array_type, baseType: !125, size: 32, elements: !38)
!125 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!126 = !{i32 7, !"Dwarf Version", i32 5}
!127 = !{i32 2, !"Debug Info Version", i32 3}
!128 = !{i32 1, !"wchar_size", i32 4}
!129 = !{i32 7, !"frame-pointer", i32 2}
!130 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!131 = distinct !DISubprogram(name: "trusted_x86_x86_sim_xdp", scope: !123, file: !123, line: 7, type: !132, scopeLine: 8, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !143)
!132 = !DISubroutineType(types: !133)
!133 = !{!110, !134}
!134 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !135, size: 64)
!135 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !7, line: 6567, size: 192, elements: !136)
!136 = !{!137, !138, !139, !140, !141, !142}
!137 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !135, file: !7, line: 6568, baseType: !10, size: 32)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !135, file: !7, line: 6569, baseType: !10, size: 32, offset: 32)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !135, file: !7, line: 6570, baseType: !10, size: 32, offset: 64)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !135, file: !7, line: 6572, baseType: !10, size: 32, offset: 96)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !135, file: !7, line: 6573, baseType: !10, size: 32, offset: 128)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !135, file: !7, line: 6575, baseType: !10, size: 32, offset: 160)
!143 = !{}
!144 = !DILocalVariable(name: "ctx", arg: 1, scope: !131, file: !123, line: 7, type: !134)
!145 = !DILocation(line: 7, column: 44, scope: !131)
!146 = !DILocalVariable(name: "__x86_sim_abi", scope: !131, file: !123, line: 9, type: !147)
!147 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_xdp_abi", file: !148, line: 64, size: 320, elements: !149)
!148 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim_local_bpf.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "cdf042bef0d13fcc12d092b7f12f07bf")
!149 = !{!150, !151, !152}
!150 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !147, file: !148, line: 65, baseType: !114, size: 64)
!151 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !147, file: !148, line: 66, baseType: !114, size: 64, offset: 64)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !147, file: !148, line: 67, baseType: !25, size: 160, offset: 128)
!153 = !DILocation(line: 9, column: 2, scope: !131)
!154 = !DILocalVariable(name: "__x86_sim_skb_ctx", scope: !131, file: !123, line: 9, type: !5)
!155 = !DILocalVariable(name: "__x86_sim_abi_kind", scope: !131, file: !123, line: 9, type: !57)
!156 = !DILocalVariable(name: "__x86_stack_value_tag_0", scope: !131, file: !123, line: 9, type: !57)
!157 = !DILocalVariable(name: "__x86_stack_value_ptr_0", scope: !131, file: !123, line: 9, type: !114)
!158 = !DILocalVariable(name: "__x86_sim_is_xdp", scope: !131, file: !123, line: 9, type: !57)
!159 = !DILocalVariable(name: "__x86_sim_helper_ctx", scope: !131, file: !123, line: 9, type: !114)
!160 = !DILocalVariable(name: "__x86_sim_helper_abi_base", scope: !131, file: !123, line: 9, type: !114)
!161 = !DILocalVariable(name: "__x86_rax", scope: !131, file: !123, line: 9, type: !162)
!162 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_gpr", file: !148, line: 90, size: 64, elements: !163)
!163 = !{!164, !165, !166}
!164 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !162, file: !148, line: 91, baseType: !114, size: 64)
!165 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !162, file: !148, line: 92, baseType: !52, size: 16)
!166 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !162, file: !148, line: 93, baseType: !167, size: 64)
!167 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 64, elements: !168)
!168 = !{!169}
!169 = !DISubrange(count: 8)
!170 = !DILocalVariable(name: "__native_value", scope: !171, file: !123, line: 9, type: !121)
!171 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!172 = !DILocation(line: 9, column: 2, scope: !171)
!173 = !{i64 2148856509}
!174 = !DILocalVariable(name: "__x86_rax_tag", scope: !131, file: !123, line: 9, type: !57)
!175 = !DILocalVariable(name: "__x86_rcx", scope: !131, file: !123, line: 9, type: !162)
!176 = !DILocalVariable(name: "__native_value", scope: !177, file: !123, line: 9, type: !121)
!177 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!178 = !DILocation(line: 9, column: 2, scope: !177)
!179 = !{i64 2148856977}
!180 = !DILocalVariable(name: "__x86_rcx_tag", scope: !131, file: !123, line: 9, type: !57)
!181 = !DILocalVariable(name: "__x86_rdx", scope: !131, file: !123, line: 9, type: !162)
!182 = !DILocalVariable(name: "__native_value", scope: !183, file: !123, line: 9, type: !121)
!183 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!184 = !DILocation(line: 9, column: 2, scope: !183)
!185 = !{i64 2148857445}
!186 = !DILocalVariable(name: "__x86_rdx_tag", scope: !131, file: !123, line: 9, type: !57)
!187 = !DILocalVariable(name: "__x86_rbx", scope: !131, file: !123, line: 9, type: !162)
!188 = !DILocalVariable(name: "__native_value", scope: !189, file: !123, line: 9, type: !121)
!189 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!190 = !DILocation(line: 9, column: 2, scope: !189)
!191 = !{i64 2148857913}
!192 = !DILocalVariable(name: "__x86_rbx_tag", scope: !131, file: !123, line: 9, type: !57)
!193 = !DILocalVariable(name: "__x86_rsp", scope: !131, file: !123, line: 9, type: !162)
!194 = !DILocalVariable(name: "__x86_rsp_tag", scope: !131, file: !123, line: 9, type: !57)
!195 = !DILocalVariable(name: "__x86_rbp", scope: !131, file: !123, line: 9, type: !162)
!196 = !DILocalVariable(name: "__native_value", scope: !197, file: !123, line: 9, type: !121)
!197 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!198 = !DILocation(line: 9, column: 2, scope: !197)
!199 = !{i64 2148858849}
!200 = !DILocalVariable(name: "__x86_rbp_tag", scope: !131, file: !123, line: 9, type: !57)
!201 = !DILocalVariable(name: "__x86_rsi", scope: !131, file: !123, line: 9, type: !162)
!202 = !DILocalVariable(name: "__native_value", scope: !203, file: !123, line: 9, type: !121)
!203 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!204 = !DILocation(line: 9, column: 2, scope: !203)
!205 = !{i64 2148859317}
!206 = !DILocalVariable(name: "__x86_rsi_tag", scope: !131, file: !123, line: 9, type: !57)
!207 = !DILocalVariable(name: "__x86_rdi", scope: !131, file: !123, line: 9, type: !162)
!208 = !DILocalVariable(name: "__native_value", scope: !209, file: !123, line: 9, type: !121)
!209 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!210 = !DILocation(line: 9, column: 2, scope: !209)
!211 = !{i64 2148859785}
!212 = !DILocalVariable(name: "__x86_rdi_tag", scope: !131, file: !123, line: 9, type: !57)
!213 = !DILocalVariable(name: "__x86_r8", scope: !131, file: !123, line: 9, type: !162)
!214 = !DILocalVariable(name: "__native_value", scope: !215, file: !123, line: 9, type: !121)
!215 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!216 = !DILocation(line: 9, column: 2, scope: !215)
!217 = !{i64 2148860250}
!218 = !DILocalVariable(name: "__x86_r8_tag", scope: !131, file: !123, line: 9, type: !57)
!219 = !DILocalVariable(name: "__x86_r9", scope: !131, file: !123, line: 9, type: !162)
!220 = !DILocalVariable(name: "__native_value", scope: !221, file: !123, line: 9, type: !121)
!221 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!222 = !DILocation(line: 9, column: 2, scope: !221)
!223 = !{i64 2148860714}
!224 = !DILocalVariable(name: "__x86_r9_tag", scope: !131, file: !123, line: 9, type: !57)
!225 = !DILocalVariable(name: "__x86_r10", scope: !131, file: !123, line: 9, type: !162)
!226 = !DILocalVariable(name: "__native_value", scope: !227, file: !123, line: 9, type: !121)
!227 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!228 = !DILocation(line: 9, column: 2, scope: !227)
!229 = !{i64 2148861183}
!230 = !DILocalVariable(name: "__x86_r10_tag", scope: !131, file: !123, line: 9, type: !57)
!231 = !DILocalVariable(name: "__x86_r11", scope: !131, file: !123, line: 9, type: !162)
!232 = !DILocalVariable(name: "__native_value", scope: !233, file: !123, line: 9, type: !121)
!233 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!234 = !DILocation(line: 9, column: 2, scope: !233)
!235 = !{i64 2148861653}
!236 = !DILocalVariable(name: "__x86_r11_tag", scope: !131, file: !123, line: 9, type: !57)
!237 = !DILocalVariable(name: "__x86_r12", scope: !131, file: !123, line: 9, type: !162)
!238 = !DILocalVariable(name: "__native_value", scope: !239, file: !123, line: 9, type: !121)
!239 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!240 = !DILocation(line: 9, column: 2, scope: !239)
!241 = !{i64 2148862123}
!242 = !DILocalVariable(name: "__x86_r12_tag", scope: !131, file: !123, line: 9, type: !57)
!243 = !DILocalVariable(name: "__x86_r13", scope: !131, file: !123, line: 9, type: !162)
!244 = !DILocalVariable(name: "__native_value", scope: !245, file: !123, line: 9, type: !121)
!245 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!246 = !DILocation(line: 9, column: 2, scope: !245)
!247 = !{i64 2148862593}
!248 = !DILocalVariable(name: "__x86_r13_tag", scope: !131, file: !123, line: 9, type: !57)
!249 = !DILocalVariable(name: "__x86_r14", scope: !131, file: !123, line: 9, type: !162)
!250 = !DILocalVariable(name: "__native_value", scope: !251, file: !123, line: 9, type: !121)
!251 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!252 = !DILocation(line: 9, column: 2, scope: !251)
!253 = !{i64 2148863063}
!254 = !DILocalVariable(name: "__x86_r14_tag", scope: !131, file: !123, line: 9, type: !57)
!255 = !DILocalVariable(name: "__x86_r15", scope: !131, file: !123, line: 9, type: !162)
!256 = !DILocalVariable(name: "__native_value", scope: !257, file: !123, line: 9, type: !121)
!257 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!258 = !DILocation(line: 9, column: 2, scope: !257)
!259 = !{i64 2148863533}
!260 = !DILocalVariable(name: "__x86_r15_tag", scope: !131, file: !123, line: 9, type: !57)
!261 = !DILocalVariable(name: "__x86_native_stack_base", scope: !131, file: !123, line: 9, type: !84)
!262 = !DILocalVariable(name: "__x86_cf", scope: !131, file: !123, line: 9, type: !57)
!263 = !DILocalVariable(name: "__native_value", scope: !264, file: !123, line: 9, type: !121)
!264 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!265 = !DILocation(line: 9, column: 2, scope: !264)
!266 = !{i64 2148863804}
!267 = !DILocalVariable(name: "__x86_zf", scope: !131, file: !123, line: 9, type: !57)
!268 = !DILocalVariable(name: "__native_value", scope: !269, file: !123, line: 9, type: !121)
!269 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!270 = !DILocation(line: 9, column: 2, scope: !269)
!271 = !{i64 2148864058}
!272 = !DILocalVariable(name: "__x86_sf", scope: !131, file: !123, line: 9, type: !57)
!273 = !DILocalVariable(name: "__native_value", scope: !274, file: !123, line: 9, type: !121)
!274 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!275 = !DILocation(line: 9, column: 2, scope: !274)
!276 = !{i64 2148864312}
!277 = !DILocalVariable(name: "__x86_of", scope: !131, file: !123, line: 9, type: !57)
!278 = !DILocalVariable(name: "__native_value", scope: !279, file: !123, line: 9, type: !121)
!279 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!280 = !DILocation(line: 9, column: 2, scope: !279)
!281 = !{i64 2148864566}
!282 = !DILocalVariable(name: "__x86_pf", scope: !131, file: !123, line: 9, type: !57)
!283 = !DILocalVariable(name: "__native_value", scope: !284, file: !123, line: 9, type: !121)
!284 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!285 = !DILocation(line: 9, column: 2, scope: !284)
!286 = !{i64 2148864820}
!287 = !DILocalVariable(name: "__x86_af", scope: !131, file: !123, line: 9, type: !57)
!288 = !DILocalVariable(name: "__native_value", scope: !289, file: !123, line: 9, type: !121)
!289 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!290 = !DILocation(line: 9, column: 2, scope: !289)
!291 = !{i64 2148865074}
!292 = !DILocalVariable(name: "__x86_xmm0_lo", scope: !131, file: !123, line: 9, type: !84)
!293 = !DILocalVariable(name: "__native_value", scope: !294, file: !123, line: 9, type: !121)
!294 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!295 = !DILocation(line: 9, column: 2, scope: !294)
!296 = !{i64 2148865328}
!297 = !DILocalVariable(name: "__x86_xmm0_hi", scope: !131, file: !123, line: 9, type: !84)
!298 = !DILocalVariable(name: "__native_value", scope: !299, file: !123, line: 9, type: !121)
!299 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!300 = !DILocation(line: 9, column: 2, scope: !299)
!301 = !{i64 2148865582}
!302 = !DILocalVariable(name: "__x86_sim_ret_addr", scope: !131, file: !123, line: 9, type: !84)
!303 = !DILocalVariable(name: "__x86_stack_mem", scope: !131, file: !123, line: 9, type: !304)
!304 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !305)
!305 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !131, file: !123, line: 9, size: 64, elements: !306)
!306 = !{!307, !311}
!307 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !305, file: !123, line: 9, baseType: !308, size: 8)
!308 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 8, elements: !309)
!309 = !{!310}
!310 = !DISubrange(count: 1)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "q", scope: !305, file: !123, line: 9, baseType: !312, size: 64)
!312 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 64, elements: !309)
!313 = !DILocalVariable(name: "__native_value", scope: !314, file: !123, line: 9, type: !121)
!314 = distinct !DILexicalBlock(scope: !131, file: !123, line: 9, column: 2)
!315 = !DILocation(line: 9, column: 2, scope: !314)
!316 = !{i64 2148866054}
!317 = !DILabel(scope: !131, name: "x86_l_0", file: !123, line: 10)
!318 = !DILocation(line: 10, column: 1, scope: !131)
!319 = !DILocation(line: 12, column: 2, scope: !131)
!320 = !DILocalVariable(name: "__x86_l_width", scope: !321, file: !123, line: 12, type: !57)
!321 = distinct !DILexicalBlock(scope: !131, file: !123, line: 12, column: 2)
!322 = !DILocation(line: 12, column: 2, scope: !321)
!323 = !DILocalVariable(name: "__kprog_x86_st_width", scope: !324, file: !123, line: 12, type: !57)
!324 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!325 = !DILocation(line: 12, column: 2, scope: !324)
!326 = !DILocalVariable(name: "__x86_l_disp", scope: !321, file: !123, line: 12, type: !115)
!327 = !DILocalVariable(name: "__kprog_x86_st_disp", scope: !328, file: !123, line: 12, type: !115)
!328 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!329 = !DILocation(line: 12, column: 2, scope: !328)
!330 = !DILocalVariable(name: "__x86_l_base_ptr", scope: !321, file: !123, line: 12, type: !114)
!331 = !DILocalVariable(name: "__x86_l_value", scope: !321, file: !123, line: 12, type: !84)
!332 = !DILocalVariable(name: "__kprog_x86_st_value", scope: !333, file: !123, line: 12, type: !84)
!333 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!334 = !DILocation(line: 12, column: 2, scope: !333)
!335 = !DILocation(line: 0, scope: !333)
!336 = !DILocalVariable(name: "__kprog_x86_st_shifted", scope: !337, file: !123, line: 12, type: !84)
!337 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!338 = !DILocation(line: 12, column: 2, scope: !337)
!339 = !DILocalVariable(name: "__kprog_x86_st_shift", scope: !340, file: !123, line: 12, type: !10)
!340 = distinct !DILexicalBlock(scope: !337, file: !123, line: 12, column: 2)
!341 = !DILocation(line: 12, column: 2, scope: !340)
!342 = !DILocalVariable(name: "__kprog_x86_mo_disp", scope: !343, file: !123, line: 12, type: !115)
!343 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!344 = !DILocation(line: 12, column: 2, scope: !343)
!345 = !DILocalVariable(name: "__kprog_x86_mo_has_index", scope: !343, file: !123, line: 12, type: !110)
!346 = !DILocalVariable(name: "__kprog_x86_mo_result", scope: !343, file: !123, line: 12, type: !84)
!347 = !DILocation(line: 12, column: 2, scope: !348)
!348 = distinct !DILexicalBlock(scope: !343, file: !123, line: 12, column: 2)
!349 = !DILocalVariable(name: "__kprog_x86_mo_scale", scope: !350, file: !123, line: 12, type: !57)
!350 = distinct !DILexicalBlock(scope: !348, file: !123, line: 12, column: 2)
!351 = !DILocation(line: 12, column: 2, scope: !350)
!352 = !DILocalVariable(name: "__kprog_x86_mo_index", scope: !350, file: !123, line: 12, type: !84)
!353 = !DILocalVariable(name: "__x86_l_meta_disp", scope: !321, file: !123, line: 12, type: !115)
!354 = !DILocation(line: 12, column: 2, scope: !355)
!355 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!356 = !DILocation(line: 12, column: 2, scope: !357)
!357 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!358 = !DILocalVariable(name: "__x86_l_tag", scope: !359, file: !123, line: 12, type: !57)
!359 = distinct !DILexicalBlock(scope: !357, file: !123, line: 12, column: 2)
!360 = !DILocation(line: 12, column: 2, scope: !359)
!361 = !DILocalVariable(name: "__x86_sw_width", scope: !362, file: !123, line: 12, type: !57)
!362 = distinct !DILexicalBlock(scope: !357, file: !123, line: 12, column: 2)
!363 = !DILocation(line: 12, column: 2, scope: !362)
!364 = !DILocalVariable(name: "__x86_sw_off", scope: !362, file: !123, line: 12, type: !115)
!365 = !DILocalVariable(name: "__x86_sw_value", scope: !362, file: !123, line: 12, type: !84)
!366 = !DILocalVariable(name: "value", arg: 1, scope: !367, file: !368, line: 221, type: !84)
!367 = distinct !DISubprogram(name: "x86_apply_width", scope: !368, file: !368, line: 221, type: !369, scopeLine: 222, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !143)
!368 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "cedba0dfb15f459a1fb61860887ac4b4")
!369 = !DISubroutineType(types: !370)
!370 = !{!84, !84, !57}
!371 = !DILocation(line: 221, column: 52, scope: !367, inlinedAt: !372)
!372 = distinct !DILocation(line: 12, column: 2, scope: !362)
!373 = !DILocalVariable(name: "width", arg: 2, scope: !367, file: !368, line: 221, type: !57)
!374 = !DILocation(line: 221, column: 64, scope: !367, inlinedAt: !372)
!375 = !DILocation(line: 223, column: 9, scope: !367, inlinedAt: !372)
!376 = !DILocation(line: 12, column: 2, scope: !377)
!377 = distinct !DILexicalBlock(scope: !362, file: !123, line: 12, column: 2)
!378 = !DILocalVariable(name: "__x86_sw_ctx_off", scope: !379, file: !123, line: 12, type: !115)
!379 = distinct !DILexicalBlock(scope: !377, file: !123, line: 12, column: 2)
!380 = !DILocation(line: 12, column: 2, scope: !379)
!381 = !DILocalVariable(name: "__x86_cbw_temp", scope: !382, file: !123, line: 12, type: !84)
!382 = distinct !DILexicalBlock(scope: !379, file: !123, line: 12, column: 2)
!383 = !DILocation(line: 12, column: 2, scope: !382)
!384 = !DILocation(line: 12, column: 2, scope: !385)
!385 = distinct !DILexicalBlock(scope: !382, file: !123, line: 12, column: 2)
!386 = !DILocation(line: 12, column: 2, scope: !387)
!387 = distinct !DILexicalBlock(scope: !388, file: !123, line: 12, column: 2)
!388 = distinct !DILexicalBlock(scope: !385, file: !123, line: 12, column: 2)
!389 = !DILocation(line: 12, column: 2, scope: !388)
!390 = !{i64 2148919728, i64 2148919738, i64 2148919761, i64 2148919771, i64 2148919794, i64 2148919804, i64 2148919827, i64 2148919837, i64 2148919860, i64 2148919870, i64 2148919893, i64 2148919903, i64 2148919926, i64 2148919936, i64 2148919959, i64 2148919969}
!391 = !DILocation(line: 12, column: 2, scope: !392)
!392 = distinct !DILexicalBlock(scope: !387, file: !123, line: 12, column: 2)
!393 = !{i64 2148920226, i64 2148920236, i64 2148920259, i64 2148920269, i64 2148920292, i64 2148920302, i64 2148920325, i64 2148920335}
!394 = !DILocation(line: 12, column: 2, scope: !395)
!395 = distinct !DILexicalBlock(scope: !392, file: !123, line: 12, column: 2)
!396 = !{i64 2148920535, i64 2148920545, i64 2148920568, i64 2148920578}
!397 = !DILocation(line: 12, column: 2, scope: !398)
!398 = distinct !DILexicalBlock(scope: !395, file: !123, line: 12, column: 2)
!399 = !{i64 2148920750, i64 2148920760}
!400 = !DILocalVariable(name: "__x86_cbw_addr", scope: !401, file: !123, line: 12, type: !118)
!401 = distinct !DILexicalBlock(scope: !385, file: !123, line: 12, column: 2)
!402 = !DILocation(line: 12, column: 2, scope: !401)
!403 = !DILocalVariable(name: "__x86_cbw_value", scope: !401, file: !123, line: 12, type: !84)
!404 = !DILocation(line: 12, column: 2, scope: !405)
!405 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!406 = !DILocation(line: 12, column: 2, scope: !407)
!407 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!408 = !DILocation(line: 12, column: 2, scope: !409)
!409 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!410 = !DILocation(line: 12, column: 2, scope: !411)
!411 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!412 = !DILocation(line: 12, column: 2, scope: !413)
!413 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!414 = !DILocation(line: 12, column: 2, scope: !415)
!415 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!416 = !DILocation(line: 12, column: 2, scope: !417)
!417 = distinct !DILexicalBlock(scope: !401, file: !123, line: 12, column: 2)
!418 = !DILocation(line: 12, column: 2, scope: !419)
!419 = distinct !DILexicalBlock(scope: !377, file: !123, line: 12, column: 2)
!420 = !DILocalVariable(name: "__x86_ss_old", scope: !421, file: !123, line: 12, type: !84)
!421 = distinct !DILexicalBlock(scope: !419, file: !123, line: 12, column: 2)
!422 = !DILocation(line: 12, column: 2, scope: !421)
!423 = !DILocalVariable(name: "__x86_sf_value", scope: !424, file: !123, line: 12, type: !84)
!424 = distinct !DILexicalBlock(scope: !421, file: !123, line: 12, column: 2)
!425 = !DILocation(line: 12, column: 2, scope: !424)
!426 = !{i64 2148923302}
!427 = !DILocalVariable(name: "__x86_ss_shift", scope: !421, file: !123, line: 12, type: !84)
!428 = !DILocalVariable(name: "__x86_ss_mask", scope: !421, file: !123, line: 12, type: !84)
!429 = !DILocalVariable(name: "width", arg: 1, scope: !430, file: !368, line: 206, type: !57)
!430 = distinct !DISubprogram(name: "x86_width_mask", scope: !368, file: !368, line: 206, type: !431, scopeLine: 207, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !143)
!431 = !DISubroutineType(types: !432)
!432 = !{!84, !57}
!433 = !DILocation(line: 206, column: 50, scope: !430, inlinedAt: !434)
!434 = distinct !DILocation(line: 12, column: 2, scope: !421)
!435 = !DILocation(line: 208, column: 9, scope: !430, inlinedAt: !434)
!436 = !DILocalVariable(name: "__x86_ss_new", scope: !421, file: !123, line: 12, type: !84)
!437 = !DILocalVariable(name: "__x86_ss_value", scope: !438, file: !123, line: 12, type: !84)
!438 = distinct !DILexicalBlock(scope: !421, file: !123, line: 12, column: 2)
!439 = !DILocation(line: 12, column: 2, scope: !438)
!440 = !{i64 2148923559}
!441 = !DILocation(line: 12, column: 2, scope: !442)
!442 = distinct !DILexicalBlock(scope: !419, file: !123, line: 12, column: 2)
!443 = !DILocalVariable(name: "__x86_ss_old", scope: !444, file: !123, line: 12, type: !84)
!444 = distinct !DILexicalBlock(scope: !442, file: !123, line: 12, column: 2)
!445 = !DILocation(line: 12, column: 2, scope: !444)
!446 = !DILocalVariable(name: "__x86_sf_value", scope: !447, file: !123, line: 12, type: !84)
!447 = distinct !DILexicalBlock(scope: !444, file: !123, line: 12, column: 2)
!448 = !DILocation(line: 12, column: 2, scope: !447)
!449 = !{i64 2148924401}
!450 = !DILocalVariable(name: "__x86_ss_shift", scope: !444, file: !123, line: 12, type: !84)
!451 = !DILocalVariable(name: "__x86_ss_mask", scope: !444, file: !123, line: 12, type: !84)
!452 = !DILocation(line: 206, column: 50, scope: !430, inlinedAt: !453)
!453 = distinct !DILocation(line: 12, column: 2, scope: !444)
!454 = !DILocation(line: 208, column: 9, scope: !430, inlinedAt: !453)
!455 = !DILocalVariable(name: "__x86_ss_new", scope: !444, file: !123, line: 12, type: !84)
!456 = !DILocalVariable(name: "__x86_ss_value", scope: !457, file: !123, line: 12, type: !84)
!457 = distinct !DILexicalBlock(scope: !444, file: !123, line: 12, column: 2)
!458 = !DILocation(line: 12, column: 2, scope: !457)
!459 = !{i64 2148924658}
!460 = !DILocation(line: 12, column: 2, scope: !461)
!461 = distinct !DILexicalBlock(scope: !442, file: !123, line: 12, column: 2)
!462 = !DILocalVariable(name: "__x86_ss_old", scope: !463, file: !123, line: 12, type: !84)
!463 = distinct !DILexicalBlock(scope: !461, file: !123, line: 12, column: 2)
!464 = !DILocation(line: 12, column: 2, scope: !463)
!465 = !DILocalVariable(name: "__x86_sf_value", scope: !466, file: !123, line: 12, type: !84)
!466 = distinct !DILexicalBlock(scope: !463, file: !123, line: 12, column: 2)
!467 = !DILocation(line: 12, column: 2, scope: !466)
!468 = !{i64 2148925492}
!469 = !DILocalVariable(name: "__x86_ss_shift", scope: !463, file: !123, line: 12, type: !84)
!470 = !DILocalVariable(name: "__x86_ss_mask", scope: !463, file: !123, line: 12, type: !84)
!471 = !DILocation(line: 206, column: 50, scope: !430, inlinedAt: !472)
!472 = distinct !DILocation(line: 12, column: 2, scope: !463)
!473 = !DILocation(line: 208, column: 9, scope: !430, inlinedAt: !472)
!474 = !DILocalVariable(name: "__x86_ss_new", scope: !463, file: !123, line: 12, type: !84)
!475 = !DILocalVariable(name: "__x86_ss_value", scope: !476, file: !123, line: 12, type: !84)
!476 = distinct !DILexicalBlock(scope: !463, file: !123, line: 12, column: 2)
!477 = !DILocation(line: 12, column: 2, scope: !476)
!478 = !{i64 2148925745}
!479 = !DILocation(line: 12, column: 2, scope: !480)
!480 = distinct !DILexicalBlock(scope: !461, file: !123, line: 12, column: 2)
!481 = !DILocation(line: 12, column: 2, scope: !482)
!482 = distinct !DILexicalBlock(scope: !480, file: !123, line: 12, column: 2)
!483 = !DILocalVariable(name: "address", arg: 1, scope: !484, file: !485, line: 94, type: !114)
!484 = distinct !DISubprogram(name: "kprog_x86_mem_store", scope: !485, file: !485, line: 94, type: !486, scopeLine: 95, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !143)
!485 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/../formal/generated/x86_mem_access.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "642fcb4f054d60386fcd37ded524589c")
!486 = !DISubroutineType(types: !487)
!487 = !{null, !114, !57, !84}
!488 = !DILocation(line: 94, column: 27, scope: !484, inlinedAt: !489)
!489 = distinct !DILocation(line: 12, column: 2, scope: !480)
!490 = !DILocalVariable(name: "width", arg: 2, scope: !484, file: !485, line: 94, type: !57)
!491 = !DILocation(line: 94, column: 41, scope: !484, inlinedAt: !489)
!492 = !DILocalVariable(name: "value", arg: 3, scope: !484, file: !485, line: 94, type: !84)
!493 = !DILocation(line: 94, column: 54, scope: !484, inlinedAt: !489)
!494 = !DILocation(line: 96, column: 13, scope: !484, inlinedAt: !489)
!495 = !DILocation(line: 96, column: 21, scope: !484, inlinedAt: !489)
!496 = !DILocation(line: 96, column: 5, scope: !484, inlinedAt: !489)
!497 = !DILocation(line: 99, column: 53, scope: !498, inlinedAt: !489)
!498 = distinct !DILexicalBlock(scope: !484, file: !485, line: 96, column: 43)
!499 = !DILocation(line: 99, column: 67, scope: !498, inlinedAt: !489)
!500 = !DILocation(line: 99, column: 9, scope: !498, inlinedAt: !489)
!501 = !{i64 824875}
!502 = !DILocation(line: 103, column: 9, scope: !498, inlinedAt: !489)
!503 = !DILocation(line: 106, column: 54, scope: !498, inlinedAt: !489)
!504 = !DILocation(line: 106, column: 68, scope: !498, inlinedAt: !489)
!505 = !DILocation(line: 106, column: 9, scope: !498, inlinedAt: !489)
!506 = !{i64 825135}
!507 = !DILocation(line: 110, column: 9, scope: !498, inlinedAt: !489)
!508 = !DILocation(line: 113, column: 54, scope: !498, inlinedAt: !489)
!509 = !DILocation(line: 113, column: 68, scope: !498, inlinedAt: !489)
!510 = !DILocation(line: 113, column: 9, scope: !498, inlinedAt: !489)
!511 = !{i64 825398}
!512 = !DILocation(line: 117, column: 9, scope: !498, inlinedAt: !489)
!513 = !DILocation(line: 120, column: 54, scope: !498, inlinedAt: !489)
!514 = !DILocation(line: 120, column: 68, scope: !498, inlinedAt: !489)
!515 = !DILocation(line: 120, column: 9, scope: !498, inlinedAt: !489)
!516 = !{i64 825661}
!517 = !DILocation(line: 124, column: 9, scope: !498, inlinedAt: !489)
!518 = !DILocation(line: 125, column: 14, scope: !498, inlinedAt: !489)
!519 = !DILocation(line: 126, column: 5, scope: !498, inlinedAt: !489)
!520 = !DILocalVariable(name: "__kprog_x86_st_arm", scope: !521, file: !123, line: 12, type: !57)
!521 = distinct !DILexicalBlock(scope: !357, file: !123, line: 12, column: 2)
!522 = !DILocation(line: 12, column: 2, scope: !521)
!523 = !DILocation(line: 12, column: 2, scope: !524)
!524 = distinct !DILexicalBlock(scope: !521, file: !123, line: 12, column: 2)
!525 = !DILocation(line: 12, column: 2, scope: !526)
!526 = distinct !DILexicalBlock(scope: !357, file: !123, line: 12, column: 2)
!527 = !DILocalVariable(name: "__x86_sv_index", scope: !528, file: !123, line: 12, type: !84)
!528 = distinct !DILexicalBlock(scope: !526, file: !123, line: 12, column: 2)
!529 = !DILocation(line: 12, column: 2, scope: !528)
!530 = !DILocalVariable(name: "__x86_sv_width", scope: !528, file: !123, line: 12, type: !84)
!531 = !DILocalVariable(name: "code", arg: 1, scope: !532, file: !368, line: 226, type: !57)
!532 = distinct !DISubprogram(name: "x86_width_effective", scope: !368, file: !368, line: 226, type: !533, scopeLine: 227, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !143)
!533 = !DISubroutineType(types: !534)
!534 = !{!57, !57}
!535 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !536)
!536 = distinct !DILocation(line: 12, column: 2, scope: !528)
!537 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !536)
!538 = !DILocalVariable(name: "__x86_sv_start", scope: !539, file: !123, line: 12, type: !84)
!539 = distinct !DILexicalBlock(scope: !528, file: !123, line: 12, column: 2)
!540 = !DILocation(line: 12, column: 2, scope: !539)
!541 = !DILocation(line: 12, column: 2, scope: !542)
!542 = distinct !DILexicalBlock(scope: !539, file: !123, line: 12, column: 2)
!543 = !DILocalVariable(name: "__x86_stw_index", scope: !544, file: !123, line: 12, type: !84)
!544 = distinct !DILexicalBlock(scope: !526, file: !123, line: 12, column: 2)
!545 = !DILocation(line: 12, column: 2, scope: !544)
!546 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !547)
!547 = distinct !DILocation(line: 12, column: 2, scope: !548)
!548 = distinct !DILexicalBlock(scope: !544, file: !123, line: 12, column: 2)
!549 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !547)
!550 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !551)
!551 = distinct !DILocation(line: 12, column: 2, scope: !548)
!552 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !551)
!553 = !DILocation(line: 12, column: 2, scope: !548)
!554 = !DILocation(line: 0, scope: !548)
!555 = !DILocation(line: 12, column: 2, scope: !556)
!556 = distinct !DILexicalBlock(scope: !548, file: !123, line: 12, column: 2)
!557 = !DILocation(line: 12, column: 2, scope: !558)
!558 = distinct !DILexicalBlock(scope: !548, file: !123, line: 12, column: 2)
!559 = !DILocalVariable(name: "__x86_stw_bytes", scope: !560, file: !123, line: 12, type: !118)
!560 = distinct !DILexicalBlock(scope: !558, file: !123, line: 12, column: 2)
!561 = !DILocation(line: 12, column: 2, scope: !560)
!562 = !DILocalVariable(name: "__x86_stw_width", scope: !560, file: !123, line: 12, type: !57)
!563 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !564)
!564 = distinct !DILocation(line: 12, column: 2, scope: !560)
!565 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !564)
!566 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !567)
!567 = distinct !DILocation(line: 12, column: 2, scope: !560)
!568 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !567)
!569 = !DILocalVariable(name: "__x86_stw_narrowed", scope: !560, file: !123, line: 12, type: !84)
!570 = !DILocation(line: 206, column: 50, scope: !430, inlinedAt: !571)
!571 = distinct !DILocation(line: 12, column: 2, scope: !560)
!572 = !DILocation(line: 208, column: 9, scope: !430, inlinedAt: !571)
!573 = !DILocation(line: 12, column: 2, scope: !574)
!574 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!575 = !DILocation(line: 12, column: 2, scope: !576)
!576 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!577 = !DILocation(line: 12, column: 2, scope: !578)
!578 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!579 = !DILocation(line: 12, column: 2, scope: !580)
!580 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!581 = !DILocation(line: 12, column: 2, scope: !582)
!582 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!583 = !DILocation(line: 12, column: 2, scope: !584)
!584 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!585 = !DILocation(line: 12, column: 2, scope: !586)
!586 = distinct !DILexicalBlock(scope: !560, file: !123, line: 12, column: 2)
!587 = !DILocalVariable(name: "__x86_l_addr", scope: !526, file: !123, line: 12, type: !114)
!588 = !DILocalVariable(name: "__x86_l_tag", scope: !589, file: !123, line: 12, type: !57)
!589 = distinct !DILexicalBlock(scope: !590, file: !123, line: 12, column: 2)
!590 = distinct !DILexicalBlock(scope: !526, file: !123, line: 12, column: 2)
!591 = !DILocation(line: 12, column: 2, scope: !589)
!592 = !DILocation(line: 12, column: 2, scope: !590)
!593 = !DILocalVariable(name: "__x86_sv_index", scope: !594, file: !123, line: 12, type: !84)
!594 = distinct !DILexicalBlock(scope: !590, file: !123, line: 12, column: 2)
!595 = !DILocation(line: 12, column: 2, scope: !594)
!596 = !DILocalVariable(name: "__x86_sv_width", scope: !594, file: !123, line: 12, type: !84)
!597 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !598)
!598 = distinct !DILocation(line: 12, column: 2, scope: !594)
!599 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !598)
!600 = !DILocalVariable(name: "__x86_sv_start", scope: !601, file: !123, line: 12, type: !84)
!601 = distinct !DILexicalBlock(scope: !594, file: !123, line: 12, column: 2)
!602 = !DILocation(line: 12, column: 2, scope: !601)
!603 = !DILocation(line: 12, column: 2, scope: !604)
!604 = distinct !DILexicalBlock(scope: !601, file: !123, line: 12, column: 2)
!605 = !DILocalVariable(name: "__x86_l_tag", scope: !606, file: !123, line: 12, type: !57)
!606 = distinct !DILexicalBlock(scope: !607, file: !123, line: 12, column: 2)
!607 = distinct !DILexicalBlock(scope: !526, file: !123, line: 12, column: 2)
!608 = !DILocation(line: 12, column: 2, scope: !606)
!609 = !DILocation(line: 12, column: 2, scope: !607)
!610 = !DILocalVariable(name: "__x86_stw_bytes", scope: !611, file: !123, line: 12, type: !118)
!611 = distinct !DILexicalBlock(scope: !607, file: !123, line: 12, column: 2)
!612 = !DILocation(line: 12, column: 2, scope: !611)
!613 = !DILocalVariable(name: "__x86_stw_width", scope: !611, file: !123, line: 12, type: !57)
!614 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !615)
!615 = distinct !DILocation(line: 12, column: 2, scope: !611)
!616 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !615)
!617 = !DILocalVariable(name: "__x86_stw_narrowed", scope: !611, file: !123, line: 12, type: !84)
!618 = !DILocation(line: 206, column: 50, scope: !430, inlinedAt: !619)
!619 = distinct !DILocation(line: 12, column: 2, scope: !611)
!620 = !DILocation(line: 208, column: 9, scope: !430, inlinedAt: !619)
!621 = !DILocation(line: 12, column: 2, scope: !622)
!622 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!623 = !DILocation(line: 12, column: 2, scope: !624)
!624 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!625 = !DILocation(line: 12, column: 2, scope: !626)
!626 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!627 = !DILocation(line: 12, column: 2, scope: !628)
!628 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!629 = !DILocation(line: 12, column: 2, scope: !630)
!630 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!631 = !DILocation(line: 12, column: 2, scope: !632)
!632 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!633 = !DILocation(line: 12, column: 2, scope: !634)
!634 = distinct !DILexicalBlock(scope: !611, file: !123, line: 12, column: 2)
!635 = !DILocalVariable(name: "__x86_st_addr", scope: !636, file: !123, line: 12, type: !114)
!636 = distinct !DILexicalBlock(scope: !607, file: !123, line: 12, column: 2)
!637 = !DILocation(line: 12, column: 2, scope: !636)
!638 = !DILocalVariable(name: "__x86_st_width", scope: !636, file: !123, line: 12, type: !57)
!639 = !DILocalVariable(name: "__x86_st_tag", scope: !636, file: !123, line: 12, type: !57)
!640 = !DILocalVariable(name: "__x86_l_tag", scope: !641, file: !123, line: 12, type: !57)
!641 = distinct !DILexicalBlock(scope: !636, file: !123, line: 12, column: 2)
!642 = !DILocation(line: 12, column: 2, scope: !641)
!643 = !DILocalVariable(name: "__x86_st_value", scope: !636, file: !123, line: 12, type: !84)
!644 = !DILocation(line: 12, column: 2, scope: !645)
!645 = distinct !DILexicalBlock(scope: !636, file: !123, line: 12, column: 2)
!646 = !DILocalVariable(name: "__x86_sv_index", scope: !647, file: !123, line: 12, type: !84)
!647 = distinct !DILexicalBlock(scope: !645, file: !123, line: 12, column: 2)
!648 = !DILocation(line: 12, column: 2, scope: !647)
!649 = !DILocalVariable(name: "__x86_sv_width", scope: !647, file: !123, line: 12, type: !84)
!650 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !651)
!651 = distinct !DILocation(line: 12, column: 2, scope: !647)
!652 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !651)
!653 = !DILocalVariable(name: "__x86_sv_start", scope: !654, file: !123, line: 12, type: !84)
!654 = distinct !DILexicalBlock(scope: !647, file: !123, line: 12, column: 2)
!655 = !DILocation(line: 12, column: 2, scope: !654)
!656 = !DILocation(line: 12, column: 2, scope: !657)
!657 = distinct !DILexicalBlock(scope: !654, file: !123, line: 12, column: 2)
!658 = !DILocation(line: 12, column: 2, scope: !659)
!659 = distinct !DILexicalBlock(scope: !645, file: !123, line: 12, column: 2)
!660 = !DILocation(line: 12, column: 2, scope: !661)
!661 = distinct !DILexicalBlock(scope: !659, file: !123, line: 12, column: 2)
!662 = !DILocation(line: 94, column: 27, scope: !484, inlinedAt: !663)
!663 = distinct !DILocation(line: 12, column: 2, scope: !636)
!664 = !DILocation(line: 94, column: 41, scope: !484, inlinedAt: !663)
!665 = !DILocation(line: 94, column: 54, scope: !484, inlinedAt: !663)
!666 = !DILocation(line: 96, column: 13, scope: !484, inlinedAt: !663)
!667 = !DILocation(line: 96, column: 21, scope: !484, inlinedAt: !663)
!668 = !DILocation(line: 96, column: 5, scope: !484, inlinedAt: !663)
!669 = !DILocation(line: 99, column: 53, scope: !498, inlinedAt: !663)
!670 = !DILocation(line: 99, column: 67, scope: !498, inlinedAt: !663)
!671 = !DILocation(line: 99, column: 9, scope: !498, inlinedAt: !663)
!672 = !DILocation(line: 103, column: 9, scope: !498, inlinedAt: !663)
!673 = !DILocation(line: 106, column: 54, scope: !498, inlinedAt: !663)
!674 = !DILocation(line: 106, column: 68, scope: !498, inlinedAt: !663)
!675 = !DILocation(line: 106, column: 9, scope: !498, inlinedAt: !663)
!676 = !DILocation(line: 110, column: 9, scope: !498, inlinedAt: !663)
!677 = !DILocation(line: 113, column: 54, scope: !498, inlinedAt: !663)
!678 = !DILocation(line: 113, column: 68, scope: !498, inlinedAt: !663)
!679 = !DILocation(line: 113, column: 9, scope: !498, inlinedAt: !663)
!680 = !DILocation(line: 117, column: 9, scope: !498, inlinedAt: !663)
!681 = !DILocation(line: 120, column: 54, scope: !498, inlinedAt: !663)
!682 = !DILocation(line: 120, column: 68, scope: !498, inlinedAt: !663)
!683 = !DILocation(line: 120, column: 9, scope: !498, inlinedAt: !663)
!684 = !DILocation(line: 124, column: 9, scope: !498, inlinedAt: !663)
!685 = !DILocation(line: 125, column: 14, scope: !498, inlinedAt: !663)
!686 = !DILocation(line: 126, column: 5, scope: !498, inlinedAt: !663)
!687 = !DILocalVariable(name: "__x86_l_tag", scope: !688, file: !123, line: 12, type: !57)
!688 = distinct !DILexicalBlock(scope: !689, file: !123, line: 12, column: 2)
!689 = distinct !DILexicalBlock(scope: !526, file: !123, line: 12, column: 2)
!690 = !DILocation(line: 12, column: 2, scope: !688)
!691 = !DILocation(line: 12, column: 2, scope: !689)
!692 = !DILocalVariable(name: "__kprog_x86_st_shift", scope: !693, file: !123, line: 12, type: !10)
!693 = distinct !DILexicalBlock(scope: !689, file: !123, line: 12, column: 2)
!694 = !DILocation(line: 12, column: 2, scope: !693)
!695 = !DILocalVariable(name: "__x86_sv_at", scope: !696, file: !123, line: 12, type: !84)
!696 = distinct !DILexicalBlock(scope: !689, file: !123, line: 12, column: 2)
!697 = !DILocation(line: 12, column: 2, scope: !696)
!698 = !DILocalVariable(name: "__x86_sv_tag", scope: !696, file: !123, line: 12, type: !57)
!699 = !DILocalVariable(name: "__x86_l_tag", scope: !700, file: !123, line: 12, type: !57)
!700 = distinct !DILexicalBlock(scope: !696, file: !123, line: 12, column: 2)
!701 = !DILocation(line: 12, column: 2, scope: !700)
!702 = !DILocation(line: 12, column: 2, scope: !703)
!703 = distinct !DILexicalBlock(scope: !696, file: !123, line: 12, column: 2)
!704 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !705)
!705 = distinct !DILocation(line: 12, column: 2, scope: !703)
!706 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !705)
!707 = !DILocalVariable(name: "__x86_sv_pointer", scope: !708, file: !123, line: 12, type: !114)
!708 = distinct !DILexicalBlock(scope: !703, file: !123, line: 12, column: 2)
!709 = !DILocation(line: 12, column: 2, scope: !708)
!710 = !DILocation(line: 12, column: 2, scope: !711)
!711 = distinct !DILexicalBlock(scope: !712, file: !123, line: 12, column: 2)
!712 = distinct !DILexicalBlock(scope: !708, file: !123, line: 12, column: 2)
!713 = !DILocation(line: 12, column: 2, scope: !712)
!714 = !DILocation(line: 12, column: 2, scope: !715)
!715 = distinct !DILexicalBlock(scope: !716, file: !123, line: 12, column: 2)
!716 = distinct !DILexicalBlock(scope: !711, file: !123, line: 12, column: 2)
!717 = !DILocation(line: 12, column: 2, scope: !716)
!718 = !DILabel(scope: !131, name: "x86_l_8", file: !123, line: 13)
!719 = !DILocation(line: 13, column: 1, scope: !131)
!720 = !DILocation(line: 15, column: 2, scope: !131)
!721 = !DILocalVariable(name: "__x86_l_width", scope: !722, file: !123, line: 15, type: !57)
!722 = distinct !DILexicalBlock(scope: !131, file: !123, line: 15, column: 2)
!723 = !DILocation(line: 15, column: 2, scope: !722)
!724 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !725)
!725 = distinct !DILocation(line: 15, column: 2, scope: !722)
!726 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !725)
!727 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !728, file: !123, line: 15, type: !57)
!728 = distinct !DILexicalBlock(scope: !722, file: !123, line: 15, column: 2)
!729 = !DILocation(line: 15, column: 2, scope: !728)
!730 = !DILocalVariable(name: "__x86_wr_width", scope: !728, file: !123, line: 15, type: !57)
!731 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !732)
!732 = distinct !DILocation(line: 15, column: 2, scope: !728)
!733 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !732)
!734 = !DILocalVariable(name: "__x86_wr_shift", scope: !728, file: !123, line: 15, type: !57)
!735 = !DILocalVariable(name: "__x86_wr_next", scope: !728, file: !123, line: 15, type: !84)
!736 = !DILocation(line: 15, column: 2, scope: !737)
!737 = distinct !DILexicalBlock(scope: !728, file: !123, line: 15, column: 2)
!738 = !DILocation(line: 15, column: 2, scope: !739)
!739 = distinct !DILexicalBlock(scope: !740, file: !123, line: 15, column: 2)
!740 = distinct !DILexicalBlock(scope: !741, file: !123, line: 15, column: 2)
!741 = distinct !DILexicalBlock(scope: !737, file: !123, line: 15, column: 2)
!742 = !DILocation(line: 15, column: 2, scope: !740)
!743 = !DILocalVariable(name: "__x86_stack_delta", scope: !744, file: !123, line: 15, type: !84)
!744 = distinct !DILexicalBlock(scope: !739, file: !123, line: 15, column: 2)
!745 = !DILocation(line: 15, column: 2, scope: !744)
!746 = !{i64 2149012327}
!747 = !DILocation(line: 15, column: 2, scope: !741)
!748 = !DILocation(line: 15, column: 2, scope: !749)
!749 = distinct !DILexicalBlock(scope: !750, file: !123, line: 15, column: 2)
!750 = distinct !DILexicalBlock(scope: !741, file: !123, line: 15, column: 2)
!751 = !DILocation(line: 15, column: 2, scope: !750)
!752 = !DILocation(line: 15, column: 2, scope: !753)
!753 = distinct !DILexicalBlock(scope: !754, file: !123, line: 15, column: 2)
!754 = distinct !DILexicalBlock(scope: !749, file: !123, line: 15, column: 2)
!755 = !DILocation(line: 15, column: 2, scope: !754)
!756 = !DILocalVariable(name: "__kprog_x86_partial", scope: !757, file: !123, line: 15, type: !758)
!757 = distinct !DILexicalBlock(scope: !749, file: !123, line: 15, column: 2)
!758 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !759)
!759 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !131, file: !123, line: 15, size: 64, elements: !760)
!760 = !{!761, !762, !763}
!761 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !759, file: !123, line: 15, baseType: !114, size: 64)
!762 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !759, file: !123, line: 15, baseType: !52, size: 16)
!763 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !759, file: !123, line: 15, baseType: !167, size: 64)
!764 = !DILocation(line: 15, column: 2, scope: !757)
!765 = !DILocation(line: 15, column: 2, scope: !766)
!766 = distinct !DILexicalBlock(scope: !757, file: !123, line: 15, column: 2)
!767 = !DILocation(line: 15, column: 2, scope: !768)
!768 = distinct !DILexicalBlock(scope: !737, file: !123, line: 15, column: 2)
!769 = !DILocation(line: 15, column: 2, scope: !770)
!770 = distinct !DILexicalBlock(scope: !771, file: !123, line: 15, column: 2)
!771 = distinct !DILexicalBlock(scope: !772, file: !123, line: 15, column: 2)
!772 = distinct !DILexicalBlock(scope: !768, file: !123, line: 15, column: 2)
!773 = !DILocation(line: 15, column: 2, scope: !771)
!774 = !DILocalVariable(name: "__x86_stack_delta", scope: !775, file: !123, line: 15, type: !84)
!775 = distinct !DILexicalBlock(scope: !770, file: !123, line: 15, column: 2)
!776 = !DILocation(line: 15, column: 2, scope: !775)
!777 = !{i64 2149051630}
!778 = !DILocation(line: 15, column: 2, scope: !772)
!779 = !DILocation(line: 15, column: 2, scope: !780)
!780 = distinct !DILexicalBlock(scope: !781, file: !123, line: 15, column: 2)
!781 = distinct !DILexicalBlock(scope: !772, file: !123, line: 15, column: 2)
!782 = !DILocation(line: 15, column: 2, scope: !781)
!783 = !DILocation(line: 15, column: 2, scope: !784)
!784 = distinct !DILexicalBlock(scope: !780, file: !123, line: 15, column: 2)
!785 = !DILocalVariable(name: "__kprog_x86_partial", scope: !786, file: !123, line: 15, type: !787)
!786 = distinct !DILexicalBlock(scope: !780, file: !123, line: 15, column: 2)
!787 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !788)
!788 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !131, file: !123, line: 15, size: 64, elements: !789)
!789 = !{!790, !791, !792}
!790 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !788, file: !123, line: 15, baseType: !114, size: 64)
!791 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !788, file: !123, line: 15, baseType: !52, size: 16)
!792 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !788, file: !123, line: 15, baseType: !167, size: 64)
!793 = !DILocation(line: 15, column: 2, scope: !786)
!794 = !DILocation(line: 15, column: 2, scope: !795)
!795 = distinct !DILexicalBlock(scope: !768, file: !123, line: 15, column: 2)
!796 = !DILocation(line: 15, column: 2, scope: !797)
!797 = distinct !DILexicalBlock(scope: !795, file: !123, line: 15, column: 2)
!798 = !DILocation(line: 15, column: 2, scope: !799)
!799 = distinct !DILexicalBlock(scope: !797, file: !123, line: 15, column: 2)
!800 = !DILocation(line: 15, column: 2, scope: !801)
!801 = distinct !DILexicalBlock(scope: !795, file: !123, line: 15, column: 2)
!802 = !DILocation(line: 15, column: 2, scope: !803)
!803 = distinct !DILexicalBlock(scope: !801, file: !123, line: 15, column: 2)
!804 = !DILabel(scope: !131, name: "x86_l_d", file: !123, line: 16)
!805 = !DILocation(line: 16, column: 1, scope: !131)
!806 = !DILocation(line: 18, column: 2, scope: !131)
!807 = !DILocalVariable(name: "__x86_rd_reg", scope: !808, file: !123, line: 18, type: !57)
!808 = distinct !DILexicalBlock(scope: !809, file: !123, line: 18, column: 2)
!809 = distinct !DILexicalBlock(scope: !131, file: !123, line: 18, column: 2)
!810 = !DILocation(line: 18, column: 2, scope: !808)
!811 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !808, file: !123, line: 18, type: !57)
!812 = !DILocalVariable(name: "__x86_rd_width", scope: !808, file: !123, line: 18, type: !57)
!813 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !814)
!814 = distinct !DILocation(line: 18, column: 2, scope: !808)
!815 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !814)
!816 = !DILocalVariable(name: "__x86_rd_shift", scope: !808, file: !123, line: 18, type: !57)
!817 = !DILocalVariable(name: "__x86_rd_ptr", scope: !808, file: !123, line: 18, type: !114)
!818 = !DILocalVariable(name: "__x86_rd_value", scope: !808, file: !123, line: 18, type: !84)
!819 = !DILocation(line: 18, column: 2, scope: !820)
!820 = distinct !DILexicalBlock(scope: !808, file: !123, line: 18, column: 2)
!821 = !DILocalVariable(name: "__x86_l_tag", scope: !822, file: !123, line: 18, type: !57)
!822 = distinct !DILexicalBlock(scope: !823, file: !123, line: 18, column: 2)
!823 = distinct !DILexicalBlock(scope: !820, file: !123, line: 18, column: 2)
!824 = !DILocation(line: 18, column: 2, scope: !822)
!825 = !DILocation(line: 18, column: 2, scope: !826)
!826 = distinct !DILexicalBlock(scope: !822, file: !123, line: 18, column: 2)
!827 = !DILocation(line: 18, column: 2, scope: !823)
!828 = !DILocalVariable(name: "__x86_stack_delta", scope: !829, file: !123, line: 18, type: !84)
!829 = distinct !DILexicalBlock(scope: !823, file: !123, line: 18, column: 2)
!830 = !DILocation(line: 18, column: 2, scope: !829)
!831 = !{i64 2149115990}
!832 = !DILocation(line: 18, column: 2, scope: !809)
!833 = !DILabel(scope: !131, name: "x86_l_12", file: !123, line: 19)
!834 = !DILocation(line: 19, column: 1, scope: !131)
!835 = !DILocation(line: 21, column: 2, scope: !131)
!836 = !DILocalVariable(name: "__x86_rd_reg", scope: !837, file: !123, line: 21, type: !57)
!837 = distinct !DILexicalBlock(scope: !838, file: !123, line: 21, column: 2)
!838 = distinct !DILexicalBlock(scope: !131, file: !123, line: 21, column: 2)
!839 = !DILocation(line: 21, column: 2, scope: !837)
!840 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !837, file: !123, line: 21, type: !57)
!841 = !DILocalVariable(name: "__x86_rd_width", scope: !837, file: !123, line: 21, type: !57)
!842 = !DILocation(line: 226, column: 54, scope: !532, inlinedAt: !843)
!843 = distinct !DILocation(line: 21, column: 2, scope: !837)
!844 = !DILocation(line: 228, column: 9, scope: !532, inlinedAt: !843)
!845 = !DILocalVariable(name: "__x86_rd_shift", scope: !837, file: !123, line: 21, type: !57)
!846 = !DILocalVariable(name: "__x86_rd_ptr", scope: !837, file: !123, line: 21, type: !114)
!847 = !DILocalVariable(name: "__x86_rd_value", scope: !837, file: !123, line: 21, type: !84)
!848 = !DILocation(line: 21, column: 2, scope: !849)
!849 = distinct !DILexicalBlock(scope: !837, file: !123, line: 21, column: 2)
!850 = !DILocalVariable(name: "__x86_l_tag", scope: !851, file: !123, line: 21, type: !57)
!851 = distinct !DILexicalBlock(scope: !852, file: !123, line: 21, column: 2)
!852 = distinct !DILexicalBlock(scope: !849, file: !123, line: 21, column: 2)
!853 = !DILocation(line: 21, column: 2, scope: !851)
!854 = !DILocation(line: 21, column: 2, scope: !855)
!855 = distinct !DILexicalBlock(scope: !851, file: !123, line: 21, column: 2)
!856 = !DILocation(line: 21, column: 2, scope: !852)
!857 = !DILocalVariable(name: "__x86_stack_delta", scope: !858, file: !123, line: 21, type: !84)
!858 = distinct !DILexicalBlock(scope: !852, file: !123, line: 21, column: 2)
!859 = !DILocation(line: 21, column: 2, scope: !858)
!860 = !{i64 2149124402}
!861 = !DILocation(line: 21, column: 2, scope: !838)
!862 = !DILocation(line: 22, column: 1, scope: !131)
