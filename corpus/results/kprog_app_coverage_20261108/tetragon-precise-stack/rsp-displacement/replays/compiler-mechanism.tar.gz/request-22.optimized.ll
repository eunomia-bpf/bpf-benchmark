; ModuleID = '/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c'
source_filename = "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

@LICENSE = dso_local global [4 x i8] c"GPL\00", section "license", align 1, !dbg !0
@llvm.compiler.used = appending global [2 x ptr] [ptr @LICENSE, ptr @trusted_x86_x86_sim_xdp], section "llvm.metadata"

; Function Attrs: nounwind
define dso_local noundef i32 @trusted_x86_x86_sim_xdp(ptr nocapture readnone %0) #0 section "xdp" !dbg !132 {
  %2 = alloca i8, align 1, !DIAssignID !467
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !467, metadata ptr %2, metadata !DIExpression()), !dbg !468
  %3 = alloca i8, align 2, !DIAssignID !469
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 8), metadata !469, metadata ptr %3, metadata !DIExpression()), !dbg !468
  %4 = alloca i8, align 1, !DIAssignID !470
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 24, 8), metadata !470, metadata ptr %4, metadata !DIExpression()), !dbg !468
  %5 = alloca i8, align 4, !DIAssignID !471
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !471, metadata ptr %5, metadata !DIExpression()), !dbg !468
  %6 = alloca i8, align 1, !DIAssignID !472
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 40, 8), metadata !472, metadata ptr %6, metadata !DIExpression()), !dbg !468
  %7 = alloca i8, align 2, !DIAssignID !473
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 8), metadata !473, metadata ptr %7, metadata !DIExpression()), !dbg !468
  %8 = alloca i8, align 1, !DIAssignID !474
  call void @llvm.dbg.assign(metadata i1 undef, metadata !256, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !474, metadata ptr %8, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !145, metadata !DIExpression()), !dbg !468
  call void @llvm.dbg.assign(metadata i8 0, metadata !146, metadata !DIExpression(), metadata !475, metadata ptr undef, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr null, metadata !153, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !154, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !155, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !157, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr null, metadata !158, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr null, metadata !159, metadata !DIExpression()), !dbg !468
  %9 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !476, !srcloc !477
  tail call void @llvm.dbg.value(metadata i64 %9, metadata !169, metadata !DIExpression()), !dbg !478
  tail call void @llvm.dbg.value(metadata i64 %9, metadata !160, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !171, metadata !DIExpression()), !dbg !468
  %10 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !479, !srcloc !480
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !173, metadata !DIExpression()), !dbg !481
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !172, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !175, metadata !DIExpression()), !dbg !468
  %11 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !482, !srcloc !483
  tail call void @llvm.dbg.value(metadata i64 %11, metadata !177, metadata !DIExpression()), !dbg !484
  tail call void @llvm.dbg.value(metadata i64 %11, metadata !176, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !179, metadata !DIExpression()), !dbg !468
  %12 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !485, !srcloc !486
  tail call void @llvm.dbg.value(metadata i64 %12, metadata !181, metadata !DIExpression()), !dbg !487
  tail call void @llvm.dbg.value(metadata i64 %12, metadata !180, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !183, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr null, metadata !184, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !185, metadata !DIExpression()), !dbg !468
  %13 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !488, !srcloc !489
  tail call void @llvm.dbg.value(metadata i64 %13, metadata !187, metadata !DIExpression()), !dbg !490
  tail call void @llvm.dbg.value(metadata i64 %13, metadata !186, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !189, metadata !DIExpression()), !dbg !468
  %14 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !491, !srcloc !492
  tail call void @llvm.dbg.value(metadata i64 %14, metadata !191, metadata !DIExpression()), !dbg !493
  tail call void @llvm.dbg.value(metadata i64 %14, metadata !190, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !193, metadata !DIExpression()), !dbg !468
  %15 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !494, !srcloc !495
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !195, metadata !DIExpression()), !dbg !496
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !194, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !197, metadata !DIExpression()), !dbg !468
  %16 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !497, !srcloc !498
  tail call void @llvm.dbg.value(metadata i64 %16, metadata !199, metadata !DIExpression()), !dbg !499
  tail call void @llvm.dbg.value(metadata i64 %16, metadata !198, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !201, metadata !DIExpression()), !dbg !468
  %17 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !500, !srcloc !501
  tail call void @llvm.dbg.value(metadata i64 %17, metadata !203, metadata !DIExpression()), !dbg !502
  tail call void @llvm.dbg.value(metadata i64 %17, metadata !202, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !205, metadata !DIExpression()), !dbg !468
  %18 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !503, !srcloc !504
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !207, metadata !DIExpression()), !dbg !505
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !206, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !209, metadata !DIExpression()), !dbg !468
  %19 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !506, !srcloc !507
  tail call void @llvm.dbg.value(metadata i64 %19, metadata !211, metadata !DIExpression()), !dbg !508
  tail call void @llvm.dbg.value(metadata i64 %19, metadata !210, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !213, metadata !DIExpression()), !dbg !468
  %20 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !509, !srcloc !510
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !215, metadata !DIExpression()), !dbg !511
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !214, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !217, metadata !DIExpression()), !dbg !468
  %21 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !512, !srcloc !513
  tail call void @llvm.dbg.value(metadata i64 %21, metadata !219, metadata !DIExpression()), !dbg !514
  tail call void @llvm.dbg.value(metadata i64 %21, metadata !218, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !221, metadata !DIExpression()), !dbg !468
  %22 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !515, !srcloc !516
  tail call void @llvm.dbg.value(metadata i64 %22, metadata !223, metadata !DIExpression()), !dbg !517
  tail call void @llvm.dbg.value(metadata i64 %22, metadata !222, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !225, metadata !DIExpression()), !dbg !468
  %23 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !518, !srcloc !519
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !227, metadata !DIExpression()), !dbg !520
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !226, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 0, metadata !229, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i64 0, metadata !230, metadata !DIExpression()), !dbg !468
  %24 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !521, !srcloc !522
  tail call void @llvm.dbg.value(metadata i64 %24, metadata !232, metadata !DIExpression()), !dbg !523
  tail call void @llvm.dbg.value(metadata i64 %24, metadata !231, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !468
  %25 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !524, !srcloc !525
  tail call void @llvm.dbg.value(metadata i64 %25, metadata !235, metadata !DIExpression()), !dbg !526
  tail call void @llvm.dbg.value(metadata i64 %25, metadata !234, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !468
  %26 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !527, !srcloc !528
  tail call void @llvm.dbg.value(metadata i64 %26, metadata !238, metadata !DIExpression()), !dbg !529
  tail call void @llvm.dbg.value(metadata i64 %26, metadata !237, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !468
  %27 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !530, !srcloc !531
  tail call void @llvm.dbg.value(metadata i64 %27, metadata !241, metadata !DIExpression()), !dbg !532
  tail call void @llvm.dbg.value(metadata i64 %27, metadata !240, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !468
  %28 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !533, !srcloc !534
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !244, metadata !DIExpression()), !dbg !535
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !243, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !468
  %29 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !536, !srcloc !537
  tail call void @llvm.dbg.value(metadata i64 %29, metadata !247, metadata !DIExpression()), !dbg !538
  tail call void @llvm.dbg.value(metadata i64 %29, metadata !246, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !468
  %30 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !539, !srcloc !540
  tail call void @llvm.dbg.value(metadata i64 %30, metadata !250, metadata !DIExpression()), !dbg !541
  tail call void @llvm.dbg.value(metadata i64 %30, metadata !249, metadata !DIExpression()), !dbg !468
  %31 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #4, !dbg !542, !srcloc !543
  tail call void @llvm.dbg.value(metadata i64 %31, metadata !253, metadata !DIExpression()), !dbg !544
  tail call void @llvm.dbg.value(metadata i64 %31, metadata !252, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i64 0, metadata !255, metadata !DIExpression()), !dbg !468
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %2), !dbg !545
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %3), !dbg !545
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %4), !dbg !545
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %5), !dbg !545
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %6), !dbg !545
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %7), !dbg !545
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %8), !dbg !545
  %32 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590037175) #4, !dbg !546, !srcloc !547
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !266, metadata !DIExpression()), !dbg !548
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !230, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 1, metadata !157, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !158, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !159, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !194, metadata !DIExpression()), !dbg !468
  tail call void @llvm.dbg.value(metadata i8 1, metadata !197, metadata !DIExpression()), !dbg !468
  call void @llvm.dbg.label(metadata !268), !dbg !549
  tail call void @llvm.dbg.value(metadata i8 8, metadata !269, metadata !DIExpression()), !dbg !550
  tail call void @llvm.dbg.value(metadata i64 0, metadata !277, metadata !DIExpression()), !dbg !550
  tail call void @llvm.dbg.value(metadata i64 0, metadata !273, metadata !DIExpression()), !dbg !550
  tail call void @llvm.dbg.value(metadata i64 0, metadata !292, metadata !DIExpression()), !dbg !550
  tail call void @llvm.dbg.value(metadata ptr null, metadata !276, metadata !DIExpression()), !dbg !550
  tail call void @llvm.dbg.value(metadata i64 1, metadata !347, metadata !DIExpression()), !dbg !551
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !349, metadata !DIExpression()), !dbg !552
  tail call void @llvm.dbg.value(metadata i8 8, metadata !353, metadata !DIExpression()), !dbg !552
  tail call void @llvm.dbg.value(metadata i64 0, metadata !354, metadata !DIExpression()), !dbg !552
  store volatile i8 0, ptr %2, align 1, !dbg !553, !tbaa !554
  store volatile i8 0, ptr %3, align 2, !dbg !557, !tbaa !554
  store volatile i8 0, ptr %4, align 1, !dbg !559, !tbaa !554
  store volatile i8 0, ptr %5, align 4, !dbg !561, !tbaa !554
  store volatile i8 0, ptr %6, align 1, !dbg !563, !tbaa !554
  store volatile i8 0, ptr %7, align 2, !dbg !565, !tbaa !554
  store volatile i8 0, ptr %8, align 1, !dbg !567, !tbaa !554
  call void @llvm.dbg.label(metadata !397), !dbg !569
  tail call void @llvm.dbg.value(metadata ptr inttoptr (i64 2 to ptr), metadata !160, metadata !DIExpression()), !dbg !468
  call void @llvm.dbg.label(metadata !437), !dbg !570
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %2), !dbg !571
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %3), !dbg !571
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %4), !dbg !571
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %5), !dbg !571
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %6), !dbg !571
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %7), !dbg !571
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %8), !dbg !571
  ret i32 2, !dbg !571
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #3

attributes #0 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="v4" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!126, !127, !128, !129, !130}
!llvm.ident = !{!131}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !123, line: 24, type: !124, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !122, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "2f410a6102e6a32f9f4e10ae67f11082")
!4 = !{!5, !114, !115, !109, !84, !57, !10, !117, !118, !120, !121, !52}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__sk_buff", file: !7, line: 6347, size: 1536, elements: !8)
!7 = !DIFile(filename: "vendor/libbpf/include/uapi/linux/bpf.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "af3577c2b1c2566ad76f1bd2c69dbe37")
!8 = !{!9, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24, !28, !29, !30, !31, !32, !33, !34, !35, !36, !40, !41, !42, !43, !44, !83, !86, !87, !88, !111, !112, !113}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !6, file: !7, line: 6348, baseType: !10, size: 32)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !11, line: 27, baseType: !12)
!11 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "", checksumkind: CSK_MD5, checksum: "b810f270733e106319b67ef512c6246e")
!12 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "pkt_type", scope: !6, file: !7, line: 6349, baseType: !10, size: 32, offset: 32)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !6, file: !7, line: 6350, baseType: !10, size: 32, offset: 64)
!15 = !DIDerivedType(tag: DW_TAG_member, name: "queue_mapping", scope: !6, file: !7, line: 6351, baseType: !10, size: 32, offset: 96)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !6, file: !7, line: 6352, baseType: !10, size: 32, offset: 128)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_present", scope: !6, file: !7, line: 6353, baseType: !10, size: 32, offset: 160)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_tci", scope: !6, file: !7, line: 6354, baseType: !10, size: 32, offset: 192)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_proto", scope: !6, file: !7, line: 6355, baseType: !10, size: 32, offset: 224)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !6, file: !7, line: 6356, baseType: !10, size: 32, offset: 256)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !6, file: !7, line: 6357, baseType: !10, size: 32, offset: 288)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !6, file: !7, line: 6358, baseType: !10, size: 32, offset: 320)
!23 = !DIDerivedType(tag: DW_TAG_member, name: "tc_index", scope: !6, file: !7, line: 6359, baseType: !10, size: 32, offset: 352)
!24 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !6, file: !7, line: 6360, baseType: !25, size: 160, offset: 384)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 160, elements: !26)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "hash", scope: !6, file: !7, line: 6361, baseType: !10, size: 32, offset: 544)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "tc_classid", scope: !6, file: !7, line: 6362, baseType: !10, size: 32, offset: 576)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !6, file: !7, line: 6363, baseType: !10, size: 32, offset: 608)
!31 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !6, file: !7, line: 6364, baseType: !10, size: 32, offset: 640)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !6, file: !7, line: 6365, baseType: !10, size: 32, offset: 672)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !6, file: !7, line: 6368, baseType: !10, size: 32, offset: 704)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip4", scope: !6, file: !7, line: 6369, baseType: !10, size: 32, offset: 736)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip4", scope: !6, file: !7, line: 6370, baseType: !10, size: 32, offset: 768)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip6", scope: !6, file: !7, line: 6371, baseType: !37, size: 128, offset: 800)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 128, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 4)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip6", scope: !6, file: !7, line: 6372, baseType: !37, size: 128, offset: 928)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "remote_port", scope: !6, file: !7, line: 6373, baseType: !10, size: 32, offset: 1056)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "local_port", scope: !6, file: !7, line: 6374, baseType: !10, size: 32, offset: 1088)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !6, file: !7, line: 6377, baseType: !10, size: 32, offset: 1120)
!44 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6378, baseType: !45, size: 64, align: 64, offset: 1152)
!45 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6378, size: 64, align: 64, elements: !46)
!46 = !{!47}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "flow_keys", scope: !45, file: !7, line: 6378, baseType: !48, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_flow_keys", file: !7, line: 7436, size: 448, elements: !50)
!50 = !{!51, !54, !55, !56, !59, !60, !61, !62, !65, !66, !67, !81, !82}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "nhoff", scope: !49, file: !7, line: 7437, baseType: !52, size: 16)
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !11, line: 24, baseType: !53)
!53 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "thoff", scope: !49, file: !7, line: 7438, baseType: !52, size: 16, offset: 16)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "addr_proto", scope: !49, file: !7, line: 7439, baseType: !52, size: 16, offset: 32)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "is_frag", scope: !49, file: !7, line: 7440, baseType: !57, size: 8, offset: 48)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !11, line: 21, baseType: !58)
!58 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "is_first_frag", scope: !49, file: !7, line: 7441, baseType: !57, size: 8, offset: 56)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "is_encap", scope: !49, file: !7, line: 7442, baseType: !57, size: 8, offset: 64)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "ip_proto", scope: !49, file: !7, line: 7443, baseType: !57, size: 8, offset: 72)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "n_proto", scope: !49, file: !7, line: 7444, baseType: !63, size: 16, offset: 80)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !64, line: 32, baseType: !52)
!64 = !DIFile(filename: "/usr/include/linux/types.h", directory: "", checksumkind: CSK_MD5, checksum: "bf9fbc0e8f60927fef9d8917535375a6")
!65 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !49, file: !7, line: 7445, baseType: !63, size: 16, offset: 96)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !49, file: !7, line: 7446, baseType: !63, size: 16, offset: 112)
!67 = !DIDerivedType(tag: DW_TAG_member, scope: !49, file: !7, line: 7447, baseType: !68, size: 256, offset: 128)
!68 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !49, file: !7, line: 7447, size: 256, elements: !69)
!69 = !{!70, !76}
!70 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7448, baseType: !71, size: 64)
!71 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7448, size: 64, elements: !72)
!72 = !{!73, !75}
!73 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !71, file: !7, line: 7449, baseType: !74, size: 32)
!74 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !64, line: 34, baseType: !10)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !71, file: !7, line: 7450, baseType: !74, size: 32, offset: 32)
!76 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7452, baseType: !77, size: 256)
!77 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7452, size: 256, elements: !78)
!78 = !{!79, !80}
!79 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !77, file: !7, line: 7453, baseType: !37, size: 128)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !77, file: !7, line: 7454, baseType: !37, size: 128, offset: 128)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !49, file: !7, line: 7457, baseType: !10, size: 32, offset: 384)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "flow_label", scope: !49, file: !7, line: 7458, baseType: !74, size: 32, offset: 416)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp", scope: !6, file: !7, line: 6379, baseType: !84, size: 64, offset: 1216)
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !11, line: 31, baseType: !85)
!85 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "wire_len", scope: !6, file: !7, line: 6380, baseType: !10, size: 32, offset: 1280)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "gso_segs", scope: !6, file: !7, line: 6381, baseType: !10, size: 32, offset: 1312)
!88 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6382, baseType: !89, size: 64, align: 64, offset: 1344)
!89 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6382, size: 64, align: 64, elements: !90)
!90 = !{!91}
!91 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !89, file: !7, line: 6382, baseType: !92, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !93, size: 64)
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !7, line: 6451, size: 640, elements: !94)
!94 = !{!95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !93, file: !7, line: 6452, baseType: !10, size: 32)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !93, file: !7, line: 6453, baseType: !10, size: 32, offset: 32)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !93, file: !7, line: 6454, baseType: !10, size: 32, offset: 64)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !93, file: !7, line: 6455, baseType: !10, size: 32, offset: 96)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !93, file: !7, line: 6456, baseType: !10, size: 32, offset: 128)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !93, file: !7, line: 6457, baseType: !10, size: 32, offset: 160)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !93, file: !7, line: 6459, baseType: !10, size: 32, offset: 192)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !93, file: !7, line: 6460, baseType: !37, size: 128, offset: 224)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !93, file: !7, line: 6461, baseType: !10, size: 32, offset: 352)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !93, file: !7, line: 6462, baseType: !63, size: 16, offset: 384)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !93, file: !7, line: 6464, baseType: !10, size: 32, offset: 416)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !93, file: !7, line: 6465, baseType: !37, size: 128, offset: 448)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !93, file: !7, line: 6466, baseType: !10, size: 32, offset: 576)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !93, file: !7, line: 6467, baseType: !109, size: 32, offset: 608)
!109 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !11, line: 26, baseType: !110)
!110 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "gso_size", scope: !6, file: !7, line: 6383, baseType: !10, size: 32, offset: 1408)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp_type", scope: !6, file: !7, line: 6384, baseType: !57, size: 8, offset: 1440)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "hwtstamp", scope: !6, file: !7, line: 6386, baseType: !84, size: 64, offset: 1472)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!115 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s64", file: !11, line: 30, baseType: !116)
!116 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!117 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!118 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !119, size: 64)
!119 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !57)
!120 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!121 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!122 = !{!0}
!123 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-22.analysis.c", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "2f410a6102e6a32f9f4e10ae67f11082")
!124 = !DICompositeType(tag: DW_TAG_array_type, baseType: !125, size: 32, elements: !38)
!125 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!126 = !{i32 7, !"Dwarf Version", i32 5}
!127 = !{i32 2, !"Debug Info Version", i32 3}
!128 = !{i32 1, !"wchar_size", i32 4}
!129 = !{i32 7, !"frame-pointer", i32 2}
!130 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!131 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!132 = distinct !DISubprogram(name: "trusted_x86_x86_sim_xdp", scope: !123, file: !123, line: 7, type: !133, scopeLine: 8, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !144)
!133 = !DISubroutineType(types: !134)
!134 = !{!110, !135}
!135 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !136, size: 64)
!136 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !7, line: 6567, size: 192, elements: !137)
!137 = !{!138, !139, !140, !141, !142, !143}
!138 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !136, file: !7, line: 6568, baseType: !10, size: 32)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !136, file: !7, line: 6569, baseType: !10, size: 32, offset: 32)
!140 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !136, file: !7, line: 6570, baseType: !10, size: 32, offset: 64)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !136, file: !7, line: 6572, baseType: !10, size: 32, offset: 96)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !136, file: !7, line: 6573, baseType: !10, size: 32, offset: 128)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !136, file: !7, line: 6575, baseType: !10, size: 32, offset: 160)
!144 = !{!145, !146, !153, !154, !155, !156, !157, !158, !159, !160, !169, !171, !172, !173, !175, !176, !177, !179, !180, !181, !183, !184, !185, !186, !187, !189, !190, !191, !193, !194, !195, !197, !198, !199, !201, !202, !203, !205, !206, !207, !209, !210, !211, !213, !214, !215, !217, !218, !219, !221, !222, !223, !225, !226, !227, !229, !230, !231, !232, !234, !235, !237, !238, !240, !241, !243, !244, !246, !247, !249, !250, !252, !253, !255, !256, !266, !268, !269, !271, !273, !274, !276, !277, !278, !280, !282, !284, !286, !287, !288, !291, !292, !293, !296, !298, !299, !300, !303, !305, !308, !309, !312, !314, !315, !316, !317, !319, !322, !324, !325, !326, !327, !329, !332, !334, !335, !336, !337, !339, !341, !344, !345, !347, !349, !353, !354, !355, !356, !359, !361, !362, !364, !367, !369, !370, !371, !373, !374, !375, !377, !378, !381, !382, !384, !387, !389, !391, !392, !394, !397, !398, !400, !402, !403, !404, !405, !411, !421, !427, !437, !438, !441, !442, !443, !444, !445, !446, !450, !452, !453, !456, !457, !458, !459, !460, !461, !465}
!145 = !DILocalVariable(name: "ctx", arg: 1, scope: !132, file: !123, line: 7, type: !135)
!146 = !DILocalVariable(name: "__x86_sim_abi", scope: !132, file: !123, line: 9, type: !147)
!147 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_xdp_abi", file: !148, line: 64, size: 320, elements: !149)
!148 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim_local_bpf.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "cdf042bef0d13fcc12d092b7f12f07bf")
!149 = !{!150, !151, !152}
!150 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !147, file: !148, line: 65, baseType: !114, size: 64)
!151 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !147, file: !148, line: 66, baseType: !114, size: 64, offset: 64)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !147, file: !148, line: 67, baseType: !25, size: 160, offset: 128)
!153 = !DILocalVariable(name: "__x86_sim_skb_ctx", scope: !132, file: !123, line: 9, type: !5)
!154 = !DILocalVariable(name: "__x86_sim_abi_kind", scope: !132, file: !123, line: 9, type: !57)
!155 = !DILocalVariable(name: "__x86_stack_value_tag_0", scope: !132, file: !123, line: 9, type: !57)
!156 = !DILocalVariable(name: "__x86_stack_value_ptr_0", scope: !132, file: !123, line: 9, type: !114)
!157 = !DILocalVariable(name: "__x86_sim_is_xdp", scope: !132, file: !123, line: 9, type: !57)
!158 = !DILocalVariable(name: "__x86_sim_helper_ctx", scope: !132, file: !123, line: 9, type: !114)
!159 = !DILocalVariable(name: "__x86_sim_helper_abi_base", scope: !132, file: !123, line: 9, type: !114)
!160 = !DILocalVariable(name: "__x86_rax", scope: !132, file: !123, line: 9, type: !161)
!161 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_gpr", file: !148, line: 90, size: 64, elements: !162)
!162 = !{!163, !164, !165}
!163 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !161, file: !148, line: 91, baseType: !114, size: 64)
!164 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !161, file: !148, line: 92, baseType: !52, size: 16)
!165 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !161, file: !148, line: 93, baseType: !166, size: 64)
!166 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 64, elements: !167)
!167 = !{!168}
!168 = !DISubrange(count: 8)
!169 = !DILocalVariable(name: "__native_value", scope: !170, file: !123, line: 9, type: !121)
!170 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!171 = !DILocalVariable(name: "__x86_rax_tag", scope: !132, file: !123, line: 9, type: !57)
!172 = !DILocalVariable(name: "__x86_rcx", scope: !132, file: !123, line: 9, type: !161)
!173 = !DILocalVariable(name: "__native_value", scope: !174, file: !123, line: 9, type: !121)
!174 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!175 = !DILocalVariable(name: "__x86_rcx_tag", scope: !132, file: !123, line: 9, type: !57)
!176 = !DILocalVariable(name: "__x86_rdx", scope: !132, file: !123, line: 9, type: !161)
!177 = !DILocalVariable(name: "__native_value", scope: !178, file: !123, line: 9, type: !121)
!178 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!179 = !DILocalVariable(name: "__x86_rdx_tag", scope: !132, file: !123, line: 9, type: !57)
!180 = !DILocalVariable(name: "__x86_rbx", scope: !132, file: !123, line: 9, type: !161)
!181 = !DILocalVariable(name: "__native_value", scope: !182, file: !123, line: 9, type: !121)
!182 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!183 = !DILocalVariable(name: "__x86_rbx_tag", scope: !132, file: !123, line: 9, type: !57)
!184 = !DILocalVariable(name: "__x86_rsp", scope: !132, file: !123, line: 9, type: !161)
!185 = !DILocalVariable(name: "__x86_rsp_tag", scope: !132, file: !123, line: 9, type: !57)
!186 = !DILocalVariable(name: "__x86_rbp", scope: !132, file: !123, line: 9, type: !161)
!187 = !DILocalVariable(name: "__native_value", scope: !188, file: !123, line: 9, type: !121)
!188 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!189 = !DILocalVariable(name: "__x86_rbp_tag", scope: !132, file: !123, line: 9, type: !57)
!190 = !DILocalVariable(name: "__x86_rsi", scope: !132, file: !123, line: 9, type: !161)
!191 = !DILocalVariable(name: "__native_value", scope: !192, file: !123, line: 9, type: !121)
!192 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!193 = !DILocalVariable(name: "__x86_rsi_tag", scope: !132, file: !123, line: 9, type: !57)
!194 = !DILocalVariable(name: "__x86_rdi", scope: !132, file: !123, line: 9, type: !161)
!195 = !DILocalVariable(name: "__native_value", scope: !196, file: !123, line: 9, type: !121)
!196 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!197 = !DILocalVariable(name: "__x86_rdi_tag", scope: !132, file: !123, line: 9, type: !57)
!198 = !DILocalVariable(name: "__x86_r8", scope: !132, file: !123, line: 9, type: !161)
!199 = !DILocalVariable(name: "__native_value", scope: !200, file: !123, line: 9, type: !121)
!200 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!201 = !DILocalVariable(name: "__x86_r8_tag", scope: !132, file: !123, line: 9, type: !57)
!202 = !DILocalVariable(name: "__x86_r9", scope: !132, file: !123, line: 9, type: !161)
!203 = !DILocalVariable(name: "__native_value", scope: !204, file: !123, line: 9, type: !121)
!204 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!205 = !DILocalVariable(name: "__x86_r9_tag", scope: !132, file: !123, line: 9, type: !57)
!206 = !DILocalVariable(name: "__x86_r10", scope: !132, file: !123, line: 9, type: !161)
!207 = !DILocalVariable(name: "__native_value", scope: !208, file: !123, line: 9, type: !121)
!208 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!209 = !DILocalVariable(name: "__x86_r10_tag", scope: !132, file: !123, line: 9, type: !57)
!210 = !DILocalVariable(name: "__x86_r11", scope: !132, file: !123, line: 9, type: !161)
!211 = !DILocalVariable(name: "__native_value", scope: !212, file: !123, line: 9, type: !121)
!212 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!213 = !DILocalVariable(name: "__x86_r11_tag", scope: !132, file: !123, line: 9, type: !57)
!214 = !DILocalVariable(name: "__x86_r12", scope: !132, file: !123, line: 9, type: !161)
!215 = !DILocalVariable(name: "__native_value", scope: !216, file: !123, line: 9, type: !121)
!216 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!217 = !DILocalVariable(name: "__x86_r12_tag", scope: !132, file: !123, line: 9, type: !57)
!218 = !DILocalVariable(name: "__x86_r13", scope: !132, file: !123, line: 9, type: !161)
!219 = !DILocalVariable(name: "__native_value", scope: !220, file: !123, line: 9, type: !121)
!220 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!221 = !DILocalVariable(name: "__x86_r13_tag", scope: !132, file: !123, line: 9, type: !57)
!222 = !DILocalVariable(name: "__x86_r14", scope: !132, file: !123, line: 9, type: !161)
!223 = !DILocalVariable(name: "__native_value", scope: !224, file: !123, line: 9, type: !121)
!224 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!225 = !DILocalVariable(name: "__x86_r14_tag", scope: !132, file: !123, line: 9, type: !57)
!226 = !DILocalVariable(name: "__x86_r15", scope: !132, file: !123, line: 9, type: !161)
!227 = !DILocalVariable(name: "__native_value", scope: !228, file: !123, line: 9, type: !121)
!228 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!229 = !DILocalVariable(name: "__x86_r15_tag", scope: !132, file: !123, line: 9, type: !57)
!230 = !DILocalVariable(name: "__x86_native_stack_base", scope: !132, file: !123, line: 9, type: !84)
!231 = !DILocalVariable(name: "__x86_cf", scope: !132, file: !123, line: 9, type: !57)
!232 = !DILocalVariable(name: "__native_value", scope: !233, file: !123, line: 9, type: !121)
!233 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!234 = !DILocalVariable(name: "__x86_zf", scope: !132, file: !123, line: 9, type: !57)
!235 = !DILocalVariable(name: "__native_value", scope: !236, file: !123, line: 9, type: !121)
!236 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!237 = !DILocalVariable(name: "__x86_sf", scope: !132, file: !123, line: 9, type: !57)
!238 = !DILocalVariable(name: "__native_value", scope: !239, file: !123, line: 9, type: !121)
!239 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!240 = !DILocalVariable(name: "__x86_of", scope: !132, file: !123, line: 9, type: !57)
!241 = !DILocalVariable(name: "__native_value", scope: !242, file: !123, line: 9, type: !121)
!242 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!243 = !DILocalVariable(name: "__x86_pf", scope: !132, file: !123, line: 9, type: !57)
!244 = !DILocalVariable(name: "__native_value", scope: !245, file: !123, line: 9, type: !121)
!245 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!246 = !DILocalVariable(name: "__x86_af", scope: !132, file: !123, line: 9, type: !57)
!247 = !DILocalVariable(name: "__native_value", scope: !248, file: !123, line: 9, type: !121)
!248 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!249 = !DILocalVariable(name: "__x86_xmm0_lo", scope: !132, file: !123, line: 9, type: !84)
!250 = !DILocalVariable(name: "__native_value", scope: !251, file: !123, line: 9, type: !121)
!251 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!252 = !DILocalVariable(name: "__x86_xmm0_hi", scope: !132, file: !123, line: 9, type: !84)
!253 = !DILocalVariable(name: "__native_value", scope: !254, file: !123, line: 9, type: !121)
!254 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!255 = !DILocalVariable(name: "__x86_sim_ret_addr", scope: !132, file: !123, line: 9, type: !84)
!256 = !DILocalVariable(name: "__x86_stack_mem", scope: !132, file: !123, line: 9, type: !257)
!257 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !258)
!258 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !132, file: !123, line: 9, size: 64, elements: !259)
!259 = !{!260, !264}
!260 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !258, file: !123, line: 9, baseType: !261, size: 8)
!261 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 8, elements: !262)
!262 = !{!263}
!263 = !DISubrange(count: 1)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "q", scope: !258, file: !123, line: 9, baseType: !265, size: 64)
!265 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 64, elements: !262)
!266 = !DILocalVariable(name: "__native_value", scope: !267, file: !123, line: 9, type: !121)
!267 = distinct !DILexicalBlock(scope: !132, file: !123, line: 9, column: 2)
!268 = !DILabel(scope: !132, name: "x86_l_0", file: !123, line: 10)
!269 = !DILocalVariable(name: "__x86_l_width", scope: !270, file: !123, line: 12, type: !57)
!270 = distinct !DILexicalBlock(scope: !132, file: !123, line: 12, column: 2)
!271 = !DILocalVariable(name: "__kprog_x86_st_width", scope: !272, file: !123, line: 12, type: !57)
!272 = distinct !DILexicalBlock(scope: !270, file: !123, line: 12, column: 2)
!273 = !DILocalVariable(name: "__x86_l_disp", scope: !270, file: !123, line: 12, type: !115)
!274 = !DILocalVariable(name: "__kprog_x86_st_disp", scope: !275, file: !123, line: 12, type: !115)
!275 = distinct !DILexicalBlock(scope: !270, file: !123, line: 12, column: 2)
!276 = !DILocalVariable(name: "__x86_l_base_ptr", scope: !270, file: !123, line: 12, type: !114)
!277 = !DILocalVariable(name: "__x86_l_value", scope: !270, file: !123, line: 12, type: !84)
!278 = !DILocalVariable(name: "__kprog_x86_st_value", scope: !279, file: !123, line: 12, type: !84)
!279 = distinct !DILexicalBlock(scope: !270, file: !123, line: 12, column: 2)
!280 = !DILocalVariable(name: "__kprog_x86_st_shifted", scope: !281, file: !123, line: 12, type: !84)
!281 = distinct !DILexicalBlock(scope: !270, file: !123, line: 12, column: 2)
!282 = !DILocalVariable(name: "__kprog_x86_st_shift", scope: !283, file: !123, line: 12, type: !10)
!283 = distinct !DILexicalBlock(scope: !281, file: !123, line: 12, column: 2)
!284 = !DILocalVariable(name: "__kprog_x86_mo_disp", scope: !285, file: !123, line: 12, type: !115)
!285 = distinct !DILexicalBlock(scope: !270, file: !123, line: 12, column: 2)
!286 = !DILocalVariable(name: "__kprog_x86_mo_has_index", scope: !285, file: !123, line: 12, type: !110)
!287 = !DILocalVariable(name: "__kprog_x86_mo_result", scope: !285, file: !123, line: 12, type: !84)
!288 = !DILocalVariable(name: "__kprog_x86_mo_scale", scope: !289, file: !123, line: 12, type: !57)
!289 = distinct !DILexicalBlock(scope: !290, file: !123, line: 12, column: 2)
!290 = distinct !DILexicalBlock(scope: !285, file: !123, line: 12, column: 2)
!291 = !DILocalVariable(name: "__kprog_x86_mo_index", scope: !289, file: !123, line: 12, type: !84)
!292 = !DILocalVariable(name: "__x86_l_meta_disp", scope: !270, file: !123, line: 12, type: !115)
!293 = !DILocalVariable(name: "__x86_l_tag", scope: !294, file: !123, line: 12, type: !57)
!294 = distinct !DILexicalBlock(scope: !295, file: !123, line: 12, column: 2)
!295 = distinct !DILexicalBlock(scope: !270, file: !123, line: 12, column: 2)
!296 = !DILocalVariable(name: "__x86_sw_width", scope: !297, file: !123, line: 12, type: !57)
!297 = distinct !DILexicalBlock(scope: !295, file: !123, line: 12, column: 2)
!298 = !DILocalVariable(name: "__x86_sw_off", scope: !297, file: !123, line: 12, type: !115)
!299 = !DILocalVariable(name: "__x86_sw_value", scope: !297, file: !123, line: 12, type: !84)
!300 = !DILocalVariable(name: "__x86_sw_ctx_off", scope: !301, file: !123, line: 12, type: !115)
!301 = distinct !DILexicalBlock(scope: !302, file: !123, line: 12, column: 2)
!302 = distinct !DILexicalBlock(scope: !297, file: !123, line: 12, column: 2)
!303 = !DILocalVariable(name: "__x86_cbw_temp", scope: !304, file: !123, line: 12, type: !84)
!304 = distinct !DILexicalBlock(scope: !301, file: !123, line: 12, column: 2)
!305 = !DILocalVariable(name: "__x86_cbw_addr", scope: !306, file: !123, line: 12, type: !118)
!306 = distinct !DILexicalBlock(scope: !307, file: !123, line: 12, column: 2)
!307 = distinct !DILexicalBlock(scope: !304, file: !123, line: 12, column: 2)
!308 = !DILocalVariable(name: "__x86_cbw_value", scope: !306, file: !123, line: 12, type: !84)
!309 = !DILocalVariable(name: "__x86_ss_old", scope: !310, file: !123, line: 12, type: !84)
!310 = distinct !DILexicalBlock(scope: !311, file: !123, line: 12, column: 2)
!311 = distinct !DILexicalBlock(scope: !302, file: !123, line: 12, column: 2)
!312 = !DILocalVariable(name: "__x86_sf_value", scope: !313, file: !123, line: 12, type: !84)
!313 = distinct !DILexicalBlock(scope: !310, file: !123, line: 12, column: 2)
!314 = !DILocalVariable(name: "__x86_ss_shift", scope: !310, file: !123, line: 12, type: !84)
!315 = !DILocalVariable(name: "__x86_ss_mask", scope: !310, file: !123, line: 12, type: !84)
!316 = !DILocalVariable(name: "__x86_ss_new", scope: !310, file: !123, line: 12, type: !84)
!317 = !DILocalVariable(name: "__x86_ss_value", scope: !318, file: !123, line: 12, type: !84)
!318 = distinct !DILexicalBlock(scope: !310, file: !123, line: 12, column: 2)
!319 = !DILocalVariable(name: "__x86_ss_old", scope: !320, file: !123, line: 12, type: !84)
!320 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!321 = distinct !DILexicalBlock(scope: !311, file: !123, line: 12, column: 2)
!322 = !DILocalVariable(name: "__x86_sf_value", scope: !323, file: !123, line: 12, type: !84)
!323 = distinct !DILexicalBlock(scope: !320, file: !123, line: 12, column: 2)
!324 = !DILocalVariable(name: "__x86_ss_shift", scope: !320, file: !123, line: 12, type: !84)
!325 = !DILocalVariable(name: "__x86_ss_mask", scope: !320, file: !123, line: 12, type: !84)
!326 = !DILocalVariable(name: "__x86_ss_new", scope: !320, file: !123, line: 12, type: !84)
!327 = !DILocalVariable(name: "__x86_ss_value", scope: !328, file: !123, line: 12, type: !84)
!328 = distinct !DILexicalBlock(scope: !320, file: !123, line: 12, column: 2)
!329 = !DILocalVariable(name: "__x86_ss_old", scope: !330, file: !123, line: 12, type: !84)
!330 = distinct !DILexicalBlock(scope: !331, file: !123, line: 12, column: 2)
!331 = distinct !DILexicalBlock(scope: !321, file: !123, line: 12, column: 2)
!332 = !DILocalVariable(name: "__x86_sf_value", scope: !333, file: !123, line: 12, type: !84)
!333 = distinct !DILexicalBlock(scope: !330, file: !123, line: 12, column: 2)
!334 = !DILocalVariable(name: "__x86_ss_shift", scope: !330, file: !123, line: 12, type: !84)
!335 = !DILocalVariable(name: "__x86_ss_mask", scope: !330, file: !123, line: 12, type: !84)
!336 = !DILocalVariable(name: "__x86_ss_new", scope: !330, file: !123, line: 12, type: !84)
!337 = !DILocalVariable(name: "__x86_ss_value", scope: !338, file: !123, line: 12, type: !84)
!338 = distinct !DILexicalBlock(scope: !330, file: !123, line: 12, column: 2)
!339 = !DILocalVariable(name: "__kprog_x86_st_arm", scope: !340, file: !123, line: 12, type: !57)
!340 = distinct !DILexicalBlock(scope: !295, file: !123, line: 12, column: 2)
!341 = !DILocalVariable(name: "__x86_sv_index", scope: !342, file: !123, line: 12, type: !84)
!342 = distinct !DILexicalBlock(scope: !343, file: !123, line: 12, column: 2)
!343 = distinct !DILexicalBlock(scope: !295, file: !123, line: 12, column: 2)
!344 = !DILocalVariable(name: "__x86_sv_width", scope: !342, file: !123, line: 12, type: !84)
!345 = !DILocalVariable(name: "__x86_sv_start", scope: !346, file: !123, line: 12, type: !84)
!346 = distinct !DILexicalBlock(scope: !342, file: !123, line: 12, column: 2)
!347 = !DILocalVariable(name: "__x86_stw_index", scope: !348, file: !123, line: 12, type: !84)
!348 = distinct !DILexicalBlock(scope: !343, file: !123, line: 12, column: 2)
!349 = !DILocalVariable(name: "__x86_stw_bytes", scope: !350, file: !123, line: 12, type: !118)
!350 = distinct !DILexicalBlock(scope: !351, file: !123, line: 12, column: 2)
!351 = distinct !DILexicalBlock(scope: !352, file: !123, line: 12, column: 2)
!352 = distinct !DILexicalBlock(scope: !348, file: !123, line: 12, column: 2)
!353 = !DILocalVariable(name: "__x86_stw_width", scope: !350, file: !123, line: 12, type: !57)
!354 = !DILocalVariable(name: "__x86_stw_narrowed", scope: !350, file: !123, line: 12, type: !84)
!355 = !DILocalVariable(name: "__x86_l_addr", scope: !343, file: !123, line: 12, type: !114)
!356 = !DILocalVariable(name: "__x86_l_tag", scope: !357, file: !123, line: 12, type: !57)
!357 = distinct !DILexicalBlock(scope: !358, file: !123, line: 12, column: 2)
!358 = distinct !DILexicalBlock(scope: !343, file: !123, line: 12, column: 2)
!359 = !DILocalVariable(name: "__x86_sv_index", scope: !360, file: !123, line: 12, type: !84)
!360 = distinct !DILexicalBlock(scope: !358, file: !123, line: 12, column: 2)
!361 = !DILocalVariable(name: "__x86_sv_width", scope: !360, file: !123, line: 12, type: !84)
!362 = !DILocalVariable(name: "__x86_sv_start", scope: !363, file: !123, line: 12, type: !84)
!363 = distinct !DILexicalBlock(scope: !360, file: !123, line: 12, column: 2)
!364 = !DILocalVariable(name: "__x86_l_tag", scope: !365, file: !123, line: 12, type: !57)
!365 = distinct !DILexicalBlock(scope: !366, file: !123, line: 12, column: 2)
!366 = distinct !DILexicalBlock(scope: !343, file: !123, line: 12, column: 2)
!367 = !DILocalVariable(name: "__x86_stw_bytes", scope: !368, file: !123, line: 12, type: !118)
!368 = distinct !DILexicalBlock(scope: !366, file: !123, line: 12, column: 2)
!369 = !DILocalVariable(name: "__x86_stw_width", scope: !368, file: !123, line: 12, type: !57)
!370 = !DILocalVariable(name: "__x86_stw_narrowed", scope: !368, file: !123, line: 12, type: !84)
!371 = !DILocalVariable(name: "__x86_st_addr", scope: !372, file: !123, line: 12, type: !114)
!372 = distinct !DILexicalBlock(scope: !366, file: !123, line: 12, column: 2)
!373 = !DILocalVariable(name: "__x86_st_width", scope: !372, file: !123, line: 12, type: !57)
!374 = !DILocalVariable(name: "__x86_st_tag", scope: !372, file: !123, line: 12, type: !57)
!375 = !DILocalVariable(name: "__x86_l_tag", scope: !376, file: !123, line: 12, type: !57)
!376 = distinct !DILexicalBlock(scope: !372, file: !123, line: 12, column: 2)
!377 = !DILocalVariable(name: "__x86_st_value", scope: !372, file: !123, line: 12, type: !84)
!378 = !DILocalVariable(name: "__x86_sv_index", scope: !379, file: !123, line: 12, type: !84)
!379 = distinct !DILexicalBlock(scope: !380, file: !123, line: 12, column: 2)
!380 = distinct !DILexicalBlock(scope: !372, file: !123, line: 12, column: 2)
!381 = !DILocalVariable(name: "__x86_sv_width", scope: !379, file: !123, line: 12, type: !84)
!382 = !DILocalVariable(name: "__x86_sv_start", scope: !383, file: !123, line: 12, type: !84)
!383 = distinct !DILexicalBlock(scope: !379, file: !123, line: 12, column: 2)
!384 = !DILocalVariable(name: "__x86_l_tag", scope: !385, file: !123, line: 12, type: !57)
!385 = distinct !DILexicalBlock(scope: !386, file: !123, line: 12, column: 2)
!386 = distinct !DILexicalBlock(scope: !343, file: !123, line: 12, column: 2)
!387 = !DILocalVariable(name: "__kprog_x86_st_shift", scope: !388, file: !123, line: 12, type: !10)
!388 = distinct !DILexicalBlock(scope: !386, file: !123, line: 12, column: 2)
!389 = !DILocalVariable(name: "__x86_sv_at", scope: !390, file: !123, line: 12, type: !84)
!390 = distinct !DILexicalBlock(scope: !386, file: !123, line: 12, column: 2)
!391 = !DILocalVariable(name: "__x86_sv_tag", scope: !390, file: !123, line: 12, type: !57)
!392 = !DILocalVariable(name: "__x86_l_tag", scope: !393, file: !123, line: 12, type: !57)
!393 = distinct !DILexicalBlock(scope: !390, file: !123, line: 12, column: 2)
!394 = !DILocalVariable(name: "__x86_sv_pointer", scope: !395, file: !123, line: 12, type: !114)
!395 = distinct !DILexicalBlock(scope: !396, file: !123, line: 12, column: 2)
!396 = distinct !DILexicalBlock(scope: !390, file: !123, line: 12, column: 2)
!397 = !DILabel(scope: !132, name: "x86_l_8", file: !123, line: 13)
!398 = !DILocalVariable(name: "__x86_l_width", scope: !399, file: !123, line: 15, type: !57)
!399 = distinct !DILexicalBlock(scope: !132, file: !123, line: 15, column: 2)
!400 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !401, file: !123, line: 15, type: !57)
!401 = distinct !DILexicalBlock(scope: !399, file: !123, line: 15, column: 2)
!402 = !DILocalVariable(name: "__x86_wr_width", scope: !401, file: !123, line: 15, type: !57)
!403 = !DILocalVariable(name: "__x86_wr_shift", scope: !401, file: !123, line: 15, type: !57)
!404 = !DILocalVariable(name: "__x86_wr_next", scope: !401, file: !123, line: 15, type: !84)
!405 = !DILocalVariable(name: "__x86_stack_delta", scope: !406, file: !123, line: 15, type: !84)
!406 = distinct !DILexicalBlock(scope: !407, file: !123, line: 15, column: 2)
!407 = distinct !DILexicalBlock(scope: !408, file: !123, line: 15, column: 2)
!408 = distinct !DILexicalBlock(scope: !409, file: !123, line: 15, column: 2)
!409 = distinct !DILexicalBlock(scope: !410, file: !123, line: 15, column: 2)
!410 = distinct !DILexicalBlock(scope: !401, file: !123, line: 15, column: 2)
!411 = !DILocalVariable(name: "__kprog_x86_partial", scope: !412, file: !123, line: 15, type: !415)
!412 = distinct !DILexicalBlock(scope: !413, file: !123, line: 15, column: 2)
!413 = distinct !DILexicalBlock(scope: !414, file: !123, line: 15, column: 2)
!414 = distinct !DILexicalBlock(scope: !409, file: !123, line: 15, column: 2)
!415 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !416)
!416 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !132, file: !123, line: 15, size: 64, elements: !417)
!417 = !{!418, !419, !420}
!418 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !416, file: !123, line: 15, baseType: !114, size: 64)
!419 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !416, file: !123, line: 15, baseType: !52, size: 16)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !416, file: !123, line: 15, baseType: !166, size: 64)
!421 = !DILocalVariable(name: "__x86_stack_delta", scope: !422, file: !123, line: 15, type: !84)
!422 = distinct !DILexicalBlock(scope: !423, file: !123, line: 15, column: 2)
!423 = distinct !DILexicalBlock(scope: !424, file: !123, line: 15, column: 2)
!424 = distinct !DILexicalBlock(scope: !425, file: !123, line: 15, column: 2)
!425 = distinct !DILexicalBlock(scope: !426, file: !123, line: 15, column: 2)
!426 = distinct !DILexicalBlock(scope: !410, file: !123, line: 15, column: 2)
!427 = !DILocalVariable(name: "__kprog_x86_partial", scope: !428, file: !123, line: 15, type: !431)
!428 = distinct !DILexicalBlock(scope: !429, file: !123, line: 15, column: 2)
!429 = distinct !DILexicalBlock(scope: !430, file: !123, line: 15, column: 2)
!430 = distinct !DILexicalBlock(scope: !425, file: !123, line: 15, column: 2)
!431 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !432)
!432 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !132, file: !123, line: 15, size: 64, elements: !433)
!433 = !{!434, !435, !436}
!434 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !432, file: !123, line: 15, baseType: !114, size: 64)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !432, file: !123, line: 15, baseType: !52, size: 16)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !432, file: !123, line: 15, baseType: !166, size: 64)
!437 = !DILabel(scope: !132, name: "x86_l_d", file: !123, line: 16)
!438 = !DILocalVariable(name: "__x86_rd_reg", scope: !439, file: !123, line: 18, type: !57)
!439 = distinct !DILexicalBlock(scope: !440, file: !123, line: 18, column: 2)
!440 = distinct !DILexicalBlock(scope: !132, file: !123, line: 18, column: 2)
!441 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !439, file: !123, line: 18, type: !57)
!442 = !DILocalVariable(name: "__x86_rd_width", scope: !439, file: !123, line: 18, type: !57)
!443 = !DILocalVariable(name: "__x86_rd_shift", scope: !439, file: !123, line: 18, type: !57)
!444 = !DILocalVariable(name: "__x86_rd_ptr", scope: !439, file: !123, line: 18, type: !114)
!445 = !DILocalVariable(name: "__x86_rd_value", scope: !439, file: !123, line: 18, type: !84)
!446 = !DILocalVariable(name: "__x86_l_tag", scope: !447, file: !123, line: 18, type: !57)
!447 = distinct !DILexicalBlock(scope: !448, file: !123, line: 18, column: 2)
!448 = distinct !DILexicalBlock(scope: !449, file: !123, line: 18, column: 2)
!449 = distinct !DILexicalBlock(scope: !439, file: !123, line: 18, column: 2)
!450 = !DILocalVariable(name: "__x86_stack_delta", scope: !451, file: !123, line: 18, type: !84)
!451 = distinct !DILexicalBlock(scope: !448, file: !123, line: 18, column: 2)
!452 = !DILabel(scope: !132, name: "x86_l_12", file: !123, line: 19)
!453 = !DILocalVariable(name: "__x86_rd_reg", scope: !454, file: !123, line: 21, type: !57)
!454 = distinct !DILexicalBlock(scope: !455, file: !123, line: 21, column: 2)
!455 = distinct !DILexicalBlock(scope: !132, file: !123, line: 21, column: 2)
!456 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !454, file: !123, line: 21, type: !57)
!457 = !DILocalVariable(name: "__x86_rd_width", scope: !454, file: !123, line: 21, type: !57)
!458 = !DILocalVariable(name: "__x86_rd_shift", scope: !454, file: !123, line: 21, type: !57)
!459 = !DILocalVariable(name: "__x86_rd_ptr", scope: !454, file: !123, line: 21, type: !114)
!460 = !DILocalVariable(name: "__x86_rd_value", scope: !454, file: !123, line: 21, type: !84)
!461 = !DILocalVariable(name: "__x86_l_tag", scope: !462, file: !123, line: 21, type: !57)
!462 = distinct !DILexicalBlock(scope: !463, file: !123, line: 21, column: 2)
!463 = distinct !DILexicalBlock(scope: !464, file: !123, line: 21, column: 2)
!464 = distinct !DILexicalBlock(scope: !454, file: !123, line: 21, column: 2)
!465 = !DILocalVariable(name: "__x86_stack_delta", scope: !466, file: !123, line: 21, type: !84)
!466 = distinct !DILexicalBlock(scope: !463, file: !123, line: 21, column: 2)
!467 = distinct !DIAssignID()
!468 = !DILocation(line: 0, scope: !132)
!469 = distinct !DIAssignID()
!470 = distinct !DIAssignID()
!471 = distinct !DIAssignID()
!472 = distinct !DIAssignID()
!473 = distinct !DIAssignID()
!474 = distinct !DIAssignID()
!475 = distinct !DIAssignID()
!476 = !DILocation(line: 9, column: 2, scope: !170)
!477 = !{i64 2148856508}
!478 = !DILocation(line: 0, scope: !170)
!479 = !DILocation(line: 9, column: 2, scope: !174)
!480 = !{i64 2148856976}
!481 = !DILocation(line: 0, scope: !174)
!482 = !DILocation(line: 9, column: 2, scope: !178)
!483 = !{i64 2148857444}
!484 = !DILocation(line: 0, scope: !178)
!485 = !DILocation(line: 9, column: 2, scope: !182)
!486 = !{i64 2148857912}
!487 = !DILocation(line: 0, scope: !182)
!488 = !DILocation(line: 9, column: 2, scope: !188)
!489 = !{i64 2148858848}
!490 = !DILocation(line: 0, scope: !188)
!491 = !DILocation(line: 9, column: 2, scope: !192)
!492 = !{i64 2148859316}
!493 = !DILocation(line: 0, scope: !192)
!494 = !DILocation(line: 9, column: 2, scope: !196)
!495 = !{i64 2148859784}
!496 = !DILocation(line: 0, scope: !196)
!497 = !DILocation(line: 9, column: 2, scope: !200)
!498 = !{i64 2148860249}
!499 = !DILocation(line: 0, scope: !200)
!500 = !DILocation(line: 9, column: 2, scope: !204)
!501 = !{i64 2148860713}
!502 = !DILocation(line: 0, scope: !204)
!503 = !DILocation(line: 9, column: 2, scope: !208)
!504 = !{i64 2148861182}
!505 = !DILocation(line: 0, scope: !208)
!506 = !DILocation(line: 9, column: 2, scope: !212)
!507 = !{i64 2148861652}
!508 = !DILocation(line: 0, scope: !212)
!509 = !DILocation(line: 9, column: 2, scope: !216)
!510 = !{i64 2148862122}
!511 = !DILocation(line: 0, scope: !216)
!512 = !DILocation(line: 9, column: 2, scope: !220)
!513 = !{i64 2148862592}
!514 = !DILocation(line: 0, scope: !220)
!515 = !DILocation(line: 9, column: 2, scope: !224)
!516 = !{i64 2148863062}
!517 = !DILocation(line: 0, scope: !224)
!518 = !DILocation(line: 9, column: 2, scope: !228)
!519 = !{i64 2148863532}
!520 = !DILocation(line: 0, scope: !228)
!521 = !DILocation(line: 9, column: 2, scope: !233)
!522 = !{i64 2148863803}
!523 = !DILocation(line: 0, scope: !233)
!524 = !DILocation(line: 9, column: 2, scope: !236)
!525 = !{i64 2148864057}
!526 = !DILocation(line: 0, scope: !236)
!527 = !DILocation(line: 9, column: 2, scope: !239)
!528 = !{i64 2148864311}
!529 = !DILocation(line: 0, scope: !239)
!530 = !DILocation(line: 9, column: 2, scope: !242)
!531 = !{i64 2148864565}
!532 = !DILocation(line: 0, scope: !242)
!533 = !DILocation(line: 9, column: 2, scope: !245)
!534 = !{i64 2148864819}
!535 = !DILocation(line: 0, scope: !245)
!536 = !DILocation(line: 9, column: 2, scope: !248)
!537 = !{i64 2148865073}
!538 = !DILocation(line: 0, scope: !248)
!539 = !DILocation(line: 9, column: 2, scope: !251)
!540 = !{i64 2148865327}
!541 = !DILocation(line: 0, scope: !251)
!542 = !DILocation(line: 9, column: 2, scope: !254)
!543 = !{i64 2148865581}
!544 = !DILocation(line: 0, scope: !254)
!545 = !DILocation(line: 9, column: 2, scope: !132)
!546 = !DILocation(line: 9, column: 2, scope: !267)
!547 = !{i64 2148866053}
!548 = !DILocation(line: 0, scope: !267)
!549 = !DILocation(line: 10, column: 1, scope: !132)
!550 = !DILocation(line: 0, scope: !270)
!551 = !DILocation(line: 0, scope: !348)
!552 = !DILocation(line: 0, scope: !350)
!553 = !DILocation(line: 12, column: 2, scope: !350)
!554 = !{!555, !555, i64 0}
!555 = !{!"omnipotent char", !556, i64 0}
!556 = !{!"Simple C/C++ TBAA"}
!557 = !DILocation(line: 12, column: 2, scope: !558)
!558 = distinct !DILexicalBlock(scope: !350, file: !123, line: 12, column: 2)
!559 = !DILocation(line: 12, column: 2, scope: !560)
!560 = distinct !DILexicalBlock(scope: !350, file: !123, line: 12, column: 2)
!561 = !DILocation(line: 12, column: 2, scope: !562)
!562 = distinct !DILexicalBlock(scope: !350, file: !123, line: 12, column: 2)
!563 = !DILocation(line: 12, column: 2, scope: !564)
!564 = distinct !DILexicalBlock(scope: !350, file: !123, line: 12, column: 2)
!565 = !DILocation(line: 12, column: 2, scope: !566)
!566 = distinct !DILexicalBlock(scope: !350, file: !123, line: 12, column: 2)
!567 = !DILocation(line: 12, column: 2, scope: !568)
!568 = distinct !DILexicalBlock(scope: !350, file: !123, line: 12, column: 2)
!569 = !DILocation(line: 13, column: 1, scope: !132)
!570 = !DILocation(line: 16, column: 1, scope: !132)
!571 = !DILocation(line: 22, column: 1, scope: !132)
