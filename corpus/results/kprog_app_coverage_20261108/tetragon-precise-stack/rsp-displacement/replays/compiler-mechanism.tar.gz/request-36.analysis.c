#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1)
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rdx,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSP, X86_WIDTH_64);
x86_l_3:
	/* 0x3: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_7:
	/* 0x7: mov    QWORD PTR [rsp],0x25 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 37ULL);
x86_l_f:
	/* 0xf: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_14:
	/* 0x14: shl    rcx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_18:
	/* 0x18: add    rsp,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSP, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1b:
	/* 0x1b: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f:
	/* 0x1f: mov    rsp,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSP, X86_RDX, X86_WIDTH_64);
x86_l_22:
	/* 0x22: jmp    27 <entry+0x27> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_27:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
