; ModuleID = '/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c'
source_filename = "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

@LICENSE = dso_local global [4 x i8] c"GPL\00", section "license", align 1, !dbg !0
@llvm.compiler.used = appending global [2 x ptr] [ptr @LICENSE, ptr @trusted_x86_x86_sim_xdp], section "llvm.metadata"

; Function Attrs: nounwind
define dso_local i32 @trusted_x86_x86_sim_xdp(ptr nocapture readnone %0) #0 section "xdp" !dbg !135 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !148, metadata !DIExpression()), !dbg !598
  call void @llvm.dbg.assign(metadata i8 0, metadata !149, metadata !DIExpression(), metadata !599, metadata ptr undef, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr null, metadata !156, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !157, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !158, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !160, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr null, metadata !161, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr null, metadata !162, metadata !DIExpression()), !dbg !598
  %2 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !600, !srcloc !601
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !172, metadata !DIExpression()), !dbg !602
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !163, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !174, metadata !DIExpression()), !dbg !598
  %3 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !603, !srcloc !604
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !176, metadata !DIExpression()), !dbg !605
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !175, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !178, metadata !DIExpression()), !dbg !598
  %4 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !606, !srcloc !607
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !180, metadata !DIExpression()), !dbg !608
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !179, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !182, metadata !DIExpression()), !dbg !598
  %5 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !609, !srcloc !610
  tail call void @llvm.dbg.value(metadata i64 %5, metadata !184, metadata !DIExpression()), !dbg !611
  tail call void @llvm.dbg.value(metadata i64 %5, metadata !183, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !186, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr null, metadata !187, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !188, metadata !DIExpression()), !dbg !598
  %6 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !612, !srcloc !613
  tail call void @llvm.dbg.value(metadata i64 %6, metadata !190, metadata !DIExpression()), !dbg !614
  tail call void @llvm.dbg.value(metadata i64 %6, metadata !189, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !192, metadata !DIExpression()), !dbg !598
  %7 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !615, !srcloc !616
  tail call void @llvm.dbg.value(metadata i64 %7, metadata !194, metadata !DIExpression()), !dbg !617
  tail call void @llvm.dbg.value(metadata i64 %7, metadata !193, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !196, metadata !DIExpression()), !dbg !598
  %8 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !618, !srcloc !619
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !198, metadata !DIExpression()), !dbg !620
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !197, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !200, metadata !DIExpression()), !dbg !598
  %9 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !621, !srcloc !622
  tail call void @llvm.dbg.value(metadata i64 %9, metadata !202, metadata !DIExpression()), !dbg !623
  tail call void @llvm.dbg.value(metadata i64 %9, metadata !201, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !204, metadata !DIExpression()), !dbg !598
  %10 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !624, !srcloc !625
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !206, metadata !DIExpression()), !dbg !626
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !205, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !208, metadata !DIExpression()), !dbg !598
  %11 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !627, !srcloc !628
  tail call void @llvm.dbg.value(metadata i64 %11, metadata !210, metadata !DIExpression()), !dbg !629
  tail call void @llvm.dbg.value(metadata i64 %11, metadata !209, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !212, metadata !DIExpression()), !dbg !598
  %12 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !630, !srcloc !631
  tail call void @llvm.dbg.value(metadata i64 %12, metadata !214, metadata !DIExpression()), !dbg !632
  tail call void @llvm.dbg.value(metadata i64 %12, metadata !213, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !216, metadata !DIExpression()), !dbg !598
  %13 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !633, !srcloc !634
  tail call void @llvm.dbg.value(metadata i64 %13, metadata !218, metadata !DIExpression()), !dbg !635
  tail call void @llvm.dbg.value(metadata i64 %13, metadata !217, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !220, metadata !DIExpression()), !dbg !598
  %14 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !636, !srcloc !637
  tail call void @llvm.dbg.value(metadata i64 %14, metadata !222, metadata !DIExpression()), !dbg !638
  tail call void @llvm.dbg.value(metadata i64 %14, metadata !221, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !224, metadata !DIExpression()), !dbg !598
  %15 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !639, !srcloc !640
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !226, metadata !DIExpression()), !dbg !641
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !225, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !228, metadata !DIExpression()), !dbg !598
  %16 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !642, !srcloc !643
  tail call void @llvm.dbg.value(metadata i64 %16, metadata !230, metadata !DIExpression()), !dbg !644
  tail call void @llvm.dbg.value(metadata i64 %16, metadata !229, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 0, metadata !232, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i64 0, metadata !233, metadata !DIExpression()), !dbg !598
  %17 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !645, !srcloc !646
  tail call void @llvm.dbg.value(metadata i64 %17, metadata !235, metadata !DIExpression()), !dbg !647
  tail call void @llvm.dbg.value(metadata i64 %17, metadata !234, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !598
  %18 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !648, !srcloc !649
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !238, metadata !DIExpression()), !dbg !650
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !237, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !598
  %19 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !651, !srcloc !652
  tail call void @llvm.dbg.value(metadata i64 %19, metadata !241, metadata !DIExpression()), !dbg !653
  tail call void @llvm.dbg.value(metadata i64 %19, metadata !240, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !598
  %20 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !654, !srcloc !655
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !244, metadata !DIExpression()), !dbg !656
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !243, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !598
  %21 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !657, !srcloc !658
  tail call void @llvm.dbg.value(metadata i64 %21, metadata !247, metadata !DIExpression()), !dbg !659
  tail call void @llvm.dbg.value(metadata i64 %21, metadata !246, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !598
  %22 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !660, !srcloc !661
  tail call void @llvm.dbg.value(metadata i64 %22, metadata !250, metadata !DIExpression()), !dbg !662
  tail call void @llvm.dbg.value(metadata i64 %22, metadata !249, metadata !DIExpression(DW_OP_constu, 1, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !598
  %23 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !663, !srcloc !664
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !253, metadata !DIExpression()), !dbg !665
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !252, metadata !DIExpression()), !dbg !598
  %24 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #3, !dbg !666, !srcloc !667
  tail call void @llvm.dbg.value(metadata i64 %24, metadata !256, metadata !DIExpression()), !dbg !668
  tail call void @llvm.dbg.value(metadata i64 %24, metadata !255, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i64 0, metadata !258, metadata !DIExpression()), !dbg !598
  %25 = tail call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590037175) #3, !dbg !669, !srcloc !670
  tail call void @llvm.dbg.value(metadata i64 %25, metadata !269, metadata !DIExpression()), !dbg !671
  tail call void @llvm.dbg.value(metadata i64 %25, metadata !233, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 1, metadata !160, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !161, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !162, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !197, metadata !DIExpression()), !dbg !598
  tail call void @llvm.dbg.value(metadata i8 1, metadata !200, metadata !DIExpression()), !dbg !598
  call void @llvm.dbg.label(metadata !271), !dbg !672
  tail call void @llvm.dbg.value(metadata !DIArgList(i8 poison, i8 poison, i8 poison, i8 poison, i8 poison, i8 poison, i8 poison, i8 poison), metadata !163, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 8, DW_OP_shl, DW_OP_LLVM_arg, 7, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_LLVM_arg, 6, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 16, DW_OP_shl, DW_OP_or, DW_OP_LLVM_arg, 5, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 24, DW_OP_shl, DW_OP_or, DW_OP_LLVM_arg, 4, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_LLVM_arg, 3, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 40, DW_OP_shl, DW_OP_or, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 48, DW_OP_shl, DW_OP_or, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 56, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !598
  call void @llvm.dbg.label(metadata !568), !dbg !673
  ret i32 poison, !dbg !674
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #2

attributes #0 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="v4" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!129, !130, !131, !132, !133}
!llvm.ident = !{!134}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !126, line: 21, type: !127, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !125, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "aa0a81fd15e76983e5e2b451ce29f641")
!4 = !{!5, !114, !57, !10, !115, !84, !117, !118, !119, !120, !52, !123}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__sk_buff", file: !7, line: 6347, size: 1536, elements: !8)
!7 = !DIFile(filename: "vendor/libbpf/include/uapi/linux/bpf.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "af3577c2b1c2566ad76f1bd2c69dbe37")
!8 = !{!9, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24, !28, !29, !30, !31, !32, !33, !34, !35, !36, !40, !41, !42, !43, !44, !83, !86, !87, !88, !111, !112, !113}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !6, file: !7, line: 6348, baseType: !10, size: 32)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !11, line: 27, baseType: !12)
!11 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "", checksumkind: CSK_MD5, checksum: "b810f270733e106319b67ef512c6246e")
!12 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "pkt_type", scope: !6, file: !7, line: 6349, baseType: !10, size: 32, offset: 32)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !6, file: !7, line: 6350, baseType: !10, size: 32, offset: 64)
!15 = !DIDerivedType(tag: DW_TAG_member, name: "queue_mapping", scope: !6, file: !7, line: 6351, baseType: !10, size: 32, offset: 96)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !6, file: !7, line: 6352, baseType: !10, size: 32, offset: 128)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_present", scope: !6, file: !7, line: 6353, baseType: !10, size: 32, offset: 160)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_tci", scope: !6, file: !7, line: 6354, baseType: !10, size: 32, offset: 192)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_proto", scope: !6, file: !7, line: 6355, baseType: !10, size: 32, offset: 224)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !6, file: !7, line: 6356, baseType: !10, size: 32, offset: 256)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !6, file: !7, line: 6357, baseType: !10, size: 32, offset: 288)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !6, file: !7, line: 6358, baseType: !10, size: 32, offset: 320)
!23 = !DIDerivedType(tag: DW_TAG_member, name: "tc_index", scope: !6, file: !7, line: 6359, baseType: !10, size: 32, offset: 352)
!24 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !6, file: !7, line: 6360, baseType: !25, size: 160, offset: 384)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 160, elements: !26)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "hash", scope: !6, file: !7, line: 6361, baseType: !10, size: 32, offset: 544)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "tc_classid", scope: !6, file: !7, line: 6362, baseType: !10, size: 32, offset: 576)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !6, file: !7, line: 6363, baseType: !10, size: 32, offset: 608)
!31 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !6, file: !7, line: 6364, baseType: !10, size: 32, offset: 640)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !6, file: !7, line: 6365, baseType: !10, size: 32, offset: 672)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !6, file: !7, line: 6368, baseType: !10, size: 32, offset: 704)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip4", scope: !6, file: !7, line: 6369, baseType: !10, size: 32, offset: 736)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip4", scope: !6, file: !7, line: 6370, baseType: !10, size: 32, offset: 768)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip6", scope: !6, file: !7, line: 6371, baseType: !37, size: 128, offset: 800)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 128, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 4)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip6", scope: !6, file: !7, line: 6372, baseType: !37, size: 128, offset: 928)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "remote_port", scope: !6, file: !7, line: 6373, baseType: !10, size: 32, offset: 1056)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "local_port", scope: !6, file: !7, line: 6374, baseType: !10, size: 32, offset: 1088)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !6, file: !7, line: 6377, baseType: !10, size: 32, offset: 1120)
!44 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6378, baseType: !45, size: 64, align: 64, offset: 1152)
!45 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6378, size: 64, align: 64, elements: !46)
!46 = !{!47}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "flow_keys", scope: !45, file: !7, line: 6378, baseType: !48, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_flow_keys", file: !7, line: 7436, size: 448, elements: !50)
!50 = !{!51, !54, !55, !56, !59, !60, !61, !62, !65, !66, !67, !81, !82}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "nhoff", scope: !49, file: !7, line: 7437, baseType: !52, size: 16)
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !11, line: 24, baseType: !53)
!53 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "thoff", scope: !49, file: !7, line: 7438, baseType: !52, size: 16, offset: 16)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "addr_proto", scope: !49, file: !7, line: 7439, baseType: !52, size: 16, offset: 32)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "is_frag", scope: !49, file: !7, line: 7440, baseType: !57, size: 8, offset: 48)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !11, line: 21, baseType: !58)
!58 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "is_first_frag", scope: !49, file: !7, line: 7441, baseType: !57, size: 8, offset: 56)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "is_encap", scope: !49, file: !7, line: 7442, baseType: !57, size: 8, offset: 64)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "ip_proto", scope: !49, file: !7, line: 7443, baseType: !57, size: 8, offset: 72)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "n_proto", scope: !49, file: !7, line: 7444, baseType: !63, size: 16, offset: 80)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !64, line: 32, baseType: !52)
!64 = !DIFile(filename: "/usr/include/linux/types.h", directory: "", checksumkind: CSK_MD5, checksum: "bf9fbc0e8f60927fef9d8917535375a6")
!65 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !49, file: !7, line: 7445, baseType: !63, size: 16, offset: 96)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !49, file: !7, line: 7446, baseType: !63, size: 16, offset: 112)
!67 = !DIDerivedType(tag: DW_TAG_member, scope: !49, file: !7, line: 7447, baseType: !68, size: 256, offset: 128)
!68 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !49, file: !7, line: 7447, size: 256, elements: !69)
!69 = !{!70, !76}
!70 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7448, baseType: !71, size: 64)
!71 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7448, size: 64, elements: !72)
!72 = !{!73, !75}
!73 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !71, file: !7, line: 7449, baseType: !74, size: 32)
!74 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !64, line: 34, baseType: !10)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !71, file: !7, line: 7450, baseType: !74, size: 32, offset: 32)
!76 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7452, baseType: !77, size: 256)
!77 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7452, size: 256, elements: !78)
!78 = !{!79, !80}
!79 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !77, file: !7, line: 7453, baseType: !37, size: 128)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !77, file: !7, line: 7454, baseType: !37, size: 128, offset: 128)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !49, file: !7, line: 7457, baseType: !10, size: 32, offset: 384)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "flow_label", scope: !49, file: !7, line: 7458, baseType: !74, size: 32, offset: 416)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp", scope: !6, file: !7, line: 6379, baseType: !84, size: 64, offset: 1216)
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !11, line: 31, baseType: !85)
!85 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "wire_len", scope: !6, file: !7, line: 6380, baseType: !10, size: 32, offset: 1280)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "gso_segs", scope: !6, file: !7, line: 6381, baseType: !10, size: 32, offset: 1312)
!88 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6382, baseType: !89, size: 64, align: 64, offset: 1344)
!89 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6382, size: 64, align: 64, elements: !90)
!90 = !{!91}
!91 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !89, file: !7, line: 6382, baseType: !92, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !93, size: 64)
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !7, line: 6451, size: 640, elements: !94)
!94 = !{!95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !93, file: !7, line: 6452, baseType: !10, size: 32)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !93, file: !7, line: 6453, baseType: !10, size: 32, offset: 32)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !93, file: !7, line: 6454, baseType: !10, size: 32, offset: 64)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !93, file: !7, line: 6455, baseType: !10, size: 32, offset: 96)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !93, file: !7, line: 6456, baseType: !10, size: 32, offset: 128)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !93, file: !7, line: 6457, baseType: !10, size: 32, offset: 160)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !93, file: !7, line: 6459, baseType: !10, size: 32, offset: 192)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !93, file: !7, line: 6460, baseType: !37, size: 128, offset: 224)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !93, file: !7, line: 6461, baseType: !10, size: 32, offset: 352)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !93, file: !7, line: 6462, baseType: !63, size: 16, offset: 384)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !93, file: !7, line: 6464, baseType: !10, size: 32, offset: 416)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !93, file: !7, line: 6465, baseType: !37, size: 128, offset: 448)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !93, file: !7, line: 6466, baseType: !10, size: 32, offset: 576)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !93, file: !7, line: 6467, baseType: !109, size: 32, offset: 608)
!109 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !11, line: 26, baseType: !110)
!110 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "gso_size", scope: !6, file: !7, line: 6383, baseType: !10, size: 32, offset: 1408)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp_type", scope: !6, file: !7, line: 6384, baseType: !57, size: 8, offset: 1440)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "hwtstamp", scope: !6, file: !7, line: 6386, baseType: !84, size: 64, offset: 1472)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!115 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s64", file: !11, line: 30, baseType: !116)
!116 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!117 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!118 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!119 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!120 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !121, size: 64)
!121 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !122)
!122 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !57)
!123 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !124, size: 64)
!124 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !114)
!125 = !{!0}
!126 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "aa0a81fd15e76983e5e2b451ce29f641")
!127 = !DICompositeType(tag: DW_TAG_array_type, baseType: !128, size: 32, elements: !38)
!128 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!129 = !{i32 7, !"Dwarf Version", i32 5}
!130 = !{i32 2, !"Debug Info Version", i32 3}
!131 = !{i32 1, !"wchar_size", i32 4}
!132 = !{i32 7, !"frame-pointer", i32 2}
!133 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!134 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!135 = distinct !DISubprogram(name: "trusted_x86_x86_sim_xdp", scope: !126, file: !126, line: 7, type: !136, scopeLine: 8, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !147)
!136 = !DISubroutineType(types: !137)
!137 = !{!110, !138}
!138 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !139, size: 64)
!139 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !7, line: 6567, size: 192, elements: !140)
!140 = !{!141, !142, !143, !144, !145, !146}
!141 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !139, file: !7, line: 6568, baseType: !10, size: 32)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !139, file: !7, line: 6569, baseType: !10, size: 32, offset: 32)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !139, file: !7, line: 6570, baseType: !10, size: 32, offset: 64)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !139, file: !7, line: 6572, baseType: !10, size: 32, offset: 96)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !139, file: !7, line: 6573, baseType: !10, size: 32, offset: 128)
!146 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !139, file: !7, line: 6575, baseType: !10, size: 32, offset: 160)
!147 = !{!148, !149, !156, !157, !158, !159, !160, !161, !162, !163, !172, !174, !175, !176, !178, !179, !180, !182, !183, !184, !186, !187, !188, !189, !190, !192, !193, !194, !196, !197, !198, !200, !201, !202, !204, !205, !206, !208, !209, !210, !212, !213, !214, !216, !217, !218, !220, !221, !222, !224, !225, !226, !228, !229, !230, !232, !233, !234, !235, !237, !238, !240, !241, !243, !244, !246, !247, !249, !250, !252, !253, !255, !256, !258, !259, !269, !271, !272, !274, !276, !277, !279, !282, !283, !285, !286, !288, !289, !290, !293, !294, !295, !296, !297, !298, !301, !304, !305, !306, !307, !310, !314, !317, !320, !321, !324, !325, !328, !329, !332, !335, !338, !340, !343, !345, !346, !347, !350, !351, !354, !355, !356, !357, !363, !373, !379, !389, !392, !394, !396, !399, !400, !401, !403, !404, !405, !408, !409, !411, !414, !415, !419, !420, !425, !427, !428, !431, !432, !434, !435, !436, !437, !443, !453, !459, !469, !473, !474, !475, !476, !482, !492, !498, !508, !509, !511, !512, !513, !516, !517, !520, !521, !524, !526, !527, !530, !531, !533, !534, !535, !536, !542, !552, !558, !568, !569, !572, !573, !574, !575, !576, !577, !581, !583, !584, !587, !588, !589, !590, !591, !592, !596}
!148 = !DILocalVariable(name: "ctx", arg: 1, scope: !135, file: !126, line: 7, type: !138)
!149 = !DILocalVariable(name: "__x86_sim_abi", scope: !135, file: !126, line: 9, type: !150)
!150 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_xdp_abi", file: !151, line: 64, size: 320, elements: !152)
!151 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim_local_bpf.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "cdf042bef0d13fcc12d092b7f12f07bf")
!152 = !{!153, !154, !155}
!153 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !150, file: !151, line: 65, baseType: !114, size: 64)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !150, file: !151, line: 66, baseType: !114, size: 64, offset: 64)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !150, file: !151, line: 67, baseType: !25, size: 160, offset: 128)
!156 = !DILocalVariable(name: "__x86_sim_skb_ctx", scope: !135, file: !126, line: 9, type: !5)
!157 = !DILocalVariable(name: "__x86_sim_abi_kind", scope: !135, file: !126, line: 9, type: !57)
!158 = !DILocalVariable(name: "__x86_stack_value_tag_0", scope: !135, file: !126, line: 9, type: !57)
!159 = !DILocalVariable(name: "__x86_stack_value_ptr_0", scope: !135, file: !126, line: 9, type: !114)
!160 = !DILocalVariable(name: "__x86_sim_is_xdp", scope: !135, file: !126, line: 9, type: !57)
!161 = !DILocalVariable(name: "__x86_sim_helper_ctx", scope: !135, file: !126, line: 9, type: !114)
!162 = !DILocalVariable(name: "__x86_sim_helper_abi_base", scope: !135, file: !126, line: 9, type: !114)
!163 = !DILocalVariable(name: "__x86_rax", scope: !135, file: !126, line: 9, type: !164)
!164 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_gpr", file: !151, line: 90, size: 64, elements: !165)
!165 = !{!166, !167, !168}
!166 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !164, file: !151, line: 91, baseType: !114, size: 64)
!167 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !164, file: !151, line: 92, baseType: !52, size: 16)
!168 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !164, file: !151, line: 93, baseType: !169, size: 64)
!169 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 64, elements: !170)
!170 = !{!171}
!171 = !DISubrange(count: 8)
!172 = !DILocalVariable(name: "__native_value", scope: !173, file: !126, line: 9, type: !118)
!173 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!174 = !DILocalVariable(name: "__x86_rax_tag", scope: !135, file: !126, line: 9, type: !57)
!175 = !DILocalVariable(name: "__x86_rcx", scope: !135, file: !126, line: 9, type: !164)
!176 = !DILocalVariable(name: "__native_value", scope: !177, file: !126, line: 9, type: !118)
!177 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!178 = !DILocalVariable(name: "__x86_rcx_tag", scope: !135, file: !126, line: 9, type: !57)
!179 = !DILocalVariable(name: "__x86_rdx", scope: !135, file: !126, line: 9, type: !164)
!180 = !DILocalVariable(name: "__native_value", scope: !181, file: !126, line: 9, type: !118)
!181 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!182 = !DILocalVariable(name: "__x86_rdx_tag", scope: !135, file: !126, line: 9, type: !57)
!183 = !DILocalVariable(name: "__x86_rbx", scope: !135, file: !126, line: 9, type: !164)
!184 = !DILocalVariable(name: "__native_value", scope: !185, file: !126, line: 9, type: !118)
!185 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!186 = !DILocalVariable(name: "__x86_rbx_tag", scope: !135, file: !126, line: 9, type: !57)
!187 = !DILocalVariable(name: "__x86_rsp", scope: !135, file: !126, line: 9, type: !164)
!188 = !DILocalVariable(name: "__x86_rsp_tag", scope: !135, file: !126, line: 9, type: !57)
!189 = !DILocalVariable(name: "__x86_rbp", scope: !135, file: !126, line: 9, type: !164)
!190 = !DILocalVariable(name: "__native_value", scope: !191, file: !126, line: 9, type: !118)
!191 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!192 = !DILocalVariable(name: "__x86_rbp_tag", scope: !135, file: !126, line: 9, type: !57)
!193 = !DILocalVariable(name: "__x86_rsi", scope: !135, file: !126, line: 9, type: !164)
!194 = !DILocalVariable(name: "__native_value", scope: !195, file: !126, line: 9, type: !118)
!195 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!196 = !DILocalVariable(name: "__x86_rsi_tag", scope: !135, file: !126, line: 9, type: !57)
!197 = !DILocalVariable(name: "__x86_rdi", scope: !135, file: !126, line: 9, type: !164)
!198 = !DILocalVariable(name: "__native_value", scope: !199, file: !126, line: 9, type: !118)
!199 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!200 = !DILocalVariable(name: "__x86_rdi_tag", scope: !135, file: !126, line: 9, type: !57)
!201 = !DILocalVariable(name: "__x86_r8", scope: !135, file: !126, line: 9, type: !164)
!202 = !DILocalVariable(name: "__native_value", scope: !203, file: !126, line: 9, type: !118)
!203 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!204 = !DILocalVariable(name: "__x86_r8_tag", scope: !135, file: !126, line: 9, type: !57)
!205 = !DILocalVariable(name: "__x86_r9", scope: !135, file: !126, line: 9, type: !164)
!206 = !DILocalVariable(name: "__native_value", scope: !207, file: !126, line: 9, type: !118)
!207 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!208 = !DILocalVariable(name: "__x86_r9_tag", scope: !135, file: !126, line: 9, type: !57)
!209 = !DILocalVariable(name: "__x86_r10", scope: !135, file: !126, line: 9, type: !164)
!210 = !DILocalVariable(name: "__native_value", scope: !211, file: !126, line: 9, type: !118)
!211 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!212 = !DILocalVariable(name: "__x86_r10_tag", scope: !135, file: !126, line: 9, type: !57)
!213 = !DILocalVariable(name: "__x86_r11", scope: !135, file: !126, line: 9, type: !164)
!214 = !DILocalVariable(name: "__native_value", scope: !215, file: !126, line: 9, type: !118)
!215 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!216 = !DILocalVariable(name: "__x86_r11_tag", scope: !135, file: !126, line: 9, type: !57)
!217 = !DILocalVariable(name: "__x86_r12", scope: !135, file: !126, line: 9, type: !164)
!218 = !DILocalVariable(name: "__native_value", scope: !219, file: !126, line: 9, type: !118)
!219 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!220 = !DILocalVariable(name: "__x86_r12_tag", scope: !135, file: !126, line: 9, type: !57)
!221 = !DILocalVariable(name: "__x86_r13", scope: !135, file: !126, line: 9, type: !164)
!222 = !DILocalVariable(name: "__native_value", scope: !223, file: !126, line: 9, type: !118)
!223 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!224 = !DILocalVariable(name: "__x86_r13_tag", scope: !135, file: !126, line: 9, type: !57)
!225 = !DILocalVariable(name: "__x86_r14", scope: !135, file: !126, line: 9, type: !164)
!226 = !DILocalVariable(name: "__native_value", scope: !227, file: !126, line: 9, type: !118)
!227 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!228 = !DILocalVariable(name: "__x86_r14_tag", scope: !135, file: !126, line: 9, type: !57)
!229 = !DILocalVariable(name: "__x86_r15", scope: !135, file: !126, line: 9, type: !164)
!230 = !DILocalVariable(name: "__native_value", scope: !231, file: !126, line: 9, type: !118)
!231 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!232 = !DILocalVariable(name: "__x86_r15_tag", scope: !135, file: !126, line: 9, type: !57)
!233 = !DILocalVariable(name: "__x86_native_stack_base", scope: !135, file: !126, line: 9, type: !84)
!234 = !DILocalVariable(name: "__x86_cf", scope: !135, file: !126, line: 9, type: !57)
!235 = !DILocalVariable(name: "__native_value", scope: !236, file: !126, line: 9, type: !118)
!236 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!237 = !DILocalVariable(name: "__x86_zf", scope: !135, file: !126, line: 9, type: !57)
!238 = !DILocalVariable(name: "__native_value", scope: !239, file: !126, line: 9, type: !118)
!239 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!240 = !DILocalVariable(name: "__x86_sf", scope: !135, file: !126, line: 9, type: !57)
!241 = !DILocalVariable(name: "__native_value", scope: !242, file: !126, line: 9, type: !118)
!242 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!243 = !DILocalVariable(name: "__x86_of", scope: !135, file: !126, line: 9, type: !57)
!244 = !DILocalVariable(name: "__native_value", scope: !245, file: !126, line: 9, type: !118)
!245 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!246 = !DILocalVariable(name: "__x86_pf", scope: !135, file: !126, line: 9, type: !57)
!247 = !DILocalVariable(name: "__native_value", scope: !248, file: !126, line: 9, type: !118)
!248 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!249 = !DILocalVariable(name: "__x86_af", scope: !135, file: !126, line: 9, type: !57)
!250 = !DILocalVariable(name: "__native_value", scope: !251, file: !126, line: 9, type: !118)
!251 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!252 = !DILocalVariable(name: "__x86_xmm0_lo", scope: !135, file: !126, line: 9, type: !84)
!253 = !DILocalVariable(name: "__native_value", scope: !254, file: !126, line: 9, type: !118)
!254 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!255 = !DILocalVariable(name: "__x86_xmm0_hi", scope: !135, file: !126, line: 9, type: !84)
!256 = !DILocalVariable(name: "__native_value", scope: !257, file: !126, line: 9, type: !118)
!257 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!258 = !DILocalVariable(name: "__x86_sim_ret_addr", scope: !135, file: !126, line: 9, type: !84)
!259 = !DILocalVariable(name: "__x86_stack_mem", scope: !135, file: !126, line: 9, type: !260)
!260 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !261)
!261 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 9, size: 64, elements: !262)
!262 = !{!263, !267}
!263 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !261, file: !126, line: 9, baseType: !264, size: 8)
!264 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 8, elements: !265)
!265 = !{!266}
!266 = !DISubrange(count: 1)
!267 = !DIDerivedType(tag: DW_TAG_member, name: "q", scope: !261, file: !126, line: 9, baseType: !268, size: 64)
!268 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 64, elements: !265)
!269 = !DILocalVariable(name: "__native_value", scope: !270, file: !126, line: 9, type: !118)
!270 = distinct !DILexicalBlock(scope: !135, file: !126, line: 9, column: 2)
!271 = !DILabel(scope: !135, name: "x86_l_0", file: !126, line: 10)
!272 = !DILocalVariable(name: "__x86_l_write_width", scope: !273, file: !126, line: 12, type: !57)
!273 = distinct !DILexicalBlock(scope: !135, file: !126, line: 12, column: 2)
!274 = !DILocalVariable(name: "__kprog_x86_ml_write", scope: !275, file: !126, line: 12, type: !57)
!275 = distinct !DILexicalBlock(scope: !273, file: !126, line: 12, column: 2)
!276 = !DILocalVariable(name: "__x86_l_mem_width", scope: !273, file: !126, line: 12, type: !57)
!277 = !DILocalVariable(name: "__kprog_x86_ml_mem", scope: !278, file: !126, line: 12, type: !57)
!278 = distinct !DILexicalBlock(scope: !273, file: !126, line: 12, column: 2)
!279 = !DILocalVariable(name: "__kprog_x86_ml_write", scope: !280, file: !126, line: 12, type: !57)
!280 = distinct !DILexicalBlock(scope: !281, file: !126, line: 12, column: 2)
!281 = distinct !DILexicalBlock(scope: !278, file: !126, line: 12, column: 2)
!282 = !DILocalVariable(name: "__x86_l_arm", scope: !273, file: !126, line: 12, type: !57)
!283 = !DILocalVariable(name: "__kprog_x86_ml_arm", scope: !284, file: !126, line: 12, type: !57)
!284 = distinct !DILexicalBlock(scope: !273, file: !126, line: 12, column: 2)
!285 = !DILocalVariable(name: "__x86_l_disp", scope: !273, file: !126, line: 12, type: !115)
!286 = !DILocalVariable(name: "__kprog_x86_mo_disp", scope: !287, file: !126, line: 12, type: !115)
!287 = distinct !DILexicalBlock(scope: !273, file: !126, line: 12, column: 2)
!288 = !DILocalVariable(name: "__kprog_x86_mo_has_index", scope: !287, file: !126, line: 12, type: !110)
!289 = !DILocalVariable(name: "__kprog_x86_mo_result", scope: !287, file: !126, line: 12, type: !84)
!290 = !DILocalVariable(name: "__kprog_x86_mo_scale", scope: !291, file: !126, line: 12, type: !57)
!291 = distinct !DILexicalBlock(scope: !292, file: !126, line: 12, column: 2)
!292 = distinct !DILexicalBlock(scope: !287, file: !126, line: 12, column: 2)
!293 = !DILocalVariable(name: "__kprog_x86_mo_index", scope: !291, file: !126, line: 12, type: !84)
!294 = !DILocalVariable(name: "__x86_l_meta_disp", scope: !273, file: !126, line: 12, type: !115)
!295 = !DILocalVariable(name: "__x86_l_base_ptr", scope: !273, file: !126, line: 12, type: !114)
!296 = !DILocalVariable(name: "__x86_l_value", scope: !273, file: !126, line: 12, type: !84)
!297 = !DILocalVariable(name: "__x86_l_addr", scope: !273, file: !126, line: 12, type: !114)
!298 = !DILocalVariable(name: "__x86_l_tag", scope: !299, file: !126, line: 12, type: !57)
!299 = distinct !DILexicalBlock(scope: !300, file: !126, line: 12, column: 2)
!300 = distinct !DILexicalBlock(scope: !273, file: !126, line: 12, column: 2)
!301 = !DILocalVariable(name: "__x86_sr_width", scope: !302, file: !126, line: 12, type: !57)
!302 = distinct !DILexicalBlock(scope: !303, file: !126, line: 12, column: 2)
!303 = distinct !DILexicalBlock(scope: !300, file: !126, line: 12, column: 2)
!304 = !DILocalVariable(name: "__x86_sr_off", scope: !302, file: !126, line: 12, type: !115)
!305 = !DILocalVariable(name: "__x86_sr_ctx", scope: !302, file: !126, line: 12, type: !5)
!306 = !DILocalVariable(name: "__x86_sr_value", scope: !302, file: !126, line: 12, type: !84)
!307 = !DILocalVariable(name: "__x86_sr_lane", scope: !308, file: !126, line: 12, type: !115)
!308 = distinct !DILexicalBlock(scope: !309, file: !126, line: 12, column: 2)
!309 = distinct !DILexicalBlock(scope: !302, file: !126, line: 12, column: 2)
!310 = !DILocalVariable(name: "__x86_sf_value", scope: !311, file: !126, line: 12, type: !84)
!311 = distinct !DILexicalBlock(scope: !312, file: !126, line: 12, column: 2)
!312 = distinct !DILexicalBlock(scope: !313, file: !126, line: 12, column: 2)
!313 = distinct !DILexicalBlock(scope: !308, file: !126, line: 12, column: 2)
!314 = !DILocalVariable(name: "__x86_sf_value", scope: !315, file: !126, line: 12, type: !84)
!315 = distinct !DILexicalBlock(scope: !316, file: !126, line: 12, column: 2)
!316 = distinct !DILexicalBlock(scope: !313, file: !126, line: 12, column: 2)
!317 = !DILocalVariable(name: "__native_value", scope: !318, file: !126, line: 12, type: !118)
!318 = distinct !DILexicalBlock(scope: !319, file: !126, line: 12, column: 2)
!319 = distinct !DILexicalBlock(scope: !308, file: !126, line: 12, column: 2)
!320 = !DILocalVariable(name: "__native_pointer", scope: !318, file: !126, line: 12, type: !118)
!321 = !DILocalVariable(name: "__x86_cbr_value", scope: !322, file: !126, line: 12, type: !84)
!322 = distinct !DILexicalBlock(scope: !323, file: !126, line: 12, column: 2)
!323 = distinct !DILexicalBlock(scope: !309, file: !126, line: 12, column: 2)
!324 = !DILocalVariable(name: "__x86_cbr_temp", scope: !322, file: !126, line: 12, type: !84)
!325 = !DILocalVariable(name: "__x86_cbr_addr", scope: !326, file: !126, line: 12, type: !120)
!326 = distinct !DILexicalBlock(scope: !327, file: !126, line: 12, column: 2)
!327 = distinct !DILexicalBlock(scope: !322, file: !126, line: 12, column: 2)
!328 = !DILocalVariable(name: "__x86_cbr_value", scope: !326, file: !126, line: 12, type: !84)
!329 = !DILocalVariable(name: "__x86_sf_value", scope: !330, file: !126, line: 12, type: !84)
!330 = distinct !DILexicalBlock(scope: !331, file: !126, line: 12, column: 2)
!331 = distinct !DILexicalBlock(scope: !323, file: !126, line: 12, column: 2)
!332 = !DILocalVariable(name: "__x86_sf_value", scope: !333, file: !126, line: 12, type: !84)
!333 = distinct !DILexicalBlock(scope: !334, file: !126, line: 12, column: 2)
!334 = distinct !DILexicalBlock(scope: !331, file: !126, line: 12, column: 2)
!335 = !DILocalVariable(name: "__x86_sf_value", scope: !336, file: !126, line: 12, type: !84)
!336 = distinct !DILexicalBlock(scope: !337, file: !126, line: 12, column: 2)
!337 = distinct !DILexicalBlock(scope: !334, file: !126, line: 12, column: 2)
!338 = !DILocalVariable(name: "__x86_snr_value", scope: !339, file: !126, line: 12, type: !84)
!339 = distinct !DILexicalBlock(scope: !337, file: !126, line: 12, column: 2)
!340 = !DILocalVariable(name: "__x86_skb_tag", scope: !341, file: !126, line: 12, type: !57)
!341 = distinct !DILexicalBlock(scope: !342, file: !126, line: 12, column: 2)
!342 = distinct !DILexicalBlock(scope: !303, file: !126, line: 12, column: 2)
!343 = !DILocalVariable(name: "__kprog_abi_kind", scope: !344, file: !126, line: 12, type: !57)
!344 = distinct !DILexicalBlock(scope: !341, file: !126, line: 12, column: 2)
!345 = !DILocalVariable(name: "__kprog_abi_offset", scope: !344, file: !126, line: 12, type: !115)
!346 = !DILocalVariable(name: "__kprog_abi_tag", scope: !344, file: !126, line: 12, type: !57)
!347 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !348, file: !126, line: 12, type: !114)
!348 = distinct !DILexicalBlock(scope: !349, file: !126, line: 12, column: 2)
!349 = distinct !DILexicalBlock(scope: !341, file: !126, line: 12, column: 2)
!350 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !348, file: !126, line: 12, type: !57)
!351 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !352, file: !126, line: 12, type: !57)
!352 = distinct !DILexicalBlock(scope: !353, file: !126, line: 12, column: 2)
!353 = distinct !DILexicalBlock(scope: !342, file: !126, line: 12, column: 2)
!354 = !DILocalVariable(name: "__x86_wr_width", scope: !352, file: !126, line: 12, type: !57)
!355 = !DILocalVariable(name: "__x86_wr_shift", scope: !352, file: !126, line: 12, type: !57)
!356 = !DILocalVariable(name: "__x86_wr_next", scope: !352, file: !126, line: 12, type: !84)
!357 = !DILocalVariable(name: "__x86_stack_delta", scope: !358, file: !126, line: 12, type: !84)
!358 = distinct !DILexicalBlock(scope: !359, file: !126, line: 12, column: 2)
!359 = distinct !DILexicalBlock(scope: !360, file: !126, line: 12, column: 2)
!360 = distinct !DILexicalBlock(scope: !361, file: !126, line: 12, column: 2)
!361 = distinct !DILexicalBlock(scope: !362, file: !126, line: 12, column: 2)
!362 = distinct !DILexicalBlock(scope: !352, file: !126, line: 12, column: 2)
!363 = !DILocalVariable(name: "__kprog_x86_partial", scope: !364, file: !126, line: 12, type: !367)
!364 = distinct !DILexicalBlock(scope: !365, file: !126, line: 12, column: 2)
!365 = distinct !DILexicalBlock(scope: !366, file: !126, line: 12, column: 2)
!366 = distinct !DILexicalBlock(scope: !361, file: !126, line: 12, column: 2)
!367 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !368)
!368 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !369)
!369 = !{!370, !371, !372}
!370 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !368, file: !126, line: 12, baseType: !114, size: 64)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !368, file: !126, line: 12, baseType: !52, size: 16)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !368, file: !126, line: 12, baseType: !169, size: 64)
!373 = !DILocalVariable(name: "__x86_stack_delta", scope: !374, file: !126, line: 12, type: !84)
!374 = distinct !DILexicalBlock(scope: !375, file: !126, line: 12, column: 2)
!375 = distinct !DILexicalBlock(scope: !376, file: !126, line: 12, column: 2)
!376 = distinct !DILexicalBlock(scope: !377, file: !126, line: 12, column: 2)
!377 = distinct !DILexicalBlock(scope: !378, file: !126, line: 12, column: 2)
!378 = distinct !DILexicalBlock(scope: !362, file: !126, line: 12, column: 2)
!379 = !DILocalVariable(name: "__kprog_x86_partial", scope: !380, file: !126, line: 12, type: !383)
!380 = distinct !DILexicalBlock(scope: !381, file: !126, line: 12, column: 2)
!381 = distinct !DILexicalBlock(scope: !382, file: !126, line: 12, column: 2)
!382 = distinct !DILexicalBlock(scope: !377, file: !126, line: 12, column: 2)
!383 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !384)
!384 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !385)
!385 = !{!386, !387, !388}
!386 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !384, file: !126, line: 12, baseType: !114, size: 64)
!387 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !384, file: !126, line: 12, baseType: !52, size: 16)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !384, file: !126, line: 12, baseType: !169, size: 64)
!389 = !DILocalVariable(name: "__x86_l_tag", scope: !390, file: !126, line: 12, type: !57)
!390 = distinct !DILexicalBlock(scope: !391, file: !126, line: 12, column: 2)
!391 = distinct !DILexicalBlock(scope: !300, file: !126, line: 12, column: 2)
!392 = !DILocalVariable(name: "__x86_xdp_value", scope: !393, file: !126, line: 12, type: !84)
!393 = distinct !DILexicalBlock(scope: !391, file: !126, line: 12, column: 2)
!394 = !DILocalVariable(name: "__x86_xdp_off", scope: !395, file: !126, line: 12, type: !115)
!395 = distinct !DILexicalBlock(scope: !393, file: !126, line: 12, column: 2)
!396 = !DILocalVariable(name: "__x86_xdp_ctx", scope: !395, file: !126, line: 12, type: !397)
!397 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !398, size: 64)
!398 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !139)
!399 = !DILocalVariable(name: "__x86_xdp_value", scope: !395, file: !126, line: 12, type: !84)
!400 = !DILocalVariable(name: "__x86_xdp_tag", scope: !393, file: !126, line: 12, type: !57)
!401 = !DILocalVariable(name: "__kprog_abi_kind", scope: !402, file: !126, line: 12, type: !57)
!402 = distinct !DILexicalBlock(scope: !393, file: !126, line: 12, column: 2)
!403 = !DILocalVariable(name: "__kprog_abi_offset", scope: !402, file: !126, line: 12, type: !115)
!404 = !DILocalVariable(name: "__kprog_abi_tag", scope: !402, file: !126, line: 12, type: !57)
!405 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !406, file: !126, line: 12, type: !114)
!406 = distinct !DILexicalBlock(scope: !407, file: !126, line: 12, column: 2)
!407 = distinct !DILexicalBlock(scope: !393, file: !126, line: 12, column: 2)
!408 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !406, file: !126, line: 12, type: !57)
!409 = !DILocalVariable(name: "__kprog_x86_md_src", scope: !410, file: !126, line: 12, type: !57)
!410 = distinct !DILexicalBlock(scope: !391, file: !126, line: 12, column: 2)
!411 = !DILocalVariable(name: "__x86_str_index", scope: !412, file: !126, line: 12, type: !84)
!412 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!413 = distinct !DILexicalBlock(scope: !391, file: !126, line: 12, column: 2)
!414 = !DILocalVariable(name: "__x86_str_value", scope: !412, file: !126, line: 12, type: !84)
!415 = !DILocalVariable(name: "__x86_str_bytes", scope: !416, file: !126, line: 12, type: !418)
!416 = distinct !DILexicalBlock(scope: !417, file: !126, line: 12, column: 2)
!417 = distinct !DILexicalBlock(scope: !412, file: !126, line: 12, column: 2)
!418 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !122, size: 64)
!419 = !DILocalVariable(name: "__x86_str_width", scope: !416, file: !126, line: 12, type: !57)
!420 = !DILocalVariable(name: "__x86_mv_saved", scope: !413, file: !126, line: 12, type: !421)
!421 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_stack_value", file: !151, line: 246, size: 128, elements: !422)
!422 = !{!423, !424}
!423 = !DIDerivedType(tag: DW_TAG_member, name: "pointer", scope: !421, file: !151, line: 246, baseType: !114, size: 64)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !421, file: !151, line: 246, baseType: !57, size: 8, offset: 64)
!425 = !DILocalVariable(name: "__x86_sv_result", scope: !426, file: !126, line: 12, type: !421)
!426 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!427 = !DILocalVariable(name: "__x86_sv_at", scope: !426, file: !126, line: 12, type: !84)
!428 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !429, file: !126, line: 12, type: !114)
!429 = distinct !DILexicalBlock(scope: !430, file: !126, line: 12, column: 2)
!430 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!431 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !429, file: !126, line: 12, type: !57)
!432 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !433, file: !126, line: 12, type: !57)
!433 = distinct !DILexicalBlock(scope: !430, file: !126, line: 12, column: 2)
!434 = !DILocalVariable(name: "__x86_wr_width", scope: !433, file: !126, line: 12, type: !57)
!435 = !DILocalVariable(name: "__x86_wr_shift", scope: !433, file: !126, line: 12, type: !57)
!436 = !DILocalVariable(name: "__x86_wr_next", scope: !433, file: !126, line: 12, type: !84)
!437 = !DILocalVariable(name: "__x86_stack_delta", scope: !438, file: !126, line: 12, type: !84)
!438 = distinct !DILexicalBlock(scope: !439, file: !126, line: 12, column: 2)
!439 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!440 = distinct !DILexicalBlock(scope: !441, file: !126, line: 12, column: 2)
!441 = distinct !DILexicalBlock(scope: !442, file: !126, line: 12, column: 2)
!442 = distinct !DILexicalBlock(scope: !433, file: !126, line: 12, column: 2)
!443 = !DILocalVariable(name: "__kprog_x86_partial", scope: !444, file: !126, line: 12, type: !447)
!444 = distinct !DILexicalBlock(scope: !445, file: !126, line: 12, column: 2)
!445 = distinct !DILexicalBlock(scope: !446, file: !126, line: 12, column: 2)
!446 = distinct !DILexicalBlock(scope: !441, file: !126, line: 12, column: 2)
!447 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !448)
!448 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !449)
!449 = !{!450, !451, !452}
!450 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !448, file: !126, line: 12, baseType: !114, size: 64)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !448, file: !126, line: 12, baseType: !52, size: 16)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !448, file: !126, line: 12, baseType: !169, size: 64)
!453 = !DILocalVariable(name: "__x86_stack_delta", scope: !454, file: !126, line: 12, type: !84)
!454 = distinct !DILexicalBlock(scope: !455, file: !126, line: 12, column: 2)
!455 = distinct !DILexicalBlock(scope: !456, file: !126, line: 12, column: 2)
!456 = distinct !DILexicalBlock(scope: !457, file: !126, line: 12, column: 2)
!457 = distinct !DILexicalBlock(scope: !458, file: !126, line: 12, column: 2)
!458 = distinct !DILexicalBlock(scope: !442, file: !126, line: 12, column: 2)
!459 = !DILocalVariable(name: "__kprog_x86_partial", scope: !460, file: !126, line: 12, type: !463)
!460 = distinct !DILexicalBlock(scope: !461, file: !126, line: 12, column: 2)
!461 = distinct !DILexicalBlock(scope: !462, file: !126, line: 12, column: 2)
!462 = distinct !DILexicalBlock(scope: !457, file: !126, line: 12, column: 2)
!463 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !464)
!464 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !465)
!465 = !{!466, !467, !468}
!466 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !464, file: !126, line: 12, baseType: !114, size: 64)
!467 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !464, file: !126, line: 12, baseType: !52, size: 16)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !464, file: !126, line: 12, baseType: !169, size: 64)
!469 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !470, file: !126, line: 12, type: !57)
!470 = distinct !DILexicalBlock(scope: !471, file: !126, line: 12, column: 2)
!471 = distinct !DILexicalBlock(scope: !472, file: !126, line: 12, column: 2)
!472 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!473 = !DILocalVariable(name: "__x86_wr_width", scope: !470, file: !126, line: 12, type: !57)
!474 = !DILocalVariable(name: "__x86_wr_shift", scope: !470, file: !126, line: 12, type: !57)
!475 = !DILocalVariable(name: "__x86_wr_next", scope: !470, file: !126, line: 12, type: !84)
!476 = !DILocalVariable(name: "__x86_stack_delta", scope: !477, file: !126, line: 12, type: !84)
!477 = distinct !DILexicalBlock(scope: !478, file: !126, line: 12, column: 2)
!478 = distinct !DILexicalBlock(scope: !479, file: !126, line: 12, column: 2)
!479 = distinct !DILexicalBlock(scope: !480, file: !126, line: 12, column: 2)
!480 = distinct !DILexicalBlock(scope: !481, file: !126, line: 12, column: 2)
!481 = distinct !DILexicalBlock(scope: !470, file: !126, line: 12, column: 2)
!482 = !DILocalVariable(name: "__kprog_x86_partial", scope: !483, file: !126, line: 12, type: !486)
!483 = distinct !DILexicalBlock(scope: !484, file: !126, line: 12, column: 2)
!484 = distinct !DILexicalBlock(scope: !485, file: !126, line: 12, column: 2)
!485 = distinct !DILexicalBlock(scope: !480, file: !126, line: 12, column: 2)
!486 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !487)
!487 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !488)
!488 = !{!489, !490, !491}
!489 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !487, file: !126, line: 12, baseType: !114, size: 64)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !487, file: !126, line: 12, baseType: !52, size: 16)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !487, file: !126, line: 12, baseType: !169, size: 64)
!492 = !DILocalVariable(name: "__x86_stack_delta", scope: !493, file: !126, line: 12, type: !84)
!493 = distinct !DILexicalBlock(scope: !494, file: !126, line: 12, column: 2)
!494 = distinct !DILexicalBlock(scope: !495, file: !126, line: 12, column: 2)
!495 = distinct !DILexicalBlock(scope: !496, file: !126, line: 12, column: 2)
!496 = distinct !DILexicalBlock(scope: !497, file: !126, line: 12, column: 2)
!497 = distinct !DILexicalBlock(scope: !481, file: !126, line: 12, column: 2)
!498 = !DILocalVariable(name: "__kprog_x86_partial", scope: !499, file: !126, line: 12, type: !502)
!499 = distinct !DILexicalBlock(scope: !500, file: !126, line: 12, column: 2)
!500 = distinct !DILexicalBlock(scope: !501, file: !126, line: 12, column: 2)
!501 = distinct !DILexicalBlock(scope: !496, file: !126, line: 12, column: 2)
!502 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !503)
!503 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !504)
!504 = !{!505, !506, !507}
!505 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !503, file: !126, line: 12, baseType: !114, size: 64)
!506 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !503, file: !126, line: 12, baseType: !52, size: 16)
!507 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !503, file: !126, line: 12, baseType: !169, size: 64)
!508 = !DILocalVariable(name: "__x86_l_ptr_tag", scope: !413, file: !126, line: 12, type: !57)
!509 = !DILocalVariable(name: "__kprog_abi_kind", scope: !510, file: !126, line: 12, type: !57)
!510 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!511 = !DILocalVariable(name: "__kprog_abi_offset", scope: !510, file: !126, line: 12, type: !115)
!512 = !DILocalVariable(name: "__kprog_abi_tag", scope: !510, file: !126, line: 12, type: !57)
!513 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !514, file: !126, line: 12, type: !114)
!514 = distinct !DILexicalBlock(scope: !515, file: !126, line: 12, column: 2)
!515 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!516 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !514, file: !126, line: 12, type: !57)
!517 = !DILocalVariable(name: "__x86_l_tag", scope: !518, file: !126, line: 12, type: !57)
!518 = distinct !DILexicalBlock(scope: !519, file: !126, line: 12, column: 2)
!519 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!520 = !DILocalVariable(name: "__x86_mv_alias", scope: !413, file: !126, line: 12, type: !421)
!521 = !DILocalVariable(name: "__x86_l_tag", scope: !522, file: !126, line: 12, type: !57)
!522 = distinct !DILexicalBlock(scope: !523, file: !126, line: 12, column: 2)
!523 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!524 = !DILocalVariable(name: "__x86_sv_result", scope: !525, file: !126, line: 12, type: !421)
!525 = distinct !DILexicalBlock(scope: !523, file: !126, line: 12, column: 2)
!526 = !DILocalVariable(name: "__x86_sv_at", scope: !525, file: !126, line: 12, type: !84)
!527 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !528, file: !126, line: 12, type: !114)
!528 = distinct !DILexicalBlock(scope: !529, file: !126, line: 12, column: 2)
!529 = distinct !DILexicalBlock(scope: !413, file: !126, line: 12, column: 2)
!530 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !528, file: !126, line: 12, type: !57)
!531 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !532, file: !126, line: 12, type: !57)
!532 = distinct !DILexicalBlock(scope: !529, file: !126, line: 12, column: 2)
!533 = !DILocalVariable(name: "__x86_wr_width", scope: !532, file: !126, line: 12, type: !57)
!534 = !DILocalVariable(name: "__x86_wr_shift", scope: !532, file: !126, line: 12, type: !57)
!535 = !DILocalVariable(name: "__x86_wr_next", scope: !532, file: !126, line: 12, type: !84)
!536 = !DILocalVariable(name: "__x86_stack_delta", scope: !537, file: !126, line: 12, type: !84)
!537 = distinct !DILexicalBlock(scope: !538, file: !126, line: 12, column: 2)
!538 = distinct !DILexicalBlock(scope: !539, file: !126, line: 12, column: 2)
!539 = distinct !DILexicalBlock(scope: !540, file: !126, line: 12, column: 2)
!540 = distinct !DILexicalBlock(scope: !541, file: !126, line: 12, column: 2)
!541 = distinct !DILexicalBlock(scope: !532, file: !126, line: 12, column: 2)
!542 = !DILocalVariable(name: "__kprog_x86_partial", scope: !543, file: !126, line: 12, type: !546)
!543 = distinct !DILexicalBlock(scope: !544, file: !126, line: 12, column: 2)
!544 = distinct !DILexicalBlock(scope: !545, file: !126, line: 12, column: 2)
!545 = distinct !DILexicalBlock(scope: !540, file: !126, line: 12, column: 2)
!546 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !547)
!547 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !548)
!548 = !{!549, !550, !551}
!549 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !547, file: !126, line: 12, baseType: !114, size: 64)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !547, file: !126, line: 12, baseType: !52, size: 16)
!551 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !547, file: !126, line: 12, baseType: !169, size: 64)
!552 = !DILocalVariable(name: "__x86_stack_delta", scope: !553, file: !126, line: 12, type: !84)
!553 = distinct !DILexicalBlock(scope: !554, file: !126, line: 12, column: 2)
!554 = distinct !DILexicalBlock(scope: !555, file: !126, line: 12, column: 2)
!555 = distinct !DILexicalBlock(scope: !556, file: !126, line: 12, column: 2)
!556 = distinct !DILexicalBlock(scope: !557, file: !126, line: 12, column: 2)
!557 = distinct !DILexicalBlock(scope: !541, file: !126, line: 12, column: 2)
!558 = !DILocalVariable(name: "__kprog_x86_partial", scope: !559, file: !126, line: 12, type: !562)
!559 = distinct !DILexicalBlock(scope: !560, file: !126, line: 12, column: 2)
!560 = distinct !DILexicalBlock(scope: !561, file: !126, line: 12, column: 2)
!561 = distinct !DILexicalBlock(scope: !556, file: !126, line: 12, column: 2)
!562 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !563)
!563 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !135, file: !126, line: 12, size: 64, elements: !564)
!564 = !{!565, !566, !567}
!565 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !563, file: !126, line: 12, baseType: !114, size: 64)
!566 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !563, file: !126, line: 12, baseType: !52, size: 16)
!567 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !563, file: !126, line: 12, baseType: !169, size: 64)
!568 = !DILabel(scope: !135, name: "x86_l_8", file: !126, line: 13)
!569 = !DILocalVariable(name: "__x86_rd_reg", scope: !570, file: !126, line: 15, type: !57)
!570 = distinct !DILexicalBlock(scope: !571, file: !126, line: 15, column: 2)
!571 = distinct !DILexicalBlock(scope: !135, file: !126, line: 15, column: 2)
!572 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !570, file: !126, line: 15, type: !57)
!573 = !DILocalVariable(name: "__x86_rd_width", scope: !570, file: !126, line: 15, type: !57)
!574 = !DILocalVariable(name: "__x86_rd_shift", scope: !570, file: !126, line: 15, type: !57)
!575 = !DILocalVariable(name: "__x86_rd_ptr", scope: !570, file: !126, line: 15, type: !114)
!576 = !DILocalVariable(name: "__x86_rd_value", scope: !570, file: !126, line: 15, type: !84)
!577 = !DILocalVariable(name: "__x86_l_tag", scope: !578, file: !126, line: 15, type: !57)
!578 = distinct !DILexicalBlock(scope: !579, file: !126, line: 15, column: 2)
!579 = distinct !DILexicalBlock(scope: !580, file: !126, line: 15, column: 2)
!580 = distinct !DILexicalBlock(scope: !570, file: !126, line: 15, column: 2)
!581 = !DILocalVariable(name: "__x86_stack_delta", scope: !582, file: !126, line: 15, type: !84)
!582 = distinct !DILexicalBlock(scope: !579, file: !126, line: 15, column: 2)
!583 = !DILabel(scope: !135, name: "x86_l_d", file: !126, line: 16)
!584 = !DILocalVariable(name: "__x86_rd_reg", scope: !585, file: !126, line: 18, type: !57)
!585 = distinct !DILexicalBlock(scope: !586, file: !126, line: 18, column: 2)
!586 = distinct !DILexicalBlock(scope: !135, file: !126, line: 18, column: 2)
!587 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !585, file: !126, line: 18, type: !57)
!588 = !DILocalVariable(name: "__x86_rd_width", scope: !585, file: !126, line: 18, type: !57)
!589 = !DILocalVariable(name: "__x86_rd_shift", scope: !585, file: !126, line: 18, type: !57)
!590 = !DILocalVariable(name: "__x86_rd_ptr", scope: !585, file: !126, line: 18, type: !114)
!591 = !DILocalVariable(name: "__x86_rd_value", scope: !585, file: !126, line: 18, type: !84)
!592 = !DILocalVariable(name: "__x86_l_tag", scope: !593, file: !126, line: 18, type: !57)
!593 = distinct !DILexicalBlock(scope: !594, file: !126, line: 18, column: 2)
!594 = distinct !DILexicalBlock(scope: !595, file: !126, line: 18, column: 2)
!595 = distinct !DILexicalBlock(scope: !585, file: !126, line: 18, column: 2)
!596 = !DILocalVariable(name: "__x86_stack_delta", scope: !597, file: !126, line: 18, type: !84)
!597 = distinct !DILexicalBlock(scope: !594, file: !126, line: 18, column: 2)
!598 = !DILocation(line: 0, scope: !135)
!599 = distinct !DIAssignID()
!600 = !DILocation(line: 9, column: 2, scope: !173)
!601 = !{i64 2148856433}
!602 = !DILocation(line: 0, scope: !173)
!603 = !DILocation(line: 9, column: 2, scope: !177)
!604 = !{i64 2148856901}
!605 = !DILocation(line: 0, scope: !177)
!606 = !DILocation(line: 9, column: 2, scope: !181)
!607 = !{i64 2148857369}
!608 = !DILocation(line: 0, scope: !181)
!609 = !DILocation(line: 9, column: 2, scope: !185)
!610 = !{i64 2148857837}
!611 = !DILocation(line: 0, scope: !185)
!612 = !DILocation(line: 9, column: 2, scope: !191)
!613 = !{i64 2148858773}
!614 = !DILocation(line: 0, scope: !191)
!615 = !DILocation(line: 9, column: 2, scope: !195)
!616 = !{i64 2148859241}
!617 = !DILocation(line: 0, scope: !195)
!618 = !DILocation(line: 9, column: 2, scope: !199)
!619 = !{i64 2148859709}
!620 = !DILocation(line: 0, scope: !199)
!621 = !DILocation(line: 9, column: 2, scope: !203)
!622 = !{i64 2148860174}
!623 = !DILocation(line: 0, scope: !203)
!624 = !DILocation(line: 9, column: 2, scope: !207)
!625 = !{i64 2148860638}
!626 = !DILocation(line: 0, scope: !207)
!627 = !DILocation(line: 9, column: 2, scope: !211)
!628 = !{i64 2148861107}
!629 = !DILocation(line: 0, scope: !211)
!630 = !DILocation(line: 9, column: 2, scope: !215)
!631 = !{i64 2148861577}
!632 = !DILocation(line: 0, scope: !215)
!633 = !DILocation(line: 9, column: 2, scope: !219)
!634 = !{i64 2148862047}
!635 = !DILocation(line: 0, scope: !219)
!636 = !DILocation(line: 9, column: 2, scope: !223)
!637 = !{i64 2148862517}
!638 = !DILocation(line: 0, scope: !223)
!639 = !DILocation(line: 9, column: 2, scope: !227)
!640 = !{i64 2148862987}
!641 = !DILocation(line: 0, scope: !227)
!642 = !DILocation(line: 9, column: 2, scope: !231)
!643 = !{i64 2148863457}
!644 = !DILocation(line: 0, scope: !231)
!645 = !DILocation(line: 9, column: 2, scope: !236)
!646 = !{i64 2148863728}
!647 = !DILocation(line: 0, scope: !236)
!648 = !DILocation(line: 9, column: 2, scope: !239)
!649 = !{i64 2148863982}
!650 = !DILocation(line: 0, scope: !239)
!651 = !DILocation(line: 9, column: 2, scope: !242)
!652 = !{i64 2148864236}
!653 = !DILocation(line: 0, scope: !242)
!654 = !DILocation(line: 9, column: 2, scope: !245)
!655 = !{i64 2148864490}
!656 = !DILocation(line: 0, scope: !245)
!657 = !DILocation(line: 9, column: 2, scope: !248)
!658 = !{i64 2148864744}
!659 = !DILocation(line: 0, scope: !248)
!660 = !DILocation(line: 9, column: 2, scope: !251)
!661 = !{i64 2148864998}
!662 = !DILocation(line: 0, scope: !251)
!663 = !DILocation(line: 9, column: 2, scope: !254)
!664 = !{i64 2148865252}
!665 = !DILocation(line: 0, scope: !254)
!666 = !DILocation(line: 9, column: 2, scope: !257)
!667 = !{i64 2148865506}
!668 = !DILocation(line: 0, scope: !257)
!669 = !DILocation(line: 9, column: 2, scope: !270)
!670 = !{i64 2148865978}
!671 = !DILocation(line: 0, scope: !270)
!672 = !DILocation(line: 10, column: 1, scope: !135)
!673 = !DILocation(line: 13, column: 1, scope: !135)
!674 = !DILocation(line: 19, column: 1, scope: !135)
