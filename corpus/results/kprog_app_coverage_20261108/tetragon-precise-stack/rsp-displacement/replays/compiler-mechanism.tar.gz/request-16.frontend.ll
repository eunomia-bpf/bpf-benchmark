; ModuleID = '/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c'
source_filename = "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

%struct.x86_sim_xdp_abi = type { ptr, ptr, [5 x i32] }
%union.x86_sim_gpr = type { ptr }
%union.anon = type { [1 x i64] }
%union.anon.0 = type { ptr }
%union.anon.1 = type { ptr }
%struct.x86_sim_stack_value = type { ptr, i8 }
%union.anon.2 = type { ptr }
%union.anon.3 = type { ptr }
%union.anon.4 = type { ptr }
%union.anon.5 = type { ptr }
%union.anon.6 = type { ptr }
%union.anon.7 = type { ptr }
%struct.xdp_md = type { i32, i32, i32, i32, i32, i32 }

@LICENSE = dso_local global [4 x i8] c"GPL\00", section "license", align 1, !dbg !0
@llvm.compiler.used = appending global [2 x ptr] [ptr @trusted_x86_x86_sim_xdp, ptr @LICENSE], section "llvm.metadata"

; Function Attrs: noinline nounwind
define dso_local i32 @trusted_x86_x86_sim_xdp(ptr noundef %0) #0 section "xdp" !dbg !134 {
  %2 = alloca i8, align 1
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  %6 = alloca i8, align 1
  %7 = alloca i8, align 1
  %8 = alloca i8, align 1
  %9 = alloca i8, align 1
  %10 = alloca i8, align 1
  %11 = alloca i8, align 1
  %12 = alloca i64, align 8
  %13 = alloca ptr, align 8
  %14 = alloca i8, align 1
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca ptr, align 8
  %18 = alloca i8, align 1
  %19 = alloca i64, align 8
  %20 = alloca i64, align 8
  %21 = alloca ptr, align 8
  %22 = alloca i64, align 8
  %23 = alloca i8, align 1
  %24 = alloca i64, align 8
  %25 = alloca i64, align 8
  %26 = alloca ptr, align 8
  %27 = alloca i64, align 8
  %28 = alloca i8, align 1
  %29 = alloca i64, align 8
  %30 = alloca i64, align 8
  %31 = alloca ptr, align 8
  %32 = alloca i64, align 8
  %33 = alloca i8, align 1
  %34 = alloca i64, align 8
  %35 = alloca i64, align 8
  %36 = alloca i8, align 1
  %37 = alloca i64, align 8
  %38 = alloca i8, align 1
  %39 = alloca i64, align 8
  %40 = alloca i8, align 1
  %41 = alloca i64, align 8
  %42 = alloca i8, align 1
  %43 = alloca i64, align 8
  %44 = alloca i64, align 8
  %45 = alloca i64, align 8
  %46 = alloca i32, align 4
  %47 = alloca ptr, align 8
  %48 = alloca %struct.x86_sim_xdp_abi, align 8
  %49 = alloca ptr, align 8
  %50 = alloca i8, align 1
  %51 = alloca i8, align 1
  %52 = alloca ptr, align 8
  %53 = alloca i8, align 1
  %54 = alloca ptr, align 8
  %55 = alloca ptr, align 8
  %56 = alloca %union.x86_sim_gpr, align 8
  %57 = alloca i64, align 8
  %58 = alloca i64, align 8
  %59 = alloca i8, align 1
  %60 = alloca %union.x86_sim_gpr, align 8
  %61 = alloca i64, align 8
  %62 = alloca i64, align 8
  %63 = alloca i8, align 1
  %64 = alloca %union.x86_sim_gpr, align 8
  %65 = alloca i64, align 8
  %66 = alloca i64, align 8
  %67 = alloca i8, align 1
  %68 = alloca %union.x86_sim_gpr, align 8
  %69 = alloca i64, align 8
  %70 = alloca i64, align 8
  %71 = alloca i8, align 1
  %72 = alloca %union.x86_sim_gpr, align 8
  %73 = alloca i8, align 1
  %74 = alloca %union.x86_sim_gpr, align 8
  %75 = alloca i64, align 8
  %76 = alloca i64, align 8
  %77 = alloca i8, align 1
  %78 = alloca %union.x86_sim_gpr, align 8
  %79 = alloca i64, align 8
  %80 = alloca i64, align 8
  %81 = alloca i8, align 1
  %82 = alloca %union.x86_sim_gpr, align 8
  %83 = alloca i64, align 8
  %84 = alloca i64, align 8
  %85 = alloca i8, align 1
  %86 = alloca %union.x86_sim_gpr, align 8
  %87 = alloca i64, align 8
  %88 = alloca i64, align 8
  %89 = alloca i8, align 1
  %90 = alloca %union.x86_sim_gpr, align 8
  %91 = alloca i64, align 8
  %92 = alloca i64, align 8
  %93 = alloca i8, align 1
  %94 = alloca %union.x86_sim_gpr, align 8
  %95 = alloca i64, align 8
  %96 = alloca i64, align 8
  %97 = alloca i8, align 1
  %98 = alloca %union.x86_sim_gpr, align 8
  %99 = alloca i64, align 8
  %100 = alloca i64, align 8
  %101 = alloca i8, align 1
  %102 = alloca %union.x86_sim_gpr, align 8
  %103 = alloca i64, align 8
  %104 = alloca i64, align 8
  %105 = alloca i8, align 1
  %106 = alloca %union.x86_sim_gpr, align 8
  %107 = alloca i64, align 8
  %108 = alloca i64, align 8
  %109 = alloca i8, align 1
  %110 = alloca %union.x86_sim_gpr, align 8
  %111 = alloca i64, align 8
  %112 = alloca i64, align 8
  %113 = alloca i8, align 1
  %114 = alloca %union.x86_sim_gpr, align 8
  %115 = alloca i64, align 8
  %116 = alloca i64, align 8
  %117 = alloca i8, align 1
  %118 = alloca i64, align 8
  %119 = alloca i8, align 1
  %120 = alloca i64, align 8
  %121 = alloca i64, align 8
  %122 = alloca i8, align 1
  %123 = alloca i64, align 8
  %124 = alloca i64, align 8
  %125 = alloca i8, align 1
  %126 = alloca i64, align 8
  %127 = alloca i64, align 8
  %128 = alloca i8, align 1
  %129 = alloca i64, align 8
  %130 = alloca i64, align 8
  %131 = alloca i8, align 1
  %132 = alloca i64, align 8
  %133 = alloca i64, align 8
  %134 = alloca i8, align 1
  %135 = alloca i64, align 8
  %136 = alloca i64, align 8
  %137 = alloca i64, align 8
  %138 = alloca i64, align 8
  %139 = alloca i64, align 8
  %140 = alloca i64, align 8
  %141 = alloca i64, align 8
  %142 = alloca i64, align 8
  %143 = alloca i64, align 8
  %144 = alloca %union.anon, align 8
  %145 = alloca i64, align 8
  %146 = alloca i64, align 8
  %147 = alloca i8, align 1
  %148 = alloca i8, align 1
  %149 = alloca i8, align 1
  %150 = alloca i8, align 1
  %151 = alloca i8, align 1
  %152 = alloca i8, align 1
  %153 = alloca i8, align 1
  %154 = alloca i8, align 1
  %155 = alloca i8, align 1
  %156 = alloca i8, align 1
  %157 = alloca i8, align 1
  %158 = alloca i64, align 8
  %159 = alloca i64, align 8
  %160 = alloca i32, align 4
  %161 = alloca i64, align 8
  %162 = alloca i8, align 1
  %163 = alloca i64, align 8
  %164 = alloca i64, align 8
  %165 = alloca i64, align 8
  %166 = alloca ptr, align 8
  %167 = alloca i64, align 8
  %168 = alloca ptr, align 8
  %169 = alloca i8, align 1
  %170 = alloca i8, align 1
  %171 = alloca i8, align 1
  %172 = alloca i64, align 8
  %173 = alloca ptr, align 8
  %174 = alloca i64, align 8
  %175 = alloca i64, align 8
  %176 = alloca i64, align 8
  %177 = alloca i64, align 8
  %178 = alloca i64, align 8
  %179 = alloca i64, align 8
  %180 = alloca i64, align 8
  %181 = alloca i64, align 8
  %182 = alloca i64, align 8
  %183 = alloca i64, align 8
  %184 = alloca i64, align 8
  %185 = alloca ptr, align 8
  %186 = alloca i64, align 8
  %187 = alloca i64, align 8
  %188 = alloca i64, align 8
  %189 = alloca i64, align 8
  %190 = alloca i64, align 8
  %191 = alloca i64, align 8
  %192 = alloca i64, align 8
  %193 = alloca i64, align 8
  %194 = alloca i64, align 8
  %195 = alloca i64, align 8
  %196 = alloca i64, align 8
  %197 = alloca i64, align 8
  %198 = alloca i8, align 1
  %199 = alloca i8, align 1
  %200 = alloca i64, align 8
  %201 = alloca i8, align 1
  %202 = alloca i8, align 1
  %203 = alloca ptr, align 8
  %204 = alloca i8, align 1
  %205 = alloca i8, align 1
  %206 = alloca i8, align 1
  %207 = alloca i8, align 1
  %208 = alloca i64, align 8
  %209 = alloca i64, align 8
  %210 = alloca i64, align 8
  %211 = alloca %union.anon.0, align 8
  %212 = alloca i64, align 8
  %213 = alloca i64, align 8
  %214 = alloca %union.anon.1, align 8
  %215 = alloca i8, align 1
  %216 = alloca i8, align 1
  %217 = alloca i64, align 8
  %218 = alloca i64, align 8
  %219 = alloca ptr, align 8
  %220 = alloca i64, align 8
  %221 = alloca i64, align 8
  %222 = alloca i8, align 1
  %223 = alloca i8, align 1
  %224 = alloca i64, align 8
  %225 = alloca i8, align 1
  %226 = alloca i8, align 1
  %227 = alloca ptr, align 8
  %228 = alloca i8, align 1
  %229 = alloca i8, align 1
  %230 = alloca i8, align 1
  %231 = alloca i64, align 8
  %232 = alloca i64, align 8
  %233 = alloca ptr, align 8
  %234 = alloca i8, align 1
  %235 = alloca i64, align 8
  %236 = alloca %struct.x86_sim_stack_value, align 8
  %237 = alloca %struct.x86_sim_stack_value, align 8
  %238 = alloca i64, align 8
  %239 = alloca ptr, align 8
  %240 = alloca i8, align 1
  %241 = alloca i8, align 1
  %242 = alloca i8, align 1
  %243 = alloca i8, align 1
  %244 = alloca i64, align 8
  %245 = alloca i64, align 8
  %246 = alloca i64, align 8
  %247 = alloca %union.anon.2, align 8
  %248 = alloca i64, align 8
  %249 = alloca i64, align 8
  %250 = alloca %union.anon.3, align 8
  %251 = alloca i8, align 1
  %252 = alloca i8, align 1
  %253 = alloca i8, align 1
  %254 = alloca i64, align 8
  %255 = alloca i64, align 8
  %256 = alloca i64, align 8
  %257 = alloca %union.anon.4, align 8
  %258 = alloca i64, align 8
  %259 = alloca i64, align 8
  %260 = alloca %union.anon.5, align 8
  %261 = alloca i8, align 1
  %262 = alloca i8, align 1
  %263 = alloca i64, align 8
  %264 = alloca i8, align 1
  %265 = alloca i8, align 1
  %266 = alloca ptr, align 8
  %267 = alloca i8, align 1
  %268 = alloca i8, align 1
  %269 = alloca i8, align 1
  %270 = alloca %struct.x86_sim_stack_value, align 8
  %271 = alloca i8, align 1
  %272 = alloca i8, align 1
  %273 = alloca %struct.x86_sim_stack_value, align 8
  %274 = alloca i64, align 8
  %275 = alloca ptr, align 8
  %276 = alloca i8, align 1
  %277 = alloca i8, align 1
  %278 = alloca i8, align 1
  %279 = alloca i8, align 1
  %280 = alloca i64, align 8
  %281 = alloca i64, align 8
  %282 = alloca i64, align 8
  %283 = alloca %union.anon.6, align 8
  %284 = alloca i64, align 8
  %285 = alloca i64, align 8
  %286 = alloca %union.anon.7, align 8
  %287 = alloca i8, align 1
  %288 = alloca i8, align 1
  %289 = alloca i8, align 1
  %290 = alloca i8, align 1
  %291 = alloca ptr, align 8
  %292 = alloca i64, align 8
  %293 = alloca i8, align 1
  %294 = alloca i8, align 1
  %295 = alloca i64, align 8
  %296 = alloca i64, align 8
  %297 = alloca i64, align 8
  %298 = alloca i8, align 1
  %299 = alloca i8, align 1
  %300 = alloca i8, align 1
  %301 = alloca i8, align 1
  %302 = alloca ptr, align 8
  %303 = alloca i64, align 8
  %304 = alloca i8, align 1
  %305 = alloca i8, align 1
  %306 = alloca i64, align 8
  %307 = alloca i64, align 8
  %308 = alloca i64, align 8
  store ptr %0, ptr %47, align 8
  call void @llvm.dbg.declare(metadata ptr %47, metadata !147, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.declare(metadata ptr %48, metadata !149, metadata !DIExpression()), !dbg !156
  call void @llvm.memset.p0.i64(ptr align 8 %48, i8 0, i64 40, i1 false), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %49, metadata !157, metadata !DIExpression()), !dbg !156
  store ptr null, ptr %49, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %50, metadata !158, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %50, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %51, metadata !159, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %51, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %52, metadata !160, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %53, metadata !161, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %53, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %54, metadata !162, metadata !DIExpression()), !dbg !156
  store ptr null, ptr %54, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %55, metadata !163, metadata !DIExpression()), !dbg !156
  store ptr null, ptr %55, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %56, metadata !164, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %57, metadata !173, metadata !DIExpression()), !dbg !175
  %309 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !175, !srcloc !176
  store i64 %309, ptr %57, align 8, !dbg !175
  %310 = load i64, ptr %57, align 8, !dbg !175
  store i64 %310, ptr %58, align 8, !dbg !175
  %311 = load i64, ptr %58, align 8, !dbg !175
  %312 = inttoptr i64 %311 to ptr, !dbg !156
  store ptr %312, ptr %56, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %59, metadata !177, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %59, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %60, metadata !178, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %61, metadata !179, metadata !DIExpression()), !dbg !181
  %313 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !181, !srcloc !182
  store i64 %313, ptr %61, align 8, !dbg !181
  %314 = load i64, ptr %61, align 8, !dbg !181
  store i64 %314, ptr %62, align 8, !dbg !181
  %315 = load i64, ptr %62, align 8, !dbg !181
  %316 = inttoptr i64 %315 to ptr, !dbg !156
  store ptr %316, ptr %60, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %63, metadata !183, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %63, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %64, metadata !184, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %65, metadata !185, metadata !DIExpression()), !dbg !187
  %317 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !187, !srcloc !188
  store i64 %317, ptr %65, align 8, !dbg !187
  %318 = load i64, ptr %65, align 8, !dbg !187
  store i64 %318, ptr %66, align 8, !dbg !187
  %319 = load i64, ptr %66, align 8, !dbg !187
  %320 = inttoptr i64 %319 to ptr, !dbg !156
  store ptr %320, ptr %64, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %67, metadata !189, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %67, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %68, metadata !190, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %69, metadata !191, metadata !DIExpression()), !dbg !193
  %321 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !193, !srcloc !194
  store i64 %321, ptr %69, align 8, !dbg !193
  %322 = load i64, ptr %69, align 8, !dbg !193
  store i64 %322, ptr %70, align 8, !dbg !193
  %323 = load i64, ptr %70, align 8, !dbg !193
  %324 = inttoptr i64 %323 to ptr, !dbg !156
  store ptr %324, ptr %68, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %71, metadata !195, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %71, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %72, metadata !196, metadata !DIExpression()), !dbg !156
  call void @llvm.memset.p0.i64(ptr align 8 %72, i8 0, i64 8, i1 false), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %73, metadata !197, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %73, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %74, metadata !198, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %75, metadata !199, metadata !DIExpression()), !dbg !201
  %325 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !201, !srcloc !202
  store i64 %325, ptr %75, align 8, !dbg !201
  %326 = load i64, ptr %75, align 8, !dbg !201
  store i64 %326, ptr %76, align 8, !dbg !201
  %327 = load i64, ptr %76, align 8, !dbg !201
  %328 = inttoptr i64 %327 to ptr, !dbg !156
  store ptr %328, ptr %74, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %77, metadata !203, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %77, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %78, metadata !204, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %79, metadata !205, metadata !DIExpression()), !dbg !207
  %329 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !207, !srcloc !208
  store i64 %329, ptr %79, align 8, !dbg !207
  %330 = load i64, ptr %79, align 8, !dbg !207
  store i64 %330, ptr %80, align 8, !dbg !207
  %331 = load i64, ptr %80, align 8, !dbg !207
  %332 = inttoptr i64 %331 to ptr, !dbg !156
  store ptr %332, ptr %78, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %81, metadata !209, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %81, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %82, metadata !210, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %83, metadata !211, metadata !DIExpression()), !dbg !213
  %333 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !213, !srcloc !214
  store i64 %333, ptr %83, align 8, !dbg !213
  %334 = load i64, ptr %83, align 8, !dbg !213
  store i64 %334, ptr %84, align 8, !dbg !213
  %335 = load i64, ptr %84, align 8, !dbg !213
  %336 = inttoptr i64 %335 to ptr, !dbg !156
  store ptr %336, ptr %82, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %85, metadata !215, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %85, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %86, metadata !216, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %87, metadata !217, metadata !DIExpression()), !dbg !219
  %337 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !219, !srcloc !220
  store i64 %337, ptr %87, align 8, !dbg !219
  %338 = load i64, ptr %87, align 8, !dbg !219
  store i64 %338, ptr %88, align 8, !dbg !219
  %339 = load i64, ptr %88, align 8, !dbg !219
  %340 = inttoptr i64 %339 to ptr, !dbg !156
  store ptr %340, ptr %86, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %89, metadata !221, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %89, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %90, metadata !222, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %91, metadata !223, metadata !DIExpression()), !dbg !225
  %341 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !225, !srcloc !226
  store i64 %341, ptr %91, align 8, !dbg !225
  %342 = load i64, ptr %91, align 8, !dbg !225
  store i64 %342, ptr %92, align 8, !dbg !225
  %343 = load i64, ptr %92, align 8, !dbg !225
  %344 = inttoptr i64 %343 to ptr, !dbg !156
  store ptr %344, ptr %90, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %93, metadata !227, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %93, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %94, metadata !228, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %95, metadata !229, metadata !DIExpression()), !dbg !231
  %345 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !231, !srcloc !232
  store i64 %345, ptr %95, align 8, !dbg !231
  %346 = load i64, ptr %95, align 8, !dbg !231
  store i64 %346, ptr %96, align 8, !dbg !231
  %347 = load i64, ptr %96, align 8, !dbg !231
  %348 = inttoptr i64 %347 to ptr, !dbg !156
  store ptr %348, ptr %94, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %97, metadata !233, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %97, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %98, metadata !234, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %99, metadata !235, metadata !DIExpression()), !dbg !237
  %349 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !237, !srcloc !238
  store i64 %349, ptr %99, align 8, !dbg !237
  %350 = load i64, ptr %99, align 8, !dbg !237
  store i64 %350, ptr %100, align 8, !dbg !237
  %351 = load i64, ptr %100, align 8, !dbg !237
  %352 = inttoptr i64 %351 to ptr, !dbg !156
  store ptr %352, ptr %98, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %101, metadata !239, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %101, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %102, metadata !240, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %103, metadata !241, metadata !DIExpression()), !dbg !243
  %353 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !243, !srcloc !244
  store i64 %353, ptr %103, align 8, !dbg !243
  %354 = load i64, ptr %103, align 8, !dbg !243
  store i64 %354, ptr %104, align 8, !dbg !243
  %355 = load i64, ptr %104, align 8, !dbg !243
  %356 = inttoptr i64 %355 to ptr, !dbg !156
  store ptr %356, ptr %102, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %105, metadata !245, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %105, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %106, metadata !246, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %107, metadata !247, metadata !DIExpression()), !dbg !249
  %357 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !249, !srcloc !250
  store i64 %357, ptr %107, align 8, !dbg !249
  %358 = load i64, ptr %107, align 8, !dbg !249
  store i64 %358, ptr %108, align 8, !dbg !249
  %359 = load i64, ptr %108, align 8, !dbg !249
  %360 = inttoptr i64 %359 to ptr, !dbg !156
  store ptr %360, ptr %106, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %109, metadata !251, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %109, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %110, metadata !252, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %111, metadata !253, metadata !DIExpression()), !dbg !255
  %361 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !255, !srcloc !256
  store i64 %361, ptr %111, align 8, !dbg !255
  %362 = load i64, ptr %111, align 8, !dbg !255
  store i64 %362, ptr %112, align 8, !dbg !255
  %363 = load i64, ptr %112, align 8, !dbg !255
  %364 = inttoptr i64 %363 to ptr, !dbg !156
  store ptr %364, ptr %110, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %113, metadata !257, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %113, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %114, metadata !258, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %115, metadata !259, metadata !DIExpression()), !dbg !261
  %365 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !261, !srcloc !262
  store i64 %365, ptr %115, align 8, !dbg !261
  %366 = load i64, ptr %115, align 8, !dbg !261
  store i64 %366, ptr %116, align 8, !dbg !261
  %367 = load i64, ptr %116, align 8, !dbg !261
  %368 = inttoptr i64 %367 to ptr, !dbg !156
  store ptr %368, ptr %114, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %117, metadata !263, metadata !DIExpression()), !dbg !156
  store i8 0, ptr %117, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %118, metadata !264, metadata !DIExpression()), !dbg !156
  store i64 0, ptr %118, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %119, metadata !265, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %120, metadata !266, metadata !DIExpression()), !dbg !268
  %369 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !268, !srcloc !269
  store i64 %369, ptr %120, align 8, !dbg !268
  %370 = load i64, ptr %120, align 8, !dbg !268
  store i64 %370, ptr %121, align 8, !dbg !268
  %371 = load i64, ptr %121, align 8, !dbg !268
  %372 = and i64 %371, 1, !dbg !156
  %373 = trunc i64 %372 to i8, !dbg !156
  store i8 %373, ptr %119, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %122, metadata !270, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %123, metadata !271, metadata !DIExpression()), !dbg !273
  %374 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !273, !srcloc !274
  store i64 %374, ptr %123, align 8, !dbg !273
  %375 = load i64, ptr %123, align 8, !dbg !273
  store i64 %375, ptr %124, align 8, !dbg !273
  %376 = load i64, ptr %124, align 8, !dbg !273
  %377 = and i64 %376, 1, !dbg !156
  %378 = trunc i64 %377 to i8, !dbg !156
  store i8 %378, ptr %122, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %125, metadata !275, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %126, metadata !276, metadata !DIExpression()), !dbg !278
  %379 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !278, !srcloc !279
  store i64 %379, ptr %126, align 8, !dbg !278
  %380 = load i64, ptr %126, align 8, !dbg !278
  store i64 %380, ptr %127, align 8, !dbg !278
  %381 = load i64, ptr %127, align 8, !dbg !278
  %382 = and i64 %381, 1, !dbg !156
  %383 = trunc i64 %382 to i8, !dbg !156
  store i8 %383, ptr %125, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %128, metadata !280, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %129, metadata !281, metadata !DIExpression()), !dbg !283
  %384 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !283, !srcloc !284
  store i64 %384, ptr %129, align 8, !dbg !283
  %385 = load i64, ptr %129, align 8, !dbg !283
  store i64 %385, ptr %130, align 8, !dbg !283
  %386 = load i64, ptr %130, align 8, !dbg !283
  %387 = and i64 %386, 1, !dbg !156
  %388 = trunc i64 %387 to i8, !dbg !156
  store i8 %388, ptr %128, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %131, metadata !285, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %132, metadata !286, metadata !DIExpression()), !dbg !288
  %389 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !288, !srcloc !289
  store i64 %389, ptr %132, align 8, !dbg !288
  %390 = load i64, ptr %132, align 8, !dbg !288
  store i64 %390, ptr %133, align 8, !dbg !288
  %391 = load i64, ptr %133, align 8, !dbg !288
  %392 = and i64 %391, 1, !dbg !156
  %393 = trunc i64 %392 to i8, !dbg !156
  store i8 %393, ptr %131, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %134, metadata !290, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %135, metadata !291, metadata !DIExpression()), !dbg !293
  %394 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !293, !srcloc !294
  store i64 %394, ptr %135, align 8, !dbg !293
  %395 = load i64, ptr %135, align 8, !dbg !293
  store i64 %395, ptr %136, align 8, !dbg !293
  %396 = load i64, ptr %136, align 8, !dbg !293
  %397 = and i64 %396, 1, !dbg !156
  %398 = trunc i64 %397 to i8, !dbg !156
  store i8 %398, ptr %134, align 1, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %137, metadata !295, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %138, metadata !296, metadata !DIExpression()), !dbg !298
  %399 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !298, !srcloc !299
  store i64 %399, ptr %138, align 8, !dbg !298
  %400 = load i64, ptr %138, align 8, !dbg !298
  store i64 %400, ptr %139, align 8, !dbg !298
  %401 = load i64, ptr %139, align 8, !dbg !298
  store i64 %401, ptr %137, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %140, metadata !300, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %141, metadata !301, metadata !DIExpression()), !dbg !303
  %402 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590364855) #8, !dbg !303, !srcloc !304
  store i64 %402, ptr %141, align 8, !dbg !303
  %403 = load i64, ptr %141, align 8, !dbg !303
  store i64 %403, ptr %142, align 8, !dbg !303
  %404 = load i64, ptr %142, align 8, !dbg !303
  store i64 %404, ptr %140, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %143, metadata !305, metadata !DIExpression()), !dbg !156
  store i64 0, ptr %143, align 8, !dbg !156
  call void @llvm.dbg.declare(metadata ptr %144, metadata !306, metadata !DIExpression()), !dbg !156
  call void @llvm.dbg.declare(metadata ptr %145, metadata !316, metadata !DIExpression()), !dbg !318
  %405 = call i64 asm sideeffect ".8byte ${1:c}", "={r0},i"(i64 8590037175) #8, !dbg !318, !srcloc !319
  store i64 %405, ptr %145, align 8, !dbg !318
  %406 = load i64, ptr %145, align 8, !dbg !318
  store i64 %406, ptr %146, align 8, !dbg !318
  %407 = load i64, ptr %146, align 8, !dbg !318
  store i64 %407, ptr %118, align 8, !dbg !156
  store i8 1, ptr %53, align 1, !dbg !156
  %408 = load ptr, ptr %47, align 8, !dbg !156
  store ptr %408, ptr %54, align 8, !dbg !156
  %409 = load ptr, ptr %47, align 8, !dbg !156
  store ptr %409, ptr %55, align 8, !dbg !156
  %410 = load ptr, ptr %47, align 8, !dbg !156
  store ptr %410, ptr %82, align 8, !dbg !156
  store i8 1, ptr %85, align 1, !dbg !156
  br label %411, !dbg !156

411:                                              ; preds = %1
  call void @llvm.dbg.label(metadata !320), !dbg !321
  br label %412, !dbg !322

412:                                              ; preds = %411
  call void @llvm.dbg.declare(metadata ptr %147, metadata !323, metadata !DIExpression()), !dbg !325
  call void @llvm.dbg.declare(metadata ptr %148, metadata !326, metadata !DIExpression()), !dbg !328
  store i8 8, ptr %148, align 1, !dbg !328
  %413 = load i8, ptr %148, align 1, !dbg !328
  store i8 %413, ptr %149, align 1, !dbg !328
  %414 = load i8, ptr %149, align 1, !dbg !328
  store i8 %414, ptr %147, align 1, !dbg !325
  call void @llvm.dbg.declare(metadata ptr %150, metadata !329, metadata !DIExpression()), !dbg !325
  call void @llvm.dbg.declare(metadata ptr %151, metadata !330, metadata !DIExpression()), !dbg !332
  store i8 0, ptr %151, align 1, !dbg !332
  %415 = load i8, ptr %151, align 1, !dbg !333
  %416 = icmp ne i8 %415, 0, !dbg !333
  br i1 %416, label %420, label %417, !dbg !332

417:                                              ; preds = %412
  call void @llvm.dbg.declare(metadata ptr %152, metadata !335, metadata !DIExpression()), !dbg !337
  store i8 8, ptr %152, align 1, !dbg !337
  %418 = load i8, ptr %152, align 1, !dbg !337
  store i8 %418, ptr %153, align 1, !dbg !337
  %419 = load i8, ptr %153, align 1, !dbg !337
  store i8 %419, ptr %151, align 1, !dbg !333
  br label %420, !dbg !333

420:                                              ; preds = %417, %412
  %421 = load i8, ptr %151, align 1, !dbg !332
  store i8 %421, ptr %154, align 1, !dbg !333
  %422 = load i8, ptr %154, align 1, !dbg !332
  store i8 %422, ptr %150, align 1, !dbg !325
  call void @llvm.dbg.declare(metadata ptr %155, metadata !338, metadata !DIExpression()), !dbg !325
  call void @llvm.dbg.declare(metadata ptr %156, metadata !339, metadata !DIExpression()), !dbg !341
  store i8 0, ptr %156, align 1, !dbg !342
  %423 = load i8, ptr %156, align 1, !dbg !341
  store i8 %423, ptr %157, align 1, !dbg !342
  %424 = load i8, ptr %157, align 1, !dbg !341
  store i8 %424, ptr %155, align 1, !dbg !325
  call void @llvm.dbg.declare(metadata ptr %158, metadata !344, metadata !DIExpression()), !dbg !325
  call void @llvm.dbg.declare(metadata ptr %159, metadata !345, metadata !DIExpression()), !dbg !347
  store i64 -1024, ptr %43, align 8
  call void @llvm.dbg.declare(metadata ptr %43, metadata !348, metadata !DIExpression()), !dbg !353
  %425 = load i64, ptr %43, align 8, !dbg !355
  store i64 %425, ptr %159, align 8, !dbg !347
  call void @llvm.dbg.declare(metadata ptr %160, metadata !356, metadata !DIExpression()), !dbg !347
  store i32 0, ptr %160, align 4, !dbg !347
  call void @llvm.dbg.declare(metadata ptr %161, metadata !357, metadata !DIExpression()), !dbg !347
  %426 = load i64, ptr %159, align 8, !dbg !347
  store i64 %426, ptr %161, align 8, !dbg !347
  %427 = load i32, ptr %160, align 4, !dbg !358
  %428 = icmp ne i32 %427, 0, !dbg !358
  br i1 %428, label %429, label %444, !dbg !347

429:                                              ; preds = %420
  call void @llvm.dbg.declare(metadata ptr %162, metadata !360, metadata !DIExpression()), !dbg !362
  store i8 0, ptr %162, align 1, !dbg !362
  call void @llvm.dbg.declare(metadata ptr %163, metadata !363, metadata !DIExpression()), !dbg !362
  store i64 0, ptr %163, align 8, !dbg !362
  %430 = load i8, ptr %162, align 1, !dbg !362
  %431 = zext i8 %430 to i32, !dbg !362
  %432 = icmp ult i32 %431, 64, !dbg !362
  br i1 %432, label %433, label %439, !dbg !362

433:                                              ; preds = %429
  %434 = load i64, ptr %163, align 8, !dbg !362
  %435 = load i8, ptr %162, align 1, !dbg !362
  %436 = zext i8 %435 to i32, !dbg !362
  %437 = zext i32 %436 to i64, !dbg !362
  %438 = shl i64 %434, %437, !dbg !362
  br label %440, !dbg !362

439:                                              ; preds = %429
  br label %440, !dbg !362

440:                                              ; preds = %439, %433
  %441 = phi i64 [ %438, %433 ], [ 0, %439 ], !dbg !362
  %442 = load i64, ptr %161, align 8, !dbg !362
  %443 = add i64 %442, %441, !dbg !362
  store i64 %443, ptr %161, align 8, !dbg !362
  br label %444, !dbg !362

444:                                              ; preds = %440, %420
  %445 = load i64, ptr %161, align 8, !dbg !347
  store i64 %445, ptr %164, align 8, !dbg !358
  %446 = load i64, ptr %164, align 8, !dbg !347
  store i64 %446, ptr %158, align 8, !dbg !325
  call void @llvm.dbg.declare(metadata ptr %165, metadata !364, metadata !DIExpression()), !dbg !325
  %447 = load i64, ptr %158, align 8, !dbg !325
  store i64 %447, ptr %165, align 8, !dbg !325
  call void @llvm.dbg.declare(metadata ptr %166, metadata !365, metadata !DIExpression()), !dbg !325
  store ptr null, ptr %166, align 8, !dbg !325
  call void @llvm.dbg.declare(metadata ptr %167, metadata !366, metadata !DIExpression()), !dbg !325
  store i64 0, ptr %167, align 8, !dbg !325
  %448 = load ptr, ptr %72, align 8, !dbg !367
  store ptr %448, ptr %166, align 8, !dbg !367
  call void @llvm.dbg.declare(metadata ptr %168, metadata !369, metadata !DIExpression()), !dbg !325
  %449 = load ptr, ptr %166, align 8, !dbg !325
  %450 = ptrtoint ptr %449 to i64, !dbg !325
  %451 = load i64, ptr %158, align 8, !dbg !325
  %452 = add i64 %450, %451, !dbg !325
  %453 = inttoptr i64 %452 to ptr, !dbg !325
  store ptr %453, ptr %168, align 8, !dbg !325
  %454 = load i8, ptr %50, align 1, !dbg !370
  %455 = zext i8 %454 to i32, !dbg !370
  %456 = icmp eq i32 %455, 1, !dbg !370
  br i1 %456, label %457, label %1254, !dbg !370

457:                                              ; preds = %444
  call void @llvm.dbg.declare(metadata ptr %169, metadata !372, metadata !DIExpression()), !dbg !374
  store i8 0, ptr %169, align 1, !dbg !374
  %458 = load i8, ptr %73, align 1, !dbg !374
  store i8 %458, ptr %169, align 1, !dbg !374
  %459 = load i8, ptr %169, align 1, !dbg !374
  store i8 %459, ptr %170, align 1, !dbg !374
  %460 = load i8, ptr %170, align 1, !dbg !374
  %461 = zext i8 %460 to i32, !dbg !370
  %462 = icmp eq i32 %461, 1, !dbg !370
  br i1 %462, label %463, label %1254, !dbg !325

463:                                              ; preds = %457
  call void @llvm.dbg.declare(metadata ptr %171, metadata !375, metadata !DIExpression()), !dbg !378
  %464 = load i8, ptr %150, align 1, !dbg !378
  store i8 %464, ptr %171, align 1, !dbg !378
  call void @llvm.dbg.declare(metadata ptr %172, metadata !379, metadata !DIExpression()), !dbg !378
  %465 = load ptr, ptr %72, align 8, !dbg !378
  %466 = ptrtoint ptr %465 to i64, !dbg !378
  %467 = load ptr, ptr %55, align 8, !dbg !378
  %468 = ptrtoint ptr %467 to i64, !dbg !378
  %469 = sub i64 %466, %468, !dbg !378
  %470 = load i64, ptr %158, align 8, !dbg !378
  %471 = add i64 %469, %470, !dbg !378
  store i64 %471, ptr %172, align 8, !dbg !378
  call void @llvm.dbg.declare(metadata ptr %173, metadata !380, metadata !DIExpression()), !dbg !378
  %472 = load ptr, ptr %54, align 8, !dbg !378
  store ptr %472, ptr %173, align 8, !dbg !378
  call void @llvm.dbg.declare(metadata ptr %174, metadata !381, metadata !DIExpression()), !dbg !378
  %473 = load i64, ptr %172, align 8, !dbg !382
  %474 = icmp sge i64 %473, 208, !dbg !382
  br i1 %474, label %475, label %481, !dbg !382

475:                                              ; preds = %463
  %476 = load i64, ptr %172, align 8, !dbg !382
  %477 = load i8, ptr %150, align 1, !dbg !382
  %478 = zext i8 %477 to i64, !dbg !382
  %479 = sub nsw i64 216, %478, !dbg !382
  %480 = icmp sle i64 %476, %479, !dbg !382
  br i1 %480, label %490, label %481, !dbg !382

481:                                              ; preds = %475, %463
  %482 = load i64, ptr %172, align 8, !dbg !382
  %483 = icmp sge i64 %482, 80, !dbg !382
  br i1 %483, label %484, label %543, !dbg !382

484:                                              ; preds = %481
  %485 = load i64, ptr %172, align 8, !dbg !382
  %486 = load i8, ptr %150, align 1, !dbg !382
  %487 = zext i8 %486 to i64, !dbg !382
  %488 = sub nsw i64 88, %487, !dbg !382
  %489 = icmp sle i64 %485, %488, !dbg !382
  br i1 %489, label %490, label %543, !dbg !378

490:                                              ; preds = %484, %475
  call void @llvm.dbg.declare(metadata ptr %175, metadata !384, metadata !DIExpression()), !dbg !386
  %491 = load i64, ptr %172, align 8, !dbg !387
  %492 = icmp sge i64 %491, 208, !dbg !387
  br i1 %492, label %493, label %500, !dbg !386

493:                                              ; preds = %490
  call void @llvm.dbg.declare(metadata ptr %176, metadata !389, metadata !DIExpression()), !dbg !392
  %494 = load ptr, ptr %173, align 8, !dbg !392
  %495 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %494, i64 76) #8, !dbg !392, !srcloc !393
  store i64 %495, ptr %176, align 8, !dbg !392
  %496 = load i64, ptr %176, align 8, !dbg !392
  store i64 %496, ptr %177, align 8, !dbg !392
  %497 = load i64, ptr %177, align 8, !dbg !392
  store i64 %497, ptr %174, align 8, !dbg !394
  %498 = load i64, ptr %172, align 8, !dbg !394
  %499 = sub nsw i64 %498, 208, !dbg !394
  store i64 %499, ptr %175, align 8, !dbg !394
  br label %507, !dbg !394

500:                                              ; preds = %490
  call void @llvm.dbg.declare(metadata ptr %178, metadata !395, metadata !DIExpression()), !dbg !398
  %501 = load ptr, ptr %173, align 8, !dbg !398
  %502 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %501, i64 80) #8, !dbg !398, !srcloc !399
  store i64 %502, ptr %178, align 8, !dbg !398
  %503 = load i64, ptr %178, align 8, !dbg !398
  store i64 %503, ptr %179, align 8, !dbg !398
  %504 = load i64, ptr %179, align 8, !dbg !398
  store i64 %504, ptr %174, align 8, !dbg !400
  %505 = load i64, ptr %172, align 8, !dbg !400
  %506 = sub nsw i64 %505, 80, !dbg !400
  store i64 %506, ptr %175, align 8, !dbg !400
  br label %507

507:                                              ; preds = %500, %493
  %508 = load i8, ptr %150, align 1, !dbg !401
  %509 = zext i8 %508 to i32, !dbg !401
  %510 = icmp ne i32 %509, 8, !dbg !401
  br i1 %510, label %511, label %542, !dbg !386

511:                                              ; preds = %507
  call void @llvm.dbg.declare(metadata ptr %180, metadata !403, metadata !DIExpression()), !dbg !405
  call void @llvm.dbg.declare(metadata ptr %181, metadata !406, metadata !DIExpression()), !dbg !405
  %512 = load i64, ptr %174, align 8, !dbg !405
  store i64 %512, ptr %181, align 8, !dbg !405
  %513 = load i64, ptr %181, align 8, !dbg !405
  %514 = call i64 asm sideeffect ".8byte 0x00000002000490b7", "={r0},{r1}"(i64 %513) #8, !dbg !405, !srcloc !407
  store i64 %514, ptr %180, align 8, !dbg !405
  %515 = load i64, ptr %180, align 8, !dbg !405
  store i64 %515, ptr %182, align 8, !dbg !405
  %516 = load i64, ptr %182, align 8, !dbg !405
  %517 = load i64, ptr %175, align 8, !dbg !401
  %518 = mul nsw i64 %517, 8, !dbg !401
  %519 = lshr i64 %516, %518, !dbg !401
  %520 = load i8, ptr %150, align 1, !dbg !401
  store i64 %519, ptr %35, align 8
  call void @llvm.dbg.declare(metadata ptr %35, metadata !408, metadata !DIExpression()), !dbg !412
  store i8 %520, ptr %36, align 1
  call void @llvm.dbg.declare(metadata ptr %36, metadata !414, metadata !DIExpression()), !dbg !415
  %521 = load i64, ptr %35, align 8, !dbg !416
  %522 = load i8, ptr %36, align 1, !dbg !416
  %523 = zext i8 %522 to i32, !dbg !416
  %524 = icmp eq i32 %523, 1, !dbg !416
  br i1 %524, label %525, label %526, !dbg !416

525:                                              ; preds = %511
  br label %539, !dbg !416

526:                                              ; preds = %511
  %527 = load i8, ptr %36, align 1, !dbg !416
  %528 = zext i8 %527 to i32, !dbg !416
  %529 = icmp eq i32 %528, 2, !dbg !416
  br i1 %529, label %530, label %531, !dbg !416

530:                                              ; preds = %526
  br label %537, !dbg !416

531:                                              ; preds = %526
  %532 = load i8, ptr %36, align 1, !dbg !416
  %533 = zext i8 %532 to i32, !dbg !416
  %534 = icmp eq i32 %533, 4, !dbg !416
  %535 = zext i1 %534 to i64, !dbg !416
  %536 = select i1 %534, i64 4294967295, i64 -1, !dbg !416
  br label %537, !dbg !416

537:                                              ; preds = %531, %530
  %538 = phi i64 [ 65535, %530 ], [ %536, %531 ], !dbg !416
  br label %539, !dbg !416

539:                                              ; preds = %525, %537
  %540 = phi i64 [ 255, %525 ], [ %538, %537 ], !dbg !416
  %541 = and i64 %521, %540, !dbg !416
  store i64 %541, ptr %174, align 8, !dbg !401
  br label %542, !dbg !401

542:                                              ; preds = %539, %507
  br label %1016, !dbg !386

543:                                              ; preds = %484, %481
  %544 = load i64, ptr %172, align 8, !dbg !417
  %545 = icmp sge i64 %544, 48, !dbg !417
  br i1 %545, label %546, label %756, !dbg !417

546:                                              ; preds = %543
  %547 = load i64, ptr %172, align 8, !dbg !417
  %548 = load i8, ptr %150, align 1, !dbg !417
  %549 = zext i8 %548 to i64, !dbg !417
  %550 = sub nsw i64 68, %549, !dbg !417
  %551 = icmp sle i64 %547, %550, !dbg !417
  br i1 %551, label %552, label %756, !dbg !382

552:                                              ; preds = %546
  call void @llvm.dbg.declare(metadata ptr %183, metadata !419, metadata !DIExpression()), !dbg !421
  call void @llvm.dbg.declare(metadata ptr %184, metadata !422, metadata !DIExpression()), !dbg !421
  %553 = load i64, ptr %172, align 8, !dbg !423
  %554 = sub nsw i64 %553, 48, !dbg !423
  %555 = add nsw i64 %554, 48, !dbg !423
  %556 = call i1 @llvm.is.constant.i64(i64 %555), !dbg !423
  br i1 %556, label %557, label %657, !dbg !421

557:                                              ; preds = %552
  %558 = load i8, ptr %150, align 1, !dbg !425
  %559 = zext i8 %558 to i32, !dbg !425
  %560 = icmp eq i32 %559, 8, !dbg !425
  br i1 %560, label %561, label %598, !dbg !428

561:                                              ; preds = %557
  %562 = load ptr, ptr %173, align 8, !dbg !425
  %563 = load i64, ptr %172, align 8, !dbg !425
  %564 = sub nsw i64 %563, 48, !dbg !425
  %565 = add nsw i64 %564, 48, !dbg !425
  %566 = add nsw i64 %565, 0, !dbg !425
  %567 = load i64, ptr %172, align 8, !dbg !425
  %568 = sub nsw i64 %567, 48, !dbg !425
  %569 = add nsw i64 %568, 48, !dbg !425
  %570 = add nsw i64 %569, 1, !dbg !425
  %571 = load i64, ptr %172, align 8, !dbg !425
  %572 = sub nsw i64 %571, 48, !dbg !425
  %573 = add nsw i64 %572, 48, !dbg !425
  %574 = add nsw i64 %573, 2, !dbg !425
  %575 = load i64, ptr %172, align 8, !dbg !425
  %576 = sub nsw i64 %575, 48, !dbg !425
  %577 = add nsw i64 %576, 48, !dbg !425
  %578 = add nsw i64 %577, 3, !dbg !425
  %579 = load i64, ptr %172, align 8, !dbg !425
  %580 = sub nsw i64 %579, 48, !dbg !425
  %581 = add nsw i64 %580, 48, !dbg !425
  %582 = add nsw i64 %581, 4, !dbg !425
  %583 = load i64, ptr %172, align 8, !dbg !425
  %584 = sub nsw i64 %583, 48, !dbg !425
  %585 = add nsw i64 %584, 48, !dbg !425
  %586 = add nsw i64 %585, 5, !dbg !425
  %587 = load i64, ptr %172, align 8, !dbg !425
  %588 = sub nsw i64 %587, 48, !dbg !425
  %589 = add nsw i64 %588, 48, !dbg !425
  %590 = add nsw i64 %589, 6, !dbg !425
  %591 = load i64, ptr %172, align 8, !dbg !425
  %592 = sub nsw i64 %591, 48, !dbg !425
  %593 = add nsw i64 %592, 48, !dbg !425
  %594 = add nsw i64 %593, 7, !dbg !425
  %595 = call { i64, i64 } asm sideeffect "$0 = *(u8 *)($2 + $3)\0A$1 = *(u8 *)($2 + $4)\0A$1 <<= 8\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $5)\0A$1 <<= 16\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $6)\0A$1 <<= 24\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $7)\0A$1 <<= 32\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $8)\0A$1 <<= 40\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $9)\0A$1 <<= 48\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $10)\0A$1 <<= 56\0A$0 $|= $1", "=&r,=&r,r,i,i,i,i,i,i,i,i,~{memory}"(ptr %562, i64 %566, i64 %570, i64 %574, i64 %578, i64 %582, i64 %586, i64 %590, i64 %594) #8, !dbg !425, !srcloc !429
  %596 = extractvalue { i64, i64 } %595, 0, !dbg !425
  %597 = extractvalue { i64, i64 } %595, 1, !dbg !425
  store i64 %596, ptr %183, align 8, !dbg !425
  store i64 %597, ptr %184, align 8, !dbg !425
  br label %656, !dbg !425

598:                                              ; preds = %557
  %599 = load i8, ptr %150, align 1, !dbg !430
  %600 = zext i8 %599 to i32, !dbg !430
  %601 = icmp eq i32 %600, 4, !dbg !430
  br i1 %601, label %602, label %623, !dbg !425

602:                                              ; preds = %598
  %603 = load ptr, ptr %173, align 8, !dbg !430
  %604 = load i64, ptr %172, align 8, !dbg !430
  %605 = sub nsw i64 %604, 48, !dbg !430
  %606 = add nsw i64 %605, 48, !dbg !430
  %607 = add nsw i64 %606, 0, !dbg !430
  %608 = load i64, ptr %172, align 8, !dbg !430
  %609 = sub nsw i64 %608, 48, !dbg !430
  %610 = add nsw i64 %609, 48, !dbg !430
  %611 = add nsw i64 %610, 1, !dbg !430
  %612 = load i64, ptr %172, align 8, !dbg !430
  %613 = sub nsw i64 %612, 48, !dbg !430
  %614 = add nsw i64 %613, 48, !dbg !430
  %615 = add nsw i64 %614, 2, !dbg !430
  %616 = load i64, ptr %172, align 8, !dbg !430
  %617 = sub nsw i64 %616, 48, !dbg !430
  %618 = add nsw i64 %617, 48, !dbg !430
  %619 = add nsw i64 %618, 3, !dbg !430
  %620 = call { i64, i64 } asm sideeffect "$0 = *(u8 *)($2 + $3)\0A$1 = *(u8 *)($2 + $4)\0A$1 <<= 8\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $5)\0A$1 <<= 16\0A$0 $|= $1\0A$1 = *(u8 *)($2 + $6)\0A$1 <<= 24\0A$0 $|= $1", "=&r,=&r,r,i,i,i,i,~{memory}"(ptr %603, i64 %607, i64 %611, i64 %615, i64 %619) #8, !dbg !430, !srcloc !432
  %621 = extractvalue { i64, i64 } %620, 0, !dbg !430
  %622 = extractvalue { i64, i64 } %620, 1, !dbg !430
  store i64 %621, ptr %183, align 8, !dbg !430
  store i64 %622, ptr %184, align 8, !dbg !430
  br label %655, !dbg !430

623:                                              ; preds = %598
  %624 = load i8, ptr %150, align 1, !dbg !433
  %625 = zext i8 %624 to i32, !dbg !433
  %626 = icmp eq i32 %625, 2, !dbg !433
  br i1 %626, label %627, label %640, !dbg !430

627:                                              ; preds = %623
  %628 = load ptr, ptr %173, align 8, !dbg !433
  %629 = load i64, ptr %172, align 8, !dbg !433
  %630 = sub nsw i64 %629, 48, !dbg !433
  %631 = add nsw i64 %630, 48, !dbg !433
  %632 = add nsw i64 %631, 0, !dbg !433
  %633 = load i64, ptr %172, align 8, !dbg !433
  %634 = sub nsw i64 %633, 48, !dbg !433
  %635 = add nsw i64 %634, 48, !dbg !433
  %636 = add nsw i64 %635, 1, !dbg !433
  %637 = call { i64, i64 } asm sideeffect "$0 = *(u8 *)($2 + $3)\0A$1 = *(u8 *)($2 + $4)\0A$1 <<= 8\0A$0 $|= $1", "=&r,=&r,r,i,i,~{memory}"(ptr %628, i64 %632, i64 %636) #8, !dbg !433, !srcloc !435
  %638 = extractvalue { i64, i64 } %637, 0, !dbg !433
  %639 = extractvalue { i64, i64 } %637, 1, !dbg !433
  store i64 %638, ptr %183, align 8, !dbg !433
  store i64 %639, ptr %184, align 8, !dbg !433
  br label %654, !dbg !433

640:                                              ; preds = %623
  %641 = load i8, ptr %150, align 1, !dbg !436
  %642 = zext i8 %641 to i32, !dbg !436
  %643 = icmp eq i32 %642, 1, !dbg !436
  br i1 %643, label %644, label %653, !dbg !433

644:                                              ; preds = %640
  %645 = load ptr, ptr %173, align 8, !dbg !436
  %646 = load i64, ptr %172, align 8, !dbg !436
  %647 = sub nsw i64 %646, 48, !dbg !436
  %648 = add nsw i64 %647, 48, !dbg !436
  %649 = add nsw i64 %648, 0, !dbg !436
  %650 = call { i64, i64 } asm sideeffect "$0 = *(u8 *)($2 + $3)", "=&r,=&r,r,i,~{memory}"(ptr %645, i64 %649) #8, !dbg !436, !srcloc !438
  %651 = extractvalue { i64, i64 } %650, 0, !dbg !436
  %652 = extractvalue { i64, i64 } %650, 1, !dbg !436
  store i64 %651, ptr %183, align 8, !dbg !436
  store i64 %652, ptr %184, align 8, !dbg !436
  br label %653, !dbg !436

653:                                              ; preds = %644, %640
  br label %654

654:                                              ; preds = %653, %627
  br label %655

655:                                              ; preds = %654, %602
  br label %656

656:                                              ; preds = %655, %561
  br label %753, !dbg !428

657:                                              ; preds = %552
  call void @llvm.dbg.declare(metadata ptr %185, metadata !439, metadata !DIExpression()), !dbg !441
  %658 = load ptr, ptr %173, align 8, !dbg !441
  %659 = load i64, ptr %172, align 8, !dbg !441
  %660 = sub nsw i64 %659, 48, !dbg !441
  %661 = add nsw i64 %660, 48, !dbg !441
  %662 = getelementptr inbounds i8, ptr %658, i64 %661, !dbg !441
  store ptr %662, ptr %185, align 8, !dbg !441
  call void @llvm.dbg.declare(metadata ptr %186, metadata !442, metadata !DIExpression()), !dbg !441
  %663 = load ptr, ptr %185, align 8, !dbg !441
  %664 = getelementptr inbounds i8, ptr %663, i64 0, !dbg !441
  %665 = load volatile i8, ptr %664, align 1, !dbg !441
  %666 = zext i8 %665 to i64, !dbg !441
  store i64 %666, ptr %186, align 8, !dbg !441
  %667 = load i8, ptr %150, align 1, !dbg !443
  %668 = zext i8 %667 to i32, !dbg !443
  %669 = icmp uge i32 %668, 2, !dbg !443
  br i1 %669, label %670, label %678, !dbg !441

670:                                              ; preds = %657
  %671 = load ptr, ptr %185, align 8, !dbg !443
  %672 = getelementptr inbounds i8, ptr %671, i64 1, !dbg !443
  %673 = load volatile i8, ptr %672, align 1, !dbg !443
  %674 = zext i8 %673 to i64, !dbg !443
  %675 = shl i64 %674, 8, !dbg !443
  %676 = load i64, ptr %186, align 8, !dbg !443
  %677 = or i64 %676, %675, !dbg !443
  store i64 %677, ptr %186, align 8, !dbg !443
  br label %678, !dbg !443

678:                                              ; preds = %670, %657
  %679 = load i8, ptr %150, align 1, !dbg !445
  %680 = zext i8 %679 to i32, !dbg !445
  %681 = icmp uge i32 %680, 4, !dbg !445
  br i1 %681, label %682, label %690, !dbg !441

682:                                              ; preds = %678
  %683 = load ptr, ptr %185, align 8, !dbg !445
  %684 = getelementptr inbounds i8, ptr %683, i64 2, !dbg !445
  %685 = load volatile i8, ptr %684, align 1, !dbg !445
  %686 = zext i8 %685 to i64, !dbg !445
  %687 = shl i64 %686, 16, !dbg !445
  %688 = load i64, ptr %186, align 8, !dbg !445
  %689 = or i64 %688, %687, !dbg !445
  store i64 %689, ptr %186, align 8, !dbg !445
  br label %690, !dbg !445

690:                                              ; preds = %682, %678
  %691 = load i8, ptr %150, align 1, !dbg !447
  %692 = zext i8 %691 to i32, !dbg !447
  %693 = icmp uge i32 %692, 4, !dbg !447
  br i1 %693, label %694, label %702, !dbg !441

694:                                              ; preds = %690
  %695 = load ptr, ptr %185, align 8, !dbg !447
  %696 = getelementptr inbounds i8, ptr %695, i64 3, !dbg !447
  %697 = load volatile i8, ptr %696, align 1, !dbg !447
  %698 = zext i8 %697 to i64, !dbg !447
  %699 = shl i64 %698, 24, !dbg !447
  %700 = load i64, ptr %186, align 8, !dbg !447
  %701 = or i64 %700, %699, !dbg !447
  store i64 %701, ptr %186, align 8, !dbg !447
  br label %702, !dbg !447

702:                                              ; preds = %694, %690
  %703 = load i8, ptr %150, align 1, !dbg !449
  %704 = zext i8 %703 to i32, !dbg !449
  %705 = icmp uge i32 %704, 8, !dbg !449
  br i1 %705, label %706, label %714, !dbg !441

706:                                              ; preds = %702
  %707 = load ptr, ptr %185, align 8, !dbg !449
  %708 = getelementptr inbounds i8, ptr %707, i64 4, !dbg !449
  %709 = load volatile i8, ptr %708, align 1, !dbg !449
  %710 = zext i8 %709 to i64, !dbg !449
  %711 = shl i64 %710, 32, !dbg !449
  %712 = load i64, ptr %186, align 8, !dbg !449
  %713 = or i64 %712, %711, !dbg !449
  store i64 %713, ptr %186, align 8, !dbg !449
  br label %714, !dbg !449

714:                                              ; preds = %706, %702
  %715 = load i8, ptr %150, align 1, !dbg !451
  %716 = zext i8 %715 to i32, !dbg !451
  %717 = icmp uge i32 %716, 8, !dbg !451
  br i1 %717, label %718, label %726, !dbg !441

718:                                              ; preds = %714
  %719 = load ptr, ptr %185, align 8, !dbg !451
  %720 = getelementptr inbounds i8, ptr %719, i64 5, !dbg !451
  %721 = load volatile i8, ptr %720, align 1, !dbg !451
  %722 = zext i8 %721 to i64, !dbg !451
  %723 = shl i64 %722, 40, !dbg !451
  %724 = load i64, ptr %186, align 8, !dbg !451
  %725 = or i64 %724, %723, !dbg !451
  store i64 %725, ptr %186, align 8, !dbg !451
  br label %726, !dbg !451

726:                                              ; preds = %718, %714
  %727 = load i8, ptr %150, align 1, !dbg !453
  %728 = zext i8 %727 to i32, !dbg !453
  %729 = icmp uge i32 %728, 8, !dbg !453
  br i1 %729, label %730, label %738, !dbg !441

730:                                              ; preds = %726
  %731 = load ptr, ptr %185, align 8, !dbg !453
  %732 = getelementptr inbounds i8, ptr %731, i64 6, !dbg !453
  %733 = load volatile i8, ptr %732, align 1, !dbg !453
  %734 = zext i8 %733 to i64, !dbg !453
  %735 = shl i64 %734, 48, !dbg !453
  %736 = load i64, ptr %186, align 8, !dbg !453
  %737 = or i64 %736, %735, !dbg !453
  store i64 %737, ptr %186, align 8, !dbg !453
  br label %738, !dbg !453

738:                                              ; preds = %730, %726
  %739 = load i8, ptr %150, align 1, !dbg !455
  %740 = zext i8 %739 to i32, !dbg !455
  %741 = icmp uge i32 %740, 8, !dbg !455
  br i1 %741, label %742, label %750, !dbg !441

742:                                              ; preds = %738
  %743 = load ptr, ptr %185, align 8, !dbg !455
  %744 = getelementptr inbounds i8, ptr %743, i64 7, !dbg !455
  %745 = load volatile i8, ptr %744, align 1, !dbg !455
  %746 = zext i8 %745 to i64, !dbg !455
  %747 = shl i64 %746, 56, !dbg !455
  %748 = load i64, ptr %186, align 8, !dbg !455
  %749 = or i64 %748, %747, !dbg !455
  store i64 %749, ptr %186, align 8, !dbg !455
  br label %750, !dbg !455

750:                                              ; preds = %742, %738
  %751 = load i64, ptr %186, align 8, !dbg !441
  store i64 %751, ptr %187, align 8, !dbg !455
  %752 = load i64, ptr %187, align 8, !dbg !441
  store i64 %752, ptr %183, align 8, !dbg !423
  br label %753

753:                                              ; preds = %750, %656
  %754 = load i64, ptr %183, align 8, !dbg !421
  store i64 %754, ptr %188, align 8, !dbg !423
  %755 = load i64, ptr %188, align 8, !dbg !421
  store i64 %755, ptr %174, align 8, !dbg !417
  br label %1015, !dbg !417

756:                                              ; preds = %546, %543
  %757 = load i64, ptr %172, align 8, !dbg !457
  %758 = icmp sge i64 %757, 134, !dbg !457
  br i1 %758, label %759, label %797, !dbg !457

759:                                              ; preds = %756
  %760 = load i64, ptr %172, align 8, !dbg !457
  %761 = load i8, ptr %171, align 1, !dbg !457
  %762 = zext i8 %761 to i32, !dbg !457
  %763 = sub nsw i32 136, %762, !dbg !457
  %764 = sext i32 %763 to i64, !dbg !457
  %765 = icmp sle i64 %760, %764, !dbg !457
  br i1 %765, label %766, label %797, !dbg !417

766:                                              ; preds = %759
  call void @llvm.dbg.declare(metadata ptr %189, metadata !459, metadata !DIExpression()), !dbg !461
  %767 = load ptr, ptr %173, align 8, !dbg !461
  %768 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %767, i64 44) #8, !dbg !461, !srcloc !462
  store i64 %768, ptr %189, align 8, !dbg !461
  %769 = load i64, ptr %189, align 8, !dbg !461
  store i64 %769, ptr %190, align 8, !dbg !461
  %770 = load i64, ptr %190, align 8, !dbg !461
  %771 = load i64, ptr %172, align 8, !dbg !457
  %772 = sub nsw i64 %771, 134, !dbg !457
  %773 = mul nsw i64 %772, 8, !dbg !457
  %774 = lshr i64 %770, %773, !dbg !457
  %775 = load i8, ptr %171, align 1, !dbg !457
  store i64 %774, ptr %37, align 8
  call void @llvm.dbg.declare(metadata ptr %37, metadata !408, metadata !DIExpression()), !dbg !463
  store i8 %775, ptr %38, align 1
  call void @llvm.dbg.declare(metadata ptr %38, metadata !414, metadata !DIExpression()), !dbg !465
  %776 = load i64, ptr %37, align 8, !dbg !466
  %777 = load i8, ptr %38, align 1, !dbg !466
  %778 = zext i8 %777 to i32, !dbg !466
  %779 = icmp eq i32 %778, 1, !dbg !466
  br i1 %779, label %780, label %781, !dbg !466

780:                                              ; preds = %766
  br label %794, !dbg !466

781:                                              ; preds = %766
  %782 = load i8, ptr %38, align 1, !dbg !466
  %783 = zext i8 %782 to i32, !dbg !466
  %784 = icmp eq i32 %783, 2, !dbg !466
  br i1 %784, label %785, label %786, !dbg !466

785:                                              ; preds = %781
  br label %792, !dbg !466

786:                                              ; preds = %781
  %787 = load i8, ptr %38, align 1, !dbg !466
  %788 = zext i8 %787 to i32, !dbg !466
  %789 = icmp eq i32 %788, 4, !dbg !466
  %790 = zext i1 %789 to i64, !dbg !466
  %791 = select i1 %789, i64 4294967295, i64 -1, !dbg !466
  br label %792, !dbg !466

792:                                              ; preds = %786, %785
  %793 = phi i64 [ 65535, %785 ], [ %791, %786 ], !dbg !466
  br label %794, !dbg !466

794:                                              ; preds = %780, %792
  %795 = phi i64 [ 255, %780 ], [ %793, %792 ], !dbg !466
  %796 = and i64 %776, %795, !dbg !466
  store i64 %796, ptr %174, align 8, !dbg !457
  br label %1014, !dbg !457

797:                                              ; preds = %759, %756
  %798 = load i64, ptr %172, align 8, !dbg !467
  %799 = icmp sge i64 %798, 144, !dbg !467
  br i1 %799, label %800, label %838, !dbg !467

800:                                              ; preds = %797
  %801 = load i64, ptr %172, align 8, !dbg !467
  %802 = load i8, ptr %171, align 1, !dbg !467
  %803 = zext i8 %802 to i32, !dbg !467
  %804 = sub nsw i32 148, %803, !dbg !467
  %805 = sext i32 %804 to i64, !dbg !467
  %806 = icmp sle i64 %801, %805, !dbg !467
  br i1 %806, label %807, label %838, !dbg !457

807:                                              ; preds = %800
  call void @llvm.dbg.declare(metadata ptr %191, metadata !469, metadata !DIExpression()), !dbg !471
  %808 = load ptr, ptr %173, align 8, !dbg !471
  %809 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %808, i64 32) #8, !dbg !471, !srcloc !472
  store i64 %809, ptr %191, align 8, !dbg !471
  %810 = load i64, ptr %191, align 8, !dbg !471
  store i64 %810, ptr %192, align 8, !dbg !471
  %811 = load i64, ptr %192, align 8, !dbg !471
  %812 = load i64, ptr %172, align 8, !dbg !467
  %813 = sub nsw i64 %812, 144, !dbg !467
  %814 = mul nsw i64 %813, 8, !dbg !467
  %815 = lshr i64 %811, %814, !dbg !467
  %816 = load i8, ptr %171, align 1, !dbg !467
  store i64 %815, ptr %39, align 8
  call void @llvm.dbg.declare(metadata ptr %39, metadata !408, metadata !DIExpression()), !dbg !473
  store i8 %816, ptr %40, align 1
  call void @llvm.dbg.declare(metadata ptr %40, metadata !414, metadata !DIExpression()), !dbg !475
  %817 = load i64, ptr %39, align 8, !dbg !476
  %818 = load i8, ptr %40, align 1, !dbg !476
  %819 = zext i8 %818 to i32, !dbg !476
  %820 = icmp eq i32 %819, 1, !dbg !476
  br i1 %820, label %821, label %822, !dbg !476

821:                                              ; preds = %807
  br label %835, !dbg !476

822:                                              ; preds = %807
  %823 = load i8, ptr %40, align 1, !dbg !476
  %824 = zext i8 %823 to i32, !dbg !476
  %825 = icmp eq i32 %824, 2, !dbg !476
  br i1 %825, label %826, label %827, !dbg !476

826:                                              ; preds = %822
  br label %833, !dbg !476

827:                                              ; preds = %822
  %828 = load i8, ptr %40, align 1, !dbg !476
  %829 = zext i8 %828 to i32, !dbg !476
  %830 = icmp eq i32 %829, 4, !dbg !476
  %831 = zext i1 %830 to i64, !dbg !476
  %832 = select i1 %830, i64 4294967295, i64 -1, !dbg !476
  br label %833, !dbg !476

833:                                              ; preds = %827, %826
  %834 = phi i64 [ 65535, %826 ], [ %832, %827 ], !dbg !476
  br label %835, !dbg !476

835:                                              ; preds = %821, %833
  %836 = phi i64 [ 255, %821 ], [ %834, %833 ], !dbg !476
  %837 = and i64 %817, %836, !dbg !476
  store i64 %837, ptr %174, align 8, !dbg !467
  br label %1013, !dbg !467

838:                                              ; preds = %800, %797
  %839 = load i64, ptr %172, align 8, !dbg !477
  %840 = icmp sge i64 %839, 168, !dbg !477
  br i1 %840, label %841, label %879, !dbg !477

841:                                              ; preds = %838
  %842 = load i64, ptr %172, align 8, !dbg !477
  %843 = load i8, ptr %171, align 1, !dbg !477
  %844 = zext i8 %843 to i32, !dbg !477
  %845 = sub nsw i32 172, %844, !dbg !477
  %846 = sext i32 %845 to i64, !dbg !477
  %847 = icmp sle i64 %842, %846, !dbg !477
  br i1 %847, label %848, label %879, !dbg !467

848:                                              ; preds = %841
  call void @llvm.dbg.declare(metadata ptr %193, metadata !479, metadata !DIExpression()), !dbg !481
  %849 = load ptr, ptr %173, align 8, !dbg !481
  %850 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %849, i64 8) #8, !dbg !481, !srcloc !482
  store i64 %850, ptr %193, align 8, !dbg !481
  %851 = load i64, ptr %193, align 8, !dbg !481
  store i64 %851, ptr %194, align 8, !dbg !481
  %852 = load i64, ptr %194, align 8, !dbg !481
  %853 = load i64, ptr %172, align 8, !dbg !477
  %854 = sub nsw i64 %853, 168, !dbg !477
  %855 = mul nsw i64 %854, 8, !dbg !477
  %856 = lshr i64 %852, %855, !dbg !477
  %857 = load i8, ptr %171, align 1, !dbg !477
  store i64 %856, ptr %41, align 8
  call void @llvm.dbg.declare(metadata ptr %41, metadata !408, metadata !DIExpression()), !dbg !483
  store i8 %857, ptr %42, align 1
  call void @llvm.dbg.declare(metadata ptr %42, metadata !414, metadata !DIExpression()), !dbg !485
  %858 = load i64, ptr %41, align 8, !dbg !486
  %859 = load i8, ptr %42, align 1, !dbg !486
  %860 = zext i8 %859 to i32, !dbg !486
  %861 = icmp eq i32 %860, 1, !dbg !486
  br i1 %861, label %862, label %863, !dbg !486

862:                                              ; preds = %848
  br label %876, !dbg !486

863:                                              ; preds = %848
  %864 = load i8, ptr %42, align 1, !dbg !486
  %865 = zext i8 %864 to i32, !dbg !486
  %866 = icmp eq i32 %865, 2, !dbg !486
  br i1 %866, label %867, label %868, !dbg !486

867:                                              ; preds = %863
  br label %874, !dbg !486

868:                                              ; preds = %863
  %869 = load i8, ptr %42, align 1, !dbg !486
  %870 = zext i8 %869 to i32, !dbg !486
  %871 = icmp eq i32 %870, 4, !dbg !486
  %872 = zext i1 %871 to i64, !dbg !486
  %873 = select i1 %871, i64 4294967295, i64 -1, !dbg !486
  br label %874, !dbg !486

874:                                              ; preds = %868, %867
  %875 = phi i64 [ 65535, %867 ], [ %873, %868 ], !dbg !486
  br label %876, !dbg !486

876:                                              ; preds = %862, %874
  %877 = phi i64 [ 255, %862 ], [ %875, %874 ], !dbg !486
  %878 = and i64 %858, %877, !dbg !486
  store i64 %878, ptr %174, align 8, !dbg !477
  br label %1012, !dbg !477

879:                                              ; preds = %841, %838
  call void @llvm.dbg.declare(metadata ptr %195, metadata !487, metadata !DIExpression()), !dbg !489
  %880 = load i64, ptr %158, align 8, !dbg !490
  %881 = call i1 @llvm.is.constant.i64(i64 %880), !dbg !490
  br i1 %881, label %882, label %970, !dbg !489

882:                                              ; preds = %879
  %883 = load ptr, ptr %72, align 8, !dbg !490
  %884 = load i64, ptr %158, align 8, !dbg !490
  %885 = load i8, ptr %150, align 1, !dbg !490
  store ptr %883, ptr %21, align 8
  call void @llvm.dbg.declare(metadata ptr %21, metadata !492, metadata !DIExpression()), !dbg !499
  store i64 %884, ptr %22, align 8
  call void @llvm.dbg.declare(metadata ptr %22, metadata !501, metadata !DIExpression()), !dbg !502
  store i8 %885, ptr %23, align 1
  call void @llvm.dbg.declare(metadata ptr %23, metadata !503, metadata !DIExpression()), !dbg !504
  %886 = load i64, ptr %22, align 8, !dbg !505
  %887 = call i1 @llvm.is.constant.i64(i64 %886), !dbg !507
  br i1 %887, label %888, label %894, !dbg !508

888:                                              ; preds = %882
  %889 = load i64, ptr %22, align 8, !dbg !509
  %890 = icmp slt i64 %889, -32768, !dbg !510
  br i1 %890, label %894, label %891, !dbg !511

891:                                              ; preds = %888
  %892 = load i64, ptr %22, align 8, !dbg !512
  %893 = icmp sgt i64 %892, 32767, !dbg !513
  br i1 %893, label %894, label %895, !dbg !514

894:                                              ; preds = %891, %888, %882
  call void @kprog_x86_fixed_displacement_required() #8, !dbg !515, !srcloc !516
  br label %895, !dbg !515

895:                                              ; preds = %894, %891
  call void @llvm.dbg.declare(metadata ptr %24, metadata !517, metadata !DIExpression()), !dbg !518
  %896 = load i8, ptr %23, align 1, !dbg !519
  %897 = zext i8 %896 to i32, !dbg !519
  %898 = icmp ne i32 %897, 0, !dbg !519
  br i1 %898, label %899, label %902, !dbg !519

899:                                              ; preds = %895
  %900 = load i8, ptr %23, align 1, !dbg !520
  %901 = zext i8 %900 to i32, !dbg !520
  br label %903, !dbg !519

902:                                              ; preds = %895
  br label %903, !dbg !519

903:                                              ; preds = %902, %899
  %904 = phi i32 [ %901, %899 ], [ 8, %902 ], !dbg !519
  switch i32 %904, label %967 [
    i32 1, label %905
    i32 2, label %921
    i32 4, label %937
    i32 8, label %953
  ], !dbg !521

905:                                              ; preds = %903
  %906 = load i64, ptr %22, align 8, !dbg !522
  %907 = icmp slt i64 %906, 0, !dbg !525
  br i1 %907, label %908, label %913, !dbg !526

908:                                              ; preds = %905
  %909 = load ptr, ptr %21, align 8, !dbg !527
  %910 = load i64, ptr %22, align 8, !dbg !528
  %911 = sub nsw i64 0, %910, !dbg !529
  %912 = call i64 asm sideeffect "$0 = *(u8 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %909, i64 %911) #8, !dbg !530, !srcloc !531
  store i64 %912, ptr %24, align 8, !dbg !530
  br label %917, !dbg !530

913:                                              ; preds = %905
  %914 = load ptr, ptr %21, align 8, !dbg !532
  %915 = load i64, ptr %22, align 8, !dbg !533
  %916 = call i64 asm sideeffect "$0 = *(u8 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %914, i64 %915) #8, !dbg !534, !srcloc !535
  store i64 %916, ptr %24, align 8, !dbg !534
  br label %917

917:                                              ; preds = %913, %908
  %918 = load i64, ptr %24, align 8, !dbg !536
  %919 = trunc i64 %918 to i8, !dbg !537
  %920 = zext i8 %919 to i64, !dbg !537
  store i64 %920, ptr %20, align 8, !dbg !538
  br label %968, !dbg !538

921:                                              ; preds = %903
  %922 = load i64, ptr %22, align 8, !dbg !539
  %923 = icmp slt i64 %922, 0, !dbg !541
  br i1 %923, label %924, label %929, !dbg !542

924:                                              ; preds = %921
  %925 = load ptr, ptr %21, align 8, !dbg !543
  %926 = load i64, ptr %22, align 8, !dbg !544
  %927 = sub nsw i64 0, %926, !dbg !545
  %928 = call i64 asm sideeffect "$0 = *(u16 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %925, i64 %927) #8, !dbg !546, !srcloc !547
  store i64 %928, ptr %24, align 8, !dbg !546
  br label %933, !dbg !546

929:                                              ; preds = %921
  %930 = load ptr, ptr %21, align 8, !dbg !548
  %931 = load i64, ptr %22, align 8, !dbg !549
  %932 = call i64 asm sideeffect "$0 = *(u16 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %930, i64 %931) #8, !dbg !550, !srcloc !551
  store i64 %932, ptr %24, align 8, !dbg !550
  br label %933

933:                                              ; preds = %929, %924
  %934 = load i64, ptr %24, align 8, !dbg !552
  %935 = trunc i64 %934 to i16, !dbg !553
  %936 = zext i16 %935 to i64, !dbg !553
  store i64 %936, ptr %20, align 8, !dbg !554
  br label %968, !dbg !554

937:                                              ; preds = %903
  %938 = load i64, ptr %22, align 8, !dbg !555
  %939 = icmp slt i64 %938, 0, !dbg !557
  br i1 %939, label %940, label %945, !dbg !558

940:                                              ; preds = %937
  %941 = load ptr, ptr %21, align 8, !dbg !559
  %942 = load i64, ptr %22, align 8, !dbg !560
  %943 = sub nsw i64 0, %942, !dbg !561
  %944 = call i64 asm sideeffect "$0 = *(u32 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %941, i64 %943) #8, !dbg !562, !srcloc !563
  store i64 %944, ptr %24, align 8, !dbg !562
  br label %949, !dbg !562

945:                                              ; preds = %937
  %946 = load ptr, ptr %21, align 8, !dbg !564
  %947 = load i64, ptr %22, align 8, !dbg !565
  %948 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %946, i64 %947) #8, !dbg !566, !srcloc !567
  store i64 %948, ptr %24, align 8, !dbg !566
  br label %949

949:                                              ; preds = %945, %940
  %950 = load i64, ptr %24, align 8, !dbg !568
  %951 = trunc i64 %950 to i32, !dbg !569
  %952 = zext i32 %951 to i64, !dbg !569
  store i64 %952, ptr %20, align 8, !dbg !570
  br label %968, !dbg !570

953:                                              ; preds = %903
  %954 = load i64, ptr %22, align 8, !dbg !571
  %955 = icmp slt i64 %954, 0, !dbg !573
  br i1 %955, label %956, label %961, !dbg !574

956:                                              ; preds = %953
  %957 = load ptr, ptr %21, align 8, !dbg !575
  %958 = load i64, ptr %22, align 8, !dbg !576
  %959 = sub nsw i64 0, %958, !dbg !577
  %960 = call i64 asm sideeffect "$0 = *(u64 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %957, i64 %959) #8, !dbg !578, !srcloc !579
  store i64 %960, ptr %24, align 8, !dbg !578
  br label %965, !dbg !578

961:                                              ; preds = %953
  %962 = load ptr, ptr %21, align 8, !dbg !580
  %963 = load i64, ptr %22, align 8, !dbg !581
  %964 = call i64 asm sideeffect "$0 = *(u64 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %962, i64 %963) #8, !dbg !582, !srcloc !583
  store i64 %964, ptr %24, align 8, !dbg !582
  br label %965

965:                                              ; preds = %961, %956
  %966 = load i64, ptr %24, align 8, !dbg !584
  store i64 %966, ptr %20, align 8, !dbg !585
  br label %968, !dbg !585

967:                                              ; preds = %903
  call void @llvm.trap(), !dbg !586
  br label %968, !dbg !587

968:                                              ; preds = %917, %933, %949, %965, %967
  %969 = load i64, ptr %20, align 8, !dbg !588
  store i64 %969, ptr %195, align 8, !dbg !490
  br label %1009, !dbg !490

970:                                              ; preds = %879
  %971 = load ptr, ptr %72, align 8, !dbg !490
  %972 = load i64, ptr %158, align 8, !dbg !490
  %973 = getelementptr inbounds i8, ptr %971, i64 %972, !dbg !490
  %974 = load i8, ptr %150, align 1, !dbg !490
  store ptr %973, ptr %13, align 8
  call void @llvm.dbg.declare(metadata ptr %13, metadata !589, metadata !DIExpression()), !dbg !593
  store i8 %974, ptr %14, align 1
  call void @llvm.dbg.declare(metadata ptr %14, metadata !595, metadata !DIExpression()), !dbg !596
  call void @llvm.dbg.declare(metadata ptr %15, metadata !597, metadata !DIExpression()), !dbg !598
  %975 = load i8, ptr %14, align 1, !dbg !599
  %976 = zext i8 %975 to i32, !dbg !599
  %977 = icmp ne i32 %976, 0, !dbg !599
  br i1 %977, label %978, label %981, !dbg !599

978:                                              ; preds = %970
  %979 = load i8, ptr %14, align 1, !dbg !600
  %980 = zext i8 %979 to i32, !dbg !600
  br label %982, !dbg !599

981:                                              ; preds = %970
  br label %982, !dbg !599

982:                                              ; preds = %981, %978
  %983 = phi i32 [ %980, %978 ], [ 8, %981 ], !dbg !599
  switch i32 %983, label %1006 [
    i32 1, label %984
    i32 2, label %990
    i32 4, label %996
    i32 8, label %1002
  ], !dbg !601

984:                                              ; preds = %982
  %985 = load ptr, ptr %13, align 8, !dbg !602
  %986 = call i64 asm sideeffect "$0 = *(u8 *)($1 + 0)", "=r,r,~{memory}"(ptr %985) #8, !dbg !604, !srcloc !605
  store i64 %986, ptr %15, align 8, !dbg !604
  %987 = load i64, ptr %15, align 8, !dbg !606
  %988 = trunc i64 %987 to i8, !dbg !607
  %989 = zext i8 %988 to i64, !dbg !607
  store i64 %989, ptr %12, align 8, !dbg !608
  br label %1007, !dbg !608

990:                                              ; preds = %982
  %991 = load ptr, ptr %13, align 8, !dbg !609
  %992 = call i64 asm sideeffect "$0 = *(u16 *)($1 + 0)", "=r,r,~{memory}"(ptr %991) #8, !dbg !610, !srcloc !611
  store i64 %992, ptr %15, align 8, !dbg !610
  %993 = load i64, ptr %15, align 8, !dbg !612
  %994 = trunc i64 %993 to i16, !dbg !613
  %995 = zext i16 %994 to i64, !dbg !613
  store i64 %995, ptr %12, align 8, !dbg !614
  br label %1007, !dbg !614

996:                                              ; preds = %982
  %997 = load ptr, ptr %13, align 8, !dbg !615
  %998 = call i64 asm sideeffect "$0 = *(u32 *)($1 + 0)", "=r,r,~{memory}"(ptr %997) #8, !dbg !616, !srcloc !617
  store i64 %998, ptr %15, align 8, !dbg !616
  %999 = load i64, ptr %15, align 8, !dbg !618
  %1000 = trunc i64 %999 to i32, !dbg !619
  %1001 = zext i32 %1000 to i64, !dbg !619
  store i64 %1001, ptr %12, align 8, !dbg !620
  br label %1007, !dbg !620

1002:                                             ; preds = %982
  %1003 = load ptr, ptr %13, align 8, !dbg !621
  %1004 = call i64 asm sideeffect "$0 = *(u64 *)($1 + 0)", "=r,r,~{memory}"(ptr %1003) #8, !dbg !622, !srcloc !623
  store i64 %1004, ptr %15, align 8, !dbg !622
  %1005 = load i64, ptr %15, align 8, !dbg !624
  store i64 %1005, ptr %12, align 8, !dbg !625
  br label %1007, !dbg !625

1006:                                             ; preds = %982
  call void @llvm.trap(), !dbg !626
  br label %1007, !dbg !627

1007:                                             ; preds = %984, %990, %996, %1002, %1006
  %1008 = load i64, ptr %12, align 8, !dbg !628
  store i64 %1008, ptr %195, align 8, !dbg !490
  br label %1009

1009:                                             ; preds = %1007, %968
  %1010 = load i64, ptr %195, align 8, !dbg !489
  store i64 %1010, ptr %196, align 8, !dbg !490
  %1011 = load i64, ptr %196, align 8, !dbg !489
  store i64 %1011, ptr %174, align 8, !dbg !477
  br label %1012

1012:                                             ; preds = %1009, %876
  br label %1013

1013:                                             ; preds = %1012, %835
  br label %1014

1014:                                             ; preds = %1013, %794
  br label %1015

1015:                                             ; preds = %1014, %753
  br label %1016

1016:                                             ; preds = %1015, %542
  %1017 = load i64, ptr %174, align 8, !dbg !378
  store i64 %1017, ptr %197, align 8, !dbg !382
  %1018 = load i64, ptr %197, align 8, !dbg !378
  store i64 %1018, ptr %167, align 8, !dbg !629
  %1019 = load i8, ptr %155, align 1, !dbg !630
  %1020 = zext i8 %1019 to i32, !dbg !630
  %1021 = icmp eq i32 %1020, 1, !dbg !630
  br i1 %1021, label %1022, label %1070, !dbg !629

1022:                                             ; preds = %1016
  call void @llvm.dbg.declare(metadata ptr %198, metadata !632, metadata !DIExpression()), !dbg !634
  call void @llvm.dbg.declare(metadata ptr %199, metadata !635, metadata !DIExpression()), !dbg !637
  store i8 1, ptr %199, align 1, !dbg !637
  call void @llvm.dbg.declare(metadata ptr %200, metadata !638, metadata !DIExpression()), !dbg !637
  %1023 = load ptr, ptr %72, align 8, !dbg !637
  %1024 = ptrtoint ptr %1023 to i64, !dbg !637
  %1025 = load ptr, ptr %55, align 8, !dbg !637
  %1026 = ptrtoint ptr %1025 to i64, !dbg !637
  %1027 = sub i64 %1024, %1026, !dbg !637
  %1028 = load i64, ptr %158, align 8, !dbg !637
  %1029 = add i64 %1027, %1028, !dbg !637
  store i64 %1029, ptr %200, align 8, !dbg !637
  call void @llvm.dbg.declare(metadata ptr %201, metadata !639, metadata !DIExpression()), !dbg !637
  store i8 0, ptr %201, align 1, !dbg !637
  %1030 = load i8, ptr %199, align 1, !dbg !640
  %1031 = zext i8 %1030 to i32, !dbg !640
  %1032 = icmp eq i32 %1031, 0, !dbg !640
  br i1 %1032, label %1033, label %1036, !dbg !640

1033:                                             ; preds = %1022
  %1034 = load i64, ptr %200, align 8, !dbg !640
  %1035 = icmp eq i64 %1034, 0, !dbg !640
  br i1 %1035, label %1043, label %1036, !dbg !640

1036:                                             ; preds = %1033, %1022
  %1037 = load i8, ptr %199, align 1, !dbg !640
  %1038 = zext i8 %1037 to i32, !dbg !640
  %1039 = icmp eq i32 %1038, 1, !dbg !640
  br i1 %1039, label %1040, label %1044, !dbg !640

1040:                                             ; preds = %1036
  %1041 = load i64, ptr %200, align 8, !dbg !640
  %1042 = icmp eq i64 %1041, 208, !dbg !640
  br i1 %1042, label %1043, label %1044, !dbg !637

1043:                                             ; preds = %1040, %1033
  store i8 2, ptr %201, align 1, !dbg !640
  br label %1060, !dbg !640

1044:                                             ; preds = %1040, %1036
  %1045 = load i8, ptr %199, align 1, !dbg !642
  %1046 = zext i8 %1045 to i32, !dbg !642
  %1047 = icmp eq i32 %1046, 0, !dbg !642
  br i1 %1047, label %1048, label %1051, !dbg !642

1048:                                             ; preds = %1044
  %1049 = load i64, ptr %200, align 8, !dbg !642
  %1050 = icmp eq i64 %1049, 8, !dbg !642
  br i1 %1050, label %1058, label %1051, !dbg !642

1051:                                             ; preds = %1048, %1044
  %1052 = load i8, ptr %199, align 1, !dbg !642
  %1053 = zext i8 %1052 to i32, !dbg !642
  %1054 = icmp eq i32 %1053, 1, !dbg !642
  br i1 %1054, label %1055, label %1059, !dbg !642

1055:                                             ; preds = %1051
  %1056 = load i64, ptr %200, align 8, !dbg !642
  %1057 = icmp eq i64 %1056, 80, !dbg !642
  br i1 %1057, label %1058, label %1059, !dbg !640

1058:                                             ; preds = %1055, %1048
  store i8 3, ptr %201, align 1, !dbg !642
  br label %1059, !dbg !642

1059:                                             ; preds = %1058, %1055, %1051
  br label %1060

1060:                                             ; preds = %1059, %1043
  %1061 = load i8, ptr %201, align 1, !dbg !637
  store i8 %1061, ptr %202, align 1, !dbg !640
  %1062 = load i8, ptr %202, align 1, !dbg !637
  store i8 %1062, ptr %198, align 1, !dbg !634
  br label %1063, !dbg !644

1063:                                             ; preds = %1060
  call void @llvm.dbg.declare(metadata ptr %203, metadata !646, metadata !DIExpression()), !dbg !648
  %1064 = load i64, ptr %167, align 8, !dbg !648
  %1065 = inttoptr i64 %1064 to ptr, !dbg !648
  store ptr %1065, ptr %203, align 8, !dbg !648
  call void @llvm.dbg.declare(metadata ptr %204, metadata !649, metadata !DIExpression()), !dbg !648
  %1066 = load i8, ptr %198, align 1, !dbg !648
  store i8 %1066, ptr %204, align 1, !dbg !648
  %1067 = load ptr, ptr %203, align 8, !dbg !648
  store ptr %1067, ptr %56, align 8, !dbg !648
  %1068 = load i8, ptr %204, align 1, !dbg !648
  store i8 %1068, ptr %59, align 1, !dbg !648
  br label %1069, !dbg !648

1069:                                             ; preds = %1063
  br label %1253, !dbg !634

1070:                                             ; preds = %1016
  br label %1071, !dbg !650

1071:                                             ; preds = %1070
  call void @llvm.dbg.declare(metadata ptr %205, metadata !652, metadata !DIExpression()), !dbg !654
  %1072 = load i8, ptr %147, align 1, !dbg !654
  store i8 %1072, ptr %205, align 1, !dbg !654
  call void @llvm.dbg.declare(metadata ptr %206, metadata !655, metadata !DIExpression()), !dbg !654
  %1073 = load i8, ptr %205, align 1, !dbg !654
  store i8 %1073, ptr %2, align 1
  call void @llvm.dbg.declare(metadata ptr %2, metadata !656, metadata !DIExpression()), !dbg !660
  %1074 = load i8, ptr %2, align 1, !dbg !662
  %1075 = zext i8 %1074 to i32, !dbg !662
  %1076 = icmp ne i32 %1075, 0, !dbg !662
  br i1 %1076, label %1077, label %1080, !dbg !662

1077:                                             ; preds = %1071
  %1078 = load i8, ptr %2, align 1, !dbg !662
  %1079 = zext i8 %1078 to i32, !dbg !662
  br label %1081, !dbg !662

1080:                                             ; preds = %1071
  br label %1081, !dbg !662

1081:                                             ; preds = %1077, %1080
  %1082 = phi i32 [ %1079, %1077 ], [ 8, %1080 ], !dbg !662
  %1083 = trunc i32 %1082 to i8, !dbg !662
  store i8 %1083, ptr %206, align 1, !dbg !654
  call void @llvm.dbg.declare(metadata ptr %207, metadata !663, metadata !DIExpression()), !dbg !654
  store i8 0, ptr %207, align 1, !dbg !654
  call void @llvm.dbg.declare(metadata ptr %208, metadata !664, metadata !DIExpression()), !dbg !654
  %1084 = load i64, ptr %167, align 8, !dbg !654
  store i64 %1084, ptr %208, align 8, !dbg !654
  %1085 = load i8, ptr %206, align 1, !dbg !665
  %1086 = zext i8 %1085 to i32, !dbg !665
  %1087 = icmp eq i32 %1086, 1, !dbg !665
  br i1 %1087, label %1088, label %1089, !dbg !665

1088:                                             ; preds = %1081
  br label %1102, !dbg !665

1089:                                             ; preds = %1081
  %1090 = load i8, ptr %206, align 1, !dbg !665
  %1091 = zext i8 %1090 to i32, !dbg !665
  %1092 = icmp eq i32 %1091, 2, !dbg !665
  br i1 %1092, label %1093, label %1094, !dbg !665

1093:                                             ; preds = %1089
  br label %1100, !dbg !665

1094:                                             ; preds = %1089
  %1095 = load i8, ptr %206, align 1, !dbg !665
  %1096 = zext i8 %1095 to i32, !dbg !665
  %1097 = icmp eq i32 %1096, 4, !dbg !665
  %1098 = zext i1 %1097 to i64, !dbg !665
  %1099 = select i1 %1097, i32 2, i32 3, !dbg !665
  br label %1100, !dbg !665

1100:                                             ; preds = %1094, %1093
  %1101 = phi i32 [ 1, %1093 ], [ %1099, %1094 ], !dbg !665
  br label %1102, !dbg !665

1102:                                             ; preds = %1100, %1088
  %1103 = phi i32 [ 0, %1088 ], [ %1101, %1100 ], !dbg !665
  %1104 = icmp eq i32 %1103, 0, !dbg !665
  br i1 %1104, label %1105, label %1160, !dbg !654

1105:                                             ; preds = %1102
  %1106 = load i8, ptr %59, align 1, !dbg !667
  %1107 = zext i8 %1106 to i32, !dbg !667
  %1108 = icmp eq i32 %1107, 4, !dbg !667
  br i1 %1108, label %1109, label %1125, !dbg !671

1109:                                             ; preds = %1105
  call void @llvm.dbg.declare(metadata ptr %209, metadata !672, metadata !DIExpression()), !dbg !674
  %1110 = load ptr, ptr %56, align 8, !dbg !674
  %1111 = ptrtoint ptr %1110 to i64, !dbg !674
  %1112 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !674
  %1113 = ptrtoint ptr %1112 to i64, !dbg !674
  %1114 = add i64 %1113, 1, !dbg !674
  %1115 = inttoptr i64 %1114 to ptr, !dbg !674
  %1116 = ptrtoint ptr %1115 to i64, !dbg !674
  %1117 = sub i64 %1111, %1116, !dbg !674
  store i64 %1117, ptr %209, align 8, !dbg !674
  %1118 = load i64, ptr %209, align 8, !dbg !674
  %1119 = call i64 asm sideeffect "", "=r,0"(i64 %1118) #8, !dbg !674, !srcloc !675
  store i64 %1119, ptr %209, align 8, !dbg !674
  %1120 = load i64, ptr %209, align 8, !dbg !674
  %1121 = load i64, ptr %118, align 8, !dbg !674
  %1122 = add i64 %1120, %1121, !dbg !674
  store i64 %1122, ptr %210, align 8, !dbg !674
  %1123 = load i64, ptr %210, align 8, !dbg !674
  %1124 = inttoptr i64 %1123 to ptr, !dbg !667
  store ptr %1124, ptr %56, align 8, !dbg !667
  br label %1125, !dbg !667

1125:                                             ; preds = %1109, %1105
  br label %1126, !dbg !676

1126:                                             ; preds = %1125
  %1127 = load i8, ptr %59, align 1, !dbg !677
  %1128 = zext i8 %1127 to i32, !dbg !677
  %1129 = icmp eq i32 %1128, 0, !dbg !677
  br i1 %1129, label %1130, label %1143, !dbg !680

1130:                                             ; preds = %1126
  %1131 = load i8, ptr %207, align 1, !dbg !681
  %1132 = zext i8 %1131 to i32, !dbg !681
  %1133 = icmp eq i32 %1132, 8, !dbg !681
  br i1 %1133, label %1134, label %1138, !dbg !684

1134:                                             ; preds = %1130
  %1135 = load i64, ptr %208, align 8, !dbg !681
  %1136 = trunc i64 %1135 to i8, !dbg !681
  %1137 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 1, !dbg !681
  store i8 %1136, ptr %1137, align 1, !dbg !681
  br label %1142, !dbg !681

1138:                                             ; preds = %1130
  %1139 = load i64, ptr %208, align 8, !dbg !681
  %1140 = trunc i64 %1139 to i8, !dbg !681
  %1141 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 0, !dbg !681
  store i8 %1140, ptr %1141, align 8, !dbg !681
  br label %1142

1142:                                             ; preds = %1138, %1134
  br label %1158, !dbg !684

1143:                                             ; preds = %1126
  call void @llvm.dbg.declare(metadata ptr %211, metadata !685, metadata !DIExpression()), !dbg !693
  %1144 = load ptr, ptr %56, align 8, !dbg !693
  store ptr %1144, ptr %211, align 8, !dbg !693
  %1145 = load i8, ptr %207, align 1, !dbg !694
  %1146 = zext i8 %1145 to i32, !dbg !694
  %1147 = icmp eq i32 %1146, 8, !dbg !694
  br i1 %1147, label %1148, label %1152, !dbg !693

1148:                                             ; preds = %1143
  %1149 = load i64, ptr %208, align 8, !dbg !694
  %1150 = trunc i64 %1149 to i8, !dbg !694
  %1151 = getelementptr inbounds [8 x i8], ptr %211, i64 0, i64 1, !dbg !694
  store volatile i8 %1150, ptr %1151, align 1, !dbg !694
  br label %1156, !dbg !694

1152:                                             ; preds = %1143
  %1153 = load i64, ptr %208, align 8, !dbg !694
  %1154 = trunc i64 %1153 to i8, !dbg !694
  %1155 = getelementptr inbounds [8 x i8], ptr %211, i64 0, i64 0, !dbg !694
  store volatile i8 %1154, ptr %1155, align 8, !dbg !694
  br label %1156

1156:                                             ; preds = %1152, %1148
  %1157 = load volatile ptr, ptr %211, align 8, !dbg !693
  store ptr %1157, ptr %56, align 8, !dbg !693
  br label %1158

1158:                                             ; preds = %1156, %1142
  store i8 0, ptr %59, align 1, !dbg !680
  br label %1159, !dbg !680

1159:                                             ; preds = %1158
  br label %1251, !dbg !676

1160:                                             ; preds = %1102
  %1161 = load i8, ptr %206, align 1, !dbg !696
  %1162 = zext i8 %1161 to i32, !dbg !696
  %1163 = icmp eq i32 %1162, 1, !dbg !696
  br i1 %1163, label %1164, label %1165, !dbg !696

1164:                                             ; preds = %1160
  br label %1178, !dbg !696

1165:                                             ; preds = %1160
  %1166 = load i8, ptr %206, align 1, !dbg !696
  %1167 = zext i8 %1166 to i32, !dbg !696
  %1168 = icmp eq i32 %1167, 2, !dbg !696
  br i1 %1168, label %1169, label %1170, !dbg !696

1169:                                             ; preds = %1165
  br label %1176, !dbg !696

1170:                                             ; preds = %1165
  %1171 = load i8, ptr %206, align 1, !dbg !696
  %1172 = zext i8 %1171 to i32, !dbg !696
  %1173 = icmp eq i32 %1172, 4, !dbg !696
  %1174 = zext i1 %1173 to i64, !dbg !696
  %1175 = select i1 %1173, i32 2, i32 3, !dbg !696
  br label %1176, !dbg !696

1176:                                             ; preds = %1170, %1169
  %1177 = phi i32 [ 1, %1169 ], [ %1175, %1170 ], !dbg !696
  br label %1178, !dbg !696

1178:                                             ; preds = %1176, %1164
  %1179 = phi i32 [ 0, %1164 ], [ %1177, %1176 ], !dbg !696
  %1180 = icmp eq i32 %1179, 1, !dbg !696
  br i1 %1180, label %1181, label %1216, !dbg !665

1181:                                             ; preds = %1178
  %1182 = load i8, ptr %59, align 1, !dbg !698
  %1183 = zext i8 %1182 to i32, !dbg !698
  %1184 = icmp eq i32 %1183, 4, !dbg !698
  br i1 %1184, label %1185, label %1201, !dbg !702

1185:                                             ; preds = %1181
  call void @llvm.dbg.declare(metadata ptr %212, metadata !703, metadata !DIExpression()), !dbg !705
  %1186 = load ptr, ptr %56, align 8, !dbg !705
  %1187 = ptrtoint ptr %1186 to i64, !dbg !705
  %1188 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !705
  %1189 = ptrtoint ptr %1188 to i64, !dbg !705
  %1190 = add i64 %1189, 1, !dbg !705
  %1191 = inttoptr i64 %1190 to ptr, !dbg !705
  %1192 = ptrtoint ptr %1191 to i64, !dbg !705
  %1193 = sub i64 %1187, %1192, !dbg !705
  store i64 %1193, ptr %212, align 8, !dbg !705
  %1194 = load i64, ptr %212, align 8, !dbg !705
  %1195 = call i64 asm sideeffect "", "=r,0"(i64 %1194) #8, !dbg !705, !srcloc !706
  store i64 %1195, ptr %212, align 8, !dbg !705
  %1196 = load i64, ptr %212, align 8, !dbg !705
  %1197 = load i64, ptr %118, align 8, !dbg !705
  %1198 = add i64 %1196, %1197, !dbg !705
  store i64 %1198, ptr %213, align 8, !dbg !705
  %1199 = load i64, ptr %213, align 8, !dbg !705
  %1200 = inttoptr i64 %1199 to ptr, !dbg !698
  store ptr %1200, ptr %56, align 8, !dbg !698
  br label %1201, !dbg !698

1201:                                             ; preds = %1185, %1181
  br label %1202, !dbg !707

1202:                                             ; preds = %1201
  %1203 = load i8, ptr %59, align 1, !dbg !708
  %1204 = zext i8 %1203 to i32, !dbg !708
  %1205 = icmp eq i32 %1204, 0, !dbg !708
  br i1 %1205, label %1206, label %1209, !dbg !711

1206:                                             ; preds = %1202
  %1207 = load i64, ptr %208, align 8, !dbg !712
  %1208 = trunc i64 %1207 to i16, !dbg !712
  store i16 %1208, ptr %56, align 8, !dbg !712
  br label %1214, !dbg !712

1209:                                             ; preds = %1202
  call void @llvm.dbg.declare(metadata ptr %214, metadata !714, metadata !DIExpression()), !dbg !722
  %1210 = load ptr, ptr %56, align 8, !dbg !722
  store ptr %1210, ptr %214, align 8, !dbg !722
  %1211 = load i64, ptr %208, align 8, !dbg !722
  %1212 = trunc i64 %1211 to i16, !dbg !722
  store volatile i16 %1212, ptr %214, align 8, !dbg !722
  %1213 = load volatile ptr, ptr %214, align 8, !dbg !722
  store ptr %1213, ptr %56, align 8, !dbg !722
  br label %1214

1214:                                             ; preds = %1209, %1206
  store i8 0, ptr %59, align 1, !dbg !711
  br label %1215, !dbg !711

1215:                                             ; preds = %1214
  br label %1250, !dbg !707

1216:                                             ; preds = %1178
  %1217 = load i8, ptr %206, align 1, !dbg !723
  %1218 = zext i8 %1217 to i32, !dbg !723
  %1219 = icmp eq i32 %1218, 1, !dbg !723
  br i1 %1219, label %1220, label %1221, !dbg !723

1220:                                             ; preds = %1216
  br label %1234, !dbg !723

1221:                                             ; preds = %1216
  %1222 = load i8, ptr %206, align 1, !dbg !723
  %1223 = zext i8 %1222 to i32, !dbg !723
  %1224 = icmp eq i32 %1223, 2, !dbg !723
  br i1 %1224, label %1225, label %1226, !dbg !723

1225:                                             ; preds = %1221
  br label %1232, !dbg !723

1226:                                             ; preds = %1221
  %1227 = load i8, ptr %206, align 1, !dbg !723
  %1228 = zext i8 %1227 to i32, !dbg !723
  %1229 = icmp eq i32 %1228, 4, !dbg !723
  %1230 = zext i1 %1229 to i64, !dbg !723
  %1231 = select i1 %1229, i32 2, i32 3, !dbg !723
  br label %1232, !dbg !723

1232:                                             ; preds = %1226, %1225
  %1233 = phi i32 [ 1, %1225 ], [ %1231, %1226 ], !dbg !723
  br label %1234, !dbg !723

1234:                                             ; preds = %1232, %1220
  %1235 = phi i32 [ 0, %1220 ], [ %1233, %1232 ], !dbg !723
  %1236 = icmp eq i32 %1235, 2, !dbg !723
  br i1 %1236, label %1237, label %1244, !dbg !696

1237:                                             ; preds = %1234
  br label %1238, !dbg !725

1238:                                             ; preds = %1237
  %1239 = load i64, ptr %208, align 8, !dbg !727
  %1240 = trunc i64 %1239 to i32, !dbg !727
  %1241 = zext i32 %1240 to i64, !dbg !727
  %1242 = inttoptr i64 %1241 to ptr, !dbg !727
  store ptr %1242, ptr %56, align 8, !dbg !727
  store i8 0, ptr %59, align 1, !dbg !727
  br label %1243, !dbg !727

1243:                                             ; preds = %1238
  br label %1249, !dbg !725

1244:                                             ; preds = %1234
  br label %1245, !dbg !729

1245:                                             ; preds = %1244
  %1246 = load i64, ptr %208, align 8, !dbg !731
  %1247 = inttoptr i64 %1246 to ptr, !dbg !731
  store ptr %1247, ptr %56, align 8, !dbg !731
  store i8 0, ptr %59, align 1, !dbg !731
  br label %1248, !dbg !731

1248:                                             ; preds = %1245
  br label %1249

1249:                                             ; preds = %1248, %1243
  br label %1250

1250:                                             ; preds = %1249, %1215
  br label %1251

1251:                                             ; preds = %1250, %1159
  br label %1252, !dbg !654

1252:                                             ; preds = %1251
  br label %1253

1253:                                             ; preds = %1252, %1069
  br label %2633, !dbg !629

1254:                                             ; preds = %457, %444
  %1255 = load i8, ptr %53, align 1, !dbg !733
  %1256 = zext i8 %1255 to i32, !dbg !733
  %1257 = icmp ne i32 %1256, 0, !dbg !733
  br i1 %1257, label %1258, label %1369, !dbg !733

1258:                                             ; preds = %1254
  call void @llvm.dbg.declare(metadata ptr %215, metadata !735, metadata !DIExpression()), !dbg !737
  store i8 0, ptr %215, align 1, !dbg !737
  %1259 = load i8, ptr %73, align 1, !dbg !737
  store i8 %1259, ptr %215, align 1, !dbg !737
  %1260 = load i8, ptr %215, align 1, !dbg !737
  store i8 %1260, ptr %216, align 1, !dbg !737
  %1261 = load i8, ptr %216, align 1, !dbg !737
  %1262 = zext i8 %1261 to i32, !dbg !733
  %1263 = icmp eq i32 %1262, 1, !dbg !733
  br i1 %1263, label %1264, label %1369, !dbg !370

1264:                                             ; preds = %1258
  call void @llvm.dbg.declare(metadata ptr %217, metadata !738, metadata !DIExpression()), !dbg !740
  call void @llvm.dbg.declare(metadata ptr %218, metadata !741, metadata !DIExpression()), !dbg !743
  %1265 = load ptr, ptr %166, align 8, !dbg !743
  %1266 = ptrtoint ptr %1265 to i64, !dbg !743
  %1267 = load ptr, ptr %54, align 8, !dbg !743
  %1268 = ptrtoint ptr %1267 to i64, !dbg !743
  %1269 = sub i64 %1266, %1268, !dbg !743
  %1270 = load i64, ptr %158, align 8, !dbg !743
  %1271 = add i64 %1269, %1270, !dbg !743
  store i64 %1271, ptr %218, align 8, !dbg !743
  call void @llvm.dbg.declare(metadata ptr %219, metadata !744, metadata !DIExpression()), !dbg !743
  %1272 = load ptr, ptr %54, align 8, !dbg !743
  store ptr %1272, ptr %219, align 8, !dbg !743
  call void @llvm.dbg.declare(metadata ptr %220, metadata !747, metadata !DIExpression()), !dbg !743
  store i64 0, ptr %220, align 8, !dbg !743
  %1273 = load i8, ptr %150, align 1, !dbg !748
  %1274 = zext i8 %1273 to i32, !dbg !748
  %1275 = icmp eq i32 %1274, 8, !dbg !748
  br i1 %1275, label %1276, label %1286, !dbg !748

1276:                                             ; preds = %1264
  %1277 = load i64, ptr %218, align 8, !dbg !748
  %1278 = icmp eq i64 %1277, 0, !dbg !748
  br i1 %1278, label %1279, label %1286, !dbg !743

1279:                                             ; preds = %1276
  %1280 = load ptr, ptr %219, align 8, !dbg !748
  %1281 = getelementptr inbounds %struct.xdp_md, ptr %1280, i32 0, i32 0, !dbg !748
  %1282 = load volatile i32, ptr %1281, align 4, !dbg !748
  %1283 = zext i32 %1282 to i64, !dbg !748
  %1284 = inttoptr i64 %1283 to ptr, !dbg !748
  %1285 = ptrtoint ptr %1284 to i64, !dbg !748
  store i64 %1285, ptr %220, align 8, !dbg !748
  br label %1317, !dbg !748

1286:                                             ; preds = %1276, %1264
  %1287 = load i8, ptr %150, align 1, !dbg !750
  %1288 = zext i8 %1287 to i32, !dbg !750
  %1289 = icmp eq i32 %1288, 8, !dbg !750
  br i1 %1289, label %1290, label %1300, !dbg !750

1290:                                             ; preds = %1286
  %1291 = load i64, ptr %218, align 8, !dbg !750
  %1292 = icmp eq i64 %1291, 8, !dbg !750
  br i1 %1292, label %1293, label %1300, !dbg !748

1293:                                             ; preds = %1290
  %1294 = load ptr, ptr %219, align 8, !dbg !750
  %1295 = getelementptr inbounds %struct.xdp_md, ptr %1294, i32 0, i32 1, !dbg !750
  %1296 = load volatile i32, ptr %1295, align 4, !dbg !750
  %1297 = zext i32 %1296 to i64, !dbg !750
  %1298 = inttoptr i64 %1297 to ptr, !dbg !750
  %1299 = ptrtoint ptr %1298 to i64, !dbg !750
  store i64 %1299, ptr %220, align 8, !dbg !750
  br label %1316, !dbg !750

1300:                                             ; preds = %1290, %1286
  %1301 = load i8, ptr %150, align 1, !dbg !752
  %1302 = zext i8 %1301 to i32, !dbg !752
  %1303 = icmp eq i32 %1302, 8, !dbg !752
  br i1 %1303, label %1304, label %1314, !dbg !752

1304:                                             ; preds = %1300
  %1305 = load i64, ptr %218, align 8, !dbg !752
  %1306 = icmp eq i64 %1305, 16, !dbg !752
  br i1 %1306, label %1307, label %1314, !dbg !750

1307:                                             ; preds = %1304
  %1308 = load ptr, ptr %219, align 8, !dbg !752
  %1309 = getelementptr inbounds %struct.xdp_md, ptr %1308, i32 0, i32 2, !dbg !752
  %1310 = load volatile i32, ptr %1309, align 4, !dbg !752
  %1311 = zext i32 %1310 to i64, !dbg !752
  %1312 = inttoptr i64 %1311 to ptr, !dbg !752
  %1313 = ptrtoint ptr %1312 to i64, !dbg !752
  store i64 %1313, ptr %220, align 8, !dbg !752
  br label %1315, !dbg !752

1314:                                             ; preds = %1304, %1300
  call void @x86_sim_unmapped_xdp_read(), !dbg !752, !srcloc !754
  br label %1315

1315:                                             ; preds = %1314, %1307
  br label %1316

1316:                                             ; preds = %1315, %1293
  br label %1317

1317:                                             ; preds = %1316, %1279
  %1318 = load i64, ptr %220, align 8, !dbg !743
  %1319 = call i64 asm sideeffect "", "=r,0"(i64 %1318) #8, !dbg !743, !srcloc !755
  store i64 %1319, ptr %220, align 8, !dbg !743
  %1320 = load i64, ptr %220, align 8, !dbg !743
  store i64 %1320, ptr %221, align 8, !dbg !743
  %1321 = load i64, ptr %221, align 8, !dbg !743
  store i64 %1321, ptr %217, align 8, !dbg !740
  call void @llvm.dbg.declare(metadata ptr %222, metadata !756, metadata !DIExpression()), !dbg !740
  call void @llvm.dbg.declare(metadata ptr %223, metadata !757, metadata !DIExpression()), !dbg !759
  store i8 0, ptr %223, align 1, !dbg !759
  call void @llvm.dbg.declare(metadata ptr %224, metadata !760, metadata !DIExpression()), !dbg !759
  %1322 = load ptr, ptr %166, align 8, !dbg !759
  %1323 = ptrtoint ptr %1322 to i64, !dbg !759
  %1324 = load ptr, ptr %54, align 8, !dbg !759
  %1325 = ptrtoint ptr %1324 to i64, !dbg !759
  %1326 = sub i64 %1323, %1325, !dbg !759
  %1327 = load i64, ptr %158, align 8, !dbg !759
  %1328 = add i64 %1326, %1327, !dbg !759
  store i64 %1328, ptr %224, align 8, !dbg !759
  call void @llvm.dbg.declare(metadata ptr %225, metadata !761, metadata !DIExpression()), !dbg !759
  store i8 0, ptr %225, align 1, !dbg !759
  %1329 = load i8, ptr %223, align 1, !dbg !762
  %1330 = zext i8 %1329 to i32, !dbg !762
  %1331 = icmp eq i32 %1330, 0, !dbg !762
  br i1 %1331, label %1332, label %1335, !dbg !762

1332:                                             ; preds = %1317
  %1333 = load i64, ptr %224, align 8, !dbg !762
  %1334 = icmp eq i64 %1333, 0, !dbg !762
  br i1 %1334, label %1342, label %1335, !dbg !762

1335:                                             ; preds = %1332, %1317
  %1336 = load i8, ptr %223, align 1, !dbg !762
  %1337 = zext i8 %1336 to i32, !dbg !762
  %1338 = icmp eq i32 %1337, 1, !dbg !762
  br i1 %1338, label %1339, label %1343, !dbg !762

1339:                                             ; preds = %1335
  %1340 = load i64, ptr %224, align 8, !dbg !762
  %1341 = icmp eq i64 %1340, 208, !dbg !762
  br i1 %1341, label %1342, label %1343, !dbg !759

1342:                                             ; preds = %1339, %1332
  store i8 2, ptr %225, align 1, !dbg !762
  br label %1359, !dbg !762

1343:                                             ; preds = %1339, %1335
  %1344 = load i8, ptr %223, align 1, !dbg !764
  %1345 = zext i8 %1344 to i32, !dbg !764
  %1346 = icmp eq i32 %1345, 0, !dbg !764
  br i1 %1346, label %1347, label %1350, !dbg !764

1347:                                             ; preds = %1343
  %1348 = load i64, ptr %224, align 8, !dbg !764
  %1349 = icmp eq i64 %1348, 8, !dbg !764
  br i1 %1349, label %1357, label %1350, !dbg !764

1350:                                             ; preds = %1347, %1343
  %1351 = load i8, ptr %223, align 1, !dbg !764
  %1352 = zext i8 %1351 to i32, !dbg !764
  %1353 = icmp eq i32 %1352, 1, !dbg !764
  br i1 %1353, label %1354, label %1358, !dbg !764

1354:                                             ; preds = %1350
  %1355 = load i64, ptr %224, align 8, !dbg !764
  %1356 = icmp eq i64 %1355, 80, !dbg !764
  br i1 %1356, label %1357, label %1358, !dbg !762

1357:                                             ; preds = %1354, %1347
  store i8 3, ptr %225, align 1, !dbg !764
  br label %1358, !dbg !764

1358:                                             ; preds = %1357, %1354, %1350
  br label %1359

1359:                                             ; preds = %1358, %1342
  %1360 = load i8, ptr %225, align 1, !dbg !759
  store i8 %1360, ptr %226, align 1, !dbg !762
  %1361 = load i8, ptr %226, align 1, !dbg !759
  store i8 %1361, ptr %222, align 1, !dbg !740
  br label %1362, !dbg !766

1362:                                             ; preds = %1359
  call void @llvm.dbg.declare(metadata ptr %227, metadata !768, metadata !DIExpression()), !dbg !770
  %1363 = load i64, ptr %217, align 8, !dbg !770
  %1364 = inttoptr i64 %1363 to ptr, !dbg !770
  store ptr %1364, ptr %227, align 8, !dbg !770
  call void @llvm.dbg.declare(metadata ptr %228, metadata !771, metadata !DIExpression()), !dbg !770
  %1365 = load i8, ptr %222, align 1, !dbg !770
  store i8 %1365, ptr %228, align 1, !dbg !770
  %1366 = load ptr, ptr %227, align 8, !dbg !770
  store ptr %1366, ptr %56, align 8, !dbg !770
  %1367 = load i8, ptr %228, align 1, !dbg !770
  store i8 %1367, ptr %59, align 1, !dbg !770
  br label %1368, !dbg !770

1368:                                             ; preds = %1362
  br label %2632, !dbg !740

1369:                                             ; preds = %1258, %1254
  call void @llvm.dbg.declare(metadata ptr %229, metadata !772, metadata !DIExpression()), !dbg !774
  store i8 0, ptr %229, align 1, !dbg !775
  %1370 = load i8, ptr %229, align 1, !dbg !774
  store i8 %1370, ptr %230, align 1, !dbg !775
  %1371 = load i8, ptr %230, align 1, !dbg !774
  %1372 = zext i8 %1371 to i32, !dbg !733
  switch i32 %1372, label %2237 [
    i32 0, label %1373
    i32 1, label %1920
  ], !dbg !733

1373:                                             ; preds = %1369
  call void @llvm.dbg.declare(metadata ptr %231, metadata !777, metadata !DIExpression()), !dbg !780
  %1374 = load ptr, ptr %166, align 8, !dbg !780
  %1375 = ptrtoint ptr %1374 to i64, !dbg !780
  %1376 = load i64, ptr %158, align 8, !dbg !780
  %1377 = add nsw i64 %1375, %1376, !dbg !780
  %1378 = add i64 %1377, 1, !dbg !780
  store i64 %1378, ptr %231, align 8, !dbg !780
  call void @llvm.dbg.declare(metadata ptr %232, metadata !781, metadata !DIExpression()), !dbg !780
  %1379 = load i8, ptr %150, align 1, !dbg !782
  store i8 %1379, ptr %3, align 1
  call void @llvm.dbg.declare(metadata ptr %3, metadata !656, metadata !DIExpression()), !dbg !784
  %1380 = load i8, ptr %3, align 1, !dbg !786
  %1381 = zext i8 %1380 to i32, !dbg !786
  %1382 = icmp ne i32 %1381, 0, !dbg !786
  br i1 %1382, label %1383, label %1386, !dbg !786

1383:                                             ; preds = %1373
  %1384 = load i8, ptr %3, align 1, !dbg !786
  %1385 = zext i8 %1384 to i32, !dbg !786
  br label %1387, !dbg !786

1386:                                             ; preds = %1373
  br label %1387, !dbg !786

1387:                                             ; preds = %1383, %1386
  %1388 = phi i32 [ %1385, %1383 ], [ 8, %1386 ], !dbg !786
  %1389 = trunc i32 %1388 to i8, !dbg !786
  %1390 = zext i8 %1389 to i32, !dbg !782
  %1391 = icmp eq i32 %1390, 8, !dbg !782
  br i1 %1391, label %1392, label %1399, !dbg !782

1392:                                             ; preds = %1387
  %1393 = load i64, ptr %231, align 8, !dbg !782
  %1394 = and i64 %1393, 7, !dbg !782
  %1395 = icmp eq i64 %1394, 0, !dbg !782
  %1396 = zext i1 %1395 to i64, !dbg !782
  %1397 = select i1 %1395, i32 1, i32 0, !dbg !782
  %1398 = icmp ne i32 %1397, 0, !dbg !782
  br label %1399

1399:                                             ; preds = %1392, %1387
  %1400 = phi i1 [ false, %1387 ], [ %1398, %1392 ], !dbg !787
  %1401 = zext i1 %1400 to i64, !dbg !782
  %1402 = select i1 %1400, i32 1, i32 0, !dbg !782
  %1403 = trunc i32 %1402 to i8, !dbg !782
  %1404 = icmp ne i8 %1403, 0, !dbg !782
  br i1 %1404, label %1405, label %1410, !dbg !780

1405:                                             ; preds = %1399
  %1406 = load i64, ptr %231, align 8, !dbg !788
  %1407 = lshr i64 %1406, 3, !dbg !788
  %1408 = getelementptr inbounds [1 x i64], ptr %144, i64 0, i64 %1407, !dbg !788
  %1409 = load volatile i64, ptr %1408, align 8, !dbg !788
  store i64 %1409, ptr %232, align 8, !dbg !788
  br label %1666, !dbg !788

1410:                                             ; preds = %1399
  call void @llvm.dbg.declare(metadata ptr %233, metadata !790, metadata !DIExpression()), !dbg !793
  %1411 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !793
  store ptr %1411, ptr %233, align 8, !dbg !793
  call void @llvm.dbg.declare(metadata ptr %234, metadata !794, metadata !DIExpression()), !dbg !793
  %1412 = load i8, ptr %150, align 1, !dbg !793
  store i8 %1412, ptr %4, align 1
  call void @llvm.dbg.declare(metadata ptr %4, metadata !656, metadata !DIExpression()), !dbg !795
  %1413 = load i8, ptr %4, align 1, !dbg !797
  %1414 = zext i8 %1413 to i32, !dbg !797
  %1415 = icmp ne i32 %1414, 0, !dbg !797
  br i1 %1415, label %1416, label %1419, !dbg !797

1416:                                             ; preds = %1410
  %1417 = load i8, ptr %4, align 1, !dbg !797
  %1418 = zext i8 %1417 to i32, !dbg !797
  br label %1420, !dbg !797

1419:                                             ; preds = %1410
  br label %1420, !dbg !797

1420:                                             ; preds = %1416, %1419
  %1421 = phi i32 [ %1418, %1416 ], [ 8, %1419 ], !dbg !797
  %1422 = trunc i32 %1421 to i8, !dbg !797
  store i8 %1422, ptr %234, align 1, !dbg !793
  %1423 = load ptr, ptr %233, align 8, !dbg !793
  %1424 = load i64, ptr %231, align 8, !dbg !793
  %1425 = getelementptr inbounds i8, ptr %1423, i64 %1424, !dbg !793
  %1426 = load volatile i8, ptr %1425, align 1, !dbg !793
  %1427 = zext i8 %1426 to i64, !dbg !793
  store i64 %1427, ptr %232, align 8, !dbg !793
  %1428 = load i8, ptr %234, align 1, !dbg !798
  %1429 = zext i8 %1428 to i32, !dbg !798
  %1430 = icmp eq i32 %1429, 1, !dbg !798
  br i1 %1430, label %1431, label %1432, !dbg !798

1431:                                             ; preds = %1420
  br label %1445, !dbg !798

1432:                                             ; preds = %1420
  %1433 = load i8, ptr %234, align 1, !dbg !798
  %1434 = zext i8 %1433 to i32, !dbg !798
  %1435 = icmp eq i32 %1434, 2, !dbg !798
  br i1 %1435, label %1436, label %1437, !dbg !798

1436:                                             ; preds = %1432
  br label %1443, !dbg !798

1437:                                             ; preds = %1432
  %1438 = load i8, ptr %234, align 1, !dbg !798
  %1439 = zext i8 %1438 to i32, !dbg !798
  %1440 = icmp eq i32 %1439, 4, !dbg !798
  %1441 = zext i1 %1440 to i64, !dbg !798
  %1442 = select i1 %1440, i32 15, i32 255, !dbg !798
  br label %1443, !dbg !798

1443:                                             ; preds = %1437, %1436
  %1444 = phi i32 [ 3, %1436 ], [ %1442, %1437 ], !dbg !798
  br label %1445, !dbg !798

1445:                                             ; preds = %1443, %1431
  %1446 = phi i32 [ 1, %1431 ], [ %1444, %1443 ], !dbg !798
  %1447 = lshr i32 %1446, 1, !dbg !798
  %1448 = and i32 %1447, 1, !dbg !798
  %1449 = trunc i32 %1448 to i8, !dbg !798
  %1450 = icmp ne i8 %1449, 0, !dbg !798
  br i1 %1450, label %1451, label %1461, !dbg !793

1451:                                             ; preds = %1445
  %1452 = load ptr, ptr %233, align 8, !dbg !798
  %1453 = load i64, ptr %231, align 8, !dbg !798
  %1454 = add i64 %1453, 1, !dbg !798
  %1455 = getelementptr inbounds i8, ptr %1452, i64 %1454, !dbg !798
  %1456 = load volatile i8, ptr %1455, align 1, !dbg !798
  %1457 = zext i8 %1456 to i64, !dbg !798
  %1458 = shl i64 %1457, 8, !dbg !798
  %1459 = load i64, ptr %232, align 8, !dbg !798
  %1460 = or i64 %1459, %1458, !dbg !798
  store i64 %1460, ptr %232, align 8, !dbg !798
  br label %1461, !dbg !798

1461:                                             ; preds = %1451, %1445
  %1462 = load i8, ptr %234, align 1, !dbg !800
  %1463 = zext i8 %1462 to i32, !dbg !800
  %1464 = icmp eq i32 %1463, 1, !dbg !800
  br i1 %1464, label %1465, label %1466, !dbg !800

1465:                                             ; preds = %1461
  br label %1479, !dbg !800

1466:                                             ; preds = %1461
  %1467 = load i8, ptr %234, align 1, !dbg !800
  %1468 = zext i8 %1467 to i32, !dbg !800
  %1469 = icmp eq i32 %1468, 2, !dbg !800
  br i1 %1469, label %1470, label %1471, !dbg !800

1470:                                             ; preds = %1466
  br label %1477, !dbg !800

1471:                                             ; preds = %1466
  %1472 = load i8, ptr %234, align 1, !dbg !800
  %1473 = zext i8 %1472 to i32, !dbg !800
  %1474 = icmp eq i32 %1473, 4, !dbg !800
  %1475 = zext i1 %1474 to i64, !dbg !800
  %1476 = select i1 %1474, i32 15, i32 255, !dbg !800
  br label %1477, !dbg !800

1477:                                             ; preds = %1471, %1470
  %1478 = phi i32 [ 3, %1470 ], [ %1476, %1471 ], !dbg !800
  br label %1479, !dbg !800

1479:                                             ; preds = %1477, %1465
  %1480 = phi i32 [ 1, %1465 ], [ %1478, %1477 ], !dbg !800
  %1481 = lshr i32 %1480, 2, !dbg !800
  %1482 = and i32 %1481, 1, !dbg !800
  %1483 = trunc i32 %1482 to i8, !dbg !800
  %1484 = icmp ne i8 %1483, 0, !dbg !800
  br i1 %1484, label %1485, label %1495, !dbg !793

1485:                                             ; preds = %1479
  %1486 = load ptr, ptr %233, align 8, !dbg !800
  %1487 = load i64, ptr %231, align 8, !dbg !800
  %1488 = add i64 %1487, 2, !dbg !800
  %1489 = getelementptr inbounds i8, ptr %1486, i64 %1488, !dbg !800
  %1490 = load volatile i8, ptr %1489, align 1, !dbg !800
  %1491 = zext i8 %1490 to i64, !dbg !800
  %1492 = shl i64 %1491, 16, !dbg !800
  %1493 = load i64, ptr %232, align 8, !dbg !800
  %1494 = or i64 %1493, %1492, !dbg !800
  store i64 %1494, ptr %232, align 8, !dbg !800
  br label %1495, !dbg !800

1495:                                             ; preds = %1485, %1479
  %1496 = load i8, ptr %234, align 1, !dbg !802
  %1497 = zext i8 %1496 to i32, !dbg !802
  %1498 = icmp eq i32 %1497, 1, !dbg !802
  br i1 %1498, label %1499, label %1500, !dbg !802

1499:                                             ; preds = %1495
  br label %1513, !dbg !802

1500:                                             ; preds = %1495
  %1501 = load i8, ptr %234, align 1, !dbg !802
  %1502 = zext i8 %1501 to i32, !dbg !802
  %1503 = icmp eq i32 %1502, 2, !dbg !802
  br i1 %1503, label %1504, label %1505, !dbg !802

1504:                                             ; preds = %1500
  br label %1511, !dbg !802

1505:                                             ; preds = %1500
  %1506 = load i8, ptr %234, align 1, !dbg !802
  %1507 = zext i8 %1506 to i32, !dbg !802
  %1508 = icmp eq i32 %1507, 4, !dbg !802
  %1509 = zext i1 %1508 to i64, !dbg !802
  %1510 = select i1 %1508, i32 15, i32 255, !dbg !802
  br label %1511, !dbg !802

1511:                                             ; preds = %1505, %1504
  %1512 = phi i32 [ 3, %1504 ], [ %1510, %1505 ], !dbg !802
  br label %1513, !dbg !802

1513:                                             ; preds = %1511, %1499
  %1514 = phi i32 [ 1, %1499 ], [ %1512, %1511 ], !dbg !802
  %1515 = lshr i32 %1514, 3, !dbg !802
  %1516 = and i32 %1515, 1, !dbg !802
  %1517 = trunc i32 %1516 to i8, !dbg !802
  %1518 = icmp ne i8 %1517, 0, !dbg !802
  br i1 %1518, label %1519, label %1529, !dbg !793

1519:                                             ; preds = %1513
  %1520 = load ptr, ptr %233, align 8, !dbg !802
  %1521 = load i64, ptr %231, align 8, !dbg !802
  %1522 = add i64 %1521, 3, !dbg !802
  %1523 = getelementptr inbounds i8, ptr %1520, i64 %1522, !dbg !802
  %1524 = load volatile i8, ptr %1523, align 1, !dbg !802
  %1525 = zext i8 %1524 to i64, !dbg !802
  %1526 = shl i64 %1525, 24, !dbg !802
  %1527 = load i64, ptr %232, align 8, !dbg !802
  %1528 = or i64 %1527, %1526, !dbg !802
  store i64 %1528, ptr %232, align 8, !dbg !802
  br label %1529, !dbg !802

1529:                                             ; preds = %1519, %1513
  %1530 = load i8, ptr %234, align 1, !dbg !804
  %1531 = zext i8 %1530 to i32, !dbg !804
  %1532 = icmp eq i32 %1531, 1, !dbg !804
  br i1 %1532, label %1533, label %1534, !dbg !804

1533:                                             ; preds = %1529
  br label %1547, !dbg !804

1534:                                             ; preds = %1529
  %1535 = load i8, ptr %234, align 1, !dbg !804
  %1536 = zext i8 %1535 to i32, !dbg !804
  %1537 = icmp eq i32 %1536, 2, !dbg !804
  br i1 %1537, label %1538, label %1539, !dbg !804

1538:                                             ; preds = %1534
  br label %1545, !dbg !804

1539:                                             ; preds = %1534
  %1540 = load i8, ptr %234, align 1, !dbg !804
  %1541 = zext i8 %1540 to i32, !dbg !804
  %1542 = icmp eq i32 %1541, 4, !dbg !804
  %1543 = zext i1 %1542 to i64, !dbg !804
  %1544 = select i1 %1542, i32 15, i32 255, !dbg !804
  br label %1545, !dbg !804

1545:                                             ; preds = %1539, %1538
  %1546 = phi i32 [ 3, %1538 ], [ %1544, %1539 ], !dbg !804
  br label %1547, !dbg !804

1547:                                             ; preds = %1545, %1533
  %1548 = phi i32 [ 1, %1533 ], [ %1546, %1545 ], !dbg !804
  %1549 = lshr i32 %1548, 4, !dbg !804
  %1550 = and i32 %1549, 1, !dbg !804
  %1551 = trunc i32 %1550 to i8, !dbg !804
  %1552 = icmp ne i8 %1551, 0, !dbg !804
  br i1 %1552, label %1553, label %1563, !dbg !793

1553:                                             ; preds = %1547
  %1554 = load ptr, ptr %233, align 8, !dbg !804
  %1555 = load i64, ptr %231, align 8, !dbg !804
  %1556 = add i64 %1555, 4, !dbg !804
  %1557 = getelementptr inbounds i8, ptr %1554, i64 %1556, !dbg !804
  %1558 = load volatile i8, ptr %1557, align 1, !dbg !804
  %1559 = zext i8 %1558 to i64, !dbg !804
  %1560 = shl i64 %1559, 32, !dbg !804
  %1561 = load i64, ptr %232, align 8, !dbg !804
  %1562 = or i64 %1561, %1560, !dbg !804
  store i64 %1562, ptr %232, align 8, !dbg !804
  br label %1563, !dbg !804

1563:                                             ; preds = %1553, %1547
  %1564 = load i8, ptr %234, align 1, !dbg !806
  %1565 = zext i8 %1564 to i32, !dbg !806
  %1566 = icmp eq i32 %1565, 1, !dbg !806
  br i1 %1566, label %1567, label %1568, !dbg !806

1567:                                             ; preds = %1563
  br label %1581, !dbg !806

1568:                                             ; preds = %1563
  %1569 = load i8, ptr %234, align 1, !dbg !806
  %1570 = zext i8 %1569 to i32, !dbg !806
  %1571 = icmp eq i32 %1570, 2, !dbg !806
  br i1 %1571, label %1572, label %1573, !dbg !806

1572:                                             ; preds = %1568
  br label %1579, !dbg !806

1573:                                             ; preds = %1568
  %1574 = load i8, ptr %234, align 1, !dbg !806
  %1575 = zext i8 %1574 to i32, !dbg !806
  %1576 = icmp eq i32 %1575, 4, !dbg !806
  %1577 = zext i1 %1576 to i64, !dbg !806
  %1578 = select i1 %1576, i32 15, i32 255, !dbg !806
  br label %1579, !dbg !806

1579:                                             ; preds = %1573, %1572
  %1580 = phi i32 [ 3, %1572 ], [ %1578, %1573 ], !dbg !806
  br label %1581, !dbg !806

1581:                                             ; preds = %1579, %1567
  %1582 = phi i32 [ 1, %1567 ], [ %1580, %1579 ], !dbg !806
  %1583 = lshr i32 %1582, 5, !dbg !806
  %1584 = and i32 %1583, 1, !dbg !806
  %1585 = trunc i32 %1584 to i8, !dbg !806
  %1586 = icmp ne i8 %1585, 0, !dbg !806
  br i1 %1586, label %1587, label %1597, !dbg !793

1587:                                             ; preds = %1581
  %1588 = load ptr, ptr %233, align 8, !dbg !806
  %1589 = load i64, ptr %231, align 8, !dbg !806
  %1590 = add i64 %1589, 5, !dbg !806
  %1591 = getelementptr inbounds i8, ptr %1588, i64 %1590, !dbg !806
  %1592 = load volatile i8, ptr %1591, align 1, !dbg !806
  %1593 = zext i8 %1592 to i64, !dbg !806
  %1594 = shl i64 %1593, 40, !dbg !806
  %1595 = load i64, ptr %232, align 8, !dbg !806
  %1596 = or i64 %1595, %1594, !dbg !806
  store i64 %1596, ptr %232, align 8, !dbg !806
  br label %1597, !dbg !806

1597:                                             ; preds = %1587, %1581
  %1598 = load i8, ptr %234, align 1, !dbg !808
  %1599 = zext i8 %1598 to i32, !dbg !808
  %1600 = icmp eq i32 %1599, 1, !dbg !808
  br i1 %1600, label %1601, label %1602, !dbg !808

1601:                                             ; preds = %1597
  br label %1615, !dbg !808

1602:                                             ; preds = %1597
  %1603 = load i8, ptr %234, align 1, !dbg !808
  %1604 = zext i8 %1603 to i32, !dbg !808
  %1605 = icmp eq i32 %1604, 2, !dbg !808
  br i1 %1605, label %1606, label %1607, !dbg !808

1606:                                             ; preds = %1602
  br label %1613, !dbg !808

1607:                                             ; preds = %1602
  %1608 = load i8, ptr %234, align 1, !dbg !808
  %1609 = zext i8 %1608 to i32, !dbg !808
  %1610 = icmp eq i32 %1609, 4, !dbg !808
  %1611 = zext i1 %1610 to i64, !dbg !808
  %1612 = select i1 %1610, i32 15, i32 255, !dbg !808
  br label %1613, !dbg !808

1613:                                             ; preds = %1607, %1606
  %1614 = phi i32 [ 3, %1606 ], [ %1612, %1607 ], !dbg !808
  br label %1615, !dbg !808

1615:                                             ; preds = %1613, %1601
  %1616 = phi i32 [ 1, %1601 ], [ %1614, %1613 ], !dbg !808
  %1617 = lshr i32 %1616, 6, !dbg !808
  %1618 = and i32 %1617, 1, !dbg !808
  %1619 = trunc i32 %1618 to i8, !dbg !808
  %1620 = icmp ne i8 %1619, 0, !dbg !808
  br i1 %1620, label %1621, label %1631, !dbg !793

1621:                                             ; preds = %1615
  %1622 = load ptr, ptr %233, align 8, !dbg !808
  %1623 = load i64, ptr %231, align 8, !dbg !808
  %1624 = add i64 %1623, 6, !dbg !808
  %1625 = getelementptr inbounds i8, ptr %1622, i64 %1624, !dbg !808
  %1626 = load volatile i8, ptr %1625, align 1, !dbg !808
  %1627 = zext i8 %1626 to i64, !dbg !808
  %1628 = shl i64 %1627, 48, !dbg !808
  %1629 = load i64, ptr %232, align 8, !dbg !808
  %1630 = or i64 %1629, %1628, !dbg !808
  store i64 %1630, ptr %232, align 8, !dbg !808
  br label %1631, !dbg !808

1631:                                             ; preds = %1621, %1615
  %1632 = load i8, ptr %234, align 1, !dbg !810
  %1633 = zext i8 %1632 to i32, !dbg !810
  %1634 = icmp eq i32 %1633, 1, !dbg !810
  br i1 %1634, label %1635, label %1636, !dbg !810

1635:                                             ; preds = %1631
  br label %1649, !dbg !810

1636:                                             ; preds = %1631
  %1637 = load i8, ptr %234, align 1, !dbg !810
  %1638 = zext i8 %1637 to i32, !dbg !810
  %1639 = icmp eq i32 %1638, 2, !dbg !810
  br i1 %1639, label %1640, label %1641, !dbg !810

1640:                                             ; preds = %1636
  br label %1647, !dbg !810

1641:                                             ; preds = %1636
  %1642 = load i8, ptr %234, align 1, !dbg !810
  %1643 = zext i8 %1642 to i32, !dbg !810
  %1644 = icmp eq i32 %1643, 4, !dbg !810
  %1645 = zext i1 %1644 to i64, !dbg !810
  %1646 = select i1 %1644, i32 15, i32 255, !dbg !810
  br label %1647, !dbg !810

1647:                                             ; preds = %1641, %1640
  %1648 = phi i32 [ 3, %1640 ], [ %1646, %1641 ], !dbg !810
  br label %1649, !dbg !810

1649:                                             ; preds = %1647, %1635
  %1650 = phi i32 [ 1, %1635 ], [ %1648, %1647 ], !dbg !810
  %1651 = lshr i32 %1650, 7, !dbg !810
  %1652 = and i32 %1651, 1, !dbg !810
  %1653 = trunc i32 %1652 to i8, !dbg !810
  %1654 = icmp ne i8 %1653, 0, !dbg !810
  br i1 %1654, label %1655, label %1665, !dbg !793

1655:                                             ; preds = %1649
  %1656 = load ptr, ptr %233, align 8, !dbg !810
  %1657 = load i64, ptr %231, align 8, !dbg !810
  %1658 = add i64 %1657, 7, !dbg !810
  %1659 = getelementptr inbounds i8, ptr %1656, i64 %1658, !dbg !810
  %1660 = load volatile i8, ptr %1659, align 1, !dbg !810
  %1661 = zext i8 %1660 to i64, !dbg !810
  %1662 = shl i64 %1661, 56, !dbg !810
  %1663 = load i64, ptr %232, align 8, !dbg !810
  %1664 = or i64 %1663, %1662, !dbg !810
  store i64 %1664, ptr %232, align 8, !dbg !810
  br label %1665, !dbg !810

1665:                                             ; preds = %1655, %1649
  br label %1666

1666:                                             ; preds = %1665, %1405
  %1667 = load i64, ptr %232, align 8, !dbg !780
  store i64 %1667, ptr %235, align 8, !dbg !782
  %1668 = load i64, ptr %235, align 8, !dbg !780
  store i64 %1668, ptr %167, align 8, !dbg !812
  call void @llvm.dbg.declare(metadata ptr %236, metadata !813, metadata !DIExpression()), !dbg !812
  call void @llvm.dbg.declare(metadata ptr %237, metadata !818, metadata !DIExpression()), !dbg !820
  call void @llvm.memset.p0.i64(ptr align 8 %237, i8 0, i64 16, i1 false), !dbg !820
  call void @llvm.dbg.declare(metadata ptr %238, metadata !821, metadata !DIExpression()), !dbg !820
  %1669 = load ptr, ptr %166, align 8, !dbg !820
  %1670 = ptrtoint ptr %1669 to i64, !dbg !820
  %1671 = load i64, ptr %165, align 8, !dbg !820
  %1672 = add nsw i64 %1670, %1671, !dbg !820
  %1673 = add i64 %1672, 1, !dbg !820
  store i64 %1673, ptr %238, align 8, !dbg !820
  %1674 = load i8, ptr %150, align 1, !dbg !822
  store i8 %1674, ptr %5, align 1
  call void @llvm.dbg.declare(metadata ptr %5, metadata !656, metadata !DIExpression()), !dbg !824
  %1675 = load i8, ptr %5, align 1, !dbg !826
  %1676 = zext i8 %1675 to i32, !dbg !826
  %1677 = icmp ne i32 %1676, 0, !dbg !826
  br i1 %1677, label %1678, label %1681, !dbg !826

1678:                                             ; preds = %1666
  %1679 = load i8, ptr %5, align 1, !dbg !826
  %1680 = zext i8 %1679 to i32, !dbg !826
  br label %1682, !dbg !826

1681:                                             ; preds = %1666
  br label %1682, !dbg !826

1682:                                             ; preds = %1678, %1681
  %1683 = phi i32 [ %1680, %1678 ], [ 8, %1681 ], !dbg !826
  %1684 = trunc i32 %1683 to i8, !dbg !826
  %1685 = zext i8 %1684 to i32, !dbg !822
  %1686 = icmp eq i32 %1685, 8, !dbg !822
  br i1 %1686, label %1687, label %1708, !dbg !820

1687:                                             ; preds = %1682
  br label %1688, !dbg !827

1688:                                             ; preds = %1687
  %1689 = load i64, ptr %238, align 8, !dbg !829
  %1690 = icmp eq i64 %1689, 0, !dbg !829
  br i1 %1690, label %1691, label %1706, !dbg !829

1691:                                             ; preds = %1688
  %1692 = load i8, ptr %51, align 1, !dbg !829
  %1693 = zext i8 %1692 to i32, !dbg !829
  %1694 = icmp ne i32 %1693, 0, !dbg !829
  br i1 %1694, label %1695, label %1706, !dbg !832

1695:                                             ; preds = %1691
  %1696 = load i8, ptr %51, align 1, !dbg !833
  %1697 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %237, i32 0, i32 1, !dbg !833
  store i8 %1696, ptr %1697, align 8, !dbg !833
  %1698 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %237, i32 0, i32 1, !dbg !835
  %1699 = load i8, ptr %1698, align 8, !dbg !835
  %1700 = zext i8 %1699 to i32, !dbg !835
  %1701 = icmp eq i32 %1700, 4, !dbg !835
  br i1 %1701, label %1702, label %1705, !dbg !833

1702:                                             ; preds = %1695
  %1703 = load ptr, ptr %52, align 8, !dbg !835
  %1704 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %237, i32 0, i32 0, !dbg !835
  store ptr %1703, ptr %1704, align 8, !dbg !835
  br label %1705, !dbg !835

1705:                                             ; preds = %1702, %1695
  br label %1706, !dbg !833

1706:                                             ; preds = %1705, %1691, %1688
  br label %1707, !dbg !832

1707:                                             ; preds = %1706
  br label %1708, !dbg !827

1708:                                             ; preds = %1707, %1682
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %236, ptr align 8 %237, i64 16, i1 false), !dbg !820
  %1709 = load i8, ptr %147, align 1, !dbg !837
  %1710 = zext i8 %1709 to i32, !dbg !837
  %1711 = icmp eq i32 %1710, 8, !dbg !837
  br i1 %1711, label %1712, label %1736, !dbg !837

1712:                                             ; preds = %1708
  %1713 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %236, i32 0, i32 1, !dbg !837
  %1714 = load i8, ptr %1713, align 8, !dbg !837
  %1715 = zext i8 %1714 to i32, !dbg !837
  %1716 = icmp ne i32 %1715, 0, !dbg !837
  br i1 %1716, label %1717, label %1736, !dbg !812

1717:                                             ; preds = %1712
  br label %1718, !dbg !837

1718:                                             ; preds = %1717
  call void @llvm.dbg.declare(metadata ptr %239, metadata !839, metadata !DIExpression()), !dbg !841
  %1719 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %236, i32 0, i32 1, !dbg !841
  %1720 = load i8, ptr %1719, align 8, !dbg !841
  %1721 = zext i8 %1720 to i32, !dbg !841
  %1722 = icmp eq i32 %1721, 4, !dbg !841
  br i1 %1722, label %1723, label %1726, !dbg !841

1723:                                             ; preds = %1718
  %1724 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %236, i32 0, i32 0, !dbg !841
  %1725 = load ptr, ptr %1724, align 8, !dbg !841
  br label %1729, !dbg !841

1726:                                             ; preds = %1718
  %1727 = load i64, ptr %167, align 8, !dbg !841
  %1728 = inttoptr i64 %1727 to ptr, !dbg !841
  br label %1729, !dbg !841

1729:                                             ; preds = %1726, %1723
  %1730 = phi ptr [ %1725, %1723 ], [ %1728, %1726 ], !dbg !841
  store ptr %1730, ptr %239, align 8, !dbg !841
  call void @llvm.dbg.declare(metadata ptr %240, metadata !842, metadata !DIExpression()), !dbg !841
  %1731 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %236, i32 0, i32 1, !dbg !841
  %1732 = load i8, ptr %1731, align 8, !dbg !841
  store i8 %1732, ptr %240, align 1, !dbg !841
  %1733 = load ptr, ptr %239, align 8, !dbg !841
  store ptr %1733, ptr %56, align 8, !dbg !841
  %1734 = load i8, ptr %240, align 1, !dbg !841
  store i8 %1734, ptr %59, align 1, !dbg !841
  br label %1735, !dbg !841

1735:                                             ; preds = %1729
  br label %1919, !dbg !841

1736:                                             ; preds = %1712, %1708
  br label %1737, !dbg !837

1737:                                             ; preds = %1736
  call void @llvm.dbg.declare(metadata ptr %241, metadata !843, metadata !DIExpression()), !dbg !845
  %1738 = load i8, ptr %147, align 1, !dbg !845
  store i8 %1738, ptr %241, align 1, !dbg !845
  call void @llvm.dbg.declare(metadata ptr %242, metadata !846, metadata !DIExpression()), !dbg !845
  %1739 = load i8, ptr %241, align 1, !dbg !845
  store i8 %1739, ptr %6, align 1
  call void @llvm.dbg.declare(metadata ptr %6, metadata !656, metadata !DIExpression()), !dbg !847
  %1740 = load i8, ptr %6, align 1, !dbg !849
  %1741 = zext i8 %1740 to i32, !dbg !849
  %1742 = icmp ne i32 %1741, 0, !dbg !849
  br i1 %1742, label %1743, label %1746, !dbg !849

1743:                                             ; preds = %1737
  %1744 = load i8, ptr %6, align 1, !dbg !849
  %1745 = zext i8 %1744 to i32, !dbg !849
  br label %1747, !dbg !849

1746:                                             ; preds = %1737
  br label %1747, !dbg !849

1747:                                             ; preds = %1743, %1746
  %1748 = phi i32 [ %1745, %1743 ], [ 8, %1746 ], !dbg !849
  %1749 = trunc i32 %1748 to i8, !dbg !849
  store i8 %1749, ptr %242, align 1, !dbg !845
  call void @llvm.dbg.declare(metadata ptr %243, metadata !850, metadata !DIExpression()), !dbg !845
  store i8 0, ptr %243, align 1, !dbg !845
  call void @llvm.dbg.declare(metadata ptr %244, metadata !851, metadata !DIExpression()), !dbg !845
  %1750 = load i64, ptr %167, align 8, !dbg !845
  store i64 %1750, ptr %244, align 8, !dbg !845
  %1751 = load i8, ptr %242, align 1, !dbg !852
  %1752 = zext i8 %1751 to i32, !dbg !852
  %1753 = icmp eq i32 %1752, 1, !dbg !852
  br i1 %1753, label %1754, label %1755, !dbg !852

1754:                                             ; preds = %1747
  br label %1768, !dbg !852

1755:                                             ; preds = %1747
  %1756 = load i8, ptr %242, align 1, !dbg !852
  %1757 = zext i8 %1756 to i32, !dbg !852
  %1758 = icmp eq i32 %1757, 2, !dbg !852
  br i1 %1758, label %1759, label %1760, !dbg !852

1759:                                             ; preds = %1755
  br label %1766, !dbg !852

1760:                                             ; preds = %1755
  %1761 = load i8, ptr %242, align 1, !dbg !852
  %1762 = zext i8 %1761 to i32, !dbg !852
  %1763 = icmp eq i32 %1762, 4, !dbg !852
  %1764 = zext i1 %1763 to i64, !dbg !852
  %1765 = select i1 %1763, i32 2, i32 3, !dbg !852
  br label %1766, !dbg !852

1766:                                             ; preds = %1760, %1759
  %1767 = phi i32 [ 1, %1759 ], [ %1765, %1760 ], !dbg !852
  br label %1768, !dbg !852

1768:                                             ; preds = %1766, %1754
  %1769 = phi i32 [ 0, %1754 ], [ %1767, %1766 ], !dbg !852
  %1770 = icmp eq i32 %1769, 0, !dbg !852
  br i1 %1770, label %1771, label %1826, !dbg !845

1771:                                             ; preds = %1768
  %1772 = load i8, ptr %59, align 1, !dbg !854
  %1773 = zext i8 %1772 to i32, !dbg !854
  %1774 = icmp eq i32 %1773, 4, !dbg !854
  br i1 %1774, label %1775, label %1791, !dbg !858

1775:                                             ; preds = %1771
  call void @llvm.dbg.declare(metadata ptr %245, metadata !859, metadata !DIExpression()), !dbg !861
  %1776 = load ptr, ptr %56, align 8, !dbg !861
  %1777 = ptrtoint ptr %1776 to i64, !dbg !861
  %1778 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !861
  %1779 = ptrtoint ptr %1778 to i64, !dbg !861
  %1780 = add i64 %1779, 1, !dbg !861
  %1781 = inttoptr i64 %1780 to ptr, !dbg !861
  %1782 = ptrtoint ptr %1781 to i64, !dbg !861
  %1783 = sub i64 %1777, %1782, !dbg !861
  store i64 %1783, ptr %245, align 8, !dbg !861
  %1784 = load i64, ptr %245, align 8, !dbg !861
  %1785 = call i64 asm sideeffect "", "=r,0"(i64 %1784) #8, !dbg !861, !srcloc !862
  store i64 %1785, ptr %245, align 8, !dbg !861
  %1786 = load i64, ptr %245, align 8, !dbg !861
  %1787 = load i64, ptr %118, align 8, !dbg !861
  %1788 = add i64 %1786, %1787, !dbg !861
  store i64 %1788, ptr %246, align 8, !dbg !861
  %1789 = load i64, ptr %246, align 8, !dbg !861
  %1790 = inttoptr i64 %1789 to ptr, !dbg !854
  store ptr %1790, ptr %56, align 8, !dbg !854
  br label %1791, !dbg !854

1791:                                             ; preds = %1775, %1771
  br label %1792, !dbg !863

1792:                                             ; preds = %1791
  %1793 = load i8, ptr %59, align 1, !dbg !864
  %1794 = zext i8 %1793 to i32, !dbg !864
  %1795 = icmp eq i32 %1794, 0, !dbg !864
  br i1 %1795, label %1796, label %1809, !dbg !867

1796:                                             ; preds = %1792
  %1797 = load i8, ptr %243, align 1, !dbg !868
  %1798 = zext i8 %1797 to i32, !dbg !868
  %1799 = icmp eq i32 %1798, 8, !dbg !868
  br i1 %1799, label %1800, label %1804, !dbg !871

1800:                                             ; preds = %1796
  %1801 = load i64, ptr %244, align 8, !dbg !868
  %1802 = trunc i64 %1801 to i8, !dbg !868
  %1803 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 1, !dbg !868
  store i8 %1802, ptr %1803, align 1, !dbg !868
  br label %1808, !dbg !868

1804:                                             ; preds = %1796
  %1805 = load i64, ptr %244, align 8, !dbg !868
  %1806 = trunc i64 %1805 to i8, !dbg !868
  %1807 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 0, !dbg !868
  store i8 %1806, ptr %1807, align 8, !dbg !868
  br label %1808

1808:                                             ; preds = %1804, %1800
  br label %1824, !dbg !871

1809:                                             ; preds = %1792
  call void @llvm.dbg.declare(metadata ptr %247, metadata !872, metadata !DIExpression()), !dbg !880
  %1810 = load ptr, ptr %56, align 8, !dbg !880
  store ptr %1810, ptr %247, align 8, !dbg !880
  %1811 = load i8, ptr %243, align 1, !dbg !881
  %1812 = zext i8 %1811 to i32, !dbg !881
  %1813 = icmp eq i32 %1812, 8, !dbg !881
  br i1 %1813, label %1814, label %1818, !dbg !880

1814:                                             ; preds = %1809
  %1815 = load i64, ptr %244, align 8, !dbg !881
  %1816 = trunc i64 %1815 to i8, !dbg !881
  %1817 = getelementptr inbounds [8 x i8], ptr %247, i64 0, i64 1, !dbg !881
  store volatile i8 %1816, ptr %1817, align 1, !dbg !881
  br label %1822, !dbg !881

1818:                                             ; preds = %1809
  %1819 = load i64, ptr %244, align 8, !dbg !881
  %1820 = trunc i64 %1819 to i8, !dbg !881
  %1821 = getelementptr inbounds [8 x i8], ptr %247, i64 0, i64 0, !dbg !881
  store volatile i8 %1820, ptr %1821, align 8, !dbg !881
  br label %1822

1822:                                             ; preds = %1818, %1814
  %1823 = load volatile ptr, ptr %247, align 8, !dbg !880
  store ptr %1823, ptr %56, align 8, !dbg !880
  br label %1824

1824:                                             ; preds = %1822, %1808
  store i8 0, ptr %59, align 1, !dbg !867
  br label %1825, !dbg !867

1825:                                             ; preds = %1824
  br label %1917, !dbg !863

1826:                                             ; preds = %1768
  %1827 = load i8, ptr %242, align 1, !dbg !883
  %1828 = zext i8 %1827 to i32, !dbg !883
  %1829 = icmp eq i32 %1828, 1, !dbg !883
  br i1 %1829, label %1830, label %1831, !dbg !883

1830:                                             ; preds = %1826
  br label %1844, !dbg !883

1831:                                             ; preds = %1826
  %1832 = load i8, ptr %242, align 1, !dbg !883
  %1833 = zext i8 %1832 to i32, !dbg !883
  %1834 = icmp eq i32 %1833, 2, !dbg !883
  br i1 %1834, label %1835, label %1836, !dbg !883

1835:                                             ; preds = %1831
  br label %1842, !dbg !883

1836:                                             ; preds = %1831
  %1837 = load i8, ptr %242, align 1, !dbg !883
  %1838 = zext i8 %1837 to i32, !dbg !883
  %1839 = icmp eq i32 %1838, 4, !dbg !883
  %1840 = zext i1 %1839 to i64, !dbg !883
  %1841 = select i1 %1839, i32 2, i32 3, !dbg !883
  br label %1842, !dbg !883

1842:                                             ; preds = %1836, %1835
  %1843 = phi i32 [ 1, %1835 ], [ %1841, %1836 ], !dbg !883
  br label %1844, !dbg !883

1844:                                             ; preds = %1842, %1830
  %1845 = phi i32 [ 0, %1830 ], [ %1843, %1842 ], !dbg !883
  %1846 = icmp eq i32 %1845, 1, !dbg !883
  br i1 %1846, label %1847, label %1882, !dbg !852

1847:                                             ; preds = %1844
  %1848 = load i8, ptr %59, align 1, !dbg !885
  %1849 = zext i8 %1848 to i32, !dbg !885
  %1850 = icmp eq i32 %1849, 4, !dbg !885
  br i1 %1850, label %1851, label %1867, !dbg !889

1851:                                             ; preds = %1847
  call void @llvm.dbg.declare(metadata ptr %248, metadata !890, metadata !DIExpression()), !dbg !892
  %1852 = load ptr, ptr %56, align 8, !dbg !892
  %1853 = ptrtoint ptr %1852 to i64, !dbg !892
  %1854 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !892
  %1855 = ptrtoint ptr %1854 to i64, !dbg !892
  %1856 = add i64 %1855, 1, !dbg !892
  %1857 = inttoptr i64 %1856 to ptr, !dbg !892
  %1858 = ptrtoint ptr %1857 to i64, !dbg !892
  %1859 = sub i64 %1853, %1858, !dbg !892
  store i64 %1859, ptr %248, align 8, !dbg !892
  %1860 = load i64, ptr %248, align 8, !dbg !892
  %1861 = call i64 asm sideeffect "", "=r,0"(i64 %1860) #8, !dbg !892, !srcloc !893
  store i64 %1861, ptr %248, align 8, !dbg !892
  %1862 = load i64, ptr %248, align 8, !dbg !892
  %1863 = load i64, ptr %118, align 8, !dbg !892
  %1864 = add i64 %1862, %1863, !dbg !892
  store i64 %1864, ptr %249, align 8, !dbg !892
  %1865 = load i64, ptr %249, align 8, !dbg !892
  %1866 = inttoptr i64 %1865 to ptr, !dbg !885
  store ptr %1866, ptr %56, align 8, !dbg !885
  br label %1867, !dbg !885

1867:                                             ; preds = %1851, %1847
  br label %1868, !dbg !894

1868:                                             ; preds = %1867
  %1869 = load i8, ptr %59, align 1, !dbg !895
  %1870 = zext i8 %1869 to i32, !dbg !895
  %1871 = icmp eq i32 %1870, 0, !dbg !895
  br i1 %1871, label %1872, label %1875, !dbg !898

1872:                                             ; preds = %1868
  %1873 = load i64, ptr %244, align 8, !dbg !899
  %1874 = trunc i64 %1873 to i16, !dbg !899
  store i16 %1874, ptr %56, align 8, !dbg !899
  br label %1880, !dbg !899

1875:                                             ; preds = %1868
  call void @llvm.dbg.declare(metadata ptr %250, metadata !901, metadata !DIExpression()), !dbg !909
  %1876 = load ptr, ptr %56, align 8, !dbg !909
  store ptr %1876, ptr %250, align 8, !dbg !909
  %1877 = load i64, ptr %244, align 8, !dbg !909
  %1878 = trunc i64 %1877 to i16, !dbg !909
  store volatile i16 %1878, ptr %250, align 8, !dbg !909
  %1879 = load volatile ptr, ptr %250, align 8, !dbg !909
  store ptr %1879, ptr %56, align 8, !dbg !909
  br label %1880

1880:                                             ; preds = %1875, %1872
  store i8 0, ptr %59, align 1, !dbg !898
  br label %1881, !dbg !898

1881:                                             ; preds = %1880
  br label %1916, !dbg !894

1882:                                             ; preds = %1844
  %1883 = load i8, ptr %242, align 1, !dbg !910
  %1884 = zext i8 %1883 to i32, !dbg !910
  %1885 = icmp eq i32 %1884, 1, !dbg !910
  br i1 %1885, label %1886, label %1887, !dbg !910

1886:                                             ; preds = %1882
  br label %1900, !dbg !910

1887:                                             ; preds = %1882
  %1888 = load i8, ptr %242, align 1, !dbg !910
  %1889 = zext i8 %1888 to i32, !dbg !910
  %1890 = icmp eq i32 %1889, 2, !dbg !910
  br i1 %1890, label %1891, label %1892, !dbg !910

1891:                                             ; preds = %1887
  br label %1898, !dbg !910

1892:                                             ; preds = %1887
  %1893 = load i8, ptr %242, align 1, !dbg !910
  %1894 = zext i8 %1893 to i32, !dbg !910
  %1895 = icmp eq i32 %1894, 4, !dbg !910
  %1896 = zext i1 %1895 to i64, !dbg !910
  %1897 = select i1 %1895, i32 2, i32 3, !dbg !910
  br label %1898, !dbg !910

1898:                                             ; preds = %1892, %1891
  %1899 = phi i32 [ 1, %1891 ], [ %1897, %1892 ], !dbg !910
  br label %1900, !dbg !910

1900:                                             ; preds = %1898, %1886
  %1901 = phi i32 [ 0, %1886 ], [ %1899, %1898 ], !dbg !910
  %1902 = icmp eq i32 %1901, 2, !dbg !910
  br i1 %1902, label %1903, label %1910, !dbg !883

1903:                                             ; preds = %1900
  br label %1904, !dbg !912

1904:                                             ; preds = %1903
  %1905 = load i64, ptr %244, align 8, !dbg !914
  %1906 = trunc i64 %1905 to i32, !dbg !914
  %1907 = zext i32 %1906 to i64, !dbg !914
  %1908 = inttoptr i64 %1907 to ptr, !dbg !914
  store ptr %1908, ptr %56, align 8, !dbg !914
  store i8 0, ptr %59, align 1, !dbg !914
  br label %1909, !dbg !914

1909:                                             ; preds = %1904
  br label %1915, !dbg !912

1910:                                             ; preds = %1900
  br label %1911, !dbg !916

1911:                                             ; preds = %1910
  %1912 = load i64, ptr %244, align 8, !dbg !918
  %1913 = inttoptr i64 %1912 to ptr, !dbg !918
  store ptr %1913, ptr %56, align 8, !dbg !918
  store i8 0, ptr %59, align 1, !dbg !918
  br label %1914, !dbg !918

1914:                                             ; preds = %1911
  br label %1915

1915:                                             ; preds = %1914, %1909
  br label %1916

1916:                                             ; preds = %1915, %1881
  br label %1917

1917:                                             ; preds = %1916, %1825
  br label %1918, !dbg !845

1918:                                             ; preds = %1917
  br label %1919

1919:                                             ; preds = %1918, %1735
  br label %2631, !dbg !812

1920:                                             ; preds = %1369
  %1921 = load i8, ptr %155, align 1, !dbg !920
  %1922 = zext i8 %1921 to i32, !dbg !920
  %1923 = icmp ne i32 %1922, 1, !dbg !920
  br i1 %1923, label %1924, label %2194, !dbg !812

1924:                                             ; preds = %1920
  %1925 = load ptr, ptr %166, align 8, !dbg !922
  store i64 -1024, ptr %44, align 8
  call void @llvm.dbg.declare(metadata ptr %44, metadata !348, metadata !DIExpression()), !dbg !925
  %1926 = load i64, ptr %44, align 8, !dbg !927
  %1927 = load i8, ptr %150, align 1, !dbg !922
  store ptr %1925, ptr %26, align 8
  call void @llvm.dbg.declare(metadata ptr %26, metadata !492, metadata !DIExpression()), !dbg !928
  store i64 %1926, ptr %27, align 8
  call void @llvm.dbg.declare(metadata ptr %27, metadata !501, metadata !DIExpression()), !dbg !930
  store i8 %1927, ptr %28, align 1
  call void @llvm.dbg.declare(metadata ptr %28, metadata !503, metadata !DIExpression()), !dbg !931
  %1928 = load i64, ptr %27, align 8, !dbg !932
  %1929 = call i1 @llvm.is.constant.i64(i64 %1928), !dbg !933
  br i1 %1929, label %1930, label %1936, !dbg !934

1930:                                             ; preds = %1924
  %1931 = load i64, ptr %27, align 8, !dbg !935
  %1932 = icmp slt i64 %1931, -32768, !dbg !936
  br i1 %1932, label %1936, label %1933, !dbg !937

1933:                                             ; preds = %1930
  %1934 = load i64, ptr %27, align 8, !dbg !938
  %1935 = icmp sgt i64 %1934, 32767, !dbg !939
  br i1 %1935, label %1936, label %1937, !dbg !940

1936:                                             ; preds = %1933, %1930, %1924
  call void @kprog_x86_fixed_displacement_required() #8, !dbg !941, !srcloc !516
  br label %1937, !dbg !941

1937:                                             ; preds = %1936, %1933
  call void @llvm.dbg.declare(metadata ptr %29, metadata !517, metadata !DIExpression()), !dbg !942
  %1938 = load i8, ptr %28, align 1, !dbg !943
  %1939 = zext i8 %1938 to i32, !dbg !943
  %1940 = icmp ne i32 %1939, 0, !dbg !943
  br i1 %1940, label %1941, label %1944, !dbg !943

1941:                                             ; preds = %1937
  %1942 = load i8, ptr %28, align 1, !dbg !944
  %1943 = zext i8 %1942 to i32, !dbg !944
  br label %1945, !dbg !943

1944:                                             ; preds = %1937
  br label %1945, !dbg !943

1945:                                             ; preds = %1944, %1941
  %1946 = phi i32 [ %1943, %1941 ], [ 8, %1944 ], !dbg !943
  switch i32 %1946, label %2009 [
    i32 1, label %1947
    i32 2, label %1963
    i32 4, label %1979
    i32 8, label %1995
  ], !dbg !945

1947:                                             ; preds = %1945
  %1948 = load i64, ptr %27, align 8, !dbg !946
  %1949 = icmp slt i64 %1948, 0, !dbg !947
  br i1 %1949, label %1950, label %1955, !dbg !948

1950:                                             ; preds = %1947
  %1951 = load ptr, ptr %26, align 8, !dbg !949
  %1952 = load i64, ptr %27, align 8, !dbg !950
  %1953 = sub nsw i64 0, %1952, !dbg !951
  %1954 = call i64 asm sideeffect "$0 = *(u8 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %1951, i64 %1953) #8, !dbg !952, !srcloc !531
  store i64 %1954, ptr %29, align 8, !dbg !952
  br label %1959, !dbg !952

1955:                                             ; preds = %1947
  %1956 = load ptr, ptr %26, align 8, !dbg !953
  %1957 = load i64, ptr %27, align 8, !dbg !954
  %1958 = call i64 asm sideeffect "$0 = *(u8 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %1956, i64 %1957) #8, !dbg !955, !srcloc !535
  store i64 %1958, ptr %29, align 8, !dbg !955
  br label %1959

1959:                                             ; preds = %1955, %1950
  %1960 = load i64, ptr %29, align 8, !dbg !956
  %1961 = trunc i64 %1960 to i8, !dbg !957
  %1962 = zext i8 %1961 to i64, !dbg !957
  store i64 %1962, ptr %25, align 8, !dbg !958
  br label %2010, !dbg !958

1963:                                             ; preds = %1945
  %1964 = load i64, ptr %27, align 8, !dbg !959
  %1965 = icmp slt i64 %1964, 0, !dbg !960
  br i1 %1965, label %1966, label %1971, !dbg !961

1966:                                             ; preds = %1963
  %1967 = load ptr, ptr %26, align 8, !dbg !962
  %1968 = load i64, ptr %27, align 8, !dbg !963
  %1969 = sub nsw i64 0, %1968, !dbg !964
  %1970 = call i64 asm sideeffect "$0 = *(u16 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %1967, i64 %1969) #8, !dbg !965, !srcloc !547
  store i64 %1970, ptr %29, align 8, !dbg !965
  br label %1975, !dbg !965

1971:                                             ; preds = %1963
  %1972 = load ptr, ptr %26, align 8, !dbg !966
  %1973 = load i64, ptr %27, align 8, !dbg !967
  %1974 = call i64 asm sideeffect "$0 = *(u16 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %1972, i64 %1973) #8, !dbg !968, !srcloc !551
  store i64 %1974, ptr %29, align 8, !dbg !968
  br label %1975

1975:                                             ; preds = %1971, %1966
  %1976 = load i64, ptr %29, align 8, !dbg !969
  %1977 = trunc i64 %1976 to i16, !dbg !970
  %1978 = zext i16 %1977 to i64, !dbg !970
  store i64 %1978, ptr %25, align 8, !dbg !971
  br label %2010, !dbg !971

1979:                                             ; preds = %1945
  %1980 = load i64, ptr %27, align 8, !dbg !972
  %1981 = icmp slt i64 %1980, 0, !dbg !973
  br i1 %1981, label %1982, label %1987, !dbg !974

1982:                                             ; preds = %1979
  %1983 = load ptr, ptr %26, align 8, !dbg !975
  %1984 = load i64, ptr %27, align 8, !dbg !976
  %1985 = sub nsw i64 0, %1984, !dbg !977
  %1986 = call i64 asm sideeffect "$0 = *(u32 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %1983, i64 %1985) #8, !dbg !978, !srcloc !563
  store i64 %1986, ptr %29, align 8, !dbg !978
  br label %1991, !dbg !978

1987:                                             ; preds = %1979
  %1988 = load ptr, ptr %26, align 8, !dbg !979
  %1989 = load i64, ptr %27, align 8, !dbg !980
  %1990 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %1988, i64 %1989) #8, !dbg !981, !srcloc !567
  store i64 %1990, ptr %29, align 8, !dbg !981
  br label %1991

1991:                                             ; preds = %1987, %1982
  %1992 = load i64, ptr %29, align 8, !dbg !982
  %1993 = trunc i64 %1992 to i32, !dbg !983
  %1994 = zext i32 %1993 to i64, !dbg !983
  store i64 %1994, ptr %25, align 8, !dbg !984
  br label %2010, !dbg !984

1995:                                             ; preds = %1945
  %1996 = load i64, ptr %27, align 8, !dbg !985
  %1997 = icmp slt i64 %1996, 0, !dbg !986
  br i1 %1997, label %1998, label %2003, !dbg !987

1998:                                             ; preds = %1995
  %1999 = load ptr, ptr %26, align 8, !dbg !988
  %2000 = load i64, ptr %27, align 8, !dbg !989
  %2001 = sub nsw i64 0, %2000, !dbg !990
  %2002 = call i64 asm sideeffect "$0 = *(u64 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %1999, i64 %2001) #8, !dbg !991, !srcloc !579
  store i64 %2002, ptr %29, align 8, !dbg !991
  br label %2007, !dbg !991

2003:                                             ; preds = %1995
  %2004 = load ptr, ptr %26, align 8, !dbg !992
  %2005 = load i64, ptr %27, align 8, !dbg !993
  %2006 = call i64 asm sideeffect "$0 = *(u64 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %2004, i64 %2005) #8, !dbg !994, !srcloc !583
  store i64 %2006, ptr %29, align 8, !dbg !994
  br label %2007

2007:                                             ; preds = %2003, %1998
  %2008 = load i64, ptr %29, align 8, !dbg !995
  store i64 %2008, ptr %25, align 8, !dbg !996
  br label %2010, !dbg !996

2009:                                             ; preds = %1945
  call void @llvm.trap(), !dbg !997
  br label %2010, !dbg !998

2010:                                             ; preds = %1959, %1975, %1991, %2007, %2009
  %2011 = load i64, ptr %25, align 8, !dbg !999
  store i64 %2011, ptr %167, align 8, !dbg !922
  br label %2012, !dbg !1000

2012:                                             ; preds = %2010
  call void @llvm.dbg.declare(metadata ptr %251, metadata !1001, metadata !DIExpression()), !dbg !1003
  %2013 = load i8, ptr %147, align 1, !dbg !1003
  store i8 %2013, ptr %251, align 1, !dbg !1003
  call void @llvm.dbg.declare(metadata ptr %252, metadata !1004, metadata !DIExpression()), !dbg !1003
  %2014 = load i8, ptr %251, align 1, !dbg !1003
  store i8 %2014, ptr %7, align 1
  call void @llvm.dbg.declare(metadata ptr %7, metadata !656, metadata !DIExpression()), !dbg !1005
  %2015 = load i8, ptr %7, align 1, !dbg !1007
  %2016 = zext i8 %2015 to i32, !dbg !1007
  %2017 = icmp ne i32 %2016, 0, !dbg !1007
  br i1 %2017, label %2018, label %2021, !dbg !1007

2018:                                             ; preds = %2012
  %2019 = load i8, ptr %7, align 1, !dbg !1007
  %2020 = zext i8 %2019 to i32, !dbg !1007
  br label %2022, !dbg !1007

2021:                                             ; preds = %2012
  br label %2022, !dbg !1007

2022:                                             ; preds = %2018, %2021
  %2023 = phi i32 [ %2020, %2018 ], [ 8, %2021 ], !dbg !1007
  %2024 = trunc i32 %2023 to i8, !dbg !1007
  store i8 %2024, ptr %252, align 1, !dbg !1003
  call void @llvm.dbg.declare(metadata ptr %253, metadata !1008, metadata !DIExpression()), !dbg !1003
  store i8 0, ptr %253, align 1, !dbg !1003
  call void @llvm.dbg.declare(metadata ptr %254, metadata !1009, metadata !DIExpression()), !dbg !1003
  %2025 = load i64, ptr %167, align 8, !dbg !1003
  store i64 %2025, ptr %254, align 8, !dbg !1003
  %2026 = load i8, ptr %252, align 1, !dbg !1010
  %2027 = zext i8 %2026 to i32, !dbg !1010
  %2028 = icmp eq i32 %2027, 1, !dbg !1010
  br i1 %2028, label %2029, label %2030, !dbg !1010

2029:                                             ; preds = %2022
  br label %2043, !dbg !1010

2030:                                             ; preds = %2022
  %2031 = load i8, ptr %252, align 1, !dbg !1010
  %2032 = zext i8 %2031 to i32, !dbg !1010
  %2033 = icmp eq i32 %2032, 2, !dbg !1010
  br i1 %2033, label %2034, label %2035, !dbg !1010

2034:                                             ; preds = %2030
  br label %2041, !dbg !1010

2035:                                             ; preds = %2030
  %2036 = load i8, ptr %252, align 1, !dbg !1010
  %2037 = zext i8 %2036 to i32, !dbg !1010
  %2038 = icmp eq i32 %2037, 4, !dbg !1010
  %2039 = zext i1 %2038 to i64, !dbg !1010
  %2040 = select i1 %2038, i32 2, i32 3, !dbg !1010
  br label %2041, !dbg !1010

2041:                                             ; preds = %2035, %2034
  %2042 = phi i32 [ 1, %2034 ], [ %2040, %2035 ], !dbg !1010
  br label %2043, !dbg !1010

2043:                                             ; preds = %2041, %2029
  %2044 = phi i32 [ 0, %2029 ], [ %2042, %2041 ], !dbg !1010
  %2045 = icmp eq i32 %2044, 0, !dbg !1010
  br i1 %2045, label %2046, label %2101, !dbg !1003

2046:                                             ; preds = %2043
  %2047 = load i8, ptr %59, align 1, !dbg !1012
  %2048 = zext i8 %2047 to i32, !dbg !1012
  %2049 = icmp eq i32 %2048, 4, !dbg !1012
  br i1 %2049, label %2050, label %2066, !dbg !1016

2050:                                             ; preds = %2046
  call void @llvm.dbg.declare(metadata ptr %255, metadata !1017, metadata !DIExpression()), !dbg !1019
  %2051 = load ptr, ptr %56, align 8, !dbg !1019
  %2052 = ptrtoint ptr %2051 to i64, !dbg !1019
  %2053 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1019
  %2054 = ptrtoint ptr %2053 to i64, !dbg !1019
  %2055 = add i64 %2054, 1, !dbg !1019
  %2056 = inttoptr i64 %2055 to ptr, !dbg !1019
  %2057 = ptrtoint ptr %2056 to i64, !dbg !1019
  %2058 = sub i64 %2052, %2057, !dbg !1019
  store i64 %2058, ptr %255, align 8, !dbg !1019
  %2059 = load i64, ptr %255, align 8, !dbg !1019
  %2060 = call i64 asm sideeffect "", "=r,0"(i64 %2059) #8, !dbg !1019, !srcloc !1020
  store i64 %2060, ptr %255, align 8, !dbg !1019
  %2061 = load i64, ptr %255, align 8, !dbg !1019
  %2062 = load i64, ptr %118, align 8, !dbg !1019
  %2063 = add i64 %2061, %2062, !dbg !1019
  store i64 %2063, ptr %256, align 8, !dbg !1019
  %2064 = load i64, ptr %256, align 8, !dbg !1019
  %2065 = inttoptr i64 %2064 to ptr, !dbg !1012
  store ptr %2065, ptr %56, align 8, !dbg !1012
  br label %2066, !dbg !1012

2066:                                             ; preds = %2050, %2046
  br label %2067, !dbg !1021

2067:                                             ; preds = %2066
  %2068 = load i8, ptr %59, align 1, !dbg !1022
  %2069 = zext i8 %2068 to i32, !dbg !1022
  %2070 = icmp eq i32 %2069, 0, !dbg !1022
  br i1 %2070, label %2071, label %2084, !dbg !1025

2071:                                             ; preds = %2067
  %2072 = load i8, ptr %253, align 1, !dbg !1026
  %2073 = zext i8 %2072 to i32, !dbg !1026
  %2074 = icmp eq i32 %2073, 8, !dbg !1026
  br i1 %2074, label %2075, label %2079, !dbg !1029

2075:                                             ; preds = %2071
  %2076 = load i64, ptr %254, align 8, !dbg !1026
  %2077 = trunc i64 %2076 to i8, !dbg !1026
  %2078 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 1, !dbg !1026
  store i8 %2077, ptr %2078, align 1, !dbg !1026
  br label %2083, !dbg !1026

2079:                                             ; preds = %2071
  %2080 = load i64, ptr %254, align 8, !dbg !1026
  %2081 = trunc i64 %2080 to i8, !dbg !1026
  %2082 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 0, !dbg !1026
  store i8 %2081, ptr %2082, align 8, !dbg !1026
  br label %2083

2083:                                             ; preds = %2079, %2075
  br label %2099, !dbg !1029

2084:                                             ; preds = %2067
  call void @llvm.dbg.declare(metadata ptr %257, metadata !1030, metadata !DIExpression()), !dbg !1038
  %2085 = load ptr, ptr %56, align 8, !dbg !1038
  store ptr %2085, ptr %257, align 8, !dbg !1038
  %2086 = load i8, ptr %253, align 1, !dbg !1039
  %2087 = zext i8 %2086 to i32, !dbg !1039
  %2088 = icmp eq i32 %2087, 8, !dbg !1039
  br i1 %2088, label %2089, label %2093, !dbg !1038

2089:                                             ; preds = %2084
  %2090 = load i64, ptr %254, align 8, !dbg !1039
  %2091 = trunc i64 %2090 to i8, !dbg !1039
  %2092 = getelementptr inbounds [8 x i8], ptr %257, i64 0, i64 1, !dbg !1039
  store volatile i8 %2091, ptr %2092, align 1, !dbg !1039
  br label %2097, !dbg !1039

2093:                                             ; preds = %2084
  %2094 = load i64, ptr %254, align 8, !dbg !1039
  %2095 = trunc i64 %2094 to i8, !dbg !1039
  %2096 = getelementptr inbounds [8 x i8], ptr %257, i64 0, i64 0, !dbg !1039
  store volatile i8 %2095, ptr %2096, align 8, !dbg !1039
  br label %2097

2097:                                             ; preds = %2093, %2089
  %2098 = load volatile ptr, ptr %257, align 8, !dbg !1038
  store ptr %2098, ptr %56, align 8, !dbg !1038
  br label %2099

2099:                                             ; preds = %2097, %2083
  store i8 0, ptr %59, align 1, !dbg !1025
  br label %2100, !dbg !1025

2100:                                             ; preds = %2099
  br label %2192, !dbg !1021

2101:                                             ; preds = %2043
  %2102 = load i8, ptr %252, align 1, !dbg !1041
  %2103 = zext i8 %2102 to i32, !dbg !1041
  %2104 = icmp eq i32 %2103, 1, !dbg !1041
  br i1 %2104, label %2105, label %2106, !dbg !1041

2105:                                             ; preds = %2101
  br label %2119, !dbg !1041

2106:                                             ; preds = %2101
  %2107 = load i8, ptr %252, align 1, !dbg !1041
  %2108 = zext i8 %2107 to i32, !dbg !1041
  %2109 = icmp eq i32 %2108, 2, !dbg !1041
  br i1 %2109, label %2110, label %2111, !dbg !1041

2110:                                             ; preds = %2106
  br label %2117, !dbg !1041

2111:                                             ; preds = %2106
  %2112 = load i8, ptr %252, align 1, !dbg !1041
  %2113 = zext i8 %2112 to i32, !dbg !1041
  %2114 = icmp eq i32 %2113, 4, !dbg !1041
  %2115 = zext i1 %2114 to i64, !dbg !1041
  %2116 = select i1 %2114, i32 2, i32 3, !dbg !1041
  br label %2117, !dbg !1041

2117:                                             ; preds = %2111, %2110
  %2118 = phi i32 [ 1, %2110 ], [ %2116, %2111 ], !dbg !1041
  br label %2119, !dbg !1041

2119:                                             ; preds = %2117, %2105
  %2120 = phi i32 [ 0, %2105 ], [ %2118, %2117 ], !dbg !1041
  %2121 = icmp eq i32 %2120, 1, !dbg !1041
  br i1 %2121, label %2122, label %2157, !dbg !1010

2122:                                             ; preds = %2119
  %2123 = load i8, ptr %59, align 1, !dbg !1043
  %2124 = zext i8 %2123 to i32, !dbg !1043
  %2125 = icmp eq i32 %2124, 4, !dbg !1043
  br i1 %2125, label %2126, label %2142, !dbg !1047

2126:                                             ; preds = %2122
  call void @llvm.dbg.declare(metadata ptr %258, metadata !1048, metadata !DIExpression()), !dbg !1050
  %2127 = load ptr, ptr %56, align 8, !dbg !1050
  %2128 = ptrtoint ptr %2127 to i64, !dbg !1050
  %2129 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1050
  %2130 = ptrtoint ptr %2129 to i64, !dbg !1050
  %2131 = add i64 %2130, 1, !dbg !1050
  %2132 = inttoptr i64 %2131 to ptr, !dbg !1050
  %2133 = ptrtoint ptr %2132 to i64, !dbg !1050
  %2134 = sub i64 %2128, %2133, !dbg !1050
  store i64 %2134, ptr %258, align 8, !dbg !1050
  %2135 = load i64, ptr %258, align 8, !dbg !1050
  %2136 = call i64 asm sideeffect "", "=r,0"(i64 %2135) #8, !dbg !1050, !srcloc !1051
  store i64 %2136, ptr %258, align 8, !dbg !1050
  %2137 = load i64, ptr %258, align 8, !dbg !1050
  %2138 = load i64, ptr %118, align 8, !dbg !1050
  %2139 = add i64 %2137, %2138, !dbg !1050
  store i64 %2139, ptr %259, align 8, !dbg !1050
  %2140 = load i64, ptr %259, align 8, !dbg !1050
  %2141 = inttoptr i64 %2140 to ptr, !dbg !1043
  store ptr %2141, ptr %56, align 8, !dbg !1043
  br label %2142, !dbg !1043

2142:                                             ; preds = %2126, %2122
  br label %2143, !dbg !1052

2143:                                             ; preds = %2142
  %2144 = load i8, ptr %59, align 1, !dbg !1053
  %2145 = zext i8 %2144 to i32, !dbg !1053
  %2146 = icmp eq i32 %2145, 0, !dbg !1053
  br i1 %2146, label %2147, label %2150, !dbg !1056

2147:                                             ; preds = %2143
  %2148 = load i64, ptr %254, align 8, !dbg !1057
  %2149 = trunc i64 %2148 to i16, !dbg !1057
  store i16 %2149, ptr %56, align 8, !dbg !1057
  br label %2155, !dbg !1057

2150:                                             ; preds = %2143
  call void @llvm.dbg.declare(metadata ptr %260, metadata !1059, metadata !DIExpression()), !dbg !1067
  %2151 = load ptr, ptr %56, align 8, !dbg !1067
  store ptr %2151, ptr %260, align 8, !dbg !1067
  %2152 = load i64, ptr %254, align 8, !dbg !1067
  %2153 = trunc i64 %2152 to i16, !dbg !1067
  store volatile i16 %2153, ptr %260, align 8, !dbg !1067
  %2154 = load volatile ptr, ptr %260, align 8, !dbg !1067
  store ptr %2154, ptr %56, align 8, !dbg !1067
  br label %2155

2155:                                             ; preds = %2150, %2147
  store i8 0, ptr %59, align 1, !dbg !1056
  br label %2156, !dbg !1056

2156:                                             ; preds = %2155
  br label %2191, !dbg !1052

2157:                                             ; preds = %2119
  %2158 = load i8, ptr %252, align 1, !dbg !1068
  %2159 = zext i8 %2158 to i32, !dbg !1068
  %2160 = icmp eq i32 %2159, 1, !dbg !1068
  br i1 %2160, label %2161, label %2162, !dbg !1068

2161:                                             ; preds = %2157
  br label %2175, !dbg !1068

2162:                                             ; preds = %2157
  %2163 = load i8, ptr %252, align 1, !dbg !1068
  %2164 = zext i8 %2163 to i32, !dbg !1068
  %2165 = icmp eq i32 %2164, 2, !dbg !1068
  br i1 %2165, label %2166, label %2167, !dbg !1068

2166:                                             ; preds = %2162
  br label %2173, !dbg !1068

2167:                                             ; preds = %2162
  %2168 = load i8, ptr %252, align 1, !dbg !1068
  %2169 = zext i8 %2168 to i32, !dbg !1068
  %2170 = icmp eq i32 %2169, 4, !dbg !1068
  %2171 = zext i1 %2170 to i64, !dbg !1068
  %2172 = select i1 %2170, i32 2, i32 3, !dbg !1068
  br label %2173, !dbg !1068

2173:                                             ; preds = %2167, %2166
  %2174 = phi i32 [ 1, %2166 ], [ %2172, %2167 ], !dbg !1068
  br label %2175, !dbg !1068

2175:                                             ; preds = %2173, %2161
  %2176 = phi i32 [ 0, %2161 ], [ %2174, %2173 ], !dbg !1068
  %2177 = icmp eq i32 %2176, 2, !dbg !1068
  br i1 %2177, label %2178, label %2185, !dbg !1041

2178:                                             ; preds = %2175
  br label %2179, !dbg !1070

2179:                                             ; preds = %2178
  %2180 = load i64, ptr %254, align 8, !dbg !1072
  %2181 = trunc i64 %2180 to i32, !dbg !1072
  %2182 = zext i32 %2181 to i64, !dbg !1072
  %2183 = inttoptr i64 %2182 to ptr, !dbg !1072
  store ptr %2183, ptr %56, align 8, !dbg !1072
  store i8 0, ptr %59, align 1, !dbg !1072
  br label %2184, !dbg !1072

2184:                                             ; preds = %2179
  br label %2190, !dbg !1070

2185:                                             ; preds = %2175
  br label %2186, !dbg !1074

2186:                                             ; preds = %2185
  %2187 = load i64, ptr %254, align 8, !dbg !1076
  %2188 = inttoptr i64 %2187 to ptr, !dbg !1076
  store ptr %2188, ptr %56, align 8, !dbg !1076
  store i8 0, ptr %59, align 1, !dbg !1076
  br label %2189, !dbg !1076

2189:                                             ; preds = %2186
  br label %2190

2190:                                             ; preds = %2189, %2184
  br label %2191

2191:                                             ; preds = %2190, %2156
  br label %2192

2192:                                             ; preds = %2191, %2100
  br label %2193, !dbg !1003

2193:                                             ; preds = %2192
  br label %2631, !dbg !1000

2194:                                             ; preds = %1920
  call void @llvm.dbg.declare(metadata ptr %261, metadata !1078, metadata !DIExpression()), !dbg !812
  call void @llvm.dbg.declare(metadata ptr %262, metadata !1079, metadata !DIExpression()), !dbg !1081
  %2195 = load i8, ptr %50, align 1, !dbg !1081
  store i8 %2195, ptr %262, align 1, !dbg !1081
  call void @llvm.dbg.declare(metadata ptr %263, metadata !1082, metadata !DIExpression()), !dbg !1081
  %2196 = load i64, ptr %158, align 8, !dbg !1081
  store i64 %2196, ptr %263, align 8, !dbg !1081
  call void @llvm.dbg.declare(metadata ptr %264, metadata !1083, metadata !DIExpression()), !dbg !1081
  store i8 0, ptr %264, align 1, !dbg !1081
  %2197 = load i8, ptr %262, align 1, !dbg !1084
  %2198 = zext i8 %2197 to i32, !dbg !1084
  %2199 = icmp eq i32 %2198, 0, !dbg !1084
  br i1 %2199, label %2200, label %2203, !dbg !1084

2200:                                             ; preds = %2194
  %2201 = load i64, ptr %263, align 8, !dbg !1084
  %2202 = icmp eq i64 %2201, 0, !dbg !1084
  br i1 %2202, label %2210, label %2203, !dbg !1084

2203:                                             ; preds = %2200, %2194
  %2204 = load i8, ptr %262, align 1, !dbg !1084
  %2205 = zext i8 %2204 to i32, !dbg !1084
  %2206 = icmp eq i32 %2205, 1, !dbg !1084
  br i1 %2206, label %2207, label %2211, !dbg !1084

2207:                                             ; preds = %2203
  %2208 = load i64, ptr %263, align 8, !dbg !1084
  %2209 = icmp eq i64 %2208, 208, !dbg !1084
  br i1 %2209, label %2210, label %2211, !dbg !1081

2210:                                             ; preds = %2207, %2200
  store i8 2, ptr %264, align 1, !dbg !1084
  br label %2227, !dbg !1084

2211:                                             ; preds = %2207, %2203
  %2212 = load i8, ptr %262, align 1, !dbg !1086
  %2213 = zext i8 %2212 to i32, !dbg !1086
  %2214 = icmp eq i32 %2213, 0, !dbg !1086
  br i1 %2214, label %2215, label %2218, !dbg !1086

2215:                                             ; preds = %2211
  %2216 = load i64, ptr %263, align 8, !dbg !1086
  %2217 = icmp eq i64 %2216, 8, !dbg !1086
  br i1 %2217, label %2225, label %2218, !dbg !1086

2218:                                             ; preds = %2215, %2211
  %2219 = load i8, ptr %262, align 1, !dbg !1086
  %2220 = zext i8 %2219 to i32, !dbg !1086
  %2221 = icmp eq i32 %2220, 1, !dbg !1086
  br i1 %2221, label %2222, label %2226, !dbg !1086

2222:                                             ; preds = %2218
  %2223 = load i64, ptr %263, align 8, !dbg !1086
  %2224 = icmp eq i64 %2223, 80, !dbg !1086
  br i1 %2224, label %2225, label %2226, !dbg !1084

2225:                                             ; preds = %2222, %2215
  store i8 3, ptr %264, align 1, !dbg !1086
  br label %2226, !dbg !1086

2226:                                             ; preds = %2225, %2222, %2218
  br label %2227

2227:                                             ; preds = %2226, %2210
  %2228 = load i8, ptr %264, align 1, !dbg !1081
  store i8 %2228, ptr %265, align 1, !dbg !1084
  %2229 = load i8, ptr %265, align 1, !dbg !1081
  store i8 %2229, ptr %261, align 1, !dbg !812
  br label %2230, !dbg !1088

2230:                                             ; preds = %2227
  call void @llvm.dbg.declare(metadata ptr %266, metadata !1090, metadata !DIExpression()), !dbg !1092
  %2231 = load ptr, ptr %168, align 8, !dbg !1092
  %2232 = load volatile ptr, ptr %2231, align 8, !dbg !1092
  store ptr %2232, ptr %266, align 8, !dbg !1092
  call void @llvm.dbg.declare(metadata ptr %267, metadata !1093, metadata !DIExpression()), !dbg !1092
  %2233 = load i8, ptr %261, align 1, !dbg !1092
  store i8 %2233, ptr %267, align 1, !dbg !1092
  %2234 = load ptr, ptr %266, align 8, !dbg !1092
  store ptr %2234, ptr %56, align 8, !dbg !1092
  %2235 = load i8, ptr %267, align 1, !dbg !1092
  store i8 %2235, ptr %59, align 1, !dbg !1092
  br label %2236, !dbg !1092

2236:                                             ; preds = %2230
  br label %2631, !dbg !812

2237:                                             ; preds = %1369
  call void @llvm.dbg.declare(metadata ptr %268, metadata !1094, metadata !DIExpression()), !dbg !1097
  store i8 0, ptr %268, align 1, !dbg !1097
  %2238 = load i8, ptr %73, align 1, !dbg !1097
  store i8 %2238, ptr %268, align 1, !dbg !1097
  %2239 = load i8, ptr %268, align 1, !dbg !1097
  store i8 %2239, ptr %269, align 1, !dbg !1097
  %2240 = load i8, ptr %269, align 1, !dbg !1097
  %2241 = zext i8 %2240 to i32, !dbg !1098
  %2242 = icmp eq i32 %2241, 1, !dbg !1098
  br i1 %2242, label %2243, label %2331, !dbg !812

2243:                                             ; preds = %2237
  %2244 = load ptr, ptr %166, align 8, !dbg !1098
  store i64 -1024, ptr %45, align 8
  call void @llvm.dbg.declare(metadata ptr %45, metadata !348, metadata !DIExpression()), !dbg !1099
  %2245 = load i64, ptr %45, align 8, !dbg !1101
  %2246 = load i8, ptr %150, align 1, !dbg !1098
  store ptr %2244, ptr %31, align 8
  call void @llvm.dbg.declare(metadata ptr %31, metadata !492, metadata !DIExpression()), !dbg !1102
  store i64 %2245, ptr %32, align 8
  call void @llvm.dbg.declare(metadata ptr %32, metadata !501, metadata !DIExpression()), !dbg !1104
  store i8 %2246, ptr %33, align 1
  call void @llvm.dbg.declare(metadata ptr %33, metadata !503, metadata !DIExpression()), !dbg !1105
  %2247 = load i64, ptr %32, align 8, !dbg !1106
  %2248 = call i1 @llvm.is.constant.i64(i64 %2247), !dbg !1107
  br i1 %2248, label %2249, label %2255, !dbg !1108

2249:                                             ; preds = %2243
  %2250 = load i64, ptr %32, align 8, !dbg !1109
  %2251 = icmp slt i64 %2250, -32768, !dbg !1110
  br i1 %2251, label %2255, label %2252, !dbg !1111

2252:                                             ; preds = %2249
  %2253 = load i64, ptr %32, align 8, !dbg !1112
  %2254 = icmp sgt i64 %2253, 32767, !dbg !1113
  br i1 %2254, label %2255, label %2256, !dbg !1114

2255:                                             ; preds = %2252, %2249, %2243
  call void @kprog_x86_fixed_displacement_required() #8, !dbg !1115, !srcloc !516
  br label %2256, !dbg !1115

2256:                                             ; preds = %2255, %2252
  call void @llvm.dbg.declare(metadata ptr %34, metadata !517, metadata !DIExpression()), !dbg !1116
  %2257 = load i8, ptr %33, align 1, !dbg !1117
  %2258 = zext i8 %2257 to i32, !dbg !1117
  %2259 = icmp ne i32 %2258, 0, !dbg !1117
  br i1 %2259, label %2260, label %2263, !dbg !1117

2260:                                             ; preds = %2256
  %2261 = load i8, ptr %33, align 1, !dbg !1118
  %2262 = zext i8 %2261 to i32, !dbg !1118
  br label %2264, !dbg !1117

2263:                                             ; preds = %2256
  br label %2264, !dbg !1117

2264:                                             ; preds = %2263, %2260
  %2265 = phi i32 [ %2262, %2260 ], [ 8, %2263 ], !dbg !1117
  switch i32 %2265, label %2328 [
    i32 1, label %2266
    i32 2, label %2282
    i32 4, label %2298
    i32 8, label %2314
  ], !dbg !1119

2266:                                             ; preds = %2264
  %2267 = load i64, ptr %32, align 8, !dbg !1120
  %2268 = icmp slt i64 %2267, 0, !dbg !1121
  br i1 %2268, label %2269, label %2274, !dbg !1122

2269:                                             ; preds = %2266
  %2270 = load ptr, ptr %31, align 8, !dbg !1123
  %2271 = load i64, ptr %32, align 8, !dbg !1124
  %2272 = sub nsw i64 0, %2271, !dbg !1125
  %2273 = call i64 asm sideeffect "$0 = *(u8 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %2270, i64 %2272) #8, !dbg !1126, !srcloc !531
  store i64 %2273, ptr %34, align 8, !dbg !1126
  br label %2278, !dbg !1126

2274:                                             ; preds = %2266
  %2275 = load ptr, ptr %31, align 8, !dbg !1127
  %2276 = load i64, ptr %32, align 8, !dbg !1128
  %2277 = call i64 asm sideeffect "$0 = *(u8 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %2275, i64 %2276) #8, !dbg !1129, !srcloc !535
  store i64 %2277, ptr %34, align 8, !dbg !1129
  br label %2278

2278:                                             ; preds = %2274, %2269
  %2279 = load i64, ptr %34, align 8, !dbg !1130
  %2280 = trunc i64 %2279 to i8, !dbg !1131
  %2281 = zext i8 %2280 to i64, !dbg !1131
  store i64 %2281, ptr %30, align 8, !dbg !1132
  br label %2329, !dbg !1132

2282:                                             ; preds = %2264
  %2283 = load i64, ptr %32, align 8, !dbg !1133
  %2284 = icmp slt i64 %2283, 0, !dbg !1134
  br i1 %2284, label %2285, label %2290, !dbg !1135

2285:                                             ; preds = %2282
  %2286 = load ptr, ptr %31, align 8, !dbg !1136
  %2287 = load i64, ptr %32, align 8, !dbg !1137
  %2288 = sub nsw i64 0, %2287, !dbg !1138
  %2289 = call i64 asm sideeffect "$0 = *(u16 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %2286, i64 %2288) #8, !dbg !1139, !srcloc !547
  store i64 %2289, ptr %34, align 8, !dbg !1139
  br label %2294, !dbg !1139

2290:                                             ; preds = %2282
  %2291 = load ptr, ptr %31, align 8, !dbg !1140
  %2292 = load i64, ptr %32, align 8, !dbg !1141
  %2293 = call i64 asm sideeffect "$0 = *(u16 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %2291, i64 %2292) #8, !dbg !1142, !srcloc !551
  store i64 %2293, ptr %34, align 8, !dbg !1142
  br label %2294

2294:                                             ; preds = %2290, %2285
  %2295 = load i64, ptr %34, align 8, !dbg !1143
  %2296 = trunc i64 %2295 to i16, !dbg !1144
  %2297 = zext i16 %2296 to i64, !dbg !1144
  store i64 %2297, ptr %30, align 8, !dbg !1145
  br label %2329, !dbg !1145

2298:                                             ; preds = %2264
  %2299 = load i64, ptr %32, align 8, !dbg !1146
  %2300 = icmp slt i64 %2299, 0, !dbg !1147
  br i1 %2300, label %2301, label %2306, !dbg !1148

2301:                                             ; preds = %2298
  %2302 = load ptr, ptr %31, align 8, !dbg !1149
  %2303 = load i64, ptr %32, align 8, !dbg !1150
  %2304 = sub nsw i64 0, %2303, !dbg !1151
  %2305 = call i64 asm sideeffect "$0 = *(u32 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %2302, i64 %2304) #8, !dbg !1152, !srcloc !563
  store i64 %2305, ptr %34, align 8, !dbg !1152
  br label %2310, !dbg !1152

2306:                                             ; preds = %2298
  %2307 = load ptr, ptr %31, align 8, !dbg !1153
  %2308 = load i64, ptr %32, align 8, !dbg !1154
  %2309 = call i64 asm sideeffect "$0 = *(u32 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %2307, i64 %2308) #8, !dbg !1155, !srcloc !567
  store i64 %2309, ptr %34, align 8, !dbg !1155
  br label %2310

2310:                                             ; preds = %2306, %2301
  %2311 = load i64, ptr %34, align 8, !dbg !1156
  %2312 = trunc i64 %2311 to i32, !dbg !1157
  %2313 = zext i32 %2312 to i64, !dbg !1157
  store i64 %2313, ptr %30, align 8, !dbg !1158
  br label %2329, !dbg !1158

2314:                                             ; preds = %2264
  %2315 = load i64, ptr %32, align 8, !dbg !1159
  %2316 = icmp slt i64 %2315, 0, !dbg !1160
  br i1 %2316, label %2317, label %2322, !dbg !1161

2317:                                             ; preds = %2314
  %2318 = load ptr, ptr %31, align 8, !dbg !1162
  %2319 = load i64, ptr %32, align 8, !dbg !1163
  %2320 = sub nsw i64 0, %2319, !dbg !1164
  %2321 = call i64 asm sideeffect "$0 = *(u64 *)($1 - $2)", "=r,r,i,~{memory}"(ptr %2318, i64 %2320) #8, !dbg !1165, !srcloc !579
  store i64 %2321, ptr %34, align 8, !dbg !1165
  br label %2326, !dbg !1165

2322:                                             ; preds = %2314
  %2323 = load ptr, ptr %31, align 8, !dbg !1166
  %2324 = load i64, ptr %32, align 8, !dbg !1167
  %2325 = call i64 asm sideeffect "$0 = *(u64 *)($1 + $2)", "=r,r,i,~{memory}"(ptr %2323, i64 %2324) #8, !dbg !1168, !srcloc !583
  store i64 %2325, ptr %34, align 8, !dbg !1168
  br label %2326

2326:                                             ; preds = %2322, %2317
  %2327 = load i64, ptr %34, align 8, !dbg !1169
  store i64 %2327, ptr %30, align 8, !dbg !1170
  br label %2329, !dbg !1170

2328:                                             ; preds = %2264
  call void @llvm.trap(), !dbg !1171
  br label %2329, !dbg !1172

2329:                                             ; preds = %2278, %2294, %2310, %2326, %2328
  %2330 = load i64, ptr %30, align 8, !dbg !1173
  store i64 %2330, ptr %167, align 8, !dbg !1098
  br label %2372, !dbg !1098

2331:                                             ; preds = %2237
  %2332 = load ptr, ptr %166, align 8, !dbg !1098
  %2333 = ptrtoint ptr %2332 to i64, !dbg !1098
  %2334 = load i64, ptr %158, align 8, !dbg !1098
  %2335 = add i64 %2333, %2334, !dbg !1098
  %2336 = inttoptr i64 %2335 to ptr, !dbg !1098
  %2337 = load i8, ptr %150, align 1, !dbg !1098
  store ptr %2336, ptr %17, align 8
  call void @llvm.dbg.declare(metadata ptr %17, metadata !589, metadata !DIExpression()), !dbg !1174
  store i8 %2337, ptr %18, align 1
  call void @llvm.dbg.declare(metadata ptr %18, metadata !595, metadata !DIExpression()), !dbg !1176
  call void @llvm.dbg.declare(metadata ptr %19, metadata !597, metadata !DIExpression()), !dbg !1177
  %2338 = load i8, ptr %18, align 1, !dbg !1178
  %2339 = zext i8 %2338 to i32, !dbg !1178
  %2340 = icmp ne i32 %2339, 0, !dbg !1178
  br i1 %2340, label %2341, label %2344, !dbg !1178

2341:                                             ; preds = %2331
  %2342 = load i8, ptr %18, align 1, !dbg !1179
  %2343 = zext i8 %2342 to i32, !dbg !1179
  br label %2345, !dbg !1178

2344:                                             ; preds = %2331
  br label %2345, !dbg !1178

2345:                                             ; preds = %2344, %2341
  %2346 = phi i32 [ %2343, %2341 ], [ 8, %2344 ], !dbg !1178
  switch i32 %2346, label %2369 [
    i32 1, label %2347
    i32 2, label %2353
    i32 4, label %2359
    i32 8, label %2365
  ], !dbg !1180

2347:                                             ; preds = %2345
  %2348 = load ptr, ptr %17, align 8, !dbg !1181
  %2349 = call i64 asm sideeffect "$0 = *(u8 *)($1 + 0)", "=r,r,~{memory}"(ptr %2348) #8, !dbg !1182, !srcloc !605
  store i64 %2349, ptr %19, align 8, !dbg !1182
  %2350 = load i64, ptr %19, align 8, !dbg !1183
  %2351 = trunc i64 %2350 to i8, !dbg !1184
  %2352 = zext i8 %2351 to i64, !dbg !1184
  store i64 %2352, ptr %16, align 8, !dbg !1185
  br label %2370, !dbg !1185

2353:                                             ; preds = %2345
  %2354 = load ptr, ptr %17, align 8, !dbg !1186
  %2355 = call i64 asm sideeffect "$0 = *(u16 *)($1 + 0)", "=r,r,~{memory}"(ptr %2354) #8, !dbg !1187, !srcloc !611
  store i64 %2355, ptr %19, align 8, !dbg !1187
  %2356 = load i64, ptr %19, align 8, !dbg !1188
  %2357 = trunc i64 %2356 to i16, !dbg !1189
  %2358 = zext i16 %2357 to i64, !dbg !1189
  store i64 %2358, ptr %16, align 8, !dbg !1190
  br label %2370, !dbg !1190

2359:                                             ; preds = %2345
  %2360 = load ptr, ptr %17, align 8, !dbg !1191
  %2361 = call i64 asm sideeffect "$0 = *(u32 *)($1 + 0)", "=r,r,~{memory}"(ptr %2360) #8, !dbg !1192, !srcloc !617
  store i64 %2361, ptr %19, align 8, !dbg !1192
  %2362 = load i64, ptr %19, align 8, !dbg !1193
  %2363 = trunc i64 %2362 to i32, !dbg !1194
  %2364 = zext i32 %2363 to i64, !dbg !1194
  store i64 %2364, ptr %16, align 8, !dbg !1195
  br label %2370, !dbg !1195

2365:                                             ; preds = %2345
  %2366 = load ptr, ptr %17, align 8, !dbg !1196
  %2367 = call i64 asm sideeffect "$0 = *(u64 *)($1 + 0)", "=r,r,~{memory}"(ptr %2366) #8, !dbg !1197, !srcloc !623
  store i64 %2367, ptr %19, align 8, !dbg !1197
  %2368 = load i64, ptr %19, align 8, !dbg !1198
  store i64 %2368, ptr %16, align 8, !dbg !1199
  br label %2370, !dbg !1199

2369:                                             ; preds = %2345
  call void @llvm.trap(), !dbg !1200
  br label %2370, !dbg !1201

2370:                                             ; preds = %2347, %2353, %2359, %2365, %2369
  %2371 = load i64, ptr %16, align 8, !dbg !1202
  store i64 %2371, ptr %167, align 8, !dbg !1098
  br label %2372

2372:                                             ; preds = %2370, %2329
  call void @llvm.dbg.declare(metadata ptr %270, metadata !1203, metadata !DIExpression()), !dbg !812
  call void @llvm.memset.p0.i64(ptr align 8 %270, i8 0, i64 16, i1 false), !dbg !812
  call void @llvm.dbg.declare(metadata ptr %271, metadata !1204, metadata !DIExpression()), !dbg !1207
  store i8 0, ptr %271, align 1, !dbg !1207
  %2373 = load i8, ptr %73, align 1, !dbg !1207
  store i8 %2373, ptr %271, align 1, !dbg !1207
  %2374 = load i8, ptr %271, align 1, !dbg !1207
  store i8 %2374, ptr %272, align 1, !dbg !1207
  %2375 = load i8, ptr %272, align 1, !dbg !1207
  %2376 = zext i8 %2375 to i32, !dbg !1208
  %2377 = icmp eq i32 %2376, 4, !dbg !1208
  br i1 %2377, label %2378, label %2419, !dbg !812

2378:                                             ; preds = %2372
  call void @llvm.dbg.declare(metadata ptr %273, metadata !1209, metadata !DIExpression()), !dbg !1211
  call void @llvm.memset.p0.i64(ptr align 8 %273, i8 0, i64 16, i1 false), !dbg !1211
  call void @llvm.dbg.declare(metadata ptr %274, metadata !1212, metadata !DIExpression()), !dbg !1211
  %2379 = load ptr, ptr %168, align 8, !dbg !1211
  %2380 = ptrtoint ptr %2379 to i64, !dbg !1211
  %2381 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1211
  %2382 = ptrtoint ptr %2381 to i64, !dbg !1211
  %2383 = sub i64 %2380, %2382, !dbg !1211
  store i64 %2383, ptr %274, align 8, !dbg !1211
  %2384 = load i8, ptr %150, align 1, !dbg !1213
  store i8 %2384, ptr %8, align 1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !656, metadata !DIExpression()), !dbg !1215
  %2385 = load i8, ptr %8, align 1, !dbg !1217
  %2386 = zext i8 %2385 to i32, !dbg !1217
  %2387 = icmp ne i32 %2386, 0, !dbg !1217
  br i1 %2387, label %2388, label %2391, !dbg !1217

2388:                                             ; preds = %2378
  %2389 = load i8, ptr %8, align 1, !dbg !1217
  %2390 = zext i8 %2389 to i32, !dbg !1217
  br label %2392, !dbg !1217

2391:                                             ; preds = %2378
  br label %2392, !dbg !1217

2392:                                             ; preds = %2388, %2391
  %2393 = phi i32 [ %2390, %2388 ], [ 8, %2391 ], !dbg !1217
  %2394 = trunc i32 %2393 to i8, !dbg !1217
  %2395 = zext i8 %2394 to i32, !dbg !1213
  %2396 = icmp eq i32 %2395, 8, !dbg !1213
  br i1 %2396, label %2397, label %2418, !dbg !1211

2397:                                             ; preds = %2392
  br label %2398, !dbg !1218

2398:                                             ; preds = %2397
  %2399 = load i64, ptr %274, align 8, !dbg !1220
  %2400 = icmp eq i64 %2399, 0, !dbg !1220
  br i1 %2400, label %2401, label %2416, !dbg !1220

2401:                                             ; preds = %2398
  %2402 = load i8, ptr %51, align 1, !dbg !1220
  %2403 = zext i8 %2402 to i32, !dbg !1220
  %2404 = icmp ne i32 %2403, 0, !dbg !1220
  br i1 %2404, label %2405, label %2416, !dbg !1223

2405:                                             ; preds = %2401
  %2406 = load i8, ptr %51, align 1, !dbg !1224
  %2407 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %273, i32 0, i32 1, !dbg !1224
  store i8 %2406, ptr %2407, align 8, !dbg !1224
  %2408 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %273, i32 0, i32 1, !dbg !1226
  %2409 = load i8, ptr %2408, align 8, !dbg !1226
  %2410 = zext i8 %2409 to i32, !dbg !1226
  %2411 = icmp eq i32 %2410, 4, !dbg !1226
  br i1 %2411, label %2412, label %2415, !dbg !1224

2412:                                             ; preds = %2405
  %2413 = load ptr, ptr %52, align 8, !dbg !1226
  %2414 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %273, i32 0, i32 0, !dbg !1226
  store ptr %2413, ptr %2414, align 8, !dbg !1226
  br label %2415, !dbg !1226

2415:                                             ; preds = %2412, %2405
  br label %2416, !dbg !1224

2416:                                             ; preds = %2415, %2401, %2398
  br label %2417, !dbg !1223

2417:                                             ; preds = %2416
  br label %2418, !dbg !1218

2418:                                             ; preds = %2417, %2392
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %270, ptr align 8 %273, i64 16, i1 false), !dbg !1211
  br label %2419, !dbg !1208

2419:                                             ; preds = %2418, %2372
  %2420 = load i8, ptr %147, align 1, !dbg !1228
  %2421 = zext i8 %2420 to i32, !dbg !1228
  %2422 = icmp eq i32 %2421, 8, !dbg !1228
  br i1 %2422, label %2423, label %2447, !dbg !1228

2423:                                             ; preds = %2419
  %2424 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %270, i32 0, i32 1, !dbg !1228
  %2425 = load i8, ptr %2424, align 8, !dbg !1228
  %2426 = zext i8 %2425 to i32, !dbg !1228
  %2427 = icmp ne i32 %2426, 0, !dbg !1228
  br i1 %2427, label %2428, label %2447, !dbg !812

2428:                                             ; preds = %2423
  br label %2429, !dbg !1228

2429:                                             ; preds = %2428
  call void @llvm.dbg.declare(metadata ptr %275, metadata !1230, metadata !DIExpression()), !dbg !1232
  %2430 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %270, i32 0, i32 1, !dbg !1232
  %2431 = load i8, ptr %2430, align 8, !dbg !1232
  %2432 = zext i8 %2431 to i32, !dbg !1232
  %2433 = icmp eq i32 %2432, 4, !dbg !1232
  br i1 %2433, label %2434, label %2437, !dbg !1232

2434:                                             ; preds = %2429
  %2435 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %270, i32 0, i32 0, !dbg !1232
  %2436 = load ptr, ptr %2435, align 8, !dbg !1232
  br label %2440, !dbg !1232

2437:                                             ; preds = %2429
  %2438 = load i64, ptr %167, align 8, !dbg !1232
  %2439 = inttoptr i64 %2438 to ptr, !dbg !1232
  br label %2440, !dbg !1232

2440:                                             ; preds = %2437, %2434
  %2441 = phi ptr [ %2436, %2434 ], [ %2439, %2437 ], !dbg !1232
  store ptr %2441, ptr %275, align 8, !dbg !1232
  call void @llvm.dbg.declare(metadata ptr %276, metadata !1233, metadata !DIExpression()), !dbg !1232
  %2442 = getelementptr inbounds %struct.x86_sim_stack_value, ptr %270, i32 0, i32 1, !dbg !1232
  %2443 = load i8, ptr %2442, align 8, !dbg !1232
  store i8 %2443, ptr %276, align 1, !dbg !1232
  %2444 = load ptr, ptr %275, align 8, !dbg !1232
  store ptr %2444, ptr %56, align 8, !dbg !1232
  %2445 = load i8, ptr %276, align 1, !dbg !1232
  store i8 %2445, ptr %59, align 1, !dbg !1232
  br label %2446, !dbg !1232

2446:                                             ; preds = %2440
  br label %2630, !dbg !1232

2447:                                             ; preds = %2423, %2419
  br label %2448, !dbg !1228

2448:                                             ; preds = %2447
  call void @llvm.dbg.declare(metadata ptr %277, metadata !1234, metadata !DIExpression()), !dbg !1236
  %2449 = load i8, ptr %147, align 1, !dbg !1236
  store i8 %2449, ptr %277, align 1, !dbg !1236
  call void @llvm.dbg.declare(metadata ptr %278, metadata !1237, metadata !DIExpression()), !dbg !1236
  %2450 = load i8, ptr %277, align 1, !dbg !1236
  store i8 %2450, ptr %9, align 1
  call void @llvm.dbg.declare(metadata ptr %9, metadata !656, metadata !DIExpression()), !dbg !1238
  %2451 = load i8, ptr %9, align 1, !dbg !1240
  %2452 = zext i8 %2451 to i32, !dbg !1240
  %2453 = icmp ne i32 %2452, 0, !dbg !1240
  br i1 %2453, label %2454, label %2457, !dbg !1240

2454:                                             ; preds = %2448
  %2455 = load i8, ptr %9, align 1, !dbg !1240
  %2456 = zext i8 %2455 to i32, !dbg !1240
  br label %2458, !dbg !1240

2457:                                             ; preds = %2448
  br label %2458, !dbg !1240

2458:                                             ; preds = %2454, %2457
  %2459 = phi i32 [ %2456, %2454 ], [ 8, %2457 ], !dbg !1240
  %2460 = trunc i32 %2459 to i8, !dbg !1240
  store i8 %2460, ptr %278, align 1, !dbg !1236
  call void @llvm.dbg.declare(metadata ptr %279, metadata !1241, metadata !DIExpression()), !dbg !1236
  store i8 0, ptr %279, align 1, !dbg !1236
  call void @llvm.dbg.declare(metadata ptr %280, metadata !1242, metadata !DIExpression()), !dbg !1236
  %2461 = load i64, ptr %167, align 8, !dbg !1236
  store i64 %2461, ptr %280, align 8, !dbg !1236
  %2462 = load i8, ptr %278, align 1, !dbg !1243
  %2463 = zext i8 %2462 to i32, !dbg !1243
  %2464 = icmp eq i32 %2463, 1, !dbg !1243
  br i1 %2464, label %2465, label %2466, !dbg !1243

2465:                                             ; preds = %2458
  br label %2479, !dbg !1243

2466:                                             ; preds = %2458
  %2467 = load i8, ptr %278, align 1, !dbg !1243
  %2468 = zext i8 %2467 to i32, !dbg !1243
  %2469 = icmp eq i32 %2468, 2, !dbg !1243
  br i1 %2469, label %2470, label %2471, !dbg !1243

2470:                                             ; preds = %2466
  br label %2477, !dbg !1243

2471:                                             ; preds = %2466
  %2472 = load i8, ptr %278, align 1, !dbg !1243
  %2473 = zext i8 %2472 to i32, !dbg !1243
  %2474 = icmp eq i32 %2473, 4, !dbg !1243
  %2475 = zext i1 %2474 to i64, !dbg !1243
  %2476 = select i1 %2474, i32 2, i32 3, !dbg !1243
  br label %2477, !dbg !1243

2477:                                             ; preds = %2471, %2470
  %2478 = phi i32 [ 1, %2470 ], [ %2476, %2471 ], !dbg !1243
  br label %2479, !dbg !1243

2479:                                             ; preds = %2477, %2465
  %2480 = phi i32 [ 0, %2465 ], [ %2478, %2477 ], !dbg !1243
  %2481 = icmp eq i32 %2480, 0, !dbg !1243
  br i1 %2481, label %2482, label %2537, !dbg !1236

2482:                                             ; preds = %2479
  %2483 = load i8, ptr %59, align 1, !dbg !1245
  %2484 = zext i8 %2483 to i32, !dbg !1245
  %2485 = icmp eq i32 %2484, 4, !dbg !1245
  br i1 %2485, label %2486, label %2502, !dbg !1249

2486:                                             ; preds = %2482
  call void @llvm.dbg.declare(metadata ptr %281, metadata !1250, metadata !DIExpression()), !dbg !1252
  %2487 = load ptr, ptr %56, align 8, !dbg !1252
  %2488 = ptrtoint ptr %2487 to i64, !dbg !1252
  %2489 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1252
  %2490 = ptrtoint ptr %2489 to i64, !dbg !1252
  %2491 = add i64 %2490, 1, !dbg !1252
  %2492 = inttoptr i64 %2491 to ptr, !dbg !1252
  %2493 = ptrtoint ptr %2492 to i64, !dbg !1252
  %2494 = sub i64 %2488, %2493, !dbg !1252
  store i64 %2494, ptr %281, align 8, !dbg !1252
  %2495 = load i64, ptr %281, align 8, !dbg !1252
  %2496 = call i64 asm sideeffect "", "=r,0"(i64 %2495) #8, !dbg !1252, !srcloc !1253
  store i64 %2496, ptr %281, align 8, !dbg !1252
  %2497 = load i64, ptr %281, align 8, !dbg !1252
  %2498 = load i64, ptr %118, align 8, !dbg !1252
  %2499 = add i64 %2497, %2498, !dbg !1252
  store i64 %2499, ptr %282, align 8, !dbg !1252
  %2500 = load i64, ptr %282, align 8, !dbg !1252
  %2501 = inttoptr i64 %2500 to ptr, !dbg !1245
  store ptr %2501, ptr %56, align 8, !dbg !1245
  br label %2502, !dbg !1245

2502:                                             ; preds = %2486, %2482
  br label %2503, !dbg !1254

2503:                                             ; preds = %2502
  %2504 = load i8, ptr %59, align 1, !dbg !1255
  %2505 = zext i8 %2504 to i32, !dbg !1255
  %2506 = icmp eq i32 %2505, 0, !dbg !1255
  br i1 %2506, label %2507, label %2520, !dbg !1258

2507:                                             ; preds = %2503
  %2508 = load i8, ptr %279, align 1, !dbg !1259
  %2509 = zext i8 %2508 to i32, !dbg !1259
  %2510 = icmp eq i32 %2509, 8, !dbg !1259
  br i1 %2510, label %2511, label %2515, !dbg !1262

2511:                                             ; preds = %2507
  %2512 = load i64, ptr %280, align 8, !dbg !1259
  %2513 = trunc i64 %2512 to i8, !dbg !1259
  %2514 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 1, !dbg !1259
  store i8 %2513, ptr %2514, align 1, !dbg !1259
  br label %2519, !dbg !1259

2515:                                             ; preds = %2507
  %2516 = load i64, ptr %280, align 8, !dbg !1259
  %2517 = trunc i64 %2516 to i8, !dbg !1259
  %2518 = getelementptr inbounds [8 x i8], ptr %56, i64 0, i64 0, !dbg !1259
  store i8 %2517, ptr %2518, align 8, !dbg !1259
  br label %2519

2519:                                             ; preds = %2515, %2511
  br label %2535, !dbg !1262

2520:                                             ; preds = %2503
  call void @llvm.dbg.declare(metadata ptr %283, metadata !1263, metadata !DIExpression()), !dbg !1271
  %2521 = load ptr, ptr %56, align 8, !dbg !1271
  store ptr %2521, ptr %283, align 8, !dbg !1271
  %2522 = load i8, ptr %279, align 1, !dbg !1272
  %2523 = zext i8 %2522 to i32, !dbg !1272
  %2524 = icmp eq i32 %2523, 8, !dbg !1272
  br i1 %2524, label %2525, label %2529, !dbg !1271

2525:                                             ; preds = %2520
  %2526 = load i64, ptr %280, align 8, !dbg !1272
  %2527 = trunc i64 %2526 to i8, !dbg !1272
  %2528 = getelementptr inbounds [8 x i8], ptr %283, i64 0, i64 1, !dbg !1272
  store volatile i8 %2527, ptr %2528, align 1, !dbg !1272
  br label %2533, !dbg !1272

2529:                                             ; preds = %2520
  %2530 = load i64, ptr %280, align 8, !dbg !1272
  %2531 = trunc i64 %2530 to i8, !dbg !1272
  %2532 = getelementptr inbounds [8 x i8], ptr %283, i64 0, i64 0, !dbg !1272
  store volatile i8 %2531, ptr %2532, align 8, !dbg !1272
  br label %2533

2533:                                             ; preds = %2529, %2525
  %2534 = load volatile ptr, ptr %283, align 8, !dbg !1271
  store ptr %2534, ptr %56, align 8, !dbg !1271
  br label %2535

2535:                                             ; preds = %2533, %2519
  store i8 0, ptr %59, align 1, !dbg !1258
  br label %2536, !dbg !1258

2536:                                             ; preds = %2535
  br label %2628, !dbg !1254

2537:                                             ; preds = %2479
  %2538 = load i8, ptr %278, align 1, !dbg !1274
  %2539 = zext i8 %2538 to i32, !dbg !1274
  %2540 = icmp eq i32 %2539, 1, !dbg !1274
  br i1 %2540, label %2541, label %2542, !dbg !1274

2541:                                             ; preds = %2537
  br label %2555, !dbg !1274

2542:                                             ; preds = %2537
  %2543 = load i8, ptr %278, align 1, !dbg !1274
  %2544 = zext i8 %2543 to i32, !dbg !1274
  %2545 = icmp eq i32 %2544, 2, !dbg !1274
  br i1 %2545, label %2546, label %2547, !dbg !1274

2546:                                             ; preds = %2542
  br label %2553, !dbg !1274

2547:                                             ; preds = %2542
  %2548 = load i8, ptr %278, align 1, !dbg !1274
  %2549 = zext i8 %2548 to i32, !dbg !1274
  %2550 = icmp eq i32 %2549, 4, !dbg !1274
  %2551 = zext i1 %2550 to i64, !dbg !1274
  %2552 = select i1 %2550, i32 2, i32 3, !dbg !1274
  br label %2553, !dbg !1274

2553:                                             ; preds = %2547, %2546
  %2554 = phi i32 [ 1, %2546 ], [ %2552, %2547 ], !dbg !1274
  br label %2555, !dbg !1274

2555:                                             ; preds = %2553, %2541
  %2556 = phi i32 [ 0, %2541 ], [ %2554, %2553 ], !dbg !1274
  %2557 = icmp eq i32 %2556, 1, !dbg !1274
  br i1 %2557, label %2558, label %2593, !dbg !1243

2558:                                             ; preds = %2555
  %2559 = load i8, ptr %59, align 1, !dbg !1276
  %2560 = zext i8 %2559 to i32, !dbg !1276
  %2561 = icmp eq i32 %2560, 4, !dbg !1276
  br i1 %2561, label %2562, label %2578, !dbg !1280

2562:                                             ; preds = %2558
  call void @llvm.dbg.declare(metadata ptr %284, metadata !1281, metadata !DIExpression()), !dbg !1283
  %2563 = load ptr, ptr %56, align 8, !dbg !1283
  %2564 = ptrtoint ptr %2563 to i64, !dbg !1283
  %2565 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1283
  %2566 = ptrtoint ptr %2565 to i64, !dbg !1283
  %2567 = add i64 %2566, 1, !dbg !1283
  %2568 = inttoptr i64 %2567 to ptr, !dbg !1283
  %2569 = ptrtoint ptr %2568 to i64, !dbg !1283
  %2570 = sub i64 %2564, %2569, !dbg !1283
  store i64 %2570, ptr %284, align 8, !dbg !1283
  %2571 = load i64, ptr %284, align 8, !dbg !1283
  %2572 = call i64 asm sideeffect "", "=r,0"(i64 %2571) #8, !dbg !1283, !srcloc !1284
  store i64 %2572, ptr %284, align 8, !dbg !1283
  %2573 = load i64, ptr %284, align 8, !dbg !1283
  %2574 = load i64, ptr %118, align 8, !dbg !1283
  %2575 = add i64 %2573, %2574, !dbg !1283
  store i64 %2575, ptr %285, align 8, !dbg !1283
  %2576 = load i64, ptr %285, align 8, !dbg !1283
  %2577 = inttoptr i64 %2576 to ptr, !dbg !1276
  store ptr %2577, ptr %56, align 8, !dbg !1276
  br label %2578, !dbg !1276

2578:                                             ; preds = %2562, %2558
  br label %2579, !dbg !1285

2579:                                             ; preds = %2578
  %2580 = load i8, ptr %59, align 1, !dbg !1286
  %2581 = zext i8 %2580 to i32, !dbg !1286
  %2582 = icmp eq i32 %2581, 0, !dbg !1286
  br i1 %2582, label %2583, label %2586, !dbg !1289

2583:                                             ; preds = %2579
  %2584 = load i64, ptr %280, align 8, !dbg !1290
  %2585 = trunc i64 %2584 to i16, !dbg !1290
  store i16 %2585, ptr %56, align 8, !dbg !1290
  br label %2591, !dbg !1290

2586:                                             ; preds = %2579
  call void @llvm.dbg.declare(metadata ptr %286, metadata !1292, metadata !DIExpression()), !dbg !1300
  %2587 = load ptr, ptr %56, align 8, !dbg !1300
  store ptr %2587, ptr %286, align 8, !dbg !1300
  %2588 = load i64, ptr %280, align 8, !dbg !1300
  %2589 = trunc i64 %2588 to i16, !dbg !1300
  store volatile i16 %2589, ptr %286, align 8, !dbg !1300
  %2590 = load volatile ptr, ptr %286, align 8, !dbg !1300
  store ptr %2590, ptr %56, align 8, !dbg !1300
  br label %2591

2591:                                             ; preds = %2586, %2583
  store i8 0, ptr %59, align 1, !dbg !1289
  br label %2592, !dbg !1289

2592:                                             ; preds = %2591
  br label %2627, !dbg !1285

2593:                                             ; preds = %2555
  %2594 = load i8, ptr %278, align 1, !dbg !1301
  %2595 = zext i8 %2594 to i32, !dbg !1301
  %2596 = icmp eq i32 %2595, 1, !dbg !1301
  br i1 %2596, label %2597, label %2598, !dbg !1301

2597:                                             ; preds = %2593
  br label %2611, !dbg !1301

2598:                                             ; preds = %2593
  %2599 = load i8, ptr %278, align 1, !dbg !1301
  %2600 = zext i8 %2599 to i32, !dbg !1301
  %2601 = icmp eq i32 %2600, 2, !dbg !1301
  br i1 %2601, label %2602, label %2603, !dbg !1301

2602:                                             ; preds = %2598
  br label %2609, !dbg !1301

2603:                                             ; preds = %2598
  %2604 = load i8, ptr %278, align 1, !dbg !1301
  %2605 = zext i8 %2604 to i32, !dbg !1301
  %2606 = icmp eq i32 %2605, 4, !dbg !1301
  %2607 = zext i1 %2606 to i64, !dbg !1301
  %2608 = select i1 %2606, i32 2, i32 3, !dbg !1301
  br label %2609, !dbg !1301

2609:                                             ; preds = %2603, %2602
  %2610 = phi i32 [ 1, %2602 ], [ %2608, %2603 ], !dbg !1301
  br label %2611, !dbg !1301

2611:                                             ; preds = %2609, %2597
  %2612 = phi i32 [ 0, %2597 ], [ %2610, %2609 ], !dbg !1301
  %2613 = icmp eq i32 %2612, 2, !dbg !1301
  br i1 %2613, label %2614, label %2621, !dbg !1274

2614:                                             ; preds = %2611
  br label %2615, !dbg !1303

2615:                                             ; preds = %2614
  %2616 = load i64, ptr %280, align 8, !dbg !1305
  %2617 = trunc i64 %2616 to i32, !dbg !1305
  %2618 = zext i32 %2617 to i64, !dbg !1305
  %2619 = inttoptr i64 %2618 to ptr, !dbg !1305
  store ptr %2619, ptr %56, align 8, !dbg !1305
  store i8 0, ptr %59, align 1, !dbg !1305
  br label %2620, !dbg !1305

2620:                                             ; preds = %2615
  br label %2626, !dbg !1303

2621:                                             ; preds = %2611
  br label %2622, !dbg !1307

2622:                                             ; preds = %2621
  %2623 = load i64, ptr %280, align 8, !dbg !1309
  %2624 = inttoptr i64 %2623 to ptr, !dbg !1309
  store ptr %2624, ptr %56, align 8, !dbg !1309
  store i8 0, ptr %59, align 1, !dbg !1309
  br label %2625, !dbg !1309

2625:                                             ; preds = %2622
  br label %2626

2626:                                             ; preds = %2625, %2620
  br label %2627

2627:                                             ; preds = %2626, %2592
  br label %2628

2628:                                             ; preds = %2627, %2536
  br label %2629, !dbg !1236

2629:                                             ; preds = %2628
  br label %2630

2630:                                             ; preds = %2629, %2446
  br label %2631, !dbg !812

2631:                                             ; preds = %2630, %2236, %2193, %1919
  br label %2632

2632:                                             ; preds = %2631, %1368
  br label %2633

2633:                                             ; preds = %2632, %1253
  br label %2634, !dbg !325

2634:                                             ; preds = %2633
  br label %2635, !dbg !325

2635:                                             ; preds = %2634
  call void @llvm.dbg.label(metadata !1311), !dbg !1312
  br label %2636, !dbg !1313

2636:                                             ; preds = %2635
  call void @llvm.dbg.declare(metadata ptr %287, metadata !1314, metadata !DIExpression()), !dbg !1317
  store i8 0, ptr %287, align 1, !dbg !1317
  call void @llvm.dbg.declare(metadata ptr %288, metadata !1318, metadata !DIExpression()), !dbg !1317
  store i8 8, ptr %288, align 1, !dbg !1317
  call void @llvm.dbg.declare(metadata ptr %289, metadata !1319, metadata !DIExpression()), !dbg !1317
  %2637 = load i8, ptr %288, align 1, !dbg !1317
  store i8 %2637, ptr %10, align 1
  call void @llvm.dbg.declare(metadata ptr %10, metadata !656, metadata !DIExpression()), !dbg !1320
  %2638 = load i8, ptr %10, align 1, !dbg !1322
  %2639 = zext i8 %2638 to i32, !dbg !1322
  %2640 = icmp ne i32 %2639, 0, !dbg !1322
  br i1 %2640, label %2641, label %2644, !dbg !1322

2641:                                             ; preds = %2636
  %2642 = load i8, ptr %10, align 1, !dbg !1322
  %2643 = zext i8 %2642 to i32, !dbg !1322
  br label %2645, !dbg !1322

2644:                                             ; preds = %2636
  br label %2645, !dbg !1322

2645:                                             ; preds = %2641, %2644
  %2646 = phi i32 [ %2643, %2641 ], [ 8, %2644 ], !dbg !1322
  %2647 = trunc i32 %2646 to i8, !dbg !1322
  store i8 %2647, ptr %289, align 1, !dbg !1317
  call void @llvm.dbg.declare(metadata ptr %290, metadata !1323, metadata !DIExpression()), !dbg !1317
  store i8 0, ptr %290, align 1, !dbg !1317
  call void @llvm.dbg.declare(metadata ptr %291, metadata !1324, metadata !DIExpression()), !dbg !1317
  %2648 = load i8, ptr %287, align 1, !dbg !1317
  %2649 = zext i8 %2648 to i32, !dbg !1317
  %2650 = icmp eq i32 %2649, 0, !dbg !1317
  br i1 %2650, label %2651, label %2653, !dbg !1317

2651:                                             ; preds = %2645
  %2652 = load ptr, ptr %56, align 8, !dbg !1317
  br label %2774, !dbg !1317

2653:                                             ; preds = %2645
  %2654 = load i8, ptr %287, align 1, !dbg !1317
  %2655 = zext i8 %2654 to i32, !dbg !1317
  %2656 = icmp eq i32 %2655, 1, !dbg !1317
  br i1 %2656, label %2657, label %2659, !dbg !1317

2657:                                             ; preds = %2653
  %2658 = load ptr, ptr %60, align 8, !dbg !1317
  br label %2772, !dbg !1317

2659:                                             ; preds = %2653
  %2660 = load i8, ptr %287, align 1, !dbg !1317
  %2661 = zext i8 %2660 to i32, !dbg !1317
  %2662 = icmp eq i32 %2661, 2, !dbg !1317
  br i1 %2662, label %2663, label %2665, !dbg !1317

2663:                                             ; preds = %2659
  %2664 = load ptr, ptr %64, align 8, !dbg !1317
  br label %2770, !dbg !1317

2665:                                             ; preds = %2659
  %2666 = load i8, ptr %287, align 1, !dbg !1317
  %2667 = zext i8 %2666 to i32, !dbg !1317
  %2668 = icmp eq i32 %2667, 3, !dbg !1317
  br i1 %2668, label %2669, label %2671, !dbg !1317

2669:                                             ; preds = %2665
  %2670 = load ptr, ptr %68, align 8, !dbg !1317
  br label %2768, !dbg !1317

2671:                                             ; preds = %2665
  %2672 = load i8, ptr %287, align 1, !dbg !1317
  %2673 = zext i8 %2672 to i32, !dbg !1317
  %2674 = icmp eq i32 %2673, 4, !dbg !1317
  br i1 %2674, label %2675, label %2677, !dbg !1317

2675:                                             ; preds = %2671
  %2676 = load ptr, ptr %72, align 8, !dbg !1317
  br label %2766, !dbg !1317

2677:                                             ; preds = %2671
  %2678 = load i8, ptr %287, align 1, !dbg !1317
  %2679 = zext i8 %2678 to i32, !dbg !1317
  %2680 = icmp eq i32 %2679, 5, !dbg !1317
  br i1 %2680, label %2681, label %2683, !dbg !1317

2681:                                             ; preds = %2677
  %2682 = load ptr, ptr %74, align 8, !dbg !1317
  br label %2764, !dbg !1317

2683:                                             ; preds = %2677
  %2684 = load i8, ptr %287, align 1, !dbg !1317
  %2685 = zext i8 %2684 to i32, !dbg !1317
  %2686 = icmp eq i32 %2685, 6, !dbg !1317
  br i1 %2686, label %2687, label %2689, !dbg !1317

2687:                                             ; preds = %2683
  %2688 = load ptr, ptr %78, align 8, !dbg !1317
  br label %2762, !dbg !1317

2689:                                             ; preds = %2683
  %2690 = load i8, ptr %287, align 1, !dbg !1317
  %2691 = zext i8 %2690 to i32, !dbg !1317
  %2692 = icmp eq i32 %2691, 7, !dbg !1317
  br i1 %2692, label %2693, label %2695, !dbg !1317

2693:                                             ; preds = %2689
  %2694 = load ptr, ptr %82, align 8, !dbg !1317
  br label %2760, !dbg !1317

2695:                                             ; preds = %2689
  %2696 = load i8, ptr %287, align 1, !dbg !1317
  %2697 = zext i8 %2696 to i32, !dbg !1317
  %2698 = icmp eq i32 %2697, 8, !dbg !1317
  br i1 %2698, label %2699, label %2701, !dbg !1317

2699:                                             ; preds = %2695
  %2700 = load ptr, ptr %86, align 8, !dbg !1317
  br label %2758, !dbg !1317

2701:                                             ; preds = %2695
  %2702 = load i8, ptr %287, align 1, !dbg !1317
  %2703 = zext i8 %2702 to i32, !dbg !1317
  %2704 = icmp eq i32 %2703, 9, !dbg !1317
  br i1 %2704, label %2705, label %2707, !dbg !1317

2705:                                             ; preds = %2701
  %2706 = load ptr, ptr %90, align 8, !dbg !1317
  br label %2756, !dbg !1317

2707:                                             ; preds = %2701
  %2708 = load i8, ptr %287, align 1, !dbg !1317
  %2709 = zext i8 %2708 to i32, !dbg !1317
  %2710 = icmp eq i32 %2709, 10, !dbg !1317
  br i1 %2710, label %2711, label %2713, !dbg !1317

2711:                                             ; preds = %2707
  %2712 = load ptr, ptr %94, align 8, !dbg !1317
  br label %2754, !dbg !1317

2713:                                             ; preds = %2707
  %2714 = load i8, ptr %287, align 1, !dbg !1317
  %2715 = zext i8 %2714 to i32, !dbg !1317
  %2716 = icmp eq i32 %2715, 11, !dbg !1317
  br i1 %2716, label %2717, label %2719, !dbg !1317

2717:                                             ; preds = %2713
  %2718 = load ptr, ptr %98, align 8, !dbg !1317
  br label %2752, !dbg !1317

2719:                                             ; preds = %2713
  %2720 = load i8, ptr %287, align 1, !dbg !1317
  %2721 = zext i8 %2720 to i32, !dbg !1317
  %2722 = icmp eq i32 %2721, 12, !dbg !1317
  br i1 %2722, label %2723, label %2725, !dbg !1317

2723:                                             ; preds = %2719
  %2724 = load ptr, ptr %102, align 8, !dbg !1317
  br label %2750, !dbg !1317

2725:                                             ; preds = %2719
  %2726 = load i8, ptr %287, align 1, !dbg !1317
  %2727 = zext i8 %2726 to i32, !dbg !1317
  %2728 = icmp eq i32 %2727, 13, !dbg !1317
  br i1 %2728, label %2729, label %2731, !dbg !1317

2729:                                             ; preds = %2725
  %2730 = load ptr, ptr %106, align 8, !dbg !1317
  br label %2748, !dbg !1317

2731:                                             ; preds = %2725
  %2732 = load i8, ptr %287, align 1, !dbg !1317
  %2733 = zext i8 %2732 to i32, !dbg !1317
  %2734 = icmp eq i32 %2733, 14, !dbg !1317
  br i1 %2734, label %2735, label %2737, !dbg !1317

2735:                                             ; preds = %2731
  %2736 = load ptr, ptr %110, align 8, !dbg !1317
  br label %2746, !dbg !1317

2737:                                             ; preds = %2731
  %2738 = load i8, ptr %287, align 1, !dbg !1317
  %2739 = zext i8 %2738 to i32, !dbg !1317
  %2740 = icmp eq i32 %2739, 15, !dbg !1317
  br i1 %2740, label %2741, label %2743, !dbg !1317

2741:                                             ; preds = %2737
  %2742 = load ptr, ptr %114, align 8, !dbg !1317
  br label %2744, !dbg !1317

2743:                                             ; preds = %2737
  br label %2744, !dbg !1317

2744:                                             ; preds = %2743, %2741
  %2745 = phi ptr [ %2742, %2741 ], [ null, %2743 ], !dbg !1317
  br label %2746, !dbg !1317

2746:                                             ; preds = %2744, %2735
  %2747 = phi ptr [ %2736, %2735 ], [ %2745, %2744 ], !dbg !1317
  br label %2748, !dbg !1317

2748:                                             ; preds = %2746, %2729
  %2749 = phi ptr [ %2730, %2729 ], [ %2747, %2746 ], !dbg !1317
  br label %2750, !dbg !1317

2750:                                             ; preds = %2748, %2723
  %2751 = phi ptr [ %2724, %2723 ], [ %2749, %2748 ], !dbg !1317
  br label %2752, !dbg !1317

2752:                                             ; preds = %2750, %2717
  %2753 = phi ptr [ %2718, %2717 ], [ %2751, %2750 ], !dbg !1317
  br label %2754, !dbg !1317

2754:                                             ; preds = %2752, %2711
  %2755 = phi ptr [ %2712, %2711 ], [ %2753, %2752 ], !dbg !1317
  br label %2756, !dbg !1317

2756:                                             ; preds = %2754, %2705
  %2757 = phi ptr [ %2706, %2705 ], [ %2755, %2754 ], !dbg !1317
  br label %2758, !dbg !1317

2758:                                             ; preds = %2756, %2699
  %2759 = phi ptr [ %2700, %2699 ], [ %2757, %2756 ], !dbg !1317
  br label %2760, !dbg !1317

2760:                                             ; preds = %2758, %2693
  %2761 = phi ptr [ %2694, %2693 ], [ %2759, %2758 ], !dbg !1317
  br label %2762, !dbg !1317

2762:                                             ; preds = %2760, %2687
  %2763 = phi ptr [ %2688, %2687 ], [ %2761, %2760 ], !dbg !1317
  br label %2764, !dbg !1317

2764:                                             ; preds = %2762, %2681
  %2765 = phi ptr [ %2682, %2681 ], [ %2763, %2762 ], !dbg !1317
  br label %2766, !dbg !1317

2766:                                             ; preds = %2764, %2675
  %2767 = phi ptr [ %2676, %2675 ], [ %2765, %2764 ], !dbg !1317
  br label %2768, !dbg !1317

2768:                                             ; preds = %2766, %2669
  %2769 = phi ptr [ %2670, %2669 ], [ %2767, %2766 ], !dbg !1317
  br label %2770, !dbg !1317

2770:                                             ; preds = %2768, %2663
  %2771 = phi ptr [ %2664, %2663 ], [ %2769, %2768 ], !dbg !1317
  br label %2772, !dbg !1317

2772:                                             ; preds = %2770, %2657
  %2773 = phi ptr [ %2658, %2657 ], [ %2771, %2770 ], !dbg !1317
  br label %2774, !dbg !1317

2774:                                             ; preds = %2772, %2651
  %2775 = phi ptr [ %2652, %2651 ], [ %2773, %2772 ], !dbg !1317
  store ptr %2775, ptr %291, align 8, !dbg !1317
  call void @llvm.dbg.declare(metadata ptr %292, metadata !1325, metadata !DIExpression()), !dbg !1317
  %2776 = load ptr, ptr %291, align 8, !dbg !1317
  %2777 = ptrtoint ptr %2776 to i64, !dbg !1317
  store i64 %2777, ptr %292, align 8, !dbg !1317
  %2778 = load i8, ptr %287, align 1, !dbg !1326
  %2779 = zext i8 %2778 to i32, !dbg !1326
  %2780 = icmp eq i32 %2779, 4, !dbg !1326
  br i1 %2780, label %2781, label %2785, !dbg !1317

2781:                                             ; preds = %2774
  %2782 = load i64, ptr %118, align 8, !dbg !1326
  %2783 = load i64, ptr %292, align 8, !dbg !1326
  %2784 = add i64 %2783, %2782, !dbg !1326
  store i64 %2784, ptr %292, align 8, !dbg !1326
  br label %2842, !dbg !1326

2785:                                             ; preds = %2774
  call void @llvm.dbg.declare(metadata ptr %293, metadata !1328, metadata !DIExpression()), !dbg !1331
  store i8 0, ptr %293, align 1, !dbg !1331
  %2786 = load i8, ptr %287, align 1, !dbg !1331
  %2787 = zext i8 %2786 to i32, !dbg !1331
  switch i32 %2787, label %2820 [
    i32 0, label %2788
    i32 1, label %2790
    i32 2, label %2792
    i32 3, label %2794
    i32 4, label %2796
    i32 5, label %2798
    i32 6, label %2800
    i32 7, label %2802
    i32 8, label %2804
    i32 9, label %2806
    i32 10, label %2808
    i32 11, label %2810
    i32 12, label %2812
    i32 13, label %2814
    i32 14, label %2816
    i32 15, label %2818
  ], !dbg !1331

2788:                                             ; preds = %2785
  %2789 = load i8, ptr %59, align 1, !dbg !1332
  store i8 %2789, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2790:                                             ; preds = %2785
  %2791 = load i8, ptr %63, align 1, !dbg !1332
  store i8 %2791, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2792:                                             ; preds = %2785
  %2793 = load i8, ptr %67, align 1, !dbg !1332
  store i8 %2793, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2794:                                             ; preds = %2785
  %2795 = load i8, ptr %71, align 1, !dbg !1332
  store i8 %2795, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2796:                                             ; preds = %2785
  %2797 = load i8, ptr %73, align 1, !dbg !1332
  store i8 %2797, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2798:                                             ; preds = %2785
  %2799 = load i8, ptr %77, align 1, !dbg !1332
  store i8 %2799, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2800:                                             ; preds = %2785
  %2801 = load i8, ptr %81, align 1, !dbg !1332
  store i8 %2801, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2802:                                             ; preds = %2785
  %2803 = load i8, ptr %85, align 1, !dbg !1332
  store i8 %2803, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2804:                                             ; preds = %2785
  %2805 = load i8, ptr %89, align 1, !dbg !1332
  store i8 %2805, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2806:                                             ; preds = %2785
  %2807 = load i8, ptr %93, align 1, !dbg !1332
  store i8 %2807, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2808:                                             ; preds = %2785
  %2809 = load i8, ptr %97, align 1, !dbg !1332
  store i8 %2809, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2810:                                             ; preds = %2785
  %2811 = load i8, ptr %101, align 1, !dbg !1332
  store i8 %2811, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2812:                                             ; preds = %2785
  %2813 = load i8, ptr %105, align 1, !dbg !1332
  store i8 %2813, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2814:                                             ; preds = %2785
  %2815 = load i8, ptr %109, align 1, !dbg !1332
  store i8 %2815, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2816:                                             ; preds = %2785
  %2817 = load i8, ptr %113, align 1, !dbg !1332
  store i8 %2817, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2818:                                             ; preds = %2785
  %2819 = load i8, ptr %117, align 1, !dbg !1332
  store i8 %2819, ptr %293, align 1, !dbg !1332
  br label %2821, !dbg !1332

2820:                                             ; preds = %2785
  br label %2821, !dbg !1332

2821:                                             ; preds = %2820, %2818, %2816, %2814, %2812, %2810, %2808, %2806, %2804, %2802, %2800, %2798, %2796, %2794, %2792, %2790, %2788
  %2822 = load i8, ptr %293, align 1, !dbg !1331
  store i8 %2822, ptr %294, align 1, !dbg !1332
  %2823 = load i8, ptr %294, align 1, !dbg !1331
  %2824 = zext i8 %2823 to i32, !dbg !1334
  %2825 = icmp eq i32 %2824, 4, !dbg !1334
  br i1 %2825, label %2826, label %2841, !dbg !1326

2826:                                             ; preds = %2821
  call void @llvm.dbg.declare(metadata ptr %295, metadata !1335, metadata !DIExpression()), !dbg !1337
  %2827 = load ptr, ptr %291, align 8, !dbg !1337
  %2828 = ptrtoint ptr %2827 to i64, !dbg !1337
  %2829 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1337
  %2830 = ptrtoint ptr %2829 to i64, !dbg !1337
  %2831 = add i64 %2830, 1, !dbg !1337
  %2832 = inttoptr i64 %2831 to ptr, !dbg !1337
  %2833 = ptrtoint ptr %2832 to i64, !dbg !1337
  %2834 = sub i64 %2828, %2833, !dbg !1337
  store i64 %2834, ptr %295, align 8, !dbg !1337
  %2835 = load i64, ptr %295, align 8, !dbg !1337
  %2836 = call i64 asm sideeffect "", "=r,0"(i64 %2835) #8, !dbg !1337, !srcloc !1338
  store i64 %2836, ptr %295, align 8, !dbg !1337
  %2837 = load i64, ptr %295, align 8, !dbg !1337
  %2838 = load i64, ptr %118, align 8, !dbg !1337
  %2839 = add i64 %2837, %2838, !dbg !1337
  store i64 %2839, ptr %296, align 8, !dbg !1337
  %2840 = load i64, ptr %296, align 8, !dbg !1337
  store i64 %2840, ptr %292, align 8, !dbg !1334
  br label %2841, !dbg !1334

2841:                                             ; preds = %2826, %2821
  br label %2842

2842:                                             ; preds = %2841, %2781
  %2843 = load i64, ptr %292, align 8, !dbg !1317
  %2844 = load i8, ptr %289, align 1, !dbg !1317
  %2845 = zext i8 %2844 to i32, !dbg !1317
  %2846 = icmp eq i32 %2845, 1, !dbg !1317
  br i1 %2846, label %2847, label %2850, !dbg !1317

2847:                                             ; preds = %2842
  %2848 = load i8, ptr %290, align 1, !dbg !1317
  %2849 = zext i8 %2848 to i32, !dbg !1317
  br label %2851, !dbg !1317

2850:                                             ; preds = %2842
  br label %2851, !dbg !1317

2851:                                             ; preds = %2850, %2847
  %2852 = phi i32 [ %2849, %2847 ], [ 0, %2850 ], !dbg !1317
  %2853 = zext i32 %2852 to i64, !dbg !1317
  %2854 = lshr i64 %2843, %2853, !dbg !1317
  %2855 = load i8, ptr %289, align 1, !dbg !1317
  %2856 = zext i8 %2855 to i32, !dbg !1317
  %2857 = icmp eq i32 %2856, 1, !dbg !1317
  br i1 %2857, label %2858, label %2859, !dbg !1317

2858:                                             ; preds = %2851
  br label %2872, !dbg !1317

2859:                                             ; preds = %2851
  %2860 = load i8, ptr %289, align 1, !dbg !1317
  %2861 = zext i8 %2860 to i32, !dbg !1317
  %2862 = icmp eq i32 %2861, 2, !dbg !1317
  br i1 %2862, label %2863, label %2864, !dbg !1317

2863:                                             ; preds = %2859
  br label %2870, !dbg !1317

2864:                                             ; preds = %2859
  %2865 = load i8, ptr %289, align 1, !dbg !1317
  %2866 = zext i8 %2865 to i32, !dbg !1317
  %2867 = icmp eq i32 %2866, 4, !dbg !1317
  %2868 = zext i1 %2867 to i64, !dbg !1317
  %2869 = select i1 %2867, i64 4294967295, i64 -1, !dbg !1317
  br label %2870, !dbg !1317

2870:                                             ; preds = %2864, %2863
  %2871 = phi i64 [ 65535, %2863 ], [ %2869, %2864 ], !dbg !1317
  br label %2872, !dbg !1317

2872:                                             ; preds = %2870, %2858
  %2873 = phi i64 [ 255, %2858 ], [ %2871, %2870 ], !dbg !1317
  %2874 = and i64 %2854, %2873, !dbg !1317
  store i64 %2874, ptr %297, align 8, !dbg !1326
  %2875 = load i64, ptr %297, align 8, !dbg !1317
  %2876 = trunc i64 %2875 to i32, !dbg !1339
  store i32 %2876, ptr %46, align 4, !dbg !1339
  br label %3120, !dbg !1339

2877:                                             ; No predecessors!
  br label %2878, !dbg !1339

2878:                                             ; preds = %2877
  call void @llvm.dbg.label(metadata !1340), !dbg !1341
  br label %2879, !dbg !1342

2879:                                             ; preds = %2878
  call void @llvm.dbg.declare(metadata ptr %298, metadata !1343, metadata !DIExpression()), !dbg !1346
  store i8 0, ptr %298, align 1, !dbg !1346
  call void @llvm.dbg.declare(metadata ptr %299, metadata !1347, metadata !DIExpression()), !dbg !1346
  store i8 8, ptr %299, align 1, !dbg !1346
  call void @llvm.dbg.declare(metadata ptr %300, metadata !1348, metadata !DIExpression()), !dbg !1346
  %2880 = load i8, ptr %299, align 1, !dbg !1346
  store i8 %2880, ptr %11, align 1
  call void @llvm.dbg.declare(metadata ptr %11, metadata !656, metadata !DIExpression()), !dbg !1349
  %2881 = load i8, ptr %11, align 1, !dbg !1351
  %2882 = zext i8 %2881 to i32, !dbg !1351
  %2883 = icmp ne i32 %2882, 0, !dbg !1351
  br i1 %2883, label %2884, label %2887, !dbg !1351

2884:                                             ; preds = %2879
  %2885 = load i8, ptr %11, align 1, !dbg !1351
  %2886 = zext i8 %2885 to i32, !dbg !1351
  br label %2888, !dbg !1351

2887:                                             ; preds = %2879
  br label %2888, !dbg !1351

2888:                                             ; preds = %2884, %2887
  %2889 = phi i32 [ %2886, %2884 ], [ 8, %2887 ], !dbg !1351
  %2890 = trunc i32 %2889 to i8, !dbg !1351
  store i8 %2890, ptr %300, align 1, !dbg !1346
  call void @llvm.dbg.declare(metadata ptr %301, metadata !1352, metadata !DIExpression()), !dbg !1346
  store i8 0, ptr %301, align 1, !dbg !1346
  call void @llvm.dbg.declare(metadata ptr %302, metadata !1353, metadata !DIExpression()), !dbg !1346
  %2891 = load i8, ptr %298, align 1, !dbg !1346
  %2892 = zext i8 %2891 to i32, !dbg !1346
  %2893 = icmp eq i32 %2892, 0, !dbg !1346
  br i1 %2893, label %2894, label %2896, !dbg !1346

2894:                                             ; preds = %2888
  %2895 = load ptr, ptr %56, align 8, !dbg !1346
  br label %3017, !dbg !1346

2896:                                             ; preds = %2888
  %2897 = load i8, ptr %298, align 1, !dbg !1346
  %2898 = zext i8 %2897 to i32, !dbg !1346
  %2899 = icmp eq i32 %2898, 1, !dbg !1346
  br i1 %2899, label %2900, label %2902, !dbg !1346

2900:                                             ; preds = %2896
  %2901 = load ptr, ptr %60, align 8, !dbg !1346
  br label %3015, !dbg !1346

2902:                                             ; preds = %2896
  %2903 = load i8, ptr %298, align 1, !dbg !1346
  %2904 = zext i8 %2903 to i32, !dbg !1346
  %2905 = icmp eq i32 %2904, 2, !dbg !1346
  br i1 %2905, label %2906, label %2908, !dbg !1346

2906:                                             ; preds = %2902
  %2907 = load ptr, ptr %64, align 8, !dbg !1346
  br label %3013, !dbg !1346

2908:                                             ; preds = %2902
  %2909 = load i8, ptr %298, align 1, !dbg !1346
  %2910 = zext i8 %2909 to i32, !dbg !1346
  %2911 = icmp eq i32 %2910, 3, !dbg !1346
  br i1 %2911, label %2912, label %2914, !dbg !1346

2912:                                             ; preds = %2908
  %2913 = load ptr, ptr %68, align 8, !dbg !1346
  br label %3011, !dbg !1346

2914:                                             ; preds = %2908
  %2915 = load i8, ptr %298, align 1, !dbg !1346
  %2916 = zext i8 %2915 to i32, !dbg !1346
  %2917 = icmp eq i32 %2916, 4, !dbg !1346
  br i1 %2917, label %2918, label %2920, !dbg !1346

2918:                                             ; preds = %2914
  %2919 = load ptr, ptr %72, align 8, !dbg !1346
  br label %3009, !dbg !1346

2920:                                             ; preds = %2914
  %2921 = load i8, ptr %298, align 1, !dbg !1346
  %2922 = zext i8 %2921 to i32, !dbg !1346
  %2923 = icmp eq i32 %2922, 5, !dbg !1346
  br i1 %2923, label %2924, label %2926, !dbg !1346

2924:                                             ; preds = %2920
  %2925 = load ptr, ptr %74, align 8, !dbg !1346
  br label %3007, !dbg !1346

2926:                                             ; preds = %2920
  %2927 = load i8, ptr %298, align 1, !dbg !1346
  %2928 = zext i8 %2927 to i32, !dbg !1346
  %2929 = icmp eq i32 %2928, 6, !dbg !1346
  br i1 %2929, label %2930, label %2932, !dbg !1346

2930:                                             ; preds = %2926
  %2931 = load ptr, ptr %78, align 8, !dbg !1346
  br label %3005, !dbg !1346

2932:                                             ; preds = %2926
  %2933 = load i8, ptr %298, align 1, !dbg !1346
  %2934 = zext i8 %2933 to i32, !dbg !1346
  %2935 = icmp eq i32 %2934, 7, !dbg !1346
  br i1 %2935, label %2936, label %2938, !dbg !1346

2936:                                             ; preds = %2932
  %2937 = load ptr, ptr %82, align 8, !dbg !1346
  br label %3003, !dbg !1346

2938:                                             ; preds = %2932
  %2939 = load i8, ptr %298, align 1, !dbg !1346
  %2940 = zext i8 %2939 to i32, !dbg !1346
  %2941 = icmp eq i32 %2940, 8, !dbg !1346
  br i1 %2941, label %2942, label %2944, !dbg !1346

2942:                                             ; preds = %2938
  %2943 = load ptr, ptr %86, align 8, !dbg !1346
  br label %3001, !dbg !1346

2944:                                             ; preds = %2938
  %2945 = load i8, ptr %298, align 1, !dbg !1346
  %2946 = zext i8 %2945 to i32, !dbg !1346
  %2947 = icmp eq i32 %2946, 9, !dbg !1346
  br i1 %2947, label %2948, label %2950, !dbg !1346

2948:                                             ; preds = %2944
  %2949 = load ptr, ptr %90, align 8, !dbg !1346
  br label %2999, !dbg !1346

2950:                                             ; preds = %2944
  %2951 = load i8, ptr %298, align 1, !dbg !1346
  %2952 = zext i8 %2951 to i32, !dbg !1346
  %2953 = icmp eq i32 %2952, 10, !dbg !1346
  br i1 %2953, label %2954, label %2956, !dbg !1346

2954:                                             ; preds = %2950
  %2955 = load ptr, ptr %94, align 8, !dbg !1346
  br label %2997, !dbg !1346

2956:                                             ; preds = %2950
  %2957 = load i8, ptr %298, align 1, !dbg !1346
  %2958 = zext i8 %2957 to i32, !dbg !1346
  %2959 = icmp eq i32 %2958, 11, !dbg !1346
  br i1 %2959, label %2960, label %2962, !dbg !1346

2960:                                             ; preds = %2956
  %2961 = load ptr, ptr %98, align 8, !dbg !1346
  br label %2995, !dbg !1346

2962:                                             ; preds = %2956
  %2963 = load i8, ptr %298, align 1, !dbg !1346
  %2964 = zext i8 %2963 to i32, !dbg !1346
  %2965 = icmp eq i32 %2964, 12, !dbg !1346
  br i1 %2965, label %2966, label %2968, !dbg !1346

2966:                                             ; preds = %2962
  %2967 = load ptr, ptr %102, align 8, !dbg !1346
  br label %2993, !dbg !1346

2968:                                             ; preds = %2962
  %2969 = load i8, ptr %298, align 1, !dbg !1346
  %2970 = zext i8 %2969 to i32, !dbg !1346
  %2971 = icmp eq i32 %2970, 13, !dbg !1346
  br i1 %2971, label %2972, label %2974, !dbg !1346

2972:                                             ; preds = %2968
  %2973 = load ptr, ptr %106, align 8, !dbg !1346
  br label %2991, !dbg !1346

2974:                                             ; preds = %2968
  %2975 = load i8, ptr %298, align 1, !dbg !1346
  %2976 = zext i8 %2975 to i32, !dbg !1346
  %2977 = icmp eq i32 %2976, 14, !dbg !1346
  br i1 %2977, label %2978, label %2980, !dbg !1346

2978:                                             ; preds = %2974
  %2979 = load ptr, ptr %110, align 8, !dbg !1346
  br label %2989, !dbg !1346

2980:                                             ; preds = %2974
  %2981 = load i8, ptr %298, align 1, !dbg !1346
  %2982 = zext i8 %2981 to i32, !dbg !1346
  %2983 = icmp eq i32 %2982, 15, !dbg !1346
  br i1 %2983, label %2984, label %2986, !dbg !1346

2984:                                             ; preds = %2980
  %2985 = load ptr, ptr %114, align 8, !dbg !1346
  br label %2987, !dbg !1346

2986:                                             ; preds = %2980
  br label %2987, !dbg !1346

2987:                                             ; preds = %2986, %2984
  %2988 = phi ptr [ %2985, %2984 ], [ null, %2986 ], !dbg !1346
  br label %2989, !dbg !1346

2989:                                             ; preds = %2987, %2978
  %2990 = phi ptr [ %2979, %2978 ], [ %2988, %2987 ], !dbg !1346
  br label %2991, !dbg !1346

2991:                                             ; preds = %2989, %2972
  %2992 = phi ptr [ %2973, %2972 ], [ %2990, %2989 ], !dbg !1346
  br label %2993, !dbg !1346

2993:                                             ; preds = %2991, %2966
  %2994 = phi ptr [ %2967, %2966 ], [ %2992, %2991 ], !dbg !1346
  br label %2995, !dbg !1346

2995:                                             ; preds = %2993, %2960
  %2996 = phi ptr [ %2961, %2960 ], [ %2994, %2993 ], !dbg !1346
  br label %2997, !dbg !1346

2997:                                             ; preds = %2995, %2954
  %2998 = phi ptr [ %2955, %2954 ], [ %2996, %2995 ], !dbg !1346
  br label %2999, !dbg !1346

2999:                                             ; preds = %2997, %2948
  %3000 = phi ptr [ %2949, %2948 ], [ %2998, %2997 ], !dbg !1346
  br label %3001, !dbg !1346

3001:                                             ; preds = %2999, %2942
  %3002 = phi ptr [ %2943, %2942 ], [ %3000, %2999 ], !dbg !1346
  br label %3003, !dbg !1346

3003:                                             ; preds = %3001, %2936
  %3004 = phi ptr [ %2937, %2936 ], [ %3002, %3001 ], !dbg !1346
  br label %3005, !dbg !1346

3005:                                             ; preds = %3003, %2930
  %3006 = phi ptr [ %2931, %2930 ], [ %3004, %3003 ], !dbg !1346
  br label %3007, !dbg !1346

3007:                                             ; preds = %3005, %2924
  %3008 = phi ptr [ %2925, %2924 ], [ %3006, %3005 ], !dbg !1346
  br label %3009, !dbg !1346

3009:                                             ; preds = %3007, %2918
  %3010 = phi ptr [ %2919, %2918 ], [ %3008, %3007 ], !dbg !1346
  br label %3011, !dbg !1346

3011:                                             ; preds = %3009, %2912
  %3012 = phi ptr [ %2913, %2912 ], [ %3010, %3009 ], !dbg !1346
  br label %3013, !dbg !1346

3013:                                             ; preds = %3011, %2906
  %3014 = phi ptr [ %2907, %2906 ], [ %3012, %3011 ], !dbg !1346
  br label %3015, !dbg !1346

3015:                                             ; preds = %3013, %2900
  %3016 = phi ptr [ %2901, %2900 ], [ %3014, %3013 ], !dbg !1346
  br label %3017, !dbg !1346

3017:                                             ; preds = %3015, %2894
  %3018 = phi ptr [ %2895, %2894 ], [ %3016, %3015 ], !dbg !1346
  store ptr %3018, ptr %302, align 8, !dbg !1346
  call void @llvm.dbg.declare(metadata ptr %303, metadata !1354, metadata !DIExpression()), !dbg !1346
  %3019 = load ptr, ptr %302, align 8, !dbg !1346
  %3020 = ptrtoint ptr %3019 to i64, !dbg !1346
  store i64 %3020, ptr %303, align 8, !dbg !1346
  %3021 = load i8, ptr %298, align 1, !dbg !1355
  %3022 = zext i8 %3021 to i32, !dbg !1355
  %3023 = icmp eq i32 %3022, 4, !dbg !1355
  br i1 %3023, label %3024, label %3028, !dbg !1346

3024:                                             ; preds = %3017
  %3025 = load i64, ptr %118, align 8, !dbg !1355
  %3026 = load i64, ptr %303, align 8, !dbg !1355
  %3027 = add i64 %3026, %3025, !dbg !1355
  store i64 %3027, ptr %303, align 8, !dbg !1355
  br label %3085, !dbg !1355

3028:                                             ; preds = %3017
  call void @llvm.dbg.declare(metadata ptr %304, metadata !1357, metadata !DIExpression()), !dbg !1360
  store i8 0, ptr %304, align 1, !dbg !1360
  %3029 = load i8, ptr %298, align 1, !dbg !1360
  %3030 = zext i8 %3029 to i32, !dbg !1360
  switch i32 %3030, label %3063 [
    i32 0, label %3031
    i32 1, label %3033
    i32 2, label %3035
    i32 3, label %3037
    i32 4, label %3039
    i32 5, label %3041
    i32 6, label %3043
    i32 7, label %3045
    i32 8, label %3047
    i32 9, label %3049
    i32 10, label %3051
    i32 11, label %3053
    i32 12, label %3055
    i32 13, label %3057
    i32 14, label %3059
    i32 15, label %3061
  ], !dbg !1360

3031:                                             ; preds = %3028
  %3032 = load i8, ptr %59, align 1, !dbg !1361
  store i8 %3032, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3033:                                             ; preds = %3028
  %3034 = load i8, ptr %63, align 1, !dbg !1361
  store i8 %3034, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3035:                                             ; preds = %3028
  %3036 = load i8, ptr %67, align 1, !dbg !1361
  store i8 %3036, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3037:                                             ; preds = %3028
  %3038 = load i8, ptr %71, align 1, !dbg !1361
  store i8 %3038, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3039:                                             ; preds = %3028
  %3040 = load i8, ptr %73, align 1, !dbg !1361
  store i8 %3040, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3041:                                             ; preds = %3028
  %3042 = load i8, ptr %77, align 1, !dbg !1361
  store i8 %3042, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3043:                                             ; preds = %3028
  %3044 = load i8, ptr %81, align 1, !dbg !1361
  store i8 %3044, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3045:                                             ; preds = %3028
  %3046 = load i8, ptr %85, align 1, !dbg !1361
  store i8 %3046, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3047:                                             ; preds = %3028
  %3048 = load i8, ptr %89, align 1, !dbg !1361
  store i8 %3048, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3049:                                             ; preds = %3028
  %3050 = load i8, ptr %93, align 1, !dbg !1361
  store i8 %3050, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3051:                                             ; preds = %3028
  %3052 = load i8, ptr %97, align 1, !dbg !1361
  store i8 %3052, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3053:                                             ; preds = %3028
  %3054 = load i8, ptr %101, align 1, !dbg !1361
  store i8 %3054, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3055:                                             ; preds = %3028
  %3056 = load i8, ptr %105, align 1, !dbg !1361
  store i8 %3056, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3057:                                             ; preds = %3028
  %3058 = load i8, ptr %109, align 1, !dbg !1361
  store i8 %3058, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3059:                                             ; preds = %3028
  %3060 = load i8, ptr %113, align 1, !dbg !1361
  store i8 %3060, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3061:                                             ; preds = %3028
  %3062 = load i8, ptr %117, align 1, !dbg !1361
  store i8 %3062, ptr %304, align 1, !dbg !1361
  br label %3064, !dbg !1361

3063:                                             ; preds = %3028
  br label %3064, !dbg !1361

3064:                                             ; preds = %3063, %3061, %3059, %3057, %3055, %3053, %3051, %3049, %3047, %3045, %3043, %3041, %3039, %3037, %3035, %3033, %3031
  %3065 = load i8, ptr %304, align 1, !dbg !1360
  store i8 %3065, ptr %305, align 1, !dbg !1361
  %3066 = load i8, ptr %305, align 1, !dbg !1360
  %3067 = zext i8 %3066 to i32, !dbg !1363
  %3068 = icmp eq i32 %3067, 4, !dbg !1363
  br i1 %3068, label %3069, label %3084, !dbg !1355

3069:                                             ; preds = %3064
  call void @llvm.dbg.declare(metadata ptr %306, metadata !1364, metadata !DIExpression()), !dbg !1366
  %3070 = load ptr, ptr %302, align 8, !dbg !1366
  %3071 = ptrtoint ptr %3070 to i64, !dbg !1366
  %3072 = getelementptr inbounds [1 x i8], ptr %144, i64 0, i64 0, !dbg !1366
  %3073 = ptrtoint ptr %3072 to i64, !dbg !1366
  %3074 = add i64 %3073, 1, !dbg !1366
  %3075 = inttoptr i64 %3074 to ptr, !dbg !1366
  %3076 = ptrtoint ptr %3075 to i64, !dbg !1366
  %3077 = sub i64 %3071, %3076, !dbg !1366
  store i64 %3077, ptr %306, align 8, !dbg !1366
  %3078 = load i64, ptr %306, align 8, !dbg !1366
  %3079 = call i64 asm sideeffect "", "=r,0"(i64 %3078) #8, !dbg !1366, !srcloc !1367
  store i64 %3079, ptr %306, align 8, !dbg !1366
  %3080 = load i64, ptr %306, align 8, !dbg !1366
  %3081 = load i64, ptr %118, align 8, !dbg !1366
  %3082 = add i64 %3080, %3081, !dbg !1366
  store i64 %3082, ptr %307, align 8, !dbg !1366
  %3083 = load i64, ptr %307, align 8, !dbg !1366
  store i64 %3083, ptr %303, align 8, !dbg !1363
  br label %3084, !dbg !1363

3084:                                             ; preds = %3069, %3064
  br label %3085

3085:                                             ; preds = %3084, %3024
  %3086 = load i64, ptr %303, align 8, !dbg !1346
  %3087 = load i8, ptr %300, align 1, !dbg !1346
  %3088 = zext i8 %3087 to i32, !dbg !1346
  %3089 = icmp eq i32 %3088, 1, !dbg !1346
  br i1 %3089, label %3090, label %3093, !dbg !1346

3090:                                             ; preds = %3085
  %3091 = load i8, ptr %301, align 1, !dbg !1346
  %3092 = zext i8 %3091 to i32, !dbg !1346
  br label %3094, !dbg !1346

3093:                                             ; preds = %3085
  br label %3094, !dbg !1346

3094:                                             ; preds = %3093, %3090
  %3095 = phi i32 [ %3092, %3090 ], [ 0, %3093 ], !dbg !1346
  %3096 = zext i32 %3095 to i64, !dbg !1346
  %3097 = lshr i64 %3086, %3096, !dbg !1346
  %3098 = load i8, ptr %300, align 1, !dbg !1346
  %3099 = zext i8 %3098 to i32, !dbg !1346
  %3100 = icmp eq i32 %3099, 1, !dbg !1346
  br i1 %3100, label %3101, label %3102, !dbg !1346

3101:                                             ; preds = %3094
  br label %3115, !dbg !1346

3102:                                             ; preds = %3094
  %3103 = load i8, ptr %300, align 1, !dbg !1346
  %3104 = zext i8 %3103 to i32, !dbg !1346
  %3105 = icmp eq i32 %3104, 2, !dbg !1346
  br i1 %3105, label %3106, label %3107, !dbg !1346

3106:                                             ; preds = %3102
  br label %3113, !dbg !1346

3107:                                             ; preds = %3102
  %3108 = load i8, ptr %300, align 1, !dbg !1346
  %3109 = zext i8 %3108 to i32, !dbg !1346
  %3110 = icmp eq i32 %3109, 4, !dbg !1346
  %3111 = zext i1 %3110 to i64, !dbg !1346
  %3112 = select i1 %3110, i64 4294967295, i64 -1, !dbg !1346
  br label %3113, !dbg !1346

3113:                                             ; preds = %3107, %3106
  %3114 = phi i64 [ 65535, %3106 ], [ %3112, %3107 ], !dbg !1346
  br label %3115, !dbg !1346

3115:                                             ; preds = %3113, %3101
  %3116 = phi i64 [ 255, %3101 ], [ %3114, %3113 ], !dbg !1346
  %3117 = and i64 %3097, %3116, !dbg !1346
  store i64 %3117, ptr %308, align 8, !dbg !1355
  %3118 = load i64, ptr %308, align 8, !dbg !1346
  %3119 = trunc i64 %3118 to i32, !dbg !1368
  store i32 %3119, ptr %46, align 4, !dbg !1368
  br label %3120, !dbg !1368

3120:                                             ; preds = %2872, %3115
  %3121 = load i32, ptr %46, align 4, !dbg !1369
  ret i32 %3121, !dbg !1369
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #1

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i64(i64) #3

declare dso_local void @x86_sim_unmapped_xdp_read() #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

declare dso_local void @kprog_x86_fixed_displacement_required() #6

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #7

attributes #0 = { noinline nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="v4" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { "dontcall-error"="unmapped native XDP context read" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="v4" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { "dontcall-error"="x86 fixed load requires a constant signed16 displacement" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="v4" }
attributes #7 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #8 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!129, !130, !131, !132}
!llvm.ident = !{!133}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !126, line: 21, type: !127, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !125, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "aa0a81fd15e76983e5e2b451ce29f641")
!4 = !{!5, !114, !57, !10, !115, !84, !117, !118, !119, !120, !52, !123}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__sk_buff", file: !7, line: 6347, size: 1536, elements: !8)
!7 = !DIFile(filename: "vendor/libbpf/include/uapi/linux/bpf.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "af3577c2b1c2566ad76f1bd2c69dbe37")
!8 = !{!9, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24, !28, !29, !30, !31, !32, !33, !34, !35, !36, !40, !41, !42, !43, !44, !83, !86, !87, !88, !111, !112, !113}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !6, file: !7, line: 6348, baseType: !10, size: 32)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !11, line: 27, baseType: !12)
!11 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "", checksumkind: CSK_MD5, checksum: "b810f270733e106319b67ef512c6246e")
!12 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "pkt_type", scope: !6, file: !7, line: 6349, baseType: !10, size: 32, offset: 32)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !6, file: !7, line: 6350, baseType: !10, size: 32, offset: 64)
!15 = !DIDerivedType(tag: DW_TAG_member, name: "queue_mapping", scope: !6, file: !7, line: 6351, baseType: !10, size: 32, offset: 96)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !6, file: !7, line: 6352, baseType: !10, size: 32, offset: 128)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_present", scope: !6, file: !7, line: 6353, baseType: !10, size: 32, offset: 160)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_tci", scope: !6, file: !7, line: 6354, baseType: !10, size: 32, offset: 192)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_proto", scope: !6, file: !7, line: 6355, baseType: !10, size: 32, offset: 224)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !6, file: !7, line: 6356, baseType: !10, size: 32, offset: 256)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !6, file: !7, line: 6357, baseType: !10, size: 32, offset: 288)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !6, file: !7, line: 6358, baseType: !10, size: 32, offset: 320)
!23 = !DIDerivedType(tag: DW_TAG_member, name: "tc_index", scope: !6, file: !7, line: 6359, baseType: !10, size: 32, offset: 352)
!24 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !6, file: !7, line: 6360, baseType: !25, size: 160, offset: 384)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 160, elements: !26)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "hash", scope: !6, file: !7, line: 6361, baseType: !10, size: 32, offset: 544)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "tc_classid", scope: !6, file: !7, line: 6362, baseType: !10, size: 32, offset: 576)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !6, file: !7, line: 6363, baseType: !10, size: 32, offset: 608)
!31 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !6, file: !7, line: 6364, baseType: !10, size: 32, offset: 640)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !6, file: !7, line: 6365, baseType: !10, size: 32, offset: 672)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !6, file: !7, line: 6368, baseType: !10, size: 32, offset: 704)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip4", scope: !6, file: !7, line: 6369, baseType: !10, size: 32, offset: 736)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip4", scope: !6, file: !7, line: 6370, baseType: !10, size: 32, offset: 768)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip6", scope: !6, file: !7, line: 6371, baseType: !37, size: 128, offset: 800)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 128, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 4)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip6", scope: !6, file: !7, line: 6372, baseType: !37, size: 128, offset: 928)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "remote_port", scope: !6, file: !7, line: 6373, baseType: !10, size: 32, offset: 1056)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "local_port", scope: !6, file: !7, line: 6374, baseType: !10, size: 32, offset: 1088)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !6, file: !7, line: 6377, baseType: !10, size: 32, offset: 1120)
!44 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6378, baseType: !45, size: 64, align: 64, offset: 1152)
!45 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6378, size: 64, align: 64, elements: !46)
!46 = !{!47}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "flow_keys", scope: !45, file: !7, line: 6378, baseType: !48, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_flow_keys", file: !7, line: 7436, size: 448, elements: !50)
!50 = !{!51, !54, !55, !56, !59, !60, !61, !62, !65, !66, !67, !81, !82}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "nhoff", scope: !49, file: !7, line: 7437, baseType: !52, size: 16)
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !11, line: 24, baseType: !53)
!53 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "thoff", scope: !49, file: !7, line: 7438, baseType: !52, size: 16, offset: 16)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "addr_proto", scope: !49, file: !7, line: 7439, baseType: !52, size: 16, offset: 32)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "is_frag", scope: !49, file: !7, line: 7440, baseType: !57, size: 8, offset: 48)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !11, line: 21, baseType: !58)
!58 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "is_first_frag", scope: !49, file: !7, line: 7441, baseType: !57, size: 8, offset: 56)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "is_encap", scope: !49, file: !7, line: 7442, baseType: !57, size: 8, offset: 64)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "ip_proto", scope: !49, file: !7, line: 7443, baseType: !57, size: 8, offset: 72)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "n_proto", scope: !49, file: !7, line: 7444, baseType: !63, size: 16, offset: 80)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !64, line: 32, baseType: !52)
!64 = !DIFile(filename: "/usr/include/linux/types.h", directory: "", checksumkind: CSK_MD5, checksum: "bf9fbc0e8f60927fef9d8917535375a6")
!65 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !49, file: !7, line: 7445, baseType: !63, size: 16, offset: 96)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !49, file: !7, line: 7446, baseType: !63, size: 16, offset: 112)
!67 = !DIDerivedType(tag: DW_TAG_member, scope: !49, file: !7, line: 7447, baseType: !68, size: 256, offset: 128)
!68 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !49, file: !7, line: 7447, size: 256, elements: !69)
!69 = !{!70, !76}
!70 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7448, baseType: !71, size: 64)
!71 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7448, size: 64, elements: !72)
!72 = !{!73, !75}
!73 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !71, file: !7, line: 7449, baseType: !74, size: 32)
!74 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !64, line: 34, baseType: !10)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !71, file: !7, line: 7450, baseType: !74, size: 32, offset: 32)
!76 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7452, baseType: !77, size: 256)
!77 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7452, size: 256, elements: !78)
!78 = !{!79, !80}
!79 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !77, file: !7, line: 7453, baseType: !37, size: 128)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !77, file: !7, line: 7454, baseType: !37, size: 128, offset: 128)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !49, file: !7, line: 7457, baseType: !10, size: 32, offset: 384)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "flow_label", scope: !49, file: !7, line: 7458, baseType: !74, size: 32, offset: 416)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp", scope: !6, file: !7, line: 6379, baseType: !84, size: 64, offset: 1216)
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !11, line: 31, baseType: !85)
!85 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "wire_len", scope: !6, file: !7, line: 6380, baseType: !10, size: 32, offset: 1280)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "gso_segs", scope: !6, file: !7, line: 6381, baseType: !10, size: 32, offset: 1312)
!88 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6382, baseType: !89, size: 64, align: 64, offset: 1344)
!89 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6382, size: 64, align: 64, elements: !90)
!90 = !{!91}
!91 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !89, file: !7, line: 6382, baseType: !92, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !93, size: 64)
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !7, line: 6451, size: 640, elements: !94)
!94 = !{!95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !93, file: !7, line: 6452, baseType: !10, size: 32)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !93, file: !7, line: 6453, baseType: !10, size: 32, offset: 32)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !93, file: !7, line: 6454, baseType: !10, size: 32, offset: 64)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !93, file: !7, line: 6455, baseType: !10, size: 32, offset: 96)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !93, file: !7, line: 6456, baseType: !10, size: 32, offset: 128)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !93, file: !7, line: 6457, baseType: !10, size: 32, offset: 160)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !93, file: !7, line: 6459, baseType: !10, size: 32, offset: 192)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !93, file: !7, line: 6460, baseType: !37, size: 128, offset: 224)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !93, file: !7, line: 6461, baseType: !10, size: 32, offset: 352)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !93, file: !7, line: 6462, baseType: !63, size: 16, offset: 384)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !93, file: !7, line: 6464, baseType: !10, size: 32, offset: 416)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !93, file: !7, line: 6465, baseType: !37, size: 128, offset: 448)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !93, file: !7, line: 6466, baseType: !10, size: 32, offset: 576)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !93, file: !7, line: 6467, baseType: !109, size: 32, offset: 608)
!109 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !11, line: 26, baseType: !110)
!110 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "gso_size", scope: !6, file: !7, line: 6383, baseType: !10, size: 32, offset: 1408)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp_type", scope: !6, file: !7, line: 6384, baseType: !57, size: 8, offset: 1440)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "hwtstamp", scope: !6, file: !7, line: 6386, baseType: !84, size: 64, offset: 1472)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!115 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s64", file: !11, line: 30, baseType: !116)
!116 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!117 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!118 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!119 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!120 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !121, size: 64)
!121 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !122)
!122 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !57)
!123 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !124, size: 64)
!124 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !114)
!125 = !{!0}
!126 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/request-16.analysis.c", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "aa0a81fd15e76983e5e2b451ce29f641")
!127 = !DICompositeType(tag: DW_TAG_array_type, baseType: !128, size: 32, elements: !38)
!128 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!129 = !{i32 7, !"Dwarf Version", i32 5}
!130 = !{i32 2, !"Debug Info Version", i32 3}
!131 = !{i32 1, !"wchar_size", i32 4}
!132 = !{i32 7, !"frame-pointer", i32 2}
!133 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!134 = distinct !DISubprogram(name: "trusted_x86_x86_sim_xdp", scope: !126, file: !126, line: 7, type: !135, scopeLine: 8, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !146)
!135 = !DISubroutineType(types: !136)
!136 = !{!110, !137}
!137 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !138, size: 64)
!138 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !7, line: 6567, size: 192, elements: !139)
!139 = !{!140, !141, !142, !143, !144, !145}
!140 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !138, file: !7, line: 6568, baseType: !10, size: 32)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !138, file: !7, line: 6569, baseType: !10, size: 32, offset: 32)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !138, file: !7, line: 6570, baseType: !10, size: 32, offset: 64)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !138, file: !7, line: 6572, baseType: !10, size: 32, offset: 96)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !138, file: !7, line: 6573, baseType: !10, size: 32, offset: 128)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !138, file: !7, line: 6575, baseType: !10, size: 32, offset: 160)
!146 = !{}
!147 = !DILocalVariable(name: "ctx", arg: 1, scope: !134, file: !126, line: 7, type: !137)
!148 = !DILocation(line: 7, column: 44, scope: !134)
!149 = !DILocalVariable(name: "__x86_sim_abi", scope: !134, file: !126, line: 9, type: !150)
!150 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_xdp_abi", file: !151, line: 64, size: 320, elements: !152)
!151 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim_local_bpf.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "cdf042bef0d13fcc12d092b7f12f07bf")
!152 = !{!153, !154, !155}
!153 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !150, file: !151, line: 65, baseType: !114, size: 64)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !150, file: !151, line: 66, baseType: !114, size: 64, offset: 64)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !150, file: !151, line: 67, baseType: !25, size: 160, offset: 128)
!156 = !DILocation(line: 9, column: 2, scope: !134)
!157 = !DILocalVariable(name: "__x86_sim_skb_ctx", scope: !134, file: !126, line: 9, type: !5)
!158 = !DILocalVariable(name: "__x86_sim_abi_kind", scope: !134, file: !126, line: 9, type: !57)
!159 = !DILocalVariable(name: "__x86_stack_value_tag_0", scope: !134, file: !126, line: 9, type: !57)
!160 = !DILocalVariable(name: "__x86_stack_value_ptr_0", scope: !134, file: !126, line: 9, type: !114)
!161 = !DILocalVariable(name: "__x86_sim_is_xdp", scope: !134, file: !126, line: 9, type: !57)
!162 = !DILocalVariable(name: "__x86_sim_helper_ctx", scope: !134, file: !126, line: 9, type: !114)
!163 = !DILocalVariable(name: "__x86_sim_helper_abi_base", scope: !134, file: !126, line: 9, type: !114)
!164 = !DILocalVariable(name: "__x86_rax", scope: !134, file: !126, line: 9, type: !165)
!165 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_gpr", file: !151, line: 90, size: 64, elements: !166)
!166 = !{!167, !168, !169}
!167 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !165, file: !151, line: 91, baseType: !114, size: 64)
!168 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !165, file: !151, line: 92, baseType: !52, size: 16)
!169 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !165, file: !151, line: 93, baseType: !170, size: 64)
!170 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 64, elements: !171)
!171 = !{!172}
!172 = !DISubrange(count: 8)
!173 = !DILocalVariable(name: "__native_value", scope: !174, file: !126, line: 9, type: !118)
!174 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!175 = !DILocation(line: 9, column: 2, scope: !174)
!176 = !{i64 2148856434}
!177 = !DILocalVariable(name: "__x86_rax_tag", scope: !134, file: !126, line: 9, type: !57)
!178 = !DILocalVariable(name: "__x86_rcx", scope: !134, file: !126, line: 9, type: !165)
!179 = !DILocalVariable(name: "__native_value", scope: !180, file: !126, line: 9, type: !118)
!180 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!181 = !DILocation(line: 9, column: 2, scope: !180)
!182 = !{i64 2148856902}
!183 = !DILocalVariable(name: "__x86_rcx_tag", scope: !134, file: !126, line: 9, type: !57)
!184 = !DILocalVariable(name: "__x86_rdx", scope: !134, file: !126, line: 9, type: !165)
!185 = !DILocalVariable(name: "__native_value", scope: !186, file: !126, line: 9, type: !118)
!186 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!187 = !DILocation(line: 9, column: 2, scope: !186)
!188 = !{i64 2148857370}
!189 = !DILocalVariable(name: "__x86_rdx_tag", scope: !134, file: !126, line: 9, type: !57)
!190 = !DILocalVariable(name: "__x86_rbx", scope: !134, file: !126, line: 9, type: !165)
!191 = !DILocalVariable(name: "__native_value", scope: !192, file: !126, line: 9, type: !118)
!192 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!193 = !DILocation(line: 9, column: 2, scope: !192)
!194 = !{i64 2148857838}
!195 = !DILocalVariable(name: "__x86_rbx_tag", scope: !134, file: !126, line: 9, type: !57)
!196 = !DILocalVariable(name: "__x86_rsp", scope: !134, file: !126, line: 9, type: !165)
!197 = !DILocalVariable(name: "__x86_rsp_tag", scope: !134, file: !126, line: 9, type: !57)
!198 = !DILocalVariable(name: "__x86_rbp", scope: !134, file: !126, line: 9, type: !165)
!199 = !DILocalVariable(name: "__native_value", scope: !200, file: !126, line: 9, type: !118)
!200 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!201 = !DILocation(line: 9, column: 2, scope: !200)
!202 = !{i64 2148858774}
!203 = !DILocalVariable(name: "__x86_rbp_tag", scope: !134, file: !126, line: 9, type: !57)
!204 = !DILocalVariable(name: "__x86_rsi", scope: !134, file: !126, line: 9, type: !165)
!205 = !DILocalVariable(name: "__native_value", scope: !206, file: !126, line: 9, type: !118)
!206 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!207 = !DILocation(line: 9, column: 2, scope: !206)
!208 = !{i64 2148859242}
!209 = !DILocalVariable(name: "__x86_rsi_tag", scope: !134, file: !126, line: 9, type: !57)
!210 = !DILocalVariable(name: "__x86_rdi", scope: !134, file: !126, line: 9, type: !165)
!211 = !DILocalVariable(name: "__native_value", scope: !212, file: !126, line: 9, type: !118)
!212 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!213 = !DILocation(line: 9, column: 2, scope: !212)
!214 = !{i64 2148859710}
!215 = !DILocalVariable(name: "__x86_rdi_tag", scope: !134, file: !126, line: 9, type: !57)
!216 = !DILocalVariable(name: "__x86_r8", scope: !134, file: !126, line: 9, type: !165)
!217 = !DILocalVariable(name: "__native_value", scope: !218, file: !126, line: 9, type: !118)
!218 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!219 = !DILocation(line: 9, column: 2, scope: !218)
!220 = !{i64 2148860175}
!221 = !DILocalVariable(name: "__x86_r8_tag", scope: !134, file: !126, line: 9, type: !57)
!222 = !DILocalVariable(name: "__x86_r9", scope: !134, file: !126, line: 9, type: !165)
!223 = !DILocalVariable(name: "__native_value", scope: !224, file: !126, line: 9, type: !118)
!224 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!225 = !DILocation(line: 9, column: 2, scope: !224)
!226 = !{i64 2148860639}
!227 = !DILocalVariable(name: "__x86_r9_tag", scope: !134, file: !126, line: 9, type: !57)
!228 = !DILocalVariable(name: "__x86_r10", scope: !134, file: !126, line: 9, type: !165)
!229 = !DILocalVariable(name: "__native_value", scope: !230, file: !126, line: 9, type: !118)
!230 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!231 = !DILocation(line: 9, column: 2, scope: !230)
!232 = !{i64 2148861108}
!233 = !DILocalVariable(name: "__x86_r10_tag", scope: !134, file: !126, line: 9, type: !57)
!234 = !DILocalVariable(name: "__x86_r11", scope: !134, file: !126, line: 9, type: !165)
!235 = !DILocalVariable(name: "__native_value", scope: !236, file: !126, line: 9, type: !118)
!236 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!237 = !DILocation(line: 9, column: 2, scope: !236)
!238 = !{i64 2148861578}
!239 = !DILocalVariable(name: "__x86_r11_tag", scope: !134, file: !126, line: 9, type: !57)
!240 = !DILocalVariable(name: "__x86_r12", scope: !134, file: !126, line: 9, type: !165)
!241 = !DILocalVariable(name: "__native_value", scope: !242, file: !126, line: 9, type: !118)
!242 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!243 = !DILocation(line: 9, column: 2, scope: !242)
!244 = !{i64 2148862048}
!245 = !DILocalVariable(name: "__x86_r12_tag", scope: !134, file: !126, line: 9, type: !57)
!246 = !DILocalVariable(name: "__x86_r13", scope: !134, file: !126, line: 9, type: !165)
!247 = !DILocalVariable(name: "__native_value", scope: !248, file: !126, line: 9, type: !118)
!248 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!249 = !DILocation(line: 9, column: 2, scope: !248)
!250 = !{i64 2148862518}
!251 = !DILocalVariable(name: "__x86_r13_tag", scope: !134, file: !126, line: 9, type: !57)
!252 = !DILocalVariable(name: "__x86_r14", scope: !134, file: !126, line: 9, type: !165)
!253 = !DILocalVariable(name: "__native_value", scope: !254, file: !126, line: 9, type: !118)
!254 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!255 = !DILocation(line: 9, column: 2, scope: !254)
!256 = !{i64 2148862988}
!257 = !DILocalVariable(name: "__x86_r14_tag", scope: !134, file: !126, line: 9, type: !57)
!258 = !DILocalVariable(name: "__x86_r15", scope: !134, file: !126, line: 9, type: !165)
!259 = !DILocalVariable(name: "__native_value", scope: !260, file: !126, line: 9, type: !118)
!260 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!261 = !DILocation(line: 9, column: 2, scope: !260)
!262 = !{i64 2148863458}
!263 = !DILocalVariable(name: "__x86_r15_tag", scope: !134, file: !126, line: 9, type: !57)
!264 = !DILocalVariable(name: "__x86_native_stack_base", scope: !134, file: !126, line: 9, type: !84)
!265 = !DILocalVariable(name: "__x86_cf", scope: !134, file: !126, line: 9, type: !57)
!266 = !DILocalVariable(name: "__native_value", scope: !267, file: !126, line: 9, type: !118)
!267 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!268 = !DILocation(line: 9, column: 2, scope: !267)
!269 = !{i64 2148863729}
!270 = !DILocalVariable(name: "__x86_zf", scope: !134, file: !126, line: 9, type: !57)
!271 = !DILocalVariable(name: "__native_value", scope: !272, file: !126, line: 9, type: !118)
!272 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!273 = !DILocation(line: 9, column: 2, scope: !272)
!274 = !{i64 2148863983}
!275 = !DILocalVariable(name: "__x86_sf", scope: !134, file: !126, line: 9, type: !57)
!276 = !DILocalVariable(name: "__native_value", scope: !277, file: !126, line: 9, type: !118)
!277 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!278 = !DILocation(line: 9, column: 2, scope: !277)
!279 = !{i64 2148864237}
!280 = !DILocalVariable(name: "__x86_of", scope: !134, file: !126, line: 9, type: !57)
!281 = !DILocalVariable(name: "__native_value", scope: !282, file: !126, line: 9, type: !118)
!282 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!283 = !DILocation(line: 9, column: 2, scope: !282)
!284 = !{i64 2148864491}
!285 = !DILocalVariable(name: "__x86_pf", scope: !134, file: !126, line: 9, type: !57)
!286 = !DILocalVariable(name: "__native_value", scope: !287, file: !126, line: 9, type: !118)
!287 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!288 = !DILocation(line: 9, column: 2, scope: !287)
!289 = !{i64 2148864745}
!290 = !DILocalVariable(name: "__x86_af", scope: !134, file: !126, line: 9, type: !57)
!291 = !DILocalVariable(name: "__native_value", scope: !292, file: !126, line: 9, type: !118)
!292 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!293 = !DILocation(line: 9, column: 2, scope: !292)
!294 = !{i64 2148864999}
!295 = !DILocalVariable(name: "__x86_xmm0_lo", scope: !134, file: !126, line: 9, type: !84)
!296 = !DILocalVariable(name: "__native_value", scope: !297, file: !126, line: 9, type: !118)
!297 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!298 = !DILocation(line: 9, column: 2, scope: !297)
!299 = !{i64 2148865253}
!300 = !DILocalVariable(name: "__x86_xmm0_hi", scope: !134, file: !126, line: 9, type: !84)
!301 = !DILocalVariable(name: "__native_value", scope: !302, file: !126, line: 9, type: !118)
!302 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!303 = !DILocation(line: 9, column: 2, scope: !302)
!304 = !{i64 2148865507}
!305 = !DILocalVariable(name: "__x86_sim_ret_addr", scope: !134, file: !126, line: 9, type: !84)
!306 = !DILocalVariable(name: "__x86_stack_mem", scope: !134, file: !126, line: 9, type: !307)
!307 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !308)
!308 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 9, size: 64, elements: !309)
!309 = !{!310, !314}
!310 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !308, file: !126, line: 9, baseType: !311, size: 8)
!311 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 8, elements: !312)
!312 = !{!313}
!313 = !DISubrange(count: 1)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "q", scope: !308, file: !126, line: 9, baseType: !315, size: 64)
!315 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 64, elements: !312)
!316 = !DILocalVariable(name: "__native_value", scope: !317, file: !126, line: 9, type: !118)
!317 = distinct !DILexicalBlock(scope: !134, file: !126, line: 9, column: 2)
!318 = !DILocation(line: 9, column: 2, scope: !317)
!319 = !{i64 2148865979}
!320 = !DILabel(scope: !134, name: "x86_l_0", file: !126, line: 10)
!321 = !DILocation(line: 10, column: 1, scope: !134)
!322 = !DILocation(line: 12, column: 2, scope: !134)
!323 = !DILocalVariable(name: "__x86_l_write_width", scope: !324, file: !126, line: 12, type: !57)
!324 = distinct !DILexicalBlock(scope: !134, file: !126, line: 12, column: 2)
!325 = !DILocation(line: 12, column: 2, scope: !324)
!326 = !DILocalVariable(name: "__kprog_x86_ml_write", scope: !327, file: !126, line: 12, type: !57)
!327 = distinct !DILexicalBlock(scope: !324, file: !126, line: 12, column: 2)
!328 = !DILocation(line: 12, column: 2, scope: !327)
!329 = !DILocalVariable(name: "__x86_l_mem_width", scope: !324, file: !126, line: 12, type: !57)
!330 = !DILocalVariable(name: "__kprog_x86_ml_mem", scope: !331, file: !126, line: 12, type: !57)
!331 = distinct !DILexicalBlock(scope: !324, file: !126, line: 12, column: 2)
!332 = !DILocation(line: 12, column: 2, scope: !331)
!333 = !DILocation(line: 12, column: 2, scope: !334)
!334 = distinct !DILexicalBlock(scope: !331, file: !126, line: 12, column: 2)
!335 = !DILocalVariable(name: "__kprog_x86_ml_write", scope: !336, file: !126, line: 12, type: !57)
!336 = distinct !DILexicalBlock(scope: !334, file: !126, line: 12, column: 2)
!337 = !DILocation(line: 12, column: 2, scope: !336)
!338 = !DILocalVariable(name: "__x86_l_arm", scope: !324, file: !126, line: 12, type: !57)
!339 = !DILocalVariable(name: "__kprog_x86_ml_arm", scope: !340, file: !126, line: 12, type: !57)
!340 = distinct !DILexicalBlock(scope: !324, file: !126, line: 12, column: 2)
!341 = !DILocation(line: 12, column: 2, scope: !340)
!342 = !DILocation(line: 12, column: 2, scope: !343)
!343 = distinct !DILexicalBlock(scope: !340, file: !126, line: 12, column: 2)
!344 = !DILocalVariable(name: "__x86_l_disp", scope: !324, file: !126, line: 12, type: !115)
!345 = !DILocalVariable(name: "__kprog_x86_mo_disp", scope: !346, file: !126, line: 12, type: !115)
!346 = distinct !DILexicalBlock(scope: !324, file: !126, line: 12, column: 2)
!347 = !DILocation(line: 12, column: 2, scope: !346)
!348 = !DILocalVariable(name: "value", arg: 1, scope: !349, file: !350, line: 279, type: !84)
!349 = distinct !DISubprogram(name: "x86_simm", scope: !350, file: !350, line: 279, type: !351, scopeLine: 280, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !146)
!350 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "cedba0dfb15f459a1fb61860887ac4b4")
!351 = !DISubroutineType(types: !352)
!352 = !{!115, !84}
!353 = !DILocation(line: 279, column: 45, scope: !349, inlinedAt: !354)
!354 = distinct !DILocation(line: 12, column: 2, scope: !346)
!355 = !DILocation(line: 281, column: 16, scope: !349, inlinedAt: !354)
!356 = !DILocalVariable(name: "__kprog_x86_mo_has_index", scope: !346, file: !126, line: 12, type: !110)
!357 = !DILocalVariable(name: "__kprog_x86_mo_result", scope: !346, file: !126, line: 12, type: !84)
!358 = !DILocation(line: 12, column: 2, scope: !359)
!359 = distinct !DILexicalBlock(scope: !346, file: !126, line: 12, column: 2)
!360 = !DILocalVariable(name: "__kprog_x86_mo_scale", scope: !361, file: !126, line: 12, type: !57)
!361 = distinct !DILexicalBlock(scope: !359, file: !126, line: 12, column: 2)
!362 = !DILocation(line: 12, column: 2, scope: !361)
!363 = !DILocalVariable(name: "__kprog_x86_mo_index", scope: !361, file: !126, line: 12, type: !84)
!364 = !DILocalVariable(name: "__x86_l_meta_disp", scope: !324, file: !126, line: 12, type: !115)
!365 = !DILocalVariable(name: "__x86_l_base_ptr", scope: !324, file: !126, line: 12, type: !114)
!366 = !DILocalVariable(name: "__x86_l_value", scope: !324, file: !126, line: 12, type: !84)
!367 = !DILocation(line: 12, column: 2, scope: !368)
!368 = distinct !DILexicalBlock(scope: !324, file: !126, line: 12, column: 2)
!369 = !DILocalVariable(name: "__x86_l_addr", scope: !324, file: !126, line: 12, type: !114)
!370 = !DILocation(line: 12, column: 2, scope: !371)
!371 = distinct !DILexicalBlock(scope: !324, file: !126, line: 12, column: 2)
!372 = !DILocalVariable(name: "__x86_l_tag", scope: !373, file: !126, line: 12, type: !57)
!373 = distinct !DILexicalBlock(scope: !371, file: !126, line: 12, column: 2)
!374 = !DILocation(line: 12, column: 2, scope: !373)
!375 = !DILocalVariable(name: "__x86_sr_width", scope: !376, file: !126, line: 12, type: !57)
!376 = distinct !DILexicalBlock(scope: !377, file: !126, line: 12, column: 2)
!377 = distinct !DILexicalBlock(scope: !371, file: !126, line: 12, column: 2)
!378 = !DILocation(line: 12, column: 2, scope: !376)
!379 = !DILocalVariable(name: "__x86_sr_off", scope: !376, file: !126, line: 12, type: !115)
!380 = !DILocalVariable(name: "__x86_sr_ctx", scope: !376, file: !126, line: 12, type: !5)
!381 = !DILocalVariable(name: "__x86_sr_value", scope: !376, file: !126, line: 12, type: !84)
!382 = !DILocation(line: 12, column: 2, scope: !383)
!383 = distinct !DILexicalBlock(scope: !376, file: !126, line: 12, column: 2)
!384 = !DILocalVariable(name: "__x86_sr_lane", scope: !385, file: !126, line: 12, type: !115)
!385 = distinct !DILexicalBlock(scope: !383, file: !126, line: 12, column: 2)
!386 = !DILocation(line: 12, column: 2, scope: !385)
!387 = !DILocation(line: 12, column: 2, scope: !388)
!388 = distinct !DILexicalBlock(scope: !385, file: !126, line: 12, column: 2)
!389 = !DILocalVariable(name: "__x86_sf_value", scope: !390, file: !126, line: 12, type: !84)
!390 = distinct !DILexicalBlock(scope: !391, file: !126, line: 12, column: 2)
!391 = distinct !DILexicalBlock(scope: !388, file: !126, line: 12, column: 2)
!392 = !DILocation(line: 12, column: 2, scope: !390)
!393 = !{i64 2148917225}
!394 = !DILocation(line: 12, column: 2, scope: !391)
!395 = !DILocalVariable(name: "__x86_sf_value", scope: !396, file: !126, line: 12, type: !84)
!396 = distinct !DILexicalBlock(scope: !397, file: !126, line: 12, column: 2)
!397 = distinct !DILexicalBlock(scope: !388, file: !126, line: 12, column: 2)
!398 = !DILocation(line: 12, column: 2, scope: !396)
!399 = !{i64 2148917447}
!400 = !DILocation(line: 12, column: 2, scope: !397)
!401 = !DILocation(line: 12, column: 2, scope: !402)
!402 = distinct !DILexicalBlock(scope: !385, file: !126, line: 12, column: 2)
!403 = !DILocalVariable(name: "__native_value", scope: !404, file: !126, line: 12, type: !118)
!404 = distinct !DILexicalBlock(scope: !402, file: !126, line: 12, column: 2)
!405 = !DILocation(line: 12, column: 2, scope: !404)
!406 = !DILocalVariable(name: "__native_pointer", scope: !404, file: !126, line: 12, type: !118)
!407 = !{i64 2148917823}
!408 = !DILocalVariable(name: "value", arg: 1, scope: !409, file: !350, line: 221, type: !84)
!409 = distinct !DISubprogram(name: "x86_apply_width", scope: !350, file: !350, line: 221, type: !410, scopeLine: 222, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !146)
!410 = !DISubroutineType(types: !411)
!411 = !{!84, !84, !57}
!412 = !DILocation(line: 221, column: 52, scope: !409, inlinedAt: !413)
!413 = distinct !DILocation(line: 12, column: 2, scope: !402)
!414 = !DILocalVariable(name: "width", arg: 2, scope: !409, file: !350, line: 221, type: !57)
!415 = !DILocation(line: 221, column: 64, scope: !409, inlinedAt: !413)
!416 = !DILocation(line: 223, column: 9, scope: !409, inlinedAt: !413)
!417 = !DILocation(line: 12, column: 2, scope: !418)
!418 = distinct !DILexicalBlock(scope: !383, file: !126, line: 12, column: 2)
!419 = !DILocalVariable(name: "__x86_cbr_value", scope: !420, file: !126, line: 12, type: !84)
!420 = distinct !DILexicalBlock(scope: !418, file: !126, line: 12, column: 2)
!421 = !DILocation(line: 12, column: 2, scope: !420)
!422 = !DILocalVariable(name: "__x86_cbr_temp", scope: !420, file: !126, line: 12, type: !84)
!423 = !DILocation(line: 12, column: 2, scope: !424)
!424 = distinct !DILexicalBlock(scope: !420, file: !126, line: 12, column: 2)
!425 = !DILocation(line: 12, column: 2, scope: !426)
!426 = distinct !DILexicalBlock(scope: !427, file: !126, line: 12, column: 2)
!427 = distinct !DILexicalBlock(scope: !424, file: !126, line: 12, column: 2)
!428 = !DILocation(line: 12, column: 2, scope: !427)
!429 = !{i64 2148918083, i64 2148918107, i64 2148918130, i64 2148918140, i64 2148918150, i64 2148918173, i64 2148918184, i64 2148918194, i64 2148918217, i64 2148918228, i64 2148918238, i64 2148918261, i64 2148918272, i64 2148918282, i64 2148918305, i64 2148918316, i64 2148918326, i64 2148918349, i64 2148918360, i64 2148918370, i64 2148918394, i64 2148918405}
!430 = !DILocation(line: 12, column: 2, scope: !431)
!431 = distinct !DILexicalBlock(scope: !426, file: !126, line: 12, column: 2)
!432 = !{i64 2148918649, i64 2148918673, i64 2148918696, i64 2148918706, i64 2148918716, i64 2148918739, i64 2148918750, i64 2148918760, i64 2148918783, i64 2148918794}
!433 = !DILocation(line: 12, column: 2, scope: !434)
!434 = distinct !DILexicalBlock(scope: !431, file: !126, line: 12, column: 2)
!435 = !{i64 2148918982, i64 2148919006, i64 2148919029, i64 2148919039}
!436 = !DILocation(line: 12, column: 2, scope: !437)
!437 = distinct !DILexicalBlock(scope: !434, file: !126, line: 12, column: 2)
!438 = !{i64 2148919199}
!439 = !DILocalVariable(name: "__x86_cbr_addr", scope: !440, file: !126, line: 12, type: !120)
!440 = distinct !DILexicalBlock(scope: !424, file: !126, line: 12, column: 2)
!441 = !DILocation(line: 12, column: 2, scope: !440)
!442 = !DILocalVariable(name: "__x86_cbr_value", scope: !440, file: !126, line: 12, type: !84)
!443 = !DILocation(line: 12, column: 2, scope: !444)
!444 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!445 = !DILocation(line: 12, column: 2, scope: !446)
!446 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!447 = !DILocation(line: 12, column: 2, scope: !448)
!448 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!449 = !DILocation(line: 12, column: 2, scope: !450)
!450 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!451 = !DILocation(line: 12, column: 2, scope: !452)
!452 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!453 = !DILocation(line: 12, column: 2, scope: !454)
!454 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!455 = !DILocation(line: 12, column: 2, scope: !456)
!456 = distinct !DILexicalBlock(scope: !440, file: !126, line: 12, column: 2)
!457 = !DILocation(line: 12, column: 2, scope: !458)
!458 = distinct !DILexicalBlock(scope: !418, file: !126, line: 12, column: 2)
!459 = !DILocalVariable(name: "__x86_sf_value", scope: !460, file: !126, line: 12, type: !84)
!460 = distinct !DILexicalBlock(scope: !458, file: !126, line: 12, column: 2)
!461 = !DILocation(line: 12, column: 2, scope: !460)
!462 = !{i64 2148922246}
!463 = !DILocation(line: 221, column: 52, scope: !409, inlinedAt: !464)
!464 = distinct !DILocation(line: 12, column: 2, scope: !458)
!465 = !DILocation(line: 221, column: 64, scope: !409, inlinedAt: !464)
!466 = !DILocation(line: 223, column: 9, scope: !409, inlinedAt: !464)
!467 = !DILocation(line: 12, column: 2, scope: !468)
!468 = distinct !DILexicalBlock(scope: !458, file: !126, line: 12, column: 2)
!469 = !DILocalVariable(name: "__x86_sf_value", scope: !470, file: !126, line: 12, type: !84)
!470 = distinct !DILexicalBlock(scope: !468, file: !126, line: 12, column: 2)
!471 = !DILocation(line: 12, column: 2, scope: !470)
!472 = !{i64 2148922713}
!473 = !DILocation(line: 221, column: 52, scope: !409, inlinedAt: !474)
!474 = distinct !DILocation(line: 12, column: 2, scope: !468)
!475 = !DILocation(line: 221, column: 64, scope: !409, inlinedAt: !474)
!476 = !DILocation(line: 223, column: 9, scope: !409, inlinedAt: !474)
!477 = !DILocation(line: 12, column: 2, scope: !478)
!478 = distinct !DILexicalBlock(scope: !468, file: !126, line: 12, column: 2)
!479 = !DILocalVariable(name: "__x86_sf_value", scope: !480, file: !126, line: 12, type: !84)
!480 = distinct !DILexicalBlock(scope: !478, file: !126, line: 12, column: 2)
!481 = !DILocation(line: 12, column: 2, scope: !480)
!482 = !{i64 2148923176}
!483 = !DILocation(line: 221, column: 52, scope: !409, inlinedAt: !484)
!484 = distinct !DILocation(line: 12, column: 2, scope: !478)
!485 = !DILocation(line: 221, column: 64, scope: !409, inlinedAt: !484)
!486 = !DILocation(line: 223, column: 9, scope: !409, inlinedAt: !484)
!487 = !DILocalVariable(name: "__x86_snr_value", scope: !488, file: !126, line: 12, type: !84)
!488 = distinct !DILexicalBlock(scope: !478, file: !126, line: 12, column: 2)
!489 = !DILocation(line: 12, column: 2, scope: !488)
!490 = !DILocation(line: 12, column: 2, scope: !491)
!491 = distinct !DILexicalBlock(scope: !488, file: !126, line: 12, column: 2)
!492 = !DILocalVariable(name: "base", arg: 1, scope: !493, file: !494, line: 56, type: !497)
!493 = distinct !DISubprogram(name: "kprog_x86_mem_load_fixed", scope: !494, file: !494, line: 56, type: !495, scopeLine: 57, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !146)
!494 = !DIFile(filename: ".agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/../formal/generated/x86_mem_access.h", directory: "/workspaces", checksumkind: CSK_MD5, checksum: "642fcb4f054d60386fcd37ded524589c")
!495 = !DISubroutineType(types: !496)
!496 = !{!84, !497, !116, !57}
!497 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !498, size: 64)
!498 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!499 = !DILocation(line: 56, column: 38, scope: !493, inlinedAt: !500)
!500 = distinct !DILocation(line: 12, column: 2, scope: !491)
!501 = !DILocalVariable(name: "displacement", arg: 2, scope: !493, file: !494, line: 56, type: !116)
!502 = !DILocation(line: 56, column: 54, scope: !493, inlinedAt: !500)
!503 = !DILocalVariable(name: "width", arg: 3, scope: !493, file: !494, line: 56, type: !57)
!504 = !DILocation(line: 56, column: 73, scope: !493, inlinedAt: !500)
!505 = !DILocation(line: 59, column: 31, scope: !506, inlinedAt: !500)
!506 = distinct !DILexicalBlock(scope: !493, file: !494, line: 59, column: 9)
!507 = !DILocation(line: 59, column: 10, scope: !506, inlinedAt: !500)
!508 = !DILocation(line: 59, column: 45, scope: !506, inlinedAt: !500)
!509 = !DILocation(line: 59, column: 48, scope: !506, inlinedAt: !500)
!510 = !DILocation(line: 59, column: 61, scope: !506, inlinedAt: !500)
!511 = !DILocation(line: 59, column: 70, scope: !506, inlinedAt: !500)
!512 = !DILocation(line: 59, column: 73, scope: !506, inlinedAt: !500)
!513 = !DILocation(line: 59, column: 86, scope: !506, inlinedAt: !500)
!514 = !DILocation(line: 59, column: 9, scope: !493, inlinedAt: !500)
!515 = !DILocation(line: 60, column: 9, scope: !506, inlinedAt: !500)
!516 = !{i32 823096}
!517 = !DILocalVariable(name: "value", scope: !493, file: !494, line: 61, type: !84)
!518 = !DILocation(line: 61, column: 11, scope: !493, inlinedAt: !500)
!519 = !DILocation(line: 62, column: 13, scope: !493, inlinedAt: !500)
!520 = !DILocation(line: 62, column: 21, scope: !493, inlinedAt: !500)
!521 = !DILocation(line: 62, column: 5, scope: !493, inlinedAt: !500)
!522 = !DILocation(line: 64, column: 13, scope: !523, inlinedAt: !500)
!523 = distinct !DILexicalBlock(scope: !524, file: !494, line: 64, column: 13)
!524 = distinct !DILexicalBlock(scope: !493, file: !494, line: 62, column: 43)
!525 = !DILocation(line: 64, column: 26, scope: !523, inlinedAt: !500)
!526 = !DILocation(line: 64, column: 13, scope: !524, inlinedAt: !500)
!527 = !DILocation(line: 65, column: 70, scope: !523, inlinedAt: !500)
!528 = !DILocation(line: 65, column: 82, scope: !523, inlinedAt: !500)
!529 = !DILocation(line: 65, column: 81, scope: !523, inlinedAt: !500)
!530 = !DILocation(line: 65, column: 13, scope: !523, inlinedAt: !500)
!531 = !{i64 823275}
!532 = !DILocation(line: 67, column: 70, scope: !523, inlinedAt: !500)
!533 = !DILocation(line: 67, column: 81, scope: !523, inlinedAt: !500)
!534 = !DILocation(line: 67, column: 13, scope: !523, inlinedAt: !500)
!535 = !{i64 823396}
!536 = !DILocation(line: 68, column: 22, scope: !524, inlinedAt: !500)
!537 = !DILocation(line: 68, column: 16, scope: !524, inlinedAt: !500)
!538 = !DILocation(line: 68, column: 9, scope: !524, inlinedAt: !500)
!539 = !DILocation(line: 70, column: 13, scope: !540, inlinedAt: !500)
!540 = distinct !DILexicalBlock(scope: !524, file: !494, line: 70, column: 13)
!541 = !DILocation(line: 70, column: 26, scope: !540, inlinedAt: !500)
!542 = !DILocation(line: 70, column: 13, scope: !524, inlinedAt: !500)
!543 = !DILocation(line: 71, column: 71, scope: !540, inlinedAt: !500)
!544 = !DILocation(line: 71, column: 83, scope: !540, inlinedAt: !500)
!545 = !DILocation(line: 71, column: 82, scope: !540, inlinedAt: !500)
!546 = !DILocation(line: 71, column: 13, scope: !540, inlinedAt: !500)
!547 = !{i64 823584}
!548 = !DILocation(line: 73, column: 71, scope: !540, inlinedAt: !500)
!549 = !DILocation(line: 73, column: 82, scope: !540, inlinedAt: !500)
!550 = !DILocation(line: 73, column: 13, scope: !540, inlinedAt: !500)
!551 = !{i64 823706}
!552 = !DILocation(line: 74, column: 23, scope: !524, inlinedAt: !500)
!553 = !DILocation(line: 74, column: 16, scope: !524, inlinedAt: !500)
!554 = !DILocation(line: 74, column: 9, scope: !524, inlinedAt: !500)
!555 = !DILocation(line: 76, column: 13, scope: !556, inlinedAt: !500)
!556 = distinct !DILexicalBlock(scope: !524, file: !494, line: 76, column: 13)
!557 = !DILocation(line: 76, column: 26, scope: !556, inlinedAt: !500)
!558 = !DILocation(line: 76, column: 13, scope: !524, inlinedAt: !500)
!559 = !DILocation(line: 77, column: 71, scope: !556, inlinedAt: !500)
!560 = !DILocation(line: 77, column: 83, scope: !556, inlinedAt: !500)
!561 = !DILocation(line: 77, column: 82, scope: !556, inlinedAt: !500)
!562 = !DILocation(line: 77, column: 13, scope: !556, inlinedAt: !500)
!563 = !{i64 823896}
!564 = !DILocation(line: 79, column: 71, scope: !556, inlinedAt: !500)
!565 = !DILocation(line: 79, column: 82, scope: !556, inlinedAt: !500)
!566 = !DILocation(line: 79, column: 13, scope: !556, inlinedAt: !500)
!567 = !{i64 824018}
!568 = !DILocation(line: 80, column: 23, scope: !524, inlinedAt: !500)
!569 = !DILocation(line: 80, column: 16, scope: !524, inlinedAt: !500)
!570 = !DILocation(line: 80, column: 9, scope: !524, inlinedAt: !500)
!571 = !DILocation(line: 82, column: 13, scope: !572, inlinedAt: !500)
!572 = distinct !DILexicalBlock(scope: !524, file: !494, line: 82, column: 13)
!573 = !DILocation(line: 82, column: 26, scope: !572, inlinedAt: !500)
!574 = !DILocation(line: 82, column: 13, scope: !524, inlinedAt: !500)
!575 = !DILocation(line: 83, column: 71, scope: !572, inlinedAt: !500)
!576 = !DILocation(line: 83, column: 83, scope: !572, inlinedAt: !500)
!577 = !DILocation(line: 83, column: 82, scope: !572, inlinedAt: !500)
!578 = !DILocation(line: 83, column: 13, scope: !572, inlinedAt: !500)
!579 = !{i64 824208}
!580 = !DILocation(line: 85, column: 71, scope: !572, inlinedAt: !500)
!581 = !DILocation(line: 85, column: 82, scope: !572, inlinedAt: !500)
!582 = !DILocation(line: 85, column: 13, scope: !572, inlinedAt: !500)
!583 = !{i64 824330}
!584 = !DILocation(line: 86, column: 16, scope: !524, inlinedAt: !500)
!585 = !DILocation(line: 86, column: 9, scope: !524, inlinedAt: !500)
!586 = !DILocation(line: 87, column: 14, scope: !524, inlinedAt: !500)
!587 = !DILocation(line: 88, column: 5, scope: !524, inlinedAt: !500)
!588 = !DILocation(line: 92, column: 1, scope: !493, inlinedAt: !500)
!589 = !DILocalVariable(name: "address", arg: 1, scope: !590, file: !494, line: 12, type: !497)
!590 = distinct !DISubprogram(name: "kprog_x86_mem_load", scope: !494, file: !494, line: 12, type: !591, scopeLine: 13, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !146)
!591 = !DISubroutineType(types: !592)
!592 = !{!84, !497, !57}
!593 = !DILocation(line: 12, column: 32, scope: !590, inlinedAt: !594)
!594 = distinct !DILocation(line: 12, column: 2, scope: !491)
!595 = !DILocalVariable(name: "width", arg: 2, scope: !590, file: !494, line: 12, type: !57)
!596 = !DILocation(line: 12, column: 46, scope: !590, inlinedAt: !594)
!597 = !DILocalVariable(name: "value", scope: !590, file: !494, line: 15, type: !84)
!598 = !DILocation(line: 15, column: 11, scope: !590, inlinedAt: !594)
!599 = !DILocation(line: 17, column: 13, scope: !590, inlinedAt: !594)
!600 = !DILocation(line: 17, column: 21, scope: !590, inlinedAt: !594)
!601 = !DILocation(line: 17, column: 5, scope: !590, inlinedAt: !594)
!602 = !DILocation(line: 20, column: 65, scope: !603, inlinedAt: !594)
!603 = distinct !DILexicalBlock(scope: !590, file: !494, line: 17, column: 43)
!604 = !DILocation(line: 20, column: 9, scope: !603, inlinedAt: !594)
!605 = !{i64 821504}
!606 = !DILocation(line: 21, column: 22, scope: !603, inlinedAt: !594)
!607 = !DILocation(line: 21, column: 16, scope: !603, inlinedAt: !594)
!608 = !DILocation(line: 21, column: 9, scope: !603, inlinedAt: !594)
!609 = !DILocation(line: 27, column: 66, scope: !603, inlinedAt: !594)
!610 = !DILocation(line: 27, column: 9, scope: !603, inlinedAt: !594)
!611 = !{i64 821759}
!612 = !DILocation(line: 28, column: 23, scope: !603, inlinedAt: !594)
!613 = !DILocation(line: 28, column: 16, scope: !603, inlinedAt: !594)
!614 = !DILocation(line: 28, column: 9, scope: !603, inlinedAt: !594)
!615 = !DILocation(line: 34, column: 66, scope: !603, inlinedAt: !594)
!616 = !DILocation(line: 34, column: 9, scope: !603, inlinedAt: !594)
!617 = !{i64 822017}
!618 = !DILocation(line: 35, column: 23, scope: !603, inlinedAt: !594)
!619 = !DILocation(line: 35, column: 16, scope: !603, inlinedAt: !594)
!620 = !DILocation(line: 35, column: 9, scope: !603, inlinedAt: !594)
!621 = !DILocation(line: 41, column: 66, scope: !603, inlinedAt: !594)
!622 = !DILocation(line: 41, column: 9, scope: !603, inlinedAt: !594)
!623 = !{i64 822275}
!624 = !DILocation(line: 42, column: 16, scope: !603, inlinedAt: !594)
!625 = !DILocation(line: 42, column: 9, scope: !603, inlinedAt: !594)
!626 = !DILocation(line: 46, column: 14, scope: !603, inlinedAt: !594)
!627 = !DILocation(line: 47, column: 5, scope: !603, inlinedAt: !594)
!628 = !DILocation(line: 48, column: 1, scope: !590, inlinedAt: !594)
!629 = !DILocation(line: 12, column: 2, scope: !377)
!630 = !DILocation(line: 12, column: 2, scope: !631)
!631 = distinct !DILexicalBlock(scope: !377, file: !126, line: 12, column: 2)
!632 = !DILocalVariable(name: "__x86_skb_tag", scope: !633, file: !126, line: 12, type: !57)
!633 = distinct !DILexicalBlock(scope: !631, file: !126, line: 12, column: 2)
!634 = !DILocation(line: 12, column: 2, scope: !633)
!635 = !DILocalVariable(name: "__kprog_abi_kind", scope: !636, file: !126, line: 12, type: !57)
!636 = distinct !DILexicalBlock(scope: !633, file: !126, line: 12, column: 2)
!637 = !DILocation(line: 12, column: 2, scope: !636)
!638 = !DILocalVariable(name: "__kprog_abi_offset", scope: !636, file: !126, line: 12, type: !115)
!639 = !DILocalVariable(name: "__kprog_abi_tag", scope: !636, file: !126, line: 12, type: !57)
!640 = !DILocation(line: 12, column: 2, scope: !641)
!641 = distinct !DILexicalBlock(scope: !636, file: !126, line: 12, column: 2)
!642 = !DILocation(line: 12, column: 2, scope: !643)
!643 = distinct !DILexicalBlock(scope: !641, file: !126, line: 12, column: 2)
!644 = !DILocation(line: 12, column: 2, scope: !645)
!645 = distinct !DILexicalBlock(scope: !633, file: !126, line: 12, column: 2)
!646 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !647, file: !126, line: 12, type: !114)
!647 = distinct !DILexicalBlock(scope: !645, file: !126, line: 12, column: 2)
!648 = !DILocation(line: 12, column: 2, scope: !647)
!649 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !647, file: !126, line: 12, type: !57)
!650 = !DILocation(line: 12, column: 2, scope: !651)
!651 = distinct !DILexicalBlock(scope: !631, file: !126, line: 12, column: 2)
!652 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !653, file: !126, line: 12, type: !57)
!653 = distinct !DILexicalBlock(scope: !651, file: !126, line: 12, column: 2)
!654 = !DILocation(line: 12, column: 2, scope: !653)
!655 = !DILocalVariable(name: "__x86_wr_width", scope: !653, file: !126, line: 12, type: !57)
!656 = !DILocalVariable(name: "code", arg: 1, scope: !657, file: !350, line: 226, type: !57)
!657 = distinct !DISubprogram(name: "x86_width_effective", scope: !350, file: !350, line: 226, type: !658, scopeLine: 227, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !146)
!658 = !DISubroutineType(types: !659)
!659 = !{!57, !57}
!660 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !661)
!661 = distinct !DILocation(line: 12, column: 2, scope: !653)
!662 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !661)
!663 = !DILocalVariable(name: "__x86_wr_shift", scope: !653, file: !126, line: 12, type: !57)
!664 = !DILocalVariable(name: "__x86_wr_next", scope: !653, file: !126, line: 12, type: !84)
!665 = !DILocation(line: 12, column: 2, scope: !666)
!666 = distinct !DILexicalBlock(scope: !653, file: !126, line: 12, column: 2)
!667 = !DILocation(line: 12, column: 2, scope: !668)
!668 = distinct !DILexicalBlock(scope: !669, file: !126, line: 12, column: 2)
!669 = distinct !DILexicalBlock(scope: !670, file: !126, line: 12, column: 2)
!670 = distinct !DILexicalBlock(scope: !666, file: !126, line: 12, column: 2)
!671 = !DILocation(line: 12, column: 2, scope: !669)
!672 = !DILocalVariable(name: "__x86_stack_delta", scope: !673, file: !126, line: 12, type: !84)
!673 = distinct !DILexicalBlock(scope: !668, file: !126, line: 12, column: 2)
!674 = !DILocation(line: 12, column: 2, scope: !673)
!675 = !{i64 2149047541}
!676 = !DILocation(line: 12, column: 2, scope: !670)
!677 = !DILocation(line: 12, column: 2, scope: !678)
!678 = distinct !DILexicalBlock(scope: !679, file: !126, line: 12, column: 2)
!679 = distinct !DILexicalBlock(scope: !670, file: !126, line: 12, column: 2)
!680 = !DILocation(line: 12, column: 2, scope: !679)
!681 = !DILocation(line: 12, column: 2, scope: !682)
!682 = distinct !DILexicalBlock(scope: !683, file: !126, line: 12, column: 2)
!683 = distinct !DILexicalBlock(scope: !678, file: !126, line: 12, column: 2)
!684 = !DILocation(line: 12, column: 2, scope: !683)
!685 = !DILocalVariable(name: "__kprog_x86_partial", scope: !686, file: !126, line: 12, type: !687)
!686 = distinct !DILexicalBlock(scope: !678, file: !126, line: 12, column: 2)
!687 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !688)
!688 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !689)
!689 = !{!690, !691, !692}
!690 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !688, file: !126, line: 12, baseType: !114, size: 64)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !688, file: !126, line: 12, baseType: !52, size: 16)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !688, file: !126, line: 12, baseType: !170, size: 64)
!693 = !DILocation(line: 12, column: 2, scope: !686)
!694 = !DILocation(line: 12, column: 2, scope: !695)
!695 = distinct !DILexicalBlock(scope: !686, file: !126, line: 12, column: 2)
!696 = !DILocation(line: 12, column: 2, scope: !697)
!697 = distinct !DILexicalBlock(scope: !666, file: !126, line: 12, column: 2)
!698 = !DILocation(line: 12, column: 2, scope: !699)
!699 = distinct !DILexicalBlock(scope: !700, file: !126, line: 12, column: 2)
!700 = distinct !DILexicalBlock(scope: !701, file: !126, line: 12, column: 2)
!701 = distinct !DILexicalBlock(scope: !697, file: !126, line: 12, column: 2)
!702 = !DILocation(line: 12, column: 2, scope: !700)
!703 = !DILocalVariable(name: "__x86_stack_delta", scope: !704, file: !126, line: 12, type: !84)
!704 = distinct !DILexicalBlock(scope: !699, file: !126, line: 12, column: 2)
!705 = !DILocation(line: 12, column: 2, scope: !704)
!706 = !{i64 2149086844}
!707 = !DILocation(line: 12, column: 2, scope: !701)
!708 = !DILocation(line: 12, column: 2, scope: !709)
!709 = distinct !DILexicalBlock(scope: !710, file: !126, line: 12, column: 2)
!710 = distinct !DILexicalBlock(scope: !701, file: !126, line: 12, column: 2)
!711 = !DILocation(line: 12, column: 2, scope: !710)
!712 = !DILocation(line: 12, column: 2, scope: !713)
!713 = distinct !DILexicalBlock(scope: !709, file: !126, line: 12, column: 2)
!714 = !DILocalVariable(name: "__kprog_x86_partial", scope: !715, file: !126, line: 12, type: !716)
!715 = distinct !DILexicalBlock(scope: !709, file: !126, line: 12, column: 2)
!716 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !717)
!717 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !718)
!718 = !{!719, !720, !721}
!719 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !717, file: !126, line: 12, baseType: !114, size: 64)
!720 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !717, file: !126, line: 12, baseType: !52, size: 16)
!721 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !717, file: !126, line: 12, baseType: !170, size: 64)
!722 = !DILocation(line: 12, column: 2, scope: !715)
!723 = !DILocation(line: 12, column: 2, scope: !724)
!724 = distinct !DILexicalBlock(scope: !697, file: !126, line: 12, column: 2)
!725 = !DILocation(line: 12, column: 2, scope: !726)
!726 = distinct !DILexicalBlock(scope: !724, file: !126, line: 12, column: 2)
!727 = !DILocation(line: 12, column: 2, scope: !728)
!728 = distinct !DILexicalBlock(scope: !726, file: !126, line: 12, column: 2)
!729 = !DILocation(line: 12, column: 2, scope: !730)
!730 = distinct !DILexicalBlock(scope: !724, file: !126, line: 12, column: 2)
!731 = !DILocation(line: 12, column: 2, scope: !732)
!732 = distinct !DILexicalBlock(scope: !730, file: !126, line: 12, column: 2)
!733 = !DILocation(line: 12, column: 2, scope: !734)
!734 = distinct !DILexicalBlock(scope: !371, file: !126, line: 12, column: 2)
!735 = !DILocalVariable(name: "__x86_l_tag", scope: !736, file: !126, line: 12, type: !57)
!736 = distinct !DILexicalBlock(scope: !734, file: !126, line: 12, column: 2)
!737 = !DILocation(line: 12, column: 2, scope: !736)
!738 = !DILocalVariable(name: "__x86_xdp_value", scope: !739, file: !126, line: 12, type: !84)
!739 = distinct !DILexicalBlock(scope: !734, file: !126, line: 12, column: 2)
!740 = !DILocation(line: 12, column: 2, scope: !739)
!741 = !DILocalVariable(name: "__x86_xdp_off", scope: !742, file: !126, line: 12, type: !115)
!742 = distinct !DILexicalBlock(scope: !739, file: !126, line: 12, column: 2)
!743 = !DILocation(line: 12, column: 2, scope: !742)
!744 = !DILocalVariable(name: "__x86_xdp_ctx", scope: !742, file: !126, line: 12, type: !745)
!745 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !746, size: 64)
!746 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !138)
!747 = !DILocalVariable(name: "__x86_xdp_value", scope: !742, file: !126, line: 12, type: !84)
!748 = !DILocation(line: 12, column: 2, scope: !749)
!749 = distinct !DILexicalBlock(scope: !742, file: !126, line: 12, column: 2)
!750 = !DILocation(line: 12, column: 2, scope: !751)
!751 = distinct !DILexicalBlock(scope: !749, file: !126, line: 12, column: 2)
!752 = !DILocation(line: 12, column: 2, scope: !753)
!753 = distinct !DILexicalBlock(scope: !751, file: !126, line: 12, column: 2)
!754 = !{i32 -2145818403}
!755 = !{i64 2149149306}
!756 = !DILocalVariable(name: "__x86_xdp_tag", scope: !739, file: !126, line: 12, type: !57)
!757 = !DILocalVariable(name: "__kprog_abi_kind", scope: !758, file: !126, line: 12, type: !57)
!758 = distinct !DILexicalBlock(scope: !739, file: !126, line: 12, column: 2)
!759 = !DILocation(line: 12, column: 2, scope: !758)
!760 = !DILocalVariable(name: "__kprog_abi_offset", scope: !758, file: !126, line: 12, type: !115)
!761 = !DILocalVariable(name: "__kprog_abi_tag", scope: !758, file: !126, line: 12, type: !57)
!762 = !DILocation(line: 12, column: 2, scope: !763)
!763 = distinct !DILexicalBlock(scope: !758, file: !126, line: 12, column: 2)
!764 = !DILocation(line: 12, column: 2, scope: !765)
!765 = distinct !DILexicalBlock(scope: !763, file: !126, line: 12, column: 2)
!766 = !DILocation(line: 12, column: 2, scope: !767)
!767 = distinct !DILexicalBlock(scope: !739, file: !126, line: 12, column: 2)
!768 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !769, file: !126, line: 12, type: !114)
!769 = distinct !DILexicalBlock(scope: !767, file: !126, line: 12, column: 2)
!770 = !DILocation(line: 12, column: 2, scope: !769)
!771 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !769, file: !126, line: 12, type: !57)
!772 = !DILocalVariable(name: "__kprog_x86_md_src", scope: !773, file: !126, line: 12, type: !57)
!773 = distinct !DILexicalBlock(scope: !734, file: !126, line: 12, column: 2)
!774 = !DILocation(line: 12, column: 2, scope: !773)
!775 = !DILocation(line: 12, column: 2, scope: !776)
!776 = distinct !DILexicalBlock(scope: !773, file: !126, line: 12, column: 2)
!777 = !DILocalVariable(name: "__x86_str_index", scope: !778, file: !126, line: 12, type: !84)
!778 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!779 = distinct !DILexicalBlock(scope: !734, file: !126, line: 12, column: 2)
!780 = !DILocation(line: 12, column: 2, scope: !778)
!781 = !DILocalVariable(name: "__x86_str_value", scope: !778, file: !126, line: 12, type: !84)
!782 = !DILocation(line: 12, column: 2, scope: !783)
!783 = distinct !DILexicalBlock(scope: !778, file: !126, line: 12, column: 2)
!784 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !785)
!785 = distinct !DILocation(line: 12, column: 2, scope: !783)
!786 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !785)
!787 = !DILocation(line: 0, scope: !783)
!788 = !DILocation(line: 12, column: 2, scope: !789)
!789 = distinct !DILexicalBlock(scope: !783, file: !126, line: 12, column: 2)
!790 = !DILocalVariable(name: "__x86_str_bytes", scope: !791, file: !126, line: 12, type: !792)
!791 = distinct !DILexicalBlock(scope: !783, file: !126, line: 12, column: 2)
!792 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !122, size: 64)
!793 = !DILocation(line: 12, column: 2, scope: !791)
!794 = !DILocalVariable(name: "__x86_str_width", scope: !791, file: !126, line: 12, type: !57)
!795 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !796)
!796 = distinct !DILocation(line: 12, column: 2, scope: !791)
!797 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !796)
!798 = !DILocation(line: 12, column: 2, scope: !799)
!799 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!800 = !DILocation(line: 12, column: 2, scope: !801)
!801 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!802 = !DILocation(line: 12, column: 2, scope: !803)
!803 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!804 = !DILocation(line: 12, column: 2, scope: !805)
!805 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!806 = !DILocation(line: 12, column: 2, scope: !807)
!807 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!808 = !DILocation(line: 12, column: 2, scope: !809)
!809 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!810 = !DILocation(line: 12, column: 2, scope: !811)
!811 = distinct !DILexicalBlock(scope: !791, file: !126, line: 12, column: 2)
!812 = !DILocation(line: 12, column: 2, scope: !779)
!813 = !DILocalVariable(name: "__x86_mv_saved", scope: !779, file: !126, line: 12, type: !814)
!814 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_stack_value", file: !151, line: 246, size: 128, elements: !815)
!815 = !{!816, !817}
!816 = !DIDerivedType(tag: DW_TAG_member, name: "pointer", scope: !814, file: !151, line: 246, baseType: !114, size: 64)
!817 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !814, file: !151, line: 246, baseType: !57, size: 8, offset: 64)
!818 = !DILocalVariable(name: "__x86_sv_result", scope: !819, file: !126, line: 12, type: !814)
!819 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!820 = !DILocation(line: 12, column: 2, scope: !819)
!821 = !DILocalVariable(name: "__x86_sv_at", scope: !819, file: !126, line: 12, type: !84)
!822 = !DILocation(line: 12, column: 2, scope: !823)
!823 = distinct !DILexicalBlock(scope: !819, file: !126, line: 12, column: 2)
!824 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !825)
!825 = distinct !DILocation(line: 12, column: 2, scope: !823)
!826 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !825)
!827 = !DILocation(line: 12, column: 2, scope: !828)
!828 = distinct !DILexicalBlock(scope: !823, file: !126, line: 12, column: 2)
!829 = !DILocation(line: 12, column: 2, scope: !830)
!830 = distinct !DILexicalBlock(scope: !831, file: !126, line: 12, column: 2)
!831 = distinct !DILexicalBlock(scope: !828, file: !126, line: 12, column: 2)
!832 = !DILocation(line: 12, column: 2, scope: !831)
!833 = !DILocation(line: 12, column: 2, scope: !834)
!834 = distinct !DILexicalBlock(scope: !830, file: !126, line: 12, column: 2)
!835 = !DILocation(line: 12, column: 2, scope: !836)
!836 = distinct !DILexicalBlock(scope: !834, file: !126, line: 12, column: 2)
!837 = !DILocation(line: 12, column: 2, scope: !838)
!838 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!839 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !840, file: !126, line: 12, type: !114)
!840 = distinct !DILexicalBlock(scope: !838, file: !126, line: 12, column: 2)
!841 = !DILocation(line: 12, column: 2, scope: !840)
!842 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !840, file: !126, line: 12, type: !57)
!843 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !844, file: !126, line: 12, type: !57)
!844 = distinct !DILexicalBlock(scope: !838, file: !126, line: 12, column: 2)
!845 = !DILocation(line: 12, column: 2, scope: !844)
!846 = !DILocalVariable(name: "__x86_wr_width", scope: !844, file: !126, line: 12, type: !57)
!847 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !848)
!848 = distinct !DILocation(line: 12, column: 2, scope: !844)
!849 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !848)
!850 = !DILocalVariable(name: "__x86_wr_shift", scope: !844, file: !126, line: 12, type: !57)
!851 = !DILocalVariable(name: "__x86_wr_next", scope: !844, file: !126, line: 12, type: !84)
!852 = !DILocation(line: 12, column: 2, scope: !853)
!853 = distinct !DILexicalBlock(scope: !844, file: !126, line: 12, column: 2)
!854 = !DILocation(line: 12, column: 2, scope: !855)
!855 = distinct !DILexicalBlock(scope: !856, file: !126, line: 12, column: 2)
!856 = distinct !DILexicalBlock(scope: !857, file: !126, line: 12, column: 2)
!857 = distinct !DILexicalBlock(scope: !853, file: !126, line: 12, column: 2)
!858 = !DILocation(line: 12, column: 2, scope: !856)
!859 = !DILocalVariable(name: "__x86_stack_delta", scope: !860, file: !126, line: 12, type: !84)
!860 = distinct !DILexicalBlock(scope: !855, file: !126, line: 12, column: 2)
!861 = !DILocation(line: 12, column: 2, scope: !860)
!862 = !{i64 2149282858}
!863 = !DILocation(line: 12, column: 2, scope: !857)
!864 = !DILocation(line: 12, column: 2, scope: !865)
!865 = distinct !DILexicalBlock(scope: !866, file: !126, line: 12, column: 2)
!866 = distinct !DILexicalBlock(scope: !857, file: !126, line: 12, column: 2)
!867 = !DILocation(line: 12, column: 2, scope: !866)
!868 = !DILocation(line: 12, column: 2, scope: !869)
!869 = distinct !DILexicalBlock(scope: !870, file: !126, line: 12, column: 2)
!870 = distinct !DILexicalBlock(scope: !865, file: !126, line: 12, column: 2)
!871 = !DILocation(line: 12, column: 2, scope: !870)
!872 = !DILocalVariable(name: "__kprog_x86_partial", scope: !873, file: !126, line: 12, type: !874)
!873 = distinct !DILexicalBlock(scope: !865, file: !126, line: 12, column: 2)
!874 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !875)
!875 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !876)
!876 = !{!877, !878, !879}
!877 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !875, file: !126, line: 12, baseType: !114, size: 64)
!878 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !875, file: !126, line: 12, baseType: !52, size: 16)
!879 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !875, file: !126, line: 12, baseType: !170, size: 64)
!880 = !DILocation(line: 12, column: 2, scope: !873)
!881 = !DILocation(line: 12, column: 2, scope: !882)
!882 = distinct !DILexicalBlock(scope: !873, file: !126, line: 12, column: 2)
!883 = !DILocation(line: 12, column: 2, scope: !884)
!884 = distinct !DILexicalBlock(scope: !853, file: !126, line: 12, column: 2)
!885 = !DILocation(line: 12, column: 2, scope: !886)
!886 = distinct !DILexicalBlock(scope: !887, file: !126, line: 12, column: 2)
!887 = distinct !DILexicalBlock(scope: !888, file: !126, line: 12, column: 2)
!888 = distinct !DILexicalBlock(scope: !884, file: !126, line: 12, column: 2)
!889 = !DILocation(line: 12, column: 2, scope: !887)
!890 = !DILocalVariable(name: "__x86_stack_delta", scope: !891, file: !126, line: 12, type: !84)
!891 = distinct !DILexicalBlock(scope: !886, file: !126, line: 12, column: 2)
!892 = !DILocation(line: 12, column: 2, scope: !891)
!893 = !{i64 2149318100}
!894 = !DILocation(line: 12, column: 2, scope: !888)
!895 = !DILocation(line: 12, column: 2, scope: !896)
!896 = distinct !DILexicalBlock(scope: !897, file: !126, line: 12, column: 2)
!897 = distinct !DILexicalBlock(scope: !888, file: !126, line: 12, column: 2)
!898 = !DILocation(line: 12, column: 2, scope: !897)
!899 = !DILocation(line: 12, column: 2, scope: !900)
!900 = distinct !DILexicalBlock(scope: !896, file: !126, line: 12, column: 2)
!901 = !DILocalVariable(name: "__kprog_x86_partial", scope: !902, file: !126, line: 12, type: !903)
!902 = distinct !DILexicalBlock(scope: !896, file: !126, line: 12, column: 2)
!903 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !904)
!904 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !905)
!905 = !{!906, !907, !908}
!906 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !904, file: !126, line: 12, baseType: !114, size: 64)
!907 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !904, file: !126, line: 12, baseType: !52, size: 16)
!908 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !904, file: !126, line: 12, baseType: !170, size: 64)
!909 = !DILocation(line: 12, column: 2, scope: !902)
!910 = !DILocation(line: 12, column: 2, scope: !911)
!911 = distinct !DILexicalBlock(scope: !884, file: !126, line: 12, column: 2)
!912 = !DILocation(line: 12, column: 2, scope: !913)
!913 = distinct !DILexicalBlock(scope: !911, file: !126, line: 12, column: 2)
!914 = !DILocation(line: 12, column: 2, scope: !915)
!915 = distinct !DILexicalBlock(scope: !913, file: !126, line: 12, column: 2)
!916 = !DILocation(line: 12, column: 2, scope: !917)
!917 = distinct !DILexicalBlock(scope: !911, file: !126, line: 12, column: 2)
!918 = !DILocation(line: 12, column: 2, scope: !919)
!919 = distinct !DILexicalBlock(scope: !917, file: !126, line: 12, column: 2)
!920 = !DILocation(line: 12, column: 2, scope: !921)
!921 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!922 = !DILocation(line: 12, column: 2, scope: !923)
!923 = distinct !DILexicalBlock(scope: !924, file: !126, line: 12, column: 2)
!924 = distinct !DILexicalBlock(scope: !921, file: !126, line: 12, column: 2)
!925 = !DILocation(line: 279, column: 45, scope: !349, inlinedAt: !926)
!926 = distinct !DILocation(line: 12, column: 2, scope: !923)
!927 = !DILocation(line: 281, column: 16, scope: !349, inlinedAt: !926)
!928 = !DILocation(line: 56, column: 38, scope: !493, inlinedAt: !929)
!929 = distinct !DILocation(line: 12, column: 2, scope: !923)
!930 = !DILocation(line: 56, column: 54, scope: !493, inlinedAt: !929)
!931 = !DILocation(line: 56, column: 73, scope: !493, inlinedAt: !929)
!932 = !DILocation(line: 59, column: 31, scope: !506, inlinedAt: !929)
!933 = !DILocation(line: 59, column: 10, scope: !506, inlinedAt: !929)
!934 = !DILocation(line: 59, column: 45, scope: !506, inlinedAt: !929)
!935 = !DILocation(line: 59, column: 48, scope: !506, inlinedAt: !929)
!936 = !DILocation(line: 59, column: 61, scope: !506, inlinedAt: !929)
!937 = !DILocation(line: 59, column: 70, scope: !506, inlinedAt: !929)
!938 = !DILocation(line: 59, column: 73, scope: !506, inlinedAt: !929)
!939 = !DILocation(line: 59, column: 86, scope: !506, inlinedAt: !929)
!940 = !DILocation(line: 59, column: 9, scope: !493, inlinedAt: !929)
!941 = !DILocation(line: 60, column: 9, scope: !506, inlinedAt: !929)
!942 = !DILocation(line: 61, column: 11, scope: !493, inlinedAt: !929)
!943 = !DILocation(line: 62, column: 13, scope: !493, inlinedAt: !929)
!944 = !DILocation(line: 62, column: 21, scope: !493, inlinedAt: !929)
!945 = !DILocation(line: 62, column: 5, scope: !493, inlinedAt: !929)
!946 = !DILocation(line: 64, column: 13, scope: !523, inlinedAt: !929)
!947 = !DILocation(line: 64, column: 26, scope: !523, inlinedAt: !929)
!948 = !DILocation(line: 64, column: 13, scope: !524, inlinedAt: !929)
!949 = !DILocation(line: 65, column: 70, scope: !523, inlinedAt: !929)
!950 = !DILocation(line: 65, column: 82, scope: !523, inlinedAt: !929)
!951 = !DILocation(line: 65, column: 81, scope: !523, inlinedAt: !929)
!952 = !DILocation(line: 65, column: 13, scope: !523, inlinedAt: !929)
!953 = !DILocation(line: 67, column: 70, scope: !523, inlinedAt: !929)
!954 = !DILocation(line: 67, column: 81, scope: !523, inlinedAt: !929)
!955 = !DILocation(line: 67, column: 13, scope: !523, inlinedAt: !929)
!956 = !DILocation(line: 68, column: 22, scope: !524, inlinedAt: !929)
!957 = !DILocation(line: 68, column: 16, scope: !524, inlinedAt: !929)
!958 = !DILocation(line: 68, column: 9, scope: !524, inlinedAt: !929)
!959 = !DILocation(line: 70, column: 13, scope: !540, inlinedAt: !929)
!960 = !DILocation(line: 70, column: 26, scope: !540, inlinedAt: !929)
!961 = !DILocation(line: 70, column: 13, scope: !524, inlinedAt: !929)
!962 = !DILocation(line: 71, column: 71, scope: !540, inlinedAt: !929)
!963 = !DILocation(line: 71, column: 83, scope: !540, inlinedAt: !929)
!964 = !DILocation(line: 71, column: 82, scope: !540, inlinedAt: !929)
!965 = !DILocation(line: 71, column: 13, scope: !540, inlinedAt: !929)
!966 = !DILocation(line: 73, column: 71, scope: !540, inlinedAt: !929)
!967 = !DILocation(line: 73, column: 82, scope: !540, inlinedAt: !929)
!968 = !DILocation(line: 73, column: 13, scope: !540, inlinedAt: !929)
!969 = !DILocation(line: 74, column: 23, scope: !524, inlinedAt: !929)
!970 = !DILocation(line: 74, column: 16, scope: !524, inlinedAt: !929)
!971 = !DILocation(line: 74, column: 9, scope: !524, inlinedAt: !929)
!972 = !DILocation(line: 76, column: 13, scope: !556, inlinedAt: !929)
!973 = !DILocation(line: 76, column: 26, scope: !556, inlinedAt: !929)
!974 = !DILocation(line: 76, column: 13, scope: !524, inlinedAt: !929)
!975 = !DILocation(line: 77, column: 71, scope: !556, inlinedAt: !929)
!976 = !DILocation(line: 77, column: 83, scope: !556, inlinedAt: !929)
!977 = !DILocation(line: 77, column: 82, scope: !556, inlinedAt: !929)
!978 = !DILocation(line: 77, column: 13, scope: !556, inlinedAt: !929)
!979 = !DILocation(line: 79, column: 71, scope: !556, inlinedAt: !929)
!980 = !DILocation(line: 79, column: 82, scope: !556, inlinedAt: !929)
!981 = !DILocation(line: 79, column: 13, scope: !556, inlinedAt: !929)
!982 = !DILocation(line: 80, column: 23, scope: !524, inlinedAt: !929)
!983 = !DILocation(line: 80, column: 16, scope: !524, inlinedAt: !929)
!984 = !DILocation(line: 80, column: 9, scope: !524, inlinedAt: !929)
!985 = !DILocation(line: 82, column: 13, scope: !572, inlinedAt: !929)
!986 = !DILocation(line: 82, column: 26, scope: !572, inlinedAt: !929)
!987 = !DILocation(line: 82, column: 13, scope: !524, inlinedAt: !929)
!988 = !DILocation(line: 83, column: 71, scope: !572, inlinedAt: !929)
!989 = !DILocation(line: 83, column: 83, scope: !572, inlinedAt: !929)
!990 = !DILocation(line: 83, column: 82, scope: !572, inlinedAt: !929)
!991 = !DILocation(line: 83, column: 13, scope: !572, inlinedAt: !929)
!992 = !DILocation(line: 85, column: 71, scope: !572, inlinedAt: !929)
!993 = !DILocation(line: 85, column: 82, scope: !572, inlinedAt: !929)
!994 = !DILocation(line: 85, column: 13, scope: !572, inlinedAt: !929)
!995 = !DILocation(line: 86, column: 16, scope: !524, inlinedAt: !929)
!996 = !DILocation(line: 86, column: 9, scope: !524, inlinedAt: !929)
!997 = !DILocation(line: 87, column: 14, scope: !524, inlinedAt: !929)
!998 = !DILocation(line: 88, column: 5, scope: !524, inlinedAt: !929)
!999 = !DILocation(line: 92, column: 1, scope: !493, inlinedAt: !929)
!1000 = !DILocation(line: 12, column: 2, scope: !924)
!1001 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !1002, file: !126, line: 12, type: !57)
!1002 = distinct !DILexicalBlock(scope: !924, file: !126, line: 12, column: 2)
!1003 = !DILocation(line: 12, column: 2, scope: !1002)
!1004 = !DILocalVariable(name: "__x86_wr_width", scope: !1002, file: !126, line: 12, type: !57)
!1005 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !1006)
!1006 = distinct !DILocation(line: 12, column: 2, scope: !1002)
!1007 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !1006)
!1008 = !DILocalVariable(name: "__x86_wr_shift", scope: !1002, file: !126, line: 12, type: !57)
!1009 = !DILocalVariable(name: "__x86_wr_next", scope: !1002, file: !126, line: 12, type: !84)
!1010 = !DILocation(line: 12, column: 2, scope: !1011)
!1011 = distinct !DILexicalBlock(scope: !1002, file: !126, line: 12, column: 2)
!1012 = !DILocation(line: 12, column: 2, scope: !1013)
!1013 = distinct !DILexicalBlock(scope: !1014, file: !126, line: 12, column: 2)
!1014 = distinct !DILexicalBlock(scope: !1015, file: !126, line: 12, column: 2)
!1015 = distinct !DILexicalBlock(scope: !1011, file: !126, line: 12, column: 2)
!1016 = !DILocation(line: 12, column: 2, scope: !1014)
!1017 = !DILocalVariable(name: "__x86_stack_delta", scope: !1018, file: !126, line: 12, type: !84)
!1018 = distinct !DILexicalBlock(scope: !1013, file: !126, line: 12, column: 2)
!1019 = !DILocation(line: 12, column: 2, scope: !1018)
!1020 = !{i64 2149381204}
!1021 = !DILocation(line: 12, column: 2, scope: !1015)
!1022 = !DILocation(line: 12, column: 2, scope: !1023)
!1023 = distinct !DILexicalBlock(scope: !1024, file: !126, line: 12, column: 2)
!1024 = distinct !DILexicalBlock(scope: !1015, file: !126, line: 12, column: 2)
!1025 = !DILocation(line: 12, column: 2, scope: !1024)
!1026 = !DILocation(line: 12, column: 2, scope: !1027)
!1027 = distinct !DILexicalBlock(scope: !1028, file: !126, line: 12, column: 2)
!1028 = distinct !DILexicalBlock(scope: !1023, file: !126, line: 12, column: 2)
!1029 = !DILocation(line: 12, column: 2, scope: !1028)
!1030 = !DILocalVariable(name: "__kprog_x86_partial", scope: !1031, file: !126, line: 12, type: !1032)
!1031 = distinct !DILexicalBlock(scope: !1023, file: !126, line: 12, column: 2)
!1032 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !1033)
!1033 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !1034)
!1034 = !{!1035, !1036, !1037}
!1035 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !1033, file: !126, line: 12, baseType: !114, size: 64)
!1036 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !1033, file: !126, line: 12, baseType: !52, size: 16)
!1037 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !1033, file: !126, line: 12, baseType: !170, size: 64)
!1038 = !DILocation(line: 12, column: 2, scope: !1031)
!1039 = !DILocation(line: 12, column: 2, scope: !1040)
!1040 = distinct !DILexicalBlock(scope: !1031, file: !126, line: 12, column: 2)
!1041 = !DILocation(line: 12, column: 2, scope: !1042)
!1042 = distinct !DILexicalBlock(scope: !1011, file: !126, line: 12, column: 2)
!1043 = !DILocation(line: 12, column: 2, scope: !1044)
!1044 = distinct !DILexicalBlock(scope: !1045, file: !126, line: 12, column: 2)
!1045 = distinct !DILexicalBlock(scope: !1046, file: !126, line: 12, column: 2)
!1046 = distinct !DILexicalBlock(scope: !1042, file: !126, line: 12, column: 2)
!1047 = !DILocation(line: 12, column: 2, scope: !1045)
!1048 = !DILocalVariable(name: "__x86_stack_delta", scope: !1049, file: !126, line: 12, type: !84)
!1049 = distinct !DILexicalBlock(scope: !1044, file: !126, line: 12, column: 2)
!1050 = !DILocation(line: 12, column: 2, scope: !1049)
!1051 = !{i64 2149420507}
!1052 = !DILocation(line: 12, column: 2, scope: !1046)
!1053 = !DILocation(line: 12, column: 2, scope: !1054)
!1054 = distinct !DILexicalBlock(scope: !1055, file: !126, line: 12, column: 2)
!1055 = distinct !DILexicalBlock(scope: !1046, file: !126, line: 12, column: 2)
!1056 = !DILocation(line: 12, column: 2, scope: !1055)
!1057 = !DILocation(line: 12, column: 2, scope: !1058)
!1058 = distinct !DILexicalBlock(scope: !1054, file: !126, line: 12, column: 2)
!1059 = !DILocalVariable(name: "__kprog_x86_partial", scope: !1060, file: !126, line: 12, type: !1061)
!1060 = distinct !DILexicalBlock(scope: !1054, file: !126, line: 12, column: 2)
!1061 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !1062)
!1062 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !1063)
!1063 = !{!1064, !1065, !1066}
!1064 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !1062, file: !126, line: 12, baseType: !114, size: 64)
!1065 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !1062, file: !126, line: 12, baseType: !52, size: 16)
!1066 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !1062, file: !126, line: 12, baseType: !170, size: 64)
!1067 = !DILocation(line: 12, column: 2, scope: !1060)
!1068 = !DILocation(line: 12, column: 2, scope: !1069)
!1069 = distinct !DILexicalBlock(scope: !1042, file: !126, line: 12, column: 2)
!1070 = !DILocation(line: 12, column: 2, scope: !1071)
!1071 = distinct !DILexicalBlock(scope: !1069, file: !126, line: 12, column: 2)
!1072 = !DILocation(line: 12, column: 2, scope: !1073)
!1073 = distinct !DILexicalBlock(scope: !1071, file: !126, line: 12, column: 2)
!1074 = !DILocation(line: 12, column: 2, scope: !1075)
!1075 = distinct !DILexicalBlock(scope: !1069, file: !126, line: 12, column: 2)
!1076 = !DILocation(line: 12, column: 2, scope: !1077)
!1077 = distinct !DILexicalBlock(scope: !1075, file: !126, line: 12, column: 2)
!1078 = !DILocalVariable(name: "__x86_l_ptr_tag", scope: !779, file: !126, line: 12, type: !57)
!1079 = !DILocalVariable(name: "__kprog_abi_kind", scope: !1080, file: !126, line: 12, type: !57)
!1080 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!1081 = !DILocation(line: 12, column: 2, scope: !1080)
!1082 = !DILocalVariable(name: "__kprog_abi_offset", scope: !1080, file: !126, line: 12, type: !115)
!1083 = !DILocalVariable(name: "__kprog_abi_tag", scope: !1080, file: !126, line: 12, type: !57)
!1084 = !DILocation(line: 12, column: 2, scope: !1085)
!1085 = distinct !DILexicalBlock(scope: !1080, file: !126, line: 12, column: 2)
!1086 = !DILocation(line: 12, column: 2, scope: !1087)
!1087 = distinct !DILexicalBlock(scope: !1085, file: !126, line: 12, column: 2)
!1088 = !DILocation(line: 12, column: 2, scope: !1089)
!1089 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!1090 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !1091, file: !126, line: 12, type: !114)
!1091 = distinct !DILexicalBlock(scope: !1089, file: !126, line: 12, column: 2)
!1092 = !DILocation(line: 12, column: 2, scope: !1091)
!1093 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !1091, file: !126, line: 12, type: !57)
!1094 = !DILocalVariable(name: "__x86_l_tag", scope: !1095, file: !126, line: 12, type: !57)
!1095 = distinct !DILexicalBlock(scope: !1096, file: !126, line: 12, column: 2)
!1096 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!1097 = !DILocation(line: 12, column: 2, scope: !1095)
!1098 = !DILocation(line: 12, column: 2, scope: !1096)
!1099 = !DILocation(line: 279, column: 45, scope: !349, inlinedAt: !1100)
!1100 = distinct !DILocation(line: 12, column: 2, scope: !1096)
!1101 = !DILocation(line: 281, column: 16, scope: !349, inlinedAt: !1100)
!1102 = !DILocation(line: 56, column: 38, scope: !493, inlinedAt: !1103)
!1103 = distinct !DILocation(line: 12, column: 2, scope: !1096)
!1104 = !DILocation(line: 56, column: 54, scope: !493, inlinedAt: !1103)
!1105 = !DILocation(line: 56, column: 73, scope: !493, inlinedAt: !1103)
!1106 = !DILocation(line: 59, column: 31, scope: !506, inlinedAt: !1103)
!1107 = !DILocation(line: 59, column: 10, scope: !506, inlinedAt: !1103)
!1108 = !DILocation(line: 59, column: 45, scope: !506, inlinedAt: !1103)
!1109 = !DILocation(line: 59, column: 48, scope: !506, inlinedAt: !1103)
!1110 = !DILocation(line: 59, column: 61, scope: !506, inlinedAt: !1103)
!1111 = !DILocation(line: 59, column: 70, scope: !506, inlinedAt: !1103)
!1112 = !DILocation(line: 59, column: 73, scope: !506, inlinedAt: !1103)
!1113 = !DILocation(line: 59, column: 86, scope: !506, inlinedAt: !1103)
!1114 = !DILocation(line: 59, column: 9, scope: !493, inlinedAt: !1103)
!1115 = !DILocation(line: 60, column: 9, scope: !506, inlinedAt: !1103)
!1116 = !DILocation(line: 61, column: 11, scope: !493, inlinedAt: !1103)
!1117 = !DILocation(line: 62, column: 13, scope: !493, inlinedAt: !1103)
!1118 = !DILocation(line: 62, column: 21, scope: !493, inlinedAt: !1103)
!1119 = !DILocation(line: 62, column: 5, scope: !493, inlinedAt: !1103)
!1120 = !DILocation(line: 64, column: 13, scope: !523, inlinedAt: !1103)
!1121 = !DILocation(line: 64, column: 26, scope: !523, inlinedAt: !1103)
!1122 = !DILocation(line: 64, column: 13, scope: !524, inlinedAt: !1103)
!1123 = !DILocation(line: 65, column: 70, scope: !523, inlinedAt: !1103)
!1124 = !DILocation(line: 65, column: 82, scope: !523, inlinedAt: !1103)
!1125 = !DILocation(line: 65, column: 81, scope: !523, inlinedAt: !1103)
!1126 = !DILocation(line: 65, column: 13, scope: !523, inlinedAt: !1103)
!1127 = !DILocation(line: 67, column: 70, scope: !523, inlinedAt: !1103)
!1128 = !DILocation(line: 67, column: 81, scope: !523, inlinedAt: !1103)
!1129 = !DILocation(line: 67, column: 13, scope: !523, inlinedAt: !1103)
!1130 = !DILocation(line: 68, column: 22, scope: !524, inlinedAt: !1103)
!1131 = !DILocation(line: 68, column: 16, scope: !524, inlinedAt: !1103)
!1132 = !DILocation(line: 68, column: 9, scope: !524, inlinedAt: !1103)
!1133 = !DILocation(line: 70, column: 13, scope: !540, inlinedAt: !1103)
!1134 = !DILocation(line: 70, column: 26, scope: !540, inlinedAt: !1103)
!1135 = !DILocation(line: 70, column: 13, scope: !524, inlinedAt: !1103)
!1136 = !DILocation(line: 71, column: 71, scope: !540, inlinedAt: !1103)
!1137 = !DILocation(line: 71, column: 83, scope: !540, inlinedAt: !1103)
!1138 = !DILocation(line: 71, column: 82, scope: !540, inlinedAt: !1103)
!1139 = !DILocation(line: 71, column: 13, scope: !540, inlinedAt: !1103)
!1140 = !DILocation(line: 73, column: 71, scope: !540, inlinedAt: !1103)
!1141 = !DILocation(line: 73, column: 82, scope: !540, inlinedAt: !1103)
!1142 = !DILocation(line: 73, column: 13, scope: !540, inlinedAt: !1103)
!1143 = !DILocation(line: 74, column: 23, scope: !524, inlinedAt: !1103)
!1144 = !DILocation(line: 74, column: 16, scope: !524, inlinedAt: !1103)
!1145 = !DILocation(line: 74, column: 9, scope: !524, inlinedAt: !1103)
!1146 = !DILocation(line: 76, column: 13, scope: !556, inlinedAt: !1103)
!1147 = !DILocation(line: 76, column: 26, scope: !556, inlinedAt: !1103)
!1148 = !DILocation(line: 76, column: 13, scope: !524, inlinedAt: !1103)
!1149 = !DILocation(line: 77, column: 71, scope: !556, inlinedAt: !1103)
!1150 = !DILocation(line: 77, column: 83, scope: !556, inlinedAt: !1103)
!1151 = !DILocation(line: 77, column: 82, scope: !556, inlinedAt: !1103)
!1152 = !DILocation(line: 77, column: 13, scope: !556, inlinedAt: !1103)
!1153 = !DILocation(line: 79, column: 71, scope: !556, inlinedAt: !1103)
!1154 = !DILocation(line: 79, column: 82, scope: !556, inlinedAt: !1103)
!1155 = !DILocation(line: 79, column: 13, scope: !556, inlinedAt: !1103)
!1156 = !DILocation(line: 80, column: 23, scope: !524, inlinedAt: !1103)
!1157 = !DILocation(line: 80, column: 16, scope: !524, inlinedAt: !1103)
!1158 = !DILocation(line: 80, column: 9, scope: !524, inlinedAt: !1103)
!1159 = !DILocation(line: 82, column: 13, scope: !572, inlinedAt: !1103)
!1160 = !DILocation(line: 82, column: 26, scope: !572, inlinedAt: !1103)
!1161 = !DILocation(line: 82, column: 13, scope: !524, inlinedAt: !1103)
!1162 = !DILocation(line: 83, column: 71, scope: !572, inlinedAt: !1103)
!1163 = !DILocation(line: 83, column: 83, scope: !572, inlinedAt: !1103)
!1164 = !DILocation(line: 83, column: 82, scope: !572, inlinedAt: !1103)
!1165 = !DILocation(line: 83, column: 13, scope: !572, inlinedAt: !1103)
!1166 = !DILocation(line: 85, column: 71, scope: !572, inlinedAt: !1103)
!1167 = !DILocation(line: 85, column: 82, scope: !572, inlinedAt: !1103)
!1168 = !DILocation(line: 85, column: 13, scope: !572, inlinedAt: !1103)
!1169 = !DILocation(line: 86, column: 16, scope: !524, inlinedAt: !1103)
!1170 = !DILocation(line: 86, column: 9, scope: !524, inlinedAt: !1103)
!1171 = !DILocation(line: 87, column: 14, scope: !524, inlinedAt: !1103)
!1172 = !DILocation(line: 88, column: 5, scope: !524, inlinedAt: !1103)
!1173 = !DILocation(line: 92, column: 1, scope: !493, inlinedAt: !1103)
!1174 = !DILocation(line: 12, column: 32, scope: !590, inlinedAt: !1175)
!1175 = distinct !DILocation(line: 12, column: 2, scope: !1096)
!1176 = !DILocation(line: 12, column: 46, scope: !590, inlinedAt: !1175)
!1177 = !DILocation(line: 15, column: 11, scope: !590, inlinedAt: !1175)
!1178 = !DILocation(line: 17, column: 13, scope: !590, inlinedAt: !1175)
!1179 = !DILocation(line: 17, column: 21, scope: !590, inlinedAt: !1175)
!1180 = !DILocation(line: 17, column: 5, scope: !590, inlinedAt: !1175)
!1181 = !DILocation(line: 20, column: 65, scope: !603, inlinedAt: !1175)
!1182 = !DILocation(line: 20, column: 9, scope: !603, inlinedAt: !1175)
!1183 = !DILocation(line: 21, column: 22, scope: !603, inlinedAt: !1175)
!1184 = !DILocation(line: 21, column: 16, scope: !603, inlinedAt: !1175)
!1185 = !DILocation(line: 21, column: 9, scope: !603, inlinedAt: !1175)
!1186 = !DILocation(line: 27, column: 66, scope: !603, inlinedAt: !1175)
!1187 = !DILocation(line: 27, column: 9, scope: !603, inlinedAt: !1175)
!1188 = !DILocation(line: 28, column: 23, scope: !603, inlinedAt: !1175)
!1189 = !DILocation(line: 28, column: 16, scope: !603, inlinedAt: !1175)
!1190 = !DILocation(line: 28, column: 9, scope: !603, inlinedAt: !1175)
!1191 = !DILocation(line: 34, column: 66, scope: !603, inlinedAt: !1175)
!1192 = !DILocation(line: 34, column: 9, scope: !603, inlinedAt: !1175)
!1193 = !DILocation(line: 35, column: 23, scope: !603, inlinedAt: !1175)
!1194 = !DILocation(line: 35, column: 16, scope: !603, inlinedAt: !1175)
!1195 = !DILocation(line: 35, column: 9, scope: !603, inlinedAt: !1175)
!1196 = !DILocation(line: 41, column: 66, scope: !603, inlinedAt: !1175)
!1197 = !DILocation(line: 41, column: 9, scope: !603, inlinedAt: !1175)
!1198 = !DILocation(line: 42, column: 16, scope: !603, inlinedAt: !1175)
!1199 = !DILocation(line: 42, column: 9, scope: !603, inlinedAt: !1175)
!1200 = !DILocation(line: 46, column: 14, scope: !603, inlinedAt: !1175)
!1201 = !DILocation(line: 47, column: 5, scope: !603, inlinedAt: !1175)
!1202 = !DILocation(line: 48, column: 1, scope: !590, inlinedAt: !1175)
!1203 = !DILocalVariable(name: "__x86_mv_alias", scope: !779, file: !126, line: 12, type: !814)
!1204 = !DILocalVariable(name: "__x86_l_tag", scope: !1205, file: !126, line: 12, type: !57)
!1205 = distinct !DILexicalBlock(scope: !1206, file: !126, line: 12, column: 2)
!1206 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!1207 = !DILocation(line: 12, column: 2, scope: !1205)
!1208 = !DILocation(line: 12, column: 2, scope: !1206)
!1209 = !DILocalVariable(name: "__x86_sv_result", scope: !1210, file: !126, line: 12, type: !814)
!1210 = distinct !DILexicalBlock(scope: !1206, file: !126, line: 12, column: 2)
!1211 = !DILocation(line: 12, column: 2, scope: !1210)
!1212 = !DILocalVariable(name: "__x86_sv_at", scope: !1210, file: !126, line: 12, type: !84)
!1213 = !DILocation(line: 12, column: 2, scope: !1214)
!1214 = distinct !DILexicalBlock(scope: !1210, file: !126, line: 12, column: 2)
!1215 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !1216)
!1216 = distinct !DILocation(line: 12, column: 2, scope: !1214)
!1217 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !1216)
!1218 = !DILocation(line: 12, column: 2, scope: !1219)
!1219 = distinct !DILexicalBlock(scope: !1214, file: !126, line: 12, column: 2)
!1220 = !DILocation(line: 12, column: 2, scope: !1221)
!1221 = distinct !DILexicalBlock(scope: !1222, file: !126, line: 12, column: 2)
!1222 = distinct !DILexicalBlock(scope: !1219, file: !126, line: 12, column: 2)
!1223 = !DILocation(line: 12, column: 2, scope: !1222)
!1224 = !DILocation(line: 12, column: 2, scope: !1225)
!1225 = distinct !DILexicalBlock(scope: !1221, file: !126, line: 12, column: 2)
!1226 = !DILocation(line: 12, column: 2, scope: !1227)
!1227 = distinct !DILexicalBlock(scope: !1225, file: !126, line: 12, column: 2)
!1228 = !DILocation(line: 12, column: 2, scope: !1229)
!1229 = distinct !DILexicalBlock(scope: !779, file: !126, line: 12, column: 2)
!1230 = !DILocalVariable(name: "__x86_wr_next_ptr", scope: !1231, file: !126, line: 12, type: !114)
!1231 = distinct !DILexicalBlock(scope: !1229, file: !126, line: 12, column: 2)
!1232 = !DILocation(line: 12, column: 2, scope: !1231)
!1233 = !DILocalVariable(name: "__x86_wr_next_tag", scope: !1231, file: !126, line: 12, type: !57)
!1234 = !DILocalVariable(name: "__x86_wr_raw_width", scope: !1235, file: !126, line: 12, type: !57)
!1235 = distinct !DILexicalBlock(scope: !1229, file: !126, line: 12, column: 2)
!1236 = !DILocation(line: 12, column: 2, scope: !1235)
!1237 = !DILocalVariable(name: "__x86_wr_width", scope: !1235, file: !126, line: 12, type: !57)
!1238 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !1239)
!1239 = distinct !DILocation(line: 12, column: 2, scope: !1235)
!1240 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !1239)
!1241 = !DILocalVariable(name: "__x86_wr_shift", scope: !1235, file: !126, line: 12, type: !57)
!1242 = !DILocalVariable(name: "__x86_wr_next", scope: !1235, file: !126, line: 12, type: !84)
!1243 = !DILocation(line: 12, column: 2, scope: !1244)
!1244 = distinct !DILexicalBlock(scope: !1235, file: !126, line: 12, column: 2)
!1245 = !DILocation(line: 12, column: 2, scope: !1246)
!1246 = distinct !DILexicalBlock(scope: !1247, file: !126, line: 12, column: 2)
!1247 = distinct !DILexicalBlock(scope: !1248, file: !126, line: 12, column: 2)
!1248 = distinct !DILexicalBlock(scope: !1244, file: !126, line: 12, column: 2)
!1249 = !DILocation(line: 12, column: 2, scope: !1247)
!1250 = !DILocalVariable(name: "__x86_stack_delta", scope: !1251, file: !126, line: 12, type: !84)
!1251 = distinct !DILexicalBlock(scope: !1246, file: !126, line: 12, column: 2)
!1252 = !DILocation(line: 12, column: 2, scope: !1251)
!1253 = !{i64 2149604208}
!1254 = !DILocation(line: 12, column: 2, scope: !1248)
!1255 = !DILocation(line: 12, column: 2, scope: !1256)
!1256 = distinct !DILexicalBlock(scope: !1257, file: !126, line: 12, column: 2)
!1257 = distinct !DILexicalBlock(scope: !1248, file: !126, line: 12, column: 2)
!1258 = !DILocation(line: 12, column: 2, scope: !1257)
!1259 = !DILocation(line: 12, column: 2, scope: !1260)
!1260 = distinct !DILexicalBlock(scope: !1261, file: !126, line: 12, column: 2)
!1261 = distinct !DILexicalBlock(scope: !1256, file: !126, line: 12, column: 2)
!1262 = !DILocation(line: 12, column: 2, scope: !1261)
!1263 = !DILocalVariable(name: "__kprog_x86_partial", scope: !1264, file: !126, line: 12, type: !1265)
!1264 = distinct !DILexicalBlock(scope: !1256, file: !126, line: 12, column: 2)
!1265 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !1266)
!1266 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !1267)
!1267 = !{!1268, !1269, !1270}
!1268 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !1266, file: !126, line: 12, baseType: !114, size: 64)
!1269 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !1266, file: !126, line: 12, baseType: !52, size: 16)
!1270 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !1266, file: !126, line: 12, baseType: !170, size: 64)
!1271 = !DILocation(line: 12, column: 2, scope: !1264)
!1272 = !DILocation(line: 12, column: 2, scope: !1273)
!1273 = distinct !DILexicalBlock(scope: !1264, file: !126, line: 12, column: 2)
!1274 = !DILocation(line: 12, column: 2, scope: !1275)
!1275 = distinct !DILexicalBlock(scope: !1244, file: !126, line: 12, column: 2)
!1276 = !DILocation(line: 12, column: 2, scope: !1277)
!1277 = distinct !DILexicalBlock(scope: !1278, file: !126, line: 12, column: 2)
!1278 = distinct !DILexicalBlock(scope: !1279, file: !126, line: 12, column: 2)
!1279 = distinct !DILexicalBlock(scope: !1275, file: !126, line: 12, column: 2)
!1280 = !DILocation(line: 12, column: 2, scope: !1278)
!1281 = !DILocalVariable(name: "__x86_stack_delta", scope: !1282, file: !126, line: 12, type: !84)
!1282 = distinct !DILexicalBlock(scope: !1277, file: !126, line: 12, column: 2)
!1283 = !DILocation(line: 12, column: 2, scope: !1282)
!1284 = !{i64 2149643511}
!1285 = !DILocation(line: 12, column: 2, scope: !1279)
!1286 = !DILocation(line: 12, column: 2, scope: !1287)
!1287 = distinct !DILexicalBlock(scope: !1288, file: !126, line: 12, column: 2)
!1288 = distinct !DILexicalBlock(scope: !1279, file: !126, line: 12, column: 2)
!1289 = !DILocation(line: 12, column: 2, scope: !1288)
!1290 = !DILocation(line: 12, column: 2, scope: !1291)
!1291 = distinct !DILexicalBlock(scope: !1287, file: !126, line: 12, column: 2)
!1292 = !DILocalVariable(name: "__kprog_x86_partial", scope: !1293, file: !126, line: 12, type: !1294)
!1293 = distinct !DILexicalBlock(scope: !1287, file: !126, line: 12, column: 2)
!1294 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !1295)
!1295 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !134, file: !126, line: 12, size: 64, elements: !1296)
!1296 = !{!1297, !1298, !1299}
!1297 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !1295, file: !126, line: 12, baseType: !114, size: 64)
!1298 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !1295, file: !126, line: 12, baseType: !52, size: 16)
!1299 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !1295, file: !126, line: 12, baseType: !170, size: 64)
!1300 = !DILocation(line: 12, column: 2, scope: !1293)
!1301 = !DILocation(line: 12, column: 2, scope: !1302)
!1302 = distinct !DILexicalBlock(scope: !1275, file: !126, line: 12, column: 2)
!1303 = !DILocation(line: 12, column: 2, scope: !1304)
!1304 = distinct !DILexicalBlock(scope: !1302, file: !126, line: 12, column: 2)
!1305 = !DILocation(line: 12, column: 2, scope: !1306)
!1306 = distinct !DILexicalBlock(scope: !1304, file: !126, line: 12, column: 2)
!1307 = !DILocation(line: 12, column: 2, scope: !1308)
!1308 = distinct !DILexicalBlock(scope: !1302, file: !126, line: 12, column: 2)
!1309 = !DILocation(line: 12, column: 2, scope: !1310)
!1310 = distinct !DILexicalBlock(scope: !1308, file: !126, line: 12, column: 2)
!1311 = !DILabel(scope: !134, name: "x86_l_8", file: !126, line: 13)
!1312 = !DILocation(line: 13, column: 1, scope: !134)
!1313 = !DILocation(line: 15, column: 2, scope: !134)
!1314 = !DILocalVariable(name: "__x86_rd_reg", scope: !1315, file: !126, line: 15, type: !57)
!1315 = distinct !DILexicalBlock(scope: !1316, file: !126, line: 15, column: 2)
!1316 = distinct !DILexicalBlock(scope: !134, file: !126, line: 15, column: 2)
!1317 = !DILocation(line: 15, column: 2, scope: !1315)
!1318 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !1315, file: !126, line: 15, type: !57)
!1319 = !DILocalVariable(name: "__x86_rd_width", scope: !1315, file: !126, line: 15, type: !57)
!1320 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !1321)
!1321 = distinct !DILocation(line: 15, column: 2, scope: !1315)
!1322 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !1321)
!1323 = !DILocalVariable(name: "__x86_rd_shift", scope: !1315, file: !126, line: 15, type: !57)
!1324 = !DILocalVariable(name: "__x86_rd_ptr", scope: !1315, file: !126, line: 15, type: !114)
!1325 = !DILocalVariable(name: "__x86_rd_value", scope: !1315, file: !126, line: 15, type: !84)
!1326 = !DILocation(line: 15, column: 2, scope: !1327)
!1327 = distinct !DILexicalBlock(scope: !1315, file: !126, line: 15, column: 2)
!1328 = !DILocalVariable(name: "__x86_l_tag", scope: !1329, file: !126, line: 15, type: !57)
!1329 = distinct !DILexicalBlock(scope: !1330, file: !126, line: 15, column: 2)
!1330 = distinct !DILexicalBlock(scope: !1327, file: !126, line: 15, column: 2)
!1331 = !DILocation(line: 15, column: 2, scope: !1329)
!1332 = !DILocation(line: 15, column: 2, scope: !1333)
!1333 = distinct !DILexicalBlock(scope: !1329, file: !126, line: 15, column: 2)
!1334 = !DILocation(line: 15, column: 2, scope: !1330)
!1335 = !DILocalVariable(name: "__x86_stack_delta", scope: !1336, file: !126, line: 15, type: !84)
!1336 = distinct !DILexicalBlock(scope: !1330, file: !126, line: 15, column: 2)
!1337 = !DILocation(line: 15, column: 2, scope: !1336)
!1338 = !{i64 2149707871}
!1339 = !DILocation(line: 15, column: 2, scope: !1316)
!1340 = !DILabel(scope: !134, name: "x86_l_d", file: !126, line: 16)
!1341 = !DILocation(line: 16, column: 1, scope: !134)
!1342 = !DILocation(line: 18, column: 2, scope: !134)
!1343 = !DILocalVariable(name: "__x86_rd_reg", scope: !1344, file: !126, line: 18, type: !57)
!1344 = distinct !DILexicalBlock(scope: !1345, file: !126, line: 18, column: 2)
!1345 = distinct !DILexicalBlock(scope: !134, file: !126, line: 18, column: 2)
!1346 = !DILocation(line: 18, column: 2, scope: !1344)
!1347 = !DILocalVariable(name: "__x86_rd_raw_width", scope: !1344, file: !126, line: 18, type: !57)
!1348 = !DILocalVariable(name: "__x86_rd_width", scope: !1344, file: !126, line: 18, type: !57)
!1349 = !DILocation(line: 226, column: 54, scope: !657, inlinedAt: !1350)
!1350 = distinct !DILocation(line: 18, column: 2, scope: !1344)
!1351 = !DILocation(line: 228, column: 9, scope: !657, inlinedAt: !1350)
!1352 = !DILocalVariable(name: "__x86_rd_shift", scope: !1344, file: !126, line: 18, type: !57)
!1353 = !DILocalVariable(name: "__x86_rd_ptr", scope: !1344, file: !126, line: 18, type: !114)
!1354 = !DILocalVariable(name: "__x86_rd_value", scope: !1344, file: !126, line: 18, type: !84)
!1355 = !DILocation(line: 18, column: 2, scope: !1356)
!1356 = distinct !DILexicalBlock(scope: !1344, file: !126, line: 18, column: 2)
!1357 = !DILocalVariable(name: "__x86_l_tag", scope: !1358, file: !126, line: 18, type: !57)
!1358 = distinct !DILexicalBlock(scope: !1359, file: !126, line: 18, column: 2)
!1359 = distinct !DILexicalBlock(scope: !1356, file: !126, line: 18, column: 2)
!1360 = !DILocation(line: 18, column: 2, scope: !1358)
!1361 = !DILocation(line: 18, column: 2, scope: !1362)
!1362 = distinct !DILexicalBlock(scope: !1358, file: !126, line: 18, column: 2)
!1363 = !DILocation(line: 18, column: 2, scope: !1359)
!1364 = !DILocalVariable(name: "__x86_stack_delta", scope: !1365, file: !126, line: 18, type: !84)
!1365 = distinct !DILexicalBlock(scope: !1359, file: !126, line: 18, column: 2)
!1366 = !DILocation(line: 18, column: 2, scope: !1365)
!1367 = !{i64 2149716283}
!1368 = !DILocation(line: 18, column: 2, scope: !1345)
!1369 = !DILocation(line: 19, column: 1, scope: !134)
