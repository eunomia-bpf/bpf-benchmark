#define X86_SIM_STACK_VALUE_WORDS(M) M(0)
#define X86_SIM_STACK_VALUE_WORDS(M) M(0)
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/rsp-displacement/source/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: jmp    0 <entry> */
	X86_SIM_X86_JMP(0x0, 0x0, x86_l_0);
x86_l_2:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
