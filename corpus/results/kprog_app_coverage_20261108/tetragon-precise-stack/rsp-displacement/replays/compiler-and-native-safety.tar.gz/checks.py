from pathlib import Path
import os,select,subprocess
O=Path(__file__).parent;R=Path('/workspaces/repository');P=O.parent/'pushpop'
def wait_file(p):
 try:
  fd=os.pidfd_open(int(p.read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
wait_file(O/'run.pid')
with(O/'existing-hosts.log').open('w')as log:q=subprocess.run(['python3',str(O/'existing-hosts.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'existing-hosts-controller.exit').write_text(str(q.returncode)+'\n')
env=dict(os.environ,PATH=str(O/'bin')+':'+os.environ['PATH'])
with(O/'micro.log').open('w')as log:q=subprocess.run(['make','-C',str(R/'kprog/x86'),'micro-proofs-build','PROOF_BUILD_DIR='+str(O/'micro'),'NEGATIVE_NATIVE_BUILD_DIR='+str(O/'negative-native')],env=env,stdout=log,stderr=subprocess.STDOUT)
(O/'micro.exit').write_text(str(q.returncode)+'\n')
wait_file(P/'checks.pid')
with(O/'safety.log').open('w')as log:q=subprocess.run(['make','-f',str(O/'safety/Makefile'),'replay'],stdout=log,stderr=subprocess.STDOUT)
(O/'safety.exit').write_text(str(q.returncode)+'\n');(O/'checks.exit').write_text('0\n')
