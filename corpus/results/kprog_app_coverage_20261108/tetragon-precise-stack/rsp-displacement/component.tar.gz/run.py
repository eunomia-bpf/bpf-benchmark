from pathlib import Path
import subprocess,json,struct,time,hashlib,sys,os
from elftools.elf.elffile import ELFFile
O=Path(__file__).parent;R=Path('/workspaces/repository');T=O.parent
with(O/'mov-hosts.log').open('w')as log:q=subprocess.run(['python3',str(O/'mov-hosts.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'hosts.exit').write_text(str(q.returncode)+'\n')
# Reuse the complete original __success native object from the current canonical component.
source=O/'global-func2.c';before=T.parent.parent/'kernel-selftest-frontiers/global_func2/trusted_x86.bpf.c';source.write_text(before.read_text().replace(str(R/'kprog/x86/x86_sim_local_bpf.h'),str(O/'source/kprog/x86/x86_sim_local_bpf.h')))
rows=[]
for name,source in [('global-func2',source),('tetragon',O/'captured.c')]:
 obj=O/(name+'.bpf.o');cmd=['/usr/lib/llvm-18/bin/clang','-g','-O3','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_x86','-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(source),'-o',str(obj)];start=time.monotonic()
 with(O/(name+'.log')).open('w')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,exit=q.returncode,wall_seconds=time.monotonic()-start,sections=[])
 if q.returncode==0:
  with obj.open('rb')as f:
   for s in ELFFile(f).iter_sections():
    if s['sh_flags']&4 and s.data_size:
     ins=list(struct.iter_unpack('<BBhi',s.data()));row['sections'].append(dict(name=s.name,instructions=len(ins),maximum_fp_minus_offset=-min([0]+[o for c,r,o,i in ins if((r&15)==10 or(r>>4)==10)and o<0])))
 rows.append(row);(O/'observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
(O/'component.exit').write_text('0\n')
