from pathlib import Path
import subprocess,json,struct,time,hashlib
from elftools.elf.elffile import ELFFile
O=Path(__file__).parent
with (O/'hosts.log').open('w')as log:
 q=subprocess.run(['python3',str(O/'hosts.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'host-controller.exit').write_text(str(q.returncode)+'\n')
t=time.monotonic()
with (O/'component.log').open('w')as log:
 q=subprocess.run(['make','-f',str(O/'Makefile'),'component'],stdout=log,stderr=subprocess.STDOUT)
(O/'component.exit').write_text(str(q.returncode)+'\n')
rows=[]
if q.returncode==0:
 with(O/'captured.bpf.o').open('rb')as f:
  for s in ELFFile(f).iter_sections():
   if s['sh_flags']&4 and s.data_size:
    ins=list(struct.iter_unpack('<BBhi',s.data()));rows.append(dict(name=s.name,instructions=len(ins),maximum_fp_minus_offset=-min([0]+[o for c,r,o,i in ins if((r&15)==10 or(r>>4)==10)and o<0])))
(O/'observations.json').write_text(json.dumps(dict(exit=q.returncode,wall_seconds=time.monotonic()-t,sections=rows,native_sha256=hashlib.sha256((O.parent/'request.native.o').read_bytes()).hexdigest(),model_sha256=hashlib.sha256((O/'source/kprog/x86/x86_sim_local_bpf.h').read_bytes()).hexdigest()),indent=2)+'\n')
(O/'run.exit').write_text('0\n')
