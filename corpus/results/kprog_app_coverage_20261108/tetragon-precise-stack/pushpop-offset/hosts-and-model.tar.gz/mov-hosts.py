from pathlib import Path
import subprocess,json
O=Path(__file__).parent;R=Path('/workspaces/repository');rows=[]
for name in ['named-host','named-host-liveness']:
 command=['cc','-O2','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-Wno-attributes','-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/src'),str(O/(name+'.c')),str(O/'native-mov.S'),'-o',str(O/name)]
 with(O/(name+'.compile.log')).open('w')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=command,compile_exit=q.returncode)
 if q.returncode==0:
  with(O/(name+'.run.log')).open('w')as log:q=subprocess.run([str(O/name)],stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(O/'mov-hosts.json').write_text(json.dumps(rows,indent=2)+'\n')
(O/'mov-hosts.exit').write_text('0\n')
