from pathlib import Path
import subprocess,json
P=Path(__file__).parent;R=Path('/workspaces/repository');rows=[]
fixtures=[('host',P/'host.c')]
for name in ['test_x86_pushpop_host.c','test_x86_pushpop_route_host.c']:
 p=R/'kprog/formal/oracles'/name;s=p.read_text().replace('#include "../x86/x86_sim_local_bpf.h"','#include '+json.dumps(str(P/'source/kprog/x86/x86_sim_local_bpf.h')));(P/name).write_text(s);fixtures.append((p.stem,P/name))
for name,source in fixtures:
 command=['cc','-O2','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-Wno-attributes','-I'+str(R/'kprog/formal'),'-I'+str(R/'kprog/formal/oracles'),'-I'+str(R/'kprog/x86'),'-I'+str(R/'kprog'),'-I'+str(R/'vendor/libbpf/src'),str(source)]
 if name in ['host','baseline-host']:command+=[str(P/'native.S')]
 command+=['-o',str(P/name)]
 with(P/(name+'.compile.log')).open('w')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=command,compile_exit=q.returncode)
 if q.returncode==0:
  with(P/(name+'.run.log')).open('w')as log:q=subprocess.run([str(P/name)],stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(P/'hosts.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
(P/'hosts.exit').write_text('0\n')
