from pathlib import Path
import shutil
T=Path(__file__).parent;R=Path('/workspaces/repository');N=T.parent.parent/'stack-spill-values';P=T/'pushpop';P.mkdir(exist_ok=True);shutil.copytree(N/'source',P/'source',dirs_exist_ok=True)
p=P/'source/kprog/x86/x86_sim_local_bpf.h';s=p.read_text();(P/'before.h').write_text(s)
start=s.index('/* Operand-sized transfers. POP increments old RSP')
helpers=r'''/* Pointer representatives follow the same native stack bytes through PUSH
 * and POP, including memory operands and their old/new RSP address rules. */
#define X86_SIM_L_STACK_MEMORY_VALUE(BASE, DISP, WIDTH) \
    ({ struct x86_sim_stack_value __x86_sm_value={}; \
       if ((BASE)==X86_RSP) \
           __x86_sm_value=X86_SIM_L_STACK_VALUES_READ(X86_SIM_L_STACK_INDEX( \
               (__s64)(long)X86_SIM_L_READ_REG_PTR(BASE)+(DISP)),(WIDTH)); \
       else if (X86_SIM_L_REG_TAG(BASE)==X86_SIM_TAG_STACK) \
           __x86_sm_value=X86_SIM_L_STACK_VALUES_READ((__u64)(long)X86_SIM_L_READ_REG_PTR(BASE)+ \
               (__u64)(DISP)-(__u64)(long)&__x86_stack_mem.b[0],(WIDTH)); \
       __x86_sm_value; })
#define X86_SIM_L_STACK_MEMORY_SAVE(BASE, DISP, WIDTH, SAVED, VALUE) \
    do { struct x86_sim_stack_value __x86_sm_saved=(SAVED); \
         void *__x86_sm_ptr=__x86_sm_saved.tag==X86_SIM_TAG_STACK ? \
             __x86_sm_saved.pointer : (void *)(long)(VALUE); \
         if ((BASE)==X86_RSP) \
             X86_SIM_L_STACK_VALUES_SAVE(X86_SIM_L_STACK_INDEX( \
                 (__s64)(long)X86_SIM_L_READ_REG_PTR(BASE)+(DISP)), \
                 (WIDTH),__x86_sm_ptr,__x86_sm_saved.tag); \
         else if (X86_SIM_L_REG_TAG(BASE)==X86_SIM_TAG_STACK) \
             X86_SIM_L_STACK_VALUES_SAVE((__u64)(long)X86_SIM_L_READ_REG_PTR(BASE)+ \
                 (__u64)(DISP)-(__u64)(long)&__x86_stack_mem.b[0], \
                 (WIDTH),__x86_sm_ptr,__x86_sm_saved.tag); \
    } while(0)

'''
s=s[:start]+helpers+s[start:]
a=s.index('#define X86_SIM_L_EXEC_PUSH_POP_STEP(');b=s.index('#define X86_SIM_L_EXEC_PUSH(SRC, FLAGS)',a);x=s[a:b]
needle='\t\t\t__u64 __x86_l_pp_value = X86_SIM_L_READ_REG(SRC); \\\n';assert x.count(needle)==1
x=x.replace(needle,needle+'''            __u8 __x86_l_pp_tag=(SRC)==X86_RSP ? X86_SIM_TAG_STACK : X86_SIM_L_REG_TAG(SRC); \\
            void *__x86_l_pp_pointer=(SRC)==X86_RSP ? \\
                X86_SIM_L_STACK_PTR((__s64)(long)X86_SIM_L_READ_REG_PTR(SRC)) : X86_SIM_L_READ_REG_PTR(SRC); \\
''')
needle='\t\t\t\t__x86_l_pp_width, __x86_l_pp_value);      \\\n';assert x.count(needle)==1
x=x.replace(needle,needle+'''            X86_SIM_L_STACK_VALUES_SAVE(X86_SIM_L_STACK_INDEX((__s64)(long)__x86_rsp.ptr), \\
                __x86_l_pp_width,__x86_l_pp_pointer,__x86_l_pp_tag); \\
''',1)
needle='\t\t\t__x86_rsp.ptr =                                   \\\n\t\t\t\tKPROG_PTR_ADD64_BITS(__x86_rsp.ptr, __x86_l_pp_step);'
assert x.count(needle)==1
x=x.replace(needle,'''            struct x86_sim_stack_value __x86_l_pp_saved=X86_SIM_L_STACK_VALUES_READ( \\
                X86_SIM_L_STACK_INDEX((__s64)(long)__x86_rsp.ptr),__x86_l_pp_width); \\
'''+needle)
needle='\t\t\tX86_SIM_L_WRITE_REG_WIDTH((DST),                  \\\n\t\t\t\t__x86_l_pp_value, __x86_l_pp_width);'
assert x.count(needle)==1
x=x.replace(needle,'''            if (__x86_l_pp_width==X86_WIDTH_64 && (DST)!=X86_RSP && \\
                __x86_l_pp_saved.tag!=X86_SIM_TAG_SCALAR) \\
                X86_SIM_L_WRITE_REG_PTR_TAG((DST),__x86_l_pp_saved.tag==X86_SIM_TAG_STACK ? \\
                    __x86_l_pp_saved.pointer : (void *)(long)__x86_l_pp_value,__x86_l_pp_saved.tag); \\
            else \\
'''+needle)
s=s[:a]+x+s[b:]
a=s.index('#define X86_SIM_L_EXEC_PUSH_OP(');b=s.index('#define X86_SIM_L_EXEC_POP_OP(',a);x=s[a:b]
needle='\t\t\t__x86_rsp.ptr = KPROG_PTR_ADD64_BITS(__x86_rsp.ptr, -(__u64)KPROG_X86_PUSH_STEP_BYTES(__x86_pp_width));'
assert x.count(needle)==1
x=x.replace(needle,'''            struct x86_sim_stack_value __x86_pp_saved={}; \\
            if (X86_PUSHPOP_AUX_MODE(AUX)==2U) \\
                __x86_pp_saved=X86_SIM_L_STACK_MEMORY_VALUE((SRC), \\
                    X86_SIM_L_MEM_OFFSET((AUX),x86_simm(IMM)),__x86_pp_width); \\
'''+needle)
needle='\t\t\t\t__x86_pp_width, __x86_pp_value);            \\\n';assert x.count(needle)==1
x=x.replace(needle,needle+'''            X86_SIM_L_STACK_VALUES_SAVE(X86_SIM_L_STACK_INDEX((__s64)(long)__x86_rsp.ptr), \\
                __x86_pp_width,__x86_pp_saved.tag==X86_SIM_TAG_STACK ? \\
                __x86_pp_saved.pointer : (void *)(long)__x86_pp_value,__x86_pp_saved.tag); \\
''');s=s[:a]+x+s[b:]
a=s.index('#define X86_SIM_L_EXEC_POP_OP(');b=s.index('#define X86_SIM_L_EXEC_PTR_LOAD(',a);x=s[a:b]
needle='\t\t\t__x86_rsp.ptr = KPROG_PTR_ADD64_BITS(__x86_rsp.ptr, (__u64)KPROG_X86_PUSH_STEP_BYTES(__x86_pp_width));'
assert x.count(needle)==1
x=x.replace(needle,'''            struct x86_sim_stack_value __x86_pp_saved=X86_SIM_L_STACK_VALUES_READ( \\
                X86_SIM_L_STACK_INDEX((__s64)(long)__x86_rsp.ptr),__x86_pp_width); \\
'''+needle)
x=x.replace('X86_SIM_L_STORE_ADDR((__u8 *)X86_SIM_L_READ_REG_PTR(DST) +','X86_SIM_L_STORE_ADDR_TAGGED((__u8 *)X86_SIM_L_READ_REG_PTR(DST) +')
lines=x.splitlines(keepends=True)
i=next(i for i,line in enumerate(lines)if 'X86_SIM_L_STORE_ADDR_TAGGED('in line)
lines[i+1]=lines[i+1].replace('__x86_pp_value);','__x86_pp_value,X86_SIM_L_REG_TAG(DST));')
lines.insert(i+2,'            X86_SIM_L_STACK_MEMORY_SAVE((DST),__x86_pp_disp,__x86_pp_width, \\\n                __x86_pp_saved,__x86_pp_value); \\\n')
x=''.join(lines)
s=s[:a]+x+s[b:];p.write_text(s)
source=(T/'generated/trusted_x86.bpf.c').read_text().replace(str(R/'kprog/x86/x86_sim_local_bpf.h'),str(p));(P/'captured.c').write_text(source)
