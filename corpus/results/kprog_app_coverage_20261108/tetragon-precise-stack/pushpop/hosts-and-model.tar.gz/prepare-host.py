from pathlib import Path
P=Path(__file__).parent;N=P.parent.parent.parent/'stack-spill-values'
s=(N/'host.c').read_text();prefix=s[:s.index('static unsigned long cases;')].replace(str(N/'source'),str(P/'source'))
prefix+='extern void native_rsp_spill(__u64 out[3],unsigned width,long delta);\n'
body=r'''
static unsigned long cases;
static int run(unsigned source,unsigned dest,unsigned helper,unsigned overwrite)
{
    static const unsigned widths[]={0,1,2,4,8};
    static const long disps[]={0,0,7,-4,0};
    unsigned width=widths[overwrite];long delta=disps[overwrite];
    __u64 native[3];
    if(source==1)native_rsp_spill(native,width,delta);
    else native_stack_spill(native,width,delta);
    X86_SIM_ENTRY_RAW((void*)0);
    __x86_native_stack_base=native[1];
    X86_SIM_L_EXEC_ALU_IMM(X86_RSP,X86_WIDTH_64,X86_ALU_SUB,64);
    X86_SIM_L_EXEC_LEA(X86_RAX,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),16);
    void *saved=source==1?X86_SIM_L_STACK_PTR(-64):X86_SIM_L_READ_REG_PTR(X86_RAX);
    X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),16);
    X86_SIM_L_EXEC_LEA(X86_RBP,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),32);
    if(source==0)X86_SIM_L_EXEC_PUSH(X86_RAX,X86_WIDTH_64);
    else if(source==1)X86_SIM_L_EXEC_PUSH(X86_RSP,X86_WIDTH_64);
    else if(source==2)X86_SIM_L_EXEC_PUSH_OP(X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0)|X86_PUSHPOP_AUX_MEM,16);
    else{
        X86_SIM_L_EXEC_LEA(X86_R8,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),16);
        X86_SIM_L_EXEC_PUSH_OP(X86_R8,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0)|X86_PUSHPOP_AUX_MEM,0);
    }
    if(X86_SIM_L_READ_REG(X86_RSP)!=native[1]-72||X86_SIM_L_STACK_READ(-72,8)!=native[0])return 1;
    if(width){
        X86_SIM_L_EXEC_MOV_IMM(X86_RCX,X86_WIDTH_64,0xaabbccddeeff0011ULL);
        X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RCX,width,X86_MEM_AUX(X86_REG_NONE,0),delta);
    }
    if(helper==1)X86_SIM_L_HELPER_READONLY_POINTER_RESULT((void*)0);
    if(helper==2)X86_SIM_L_HELPER_SCALAR_RESULT(0);
    __x86_cf=1;__x86_zf=0;__x86_sf=1;__x86_of=0;
    if(dest==0)X86_SIM_L_EXEC_POP(X86_RDX,X86_WIDTH_64);
    else if(dest==1)X86_SIM_L_EXEC_POP(X86_RSP,X86_WIDTH_64);
    else if(dest==2){
        X86_SIM_L_EXEC_POP_OP(X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0)|X86_PUSHPOP_AUX_MEM,32);
        X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),32);
    }else{
        X86_SIM_L_EXEC_POP_OP(X86_RBP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0)|X86_PUSHPOP_AUX_MEM,0);
        X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RBP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),0);
    }
    unsigned target=dest==1?X86_RSP:X86_RDX;
    if(X86_SIM_L_READ_REG(target)!=native[2])return 2;
    int overlap=width&&delta<8&&delta+(long)width>0;
    unsigned tag=dest==1||overlap||helper==2?X86_SIM_TAG_SCALAR:X86_SIM_TAG_STACK;
    if(X86_SIM_L_REG_TAG(target)!=tag)return 3;
    if(tag==X86_SIM_TAG_STACK&&X86_SIM_L_READ_REG_PTR(target)!=saved)return 4;
    if(dest!=1&&X86_SIM_L_READ_REG(X86_RSP)!=native[1]-64)return 5;
    if(__x86_cf!=1||__x86_zf!=0||__x86_sf!=1||__x86_of!=0)return 6;
    cases++;return 0;
}
int main(void)
{
    for(unsigned s=0;s<4;s++)for(unsigned d=0;d<4;d++)for(unsigned h=0;h<3;h++)for(unsigned o=0;o<5;o++){
        int rc=run(s,d,h,o);
        if(rc){printf("push/pop source%u dest%u helper%u overwrite%u rc%d\n",s,d,h,o,rc);return 1;}
    }
    printf("native pointer PUSH/POP value/representation lanes: %lu cases, 0 differences\n",cases);return 0;
}
'''
(P/'host.c').write_text(prefix+body)
asm=(N/'native.S').read_text();rsp=asm.replace('native_stack_spill','native_rsp_spill').replace('lea 16(%rsp),%rax','lea 0(%rsp),%rax').replace('.L','.Lrsp');(P/'native.S').write_text(asm+rsp)
base=P/'source/kprog/x86/baseline.h';base.write_bytes((P/'before.h').read_bytes());(P/'baseline-host.c').write_text((prefix+body).replace(str(P/'source/kprog/x86/x86_sim_local_bpf.h'),str(base)))
