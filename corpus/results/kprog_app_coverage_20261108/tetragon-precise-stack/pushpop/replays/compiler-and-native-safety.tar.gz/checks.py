from pathlib import Path
import os,select,subprocess,json
P=Path(__file__).parent;R=Path('/workspaces/repository');G=P.parent.parent.parent/'stack-spill-values/canonical-runtime'
def wait_file(name):
 try:
  fd=os.pidfd_open(int(name.read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
wait_file(P/'component.pid')
env=dict(os.environ,PATH=str(P/'bin')+':'+os.environ['PATH'])
with(P/'micro.log').open('w')as log:q=subprocess.run(['taskset','-c','8-11','make','-C',str(R/'kprog/x86'),'micro-proofs-build','PROOF_BUILD_DIR='+str(P/'micro'),'NEGATIVE_NATIVE_BUILD_DIR='+str(P/'negative-native')],env=env,stdout=log,stderr=subprocess.STDOUT)
(P/'micro.exit').write_text(str(q.returncode)+'\n')
wait_file(G/'queue-next.pid')
with(P/'safety.log').open('w')as log:q=subprocess.run(['make','-f',str(P/'safety/Makefile'),'replay'],stdout=log,stderr=subprocess.STDOUT)
(P/'safety.exit').write_text(str(q.returncode)+'\n');(P/'checks.exit').write_text('0\n')
