#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1)
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1)
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/pushpop/source/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_4:
	/* 0x4: mov    QWORD PTR [rsp],0x25 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 37ULL);
x86_l_c:
	/* 0xc: mov    rax,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSP, X86_WIDTH_64);
x86_l_f:
	/* 0xf: mov    ecx,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11:
	/* 0x11: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15:
	/* 0x15: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_18:
	/* 0x18: jne    24 <entry+0x24> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18, 0x24, x86_l_24);
x86_l_1a:
	/* 0x1a: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1f:
	/* 0x1f: jmp    2e <entry+0x2e> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_24:
	/* 0x24: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_29:
	/* 0x29: jmp    2e <entry+0x2e> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2e:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
