from pathlib import Path
import shutil
T=Path(__file__).parent;R=Path('/workspaces/repository');N=T.parent.parent/'stack-spill-values';A=T/'alias';A.mkdir(exist_ok=True)
shutil.copytree(N/'source',A/'source',dirs_exist_ok=True);p=A/'source/kprog/x86/x86_sim_local_bpf.h';s=p.read_text();(A/'before.h').write_text(s)
# Preserve the native address/width/raw byte accesses. Ghost slots use the
# original pre-opacity expression, whose bits equal the actual raw address.
a=s.index('#define X86_SIM_L_EXEC_MOV_LOAD(');b=s.index('#define X86_SIM_L_EXEC_STORE(',a);x=s[a:b];old='(__u64)(long)__x86_l_addr-(__u64)(long)&__x86_stack_mem.b[0],__x86_l_mem_width);';new='(__u64)(long)__x86_l_base_ptr+(__u64)__x86_l_meta_disp-(__u64)(long)&__x86_stack_mem.b[0],__x86_l_mem_width);';assert x.count(old)==1;x=x.replace(old,new);s=s[:a]+x+s[b:]
a=s.index('#define X86_SIM_L_EXEC_STORE(');b=s.index('#define X86_SIM_L_EXEC_MOVBE_LOAD(',a);x=s[a:b]
x=x.replace('(__u64)(long)__x86_l_addr-(__u64)(long)&__x86_stack_mem.b[0]', '(__u64)(long)__x86_l_base_ptr+(__u64)__x86_l_meta_disp-(__u64)(long)&__x86_stack_mem.b[0]')
needle='                X86_SIM_L_STACK_VALUES_ERASE((__u64)(long)__x86_l_base_ptr+(__u64)__x86_l_meta_disp-(__u64)(long)&__x86_stack_mem.b[0],__x86_l_width); \\\n';assert x.count(needle)==1
x=x.replace(needle,needle+'            else if (X86_SIM_L_REG_TAG(DST)==X86_SIM_TAG_SCALAR) X86_SIM_L_STACK_VALUES_CLEAR(); \\\n')
x=x.replace('X86_SIM_L_STORE_ADDR_TAGGED(__x86_l_addr, \\\n                    __x86_l_width,__x86_l_value,X86_SIM_L_REG_TAG(DST))','KPROG_X86_MEM_STORE(__x86_l_addr, \\\n                    __x86_l_width,__x86_l_value)')
s=s[:a]+x+s[b:]
# LEA is pure native address arithmetic. Its pointer-shaped representation
# can retain that same offset before opacity; no memory access is removed.
a=s.index('#define X86_SIM_L_EXEC_LEA(');b=s.index('/* Classic ROR',a);x=s[a:b];needle='\t\t\tX86_SIM_L_BARRIER_VAR(__x86_l_off);';assert x.count(needle)==1;x=x.replace(needle,'            __s64 __x86_l_meta_off=__x86_l_off; \\\n'+needle)
x=x.replace('(__s64)((__u64)(unsigned long)__x86_l_src_ptr + (__u64)__x86_l_off)','(__s64)((__u64)(unsigned long)__x86_l_src_ptr + (__u64)__x86_l_meta_off)')
x=x.replace('__x86_l_src_ptr, __x86_l_off);','__x86_l_src_ptr, __x86_l_meta_off);')
s=s[:a]+x+s[b:];p.write_text(s)
source=(T/'generated/trusted_x86.bpf.c').read_text().replace(str(R/'kprog/x86/x86_sim_local_bpf.h'),str(p));(A/'captured.c').write_text(source)
for name in ['host.c','host-liveness.c']:(A/name).write_text((N/name).read_text().replace(str(N/'source'),str(A/'source')))
shutil.copy2(N/'native.S',A/'native.S')
