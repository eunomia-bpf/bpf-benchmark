#define __BPF_HELPERS__ 1
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 128U
typedef unsigned char __u8; typedef unsigned short __u16;
typedef unsigned int __u32; typedef unsigned long long __u64;
typedef signed char __s8; typedef short __s16;
typedef signed int __s32; typedef signed long long __s64;
#define __always_inline inline
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15)
#include "/workspaces/repository/kprog/formal/oracles/x86_helper_environment_host.h"
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-precise-stack/alias/source/kprog/x86/x86_sim_local_bpf.h"
#undef X86_SIM_L_ENTRY_STACK_BASE
#define X86_SIM_L_ENTRY_STACK_BASE() native[1]
#include <stdio.h>
#include <string.h>
extern void native_stack_spill(__u64 out[3],unsigned width,long delta);
static unsigned long cases;
static int run(unsigned width,long delta,unsigned alias,unsigned helper)
{
    __u64 native[3];native_stack_spill(native,width,delta);
    X86_SIM_ENTRY_RAW((void*)0);
    __x86_native_stack_base=native[1];
    X86_SIM_L_EXEC_ALU_IMM(X86_RSP,X86_WIDTH_64,X86_ALU_SUB,64);
    X86_SIM_L_EXEC_LEA(X86_RAX,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),16);
    void *saved=X86_SIM_L_READ_REG_PTR(X86_RAX);
    X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),48);
    if(X86_SIM_L_STACK_READ(-16,8)!=native[0])return 1;
    if(width){
        X86_SIM_L_EXEC_MOV_IMM(X86_RCX,X86_WIDTH_64,0xaabbccddeeff0011ULL);
        if(alias){
            X86_SIM_L_EXEC_LEA(X86_RBP,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),48+delta);
            X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RBP,X86_RCX,width,X86_MEM_AUX(X86_REG_NONE,0),0);
        }else X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RCX,width,X86_MEM_AUX(X86_REG_NONE,0),48+delta);
    }
    if(helper==1)X86_SIM_L_HELPER_READONLY_POINTER_RESULT((void*)0);
    if(helper==2)X86_SIM_L_HELPER_SCALAR_RESULT(0);
    __x86_cf=1;__x86_zf=0;__x86_sf=1;__x86_of=0;
    X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),48);
    if(X86_SIM_L_READ_REG(X86_RDX)!=native[2])return 2;
    int overlap=width && delta<8 && delta+(long)width>0;
    unsigned tag=overlap||helper==2?X86_SIM_TAG_SCALAR:X86_SIM_TAG_STACK;
    if(X86_SIM_L_REG_TAG(X86_RDX)!=tag)return 3;
    if(tag==X86_SIM_TAG_STACK && X86_SIM_L_READ_REG_PTR(X86_RDX)!=saved)return 4;
    if(__x86_cf!=1||__x86_zf!=0||__x86_sf!=1||__x86_of!=0)return 5;
    cases++;return 0;
}
int main(void)
{
    for(unsigned repeat=0;repeat<128;repeat++)for(unsigned alias=0;alias<2;alias++)for(unsigned h=0;h<3;h++){
        int rc=run(0,0,alias,h);if(rc){printf("spill base rc%d\n",rc);return 1;}
        for(unsigned width=1;width<=8;width*=2)for(long delta=-8;delta<=8;delta++){
            rc=run(width,delta,alias,h);
            if(rc){printf("spill rc%d w%u delta%ld alias%u helper%u\n",rc,width,delta,alias,h);return 1;}
        }
    }
    printf("native stack spill/value lanes: %lu cases, 0 differences\n",cases);return 0;
}
