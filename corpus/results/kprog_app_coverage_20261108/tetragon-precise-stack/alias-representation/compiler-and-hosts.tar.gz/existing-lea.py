from pathlib import Path
import subprocess,json
A=Path(__file__).parent;R=Path('/workspaces/repository');rows=[]
for name in ['test_x86_lea_handler_host.c','test_x86_lea_route_host.c']:
 p=R/'kprog/formal/oracles'/name;s=p.read_text().replace('#include "../x86/x86_sim_local_bpf.h"','#include '+json.dumps(str(A/'source/kprog/x86/x86_sim_local_bpf.h')));source=A/name;source.write_text(s);exe=A/p.stem
 command=['cc','-O2','-g','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(R/'kprog/formal'),'-I'+str(R/'kprog/formal/oracles'),'-I'+str(R/'kprog/x86'),'-I'+str(R/'kprog'),'-I'+str(R/'vendor/libbpf/src'),str(source),'-o',str(exe)]
 with(A/(p.stem+'.compile.log')).open('w')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=command,compile_exit=q.returncode)
 if q.returncode==0:
  with(A/(p.stem+'.run.log')).open('w')as log:q=subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);print(row,flush=True)
(A/'lea-outcomes.json').write_text(json.dumps(rows,indent=2)+'\n')
