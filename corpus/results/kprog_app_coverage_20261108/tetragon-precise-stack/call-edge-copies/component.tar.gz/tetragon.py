from pathlib import Path
import subprocess,time,json,struct
from elftools.elf.elffile import ELFFile
O=Path(__file__).parent;R=Path('/workspaces/repository');source=O/'tetragon-after.c';obj=O/'tetragon-after.bpf.o'
command=['/usr/lib/llvm-18/bin/clang','-g','-O3','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_x86','-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(source),'-o',str(obj)];start=time.monotonic()
with(O/'tetragon.compile.log').open('w')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
row=dict(command=command,exit=q.returncode,wall_seconds=time.monotonic()-start,sections=[])
if q.returncode==0:
 with obj.open('rb')as f:
  for s in ELFFile(f).iter_sections():
   if s['sh_flags']&4 and s.data_size:
    ins=list(struct.iter_unpack('<BBhi',s.data()));row['sections'].append(dict(name=s.name,instructions=len(ins),maximum_fp_minus_offset=-min([0]+[o for c,r,o,i in ins if((r&15)==10 or(r>>4)==10)and o<0])))
(O/'tetragon.json').write_text(json.dumps(row,indent=2)+'\n');(O/'tetragon.exit').write_text(str(q.returncode)+'\n');print(row,flush=True)
