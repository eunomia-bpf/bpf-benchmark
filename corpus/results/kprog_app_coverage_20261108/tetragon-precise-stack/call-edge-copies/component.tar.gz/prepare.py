from pathlib import Path
import re,json,sys
R=Path('/workspaces/repository');O=Path(__file__).parent;T=O.parent/'remaining-apps/tetragon-precise-stack';K=O.parent/'kernel-selftest-frontiers/global_func2'
def copy_edges(s):
 marks=list(re.finditer(r'\t/\* native subroutine ([^\n]+) \*/\n',s));end=s.index('x86_sim_ret_dispatch:\n');bodies={}
 for i,m in enumerate(marks):
  body=s[m.start():marks[i+1].start()if i+1<len(marks)else end];labels=re.findall(r'^x86_l_([0-9a-f]+):',body,re.M)
  if labels:bodies[labels[0]]=(body,labels,('x86_l_'+re.search(r'^x86_l_([0-9a-f]+):',s[marks[i+1].start():],re.M)[1]if i+1<len(marks)else'x86_sim_ret_dispatch'))
 call=re.compile(r'X86_SIM_X86_CALL\(x86_l_([0-9a-f]+), (0x[0-9a-f]+ULL)\)')
 keys=sorted({(m[1],m[2])for m in call.finditer(s)if m[1]in bodies})
 def label(target,ret):return'x86_copy_'+ret[2:-3]+'_'+target+'_l_'+target
 def calls(body):return call.sub(lambda m:'X86_SIM_X86_CALL('+label(m[1],m[2])+', '+m[2]+')'if(m[1],m[2])in keys else m[0],body)
 clones=[]
 for target,ret in keys:
  body,labels,fallthrough=bodies[target];prefix='x86_copy_'+ret[2:-3]+'_'+target+'_l_';body=calls(body);body=re.sub(r'\bx86_l_([0-9a-f]+)\b',lambda m:prefix+m[1]if m[1]in labels else m[0],body)
  clones.append(body+'\tgoto '+fallthrough+';\n')
 out=calls(s);point=out.index('x86_sim_ret_dispatch:\n');return out[:point]+'\n'.join(clones)+'\n'+out[point:],dict(copies=len(keys),original_native_labels=len(re.findall(r'^x86_l_',s,re.M)))
rows=[]
for name,source in [('global-func2',K/'trusted_x86.bpf.c'),('tetragon',T/'generated/trusted_x86.bpf.c')]:
 s=source.read_text();(O/(name+'-before.c')).write_text(s);out,meta=copy_edges(s);(O/(name+'-after.c')).write_text(out);rows.append(dict(name=name,**meta))
# RAW host entry retains upstream context bytes while the kernel compiler components retain their original entry ABI.
sys.path.insert(0,str(R/'kprog/x86/micro-prog'));import generate_micro_sim_proofs as gen
entry,subs,exit_addr,rodata=gen.parse_native_linked_program('trusted_x86',K)
s=gen.render_program('trusted_x86',entry,subs,kind='raw',exit_addr=exit_addr,rodata16=rodata,program_section='tc').replace('#include "../x86_sim_local_bpf.h"','#include '+json.dumps(str(R/'kprog/x86/x86_sim_local_bpf.h')))
(O/'host-before.c').write_text(s);(O/'host-after.c').write_text(copy_edges(s)[0]);(O/'copy-layout.json').write_text(json.dumps(rows,indent=2)+'\n')
(O/'host-environment.h').write_text('#include <linux/bpf.h>\n#define __always_inline inline\n#include "'+str(R/'kprog/formal/oracles/x86_helper_environment_host.h')+'"\n#define SEC(NAME)\n')
(O/'host-driver.c').write_text(r"""#include <linux/bpf.h>
#include <stdio.h>
#include <string.h>
extern int global_func2(struct __sk_buff *);
extern int trusted_x86_x86_sim_xdp(void *);
int main(void){
 const unsigned v[]={0,1,2,3,7,255,256,65535,65536,0x7fffffff,0x80000000,0xfffffffe,0xffffffff};unsigned cases=0;
 for(unsigned a=0;a<sizeof(v)/sizeof(v[0]);a++)for(unsigned b=0;b<sizeof(v)/sizeof(v[0]);b++){
  struct __sk_buff ctx;memset(&ctx,0,sizeof ctx);ctx.len=v[a];ctx.ifindex=v[b];unsigned expected=global_func2(&ctx),actual=trusted_x86_x86_sim_xdp(&ctx);
  if(expected!=actual){printf("len%u ifindex%u expected%u actual%u\n",ctx.len,ctx.ifindex,expected,actual);return 1;}cases++;
 }
 printf("original native C global_func2 and generated RAW entry: %u cases, 0 differences\n",cases);return 0;
}
""")
print(rows)
