from pathlib import Path
import os,subprocess
O=Path(__file__).parent;R=Path('/workspaces/repository');env=dict(os.environ,PATH=str(O/'bin')+':'+os.environ['PATH'])
with(O/'micro.log').open('w')as log:q=subprocess.run(['make','-C',str(R/'kprog/x86'),'micro-proofs-build','PROOF_BUILD_DIR='+str(O/'micro'),'NEGATIVE_NATIVE_BUILD_DIR='+str(O/'negative-native')],env=env,stdout=log,stderr=subprocess.STDOUT)
(O/'micro.exit').write_text(str(q.returncode)+'\n')
