#define __BPF_HELPERS__ 1
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 128U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15)
#include <linux/bpf.h>
#include "/workspaces/repository/kprog/formal/oracles/x86_helper_environment_host.h"
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/helper-frame-origin/source/kprog/x86/x86_sim_local_bpf.h"
#undef X86_SIM_L_ENTRY_STACK_BASE
#define X86_SIM_L_ENTRY_STACK_BASE() 0ULL
#include <stdio.h>
static int run(long sp,unsigned helper){
 X86_SIM_ENTRY_RAW((void*)0);__x86_rsp.ptr=(void*)sp;
 for(long off=-128;off<=-8;off+=8)X86_SIM_L_STACK_VALUES_SAVE(X86_SIM_L_STACK_INDEX(off),8,X86_SIM_L_STACK_PTR(-16),X86_SIM_TAG_STACK);
 if(helper)X86_SIM_L_HELPER_READONLY_POINTER_RESULT((void*)0);else X86_SIM_L_HELPER_READONLY_SCALAR_RESULT(123);
 for(long off=-128;off<=-8;off+=8){
  struct x86_sim_stack_value v=X86_SIM_L_STACK_VALUES_READ(X86_SIM_L_STACK_INDEX(off),8);
  unsigned want=off<sp?X86_SIM_TAG_SCALAR:X86_SIM_TAG_STACK;
  if(v.tag!=want){printf("SP%ld slot%ld helper%u tag%u expected%u\n",sp,off,helper,v.tag,want);return 1;}
 }
 return 0;
}
int main(void){unsigned cases=0;for(long sp=-120;sp<=0;sp++)for(unsigned helper=0;helper<2;helper++){if(run(sp,helper))return 1;cases+=16;}printf("helper frame origin and every aligned word at byte-granular SP: %u cases, 0 differences\n",cases);return 0;}
