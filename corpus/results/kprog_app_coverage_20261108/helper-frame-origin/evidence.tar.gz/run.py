from pathlib import Path
import subprocess,json
O=Path(__file__).parent;R=Path('/workspaces/repository');rows=[]
for name in ['before','after']:
 cmd=['cc','-O2','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-Wno-attributes','-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/src'),str(O/(name+'.c')),'-o',str(O/name)]
 with(O/(name+'.compile.log')).open('w')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,compile_exit=q.returncode)
 if q.returncode==0:
  with(O/(name+'.run.log')).open('w')as log:q=subprocess.run([str(O/name)],stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(O/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
with(O/'mov-hosts.log').open('w')as log:q=subprocess.run(['python3',str(O/'mov-hosts.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'run.exit').write_text(str(q.returncode)+'\n')
