set -eu
D=/workspaces/.agent-state/kprog-lanes/C/proof-kfunc
trap 'echo $? > "$D/build.exit"' EXIT
cd /workspaces/repository
make -f "$D/Makefile" check
