#include "/workspaces/repository/kprog/libnativeloader/include/native_loader.hpp"
#include <bpf/bpf.h>
#include <bpf/libbpf.h>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <stdexcept>
using Object=std::unique_ptr<bpf_object,decltype(&bpf_object__close)>;
int main(int argc,char **argv)
{
    if (argc!=4) return 2;
    try {
        Object object(bpf_object__open_file(argv[1],nullptr),bpf_object__close);
        if (!object) throw std::runtime_error("open resource object failed");
        bpf_program *program=bpf_object__next_program(object.get(),nullptr);
        const auto type=bpf_program__type(program);
        bpf_program *p;
        bpf_object__for_each_program(p,object.get())
            if (bpf_program__set_autoload(p,false)) throw std::runtime_error("disable original program load failed");
        if (bpf_object__load(object.get())) throw std::runtime_error("load resource maps failed");
        native_loader::FdLoadOptions options{};
        bpf_prog_info context{};context.type=type;context.gpl_compatible=1;
        options.native_context=context;
        options.native_object_path=std::filesystem::absolute(argv[2]);options.symbol_name=argv[3];
        options.native_link_path="/workspaces/repository/kprog/x86/native_lab/native_link/target/debug/native-link";
        bpf_map *map;
        bpf_object__for_each_map(map,object.get()) {
            bpf_map_info info{};uint32_t size=sizeof(info);
            if (bpf_obj_get_info_by_fd(bpf_map__fd(map),&info,&size)) throw std::runtime_error("query resource map failed");
            options.trusted_maps.push_back({bpf_map__name(map),info.id,std::nullopt});
        }
        auto loaded=native_loader::load_from_fd(options);
        std::printf("native program id=%u source_prog_id=%u\n",loaded.native_prog_id,loaded.original_prog_id);
        native_loader::close_loaded_program(&loaded);
        if (std::fflush(stdout)) throw std::runtime_error("flush probe output failed");
    } catch (const std::exception &error) {
        std::fprintf(stderr,"raw-probe: %s\n",error.what());return 1;
    }
    return 0;
}
