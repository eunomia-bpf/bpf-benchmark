#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 32U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("tc")
int trusted_x86_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
x86_l_0:
	/* 0x0: jmp    40000000 <f1+0x3fffffbd> */
	X86_SIM_X86_JMP(0x0, 0x5, x86_l_5);
x86_l_40000014:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_5 */
x86_l_5:
	/* 0x5: jmp    40000005 <f1+0x3fffffc2> */
	X86_SIM_X86_SUB_JMP(0x5, 0xa, x86_l_a);

	/* native subroutine native_link_sub_a */
x86_l_a:
	/* 0xa: jmp    4000000a <f1+0x3fffffc7> */
	X86_SIM_X86_SUB_JMP(0xa, 0xf, x86_l_f);

	/* native subroutine native_link_sub_f */
x86_l_f:
	/* 0xf: jmp    4000000f <f1+0x3fffffcc> */
	X86_SIM_X86_SUB_JMP(0xf, 0x14, x86_l_14);

	/* native subroutine native_link_sub_14 */
x86_l_14:
	/* 0x14: mov    rsi,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RDI, X86_WIDTH_64);
x86_l_17:
	/* 0x17: mov    edi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 1ULL);
x86_l_1c:
	/* 0x1c: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_21:
	/* 0x21: jmp    40000014 <f1+0x3fffffd1> */
	X86_SIM_X86_SUB_JMP(0x21, 0x26, x86_l_26);

	/* native subroutine native_link_sub_26 */
x86_l_26:
	/* 0x26: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_27:
	/* 0x27: mov    ebx,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_32);
x86_l_29:
	/* 0x29: mov    edi,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RDX, X86_WIDTH_32);
x86_l_2b:
	/* 0x2b: call   26 <f3> */
	X86_SIM_X86_CALL(x86_l_34, 0x30ULL);
x86_l_30:
	/* 0x30: add    eax,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_32:
	/* 0x32: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33:
	/* 0x33: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_34 */
x86_l_34:
	/* 0x34: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_35:
	/* 0x35: mov    ebx,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_32);
x86_l_37:
	/* 0x37: mov    rdi,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_3a:
	/* 0x3a: call   34 <f2> */
	X86_SIM_X86_CALL(x86_l_43, 0x3fULL);
x86_l_3f:
	/* 0x3f: add    eax,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_41:
	/* 0x41: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_42:
	/* 0x42: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_43 */
x86_l_43:
	/* 0x43: mov    eax,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45:
	/* 0x45: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x30ULL: goto x86_l_30;
	case 0x3fULL: goto x86_l_3f;
	}

}

X86_SIM_LICENSE();
