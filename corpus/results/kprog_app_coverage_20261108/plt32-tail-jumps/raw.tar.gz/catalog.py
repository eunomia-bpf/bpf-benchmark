from pathlib import Path
import json,subprocess,hashlib,tarfile
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');D=Path(__file__).parent;O=D/'catalog';O.mkdir()
source=R/'kprog/selftests/build/programs.json';(O/'programs.json').write_bytes(source.read_bytes())
rows=[r for r in json.loads(source.read_text())['programs'] if r['body']=='c' and r.get('compiled') and r.get('entry')]
links=[('before',D/'native-link.before'),('after',R/'kprog/x86/native_lab/native_link/target/debug/native-link')]
results=[]
with tarfile.open(O/'native-inputs.tar.gz','w:gz') as inputs:
 for i,row in enumerate(rows):
  n=row['program'];native=Path(row['bpf_object'][:-6]+'.native.o');inputs.add(native,arcname=native.name)
  item=dict(row,native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),modes={})
  for mode,link in links:
   out=O/(str(i)+'-'+mode+'.proof.o');cmd=[str(link),'--input',str(native),'--symbol',n,'--mode','proof','--preserve-entry-abi','--output',str(out)]
   q=subprocess.run(cmd,cwd=R,text=True,capture_output=True);record=dict(command=cmd,exit=q.returncode,stdout=q.stdout,stderr=q.stderr)
   if q.returncode==0:
    with out.open('rb') as f:
     elf=ELFFile(f);record['text_bytes']=elf.get_section_by_name('.text').data_size
     record['functions']=[s.name for s in elf.get_section_by_name('.symtab').iter_symbols()if s['st_info']['type']=='STT_FUNC']
    record['proof_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
   item['modes'][mode]=record
  results.append(item);(O/'outcomes.json').write_text(json.dumps(results,indent=2)+'\n')
summary=dict(total=len(rows),linkers={mode:hashlib.sha256(p.read_bytes()).hexdigest() for mode,p in links},counts={mode:dict(generated=sum(r['modes'][mode]['exit']==0 for r in results),generation_failed=sum(r['modes'][mode]['exit']!=0 for r in results))for mode,_ in links},changed=[dict(program=r['program'],before={k:r['modes']['before'].get(k)for k in ['exit','text_bytes','functions']},after={k:r['modes']['after'].get(k)for k in ['exit','text_bytes','functions']})for r in results if any(r['modes']['before'].get(k)!=r['modes']['after'].get(k)for k in ['exit','text_bytes','functions','proof_sha256'])])
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
