#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 48U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("cgroup_skb/ingress")
int trusted_x86_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_4:
	/* 0x4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_7:
	/* 0x7: call   0 <global_func16> */
	X86_SIM_X86_CALL(x86_l_1e, 0xcULL);
x86_l_c:
	/* 0xc: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e:
	/* 0xe: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_10:
	/* 0x10: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_13:
	/* 0x13: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_15:
	/* 0x15: add    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_19:
	/* 0x19: jmp    2a <foo+0xc> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2a:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_1e */
x86_l_1e:
	/* 0x1e: test   rdi,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64);
x86_l_21:
	/* 0x21: je     27 <foo+0x9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x21, 0x27, x86_l_27);
x86_l_23:
	/* 0x23: mov    eax,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_26:
	/* 0x26: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_27:
	/* 0x27: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_29:
	/* 0x29: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0xcULL: goto x86_l_c;
	}

}

X86_SIM_LICENSE();
