from pathlib import Path
import sys,json,hashlib,subprocess,os
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');D=Path(__file__).parent
sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
link=R/'kprog/x86/native_lab/native_link/target/debug/native-link'
rows=[]
for n in [2,4,16]:
 name='global_func'+str(n); native=R/'kprog/selftests/build'/('test_global_func'+str(n)+'__'+name+'.native.o')
 row=dict(entry=name,native_sha256=hashlib.sha256(native.read_bytes()).hexdigest())
 out=D/'roundtrip'/name
 try:
  row['artifacts']=specialize(native.read_bytes(),name,dict(prog_type=3 if n<9 else 8,section='tc' if n<9 else 'cgroup_skb/ingress',maps=[]),out,link)
  for path in [native,out/'trusted_x86.proof.o']:
   p=subprocess.run(['objdump','-dr',str(path)],capture_output=True,text=True,check=True)
   (out/(path.name+'.disasm')).write_text(p.stdout+p.stderr)
  with (out/'trusted_x86.bpf.o').open('rb') as f:
   elf=ELFFile(f);row['sections']=[dict(name=s.name,instructions=s.data_size//8)for s in elf.iter_sections()if s['sh_flags']&4 and s.data_size]
  with (out/'trusted_x86.proof.o').open('rb') as f:
   elf=ELFFile(f);row['proof_symbols']=[dict(name=s.name,value=s['st_value'],size=s['st_size'])for s in elf.get_section_by_name('.symtab').iter_symbols()if s['st_info']['type']=='STT_FUNC'];row['text_bytes']=elf.get_section_by_name('.text').data_size
  cmd=[str(link),'--input',str(out/'trusted_x86.proof.o'),'--symbol',name,'--mode','kernel','--output',str(out/'native.bin'),'--show']
  done=subprocess.run(cmd,capture_output=True,text=True);(out/'kernel.stdout').write_text(done.stdout);(out/'kernel.stderr').write_text(done.stderr)
  row.update(kernel_command=cmd,kernel_exit=done.returncode,compile_exit=0)
 except Exception as e:row.update(compile_exit=1,error=str(e))
 rows.append(row);(D/'component.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)

raise SystemExit(int(any(r.get('compile_exit',1) or r.get('kernel_exit',1) for r in rows)))
