from pathlib import Path
import subprocess,os,sys,json,fcntl,tarfile,hashlib
R=Path('/workspaces/repository');D=Path(__file__).parent;S=D/'requests';S.mkdir(mode=0o700)
command=[sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(S),'--native-link',str(R/'kprog/x86/native_lab/native_link/target/debug/native-link'),'--loader','/workspaces/.agent-state/kprog-lanes/C/design-only/native-context/loader/trusted-native-loader']
service=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=(D/'service.stderr').open('w'),text=True)
log=[];rows=[]
try:
 line=service.stdout.readline();log.append(line);print(line,flush=True)
 for n in [4,8]:
  name='global_func'+str(n);stem=R/'kprog/selftests/build'/('test_global_func'+str(n)+'__'+name)
  cmd=[str(D/'probe'),str(stem)+'.bpf.o',str(stem)+'.native.o',name]
  q=subprocess.run(cmd,env=dict(os.environ,BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1'),capture_output=True,text=True)
  (D/(name+'.stdout')).write_text(q.stdout);(D/(name+'.stderr')).write_text(q.stderr)
  line=service.stdout.readline();log.append(line)
  row=dict(entry=name,expect='success',command=cmd,exit=q.returncode,request=json.loads(line),execution='load-only')
  rows.append(row);(D/'runtime.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:
 with (S/'request.lock').open('rb') as lock:fcntl.flock(lock,fcntl.LOCK_EX)
 service.terminate();tail=service.communicate()[0];log.append(tail);(D/'service.log').write_text(''.join(log))
