from pathlib import Path
import subprocess,json,datetime,traceback,tarfile,sys,hashlib
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/otel-native-size'
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 save('native_compile')
 with(G/'native.log').open('w')as f:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'native-mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'native.exit').write_text(str(p.returncode)+'\n')
 if p.returncode==0:
  save('generation')
  with(G/'generation.log').open('w')as f:q=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'generation-mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
  (G/'generation.exit').write_text(str(q.returncode)+'\n')
 result=dict(native_make_exit=p.returncode,source_edit='65e7f7a0b original4frame counted loop',native_policy='generic pre-submit -Os candidate, current production flags retained',model_source='0818f5677 current RAW/named helpers',native_executions=0,generation=json.loads((G/'generation-outcomes.json').read_text())if(G/'generation-outcomes.json').exists()else[]);O.mkdir(exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Native compile size policy before submission\n\nThis experiment compiles the entire original edited OTel native application with generic Os flags before P submission, using the existing native-division pass and all existing source/ABI options. The JIT baseline keeps the identical source65e7f7a0b. Every native byte/link/helper relocation is then input to normal trusted specialization; the current production compiler flags retain their definition. Identical original O3 P is also recompiled to B with the current RAW/named-helper model, separating compiler-policy and simulator-epoch effects. Actual native Makeexit'+str(result['native_make_exit'])+' and all generated C/B/backend frame observations are retained. Original2/O3-B measurement833b2e9df retains12803instructions/frame560 for both B levels. This measurement uses native executions0; actual stock-verifier/application outcomes follow the selected P epoch. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for x in G.iterdir():
   if x.name not in ['controller.log','status.json']:tf.add(x,arcname=x.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure generic native size policy before OTel submission',G/'publication.json');save('finished',commit=commit,**result)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/V/R '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' whole OTel native compile Os before submission, actual '+repr(result)+'. Current productionP/B flags retained; all actual P/C/B records retained. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
