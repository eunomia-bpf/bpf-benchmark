from pathlib import Path
import json,sys,traceback,hashlib,struct
from elftools.elf.elffile import ELFFile
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
out=[]
for label,native in [('original-O3-native-current-model',G/'original.native.o'),('Os-native-current-model',G/'native/otel/otelcol-ebpf-profiler.native.o')]:
 row=dict(label=label,native_sha256=hashlib.sha256(native.read_bytes()).hexdigest())
 try:
  result=specialize(native.read_bytes(),'perf_unwind_native',json.loads((G/'metadata.json').read_text()),G/label,R/'kprog/x86/native_lab/native_link/target/release/native-link');row['artifacts']=result;row['stage']='compiled';sections=[]
  with Path(result['simulator_object']).open('rb')as f:
   for s in ELFFile(f).iter_sections():
    if s['sh_flags']&4 and s['sh_size']:
     disps=[];d=s.data()
     for i in range(0,len(d),8):
      code,regs,off,imm=struct.unpack('<BBhi',d[i:i+8]);dst=regs&15;src=regs>>4
      if(code&7)in[1,2,3]and((src==10 and(code&7)==1)or(dst==10 and(code&7)in[2,3]))and off<0:disps.append(-off)
     sections.append(dict(name=s.name,instructions=len(d)//8,max_direct_frame_displacement=max(disps,default=0)))
  row['compiled_sections']=sections
 except Exception as e:row.update(stage='generation_or_compile_failure',error=str(e),traceback=traceback.format_exc())
 out.append(row);(G/'generation-outcomes.json').write_text(json.dumps(out,indent=2)+'\n');print(label,row['stage'],row.get('compiled_sections'),flush=True)
