from pathlib import Path
import subprocess,os
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
subprocess.run(['mount','--bind',str(G/'app-source'),str(R/'vendor/bpf/otel')],check=True)
os.execvp('make',['make','-f',str(G/'Makefile'),'native'])
