from pathlib import Path
import os,select,subprocess,json,tarfile,sys,datetime,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/remaining-apps/tracee-checked-offset';O=R/'corpus/results/kprog_app_coverage_20261108/raw-helper-context/safety'
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('queued_after_paired_tracee')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('running')
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n');rows=json.loads((G/'safety/outcomes.json').read_text());result=dict(make_exit=p.returncode,cases=len(rows),stages={s:sum(r['stage']==s for r in rows)for s in sorted({r['stage']for r in rows})},native_risk_executions=0);O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Original38 with RAW helper context identity\n\nActual stages '+repr(result)+'. Original native fixtures/annotations retain bytes. Positive controls use their original TEST_RUN comparison; risky inputs use load-only submission. Native risky executions0. Captured production source includes two RAW entry environment assignments, giving identity helper context translation. Complete native/C/B/compiler/verifier/request records accompany raw.tar.gz. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for name in ['source','safety','safety.py','Makefile','mount.py','controller.py','run.log','run.exit']:tf.add(G/name,arcname=name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(x.relative_to(R))for x in O.iterdir()if x.is_file()],'Record original38 with x86 raw helper context identity',G/'safety-publication.json');save('finished',commit=commit,**result)
 msg='\n- LOCAL C FOR A/V/R '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' original38 RAW entry source a808041cc actual '+repr(result)+'. Complete native/compiler/verifier records retained; runtime admission additions0.\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a')as f:f.write(msg)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
