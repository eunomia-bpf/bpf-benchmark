set -eu
D=/workspaces/.agent-state/kprog-lanes/C/cilium-dead-helper-runtime
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/C/cilium-dead-helper-runtime/Makefile corpus STATE="$D" CPUS=20-23 VM_CPUS=8 VM_MEM=12G APPS=cilium/agent SAMPLES=1 WORKLOAD_DURATION=2
