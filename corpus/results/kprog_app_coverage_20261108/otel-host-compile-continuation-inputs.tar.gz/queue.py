from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,shutil,os,select
R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');D=Path(__file__).parent
os.chdir(R);image='bpf-benchmark/kprog-otel-host-compile-continuation:c-20261108'
assert json.loads(subprocess.check_output(['docker','image','inspect','bpf-benchmark/kprog-native-only:x86-current']))[0]['Id']==json.loads((D/'base-image.json').read_text())['Id']
with (D/'build.log').open('wb') as log:
 q=subprocess.run(['docker','build','-f',str(D/'Dockerfile'),'-t',image,str(D)],stdout=log,stderr=subprocess.STDOUT);q.check_returncode()
(D/'image.json').write_bytes(subprocess.check_output(['docker','image','inspect',image]))
old=json.loads((C/'micro-wrapping-epoch/running-inputs.json').read_text());files=set(old['sha256'])|{'kprog/trusted_service.py','kprog/trusted_generation.py','kprog/x86/trusted_specializer.py','kprog/trusted_loader.cpp','kprog/libnativeloader/build/trusted-native-loader','kinsn/module/include/native_lab_group.h','kinsn/module/x86/bpf_x86_native_lab.c'}
files|={'kprog/trusted_compile.py'}
files|={str(p.relative_to(R)) for p in (R/'kprog/x86/micro-prog').glob('*.py')}
pins=dict(cpus='20-23',vcpus=8,guest_memory='12G',samples=1,duration=2,app='otelcol-ebpf-profiler/profiling',started=datetime.now(timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),image=json.loads((D/'image.json').read_text())[0]['Id'],sha256={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in sorted(files)})
for n in sorted(files):
 if n.endswith(('.py','.h','.cpp','.c','.rs')):
  p=D/'source-pins'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
(D/'private-inputs.json').write_text(json.dumps({n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in ['module.ko','native-link-readonly-c','guest.py','Makefile','Dockerfile','libnative_loader.so','trusted-native-loader','candidate.h','clang-candidate','read.h']},indent=2)+'\n')
with (D/'run.log').open('wb') as log:p=subprocess.Popen(['setsid','nohup','sh',str(D/'run.sh')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
pins['driver_pid']=p.pid;(D/'running-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
with (C.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL C whole otelcol-ebpf-profiler/profiling fresh host compiler replay:'+pins['started']+' driver'+str(p.pid)+',12GiB/eight vCPU/20-23,common c664565cc caller/linker/T57e6 module. Captured candidate inputs at '+str(D)+'; terminal archives record actual outcome.\n')
print('APPLICATION_STARTED',p.pid,flush=True);rc=p.wait()
with (D/'collect.log').open('wb') as log:q=subprocess.run(['python3',str(D/'collect.py')],stdout=log,stderr=subprocess.STDOUT)
(D/'collect.exit').write_text(str(q.returncode)+'\n');print('APPLICATION_CLOSED',rc,q.returncode,flush=True)
with (D/'image-retire.log').open('wb') as log:q=subprocess.run(['docker','image','rm',image],stdout=log,stderr=subprocess.STDOUT)
(D/'image-retire.exit').write_text(str(q.returncode)+'\n')
