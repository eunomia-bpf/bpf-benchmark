from pathlib import Path
import subprocess,re,json,hashlib
N=Path(__file__).parent;out={}
for name in ['cilium.before','cilium.baseline','cilium','tetragon.before','tetragon.baseline','tetragon']:
 p=N/(name+'.bpf.o')
 if not p.exists():continue
 s=subprocess.check_output(['llvm-objdump-18','-d',str(p)],text=True);offsets=[int(x,0) for x in re.findall(r'r10\s*-\s*(0x[0-9a-fA-F]+|[0-9]+)',s)];out[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'object_bytes':p.stat().st_size,'max_direct_frame_offset':max(offsets,default=0),'direct_accesses_beyond_512':sum(x>512 for x in offsets)}
(N/'frame-observations.json').write_text(json.dumps(out,indent=2)+'\n')
