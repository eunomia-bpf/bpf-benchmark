set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/flag-storage
trap 'echo $? > "$N/check.exit"' EXIT
taskset -c 8-11 make -f "$N/Makefile" host > "$N/host.log" 2>&1
for app in cilium tetragon; do
 taskset -c 8-11 make -f "$N/Makefile" "$app" > "$N/$app.compile.log" 2>&1
 python3 "$N/measure.py"
done
