set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/flag-storage
trap 'echo $? > "$N/baseline.exit"' EXIT
for app in cilium tetragon; do
 taskset -c 8-11 make -f "$N/Makefile" "$app-baseline" > "$N/$app.baseline.log" 2>&1
 python3 "$N/measure.py"
done
