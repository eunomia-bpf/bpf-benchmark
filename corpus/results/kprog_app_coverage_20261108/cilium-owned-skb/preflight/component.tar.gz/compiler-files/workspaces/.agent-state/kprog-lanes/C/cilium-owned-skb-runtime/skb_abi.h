/* Live native TC field projection through the kernel BPF context ABI. */
#if defined(__bpf__) || defined(__BPF__)
extern void *bpf_cast_to_kern_ctx(void *) __ksym;
#else
static inline void *bpf_cast_to_kern_ctx(void *ctx) { return ctx; }
#endif
extern __u64 x86_sim_unmapped_skb_read(void)
 __attribute__((error("native skb read requires a mapped ABI field")));
extern void x86_sim_unmapped_skb_write(void)
 __attribute__((error("native skb write requires a mapped ABI field")));
#define X86_SIM_L_LIVE_SKB() \
(__x86_sim_abi_kind == KPROG_ABI_KIND_SKB)

#define X86_SIM_L_SKB_OFFSET(BASE, OFF) \
((__s64)((__u64)(long)(BASE) - (__u64)(long)__x86_sim_helper_abi_base + (__u64)(OFF)))

#define X86_SIM_L_SKB_READ(BASE, OFF, WIDTH) \
({ __s64 __skb_off = X86_SIM_L_SKB_OFFSET((BASE),(OFF)); \
 struct __sk_buff *__skb_ctx = __x86_sim_helper_ctx; \
 __u64 __skb_value; \
 if ((WIDTH)==X86_WIDTH_64 && __skb_off==KPROG_ABI_SKB_DATA_OFF) \
  __skb_value=(__u64)(long)(void *)(long)__skb_ctx->data; \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==KPROG_ABI_SKB_DATA_END_OFF) \
  __skb_value=(__u64)(long)(void *)(long)__skb_ctx->data_end; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==48) __skb_value=__skb_ctx->cb[0]; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==52) __skb_value=__skb_ctx->cb[1]; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==56) __skb_value=__skb_ctx->cb[2]; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==60) __skb_value=__skb_ctx->cb[3]; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==64) __skb_value=__skb_ctx->cb[4]; \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==48) __skb_value=(__u64)__skb_ctx->cb[0]|((__u64)__skb_ctx->cb[1]<<32); \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==52) __skb_value=(__u64)__skb_ctx->cb[1]|((__u64)__skb_ctx->cb[2]<<32); \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==56) __skb_value=(__u64)__skb_ctx->cb[2]|((__u64)__skb_ctx->cb[3]<<32); \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==60) __skb_value=(__u64)__skb_ctx->cb[3]|((__u64)__skb_ctx->cb[4]<<32); \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==112) __skb_value=__skb_ctx->len; \
 else if ((WIDTH)==X86_WIDTH_16 && __skb_off==124) __skb_value=__skb_ctx->queue_mapping; \
 else if ((WIDTH)==X86_WIDTH_16 && __skb_off==134) __skb_value=__skb_ctx->tc_index; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==144) __skb_value=__skb_ctx->priority; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==148) __skb_value=__skb_ctx->ingress_ifindex; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==152) __skb_value=__skb_ctx->hash; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==168) __skb_value=__skb_ctx->mark; \
 else if ((WIDTH)==X86_WIDTH_16 && __skb_off==180) __skb_value=__skb_ctx->protocol; \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==32) __skb_value=__skb_ctx->tstamp; \
 else __skb_value=KPROG_X86_MEM_LOAD_FIXED((BASE),(OFF),(WIDTH)); \
 __skb_value; })

#define X86_SIM_L_SKB_WRITE(BASE, OFF, WIDTH, VALUE) \
do { __s64 __skb_off = X86_SIM_L_SKB_OFFSET((BASE),(OFF)); \
 struct __sk_buff *__skb_ctx=__x86_sim_helper_ctx; \
 __u64 __skb_value=(VALUE); \
 if ((WIDTH)==X86_WIDTH_32 && __skb_off==48) __skb_ctx->cb[0]=(__u32)__skb_value; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==52) __skb_ctx->cb[1]=(__u32)__skb_value; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==56) __skb_ctx->cb[2]=(__u32)__skb_value; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==60) __skb_ctx->cb[3]=(__u32)__skb_value; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==64) __skb_ctx->cb[4]=(__u32)__skb_value; \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==48) { __skb_ctx->cb[0]=(__u32)__skb_value; __skb_ctx->cb[1]=(__u32)(__skb_value>>32); } \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==52) { __skb_ctx->cb[1]=(__u32)__skb_value; __skb_ctx->cb[2]=(__u32)(__skb_value>>32); } \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==56) { __skb_ctx->cb[2]=(__u32)__skb_value; __skb_ctx->cb[3]=(__u32)(__skb_value>>32); } \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==60) { __skb_ctx->cb[3]=(__u32)__skb_value; __skb_ctx->cb[4]=(__u32)(__skb_value>>32); } \
 else if ((WIDTH)==X86_WIDTH_16 && __skb_off==124) __skb_ctx->queue_mapping=__skb_value; \
 else if ((WIDTH)==X86_WIDTH_16 && __skb_off==134) __skb_ctx->tc_index=__skb_value; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==144) __skb_ctx->priority=__skb_value; \
 else if ((WIDTH)==X86_WIDTH_32 && __skb_off==168) __skb_ctx->mark=__skb_value; \
 else if ((WIDTH)==X86_WIDTH_64 && __skb_off==32) __skb_ctx->tstamp=__skb_value; \
 else x86_sim_unmapped_skb_write(); \
} while (0)

