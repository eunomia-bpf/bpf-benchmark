from pathlib import Path
from datetime import datetime,timezone
from elftools.elf.elffile import ELFFile
import os,select,json,hashlib,tarfile,io,struct,subprocess,sys
R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');D=Path(__file__).parent;O=R/'corpus/results/kprog_app_coverage_20261108/cilium-owned-skb/preflight'
try:
 fd=os.pidfd_open(354295);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
rc=int((D/'preflight.exit').read_text());O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();obs=dict(compile_exit=rc,selected_skb_sha256=sha(D/'skb_abi.h'),selected_abi_sha256=sha(D/'abi_load.h'),selected_header_sha256=sha(D/'candidate.h'));inputs={}
if rc==0:
 with(D/'preflight.bpf.o').open('rb')as f:
  e=ELFFile(f);code=[i for section in e.iter_sections()if section['sh_flags']&4 for i in struct.iter_unpack('<BBhi',section.data())];frames=[off for c,r,off,imm in code if off<0 and((c&7)==1 and r>>4==10 or(c&7)in(2,3)and r&15==10)];di=e.get_dwarf_info();rows=[]
  for cu in di.iter_CUs():
   lp=di.line_program_for_CU(cu);base=Path(cu.get_top_DIE().attributes['DW_AT_comp_dir'].value.decode())
   for row in lp.header.file_names:
    p=Path(row.DW_LNCT_path.decode());directory=Path(lp.header.directories[row.DW_LNCT_directory_index].DW_LNCT_path.decode());p=(base/directory/p).resolve()if not p.is_absolute()else p;expected=bytes(row.DW_LNCT_MD5).hex();data=p.read_bytes();recovered=None
    if hashlib.md5(data).hexdigest()!=expected:
     assert p.is_relative_to(R),str(p)
     for co in subprocess.check_output(['git','log','--format=%H','--',str(p.relative_to(R))],text=True).splitlines():
      q=subprocess.run(['git','show',co+':'+str(p.relative_to(R))],capture_output=True)
      if q.returncode==0 and hashlib.md5(q.stdout).hexdigest()==expected:data=q.stdout;recovered=co;break
    assert hashlib.md5(data).hexdigest()==expected,str(p);inputs[str(p)]=data;rows.append(dict(path=str(p),md5=expected,sha256=hashlib.sha256(data).hexdigest(),recovered_from=recovered))
  assert str(D/'skb_abi.h')in inputs
  assert inputs[str(D/'skb_abi.h')]==(D/'skb_abi.h').read_bytes()
  assert all('tc-stack-successors/cilium__agent/skb_abi.h'not in p for p in inputs)
  obs.update(bpf_instructions=len(code),deepest_direct_frame_offset=min(frames,default=0),compiler_files=rows,source_sha256=sha(D/'preflight.bpf.c'),object_sha256=sha(D/'preflight.bpf.o'))
(D/'preflight-observations.json').write_text(json.dumps(obs,indent=2)+'\n')
with tarfile.open(O/'component.tar.gz','x:gz')as t:
 for n in ['preflight.bpf.c','preflight.bpf.o','preflight.sh','preflight.log','preflight.exit','preflight-observations.json','candidate.h','skb_abi.h','abi_load.h','helper.h','plan.json','publish-preflight.py']:
  if(D/n).exists():t.add(D/n,arcname=n)
 for n,data in inputs.items():
  m=tarfile.TarInfo('compiler-files/'+n.lstrip('/'));m.size=len(data);m.mtime=0;t.addfile(m,io.BytesIO(data))
obs['archive_sha256']=sha(O/'component.tar.gz');(O/'observations.json').write_text(json.dumps(obs,indent=2)+'\n')
text='# Whole Cilium TC source with cohort-owned includes\n\nThe complete original cil_from_host translation compiles with the selected cohort-owned skb and ABI headers. The actual DWARF source file entries and checksums appear in observations.json. Native skb data_len reads its actual field through the kernel context and the existing fixed-width load.\n\n' if rc==0 else '# Whole Cilium selected-header compiler outcome\n\nThe complete original cil_from_host translation reaches the compiler outcome recorded in observations.json. Full source and diagnostics are retained.\n\n'
text+='The archive preserves exact generated C/BPF, header/compiler-file snapshots, commands and logs. The queued whole application follows the active OTel continuation with its original native input, workload, kernel/module and caller. Actual terminal loading supplies kernel acceptance and runtime evidence.\n'
(O/'README.md').write_text(text)
sys.path.insert(0,str(C));from publish_owned import publish
before=sha(R/'.git/index');co=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'x86: compile Cilium through its selected native skb headers',D/'preflight-publication.json');assert before==sha(R/'.git/index')
with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C '+datetime.now(timezone.utc).isoformat()+': PUSHED '+co+' complete original Cilium TC selected-header compile exit '+str(rc)+'. Actual DWARF compiler files, source/object hashes and scoped skb identity captured. Whole application queue354296 follows OTel334148; native/workload/kernel/module/caller retained.\n')
print('PUSHED',co,obs,flush=True)
