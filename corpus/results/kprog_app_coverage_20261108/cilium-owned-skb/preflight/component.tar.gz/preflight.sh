set -eu
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/cilium-owned-skb-runtime
trap 'echo $? > "$D/preflight.exit"' EXIT
make -f /dev/stdin <<'MAKE'
.PHONY: check
D := /workspaces/.agent-state/kprog-lanes/C/cilium-owned-skb-runtime
check:
	/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c $(D)/preflight.bpf.c -o $(D)/preflight.bpf.o
MAKE
