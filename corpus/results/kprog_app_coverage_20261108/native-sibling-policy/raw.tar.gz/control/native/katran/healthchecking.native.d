/workspaces/.agent-state/kprog-lanes/C/design-only/native-sibling-policy/control/native/katran/healthchecking.native.o: \
  katran/katran/lib/bpf/healthchecking.c /usr/include/linux/if_ether.h \
  /usr/include/linux/types.h /usr/include/x86_64-linux-gnu/asm/types.h \
  /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
  /usr/include/x86_64-linux-gnu/asm/bitsperlong.h \
  /usr/include/asm-generic/bitsperlong.h \
  /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types_64.h \
  /usr/include/asm-generic/posix_types.h /usr/include/linux/ip.h \
  /usr/include/x86_64-linux-gnu/asm/byteorder.h \
  /usr/include/linux/byteorder/little_endian.h /usr/include/linux/swab.h \
  /usr/include/x86_64-linux-gnu/asm/swab.h /usr/include/linux/ipv6.h \
  /usr/include/linux/libc-compat.h /usr/include/linux/in6.h \
  /usr/include/linux/pkt_cls.h /usr/include/linux/pkt_sched.h \
  /usr/include/linux/const.h /usr/include/linux/string.h \
  /usr/include/string.h \
  /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
  /usr/include/features.h /usr/include/features-time64.h \
  /usr/include/x86_64-linux-gnu/bits/wordsize.h \
  /usr/include/x86_64-linux-gnu/bits/timesize.h \
  /usr/include/stdc-predef.h /usr/include/x86_64-linux-gnu/sys/cdefs.h \
  /usr/include/x86_64-linux-gnu/bits/long-double.h \
  /usr/include/x86_64-linux-gnu/gnu/stubs.h \
  /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
  /usr/lib/llvm-18/lib/clang/18/include/stddef.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h \
  /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
  /usr/include/strings.h /usr/include/linux/udp.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_common.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_helpers.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/encap_helpers.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_endian.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/balancer_consts.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/csum_helpers.h \
  /usr/include/linux/in.h /usr/include/linux/socket.h \
  /usr/lib/llvm-18/lib/clang/18/include/stdbool.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/healthchecking_helpers.h \
  /usr/include/linux/tcp.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/healthchecking_maps.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/healthchecking_consts.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/healthchecking_structs.h
