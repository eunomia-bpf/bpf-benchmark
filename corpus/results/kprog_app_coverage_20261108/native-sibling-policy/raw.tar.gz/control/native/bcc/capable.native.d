/workspaces/.agent-state/kprog-lanes/C/design-only/native-sibling-policy/control/native/bcc/capable.native.o: \
  bcc/libbpf-tools/capable.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/x86/vmlinux.h \
  /usr/include/bpf/bpf_helpers.h /usr/include/bpf/bpf_tracing.h \
  bcc/libbpf-tools/capable.h
