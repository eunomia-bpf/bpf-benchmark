/workspaces/.agent-state/kprog-lanes/C/design-only/native-sibling-policy/control/native/bcc/runqlat.native.o: \
  bcc/libbpf-tools/runqlat.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/x86/vmlinux.h \
  /usr/include/bpf/bpf_helpers.h /usr/include/bpf/bpf_core_read.h \
  /usr/include/bpf/bpf_tracing.h bcc/libbpf-tools/runqlat.h \
  bcc/libbpf-tools/bits.bpf.h bcc/libbpf-tools/maps.bpf.h \
  /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
  bcc/libbpf-tools/core_fixes.bpf.h
