/workspaces/.agent-state/kprog-lanes/C/design-only/native-sibling-policy/sibling/native/katran/xdp_root.native.o: \
  katran/katran/lib/bpf/xdp_root.c \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf.h \
  /usr/include/linux/types.h /usr/include/x86_64-linux-gnu/asm/types.h \
  /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
  /usr/include/x86_64-linux-gnu/asm/bitsperlong.h \
  /usr/include/asm-generic/bitsperlong.h \
  /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types_64.h \
  /usr/include/asm-generic/posix_types.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_common.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_helpers.h
