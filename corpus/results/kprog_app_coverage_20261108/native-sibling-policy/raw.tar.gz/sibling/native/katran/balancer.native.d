/workspaces/.agent-state/kprog-lanes/C/design-only/native-sibling-policy/sibling/native/katran/balancer.native.o: \
  katran/katran/lib/bpf/balancer.c /usr/include/linux/in.h \
  /usr/include/linux/types.h /usr/include/x86_64-linux-gnu/asm/types.h \
  /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
  /usr/include/x86_64-linux-gnu/asm/bitsperlong.h \
  /usr/include/asm-generic/bitsperlong.h \
  /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types.h \
  /usr/include/x86_64-linux-gnu/asm/posix_types_64.h \
  /usr/include/asm-generic/posix_types.h \
  /usr/include/linux/libc-compat.h /usr/include/linux/socket.h \
  /usr/include/x86_64-linux-gnu/asm/byteorder.h \
  /usr/include/linux/byteorder/little_endian.h /usr/include/linux/swab.h \
  /usr/include/x86_64-linux-gnu/asm/swab.h /usr/include/linux/ip.h \
  /usr/include/linux/ipv6.h /usr/include/linux/in6.h \
  /usr/lib/llvm-18/lib/clang/18/include/stdbool.h \
  /usr/lib/llvm-18/lib/clang/18/include/stddef.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_ptrdiff_t.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_max_align_t.h \
  /usr/lib/llvm-18/lib/clang/18/include/__stddef_offsetof.h \
  /usr/include/string.h \
  /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
  /usr/include/features.h /usr/include/features-time64.h \
  /usr/include/x86_64-linux-gnu/bits/wordsize.h \
  /usr/include/x86_64-linux-gnu/bits/timesize.h \
  /usr/include/stdc-predef.h /usr/include/x86_64-linux-gnu/sys/cdefs.h \
  /usr/include/x86_64-linux-gnu/bits/long-double.h \
  /usr/include/x86_64-linux-gnu/gnu/stubs.h \
  /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
  /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
  /usr/include/strings.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_common.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_helpers.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/jhash.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/balancer_consts.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/balancer_helpers.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/balancer_structs.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/control_data_maps.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/csum_helpers.h \
  /usr/include/linux/udp.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/linux_includes/bpf_endian.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/introspection.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/balancer_maps.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/handle_icmp.h \
  /usr/include/linux/icmp.h /usr/include/linux/if.h \
  /usr/include/x86_64-linux-gnu/sys/socket.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h \
  /usr/include/x86_64-linux-gnu/bits/socket.h \
  /usr/include/x86_64-linux-gnu/sys/types.h \
  /usr/include/x86_64-linux-gnu/bits/types.h \
  /usr/include/x86_64-linux-gnu/bits/typesizes.h \
  /usr/include/x86_64-linux-gnu/bits/time64.h \
  /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/timer_t.h \
  /usr/include/x86_64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
  /usr/include/x86_64-linux-gnu/bits/endian.h \
  /usr/include/x86_64-linux-gnu/bits/endianness.h \
  /usr/include/x86_64-linux-gnu/bits/byteswap.h \
  /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
  /usr/include/x86_64-linux-gnu/sys/select.h \
  /usr/include/x86_64-linux-gnu/bits/select.h \
  /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
  /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
  /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
  /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
  /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
  /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
  /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h \
  /usr/include/x86_64-linux-gnu/bits/socket_type.h \
  /usr/include/x86_64-linux-gnu/bits/sockaddr.h \
  /usr/include/x86_64-linux-gnu/asm/socket.h \
  /usr/include/asm-generic/socket.h \
  /usr/include/x86_64-linux-gnu/asm/sockios.h \
  /usr/include/asm-generic/sockios.h \
  /usr/include/x86_64-linux-gnu/bits/types/struct_osockaddr.h \
  /usr/include/linux/hdlc/ioctl.h /usr/include/linux/icmpv6.h \
  /usr/include/linux/if_ether.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/pckt_encap.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/encap_helpers.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/flow_debug.h \
  /workspaces/repository/vendor/bpf/katran/katran/lib/bpf/pckt_parsing.h \
  /usr/include/linux/ptrace.h /usr/include/x86_64-linux-gnu/asm/ptrace.h \
  /usr/include/x86_64-linux-gnu/asm/ptrace-abi.h \
  /usr/include/x86_64-linux-gnu/asm/processor-flags.h \
  /usr/include/linux/const.h /usr/include/linux/tcp.h
