/workspaces/.agent-state/kprog-lanes/C/design-only/native-sibling-policy/sibling/native/bcc/opensnoop.native.o: \
  bcc/libbpf-tools/opensnoop.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/x86/vmlinux.h \
  /usr/include/bpf/bpf_helpers.h bcc/libbpf-tools/opensnoop.h
