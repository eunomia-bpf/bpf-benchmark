__attribute__((section("license"), used))
char __only_license[] = "GPL";
#include <vmlinux.h>
#include <bpf_helpers.h>
#include "/workspaces/repository/vendor/linux-framework/tools/testing/selftests/bpf/bpf_kfuncs.h"
#include "/workspaces/repository/vendor/linux-framework/tools/testing/selftests/bpf/progs/test_global_func6.c"
