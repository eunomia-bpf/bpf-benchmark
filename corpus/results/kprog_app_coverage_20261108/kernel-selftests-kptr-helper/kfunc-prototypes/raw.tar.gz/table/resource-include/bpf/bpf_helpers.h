#include_next <bpf/bpf_helpers.h>
#include "/workspaces/repository/vendor/linux-framework/tools/testing/selftests/bpf/bpf_kfuncs.h"
