from pathlib import Path
import importlib.util,json,shutil,hashlib
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');K=G.parent/'kernel-selftests-direct'
spec=importlib.util.spec_from_file_location('selftests',R/'kprog/selftests/selftests.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
table=G/'table';table.mkdir(exist_ok=True);j=json.loads((K/'table/programs.json').read_text());rows=j['programs'];files={r['file']:Path(r['path']) for r in rows if r['body']=='c' and r.get('compiled') and r.get('entry')};bpfdir=R/'vendor/linux-framework/tools/testing/selftests/bpf';includes=[bpfdir,bpfdir/'progs',R/'kprog/selftests/include',bpfdir/'tools/include',bpfdir/'tools/include/uapi',R/'vendor/libbpf/include/uapi',R/'vendor/libbpf/src',Path('/usr/include/x86_64-linux-gnu')];compiled={}
for name,p in sorted(files.items()):
 out=table/(p.stem+'.bpf.o');ok,err=m.compile_bpf(p,out,includes,'/usr/lib/llvm-18/bin/clang','x86');compiled[name]=dict(ok=ok,diagnostic=err,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),object=str(out) if ok else None);print(name,ok,flush=True)
for r in rows:
 if r['body']=='c' and r.get('compiled') and r.get('entry'):
  old=K/'table'/(Path(r['path']).stem+'__'+r['program']+'.native.o');shutil.copy2(old,table/old.name);r['bpf_object']=compiled[r['file']]['object'];r['bpf_error']=compiled[r['file']]['diagnostic']
(table/'programs.json').write_text(json.dumps(j,indent=2)+'\n');(G/'resource-compile.json').write_text(json.dumps(compiled,indent=2)+'\n')
