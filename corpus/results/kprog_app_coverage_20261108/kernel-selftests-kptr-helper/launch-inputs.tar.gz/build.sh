set -eu
cd /workspaces/repository
make -C vendor/linux-framework O=/workspaces/repository/kprog/tv/build-kernel-x86 M=/workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-kptr-helper/testmod-source MO=/workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-kptr-helper/testmod-build modules -j2
make -C kprog/libnativeloader trusted-service
make -f /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-kptr-helper/Makefile linker resources
