from pathlib import Path
import os,json,subprocess,tarfile,sys,datetime,traceback,gzip
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/kernel-selftests-kptr-helper'
sys.path.insert(0,str(C));from publish_owned import publish
def notice(s):
 msg='\n- LOCAL C FOR R/A/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': '+s+'\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a') as f:f.write(msg)
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 O.mkdir(exist_ok=True);(O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 (O/'README.md').write_text('# Original x86 kernel C replay with complete upstream resources\n\nThis successor reuses all239 original native entries and annotations from d56aade53. Each resource BPF object comes from the complete original source file, preserving full map pointee BTF. The exact upstream bpf_testmod builds against the sole paired x86 kernel cache through explicit O/M/MO directories. The warm canonical loader/linker include helper194 operation identity and address resolution. Every BPF program has autoload=false during maps/BTF creation, then native P/source_prog_id0 uses the five-step path. Every submission is load-only; native executions0.\n\nThe captured x86 header/generator includes c1f6 undefined PF/AF modeling, e600 default unresolved-return dispatch and a3e9812a3 named helper194 exchange body. Previous cohort5d1b36b70 retains all239 original outcomes; the three exchange compiler jobs now compile0 under that body. This complete successor records every actual stock-verifier or coverage stage after the extension. Native input objects retain the earlier compiler bytes, including original division operations. The kernel selftest source and38 safety fixtures retain their published bytes. launch.json retains all239 entry/object identities, every resource compilation result, and captured loader/module/producer source. Compiler differences for dynptr argument policy and misaligned_access_read width follow the coordinator decision alongside the raw agreement counts.\n\nCommand: `make -f /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/Makefile run`. The guest runs20-23/12GiB after the whole Cilium controller completes. Every resource/generation/compiler/verifier/installed stage remains in the table. Runtime admission additions0.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for name in ['launch.json','source','table','Makefile','mount.py','controller.py','testmod-source','testmod-build','resource-compile.json','resources.py','prepare.log','prepare.exit','prepare-status.json','build.sh']:tf.add(G/name,arcname=name)
 commit=publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run original x86 kernel C entries through direct native submission',G/'launch-publication.json');save('queued_after_cilium',launch_publication=commit);notice('PUSHED '+commit+' priority2a original239x86 native-entry successor queued20-23/12GiB after actual Cilium controller. Complete original resource BTF files39/38compiled, upstream paired bpf_testmod build0, current generic helper194 body/loader/linker, canonical c1f6/e600 model/generator captured. Original native/annotations retain bytes; allautoloadfalse/source0/loadonly. Runtime admission additions0.')
 import select
 Q=C/'design-only/remaining-apps/cilium-native-division-retry'
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('running',launch_publication=commit)
 with (G/'run.log').open('w') as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(G/'pycache')})
 (G/'run.exit').write_text(str(p.returncode)+'\n');report=dict(make_exit=p.returncode,native_execution_count=0);paths=[]
 q=G/'out/submissions.json'
 if q.exists():
  (O/'submissions.json').write_bytes(q.read_bytes());paths.append(O/'submissions.json');report['counts']=json.loads(q.read_text())['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
  for name in ['out','tmp','run.log','run.exit']:tf.add(G/name,arcname=name)
 paths.append(O/'raw.tar.gz');commit=publish([str(p.relative_to(R)) for p in paths],'Record original x86 kernel C direct native outcomes',G/'result-publication.json');save('finished',result_publication=commit,**report);notice('PUSHED '+commit+' original239x86 direct-native terminal '+json.dumps(report)+'. Every actual resource/generation/compiler/verifier/install row and native/B/maps/context retained; installed __failure rows supply simulator/compiler triage findings. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
