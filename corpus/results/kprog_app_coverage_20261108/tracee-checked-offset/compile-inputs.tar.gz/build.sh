set -eu
cd /workspaces/repository
mount --bind /workspaces/repository/vendor/bpf/tracee/pkg/ebpf/c /workspaces/repository/vendor/repos/tracee/pkg/ebpf/c
make -f /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-checked-offset/Makefile native baseline binary
