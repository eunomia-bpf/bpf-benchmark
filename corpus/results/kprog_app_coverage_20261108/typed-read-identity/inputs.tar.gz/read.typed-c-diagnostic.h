#ifndef KPROG_FORMAL_GENERATED_X86_REG_READ_H
#define KPROG_FORMAL_GENERATED_X86_REG_READ_H
#define KPROG_X86_READ_REG_AT(VALUE, WIDTH, BYTE_SHIFT) \
 ({ __u64 __read_value=(VALUE); __u64 __read_result; \
    if ((WIDTH)==X86_WIDTH_8) { \
      __u8 __narrow=(__u8)(__read_value >> (BYTE_SHIFT)); \
      __asm__("" : "+r"(__narrow)); __read_result=__narrow; \
    } else if ((WIDTH)==X86_WIDTH_16) { \
      __u16 __narrow=(__u16)__read_value; \
      __asm__("" : "+r"(__narrow)); __read_result=__narrow; \
    } else if ((WIDTH)==X86_WIDTH_32) { \
      __u32 __narrow=(__u32)__read_value; \
      __asm__("" : "+r"(__narrow)); __read_result=__narrow; \
    } else __read_result=__read_value; \
    __read_result; })
#endif
