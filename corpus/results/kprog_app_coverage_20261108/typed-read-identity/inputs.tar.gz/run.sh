set -eu
D=/workspaces/.agent-state/kprog-lanes/C/typed-read-identity
trap 'echo $? > "$D/checks.exit"' EXIT
cd /workspaces/repository
make -f "$D/Makefile" check actual
