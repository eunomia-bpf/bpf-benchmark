typedef unsigned long long __u64;typedef unsigned int __u32;typedef unsigned short __u16;typedef unsigned char __u8;
#define X86_WIDTH_8 1U
#define X86_WIDTH_16 2U
#define X86_WIDTH_32 4U
#define X86_WIDTH_64 8U
#include "read.h"
__u64 low8(__u64 a){return KPROG_X86_READ_REG_AT(a,1,0);}
__u64 high8(__u64 a){return KPROG_X86_READ_REG_AT(a,1,8);}
__u64 word(__u64 a){return KPROG_X86_READ_REG_AT(a,2,8);}
__u64 dword(__u64 a){return KPROG_X86_READ_REG_AT(a,4,8);}
__u64 qword(__u64 a){return KPROG_X86_READ_REG_AT(a,8,8);}
