set -eu
D=/workspaces/.agent-state/kprog-lanes/C/stack-fixed-offsets
cd /workspaces/repository
trap 'echo $? > "$D/checks.exit"' EXIT
/usr/lib/llvm-18/bin/clang -O3 -mcpu=v4 -target bpf -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/stack.c" -o "$D/stack.o"
cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/stack.c" -o "$D/host.o"
c++ -O2 -std=c++20 -fsanitize=undefined -fno-sanitize-recover=undefined -Ivendor/llvmbpf/include -Ivendor/llvmbpf/src "$D/run.cpp" "$D/host.o" runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o -L/usr/lib/llvm-18/lib -lLLVM-18 -lspdlog -lfmt -ldl -pthread -o "$D/check"
python3 "$D/extract.py"
"$D/check" "$D"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/tetragon.bpf.c" -o "$D/tetragon.bpf.o"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/otel.bpf.c" -o "$D/otel.bpf.o"
