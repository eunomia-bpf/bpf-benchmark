#include <llvmbpf.hpp>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
#include <string>
struct Input {uint64_t value,index,readback,second;uint8_t initial[64],arena[64];};
extern "C" uint64_t stack_0_0(Input*);
extern "C" uint64_t stack_0_1(Input*);
extern "C" uint64_t stack_0_2(Input*);
extern "C" uint64_t stack_0_3(Input*);
extern "C" uint64_t stack_0_4(Input*);
extern "C" uint64_t stack_0_5(Input*);
extern "C" uint64_t stack_0_6(Input*);
extern "C" uint64_t stack_0_7(Input*);
extern "C" uint64_t stack_0_8(Input*);
extern "C" uint64_t stack_1_0(Input*);
extern "C" uint64_t stack_1_1(Input*);
extern "C" uint64_t stack_1_2(Input*);
extern "C" uint64_t stack_1_3(Input*);
extern "C" uint64_t stack_1_4(Input*);
extern "C" uint64_t stack_1_5(Input*);
extern "C" uint64_t stack_1_6(Input*);
extern "C" uint64_t stack_1_7(Input*);
extern "C" uint64_t stack_1_8(Input*);
extern "C" uint64_t stack_2_0(Input*);
extern "C" uint64_t stack_2_1(Input*);
extern "C" uint64_t stack_2_2(Input*);
extern "C" uint64_t stack_2_3(Input*);
extern "C" uint64_t stack_2_4(Input*);
extern "C" uint64_t stack_2_5(Input*);
extern "C" uint64_t stack_2_6(Input*);
extern "C" uint64_t stack_2_7(Input*);
extern "C" uint64_t stack_2_8(Input*);
extern "C" uint64_t stack_4_0(Input*);
extern "C" uint64_t stack_4_1(Input*);
extern "C" uint64_t stack_4_2(Input*);
extern "C" uint64_t stack_4_3(Input*);
extern "C" uint64_t stack_4_4(Input*);
extern "C" uint64_t stack_4_5(Input*);
extern "C" uint64_t stack_4_6(Input*);
extern "C" uint64_t stack_4_7(Input*);
extern "C" uint64_t stack_4_8(Input*);
extern "C" uint64_t stack_8_0(Input*);
extern "C" uint64_t stack_8_1(Input*);
extern "C" uint64_t stack_8_2(Input*);
extern "C" uint64_t stack_8_3(Input*);
extern "C" uint64_t stack_8_4(Input*);
extern "C" uint64_t stack_8_5(Input*);
extern "C" uint64_t stack_8_6(Input*);
extern "C" uint64_t stack_8_7(Input*);
extern "C" uint64_t stack_8_8(Input*);
struct Case{const char* name;unsigned width,offset;uint64_t(*host)(Input*);};
Case cases[]={
{"stack_0_0",0,0,stack_0_0},
{"stack_0_1",0,1,stack_0_1},
{"stack_0_2",0,2,stack_0_2},
{"stack_0_3",0,3,stack_0_3},
{"stack_0_4",0,4,stack_0_4},
{"stack_0_5",0,5,stack_0_5},
{"stack_0_6",0,6,stack_0_6},
{"stack_0_7",0,7,stack_0_7},
{"stack_0_8",0,64,stack_0_8},
{"stack_1_0",1,0,stack_1_0},
{"stack_1_1",1,1,stack_1_1},
{"stack_1_2",1,2,stack_1_2},
{"stack_1_3",1,3,stack_1_3},
{"stack_1_4",1,4,stack_1_4},
{"stack_1_5",1,5,stack_1_5},
{"stack_1_6",1,6,stack_1_6},
{"stack_1_7",1,7,stack_1_7},
{"stack_1_8",1,64,stack_1_8},
{"stack_2_0",2,0,stack_2_0},
{"stack_2_1",2,1,stack_2_1},
{"stack_2_2",2,2,stack_2_2},
{"stack_2_3",2,3,stack_2_3},
{"stack_2_4",2,4,stack_2_4},
{"stack_2_5",2,5,stack_2_5},
{"stack_2_6",2,6,stack_2_6},
{"stack_2_7",2,7,stack_2_7},
{"stack_2_8",2,64,stack_2_8},
{"stack_4_0",4,0,stack_4_0},
{"stack_4_1",4,1,stack_4_1},
{"stack_4_2",4,2,stack_4_2},
{"stack_4_3",4,3,stack_4_3},
{"stack_4_4",4,4,stack_4_4},
{"stack_4_5",4,5,stack_4_5},
{"stack_4_6",4,6,stack_4_6},
{"stack_4_7",4,7,stack_4_7},
{"stack_4_8",4,64,stack_4_8},
{"stack_8_0",8,0,stack_8_0},
{"stack_8_1",8,1,stack_8_1},
{"stack_8_2",8,2,stack_8_2},
{"stack_8_3",8,3,stack_8_3},
{"stack_8_4",8,4,stack_8_4},
{"stack_8_5",8,5,stack_8_5},
{"stack_8_6",8,6,stack_8_6},
{"stack_8_7",8,7,stack_8_7},
{"stack_8_8",8,64,stack_8_8}};
int main(int argc,char**argv){if(argc!=2)return 2;std::string root=argv[1];std::ofstream bad(root+"/mismatches.jsonl");uint64_t total=0,fail=0;
for(auto &c:cases){std::ifstream in(root+"/"+c.name+".bin",std::ios::binary);std::vector<uint8_t>code((std::istreambuf_iterator<char>(in)),{});if(code.empty())return 3;
bpftime::llvmbpf_vm vm;if(vm.load_code(code.data(),code.size())<0||!vm.compile()){std::cerr<<vm.get_error_message()<<'\n';return 4;}
uint64_t state=0xfedcba9876543210ULL;
for(unsigned j=0;j<4096;++j){state=state*6364136223846793005ULL+1442695040888963407ULL;Input input{};input.value=j==0?0:j==1?~0ULL:state;unsigned width=c.width?c.width:8;input.index=j%(65-width);for(unsigned k=0;k<64;++k)input.initial[k]=uint8_t(state>>(8*(k%8)))^k;
Input host=input,jit=input,want=input;unsigned index=c.offset==64?input.index:c.offset;uint64_t value=0;memcpy(want.arena,input.initial,64);for(unsigned k=0;k<width;k++){uint8_t byte=input.value>>(8*k);want.arena[index+k]=byte;value|=uint64_t(byte)<<(8*k);}want.readback=want.second=value;
uint64_t got=1,hostret=c.host(&host);if(vm.exec(&jit,sizeof(jit),got)<0)return 5;
if(got||hostret||memcmp(&host,&want,sizeof(want))||memcmp(&jit,&want,sizeof(want))){++fail;bad<<"{\"form\":\""<<c.name<<"\",\"case\":"<<j<<",\"offset\":"<<index<<"}\n";}++total;}}
std::cout<<"stack offset actual BPF-JIT/host/independent byte oracle: "<<total<<" observations, differences="<<fail<<'\n';return fail?1:0;}
