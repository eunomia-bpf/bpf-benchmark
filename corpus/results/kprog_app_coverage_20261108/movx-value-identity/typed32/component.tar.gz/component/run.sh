set -eu
D=/workspaces/.agent-state/kprog-lanes/C/movx-value-identity/typed32
cd /workspaces/repository
trap 'echo $? > "$D/checks.exit"' EXIT
make -f /dev/stdin <<'MAKE'
.PHONY: check
D := /workspaces/.agent-state/kprog-lanes/C/movx-value-identity/typed32
check:
	cc -O2 -fsanitize=undefined -fno-sanitize-recover=all -Ikprog/x86 -Ikprog/formal -Ikprog/formal/oracles -Ivendor/libbpf/src -Ivendor/libbpf/include/uapi $(D)/movx-route.c -o $(D)/movx-route
	$(D)/movx-route
	/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c $(D)/tracee.bpf.c -o $(D)/tracee.bpf.o
MAKE
