from pathlib import Path
import subprocess,sys
D=Path(__file__).parent
if subprocess.run(['mountpoint','-q','/sys/kernel/debug']).returncode:
 subprocess.run(['mount','-t','debugfs','debugfs','/sys/kernel/debug'],check=True)
subprocess.run(['insmod',str(D/'module.ko')],check=True)
try:
 subprocess.run([sys.executable,str(D/'safety/check.py'),'check'],check=True)
finally:
 (D/'safety/kernel.log').write_bytes(subprocess.check_output(['dmesg']))
