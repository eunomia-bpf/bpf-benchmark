from pathlib import Path
from datetime import datetime,timezone
import subprocess,os,select,json,tarfile,sys,hashlib,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/remaining-apps/four-apps-undefined-flags-retry'
try:
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 pins={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [R/'kprog/x86/micro-prog/generate_micro_sim_proofs.py',R/'kprog/x86/x86_sim_local_bpf.h',R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage',R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko']};(G/'safety-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
 with(G/'safety.log').open('w')as log:q=subprocess.run(['make','-f',str(G/'Makefile'),'safety'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (G/'safety.exit').write_text(str(q.returncode)+'\n');rows=json.loads((G/'safety/outcomes.json').read_text());stages={s:sum(r['stage']==s for r in rows)for s in sorted(set(r['stage']for r in rows))};result=dict(utc=datetime.now(timezone.utc).isoformat(),make_exit=q.returncode,cases=len(rows),stages=stages,native_risk_executions=0,inputs=pins)
 O=R/'corpus/results/kprog_app_coverage_20261108/native-division-ret/safety';O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Existing native38 after the approved return-dispatch default\n\nThe original38native P/resource objects retain their bytes and actual DIV-fault cases. The canonical generator sends unmatched subroutine returns through the existing unresolved-indirect path. Exact x86#DE semantics stay in the simulator. Actual stages'+json.dumps(stages)+'; Makeexit'+str(q.returncode)+'. Risk native execution count0; the nine original positive controls retain their existing TEST_RUN comparison. Complete native/C/B/verifier/resource/request records are in raw.tar.gz.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for n in ['safety','safety.py','safety.log','safety.exit','safety-inputs.json','Makefile','safety-controller.py']:tf.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record native safety after total return dispatch',G/'safety-publication.json');msg='\n- LOCAL C FOR V/A/R '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' approvedreturn default existing38 actual'+json.dumps(result)+'. OriginalnativeP retained, zero riskexecution; exact#DE model retained.\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a')as f:f.write(msg)
except BaseException as e:(G/'safety-error.json').write_text(json.dumps(dict(error=str(e),traceback=traceback.format_exc()),indent=2));raise
