#include <stdint.h>
uint8_t u8q(uint8_t a, uint8_t b) { return a / b; }
uint8_t u8r(uint8_t a, uint8_t b) { return a % b; }
int8_t s8q(int8_t a, int8_t b) { return a / b; }
int8_t s8r(int8_t a, int8_t b) { return a % b; }
uint16_t u16q(uint16_t a, uint16_t b) { return a / b; }
uint16_t u16r(uint16_t a, uint16_t b) { return a % b; }
int16_t s16q(int16_t a, int16_t b) { return a / b; }
int16_t s16r(int16_t a, int16_t b) { return a % b; }
uint32_t u32q(uint32_t a, uint32_t b) { return a / b; }
uint32_t u32r(uint32_t a, uint32_t b) { return a % b; }
int32_t s32q(int32_t a, int32_t b) { return a / b; }
int32_t s32r(int32_t a, int32_t b) { return a % b; }
uint64_t u64q(uint64_t a, uint64_t b) { return a / b; }
uint64_t u64r(uint64_t a, uint64_t b) { return a % b; }
int64_t s64q(int64_t a, int64_t b) { return a / b; }
int64_t s64r(int64_t a, int64_t b) { return a % b; }
