#include <stdint.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
extern uint8_t u8q(uint8_t a, uint8_t b);
extern uint8_t u8r(uint8_t a, uint8_t b);
static void check_u8q(uint64_t a0, uint64_t b0) {
 uint8_t a=(uint8_t)a0,b=(uint8_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else {eq=a/b;er=a%b;}
 uint8_t aq=u8q(a,b),ar=u8r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"u8q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern int8_t s8q(int8_t a, int8_t b);
extern int8_t s8r(int8_t a, int8_t b);
static void check_s8q(uint64_t a0, uint64_t b0) {
 int8_t a=(int8_t)a0,b=(int8_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else if(a==INT8_MIN && b==-1) {eq=INT8_MIN;er=0;} else {eq=a/b;er=a%b;}
 int8_t aq=s8q(a,b),ar=s8r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"s8q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern uint16_t u16q(uint16_t a, uint16_t b);
extern uint16_t u16r(uint16_t a, uint16_t b);
static void check_u16q(uint64_t a0, uint64_t b0) {
 uint16_t a=(uint16_t)a0,b=(uint16_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else {eq=a/b;er=a%b;}
 uint16_t aq=u16q(a,b),ar=u16r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"u16q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern int16_t s16q(int16_t a, int16_t b);
extern int16_t s16r(int16_t a, int16_t b);
static void check_s16q(uint64_t a0, uint64_t b0) {
 int16_t a=(int16_t)a0,b=(int16_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else if(a==INT16_MIN && b==-1) {eq=INT16_MIN;er=0;} else {eq=a/b;er=a%b;}
 int16_t aq=s16q(a,b),ar=s16r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"s16q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern uint32_t u32q(uint32_t a, uint32_t b);
extern uint32_t u32r(uint32_t a, uint32_t b);
static void check_u32q(uint64_t a0, uint64_t b0) {
 uint32_t a=(uint32_t)a0,b=(uint32_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else {eq=a/b;er=a%b;}
 uint32_t aq=u32q(a,b),ar=u32r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"u32q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern int32_t s32q(int32_t a, int32_t b);
extern int32_t s32r(int32_t a, int32_t b);
static void check_s32q(uint64_t a0, uint64_t b0) {
 int32_t a=(int32_t)a0,b=(int32_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else if(a==INT32_MIN && b==-1) {eq=INT32_MIN;er=0;} else {eq=a/b;er=a%b;}
 int32_t aq=s32q(a,b),ar=s32r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"s32q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern uint64_t u64q(uint64_t a, uint64_t b);
extern uint64_t u64r(uint64_t a, uint64_t b);
static void check_u64q(uint64_t a0, uint64_t b0) {
 uint64_t a=(uint64_t)a0,b=(uint64_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else {eq=a/b;er=a%b;}
 uint64_t aq=u64q(a,b),ar=u64r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"u64q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

extern int64_t s64q(int64_t a, int64_t b);
extern int64_t s64r(int64_t a, int64_t b);
static void check_s64q(uint64_t a0, uint64_t b0) {
 int64_t a=(int64_t)a0,b=(int64_t)b0,eq,er;
 if (b==0) { eq=0;er=a; } else if(a==INT64_MIN && b==-1) {eq=INT64_MIN;er=0;} else {eq=a/b;er=a%b;}
 int64_t aq=s64q(a,b),ar=s64r(a,b);
 if(aq!=eq || ar!=er) {fprintf(stderr,"s64q a=%llu b=%llu q=%llu/%llu r=%llu/%llu\n",(unsigned long long)a0,(unsigned long long)b0,(unsigned long long)aq,(unsigned long long)eq,(unsigned long long)ar,(unsigned long long)er);exit(1);}
}

static uint64_t random_word(void) {static uint64_t x=0x154c4ead29ac7831ULL;x^=x<<13;x^=x>>7;x^=x<<17;return x;}
int main(void) { uint64_t edges[]={0,1,2,3,7,8,15,16,127,128,255,256,32767,32768,65535,65536,0x7fffffffULL,0x80000000ULL,0xffffffffULL,0x100000000ULL,0x7fffffffffffffffULL,0x8000000000000000ULL,0xffffffffffffffffULL}; unsigned long long n=0; for(unsigned i=0;i<sizeof(edges)/sizeof(*edges);i++)for(unsigned j=0;j<sizeof(edges)/sizeof(*edges);j++){uint64_t a=edges[i],b=edges[j];
check_u8q(a,b);n++;
check_s8q(a,b);n++;
check_u16q(a,b);n++;
check_s16q(a,b);n++;
check_u32q(a,b);n++;
check_s32q(a,b);n++;
check_u64q(a,b);n++;
check_s64q(a,b);n++;
} for(unsigned i=0;i<100000;i++){uint64_t a=random_word(),b=(i%4==0)?0:random_word();
check_u8q(a,b);n++;
check_s8q(a,b);n++;
check_u16q(a,b);n++;
check_s16q(a,b);n++;
check_u32q(a,b);n++;
check_s32q(a,b);n++;
check_u64q(a,b);n++;
check_s64q(a,b);n++;
} printf("native division/remainder: %llu operand pairs, %llu results OK\n",n,n*2);return 0;}
