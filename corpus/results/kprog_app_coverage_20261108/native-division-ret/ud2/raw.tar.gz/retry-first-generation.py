from pathlib import Path
import tarfile,json,subprocess,sys
G=Path(__file__).resolve().parent;H=G.parent/'cilium-native-division-retry';sys.path.insert(0,'/workspaces/repository/kprog')
from x86 import trusted_specializer as adapter
archive=next(H.glob('trusted-state-*/requests/1.failure.tar.gz'));D=G/'first-request';D.mkdir(exist_ok=True)
with tarfile.open(archive)as tf:
 for leaf in ['kernel.native.o','kernel.entry','generation.metadata.json']:
  name=next(n for n in tf.getnames()if n.endswith('/'+leaf));(D/leaf).write_bytes(tf.extractfile(name).read())
result=adapter.specialize((D/'kernel.native.o').read_bytes(),(D/'kernel.entry').read_text().strip(),json.loads((D/'generation.metadata.json').read_text()),D/'generated-ud2',Path('/workspaces/repository/kprog/x86/native_lab/native_link/target/release/native-link'));(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
