#include <stdint.h>
typedef uint32_t v4u32 __attribute__((vector_size(16)));
typedef int64_t v2s64 __attribute__((vector_size(16)));
void vuq(v4u32 *a,v4u32 *b,v4u32 *c) {*c=*a / *b;}
void vur(v4u32 *a,v4u32 *b,v4u32 *c) {*c=*a % *b;}
void vsq(v2s64 *a,v2s64 *b,v2s64 *c) {*c=*a / *b;}
void vsr(v2s64 *a,v2s64 *b,v2s64 *c) {*c=*a % *b;}
