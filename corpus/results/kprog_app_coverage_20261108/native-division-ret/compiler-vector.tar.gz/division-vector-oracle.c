#include <stdint.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
extern void vuq(void*,void*,void*),vur(void*,void*,void*),vsq(void*,void*,void*),vsr(void*,void*,void*);
static uint64_t rnd(void){static uint64_t x=0x1241c7e2adbc0451ULL;x^=x<<13;x^=x>>7;x^=x<<17;return x;}
int main(void){unsigned results=0;for(unsigned k=0;k<10000;k++){
 _Alignas(16) uint32_t a[4],b[4],q[4],r[4];
 _Alignas(16) int64_t x[2],y[2],z[2],w[2];
 for(unsigned j=0;j<4;j++){a[j]=rnd();b[j]=k%4?rnd():0;}
 for(unsigned j=0;j<2;j++){x[j]=k%5?rnd():INT64_MIN;y[j]=k%4?(k%5?rnd():-1):0;}
 vuq(a,b,q);vur(a,b,r);vsq(x,y,z);vsr(x,y,w);
 for(unsigned j=0;j<4;j++){uint32_t eq=b[j]?a[j]/b[j]:0,er=b[j]?a[j]%b[j]:a[j];if(q[j]!=eq||r[j]!=er)abort();results+=2;}
 for(unsigned j=0;j<2;j++){int64_t eq,er;if(y[j]==0){eq=0;er=x[j];}else if(x[j]==INT64_MIN&&y[j]==-1){eq=INT64_MIN;er=0;}else{eq=x[j]/y[j];er=x[j]%y[j];}if(z[j]!=eq||w[j]!=er)abort();results+=2;}
 }printf("native vector division: %u lane results OK\n",results);return 0;}
