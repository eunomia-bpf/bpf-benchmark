from pathlib import Path
import subprocess,os,signal,json,datetime,traceback,tarfile,sys,select
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');OLD=C/'design-only/remaining-apps/tracee-checked-offset'
try:
 with(G/'controller.log').open('w')as f:p=subprocess.run([sys.executable,str(G/'controller.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'recovery.exit').write_text(str(p.returncode)+'\n')
 # Publish the two interrupted host-launch epochs as infrastructure outcomes.
 O=R/'corpus/results/kprog_app_coverage_20261108/application-orphan-recovery';O.mkdir(exist_ok=True)
 record=dict(recovery_successor_exit=p.returncode,cilium_qemu=2276915,original_cilium_make_exit=241,tracee_successor_terminated=2295844,reason='Cilium vng parent exited while its actual QEMU continued; early Tracee successor stopped to keep serial12GiB budget',followup=str(G),raw38_waiter=2260774)
 (O/'summary.json').write_text(json.dumps(record,indent=2)+'\n');(O/'README.md').write_text('# Application guest-parent recovery\n\nCilium vng parent exited241 while QEMU2276915 retained its disk and generated actual native request1 successfully. Its old same-name094153 summary and collector archive supplied an archive-name collision during host collection. The downstream Tracee guest started early; its QEMU2295844 was terminated, preserving Cilium and the serial12GiB lane budget. Original38 waiter2260774 waited stopped until the fresh paired Tracee successor completed. Every interrupted diagnostic and actual request log is retained below; actual terminal application acceptance stays with the fresh cohort. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for name in ['cilium-prepared-end','tracee-checked-offset']:
   P=G.parent/name
   for n in ['status.json','controller.py','controller.log','run.log','run.exit','collect.log','collect.exit','summary.json','orphan-recovery.json']:
    if(P/n).exists():tf.add(P/n,arcname=name+'/'+n)
   for q in P.glob('.live-*/service.log'):tf.add(q,arcname=name+'/'+q.parent.name+'/service.log')
  for n in ['recover.py','controller.py','controller.log','recovery.exit']:tf.add(G/n,arcname='successor/'+n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record application guest-parent recovery and retained request logs',G/'recovery-publication.json')
 os.kill(2260774,signal.SIGCONT)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' guest-parent/collector recovery. Fresh pairedTracee controller closed with exit'+str(p.returncode)+'; original38 waiter2260774 resumed, followed by entire239 and Tetragon actual queue. Runtime admission additions0.\n')
except BaseException as e:
 (G/'recovery-error.json').write_text(json.dumps(dict(error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
