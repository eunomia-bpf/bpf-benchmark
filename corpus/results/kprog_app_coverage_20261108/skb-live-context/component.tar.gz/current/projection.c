#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <linux/bpf.h>
#define __s64 long long
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/skb-live-context/source/kprog/x86/x86_sim_local_bpf.h"
#include "x86_no_helpers_host.h"
unsigned long native_lab_entry_input(unsigned int kind) { (void)kind; return 0; }
static unsigned long cases;
static uint64_t mask(unsigned width) { return width==8 ? UINT64_MAX : (UINT64_C(1)<<(8*width))-1; }
static int test_cb(struct __sk_buff *ctx, unsigned width, unsigned off, int alias, uint64_t value) {
 X86_SIM_ENTRY_SKB(ctx);
 if (__x86_rdi.ptr != (void *)ctx) return 1;
 X86_SIM_L_WRITE_REG_PTR_TAG(X86_RSI,(__u8 *)__x86_rdi.ptr+alias,X86_SIM_TAG_ABI);
 unsigned char expected[sizeof(*ctx)]; memcpy(expected,ctx,sizeof(*ctx));
 uint64_t before=0; memcpy(&before,expected+offsetof(struct __sk_buff,cb)+off,width);
 uint64_t got=X86_SIM_L_READ_MEM_VALUE(X86_RSI,X86_MEM_AUX(X86_REG_NONE,0),X86_SKB_CB_OFF+off-alias,width,0);
 if (got!=(before&mask(width))) return 2;
 memcpy(expected+offsetof(struct __sk_buff,cb)+off,&value,width);
 X86_SIM_L_WRITE_REG_WIDTH(X86_RAX,value,X86_WIDTH_64); X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSI,X86_RAX,width,X86_MEM_AUX(X86_REG_NONE,0),X86_SKB_CB_OFF+off-alias);
 if (memcmp(expected,ctx,sizeof(*ctx))) return 3;
 got=X86_SIM_L_READ_MEM_VALUE(X86_RSI,X86_MEM_AUX(X86_REG_NONE,0),X86_SKB_CB_OFF+off-alias,width,0);
 cases++;return got!=(value&mask(width)) ? 4:0;
}
static int test_packet(struct __sk_buff *ctx,unsigned width,unsigned lane,int alias,int end) {
 X86_SIM_ENTRY_SKB(ctx);
 X86_SIM_L_WRITE_REG_PTR_TAG(X86_RSI,(__u8 *)__x86_rdi.ptr+alias,X86_SIM_TAG_ABI);
 long off=(end ? X86_SKB_DATA_END_OFF:X86_SKB_DATA_OFF)+lane-alias;
 uint64_t got=X86_SIM_L_READ_MEM_VALUE(X86_RSI,X86_MEM_AUX(X86_REG_NONE,0),off,width,0);
 uint64_t expected=((uint64_t)(end?ctx->data_end:ctx->data)>>(lane*8))&mask(width);
 unsigned tag=width==8 ? KPROG_ABI_LOAD_TAG(KPROG_ABI_KIND_SKB,X86_SIM_L_SKB_OFFSET(X86_RSI,off),X86_SIM_TAG_SCALAR,X86_SIM_TAG_PACKET,X86_SIM_TAG_PACKET_END):X86_SIM_TAG_SCALAR;
 unsigned wanted=width==8?(end?X86_SIM_TAG_PACKET_END:X86_SIM_TAG_PACKET):X86_SIM_TAG_SCALAR;
 cases++;return got!=expected||tag!=wanted ? 5:0;
}
static int test_lengths(uint32_t len,uint32_t data_len,int alias) {
 uint64_t backing[32]={0}; struct __sk_buff *ctx=(struct __sk_buff *)backing;
 ctx->len=len; memcpy((char *)backing+112,&len,4);memcpy((char *)backing+116,&data_len,4);
 X86_SIM_ENTRY_SKB(ctx);
 X86_SIM_L_WRITE_REG_PTR_TAG(X86_RSI,(void *)((uintptr_t)__x86_rdi.ptr+alias),X86_SIM_TAG_ABI);
 uint64_t actual=X86_SIM_L_READ_MEM_VALUE(X86_RSI,X86_MEM_AUX(X86_REG_NONE,0),112-alias,X86_WIDTH_32,0);
 if(actual!=len) return 6;
 X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RAX,X86_RSI,X86_WIDTH_32,X86_MEM_AUX(X86_REG_NONE,0),112-alias);
 X86_SIM_L_EXEC_ALU_MEM(X86_RAX,X86_RSI,X86_WIDTH_32,(X86_MEM_AUX_FULL(X86_REG_NONE,0,X86_WIDTH_32)|X86_MEM_AUX_ALU_OP(X86_ALU_SUB)),116-alias);
 cases+=2;return X86_SIM_L_READ_REG(X86_RAX)!=(uint32_t)(len-data_len) ? 7:0;
}
int main(void) {
 struct __sk_buff ctx;uint64_t state=0x43215678aa55cc33ULL;
 for(unsigned round=0;round<256;round++) {
  for(int alias=-16;alias<=16;alias+=8) { int rc=test_lengths((uint32_t)state,(uint32_t)(state>>32),alias);if(rc){printf("native fields %d\n",rc);return rc;} }
  for(unsigned i=0;i<sizeof(ctx);i++){state^=state<<13;state^=state>>7;state^=state<<17;((unsigned char *)&ctx)[i]=state;}
  for(unsigned width=1;width<=8;width*=2) {
   for(unsigned off=0;off+width<=20;off++)for(int alias=-16;alias<=16;alias+=8) {
    int rc=test_cb(&ctx,width,off,alias,state^((uint64_t)off<<32));if(rc){printf("cb fail %d/%u/%u/%d\n",rc,width,off,alias);return rc;}
   }
   for(unsigned lane=0;lane+width<=8;lane++)for(int alias=-16;alias<=16;alias+=8)for(int end=0;end<2;end++) {
    int rc=test_packet(&ctx,width,lane,alias,end);if(rc){printf("packet fail %u/%u/%d/%d\n",width,lane,alias,end);return rc;}
   }
  }
 }
 printf("x86 skb live projection: %lu full-state/width/alias observations PASS\n",cases);return 0;
}
