set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/exact-helper-context
trap 'echo $? > "$N/check.exit"' EXIT
taskset -c 8-11 make -f "$N/Makefile" proof > "$N/proof.log" 2>&1
taskset -c 8-11 make -f "$N/Makefile" host > "$N/host.log" 2>&1
