from pathlib import Path
import sys,json,traceback,hashlib,time
R=Path('/workspaces/repository');O=Path(__file__).parent
sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
rows=[]
for n in [2,4,9,16]:
 symbol='global_func'+str(n);source=R/'kprog/selftests/build'/('test_global_func'+str(n)+'__'+symbol+'.native.o');t=time.monotonic();row=dict(symbol=symbol,native_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),metadata=dict(prog_type=3 if n in [2,4] else 8,section='tc'if n in [2,4]else'cgroup_skb/ingress',maps=[]))
 try:row['artifacts']=specialize(source.read_bytes(),symbol,row['metadata'],O/symbol,R/'kprog/x86/native_lab/native_link/target/release/native-link');row['exit']=0
 except Exception as e:row['exit']=1;row['exception']=str(e);row['traceback']=traceback.format_exc()
 row['wall_seconds']=time.monotonic()-t;rows.append(row);(O/'observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
(O/'run.exit').write_text('0\n')
