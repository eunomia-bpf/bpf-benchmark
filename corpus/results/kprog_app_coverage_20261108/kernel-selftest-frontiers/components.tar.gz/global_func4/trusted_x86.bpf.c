#define X86_SIM_STACK_VALUE_WORDS(M) M(0)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("tc")
int trusted_x86_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
x86_l_0:
	/* 0x0: jmp    5 <global_func4+0x5> */
	X86_SIM_X86_RET();
x86_l_5:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
