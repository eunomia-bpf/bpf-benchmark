#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 520U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30) M(31) M(32) M(33) M(34) M(35) M(36) M(37) M(38) M(39) M(40) M(41) M(42) M(43) M(44) M(45) M(46) M(47) M(48) M(49) M(50) M(51) M(52) M(53) M(54) M(55) M(56) M(57) M(58) M(59) M(60) M(61) M(62) M(63) M(64)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("tc")
int trusted_x86_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_a:
	/* 0xa: mov    r15d,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d:
	/* 0xd: call   0 <global_func2> */
	X86_SIM_X86_CALL(x86_copy_12_4e_l_4e, 0x12ULL);
x86_l_12:
	/* 0x12: mov    ebp,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_32);
x86_l_14:
	/* 0x14: mov    edi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_19:
	/* 0x19: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_1c:
	/* 0x1c: call   0 <global_func2> */
	X86_SIM_X86_CALL(x86_copy_21_84_l_84, 0x21ULL);
x86_l_21:
	/* 0x21: mov    r14d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_32);
x86_l_24:
	/* 0x24: add    r14d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBP, X86_WIDTH_32, X86_ALU_ADD);
x86_l_27:
	/* 0x27: mov    edi,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 3ULL);
x86_l_2c:
	/* 0x2c: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2f:
	/* 0x2f: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_34:
	/* 0x34: call   0 <global_func2> */
	X86_SIM_X86_CALL(x86_copy_39_af_l_af, 0x39ULL);
x86_l_39:
	/* 0x39: add    eax,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_32, X86_ALU_ADD);
x86_l_3c:
	/* 0x3c: add    eax,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R15, X86_WIDTH_32, X86_ALU_ADD);
x86_l_3f:
	/* 0x3f: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_43:
	/* 0x43: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_44:
	/* 0x44: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_46:
	/* 0x46: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_48:
	/* 0x48: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_49:
	/* 0x49: jmp    f5 <f3+0x46> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_f5:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_4e */
x86_l_4e:
	/* 0x4e: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4f:
	/* 0x4f: sub    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 416ULL);
x86_l_56:
	/* 0x56: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_59:
	/* 0x59: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5c:
	/* 0x5c: mov    edx,0x1a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 416ULL);
x86_l_61:
	/* 0x61: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_63:
	/* 0x63: call   68 <f1+0x1a> */
	X86_SIM_L_EXEC_CALL_MEMSET(416ULL);
x86_l_68:
	/* 0x68: movzx  eax,BYTE PTR [rsp+0x19f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 415ULL);
x86_l_70:
	/* 0x70: mov    BYTE PTR [rsp+0x19f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 415ULL);
x86_l_77:
	/* 0x77: mov    eax,DWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_79:
	/* 0x79: add    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_7b:
	/* 0x7b: add    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_l_82:
	/* 0x82: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_83:
	/* 0x83: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_84 */
x86_l_84:
	/* 0x84: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_85:
	/* 0x85: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_87:
	/* 0x87: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_88:
	/* 0x88: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_8b:
	/* 0x8b: mov    ebp,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDI, X86_WIDTH_32);
x86_l_8d:
	/* 0x8d: mov    rdi,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_90:
	/* 0x90: call   84 <f2> */
	X86_SIM_X86_CALL(x86_copy_95_4e_l_4e, 0x95ULL);
x86_l_95:
	/* 0x95: mov    r14d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_32);
x86_l_98:
	/* 0x98: mov    edi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_32);
x86_l_9a:
	/* 0x9a: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_9d:
	/* 0x9d: mov    edx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_a2:
	/* 0xa2: call   84 <f2> */
	X86_SIM_X86_CALL(x86_copy_a7_af_l_af, 0xa7ULL);
x86_l_a7:
	/* 0xa7: add    eax,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_32, X86_ALU_ADD);
x86_l_aa:
	/* 0xaa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ab:
	/* 0xab: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_ad:
	/* 0xad: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_ae:
	/* 0xae: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_af */
x86_l_af:
	/* 0xaf: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b0:
	/* 0xb0: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_b2:
	/* 0xb2: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b3:
	/* 0xb3: sub    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 416ULL);
x86_l_ba:
	/* 0xba: mov    ebx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDX, X86_WIDTH_32);
x86_l_bc:
	/* 0xbc: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_bf:
	/* 0xbf: mov    ebp,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDI, X86_WIDTH_32);
x86_l_c1:
	/* 0xc1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_c4:
	/* 0xc4: mov    edx,0x1a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 416ULL);
x86_l_c9:
	/* 0xc9: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_cb:
	/* 0xcb: call   140 <f3+0x91> */
	X86_SIM_L_EXEC_CALL_MEMSET(416ULL);
x86_l_d0:
	/* 0xd0: movzx  eax,BYTE PTR [rsp+0x19f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 415ULL);
x86_l_d8:
	/* 0xd8: mov    BYTE PTR [rsp+0x19f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 415ULL);
x86_l_df:
	/* 0xdf: imul   ebp,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBX, X86_WIDTH_32, X86_ALU_IMUL);
x86_l_e2:
	/* 0xe2: imul   ebp,DWORD PTR [r14+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBP, X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_IMUL)), 40ULL);
x86_l_e7:
	/* 0xe7: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_e9:
	/* 0xe9: add    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_l_f0:
	/* 0xf0: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f1:
	/* 0xf1: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f3:
	/* 0xf3: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f4:
	/* 0xf4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_4e */
x86_copy_12_4e_l_4e:
	/* 0x4e: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_12_4e_l_4f:
	/* 0x4f: sub    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 416ULL);
x86_copy_12_4e_l_56:
	/* 0x56: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_copy_12_4e_l_59:
	/* 0x59: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_copy_12_4e_l_5c:
	/* 0x5c: mov    edx,0x1a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 416ULL);
x86_copy_12_4e_l_61:
	/* 0x61: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_copy_12_4e_l_63:
	/* 0x63: call   68 <f1+0x1a> */
	X86_SIM_L_EXEC_CALL_MEMSET(416ULL);
x86_copy_12_4e_l_68:
	/* 0x68: movzx  eax,BYTE PTR [rsp+0x19f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 415ULL);
x86_copy_12_4e_l_70:
	/* 0x70: mov    BYTE PTR [rsp+0x19f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 415ULL);
x86_copy_12_4e_l_77:
	/* 0x77: mov    eax,DWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_copy_12_4e_l_79:
	/* 0x79: add    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD);
x86_copy_12_4e_l_7b:
	/* 0x7b: add    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_copy_12_4e_l_82:
	/* 0x82: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_12_4e_l_83:
	/* 0x83: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	goto x86_l_84;

	/* native subroutine native_link_sub_4e */
x86_copy_95_4e_l_4e:
	/* 0x4e: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_95_4e_l_4f:
	/* 0x4f: sub    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 416ULL);
x86_copy_95_4e_l_56:
	/* 0x56: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_copy_95_4e_l_59:
	/* 0x59: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_copy_95_4e_l_5c:
	/* 0x5c: mov    edx,0x1a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 416ULL);
x86_copy_95_4e_l_61:
	/* 0x61: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_copy_95_4e_l_63:
	/* 0x63: call   68 <f1+0x1a> */
	X86_SIM_L_EXEC_CALL_MEMSET(416ULL);
x86_copy_95_4e_l_68:
	/* 0x68: movzx  eax,BYTE PTR [rsp+0x19f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 415ULL);
x86_copy_95_4e_l_70:
	/* 0x70: mov    BYTE PTR [rsp+0x19f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 415ULL);
x86_copy_95_4e_l_77:
	/* 0x77: mov    eax,DWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_copy_95_4e_l_79:
	/* 0x79: add    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD);
x86_copy_95_4e_l_7b:
	/* 0x7b: add    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_copy_95_4e_l_82:
	/* 0x82: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_95_4e_l_83:
	/* 0x83: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	goto x86_l_84;

	/* native subroutine native_link_sub_84 */
x86_copy_21_84_l_84:
	/* 0x84: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_copy_21_84_l_85:
	/* 0x85: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_copy_21_84_l_87:
	/* 0x87: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_21_84_l_88:
	/* 0x88: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_copy_21_84_l_8b:
	/* 0x8b: mov    ebp,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDI, X86_WIDTH_32);
x86_copy_21_84_l_8d:
	/* 0x8d: mov    rdi,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_64);
x86_copy_21_84_l_90:
	/* 0x90: call   84 <f2> */
	X86_SIM_X86_CALL(x86_copy_95_4e_l_4e, 0x95ULL);
x86_copy_21_84_l_95:
	/* 0x95: mov    r14d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_32);
x86_copy_21_84_l_98:
	/* 0x98: mov    edi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_32);
x86_copy_21_84_l_9a:
	/* 0x9a: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_copy_21_84_l_9d:
	/* 0x9d: mov    edx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1ULL);
x86_copy_21_84_l_a2:
	/* 0xa2: call   84 <f2> */
	X86_SIM_X86_CALL(x86_copy_a7_af_l_af, 0xa7ULL);
x86_copy_21_84_l_a7:
	/* 0xa7: add    eax,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_32, X86_ALU_ADD);
x86_copy_21_84_l_aa:
	/* 0xaa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_21_84_l_ab:
	/* 0xab: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_copy_21_84_l_ad:
	/* 0xad: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_copy_21_84_l_ae:
	/* 0xae: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	goto x86_l_af;

	/* native subroutine native_link_sub_af */
x86_copy_39_af_l_af:
	/* 0xaf: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_copy_39_af_l_b0:
	/* 0xb0: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_copy_39_af_l_b2:
	/* 0xb2: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_39_af_l_b3:
	/* 0xb3: sub    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 416ULL);
x86_copy_39_af_l_ba:
	/* 0xba: mov    ebx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDX, X86_WIDTH_32);
x86_copy_39_af_l_bc:
	/* 0xbc: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_copy_39_af_l_bf:
	/* 0xbf: mov    ebp,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDI, X86_WIDTH_32);
x86_copy_39_af_l_c1:
	/* 0xc1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_copy_39_af_l_c4:
	/* 0xc4: mov    edx,0x1a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 416ULL);
x86_copy_39_af_l_c9:
	/* 0xc9: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_copy_39_af_l_cb:
	/* 0xcb: call   140 <f3+0x91> */
	X86_SIM_L_EXEC_CALL_MEMSET(416ULL);
x86_copy_39_af_l_d0:
	/* 0xd0: movzx  eax,BYTE PTR [rsp+0x19f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 415ULL);
x86_copy_39_af_l_d8:
	/* 0xd8: mov    BYTE PTR [rsp+0x19f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 415ULL);
x86_copy_39_af_l_df:
	/* 0xdf: imul   ebp,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBX, X86_WIDTH_32, X86_ALU_IMUL);
x86_copy_39_af_l_e2:
	/* 0xe2: imul   ebp,DWORD PTR [r14+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBP, X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_IMUL)), 40ULL);
x86_copy_39_af_l_e7:
	/* 0xe7: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_copy_39_af_l_e9:
	/* 0xe9: add    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_copy_39_af_l_f0:
	/* 0xf0: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_39_af_l_f1:
	/* 0xf1: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_copy_39_af_l_f3:
	/* 0xf3: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_copy_39_af_l_f4:
	/* 0xf4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	goto x86_sim_ret_dispatch;

	/* native subroutine native_link_sub_af */
x86_copy_a7_af_l_af:
	/* 0xaf: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_copy_a7_af_l_b0:
	/* 0xb0: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_copy_a7_af_l_b2:
	/* 0xb2: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_a7_af_l_b3:
	/* 0xb3: sub    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 416ULL);
x86_copy_a7_af_l_ba:
	/* 0xba: mov    ebx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDX, X86_WIDTH_32);
x86_copy_a7_af_l_bc:
	/* 0xbc: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_copy_a7_af_l_bf:
	/* 0xbf: mov    ebp,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDI, X86_WIDTH_32);
x86_copy_a7_af_l_c1:
	/* 0xc1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_copy_a7_af_l_c4:
	/* 0xc4: mov    edx,0x1a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 416ULL);
x86_copy_a7_af_l_c9:
	/* 0xc9: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_copy_a7_af_l_cb:
	/* 0xcb: call   140 <f3+0x91> */
	X86_SIM_L_EXEC_CALL_MEMSET(416ULL);
x86_copy_a7_af_l_d0:
	/* 0xd0: movzx  eax,BYTE PTR [rsp+0x19f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 415ULL);
x86_copy_a7_af_l_d8:
	/* 0xd8: mov    BYTE PTR [rsp+0x19f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 415ULL);
x86_copy_a7_af_l_df:
	/* 0xdf: imul   ebp,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBX, X86_WIDTH_32, X86_ALU_IMUL);
x86_copy_a7_af_l_e2:
	/* 0xe2: imul   ebp,DWORD PTR [r14+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBP, X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_IMUL)), 40ULL);
x86_copy_a7_af_l_e7:
	/* 0xe7: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_copy_a7_af_l_e9:
	/* 0xe9: add    rsp,0x1a0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_copy_a7_af_l_f0:
	/* 0xf0: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_copy_a7_af_l_f1:
	/* 0xf1: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_copy_a7_af_l_f3:
	/* 0xf3: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_copy_a7_af_l_f4:
	/* 0xf4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	goto x86_sim_ret_dispatch;

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x12ULL: goto x86_l_12;
	case 0x21ULL: goto x86_l_21;
	case 0x39ULL: goto x86_l_39;
	case 0x95ULL: goto x86_l_95;
	case 0xa7ULL: goto x86_l_a7;
	}

}

X86_SIM_LICENSE();
