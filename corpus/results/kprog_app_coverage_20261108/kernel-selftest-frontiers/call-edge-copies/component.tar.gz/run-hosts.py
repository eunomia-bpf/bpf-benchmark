from pathlib import Path
import subprocess,json,time,struct
from elftools.elf.elffile import ELFFile
O=Path(__file__).parent;R=Path('/workspaces/repository');rows=[]
for epoch in ['before','after']:
 cmd=['cc','-O2','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-Wno-attributes','-Wno-builtin-macro-redefined','-include',str(O/'host-environment.h'),'-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/src'),str(O/('host-'+epoch+'.c')),str(O/'host-driver.c'),str(R/'kprog/selftests/build/test_global_func2__global_func2.native.o'),'-o',str(O/('host-'+epoch))]
 with(O/('host-'+epoch+'.compile.log')).open('w')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name='host-'+epoch,command=cmd,compile_exit=q.returncode)
 if q.returncode==0:
  with(O/('host-'+epoch+'.run.log')).open('w')as log:q=subprocess.run([str(O/('host-'+epoch))],stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(O/'hosts.json').write_text(json.dumps(rows,indent=2)+'\n')
(O/'hosts.exit').write_text('0\n')
