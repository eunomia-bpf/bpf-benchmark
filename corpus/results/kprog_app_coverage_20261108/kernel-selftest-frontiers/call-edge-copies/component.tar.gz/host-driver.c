#include <linux/bpf.h>
#include <stdio.h>
#include <string.h>
unsigned long long native_lab_entry_input(unsigned kind){(void)kind;return 0;}
extern int global_func2(struct __sk_buff *);
extern int trusted_x86_x86_sim_xdp(void *);
int main(void){
 const unsigned v[]={0,1,2,3,7,255,256,65535,65536,0x7fffffff,0x80000000,0xfffffffe,0xffffffff};unsigned cases=0;
 for(unsigned a=0;a<sizeof(v)/sizeof(v[0]);a++)for(unsigned b=0;b<sizeof(v)/sizeof(v[0]);b++){
  struct __sk_buff ctx;memset(&ctx,0,sizeof ctx);ctx.len=v[a];ctx.ifindex=v[b];unsigned expected=global_func2(&ctx),actual=trusted_x86_x86_sim_xdp(&ctx);
  if(expected!=actual){printf("len%u ifindex%u expected%u actual%u\n",ctx.len,ctx.ifindex,expected,actual);return 1;}cases++;
 }
 printf("original native C global_func2 and generated RAW entry: %u cases, 0 differences\n",cases);return 0;
}
