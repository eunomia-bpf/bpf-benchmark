#include <linux/bpf.h>
#define __always_inline inline
#include "/workspaces/repository/kprog/formal/oracles/x86_helper_environment_host.h"
#define SEC(NAME)
