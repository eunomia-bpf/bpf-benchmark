from pathlib import Path
import subprocess,json,time,struct
from elftools.elf.elffile import ELFFile
O=Path(__file__).parent;R=Path('/workspaces/repository');rows=[]
for epoch in ['before','after']:
 cmd=['cc','-O2','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-Wno-attributes','-Wno-builtin-macro-redefined','-include',str(O/'host-environment.h'),'-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/src'),str(O/('host-'+epoch+'.c')),str(O/'host-driver.c'),str(R/'kprog/selftests/build/test_global_func2__global_func2.native.o'),'-o',str(O/('host-'+epoch))]
 with(O/('host-'+epoch+'.compile.log')).open('w')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name='host-'+epoch,command=cmd,compile_exit=q.returncode)
 if q.returncode==0:
  with(O/('host-'+epoch+'.run.log')).open('w')as log:q=subprocess.run([str(O/('host-'+epoch))],stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(O/'hosts.json').write_text(json.dumps(rows,indent=2)+'\n')
cmd=['/usr/lib/llvm-18/bin/clang','-g','-O3','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_x86','-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(O/'global-func2-after.c'),'-o',str(O/'global-func2-after.bpf.o')];t=time.monotonic()
with(O/'global-func2.compile.log').open('w')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
row=dict(command=cmd,exit=q.returncode,wall_seconds=time.monotonic()-t,sections=[])
if q.returncode==0:
 with(O/'global-func2-after.bpf.o').open('rb')as f:
  for s in ELFFile(f).iter_sections():
   if s['sh_flags']&4 and s.data_size:
    ins=list(struct.iter_unpack('<BBhi',s.data()));row['sections'].append(dict(name=s.name,instructions=len(ins),maximum_fp_minus_offset=-min([0]+[o for c,r,o,i in ins if((r&15)==10 or(r>>4)==10)and o<0])))
(O/'observations.json').write_text(json.dumps(row,indent=2)+'\n');(O/'run.exit').write_text('0\n');print(row,flush=True)
