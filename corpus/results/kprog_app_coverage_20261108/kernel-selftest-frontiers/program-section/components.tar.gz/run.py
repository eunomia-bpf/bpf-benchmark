from pathlib import Path
import sys,json,hashlib,subprocess,importlib.util,struct
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');O=Path(__file__).parent
sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
sys.path.insert(0,str(R/'kprog/x86/micro-prog'));import generate_micro_sim_proofs as gen
old=importlib.util.spec_from_file_location('section_before',O/'before.py');before=importlib.util.module_from_spec(old);sys.modules[old.name]=before;old.loader.exec_module(before)
native=R/'kprog/selftests/build/test_global_func16__global_func16.native.o';rows=[]
for epoch,module in [('before',before),('after',gen)]:
 import trusted_specializer;trusted_specializer.gen=module
 for section in ['cgroup_skb/ingress','cgroup_skb/egress']:
  d=O/(epoch+'-'+section.rsplit('/',1)[-1]);meta=dict(prog_type=8,section=section,maps=[])
  result=specialize(native.read_bytes(),'global_func16',meta,d,R/'kprog/x86/native_lab/native_link/target/release/native-link')
  with Path(result['simulator_object']).open('rb')as f:
   elf=ELFFile(f);symbols=elf.get_section_by_name('.symtab');symbol=next(s for s in symbols.iter_symbols()if s.name==result['simulator_program']);s=elf.get_section(symbol['st_shndx']);rows.append(dict(epoch=epoch,requested_section=section,actual_section=s.name,instructions=s.data_size//8,code_sha256=hashlib.sha256(s.data()).hexdigest(),native_sha256=hashlib.sha256(native.read_bytes()).hexdigest()))
(O/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
trusted_specializer.gen=gen
with(O/'existing-worker.log').open('w')as log:q=subprocess.run([sys.executable,str(R/'kprog/test/check_trusted_worker.py')],env=dict(__import__('os').environ,CLANG='/usr/lib/llvm-18/bin/clang',PATH='/usr/lib/llvm-18/bin:'+__import__('os').environ['PATH']),stdout=log,stderr=subprocess.STDOUT)
(O/'worker.exit').write_text(str(q.returncode)+'\n');(O/'run.exit').write_text('0\n');print(json.dumps(rows),flush=True)
