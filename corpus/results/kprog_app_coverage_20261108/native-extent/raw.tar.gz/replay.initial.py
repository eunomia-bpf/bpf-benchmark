from pathlib import Path
import subprocess,json,fcntl,os,sys,hashlib
R=Path('/workspaces/repository');N=Path(__file__).parent;S=N/'requests';S.mkdir(mode=0o700)
command=[sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(S),'--native-link',str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'--loader',str(N/'trusted-native-loader')]
service=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=(N/'service.stderr').open('w'),text=True);log=[];rows=[]
try:
 line=service.stdout.readline();log.append(line);print(line,flush=True)
 for key in ['small','wide']:
  command=[str(N/'probe'),str(N.parent/'safety/build/context_array.bpf.o'),str(N/(key+'.native.o')),'0','2']
  q=subprocess.run(command,env=dict(os.environ,BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1'),capture_output=True,text=True)
  (N/(key+'.stdout')).write_text(q.stdout);(N/(key+'.stderr')).write_text(q.stderr)
  line=service.stdout.readline();log.append(line);row=dict(case=key,command=command,exit=q.returncode,request=json.loads(line));rows.append(row);(N/'runtime.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:
 with(S/'request.lock').open('rb')as lock:fcntl.flock(lock,fcntl.LOCK_EX)
 service.terminate();tail=service.communicate()[0];log.append(tail);(N/'service.log').write_text(''.join(log))
raise SystemExit(int(any(r['exit']or r['request']['status']for r in rows)))
