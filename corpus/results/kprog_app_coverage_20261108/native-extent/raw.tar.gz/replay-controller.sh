set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/native-extent
trap 'echo $? > "$N/replay.exit"' EXIT
make -f "$N/Makefile" host replay
