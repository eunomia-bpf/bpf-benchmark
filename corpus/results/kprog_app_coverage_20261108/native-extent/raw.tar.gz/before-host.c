#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
typedef uint8_t u8;typedef uint32_t u32;typedef uint64_t u64;
#define BPF_MAX_INSN_SIZE 128
#define GFP_KERNEL 0
struct bpf_prog { int value; }; struct bpf_insn { int value; };
struct bpf_kinsn { bool native_proof; unsigned max_emit_bytes; int (*emit_x86)(u8*,u32*,bool,u64,const struct bpf_prog*,const u8*); };
static unsigned length, calls, allocated, freed;static int fail_alloc,fail_emit;
static void *kvzalloc(size_t n,int flags){(void)flags;if(fail_alloc)return NULL;allocated++;return calloc(n?n:1,1);}
static void kvfree(void*p){if(p){freed++;free(p);}}
static int callback(u8*p,u32*off,bool emit,u64 payload,const struct bpf_prog*prog,const u8*ip){(void)payload;(void)prog;calls++;if(emit&&fail_emit)return -EIO;if(emit)for(unsigned i=0;i<length;i++)p[*off+i]=(u8)(i^0x5a);if(emit&&ip!=(const u8*)0x12340000)return -EINVAL;*off+=length;return length;}
static struct bpf_kinsn desc;
static int bpf_jit_get_kinsn_payload(const struct bpf_prog*p,const struct bpf_insn*i,const struct bpf_kinsn**k,u64*payload){(void)p;(void)i;*k=&desc;*payload=17;return 0;}
static int emit_kinsn_desc_call(u8 **pprog, const struct bpf_prog *bpf_prog,
				const struct bpf_insn *insn, bool emit,
				const u8 *final_ip)
{
	const struct bpf_kinsn *kinsn;
	u8 scratch[BPF_MAX_INSN_SIZE];
	u8 *prog = *pprog;
	u32 off = 0;
	u64 payload;
	int ret;

	ret = bpf_jit_get_kinsn_payload(bpf_prog, insn, &kinsn, &payload);
	if (ret)
		return ret;
	if (!kinsn || !kinsn->emit_x86)
		return -EOPNOTSUPP;
	if (kinsn->max_emit_bytes > BPF_MAX_INSN_SIZE)
		return -E2BIG;

	ret = kinsn->emit_x86(scratch, &off, emit, payload, bpf_prog,
			      final_ip);
	if (ret < 0)
		return ret;
	if (ret != off || ret > kinsn->max_emit_bytes)
		return -EFAULT;
	if (emit)
		memcpy(prog, scratch, off);

	*pprog = prog + off;
	return 0;
}

int main(void){u8 bytes[128],*p=bytes;length=129;desc=(struct bpf_kinsn){.native_proof=true,.max_emit_bytes=129,.emit_x86=callback};int r=emit_kinsn_desc_call(&p,NULL,NULL,false,NULL);printf("before native length129: result%d callback_calls%u\n",r,calls);return r==-E2BIG&&calls==0?0:1;}
