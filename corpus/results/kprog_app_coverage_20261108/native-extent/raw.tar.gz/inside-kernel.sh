set -eu
R=/workspaces/repository
N=/workspaces/.agent-state/kprog-lanes/C/design-only/native-extent
mount --bind "$N/build" "$R/kprog/tv/build-kernel-x86"
find "$N/kernel-source" -type f | while IFS= read -r source; do
 relative=${source#"$N/kernel-source/"}
 mount --bind "$source" "$R/vendor/linux-framework/$relative"
done
exec make -f "$N/Makefile" image module
