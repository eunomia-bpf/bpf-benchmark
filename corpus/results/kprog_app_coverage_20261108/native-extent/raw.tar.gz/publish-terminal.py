from pathlib import Path
from datetime import datetime,timezone
import os,select,sys,subprocess,json,tarfile,hashlib,io
N=Path(__file__).parent;C=N.parent.parent;R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((N/'replay.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
O=R/'corpus/results/kprog_app_coverage_20261108/native-extent';O.mkdir(exist_ok=True)
records=json.loads((N/'host-retry-serial/runtime.json').read_text())
result=dict(utc=datetime.now(timezone.utc).isoformat(),source_adoption=False,build_exit=int((N/'build.exit').read_text()),replay_exit=int((N/'replay-serial.exit').read_text()),initial_guest_records=json.loads((N/'runtime.json').read_text()),records=records,source_hashes={})
for p in [N/'bpf_jit_comp.c',N/'bpf_x86_native_lab.c',N/'native-proof-regions.patch',N/'native_loader.cpp',N/'probe',N/'trusted-native-loader',N/'build/arch/x86/boot/bzImage',N/'build/vmlinux',N/'module-output/bpf_x86_native_lab.ko']:
 result['source_hashes'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
for row in records:
 archive=Path(row['request'].get('artifact_archive',row['request'].get('failure_archive')))
 with tarfile.open(archive)as t:
  names=set(t.getnames());row['compiled']='request/generated/trusted_x86.bpf.o'in names
  row['native_sha256_matches']=hashlib.sha256(t.extractfile('request/kernel.native.o').read()).hexdigest()==row['request']['native_sha256']
(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# x86 exact native JIT emission extent','','Private native-kinsn transport uses the callback emit=false extent to allocate native emission storage, followed by the existing JIT image/offset path. Ordinary kinsn scratch rules retain their current route. Native descriptor max_emit_bytes128 retires in the paired candidate module. Callback/allocation errors retain their ordinary handling; runtime admission predicates and new limits added0. Canonical source/runtime adoption0.','','The existing warm kernel cache supplies the candidate Image/module build, exit'+str(result['build_exit'])+'. Existing patch application/idempotence/conflict checks pass. The actual source-extracted host helper covers24 native/ordinary length/emit scenes and2 allocation/callback error paths under ASan/UBSan, and retains the baseline declared129-byte refusal. Private loader changes only its transport chunk width to64KiB to exercise a complete wide chunk; actual native input bytes retain their identity.','','| Native input | Generated/compiled | Service status | Producer/TEST_RUN exit |','| --- | ---: | ---: | ---: |']
for row in records:lines.append('| '+row['case']+' | '+str(int(row['compiled']))+' | '+str(row['request']['status'])+' | '+str(row['exit'])+' |')
lines+=['','The original wide native object has32780text bytes (8193ordinary LEA instructions between scalar initialization and retval2); normal link canonicalization supplies the final image. Both positive producers use the existing XDP TEST_RUN and compare retval2/output0. Actual results above retain their own stages. The initial2GiB guest compiles/executes the small control and records a wide-compiler SIGKILL; the serial retry uses the existing host compiler broker and the identical native input. A short earlier host retry was withdrawn to preserve the active Tracee guest; the resource correction record and original files remain archived.','','Commands in the owning Workspace:','','```sh','sh /workspaces/.agent-state/kprog-lanes/C/design-only/native-extent/build.sh','make -f /workspaces/.agent-state/kprog-lanes/C/design-only/native-extent/Makefile host loader native-inputs','python3 /workspaces/.agent-state/kprog-lanes/C/design-only/native-extent/retry.serial.py','```','','[summary.json](summary.json) retains real stages and hashes; [raw.tar.gz](raw.tar.gz) retains exact source/patch/private transport edits, original positive native objects, source-extracted host cases, kernel/module/compiler logs, complete initial/retry service/native/BPF/verifier receipts, actual candidate Image/module, and reproduction scripts. The private warm kernel build remains available for a coherent shared-kernel/module adoption and original BCC/Katran replay. Universal native-link/copy/ABI laws retain V ownership.','']
(O/'README.md').write_text('\n'.join(lines))
with tarfile.open(O/'raw.tar.gz','w:gz')as t:
 for p in sorted(N.iterdir()):
  if p.name not in ['build','module-output','module-source','publication.json','publication.log','__pycache__']:
   t.add(p,arcname=p.name)
 t.add(N/'build/arch/x86/boot/bzImage',arcname='kernel/bzImage')
 t.add(N/'module-output/bpf_x86_native_lab.ko',arcname='kernel/bpf_x86_native_lab.ko')
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record x86 exact native-emission extent kernel and runtime observations',N/'publication.json');now=datetime.now(timezone.utc).isoformat()
text='\n- LOCAL C FOR A/V/R '+now+': PUSHED '+commit+' private x86 exact native extent: build'+str(result['build_exit'])+', serial original small/wide runtime'+str(result['replay_exit'])+', stages'+repr([(r['case'],r['request']['status'],r['exit'])for r in records])+'. Existing24source-extracted host scenes+2error paths and patchchecks0; full initial guest OOM/source/host-broker/retry records retained. Canonical source/runtime adoption0; coherent paired adoption and BCC/Katran replay follow. Runtime admission additions0.\n'
(C.parent/'COORDINATION.md').open('a').write(text);(C/'last.md').open('a').write('\n## '+now+' native extent terminal\n'+text)
p=C/'current.json';j=json.loads(p.read_text());j['updated']=now;j['active']['native-extent'].update(status='closed and published '+commit,result=result);p.write_text(json.dumps(j,indent=2)+'\n');print('PUBLISHED',commit,result['replay_exit'],flush=True)
