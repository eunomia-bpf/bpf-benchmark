from pathlib import Path
import os,sys,subprocess,json,threading,time
N=Path(__file__).parent;S=N/'broker'
with(N/'broker.log').open('w')as log:server=subprocess.Popen(['taskset','-c','8-11',sys.executable,'/workspaces/repository/kprog/trusted_compile.py','serve','--scope',str(N),'--state',str(S),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
def monitor():
 rc=server.wait()
 if not(S/'STOP').exists():(S/'failed.json').write_text(json.dumps(dict(error='compiler exited',returncode=rc))+'\n')
threading.Thread(target=monitor,daemon=True).start()
try:
 while not(S/'ready.json').exists():
  if server.poll()is not None:raise RuntimeError('compiler startup '+str(server.returncode))
  time.sleep(.1)
 with(N/'replay-retry.log').open('w')as log:q=subprocess.run(['make','-f',str(N/'Makefile'),'replay'],stdout=log,stderr=subprocess.STDOUT)
 (N/'replay-retry.exit').write_text(str(q.returncode)+'\n')
finally:
 (S/'STOP').write_text('native extent replay closed\n');server.wait()
