#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
typedef uint8_t u8;typedef uint32_t u32;typedef uint64_t u64;
#define BPF_MAX_INSN_SIZE 128
#define GFP_KERNEL 0
struct bpf_prog { int value; }; struct bpf_insn { int value; };
struct bpf_kinsn { bool native_proof; unsigned max_emit_bytes; int (*emit_x86)(u8*,u32*,bool,u64,const struct bpf_prog*,const u8*); };
static unsigned length, calls, allocated, freed;static int fail_alloc,fail_emit;
static void *kvzalloc(size_t n,int flags){(void)flags;if(fail_alloc)return NULL;allocated++;return calloc(n?n:1,1);}
static void kvfree(void*p){if(p){freed++;free(p);}}
static int callback(u8*p,u32*off,bool emit,u64 payload,const struct bpf_prog*prog,const u8*ip){(void)payload;(void)prog;calls++;if(emit&&fail_emit)return -EIO;if(emit)for(unsigned i=0;i<length;i++)p[*off+i]=(u8)(i^0x5a);if(emit&&ip!=(const u8*)0x12340000)return -EINVAL;*off+=length;return length;}
static struct bpf_kinsn desc;
static int bpf_jit_get_kinsn_payload(const struct bpf_prog*p,const struct bpf_insn*i,const struct bpf_kinsn**k,u64*payload){(void)p;(void)i;*k=&desc;*payload=17;return 0;}
static int emit_kinsn_desc_call(u8 **pprog, const struct bpf_prog *bpf_prog,
				const struct bpf_insn *insn, bool emit,
				const u8 *final_ip, u8 **native_image,
				int *native_len)
{
	const struct bpf_kinsn *kinsn;
	u8 scratch[BPF_MAX_INSN_SIZE];
	u8 *prog = *pprog;
	u32 off = 0;
	u64 payload;
	int ret;

	ret = bpf_jit_get_kinsn_payload(bpf_prog, insn, &kinsn, &payload);
	if (ret)
		return ret;
	if (!kinsn || !kinsn->emit_x86)
		return -EOPNOTSUPP;
	if (kinsn->native_proof) {
		ret = kinsn->emit_x86(NULL, &off, false, payload, bpf_prog, NULL);
		if (ret < 0)
			return ret;
		*native_len = off;
		if (!emit)
			return 0;
		*native_image = kvzalloc(off, GFP_KERNEL);
		if (!*native_image)
			return -ENOMEM;
		off = 0;
		ret = kinsn->emit_x86(*native_image, &off, true, payload,
				      bpf_prog, final_ip);
		if (ret < 0) {
			kvfree(*native_image);
			*native_image = NULL;
			return ret;
		}
		*native_len = off;
		return 0;
	}
	if (kinsn->max_emit_bytes > BPF_MAX_INSN_SIZE)
		return -E2BIG;

	ret = kinsn->emit_x86(scratch, &off, emit, payload, bpf_prog,
			      final_ip);
	if (ret < 0)
		return ret;
	if (ret != off || ret > kinsn->max_emit_bytes)
		return -EFAULT;
	if (emit)
		memcpy(prog, scratch, off);

	*pprog = prog + off;
	return 0;
}

int main(void){unsigned scenes=0;for(unsigned native=0;native<2;native++)for(unsigned emit=0;emit<2;emit++)for(unsigned n=0;n<8;n++){unsigned widths[]={0,1,127,128,129,4096,16384,32780};length=widths[n];if(!native&&length>128)continue;u8 bytes[128],*p=bytes,*image=NULL;int count=-1;calls=allocated=freed=0;desc=(struct bpf_kinsn){.native_proof=native,.max_emit_bytes=native?0:length,.emit_x86=callback};int r=emit_kinsn_desc_call(&p,NULL,NULL,emit,(const u8*)0x12340000,&image,&count);if(r)return 1;if(native){if(count!=(int)length||p!=bytes||calls!=(emit?2u:1u)||allocated!=emit)return 2;if(emit)for(unsigned i=0;i<length;i++)if(image[i]!=(u8)(i^0x5a))return 3;kvfree(image);if(freed!=allocated)return 4;}else{if(count!=-1||p!=bytes+length||image||calls!=1)return 5;if(emit)for(unsigned i=0;i<length;i++)if(bytes[i]!=(u8)(i^0x5a))return 6;}scenes++;}
length=32780;desc.native_proof=true;u8 bytes[128],*p=bytes,*image=NULL;int count=-1;fail_alloc=1;if(emit_kinsn_desc_call(&p,NULL,NULL,true,(const u8*)0x12340000,&image,&count)!=-ENOMEM)return 7;fail_alloc=0;fail_emit=1;allocated=freed=0;if(emit_kinsn_desc_call(&p,NULL,NULL,true,(const u8*)0x12340000,&image,&count)!=-EIO||image||allocated!=freed)return 8;printf("candidate exact native/ordinary emit/size scenes%u allocation/callback errors2: PASS\n",scenes);return 0;}
