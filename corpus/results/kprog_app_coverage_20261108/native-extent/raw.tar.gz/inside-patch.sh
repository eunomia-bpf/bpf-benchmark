set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/native-extent
mount --bind "$N/native-proof-regions.patch" /workspaces/repository/kprog/tv/native-proof-regions.patch
exec make -f "$N/Makefile" patch-check
