set -eu
R=/workspaces/repository
N=/workspaces/.agent-state/kprog-lanes/C/design-only/native-extent
trap 'echo $? > "$N/build.exit"' EXIT
install -d "$N/build"
rsync -aS --exclude='/.modules-install.*/' --exclude='/modules-install/' --exclude='/.virtme_mods/' "$R/kprog/tv/build-kernel-x86/" "$N/build/"
unshare --mount --propagation private sh "$N/inside-kernel.sh"
sha256sum "$N/build/arch/x86/boot/bzImage" "$N/build/vmlinux" "$N/module-output/bpf_x86_native_lab.ko" > "$N/outputs.sha256"
