from pathlib import Path
from datetime import datetime,timezone
import os,sys,select,subprocess,json
N=Path(__file__).parent;R=Path('/workspaces/repository');D=N.parent/'remaining-apps';A=D/'bcc-katran-native-extent'
try:
 fd=os.pidfd_open(int((N/'publication.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
receipt=json.loads((N/'publication.json').read_text());result=json.loads((R/'corpus/results/kprog_app_coverage_20261108/native-extent/summary.json').read_text())
if result['replay_exit']:raise RuntimeError('continue actual native extent frontier '+str(result['replay_exit']))
command=['make','-f',str(A/'Makefile'),'corpus','STATE='+str(A),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=bcc/set,katran','SAMPLES=1','WORKLOAD_DURATION=2']
with(N/'functional.log').open('w')as log:q=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
(N/'functional.exit').write_text(str(q.returncode)+'\n')
with(N/'functional-collect.log').open('w')as log:q=subprocess.run([sys.executable,str(D/'collect.py'),'bcc-katran-native-extent'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(N/'functional-collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
with(N/'canonical-safety.log').open('w')as log:q=subprocess.run(['make','-f',str(N/'Makefile'),'canonical-probe','safety'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(N/'canonical-safety.exit').write_text(str(q.returncode)+'\n')
with(N/'functional-publish.log').open('w')as log:q=subprocess.run([sys.executable,str(N/'publish-functional.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(N/'functional-publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
