from pathlib import Path
from datetime import datetime,timezone
import os,select,subprocess,sys,json,tarfile
D=Path(__file__).parent;N=D.parent;C=N.parent.parent;R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((N/'extent-control/controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
with(D/'replay.log').open('w')as log:q=subprocess.run(['make','-f',str(D/'Makefile'),'replay'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(D/'replay.exit').write_text(str(q.returncode)+'\n')
O=R/'corpus/results/kprog_app_coverage_20261108/native-extent/adoption';p=O/'summary.json';result=json.loads(p.read_text());rows=json.loads((D/'runtime/runtime.json').read_text());result['shared_runtime_control']=dict(utc=datetime.now(timezone.utc).isoformat(),exit=q.returncode,records=rows);p.write_text(json.dumps(result,indent=2)+'\n')
with tarfile.open(O/'control.tar.gz','w:gz')as t:
 for n in ['runtime','replay.py','replay.log','replay.exit','replay-queue.py','Makefile']:t.add(D/n,arcname=n)
text='\n### Fresh shared runtime control\n\nThe newly built shared Image/module repeats the existing original small and264-byte native controls. Actual service statuses and TEST_RUN exits: '+repr([(r['case'],r['request']['status'],r['exit'])for r in rows])+'. [summary.json](summary.json) retains complete rows; [control.tar.gz](control.tar.gz) retains copied P, generated B, compiler/verifier/native execution receipts and commands. The original BCC/Katran and38native serial queue closes before this2GiB control starts. Runtime admission additions:0.\n';(O/'README.md').open('a').write(text)
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish([str(p.relative_to(R))for p in [O/'summary.json',O/'README.md',O/'control.tar.gz']],'Record fresh shared x86 native extent execution',D/'control-publication.json');now=datetime.now(timezone.utc).isoformat();msg='\n- LOCAL C FOR R/A/V '+now+': PUSHED '+commit+' fresh SHARED x86 extent Image/module control: '+repr([(r['case'],r['request']['status'],r['exit'])for r in rows])+'. Same original small/264-byte native inputs, actual P/kernel copy/B/stock verifier/JIT TEST_RUN receipts archived. Whole original BCC/Katran andnative38 retain own preceding terminal result. Runtime admission additions0.\n';(C.parent/'COORDINATION.md').open('a').write(msg);(C/'last.md').open('a').write(msg)
p=C/'current.json';j=json.loads(p.read_text());j['updated']=now;j['active']['native-extent'].update(shared_control_publication=commit,shared_control=result['shared_runtime_control']);j['next']='Read whole native-extent functional and shared-control actual receipts; continue priority2a original kernel C selftest faithfulness and the four application frontiers. Existing32780-byte Clang expansion, Cilium DIV and unresolvedRET Notices retain their domains.';p.write_text(json.dumps(j,indent=2)+'\n');print(commit,flush=True)
