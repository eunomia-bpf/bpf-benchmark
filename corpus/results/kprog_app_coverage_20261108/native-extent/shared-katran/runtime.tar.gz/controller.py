from pathlib import Path
import subprocess,sys
G=Path(__file__).parent;R=Path('/workspaces/repository')
command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=katran','SAMPLES=1','WORKLOAD_DURATION=2']
with(G/'run.log').open('w')as log:q=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
(G/'run.exit').write_text(str(q.returncode)+'\n')
with(G/'collect.log').open('w')as log:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
with(G/'publish.log').open('w')as log:q=subprocess.run([sys.executable,str(G/'publish.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(G/'publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
