#!/bin/sh
uname -r
cat /proc/mounts | grep -E '/lib|/workspaces|modules'
printf '\nMODULE RESOLUTION\n'
modinfo -n ip_tunnel
p=$(modinfo -n ip_tunnel);readlink -f "$p";sha256sum "$p"
modprobe --show-depends ip_tunnel
modprobe ip_tunnel
printf 'IP_TUNNEL_MODPROBE_EXIT=%s\n' "$?"
printf '\nMODULE BTF ERRORS\n'
dmesg | tail -65
