from pathlib import Path
from datetime import datetime,timezone
import sys,json,tarfile,hashlib
E=Path(__file__).parent;N=E.parent;C=N.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/native-extent/extent-control';O.mkdir(parents=True,exist_ok=True)
rows=json.loads((E/'runtime/runtime.json').read_text());result=dict(utc=datetime.now(timezone.utc).isoformat(),replay_exit=int((E/'replay.exit').read_text()),source_adoption=False,records=rows)
for row in rows:
 with tarfile.open(row['request'].get('artifact_archive',row['request'].get('failure_archive')))as t:
  names=set(t.getnames());row['compiled']='request/generated/trusted_x86.bpf.o'in names
  row['native_hash_matches']=hashlib.sha256(t.extractfile('request/kernel.native.o').read()).hexdigest()==row['request']['native_sha256']
(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Exact native emission extent functional control','','The paired candidate kernel/module use the native emit=false extent and request-owned emission storage. This control retains every original native instruction: scalar initialization,64 LEA instructions, retval2 and RET. Its268-byte original text exercises the former128-byte scratch boundary. The private producer uses64KiB transport chunks; original BCC/Katran replays retain their128-byte loader transport. Canonical source/runtime adoption follows the paired shared-build handoff.','','| Native input | Compiled | Kernel status | TEST_RUN producer |','| --- | ---: | ---: | ---: |']
for row in rows:lines.append('| '+row['case']+' | '+str(int(row['compiled']))+' | '+str(row['request']['status'])+' | '+str(row['exit'])+' |')
lines+=['','The earlier32780-byte control retains its original native input and both archived compiler outcomes. The host retry reaches Clang18 source-location exhaustion during macro expansion, before stock verification/JIT emission. Its actual compiler diagnosis remains a generator coverage item. This functional control supplies a separate measured extent domain.','','```sh','make -f /workspaces/.agent-state/kprog-lanes/C/design-only/native-extent/extent-control/Makefile native replay','```','','[summary.json](summary.json) holds observed stages and native joins; [raw.tar.gz](raw.tar.gz) retains actual source/native/BPF/compiler/verifier/execution records. Runtime admission additions0.','']
(O/'README.md').write_text('\n'.join(lines))
with tarfile.open(O/'raw.tar.gz','w:gz')as t:
 for f in ['medium.S','medium.native.o','Makefile','replay.py','replay.log','replay.exit','runtime','controller.py','functional.py','publish.py']:t.add(E/f,arcname=f)
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record native x86 emission above fixed scratch extent',E/'publication.json');now=datetime.now(timezone.utc).isoformat()
text='\n- LOCAL C FOR R/A/V '+now+': PUSHED '+commit+' exact-extent controls '+repr([(x['case'],x['request']['status'],x['exit'])for x in rows])+'. Original medium268-byte native text passes through same P/kernel-copy/specializer/verifier/JIT route; actual compiler/native joins archived. Earlier32780-byte P retains Clang source-location exhaustion before verifier/JIT. Original BCC/Katran and native38 functional sequence continues on paired private Image/module, regular128-byte transport. Source/runtime adoption0; runtime admission additions0.\n'
(C.parent/'COORDINATION.md').open('a').write(text);(C/'last.md').open('a').write(text)
p=C/'current.json';j=json.loads(p.read_text());j['updated']=now;j['active']['native-extent'].update(extent_control_publication=commit,extent_control_results=result);p.write_text(json.dumps(j,indent=2)+'\n');print(commit,flush=True)
