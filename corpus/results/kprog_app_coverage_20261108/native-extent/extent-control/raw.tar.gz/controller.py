from pathlib import Path
import subprocess,sys,json
E=Path(__file__).parent;N=E.parent;R=Path('/workspaces/repository')
with (E/'replay.log').open('w')as log:q=subprocess.run(['make','-f',str(E/'Makefile'),'native','replay'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(E/'replay.exit').write_text(str(q.returncode)+'\n')
with (E/'publish.log').open('w')as log:q=subprocess.run([sys.executable,str(E/'publish.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(E/'publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
with (E/'functional.log').open('w')as log:q=subprocess.run([sys.executable,str(E/'functional.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(E/'functional.exit').write_text(str(q.returncode)+'\n')
