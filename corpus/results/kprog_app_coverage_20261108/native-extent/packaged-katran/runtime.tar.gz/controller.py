from pathlib import Path
import subprocess,sys,json,hashlib
from datetime import datetime,timezone
V=Path(__file__).parent;R=Path('/workspaces/repository');P=V.parent/'katran-shared-extent/package-runtime'
with(P/'build.log').open('w')as log:q=subprocess.run(['taskset','-c','20-23','make','-f',str(P/'Makefile'),'image'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(P/'build.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
image=json.loads(subprocess.check_output(['docker','image','inspect','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True))[0];(P/'image.json').write_text(json.dumps(image,indent=2)+'\n')
modules={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest()for p in P.glob('ordinary/**/*.ko')};modules.update({str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (P/'native').glob('*.ko')});(P/'module-hashes.json').write_text(json.dumps(modules,indent=2)+'\n')
inputs=dict(utc=datetime.now(timezone.utc).isoformat(),image=image['Id'],base_image=(P/'base-image').read_text().strip(),previous_results=['d28f03a335a7897ffd15b13f8778c9ca7263bae9','5b498c6dd90673b0418ee5d7c2209e55f04a849f'],ordinary_module_count=sum(k.startswith('ordinary/') for k in modules),native_module_count=sum(k.startswith('native/') for k in modules),files={})
for p in [R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage',R/'kprog/tv/build-kernel-x86/vmlinux',R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko',V/'Makefile',V/'guest.py']:inputs['files'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(V/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
with(V/'run.log').open('w')as log:q=subprocess.run(['make','-f',str(V/'Makefile'),'corpus','STATE='+str(V),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=katran','SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(V/'run.exit').write_text(str(q.returncode)+'\n')
with(V/'collect.log').open('w')as log:q=subprocess.run([sys.executable,str(V.parent/'collect.py'),V.name],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(V/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
with(V/'publish.log').open('w')as log:q=subprocess.run([sys.executable,str(V/'publish.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(V/'publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
