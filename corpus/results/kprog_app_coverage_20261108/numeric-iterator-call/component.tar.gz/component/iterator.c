#if !defined(__bpf__) && !defined(__BPF__)
#define BPF_NO_PRESERVE_ACCESS_INDEX
#endif
#include "/workspaces/repository/vendor/bpf/tetragon/bpf/include/vmlinux_generated_x86.h"
#include <bpf_helpers.h>
SEC("xdp") int numeric_iterator(void *ctx)
{
 int i;
 unsigned sum = 0;
 bpf_for(i, 0, 2048) { sum += i; }
 return sum == 2096128 ? 2 : 0;
}
char LICENSE[] SEC("license") = "GPL";
