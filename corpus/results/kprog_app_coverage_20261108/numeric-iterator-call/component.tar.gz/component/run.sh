set -eu
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/numeric-iterator-call
trap 'echo $? > "$D/checks.exit"' EXIT
make -f /dev/stdin <<'MAKE'
.PHONY: check
D := /workspaces/.agent-state/kprog-lanes/C/numeric-iterator-call
check:
	/usr/lib/llvm-18/bin/clang -O2 -g -fPIC -c -Ivendor/libbpf/src $(D)/iterator.c -o $(D)/iterator.native.o
	/usr/lib/llvm-18/bin/clang -O2 -g -target bpf -D__TARGET_ARCH_x86 -Ivendor/libbpf/src -c $(D)/iterator.c -o $(D)/iterator.bpf.o
	objdump -dr -Mintel $(D)/iterator.native.o > $(D)/iterator.native.asm
	/usr/lib/llvm-18/bin/llvm-objdump -dr $(D)/iterator.bpf.o > $(D)/iterator.bpf.asm
	/workspaces/.agent-state/kprog-lanes/C/cilium-skb-data-len-runtime/native-link-readonly-c --input $(D)/iterator.native.o --symbol numeric_iterator --mode proof --preserve-entry-abi --output $(D)/iterator.proof.o
MAKE
