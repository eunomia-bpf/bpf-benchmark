
/workspaces/.agent-state/kprog-lanes/C/numeric-iterator-call/iterator.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <numeric_iterator>:
       0:	bf a7 00 00 00 00 00 00	r7 = r10
       1:	07 07 00 00 f8 ff ff ff	r7 += -0x8
       2:	b7 06 00 00 00 00 00 00	r6 = 0x0
       3:	b7 08 00 00 00 08 00 00	r8 = 0x800
       4:	bf 71 00 00 00 00 00 00	r1 = r7
       5:	b7 02 00 00 00 00 00 00	r2 = 0x0
       6:	b7 03 00 00 00 08 00 00	r3 = 0x800
       7:	85 10 00 00 ff ff ff ff	call -0x1
		0000000000000038:  R_BPF_64_32	bpf_iter_num_new
       8:	bf 71 00 00 00 00 00 00	r1 = r7
       9:	85 10 00 00 ff ff ff ff	call -0x1
		0000000000000048:  R_BPF_64_32	bpf_iter_num_next
      10:	15 00 10 00 00 00 00 00	if r0 == 0x0 goto +0x10 <LBB0_7>
      11:	b7 01 00 00 00 00 00 00	r1 = 0x0
      12:	05 00 06 00 00 00 00 00	goto +0x6 <LBB0_3>

0000000000000068 <LBB0_2>:
      13:	0f 16 00 00 00 00 00 00	r6 += r1
      14:	bf a1 00 00 00 00 00 00	r1 = r10
      15:	07 01 00 00 f8 ff ff ff	r1 += -0x8
      16:	85 10 00 00 ff ff ff ff	call -0x1
		0000000000000080:  R_BPF_64_32	bpf_iter_num_next
      17:	bf 61 00 00 00 00 00 00	r1 = r6
      18:	15 00 02 00 00 00 00 00	if r0 == 0x0 goto +0x2 <LBB0_4>

0000000000000098 <LBB0_3>:
      19:	61 06 00 00 00 00 00 00	r6 = *(u32 *)(r0 + 0x0)
      20:	2d 68 f8 ff 00 00 00 00	if r8 > r6 goto -0x8 <LBB0_2>

00000000000000a8 <LBB0_4>:
      21:	67 01 00 00 20 00 00 00	r1 <<= 0x20
      22:	77 01 00 00 20 00 00 00	r1 >>= 0x20
      23:	b7 06 00 00 01 00 00 00	r6 = 0x1
      24:	15 01 01 00 00 fc 1f 00	if r1 == 0x1ffc00 goto +0x1 <LBB0_6>
      25:	b7 06 00 00 00 00 00 00	r6 = 0x0

00000000000000d0 <LBB0_6>:
      26:	67 06 00 00 01 00 00 00	r6 <<= 0x1

00000000000000d8 <LBB0_7>:
      27:	bf a1 00 00 00 00 00 00	r1 = r10
      28:	07 01 00 00 f8 ff ff ff	r1 += -0x8
      29:	85 10 00 00 ff ff ff ff	call -0x1
		00000000000000e8:  R_BPF_64_32	bpf_iter_num_destroy
      30:	bf 60 00 00 00 00 00 00	r0 = r6
      31:	95 00 00 00 00 00 00 00	exit
