
/workspaces/.agent-state/kprog-lanes/C/numeric-iterator-call/iterator.native.o:     file format elf64-x86-64


Disassembly of section xdp:

0000000000000000 <numeric_iterator>:
   0:	55                   	push   rbp
   1:	41 56                	push   r14
   3:	53                   	push   rbx
   4:	48 83 ec 10          	sub    rsp,0x10
   8:	4c 8d 74 24 08       	lea    r14,[rsp+0x8]
   d:	31 db                	xor    ebx,ebx
   f:	4c 89 f7             	mov    rdi,r14
  12:	31 f6                	xor    esi,esi
  14:	ba 00 08 00 00       	mov    edx,0x800
  19:	e8 00 00 00 00       	call   1e <numeric_iterator+0x1e>
			1a: R_X86_64_PLT32	bpf_iter_num_new-0x4
  1e:	4c 89 f7             	mov    rdi,r14
  21:	e8 00 00 00 00       	call   26 <numeric_iterator+0x26>
			22: R_X86_64_PLT32	bpf_iter_num_next-0x4
  26:	48 85 c0             	test   rax,rax
  29:	74 3a                	je     65 <numeric_iterator+0x65>
  2b:	31 ed                	xor    ebp,ebp
  2d:	48 8d 5c 24 08       	lea    rbx,[rsp+0x8]
  32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  39:	1f 84 00 00 00 00 00 
  40:	8b 00                	mov    eax,DWORD PTR [rax]
  42:	3d 00 08 00 00       	cmp    eax,0x800
  47:	73 0f                	jae    58 <numeric_iterator+0x58>
  49:	01 c5                	add    ebp,eax
  4b:	48 89 df             	mov    rdi,rbx
  4e:	e8 00 00 00 00       	call   53 <numeric_iterator+0x53>
			4f: R_X86_64_PLT32	bpf_iter_num_next-0x4
  53:	48 85 c0             	test   rax,rax
  56:	75 e8                	jne    40 <numeric_iterator+0x40>
  58:	31 db                	xor    ebx,ebx
  5a:	81 fd 00 fc 1f 00    	cmp    ebp,0x1ffc00
  60:	0f 94 c3             	sete   bl
  63:	01 db                	add    ebx,ebx
  65:	48 8d 7c 24 08       	lea    rdi,[rsp+0x8]
  6a:	e8 00 00 00 00       	call   6f <numeric_iterator+0x6f>
			6b: R_X86_64_PLT32	bpf_iter_num_destroy-0x4
  6f:	89 d8                	mov    eax,ebx
  71:	48 83 c4 10          	add    rsp,0x10
  75:	5b                   	pop    rbx
  76:	41 5e                	pop    r14
  78:	5d                   	pop    rbp
  79:	c3                   	ret
