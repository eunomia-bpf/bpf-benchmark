set -eu
D=/workspaces/.agent-state/kprog-lanes/C/dead-map-helper-binding
trap 'echo $? > "$D/build.exit"' EXIT
sh "$D/check.sh"
unshare --mount --propagation private sh "$D/inside.sh"
sha256sum "$D/module/bpf_x86_native_lab.ko" > "$D/module.sha256"
