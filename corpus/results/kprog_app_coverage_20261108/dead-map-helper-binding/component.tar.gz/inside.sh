set -eu
D=/workspaces/.agent-state/kprog-lanes/C/dead-map-helper-binding
R=/workspaces/repository
K=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
mount --bind "$K/build" "$R/kprog/tv/build-kernel-x86"
mount --bind "$D/candidate.h" "$R/kinsn/module/include/native_lab_group.h"
make -C "$R/kprog/tv/build-kernel-x86" M="$R/kinsn/module/x86" MO="$D/module" ARCH=x86 -j4 modules
