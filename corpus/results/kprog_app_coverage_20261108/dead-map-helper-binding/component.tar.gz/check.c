#include <linux/bpf.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
typedef uint32_t u32;typedef uint64_t u64;typedef int64_t s64;typedef int32_t s32;
#define INSN_BUF_SIZE 16
#define GFP_KERNEL 0
static int allocation_failure;
static void *kcalloc(size_t n,size_t s,int flags){(void)flags;return allocation_failure?NULL:calloc(n,s);}
#define kfree free
static char __bpf_call_base[1];
struct bpf_map;
struct map_ops {void *map_update_elem,*map_lookup_elem;int(*map_gen_lookup)(struct bpf_map *,struct bpf_insn *);};
struct bpf_map {struct map_ops *ops;int mode;};
struct map_state {bool poison;struct bpf_map *map_ptr;};
struct bpf_insn_aux_data {u32 seen;struct map_state map_ptr_state;};
struct bpf_prog {struct bpf_insn *insnsi;};
struct bpf_verifier_env {struct bpf_insn_aux_data *insn_aux_data;struct bpf_prog *prog;u32 used_map_cnt;struct bpf_map **used_maps;};
static int gen(struct bpf_map *map,struct bpf_insn *out){
 switch(map->mode){case 0:return -EOPNOTSUPP;case 1:out[0]=(struct bpf_insn){.code=BPF_JMP|BPF_CALL,.imm=111};return 1;case 2:out[0]=(struct bpf_insn){.code=BPF_JMP|BPF_CALL,.imm=-11};return 1;case 3:out[0]=(struct bpf_insn){.code=BPF_JMP|BPF_CALL,.src_reg=BPF_PSEUDO_CALL,.imm=111};return 1;case 4:out[0]=(struct bpf_insn){.code=BPF_JMP32|BPF_CALL,.imm=111};return 1;case 5:return 0;case 6:return INSN_BUF_SIZE;default:return -EIO;}
}
#include "functions.inc"
static int map_expected(struct bpf_map *m,int id,u64 target){
 if(id==BPF_FUNC_map_update_elem)return target==(u64)(uintptr_t)m->ops->map_update_elem;
 if(id!=BPF_FUNC_map_lookup_elem)return 0;
 if(target==(u64)(uintptr_t)m->ops->map_lookup_elem)return 1;
 if(!m->ops->map_gen_lookup)return 0;
 if(allocation_failure)return -ENOMEM;
 if(m->mode==7)return -EIO;
 if(m->mode==5||m->mode==6)return -EFAULT;
 return (m->mode==1 && target==(u64)(uintptr_t)__bpf_call_base+111)||(m->mode==2 && target==(u64)(uintptr_t)__bpf_call_base-11);
}
int main(void){
 struct map_ops ops[3]={{(void*)0x1000,(void*)0x2000,gen},{(void*)0x3000,(void*)0x4000,gen},{(void*)0x5000,(void*)0x6000,NULL}};
 struct bpf_map maps[3]={{&ops[0],0},{&ops[1],0},{&ops[2],0}},*owned[3]={&maps[0],&maps[1],&maps[2]};
 struct bpf_insn call={.code=BPF_JMP|BPF_CALL};struct bpf_prog prog={&call};struct bpf_insn_aux_data aux={0};struct bpf_verifier_env env={&aux,&prog,3,owned};
 int ids[]={BPF_FUNC_map_lookup_elem,BPF_FUNC_map_update_elem,BPF_FUNC_map_delete_elem,0,999};
 u64 targets[]={0x1000,0x2000,0x3000,0x4000,0x5000,0x6000,(u64)(uintptr_t)__bpf_call_base+111,(u64)(uintptr_t)__bpf_call_base-11,0,0xdeadbeef};
 unsigned long count=0;
 for(int mode=0;mode<8;mode++)for(int mode2=0;mode2<8;mode2++)for(unsigned used=0;used<=3;used++)for(unsigned seen=0;seen<=2;seen++)for(int poison=0;poison<2;poison++)for(unsigned selected=0;selected<=3;selected++)for(unsigned id=0;id<5;id++)for(unsigned target=0;target<10;target++)for(int oom=0;oom<2;oom++){
  maps[0].mode=mode;maps[1].mode=mode2;env.used_map_cnt=used;aux.seen=seen;aux.map_ptr_state.poison=poison;aux.map_ptr_state.map_ptr=selected<3?&maps[selected]:NULL;call.imm=ids[id];allocation_failure=oom;
  int expected=0;if(seen){if(!poison&&selected<3)expected=map_expected(&maps[selected],call.imm,targets[target]);}else for(unsigned i=0;i<used;i++){expected=map_expected(owned[i],call.imm,targets[target]);if(expected)break;}
  int got=native_lab_map_helper_target(&env,0,targets[target]);if(got!=expected){fprintf(stderr,"helper identity mismatch mode=%d/%d used=%u seen=%u poison=%d map=%u id=%d target=%llx oom=%d got=%d expected=%d\n",mode,mode2,used,seen,poison,selected,call.imm,(unsigned long long)targets[target],oom,got,expected);return 1;}count++;
 }
 printf("generic map-helper identity: OK (%lu controls)\n",count);return 0;
}
