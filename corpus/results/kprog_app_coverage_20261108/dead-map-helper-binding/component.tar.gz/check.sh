set -eu
D=/workspaces/.agent-state/kprog-lanes/C/dead-map-helper-binding
R=/workspaces/repository
trap 'echo $? > "$D/check.exit"' EXIT
cd "$R"
cc -Wall -Wextra -Werror -O2 -fsanitize=address,undefined -fno-sanitize-recover=all "$D/check.c" -o "$D/check"
"$D/check"
