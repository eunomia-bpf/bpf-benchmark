savedcmd_bpf_test_modorder_x.mod := printf '%s\n'   bpf_test_modorder_x.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_test_modorder_x.mod
