savedcmd_bpf_test_rqspinlock.mod := printf '%s\n'   bpf_test_rqspinlock.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_test_rqspinlock.mod
