savedcmd_bpf_testmod.mod := printf '%s\n'   bpf_testmod.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_testmod.mod
