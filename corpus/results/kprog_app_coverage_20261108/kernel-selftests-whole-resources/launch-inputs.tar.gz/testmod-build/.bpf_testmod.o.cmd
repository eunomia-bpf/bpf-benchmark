savedcmd_bpf_testmod.o := gcc -Wp,-MMD,./.bpf_testmod.o.d -nostdinc -I/workspaces/repository/vendor/linux-framework/arch/x86/include -I/workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated -I/workspaces/repository/vendor/linux-framework/include -I/workspaces/repository/kprog/tv/build-kernel-x86/include -I/workspaces/repository/vendor/linux-framework/arch/x86/include/uapi -I/workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi -I/workspaces/repository/vendor/linux-framework/include/uapi -I/workspaces/repository/kprog/tv/build-kernel-x86/include/generated/uapi -include /workspaces/repository/vendor/linux-framework/include/linux/compiler-version.h -include /workspaces/repository/vendor/linux-framework/include/linux/kconfig.h -include /workspaces/repository/vendor/linux-framework/include/linux/compiler_types.h -D__KERNEL__ -fmacro-prefix-map=/workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/= -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -mno-sse4a -fcf-protection=none -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -fno-stack-clash-protection -pg -mrecord-mcount -mfentry -DCC_USING_FENTRY -fno-inline-functions-called-once -falign-functions=16 -fstrict-flex-arrays=3 -fms-extensions -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wno-type-limits -Wno-dangling-pointer -Wvla-larger-than=1 -Wno-pointer-sign -Wcast-function-type -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -g -I/workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/. -I/workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/. -I.  -DMODULE  -DKBUILD_BASENAME='"bpf_testmod"' -DKBUILD_MODNAME='"bpf_testmod"' -D__KBUILD_MODNAME=bpf_testmod -c -o bpf_testmod.o /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/bpf_testmod.c   ; /workspaces/repository/kprog/tv/build-kernel-x86/tools/objtool/objtool --hacks=jump_label --hacks=noinstr --hacks=skylake --orc --retpoline --rethunk --static-call --uaccess --prefix=16  --link  --module bpf_testmod.o

source_bpf_testmod.o := /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/bpf_testmod.c

deps_bpf_testmod.o := \
    $(wildcard include/config/X86_64) \
  /workspaces/repository/vendor/linux-framework/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /workspaces/repository/vendor/linux-framework/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /workspaces/repository/vendor/linux-framework/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/CC_HAS_ASSUME) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/FORTIFY_SOURCE) \
    $(wildcard include/config/UBSAN_BOUNDS) \
    $(wildcard include/config/CC_HAS_COUNTED_BY_PTR) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CFI) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_BROKEN_COUNTED_BY_REF) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /workspaces/repository/vendor/linux-framework/include/linux/compiler-context-analysis.h \
  /workspaces/repository/vendor/linux-framework/include/linux/compiler_attributes.h \
  /workspaces/repository/vendor/linux-framework/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /workspaces/repository/vendor/linux-framework/include/linux/bpf.h \
    $(wildcard include/config/CGROUP_BPF) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/MEMCG) \
    $(wildcard include/config/DEBUG_KERNEL) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/X86) \
    $(wildcard include/config/DYNAMIC_FTRACE_WITH_JMP) \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/BPF_JIT) \
    $(wildcard include/config/FINEIBT) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/NET) \
    $(wildcard include/config/BPF_LSM) \
    $(wildcard include/config/BPF_JIT_ALWAYS_ON) \
    $(wildcard include/config/BPF_EVENTS) \
    $(wildcard include/config/INET) \
    $(wildcard include/config/KEYS) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/bpf.h \
    $(wildcard include/config/BPF_LIRC_MODE2) \
    $(wildcard include/config/EFFICIENT_UNALIGNED_ACCESS) \
    $(wildcard include/config/CGROUP_NET_CLASSID) \
    $(wildcard include/config/IP_ROUTE_CLASSID) \
    $(wildcard include/config/BPF_KPROBE_OVERRIDE) \
    $(wildcard include/config/XFRM) \
    $(wildcard include/config/SOCK_CGROUP_DATA) \
    $(wildcard include/config/IPV6) \
  /workspaces/repository/vendor/linux-framework/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/types.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/types.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/types.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/int-ll64.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/int-ll64.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/bitsperlong.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitsperlong.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/bitsperlong.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/posix_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/stddef.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/stddef.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/posix_types_64.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/posix_types.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/bpf_common.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/filter.h \
  /workspaces/repository/vendor/linux-framework/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/rwonce.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/rwonce.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /workspaces/repository/vendor/linux-framework/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /workspaces/repository/vendor/linux-framework/include/crypto/sha2.h \
  /workspaces/repository/vendor/linux-framework/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /workspaces/repository/vendor/linux-framework/include/linux/alloc_tag.h \
    $(wildcard include/config/MEM_ALLOC_PROFILING_DEBUG) \
    $(wildcard include/config/MEM_ALLOC_PROFILING) \
    $(wildcard include/config/ARCH_MODULE_NEEDS_WEAK_PER_CPU) \
    $(wildcard include/config/MEM_ALLOC_PROFILING_ENABLED_BY_DEFAULT) \
  /workspaces/repository/vendor/linux-framework/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
    $(wildcard include/config/DEBUG_BUGVERBOSE_DETAILED) \
  /workspaces/repository/vendor/linux-framework/include/linux/stringify.h \
  /workspaces/repository/vendor/linux-framework/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /workspaces/repository/vendor/linux-framework/include/linux/objtool.h \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/MITIGATION_UNRET_ENTRY) \
    $(wildcard include/config/MITIGATION_SRSO) \
  /workspaces/repository/vendor/linux-framework/include/linux/objtool_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/annotate.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/asm.h \
    $(wildcard include/config/KPROBES) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/asm-offsets.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/include/generated/asm-offsets.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/extable_fixup_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /workspaces/repository/vendor/linux-framework/include/linux/once_lite.h \
  /workspaces/repository/vendor/linux-framework/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /workspaces/repository/vendor/linux-framework/include/linux/stdarg.h \
  /workspaces/repository/vendor/linux-framework/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /workspaces/repository/vendor/linux-framework/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /workspaces/repository/vendor/linux-framework/include/linux/build_bug.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kern_levels.h \
  /workspaces/repository/vendor/linux-framework/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /workspaces/repository/vendor/linux-framework/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/GENDWARFKSYMS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/CALL_PADDING) \
    $(wildcard include/config/MITIGATION_RETHUNK) \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/MITIGATION_SLS) \
    $(wildcard include/config/FUNCTION_PADDING_BYTES) \
    $(wildcard include/config/UML) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/ibt.h \
    $(wildcard include/config/X86_KERNEL_IBT) \
  /workspaces/repository/vendor/linux-framework/include/linux/ratelimit_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bits.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/bits.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/const.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/const.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/bits.h \
  /workspaces/repository/vendor/linux-framework/include/linux/overflow.h \
  /workspaces/repository/vendor/linux-framework/include/linux/limits.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/limits.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/limits.h \
  /workspaces/repository/vendor/linux-framework/include/linux/const.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/param.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/param.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/param.h \
  /workspaces/repository/vendor/linux-framework/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/spinlock_types.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/qrwlock_types.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/byteorder.h \
  /workspaces/repository/vendor/linux-framework/include/linux/byteorder/little_endian.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/byteorder/little_endian.h \
  /workspaces/repository/vendor/linux-framework/include/linux/swab.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/swab.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/swab.h \
  /workspaces/repository/vendor/linux-framework/include/linux/byteorder/generic.h \
  /workspaces/repository/vendor/linux-framework/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCK_STAT) \
  /workspaces/repository/vendor/linux-framework/include/linux/dynamic_debug.h \
    $(wildcard include/config/JUMP_LABEL) \
  /workspaces/repository/vendor/linux-framework/include/linux/jump_label.h \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /workspaces/repository/vendor/linux-framework/include/linux/cleanup.h \
  /workspaces/repository/vendor/linux-framework/include/linux/err.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/errno.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/errno.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/errno-base.h \
  /workspaces/repository/vendor/linux-framework/include/linux/args.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/jump_label.h \
    $(wildcard include/config/HAVE_JUMP_LABEL_HACK) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/nops.h \
  /workspaces/repository/vendor/linux-framework/include/linux/codetag.h \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/CODE_TAGGING) \
  /workspaces/repository/vendor/linux-framework/include/linux/container_of.h \
  /workspaces/repository/vendor/linux-framework/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_RT) \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPTION) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/PREEMPT_NONE) \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/PREEMPT) \
    $(wildcard include/config/PREEMPT_LAZY) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/preempt.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/rmwcc.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/CC_HAS_NAMED_AS) \
    $(wildcard include/config/USE_X86_SEG_SUPPORT) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/percpu.h \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /workspaces/repository/vendor/linux-framework/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /workspaces/repository/vendor/linux-framework/include/linux/percpu-defs.h \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /workspaces/repository/vendor/linux-framework/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /workspaces/repository/vendor/linux-framework/include/linux/atomic.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/atomic.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/CALL_THUNKS) \
    $(wildcard include/config/MITIGATION_ITS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cmpxchg.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cpufeatures.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cmpxchg_64.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/barrier.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/barrier.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/atomic64_64.h \
  /workspaces/repository/vendor/linux-framework/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /workspaces/repository/vendor/linux-framework/include/linux/atomic/atomic-long.h \
  /workspaces/repository/vendor/linux-framework/include/linux/atomic/atomic-instrumented.h \
  /workspaces/repository/vendor/linux-framework/include/linux/instrumented.h \
    $(wildcard include/config/DEBUG_ATOMIC) \
    $(wildcard include/config/DEBUG_ATOMIC_LARGEST_ALIGN) \
  /workspaces/repository/vendor/linux-framework/include/linux/kmsan-checks.h \
    $(wildcard include/config/KMSAN) \
  /workspaces/repository/vendor/linux-framework/include/linux/bitmap.h \
  /workspaces/repository/vendor/linux-framework/include/linux/align.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/align.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bitops.h \
  /workspaces/repository/vendor/linux-framework/include/linux/typecheck.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/kernel.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/sysinfo.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/generic-non-atomic.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/X86_CMOV) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/sched.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/arch_hweight.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/const_hweight.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/instrumented-atomic.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/instrumented-lock.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/le.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /workspaces/repository/vendor/linux-framework/include/linux/errno.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/errno.h \
  /workspaces/repository/vendor/linux-framework/include/linux/find.h \
  /workspaces/repository/vendor/linux-framework/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
  /workspaces/repository/vendor/linux-framework/include/linux/array_size.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/string.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/string.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /workspaces/repository/vendor/linux-framework/include/linux/fortify-string.h \
    $(wildcard include/config/CC_HAS_KASAN_MEMINTRINSIC_PREFIX) \
    $(wildcard include/config/GENERIC_ENTRY) \
  /workspaces/repository/vendor/linux-framework/include/linux/bitmap-str.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cpumask_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/gfp_types.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
  /workspaces/repository/vendor/linux-framework/include/linux/numa.h \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /workspaces/repository/vendor/linux-framework/include/linux/nodemask.h \
    $(wildcard include/config/HIGHMEM) \
  /workspaces/repository/vendor/linux-framework/include/linux/minmax.h \
  /workspaces/repository/vendor/linux-framework/include/linux/nodemask_types.h \
    $(wildcard include/config/NODES_SHIFT) \
  /workspaces/repository/vendor/linux-framework/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /workspaces/repository/vendor/linux-framework/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/DYNAMIC_FTRACE) \
  /workspaces/repository/vendor/linux-framework/include/linux/kstrtox.h \
  /workspaces/repository/vendor/linux-framework/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /workspaces/repository/vendor/linux-framework/include/linux/math.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/div64.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/div64.h \
    $(wildcard include/config/CC_OPTIMIZE_FOR_PERFORMANCE) \
  /workspaces/repository/vendor/linux-framework/include/linux/sprintf.h \
  /workspaces/repository/vendor/linux-framework/include/linux/trace_printk.h \
    $(wildcard include/config/TRACING) \
  /workspaces/repository/vendor/linux-framework/include/linux/instruction_pointer.h \
  /workspaces/repository/vendor/linux-framework/include/linux/util_macros.h \
    $(wildcard include/config/FOO_SUSPEND) \
  /workspaces/repository/vendor/linux-framework/include/linux/wordpart.h \
  /workspaces/repository/vendor/linux-framework/include/linux/list.h \
    $(wildcard include/config/LIST_HARDENED) \
    $(wildcard include/config/DEBUG_LIST) \
  /workspaces/repository/vendor/linux-framework/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/random.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/ioctl.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/ioctl.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/ioctl.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/ioctl.h \
  /workspaces/repository/vendor/linux-framework/include/linux/irqnr.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/irqnr.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/sparsemem.h \
    $(wildcard include/config/SPARSEMEM) \
    $(wildcard include/config/X86_PAE) \
  /workspaces/repository/vendor/linux-framework/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
    $(wildcard include/config/CSD_LOCK_WAIT_DEBUG) \
  /workspaces/repository/vendor/linux-framework/include/linux/smp_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /workspaces/repository/vendor/linux-framework/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/ARCH_HAS_PREEMPT_LAZY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/SH) \
  /workspaces/repository/vendor/linux-framework/include/linux/restart_block.h \
  /workspaces/repository/vendor/linux-framework/include/linux/time64.h \
  /workspaces/repository/vendor/linux-framework/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /workspaces/repository/vendor/linux-framework/include/vdso/math64.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/time64.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/time.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/time_types.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/current.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /workspaces/repository/vendor/linux-framework/include/vdso/cache.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/VM86) \
    $(wildcard include/config/X86_FRED) \
    $(wildcard include/config/X86_IOPL_IOPERM) \
    $(wildcard include/config/COMPAT) \
    $(wildcard include/config/IA32_EMULATION) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/page.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /workspaces/repository/vendor/linux-framework/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/mem_encrypt.h \
    $(wildcard include/config/X86_MEM_ENCRYPT) \
  /workspaces/repository/vendor/linux-framework/include/linux/cc_platform.h \
    $(wildcard include/config/ARCH_HAS_CC_PLATFORM) \
  /workspaces/repository/vendor/linux-framework/include/vdso/page.h \
    $(wildcard include/config/PAGE_SHIFT) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/kaslr.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/page_64.h \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/X86_VSYSCALL_EMULATION) \
  /workspaces/repository/vendor/linux-framework/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_IRQSOFF) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /workspaces/repository/vendor/linux-framework/include/linux/range.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
  /workspaces/repository/vendor/linux-framework/include/linux/pfn.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/getorder.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cpufeature.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/processor.h \
    $(wildcard include/config/X86_VMX_FEATURE_NAMES) \
    $(wildcard include/config/X86_USER_SHADOW_STACK) \
    $(wildcard include/config/X86_DEBUG_FPU) \
    $(wildcard include/config/PARAVIRT_XXL) \
    $(wildcard include/config/CPU_SUP_AMD) \
    $(wildcard include/config/XEN) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/MITIGATION_PAGE_TABLE_ISOLATION) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/processor-flags.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/math_emu.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/ptrace.h \
    $(wildcard include/config/PARAVIRT) \
    $(wildcard include/config/X86_DEBUGCTLMSR) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/segment.h \
    $(wildcard include/config/XEN_PV) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/ptrace.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/ptrace-abi.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/paravirt-base.h \
    $(wildcard include/config/PARAVIRT_SPINLOCKS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/proto.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/ldt.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/sigcontext.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cpuid/api.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cpuid/types.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PROC_FS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/desc_defs.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/special_insns.h \
  /workspaces/repository/vendor/linux-framework/include/linux/irqflags.h \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /workspaces/repository/vendor/linux-framework/include/linux/irqflags_types.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/irqflags.h \
    $(wildcard include/config/DEBUG_ENTRY) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/nospec-branch.h \
    $(wildcard include/config/CALL_THUNKS_DEBUG) \
    $(wildcard include/config/MITIGATION_CALL_DEPTH_TRACKING) \
    $(wildcard include/config/MITIGATION_IBPB_ENTRY) \
  /workspaces/repository/vendor/linux-framework/include/linux/static_key.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/msr-index.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/unwind_hints.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/orc_types.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/GEN-for-each-reg.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/fpu/types.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/vmxfeatures.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/vdso/processor.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/shstk.h \
  /workspaces/repository/vendor/linux-framework/include/linux/personality.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/personality.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/cpufeaturemasks.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/thread_info_tif.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/smp.h \
    $(wildcard include/config/DEBUG_NMI_SELFTEST) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cpumask.h \
  /workspaces/repository/vendor/linux-framework/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
    $(wildcard include/config/NO_HZ_COMMON) \
  /workspaces/repository/vendor/linux-framework/include/linux/ktime.h \
  /workspaces/repository/vendor/linux-framework/include/linux/jiffies.h \
  /workspaces/repository/vendor/linux-framework/include/linux/time.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /workspaces/repository/vendor/linux-framework/include/linux/time32.h \
  /workspaces/repository/vendor/linux-framework/include/linux/timex.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/timex.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/timex.h \
    $(wildcard include/config/X86_TSC) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/tsc.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/msr.h \
    $(wildcard include/config/TRACEPOINTS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/msr.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/shared/msr.h \
  /workspaces/repository/vendor/linux-framework/include/linux/percpu.h \
    $(wildcard include/config/RANDOM_KMALLOC_CACHES) \
    $(wildcard include/config/PAGE_SIZE_4KB) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/RT_MUTEXES) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/SCHED_CLASS_EXT) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/CFS_BANDWIDTH) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/MEMCG_V1) \
    $(wildcard include/config/LRU_GEN) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/ARCH_HAS_CPU_PASID) \
    $(wildcard include/config/X86_BUS_LOCK_DETECT) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/DETECT_HUNG_TASK_BLOCKER) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/NUMA_BALANCING) \
    $(wildcard include/config/ARCH_HAS_LAZY_MMU_MODE) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/UPROBES) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/KSTACK_ERASE) \
    $(wildcard include/config/KSTACK_ERASE_METRICS) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/RETHOOK) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/RV) \
    $(wildcard include/config/RV_PER_TASK_MONITORS) \
    $(wildcard include/config/USER_EVENTS) \
    $(wildcard include/config/UNWIND_USER) \
    $(wildcard include/config/SCHED_PROXY_EXEC) \
    $(wildcard include/config/SCHED_MM_CID) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/sched.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pid_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sem_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/shm.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/shmparam.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kmsan_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/mutex_types.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /workspaces/repository/vendor/linux-framework/include/linux/osq_lock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/spinlock_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rwlock_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/plist_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/hrtimer_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/timerqueue_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rbtree_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/timer_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/seccomp_types.h \
    $(wildcard include/config/SECCOMP) \
  /workspaces/repository/vendor/linux-framework/include/linux/refcount_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/resource.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/resource.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/resource.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/resource.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/resource.h \
  /workspaces/repository/vendor/linux-framework/include/linux/latencytop.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/prio.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/signal.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/signal.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/signal.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/signal-defs.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/siginfo.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/siginfo.h \
  /workspaces/repository/vendor/linux-framework/include/linux/spinlock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bottom_half.h \
  /workspaces/repository/vendor/linux-framework/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/mmiowb.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/spinlock.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/qspinlock.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/paravirt.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/ZERO_CALL_USED_REGS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/frame.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/paravirt-spinlock.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/qspinlock.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/qrwlock.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/qrwlock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rwlock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /workspaces/repository/vendor/linux-framework/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /workspaces/repository/vendor/linux-framework/include/linux/syscall_user_dispatch_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/mm_types_task.h \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/tlbbatch.h \
  /workspaces/repository/vendor/linux-framework/include/linux/netdevice_xmit.h \
    $(wildcard include/config/NET_ACT_MIRRED) \
    $(wildcard include/config/NET_EGRESS) \
    $(wildcard include/config/NF_DUP_NETDEV) \
  /workspaces/repository/vendor/linux-framework/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /workspaces/repository/vendor/linux-framework/include/linux/posix-timers_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rseq_types.h \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/RSEQ_SLICE_EXTENSION) \
  /workspaces/repository/vendor/linux-framework/include/linux/irq_work_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/workqueue_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/seqlock_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kcsan.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rv.h \
    $(wildcard include/config/RV_LTL_MONITOR) \
    $(wildcard include/config/RV_REACTORS) \
  /workspaces/repository/vendor/linux-framework/include/linux/uidgid_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/tracepoint-defs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/unwind_deferred_types.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/kmap_size.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  /workspaces/repository/kprog/tv/build-kernel-x86/include/generated/rq-offsets.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/ext.h \
    $(wildcard include/config/EXT_GROUP_SCHED) \
  /workspaces/repository/vendor/linux-framework/include/linux/rhashtable-types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/mutex.h \
  /workspaces/repository/vendor/linux-framework/include/linux/debug_locks.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/time32.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/time.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/jiffies.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/include/generated/timeconst.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/ktime.h \
  /workspaces/repository/vendor/linux-framework/include/linux/timekeeping.h \
    $(wildcard include/config/POSIX_AUX_CLOCKS) \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /workspaces/repository/vendor/linux-framework/include/linux/clocksource_ids.h \
  /workspaces/repository/vendor/linux-framework/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /workspaces/repository/vendor/linux-framework/include/linux/rcupdate.h \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/RCU_STRICT_GRACE_PERIOD) \
    $(wildcard include/config/RCU_LAZY) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/VIRT_XFER_TO_GUEST_WORK) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /workspaces/repository/vendor/linux-framework/include/linux/context_tracking_irq.h \
    $(wildcard include/config/CONTEXT_TRACKING_IDLE) \
  /workspaces/repository/vendor/linux-framework/include/linux/rcutree.h \
  /workspaces/repository/vendor/linux-framework/include/linux/file.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rbtree_latch.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rbtree.h \
  /workspaces/repository/vendor/linux-framework/include/linux/seqlock.h \
    $(wildcard include/config/CC_IS_GCC) \
    $(wildcard include/config/GCC_VERSION) \
  /workspaces/repository/vendor/linux-framework/include/linux/mm_types.h \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/SLAB_OBJ_EXT) \
    $(wildcard include/config/HUGETLB_PMD_PAGE_TABLE_SHARING) \
    $(wildcard include/config/SLAB_FREELIST_HARDENED) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/ANON_VMA_NAME) \
    $(wildcard include/config/PER_VMA_LOCK) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/FUTEX_PRIVATE_HASH) \
    $(wildcard include/config/ARCH_HAS_ELF_CORE_EFLAGS) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/SPLIT_PMD_PTLOCKS) \
    $(wildcard include/config/HUGETLB_PAGE) \
    $(wildcard include/config/IOMMU_MM_DATA) \
    $(wildcard include/config/KSM) \
    $(wildcard include/config/LRU_GEN_WALKS_MMU) \
    $(wildcard include/config/MM_ID) \
    $(wildcard include/config/CORE_DUMP_DEFAULT_ELF_HEADERS) \
  /workspaces/repository/vendor/linux-framework/include/linux/auxvec.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/auxvec.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/auxvec.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kref.h \
  /workspaces/repository/vendor/linux-framework/include/linux/refcount.h \
  /workspaces/repository/vendor/linux-framework/include/linux/maple_tree.h \
    $(wildcard include/config/MAPLE_RCU_DISABLED) \
    $(wildcard include/config/DEBUG_MAPLE_TREE) \
  /workspaces/repository/vendor/linux-framework/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /workspaces/repository/vendor/linux-framework/include/linux/completion.h \
  /workspaces/repository/vendor/linux-framework/include/linux/swait.h \
  /workspaces/repository/vendor/linux-framework/include/linux/wait.h \
  /workspaces/repository/vendor/linux-framework/include/linux/uprobes.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/uprobes.h \
  /workspaces/repository/vendor/linux-framework/include/linux/notifier.h \
    $(wildcard include/config/TREE_SRCU) \
  /workspaces/repository/vendor/linux-framework/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/NEED_SRCU_NMI_SAFE) \
  /workspaces/repository/vendor/linux-framework/include/linux/rcu_segcblist.h \
  /workspaces/repository/vendor/linux-framework/include/linux/srcutree.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /workspaces/repository/vendor/linux-framework/include/linux/page-flags-layout.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/include/generated/bounds.h \
  /workspaces/repository/vendor/linux-framework/include/linux/percpu_counter.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/mmu.h \
    $(wildcard include/config/MODIFY_LDT_SYSCALL) \
    $(wildcard include/config/ADDRESS_MASKING) \
    $(wildcard include/config/BROADCAST_TLB_FLUSH) \
  /workspaces/repository/vendor/linux-framework/include/linux/module.h \
    $(wildcard include/config/MODULES_TREE_LOOKUP) \
    $(wildcard include/config/STACKTRACE_BUILD_ID) \
    $(wildcard include/config/ARCH_USES_CFI_TRAPS) \
    $(wildcard include/config/MODULE_SIG) \
    $(wildcard include/config/KALLSYMS) \
    $(wildcard include/config/DEBUG_INFO_BTF_MODULES) \
    $(wildcard include/config/EVENT_TRACING) \
    $(wildcard include/config/MODULE_UNLOAD) \
    $(wildcard include/config/CONSTRUCTORS) \
    $(wildcard include/config/FUNCTION_ERROR_INJECTION) \
  /workspaces/repository/vendor/linux-framework/include/linux/stat.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/stat.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/stat.h \
  /workspaces/repository/vendor/linux-framework/include/linux/uidgid.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /workspaces/repository/vendor/linux-framework/include/linux/highuid.h \
  /workspaces/repository/vendor/linux-framework/include/linux/buildid.h \
    $(wildcard include/config/VMCORE_INFO) \
  /workspaces/repository/vendor/linux-framework/include/linux/kmod.h \
  /workspaces/repository/vendor/linux-framework/include/linux/umh.h \
  /workspaces/repository/vendor/linux-framework/include/linux/gfp.h \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/ZONE_DEVICE) \
    $(wildcard include/config/CONTIG_ALLOC) \
  /workspaces/repository/vendor/linux-framework/include/linux/mmzone.h \
    $(wildcard include/config/ARCH_FORCE_MAX_ORDER) \
    $(wildcard include/config/PAGE_BLOCK_MAX_ORDER) \
    $(wildcard include/config/CMA) \
    $(wildcard include/config/MEMORY_ISOLATION) \
    $(wildcard include/config/ZSMALLOC) \
    $(wildcard include/config/UNACCEPTED_MEMORY) \
    $(wildcard include/config/IOMMU_SUPPORT) \
    $(wildcard include/config/LRU_GEN_STATS) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_EXTENSION) \
    $(wildcard include/config/DEFERRED_STRUCT_PAGE_INIT) \
    $(wildcard include/config/HAVE_MEMORYLESS_NODES) \
    $(wildcard include/config/SPARSEMEM_EXTREME) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP_PREINIT) \
    $(wildcard include/config/HAVE_ARCH_PFN_VALID) \
  /workspaces/repository/vendor/linux-framework/include/linux/list_nulls.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pageblock-flags.h \
    $(wildcard include/config/HUGETLB_PAGE_SIZE_VARIABLE) \
  /workspaces/repository/vendor/linux-framework/include/linux/page-flags.h \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_2) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_3) \
    $(wildcard include/config/MIGRATION) \
    $(wildcard include/config/HUGETLB_PAGE_OPTIMIZE_VMEMMAP) \
  /workspaces/repository/vendor/linux-framework/include/linux/local_lock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/local_lock_internal.h \
  /workspaces/repository/vendor/linux-framework/include/linux/zswap.h \
    $(wildcard include/config/ZSWAP) \
  /workspaces/repository/vendor/linux-framework/include/linux/memory_hotplug.h \
    $(wildcard include/config/ARCH_HAS_ADD_PAGES) \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/mmzone.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/mmzone.h \
  /workspaces/repository/vendor/linux-framework/include/linux/topology.h \
    $(wildcard include/config/USE_PERCPU_NUMA_NODE_ID) \
    $(wildcard include/config/SCHED_SMT) \
    $(wildcard include/config/GENERIC_ARCH_TOPOLOGY) \
  /workspaces/repository/vendor/linux-framework/include/linux/arch_topology.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/topology.h \
    $(wildcard include/config/X86_LOCAL_APIC) \
    $(wildcard include/config/SCHED_MC_PRIO) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/EISA) \
    $(wildcard include/config/X86_MPPARSE) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/mpspec_def.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/x86_init.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/apicdef.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/topology.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cpu_smt.h \
    $(wildcard include/config/HOTPLUG_SMT) \
  /workspaces/repository/vendor/linux-framework/include/linux/sysctl.h \
    $(wildcard include/config/SYSCTL) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/sysctl.h \
  /workspaces/repository/vendor/linux-framework/include/linux/elf.h \
    $(wildcard include/config/ARCH_HAVE_EXTRA_ELF_NOTES) \
    $(wildcard include/config/ARCH_USE_GNU_PROPERTY) \
    $(wildcard include/config/ARCH_HAVE_ELF_PROT) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/elf.h \
    $(wildcard include/config/X86_X32_ABI) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/ia32.h \
  /workspaces/repository/vendor/linux-framework/include/linux/compat.h \
    $(wildcard include/config/ARCH_HAS_SYSCALL_WRAPPER) \
    $(wildcard include/config/COMPAT_OLD_SIGACTION) \
    $(wildcard include/config/HARDENED_USERCOPY) \
    $(wildcard include/config/ODD_RT_SIGACTION) \
  /workspaces/repository/vendor/linux-framework/include/linux/sem.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/sem.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ipc.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/ipc.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/ipcbuf.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/ipcbuf.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/sembuf.h \
  /workspaces/repository/vendor/linux-framework/include/linux/socket.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/socket.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/socket.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/sockios.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/sockios.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/sockios.h \
  /workspaces/repository/vendor/linux-framework/include/linux/uio.h \
    $(wildcard include/config/ARCH_HAS_COPY_MC) \
  /workspaces/repository/vendor/linux-framework/include/linux/ucopysize.h \
    $(wildcard include/config/HARDENED_USERCOPY_DEFAULT_ON) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/uio.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/socket.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/libc-compat.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/hdlc/ioctl.h \
  /workspaces/repository/vendor/linux-framework/include/linux/fs.h \
    $(wildcard include/config/FANOTIFY_ACCESS_PERMISSIONS) \
    $(wildcard include/config/READ_ONLY_THP_FOR_FS) \
    $(wildcard include/config/FS_POSIX_ACL) \
    $(wildcard include/config/CGROUP_WRITEBACK) \
    $(wildcard include/config/IMA) \
    $(wildcard include/config/FILE_LOCKING) \
    $(wildcard include/config/FSNOTIFY) \
    $(wildcard include/config/EPOLL) \
    $(wildcard include/config/FS_DAX) \
    $(wildcard include/config/BLOCK) \
    $(wildcard include/config/UNICODE) \
  /workspaces/repository/vendor/linux-framework/include/linux/fs/super.h \
  /workspaces/repository/vendor/linux-framework/include/linux/fs/super_types.h \
    $(wildcard include/config/QUOTA) \
    $(wildcard include/config/FS_ENCRYPTION) \
    $(wildcard include/config/FS_VERITY) \
  /workspaces/repository/vendor/linux-framework/include/linux/fs_dirent.h \
  /workspaces/repository/vendor/linux-framework/include/linux/errseq.h \
  /workspaces/repository/vendor/linux-framework/include/linux/list_lru.h \
  /workspaces/repository/vendor/linux-framework/include/linux/shrinker.h \
    $(wildcard include/config/SHRINKER_DEBUG) \
  /workspaces/repository/vendor/linux-framework/include/linux/xarray.h \
    $(wildcard include/config/XARRAY_MULTI) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/mm.h \
    $(wildcard include/config/MMU_LAZY_TLB_REFCOUNT) \
    $(wildcard include/config/ARCH_HAS_MEMBARRIER_CALLBACKS) \
    $(wildcard include/config/ARCH_HAS_SYNC_CORE_BEFORE_USERMODE) \
  /workspaces/repository/vendor/linux-framework/include/linux/sync_core.h \
    $(wildcard include/config/ARCH_HAS_PREPARE_SYNC_CORE_CMD) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/sync_core.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/coredump.h \
  /workspaces/repository/vendor/linux-framework/include/linux/list_bl.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bit_spinlock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/uuid.h \
  /workspaces/repository/vendor/linux-framework/include/linux/percpu-rwsem.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rcuwait.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/signal.h \
    $(wildcard include/config/SCHED_AUTOGROUP) \
    $(wildcard include/config/BSD_PROCESS_ACCT) \
    $(wildcard include/config/TASKSTATS) \
    $(wildcard include/config/STACK_GROWSUP) \
  /workspaces/repository/vendor/linux-framework/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /workspaces/repository/vendor/linux-framework/include/linux/signal.h \
    $(wildcard include/config/DYNAMIC_SIGFRAME) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/jobctl.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/task.h \
    $(wildcard include/config/HAVE_EXIT_THREAD) \
    $(wildcard include/config/ARCH_WANTS_DYNAMIC_TASK_STRUCT) \
    $(wildcard include/config/HAVE_ARCH_THREAD_STRUCT_WHITELIST) \
  /workspaces/repository/vendor/linux-framework/include/linux/uaccess.h \
    $(wildcard include/config/ARCH_HAS_SUBPAGE_FAULTS) \
  /workspaces/repository/vendor/linux-framework/include/linux/fault-inject-usercopy.h \
    $(wildcard include/config/FAULT_INJECTION_USERCOPY) \
  /workspaces/repository/vendor/linux-framework/include/linux/nospec.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/uaccess.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO_OUTPUT) \
    $(wildcard include/config/CC_HAS_ASM_GOTO_TIED_OUTPUT) \
    $(wildcard include/config/X86_INTEL_USERCOPY) \
  /workspaces/repository/vendor/linux-framework/include/linux/mmap_lock.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/smap.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/extable.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/tlbflush.h \
  /workspaces/repository/vendor/linux-framework/include/linux/mmu_notifier.h \
  /workspaces/repository/vendor/linux-framework/include/linux/interval_tree.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/invpcid.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pti.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pgtable.h \
    $(wildcard include/config/DEBUG_WX) \
    $(wildcard include/config/HAVE_ARCH_TRANSPARENT_HUGEPAGE_PUD) \
    $(wildcard include/config/ARCH_SUPPORTS_PMD_PFNMAP) \
    $(wildcard include/config/ARCH_SUPPORTS_PUD_PFNMAP) \
    $(wildcard include/config/HAVE_ARCH_SOFT_DIRTY) \
    $(wildcard include/config/ARCH_ENABLE_THP_MIGRATION) \
    $(wildcard include/config/PAGE_TABLE_CHECK) \
    $(wildcard include/config/X86_SGX) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pkru.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/fpu/api.h \
    $(wildcard include/config/MATH_EMULATION) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/coco.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/pgtable_uffd.h \
    $(wildcard include/config/PTE_MARKER_UFFD_WP) \
  /workspaces/repository/vendor/linux-framework/include/linux/page_table_check.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pgtable_64.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/fixmap.h \
    $(wildcard include/config/PROVIDE_OHCI1394_DMA_INIT) \
    $(wildcard include/config/X86_IO_APIC) \
    $(wildcard include/config/PCI_MMCONFIG) \
    $(wildcard include/config/ACPI_APEI_GHES) \
    $(wildcard include/config/INTEL_TXT) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/vsyscall.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/fixmap.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pgtable-invert.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/uaccess_64.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/access_ok.h \
    $(wildcard include/config/ALTERNATE_USER_ADDRESS_SPACE) \
  /workspaces/repository/vendor/linux-framework/include/linux/cred.h \
  /workspaces/repository/vendor/linux-framework/include/linux/capability.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/capability.h \
  /workspaces/repository/vendor/linux-framework/include/linux/key.h \
    $(wildcard include/config/KEY_NOTIFICATIONS) \
  /workspaces/repository/vendor/linux-framework/include/linux/assoc_array.h \
    $(wildcard include/config/ASSOCIATIVE_ARRAY) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/user.h \
    $(wildcard include/config/VFIO_PCI_ZDEV_KVM) \
    $(wildcard include/config/IOMMUFD) \
    $(wildcard include/config/WATCH_QUEUE) \
  /workspaces/repository/vendor/linux-framework/include/linux/ratelimit.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pid.h \
  /workspaces/repository/vendor/linux-framework/include/linux/posix-timers.h \
  /workspaces/repository/vendor/linux-framework/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /workspaces/repository/vendor/linux-framework/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /workspaces/repository/vendor/linux-framework/include/linux/hrtimer_defs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/timerqueue.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rcuref.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rcu_sync.h \
  /workspaces/repository/vendor/linux-framework/include/linux/quota.h \
    $(wildcard include/config/QUOTA_NETLINK_INTERFACE) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/dqblk_xfs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dqblk_v1.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dqblk_v2.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dqblk_qtree.h \
  /workspaces/repository/vendor/linux-framework/include/linux/projid.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/quota.h \
  /workspaces/repository/vendor/linux-framework/include/linux/unicode.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dcache.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rculist_bl.h \
  /workspaces/repository/vendor/linux-framework/include/linux/lockref.h \
    $(wildcard include/config/ARCH_USE_CMPXCHG_LOCKREF) \
  /workspaces/repository/vendor/linux-framework/include/linux/stringhash.h \
    $(wildcard include/config/DCACHE_WORD_ACCESS) \
  /workspaces/repository/vendor/linux-framework/include/linux/hash.h \
    $(wildcard include/config/HAVE_ARCH_HASH) \
  /workspaces/repository/vendor/linux-framework/include/linux/vfsdebug.h \
    $(wildcard include/config/DEBUG_VFS) \
  /workspaces/repository/vendor/linux-framework/include/linux/wait_bit.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kdev_t.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/kdev_t.h \
  /workspaces/repository/vendor/linux-framework/include/linux/path.h \
  /workspaces/repository/vendor/linux-framework/include/linux/radix-tree.h \
  /workspaces/repository/vendor/linux-framework/include/linux/semaphore.h \
  /workspaces/repository/vendor/linux-framework/include/linux/fcntl.h \
    $(wildcard include/config/ARCH_32BIT_OFF_T) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/fcntl.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/fcntl.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/fcntl.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/openat2.h \
  /workspaces/repository/vendor/linux-framework/include/linux/migrate_mode.h \
  /workspaces/repository/vendor/linux-framework/include/linux/delayed_call.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ioprio.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/rt.h \
  /workspaces/repository/vendor/linux-framework/include/linux/iocontext.h \
    $(wildcard include/config/BLK_ICQ) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/ioprio.h \
  /workspaces/repository/vendor/linux-framework/include/linux/mount.h \
  /workspaces/repository/vendor/linux-framework/include/linux/mnt_idmapping.h \
  /workspaces/repository/vendor/linux-framework/include/linux/slab.h \
    $(wildcard include/config/FAILSLAB) \
    $(wildcard include/config/KFENCE) \
    $(wildcard include/config/SLUB_TINY) \
    $(wildcard include/config/SLUB_DEBUG) \
    $(wildcard include/config/SLAB_BUCKETS) \
    $(wildcard include/config/KVFREE_RCU_BATCHED) \
  /workspaces/repository/vendor/linux-framework/include/linux/percpu-refcount.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kasan.h \
    $(wildcard include/config/KASAN_STACK) \
    $(wildcard include/config/KASAN_VMALLOC) \
  /workspaces/repository/vendor/linux-framework/include/linux/kasan-enabled.h \
    $(wildcard include/config/ARCH_DEFER_KASAN) \
  /workspaces/repository/vendor/linux-framework/include/linux/kasan-tags.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rw_hint.h \
  /workspaces/repository/vendor/linux-framework/include/linux/file_ref.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/fs.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/aio_abi.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/unistd.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/unistd.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/unistd.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/unistd_64.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/unistd_64_x32.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/unistd_32_ia32.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/compat.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/task_stack.h \
    $(wildcard include/config/DEBUG_STACK_USAGE) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/magic.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/user32.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/compat.h \
    $(wildcard include/config/COMPAT_FOR_U64_ALIGNMENT) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/syscall_wrapper.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/user.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/user_64.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/fsgsbase.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/vdso.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/elf.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/elf-em.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kobject.h \
    $(wildcard include/config/UEVENT_HELPER) \
    $(wildcard include/config/DEBUG_KOBJECT_RELEASE) \
  /workspaces/repository/vendor/linux-framework/include/linux/sysfs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kernfs.h \
    $(wildcard include/config/KERNFS) \
  /workspaces/repository/vendor/linux-framework/include/linux/idr.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kobject_ns.h \
  /workspaces/repository/vendor/linux-framework/include/linux/moduleparam.h \
    $(wildcard include/config/ALPHA) \
    $(wildcard include/config/PPC64) \
  /workspaces/repository/vendor/linux-framework/include/linux/error-injection.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/error-injection.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/module.h \
    $(wildcard include/config/UNWINDER_ORC) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/module.h \
    $(wildcard include/config/HAVE_MOD_ARCH_SPECIFIC) \
  /workspaces/repository/vendor/linux-framework/include/linux/kallsyms.h \
    $(wildcard include/config/KALLSYMS_ALL) \
    $(wildcard include/config/HAVE_FUNCTION_DESCRIPTORS) \
  /workspaces/repository/vendor/linux-framework/include/linux/mm.h \
    $(wildcard include/config/HAVE_ARCH_MMAP_RND_BITS) \
    $(wildcard include/config/HAVE_ARCH_MMAP_RND_COMPAT_BITS) \
    $(wildcard include/config/PPC32) \
    $(wildcard include/config/RISCV_USER_CFI) \
    $(wildcard include/config/ARM64_GCS) \
    $(wildcard include/config/ARCH_HAS_PKEYS) \
    $(wildcard include/config/ARCH_PKEY_BITS) \
    $(wildcard include/config/PARISC) \
    $(wildcard include/config/SPARC64) \
    $(wildcard include/config/ARM64_MTE) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_MINOR) \
    $(wildcard include/config/MSEAL_SYSTEM_MAPPINGS) \
    $(wildcard include/config/FIND_NORMAL_PAGE) \
    $(wildcard include/config/SHMEM) \
    $(wildcard include/config/HAVE_GIGANTIC_FOLIOS) \
    $(wildcard include/config/ARCH_HAS_PTE_SPECIAL) \
    $(wildcard include/config/ASYNC_KERNEL_PGTABLE_FREE) \
    $(wildcard include/config/SPLIT_PTE_PTLOCKS) \
    $(wildcard include/config/HIGHPTE) \
    $(wildcard include/config/DEBUG_VM_RB) \
    $(wildcard include/config/PAGE_POISONING) \
    $(wildcard include/config/INIT_ON_ALLOC_DEFAULT_ON) \
    $(wildcard include/config/INIT_ON_FREE_DEFAULT_ON) \
    $(wildcard include/config/DEBUG_PAGEALLOC) \
    $(wildcard include/config/ARCH_WANT_OPTIMIZE_DAX_VMEMMAP) \
    $(wildcard include/config/HUGETLBFS) \
    $(wildcard include/config/MAPPING_DIRTY_HELPERS) \
    $(wildcard include/config/PAGE_POOL) \
  /workspaces/repository/vendor/linux-framework/include/linux/pgalloc_tag.h \
  /workspaces/repository/vendor/linux-framework/include/linux/page_ext.h \
  /workspaces/repository/vendor/linux-framework/include/linux/stacktrace.h \
    $(wildcard include/config/ARCH_STACKWALK) \
    $(wildcard include/config/STACKTRACE) \
    $(wildcard include/config/HAVE_RELIABLE_STACKTRACE) \
  /workspaces/repository/vendor/linux-framework/include/linux/page_ref.h \
    $(wildcard include/config/DEBUG_PAGE_REF) \
  /workspaces/repository/vendor/linux-framework/include/linux/sizes.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pgtable.h \
    $(wildcard include/config/ARCH_HAS_NONLEAF_PMD_YOUNG) \
    $(wildcard include/config/ARCH_HAS_HW_PTE_YOUNG) \
    $(wildcard include/config/GUP_GET_PXX_LOW_HIGH) \
    $(wildcard include/config/ARCH_WANT_PMD_MKWRITE) \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMAP) \
    $(wildcard include/config/X86_ESPFIX64) \
  /workspaces/repository/vendor/linux-framework/include/linux/memremap.h \
    $(wildcard include/config/DEVICE_PRIVATE) \
    $(wildcard include/config/PCI_P2PDMA) \
  /workspaces/repository/vendor/linux-framework/include/linux/ioport.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cacheinfo.h \
    $(wildcard include/config/ACPI_PPTT) \
    $(wildcard include/config/ARM) \
    $(wildcard include/config/ARCH_HAS_CPU_CACHE_ALIASING) \
  /workspaces/repository/vendor/linux-framework/include/linux/cpuhplock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/iommu-debug-pagealloc.h \
    $(wildcard include/config/IOMMU_DEBUG_PAGEALLOC) \
  /workspaces/repository/vendor/linux-framework/include/linux/huge_mm.h \
    $(wildcard include/config/PGTABLE_HAS_HUGE_LEAVES) \
    $(wildcard include/config/PERSISTENT_HUGE_ZERO_FOLIO) \
  /workspaces/repository/vendor/linux-framework/include/linux/vmstat.h \
    $(wildcard include/config/VM_EVENT_COUNTERS) \
    $(wildcard include/config/DEBUG_TLBFLUSH) \
    $(wildcard include/config/PER_VMA_LOCK_STATS) \
  /workspaces/repository/vendor/linux-framework/include/linux/vm_event_item.h \
    $(wildcard include/config/BALLOON) \
    $(wildcard include/config/BALLOON_MIGRATION) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/sections.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/sections.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bpfptr.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sockptr.h \
  /workspaces/repository/vendor/linux-framework/include/linux/btf.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bsearch.h \
  /workspaces/repository/vendor/linux-framework/include/linux/btf_ids.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/btf.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rcupdate_trace.h \
    $(wildcard include/config/TASKS_TRACE_RCU_NO_MB) \
  /workspaces/repository/vendor/linux-framework/include/linux/static_call.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cpu.h \
    $(wildcard include/config/GENERIC_CPU_DEVICES) \
    $(wildcard include/config/PM_SLEEP_SMP) \
    $(wildcard include/config/PM_SLEEP_SMP_NONZERO_CPU) \
    $(wildcard include/config/ARCH_HAS_CPU_FINALIZE_INIT) \
    $(wildcard include/config/CPU_MITIGATIONS) \
  /workspaces/repository/vendor/linux-framework/include/linux/node.h \
    $(wildcard include/config/HMEM_REPORTING) \
  /workspaces/repository/vendor/linux-framework/include/linux/device.h \
    $(wildcard include/config/GENERIC_MSI_IRQ) \
    $(wildcard include/config/ENERGY_MODEL) \
    $(wildcard include/config/PINCTRL) \
    $(wildcard include/config/ARCH_HAS_DMA_OPS) \
    $(wildcard include/config/DMA_DECLARE_COHERENT) \
    $(wildcard include/config/DMA_CMA) \
    $(wildcard include/config/SWIOTLB) \
    $(wildcard include/config/SWIOTLB_DYNAMIC) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_DEVICE) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU_ALL) \
    $(wildcard include/config/DMA_OPS_BYPASS) \
    $(wildcard include/config/DMA_NEED_SYNC) \
    $(wildcard include/config/IOMMU_DMA) \
    $(wildcard include/config/PM) \
    $(wildcard include/config/PM_SLEEP) \
    $(wildcard include/config/OF) \
    $(wildcard include/config/DEVTMPFS) \
  /workspaces/repository/vendor/linux-framework/include/linux/dev_printk.h \
  /workspaces/repository/vendor/linux-framework/include/linux/energy_model.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/cpufreq.h \
    $(wildcard include/config/CPU_FREQ) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/topology.h \
    $(wildcard include/config/SCHED_CLUSTER) \
    $(wildcard include/config/SCHED_MC) \
    $(wildcard include/config/CPU_FREQ_GOV_SCHEDUTIL) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/idle.h \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/sd_flags.h \
  /workspaces/repository/vendor/linux-framework/include/linux/klist.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pm.h \
    $(wildcard include/config/VT_CONSOLE_SLEEP) \
    $(wildcard include/config/CXL_SUSPEND) \
    $(wildcard include/config/PM_CLK) \
    $(wildcard include/config/PM_GENERIC_DOMAINS) \
  /workspaces/repository/vendor/linux-framework/include/linux/device/bus.h \
    $(wildcard include/config/ACPI) \
  /workspaces/repository/vendor/linux-framework/include/linux/device/class.h \
  /workspaces/repository/vendor/linux-framework/include/linux/device/devres.h \
    $(wildcard include/config/HAS_IOMEM) \
  /workspaces/repository/vendor/linux-framework/include/linux/device/driver.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/device.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pm_wakeup.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cpuhotplug.h \
    $(wildcard include/config/HOTPLUG_CORE_SYNC_DEAD) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/static_call.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/text-patching.h \
    $(wildcard include/config/UML_X86) \
  /workspaces/repository/vendor/linux-framework/include/linux/memcontrol.h \
    $(wildcard include/config/MEMCG_NMI_SAFETY_REQUIRES_ATOMIC) \
  /workspaces/repository/vendor/linux-framework/include/linux/cgroup.h \
    $(wildcard include/config/DEBUG_CGROUP_REF) \
    $(wildcard include/config/CGROUP_CPUACCT) \
    $(wildcard include/config/CGROUP_DATA) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/cgroupstats.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/taskstats.h \
  /workspaces/repository/vendor/linux-framework/include/linux/seq_file.h \
  /workspaces/repository/vendor/linux-framework/include/linux/string_helpers.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ctype.h \
  /workspaces/repository/vendor/linux-framework/include/linux/string_choices.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ns_common.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ns/ns_common_types.h \
    $(wildcard include/config/IPC_NS) \
    $(wildcard include/config/NET_NS) \
    $(wildcard include/config/PID_NS) \
    $(wildcard include/config/TIME_NS) \
    $(wildcard include/config/UTS_NS) \
  /workspaces/repository/vendor/linux-framework/include/linux/ns/nstree_types.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/nsfs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/nsproxy.h \
  /workspaces/repository/vendor/linux-framework/include/linux/user_namespace.h \
    $(wildcard include/config/INOTIFY_USER) \
    $(wildcard include/config/FANOTIFY) \
    $(wildcard include/config/BINFMT_MISC) \
    $(wildcard include/config/PERSISTENT_KEYRINGS) \
  /workspaces/repository/vendor/linux-framework/include/linux/rculist_nulls.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kernel_stat.h \
    $(wildcard include/config/GENERIC_IRQ_STAT_SNAPSHOT) \
  /workspaces/repository/vendor/linux-framework/include/linux/interrupt.h \
    $(wildcard include/config/IRQ_FORCED_THREADING) \
    $(wildcard include/config/GENERIC_IRQ_PROBE) \
  /workspaces/repository/vendor/linux-framework/include/linux/irqreturn.h \
  /workspaces/repository/vendor/linux-framework/include/linux/hardirq.h \
  /workspaces/repository/vendor/linux-framework/include/linux/context_tracking_state.h \
    $(wildcard include/config/CONTEXT_TRACKING_USER) \
    $(wildcard include/config/CONTEXT_TRACKING) \
    $(wildcard include/config/RCU_DYNTICKS_TORTURE) \
  /workspaces/repository/vendor/linux-framework/include/linux/ftrace_irq.h \
    $(wildcard include/config/HWLAT_TRACER) \
    $(wildcard include/config/OSNOISE_TRACER) \
  /workspaces/repository/vendor/linux-framework/include/linux/vtime.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING) \
    $(wildcard include/config/IRQ_TIME_ACCOUNTING) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/hardirq.h \
    $(wildcard include/config/KVM_INTEL) \
    $(wildcard include/config/KVM) \
    $(wildcard include/config/GUEST_PERF_EVENTS) \
    $(wildcard include/config/X86_THERMAL_VECTOR) \
    $(wildcard include/config/X86_MCE_THRESHOLD) \
    $(wildcard include/config/X86_MCE_AMD) \
    $(wildcard include/config/X86_HV_CALLBACK_VECTOR) \
    $(wildcard include/config/HYPERV) \
    $(wildcard include/config/X86_POSTED_MSI) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/irq.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/irq_vectors.h \
    $(wildcard include/config/PCI_MSI) \
  /workspaces/repository/vendor/linux-framework/include/linux/cgroup-defs.h \
    $(wildcard include/config/CGROUP_NET_PRIO) \
  /workspaces/repository/vendor/linux-framework/include/linux/u64_stats_sync.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/local64.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/local64.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/local.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bpf-cgroup-defs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/psi_types.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kthread.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cgroup_subsys.h \
    $(wildcard include/config/CGROUP_DEVICE) \
    $(wildcard include/config/CGROUP_FREEZER) \
    $(wildcard include/config/CGROUP_PERF) \
    $(wildcard include/config/CGROUP_HUGETLB) \
    $(wildcard include/config/CGROUP_PIDS) \
    $(wildcard include/config/CGROUP_RDMA) \
    $(wildcard include/config/CGROUP_MISC) \
    $(wildcard include/config/CGROUP_DMEM) \
    $(wildcard include/config/CGROUP_DEBUG) \
  /workspaces/repository/vendor/linux-framework/include/linux/cgroup_namespace.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cgroup_refcnt.h \
  /workspaces/repository/vendor/linux-framework/include/linux/page_counter.h \
  /workspaces/repository/vendor/linux-framework/include/linux/vmpressure.h \
  /workspaces/repository/vendor/linux-framework/include/linux/eventfd.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/eventfd.h \
  /workspaces/repository/vendor/linux-framework/include/linux/writeback.h \
  /workspaces/repository/vendor/linux-framework/include/linux/flex_proportions.h \
  /workspaces/repository/vendor/linux-framework/include/linux/backing-dev-defs.h \
    $(wildcard include/config/DEBUG_FS) \
  /workspaces/repository/vendor/linux-framework/include/linux/blk_types.h \
    $(wildcard include/config/FAIL_MAKE_REQUEST) \
    $(wildcard include/config/BLK_CGROUP_IOCOST) \
    $(wildcard include/config/BLK_INLINE_ENCRYPTION) \
    $(wildcard include/config/BLK_DEV_INTEGRITY) \
  /workspaces/repository/vendor/linux-framework/include/linux/bvec.h \
  /workspaces/repository/vendor/linux-framework/include/linux/highmem.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cacheflush.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cacheflush.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/cacheflush.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kmsan.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dma-direction.h \
  /workspaces/repository/vendor/linux-framework/include/linux/highmem-internal.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pagevec.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bio.h \
    $(wildcard include/config/BLK_DEV_ZONED) \
  /workspaces/repository/vendor/linux-framework/include/linux/mempool.h \
  /workspaces/repository/vendor/linux-framework/include/linux/cfi.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cfi.h \
    $(wildcard include/config/FINEIBT_BHI) \
    $(wildcard include/config/FUNCTION_PADDING_CFI) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/rqspinlock.h \
    $(wildcard include/config/QUEUED_SPINLOCKS) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/rqspinlock.h \
  /workspaces/repository/vendor/linux-framework/include/linux/bpf_types.h \
    $(wildcard include/config/NETFILTER_BPF_LINK) \
    $(wildcard include/config/XDP_SOCKETS) \
  /workspaces/repository/vendor/linux-framework/include/linux/delay.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/delay.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/delay.h \
  /workspaces/repository/vendor/linux-framework/include/linux/tracepoint.h \
    $(wildcard include/config/HAVE_SYSCALL_TRACEPOINTS) \
  /workspaces/repository/vendor/linux-framework/include/linux/net.h \
  /workspaces/repository/vendor/linux-framework/include/linux/once.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/net.h \
  /workspaces/repository/vendor/linux-framework/include/linux/inet.h \
  /workspaces/repository/vendor/linux-framework/include/net/net_namespace.h \
    $(wildcard include/config/NF_CONNTRACK) \
    $(wildcard include/config/NF_FLOW_TABLE) \
    $(wildcard include/config/UNIX) \
    $(wildcard include/config/IEEE802154_6LOWPAN) \
    $(wildcard include/config/IP_SCTP) \
    $(wildcard include/config/NETFILTER) \
    $(wildcard include/config/NF_TABLES) \
    $(wildcard include/config/WEXT_CORE) \
    $(wildcard include/config/IP_VS) \
    $(wildcard include/config/MPLS) \
    $(wildcard include/config/CAN) \
    $(wildcard include/config/MCTP) \
    $(wildcard include/config/CRYPTO_USER) \
    $(wildcard include/config/SMC) \
    $(wildcard include/config/DEBUG_NET_SMALL_RTNL) \
    $(wildcard include/config/VSOCKETS) \
    $(wildcard include/config/NET_NS_REFCNT_TRACKER) \
  /workspaces/repository/vendor/linux-framework/include/net/flow.h \
  /workspaces/repository/vendor/linux-framework/include/linux/in6.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/in6.h \
  /workspaces/repository/vendor/linux-framework/include/net/inet_dscp.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/core.h \
    $(wildcard include/config/RPS) \
  /workspaces/repository/vendor/linux-framework/include/net/netns/mib.h \
    $(wildcard include/config/XFRM_STATISTICS) \
    $(wildcard include/config/TLS) \
    $(wildcard include/config/MPTCP) \
  /workspaces/repository/vendor/linux-framework/include/net/snmp.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/snmp.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/unix.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/packet.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/ipv4.h \
    $(wildcard include/config/IP_ROUTE_MULTIPATH) \
    $(wildcard include/config/NET_UDP_TUNNEL) \
    $(wildcard include/config/IP_MULTIPLE_TABLES) \
    $(wildcard include/config/NET_L3_MASTER_DEV) \
    $(wildcard include/config/IP_MROUTE) \
    $(wildcard include/config/IP_MROUTE_MULTIPLE_TABLES) \
  /workspaces/repository/vendor/linux-framework/include/net/inet_frag.h \
  /workspaces/repository/vendor/linux-framework/include/net/dropreason-core.h \
  /workspaces/repository/vendor/linux-framework/include/linux/siphash.h \
    $(wildcard include/config/HAVE_EFFICIENT_UNALIGNED_ACCESS) \
  /workspaces/repository/vendor/linux-framework/include/net/netns/ipv6.h \
    $(wildcard include/config/IPV6_MULTIPLE_TABLES) \
    $(wildcard include/config/IPV6_SUBTREES) \
    $(wildcard include/config/IPV6_MROUTE) \
    $(wildcard include/config/IPV6_MROUTE_MULTIPLE_TABLES) \
    $(wildcard include/config/NF_DEFRAG_IPV6) \
  /workspaces/repository/vendor/linux-framework/include/net/dst_ops.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/icmpv6.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/nexthop.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/ieee802154_6lowpan.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/sctp.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/netfilter.h \
    $(wildcard include/config/LWTUNNEL) \
    $(wildcard include/config/NETFILTER_FAMILY_ARP) \
    $(wildcard include/config/NETFILTER_FAMILY_BRIDGE) \
    $(wildcard include/config/NF_DEFRAG_IPV4) \
  /workspaces/repository/vendor/linux-framework/include/linux/netfilter_defs.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netfilter.h \
  /workspaces/repository/vendor/linux-framework/include/linux/in.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/in.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/conntrack.h \
    $(wildcard include/config/NF_CT_PROTO_SCTP) \
    $(wildcard include/config/NF_CT_PROTO_GRE) \
    $(wildcard include/config/NF_CONNTRACK_EVENTS) \
    $(wildcard include/config/NF_CONNTRACK_LABELS) \
  /workspaces/repository/vendor/linux-framework/include/linux/netfilter/nf_conntrack_tcp.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netfilter/nf_conntrack_tcp.h \
  /workspaces/repository/vendor/linux-framework/include/linux/netfilter/nf_conntrack_sctp.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netfilter/nf_conntrack_sctp.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netfilter/nf_conntrack_tuple_common.h \
  /workspaces/repository/vendor/linux-framework/include/linux/netfilter/nf_conntrack_common.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netfilter/nf_conntrack_common.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/flow_table.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/nftables.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/xfrm.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/xfrm.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/mpls.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/can.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/xdp.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/smc.h \
    $(wildcard include/config/SMC_HS_CTRL_BPF) \
  /workspaces/repository/vendor/linux-framework/include/net/netns/bpf.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/mctp.h \
  /workspaces/repository/vendor/linux-framework/include/linux/hashtable.h \
  /workspaces/repository/vendor/linux-framework/include/net/netns/vsock.h \
  /workspaces/repository/vendor/linux-framework/include/net/net_trackers.h \
    $(wildcard include/config/NET_DEV_REFCNT_TRACKER) \
  /workspaces/repository/vendor/linux-framework/include/linux/ref_tracker.h \
    $(wildcard include/config/REF_TRACKER) \
  /workspaces/repository/vendor/linux-framework/include/linux/stackdepot.h \
    $(wildcard include/config/STACKDEPOT) \
    $(wildcard include/config/STACKDEPOT_MAX_FRAMES) \
    $(wildcard include/config/STACKDEPOT_ALWAYS_INIT) \
  /workspaces/repository/vendor/linux-framework/include/linux/skbuff.h \
    $(wildcard include/config/BRIDGE_NETFILTER) \
    $(wildcard include/config/NET_TC_SKB_EXT) \
    $(wildcard include/config/MAX_SKB_FRAGS) \
    $(wildcard include/config/NET_SOCK_MSG) \
    $(wildcard include/config/SKB_EXTENSIONS) \
    $(wildcard include/config/NET_XGRESS) \
    $(wildcard include/config/WIRELESS) \
    $(wildcard include/config/IPV6_NDISC_NODETYPE) \
    $(wildcard include/config/NETFILTER_XT_TARGET_TRACE) \
    $(wildcard include/config/NET_SWITCHDEV) \
    $(wildcard include/config/NET_REDIRECT) \
    $(wildcard include/config/NETFILTER_SKIP_EGRESS) \
    $(wildcard include/config/SKB_DECRYPTED) \
    $(wildcard include/config/NET_SCHED) \
    $(wildcard include/config/NET_RX_BUSY_POLL) \
    $(wildcard include/config/XPS) \
    $(wildcard include/config/NETWORK_SECMARK) \
    $(wildcard include/config/DEBUG_NET) \
    $(wildcard include/config/FAIL_SKB_REALLOC) \
    $(wildcard include/config/NETWORK_PHY_TIMESTAMPING) \
    $(wildcard include/config/MCTP_FLOWS) \
    $(wildcard include/config/INET_PSP) \
  /workspaces/repository/vendor/linux-framework/include/net/checksum.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/checksum.h \
    $(wildcard include/config/GENERIC_CSUM) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/checksum_64.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dma-mapping.h \
    $(wildcard include/config/DMA_API_DEBUG) \
    $(wildcard include/config/HAS_DMA) \
    $(wildcard include/config/NEED_DMA_MAP_STATE) \
  /workspaces/repository/vendor/linux-framework/include/linux/scatterlist.h \
    $(wildcard include/config/NEED_SG_DMA_LENGTH) \
    $(wildcard include/config/NEED_SG_DMA_FLAGS) \
    $(wildcard include/config/DEBUG_SG) \
    $(wildcard include/config/SGL_ALLOC) \
    $(wildcard include/config/ARCH_NO_SG_CHAIN) \
    $(wildcard include/config/SG_POOL) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/io.h \
    $(wildcard include/config/MTRR) \
    $(wildcard include/config/X86_PAT) \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/asm/early_ioremap.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/early_ioremap.h \
    $(wildcard include/config/GENERIC_EARLY_IOREMAP) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/shared/io.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/io.h \
    $(wildcard include/config/GENERIC_IOMAP) \
    $(wildcard include/config/TRACE_MMIO_ACCESS) \
    $(wildcard include/config/HAS_IOPORT) \
    $(wildcard include/config/GENERIC_IOREMAP) \
    $(wildcard include/config/HAS_IOPORT_MAP) \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/iomap.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/PCI) \
    $(wildcard include/config/NO_GENERIC_PCI_IOPORT_MAP) \
    $(wildcard include/config/GENERIC_PCI_IOMAP) \
  /workspaces/repository/vendor/linux-framework/include/linux/logic_pio.h \
    $(wildcard include/config/INDIRECT_PIO) \
  /workspaces/repository/vendor/linux-framework/include/linux/fwnode.h \
  /workspaces/repository/vendor/linux-framework/include/linux/netdev_features.h \
  /workspaces/repository/vendor/linux-framework/include/net/flow_dissector.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if_ether.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/pkt_cls.h \
    $(wildcard include/config/NET_CLS_ACT) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/pkt_sched.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if_packet.h \
  /workspaces/repository/vendor/linux-framework/include/linux/page_frag_cache.h \
  /workspaces/repository/vendor/linux-framework/include/net/net_debug.h \
  /workspaces/repository/vendor/linux-framework/include/net/netmem.h \
    $(wildcard include/config/NET_DEVMEM) \
  /workspaces/repository/vendor/linux-framework/include/linux/seq_file_net.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/un.h \
  /workspaces/repository/vendor/linux-framework/include/linux/filter.h \
    $(wildcard include/config/HAVE_EBPF_JIT) \
  /workspaces/repository/vendor/linux-framework/include/linux/sched/clock.h \
    $(wildcard include/config/ARCH_WANTS_NO_INSTR) \
    $(wildcard include/config/GENERIC_SCHED_CLOCK) \
    $(wildcard include/config/HAVE_UNSTABLE_SCHED_CLOCK) \
  /workspaces/repository/vendor/linux-framework/include/linux/set_memory.h \
    $(wildcard include/config/ARCH_HAS_SET_MEMORY) \
    $(wildcard include/config/ARCH_HAS_SET_DIRECT_MAP) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/set_memory.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/set_memory.h \
  /workspaces/repository/vendor/linux-framework/include/linux/if_vlan.h \
    $(wildcard include/config/VLAN_8021Q) \
    $(wildcard include/config/NET_POLL_CONTROLLER) \
  /workspaces/repository/vendor/linux-framework/include/linux/netdevice.h \
    $(wildcard include/config/DCB) \
    $(wildcard include/config/HYPERV_NET) \
    $(wildcard include/config/WLAN) \
    $(wildcard include/config/AX25) \
    $(wildcard include/config/MAC80211_MESH) \
    $(wildcard include/config/NET_IPIP) \
    $(wildcard include/config/NET_IPGRE) \
    $(wildcard include/config/IPV6_SIT) \
    $(wildcard include/config/IPV6_TUNNEL) \
    $(wildcard include/config/NETPOLL) \
    $(wildcard include/config/BQL) \
    $(wildcard include/config/RFS_ACCEL) \
    $(wildcard include/config/FCOE) \
    $(wildcard include/config/XFRM_OFFLOAD) \
    $(wildcard include/config/LIBFCOE) \
    $(wildcard include/config/NET_SHAPER) \
    $(wildcard include/config/NETFILTER_EGRESS) \
    $(wildcard include/config/WIRELESS_EXT) \
    $(wildcard include/config/TLS_DEVICE) \
    $(wildcard include/config/NET_DSA) \
    $(wildcard include/config/TIPC) \
    $(wildcard include/config/ATALK) \
    $(wildcard include/config/CFG80211) \
    $(wildcard include/config/IEEE802154) \
    $(wildcard include/config/6LOWPAN) \
    $(wildcard include/config/MPLS_ROUTING) \
    $(wildcard include/config/NETFILTER_INGRESS) \
    $(wildcard include/config/PCPU_DEV_REFCNT) \
    $(wildcard include/config/GARP) \
    $(wildcard include/config/MRP) \
    $(wildcard include/config/NET_DROP_MONITOR) \
    $(wildcard include/config/MACSEC) \
    $(wildcard include/config/DPLL) \
    $(wildcard include/config/DIMLIB) \
    $(wildcard include/config/NET_FLOW_LIMIT) \
    $(wildcard include/config/ETHTOOL_NETLINK) \
  /workspaces/repository/vendor/linux-framework/include/linux/prefetch.h \
  /workspaces/repository/vendor/linux-framework/include/linux/dynamic_queue_limits.h \
  /workspaces/repository/vendor/linux-framework/include/net/dcbnl.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/dcbnl.h \
  /workspaces/repository/vendor/linux-framework/include/net/netprio_cgroup.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/neighbour.h \
  /workspaces/repository/vendor/linux-framework/include/linux/netlink.h \
  /workspaces/repository/vendor/linux-framework/include/net/scm.h \
    $(wildcard include/config/SECURITY_NETWORK) \
  /workspaces/repository/vendor/linux-framework/include/linux/security.h \
    $(wildcard include/config/SECURITY_INFINIBAND) \
    $(wildcard include/config/SECURITY_NETWORK_XFRM) \
    $(wildcard include/config/SECURITY_PATH) \
    $(wildcard include/config/SECURITYFS) \
  /workspaces/repository/vendor/linux-framework/include/linux/kernel_read_file.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/lsm.h \
  /workspaces/repository/vendor/linux-framework/include/linux/lsm/selinux.h \
    $(wildcard include/config/SECURITY_SELINUX) \
  /workspaces/repository/vendor/linux-framework/include/linux/lsm/smack.h \
    $(wildcard include/config/SECURITY_SMACK) \
  /workspaces/repository/vendor/linux-framework/include/linux/lsm/apparmor.h \
    $(wildcard include/config/SECURITY_APPARMOR) \
  /workspaces/repository/vendor/linux-framework/include/linux/lsm/bpf.h \
  /workspaces/repository/vendor/linux-framework/include/net/compat.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netlink.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netdevice.h \
  /workspaces/repository/vendor/linux-framework/include/linux/if_ether.h \
  /workspaces/repository/vendor/linux-framework/include/linux/if_link.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if_link.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if_bonding.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/netdev.h \
  /workspaces/repository/vendor/linux-framework/include/net/neighbour_tables.h \
  /workspaces/repository/vendor/linux-framework/include/linux/etherdevice.h \
  /workspaces/repository/vendor/linux-framework/include/linux/crc32.h \
    $(wildcard include/config/CRC32_ARCH) \
  /workspaces/repository/vendor/linux-framework/include/linux/bitrev.h \
    $(wildcard include/config/HAVE_ARCH_BITREVERSE) \
  /workspaces/repository/vendor/linux-framework/include/linux/unaligned.h \
  /workspaces/repository/vendor/linux-framework/include/linux/unaligned/packed_struct.h \
  /workspaces/repository/vendor/linux-framework/include/vdso/unaligned.h \
  /workspaces/repository/vendor/linux-framework/include/linux/rtnetlink.h \
    $(wildcard include/config/NET_INGRESS) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/rtnetlink.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if_addr.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/if_vlan.h \
  /workspaces/repository/vendor/linux-framework/include/linux/vmalloc.h \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMALLOC) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/vmalloc.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/pgtable_areas.h \
  /workspaces/repository/vendor/linux-framework/include/crypto/sha1.h \
  /workspaces/repository/vendor/linux-framework/include/net/sch_generic.h \
  /workspaces/repository/vendor/linux-framework/include/net/gen_stats.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/gen_stats.h \
  /workspaces/repository/vendor/linux-framework/include/net/rtnetlink.h \
  /workspaces/repository/vendor/linux-framework/include/net/netlink.h \
  /workspaces/repository/vendor/linux-framework/include/net/flow_offload.h \
  /workspaces/repository/vendor/linux-framework/include/net/sock.h \
    $(wildcard include/config/SOCK_RX_QUEUE_MAPPING) \
    $(wildcard include/config/SOCK_VALIDATE_XMIT) \
    $(wildcard include/config/BT) \
  /workspaces/repository/vendor/linux-framework/include/linux/poll.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/poll.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/poll.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/poll.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/eventpoll.h \
  /workspaces/repository/vendor/linux-framework/include/linux/indirect_call_wrapper.h \
  /workspaces/repository/vendor/linux-framework/include/net/dst.h \
  /workspaces/repository/vendor/linux-framework/include/net/neighbour.h \
  /workspaces/repository/vendor/linux-framework/include/net/tcp_states.h \
  /workspaces/repository/vendor/linux-framework/include/linux/net_tstamp.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/net_tstamp.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/ethtool_netlink_generated.h \
  /workspaces/repository/vendor/linux-framework/include/net/l3mdev.h \
  /workspaces/repository/vendor/linux-framework/include/net/fib_rules.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/fib_rules.h \
  /workspaces/repository/vendor/linux-framework/include/net/fib_notifier.h \
  /workspaces/repository/vendor/linux-framework/include/linux/namei.h \
  /workspaces/repository/vendor/linux-framework/include/linux/fs_struct.h \
  /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/bpf_testmod.h \
  /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/bpf_testmod_kfunc.h \
  /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/bpf_testmod-events.h \
  /workspaces/repository/vendor/linux-framework/include/trace/define_trace.h \
  /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/././bpf_testmod-events.h \
  /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-whole-resources/testmod-source/././bpf_testmod.h \
  /workspaces/repository/vendor/linux-framework/include/trace/trace_events.h \
  /workspaces/repository/vendor/linux-framework/include/linux/trace_events.h \
    $(wildcard include/config/DYNAMIC_EVENTS) \
    $(wildcard include/config/HIST_TRIGGERS) \
    $(wildcard include/config/KPROBE_EVENTS) \
    $(wildcard include/config/UPROBE_EVENTS) \
  /workspaces/repository/vendor/linux-framework/include/linux/ring_buffer.h \
    $(wildcard include/config/RING_BUFFER_ALLOW_SWAP) \
    $(wildcard include/config/RING_BUFFER) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/trace_mmap.h \
  /workspaces/repository/vendor/linux-framework/include/linux/trace_seq.h \
  /workspaces/repository/vendor/linux-framework/include/linux/seq_buf.h \
  /workspaces/repository/vendor/linux-framework/include/linux/perf_event.h \
    $(wildcard include/config/HAVE_HW_BREAKPOINT) \
    $(wildcard include/config/FUNCTION_TRACER) \
    $(wildcard include/config/PERF_GUEST_MEDIATED_PMU) \
    $(wildcard include/config/CPU_SUP_INTEL) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/perf_event.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/bpf_perf_event.h \
  /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/include/generated/uapi/asm/bpf_perf_event.h \
  /workspaces/repository/vendor/linux-framework/include/uapi/asm-generic/bpf_perf_event.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ptrace.h \
  /workspaces/repository/vendor/linux-framework/include/linux/pid_namespace.h \
    $(wildcard include/config/MEMFD_CREATE) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/ptrace.h \
  /workspaces/repository/vendor/linux-framework/include/linux/seccomp.h \
    $(wildcard include/config/HAVE_ARCH_SECCOMP_FILTER) \
    $(wildcard include/config/SECCOMP_FILTER) \
    $(wildcard include/config/CHECKPOINT_RESTORE) \
    $(wildcard include/config/SECCOMP_CACHE_DEBUG) \
  /workspaces/repository/vendor/linux-framework/include/uapi/linux/seccomp.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/seccomp.h \
  /workspaces/repository/vendor/linux-framework/include/asm-generic/seccomp.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/perf_event.h \
    $(wildcard include/config/PERF_EVENTS_AMD_BRS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/stacktrace.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/cpu_entry_area.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/intel_ds.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/switch_to.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/hw_breakpoint.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/hw_breakpoint.h \
  /workspaces/repository/vendor/linux-framework/include/linux/kdebug.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/kdebug.h \
  /workspaces/repository/vendor/linux-framework/include/linux/ftrace.h \
    $(wildcard include/config/HAVE_FUNCTION_GRAPH_FREGS) \
    $(wildcard include/config/HAVE_DYNAMIC_FTRACE_WITH_ARGS) \
    $(wildcard include/config/HAVE_FTRACE_REGS_HAVING_PT_REGS) \
    $(wildcard include/config/HAVE_REGS_AND_STACK_ACCESS_API) \
    $(wildcard include/config/DYNAMIC_FTRACE_WITH_REGS) \
    $(wildcard include/config/DYNAMIC_FTRACE_WITH_ARGS) \
    $(wildcard include/config/DYNAMIC_FTRACE_WITH_DIRECT_CALLS) \
    $(wildcard include/config/STACK_TRACER) \
    $(wildcard include/config/DYNAMIC_FTRACE_WITH_CALL_OPS) \
    $(wildcard include/config/FUNCTION_GRAPH_RETVAL) \
    $(wildcard include/config/FTRACE_SYSCALLS) \
  /workspaces/repository/vendor/linux-framework/include/linux/trace_recursion.h \
    $(wildcard include/config/FTRACE_RECORD_RECURSION) \
    $(wildcard include/config/FTRACE_VALIDATE_RCU_IS_WATCHING) \
  /workspaces/repository/vendor/linux-framework/include/linux/trace_clock.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/trace_clock.h \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/ftrace.h \
    $(wildcard include/config/HAVE_FENTRY) \
  /workspaces/repository/vendor/linux-framework/include/linux/ftrace_regs.h \
  /workspaces/repository/vendor/linux-framework/include/linux/irq_work.h \
    $(wildcard include/config/IRQ_WORK) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/asm/irq_work.h \
  /workspaces/repository/vendor/linux-framework/include/linux/jump_label_ratelimit.h \
  /workspaces/repository/vendor/linux-framework/include/linux/perf_regs.h \
    $(wildcard include/config/HAVE_PERF_REGS) \
  /workspaces/repository/vendor/linux-framework/arch/x86/include/uapi/asm/perf_regs.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/init.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage1_struct_define.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage2_data_offsets.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage3_trace_output.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage4_event_fields.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage5_get_offsets.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage6_event_callback.h \
  /workspaces/repository/vendor/linux-framework/include/trace/stages/stage7_class_define.h \
  /workspaces/repository/vendor/linux-framework/include/trace/perf.h \
  /workspaces/repository/vendor/linux-framework/include/trace/bpf_probe.h \

bpf_testmod.o: $(deps_bpf_testmod.o)

$(deps_bpf_testmod.o):

bpf_testmod.o: $(wildcard /workspaces/repository/kprog/tv/build-kernel-x86/tools/objtool/objtool)
#SYMVER bpf_testmod_test_read 0x3558d2d6
#SYMVER bpf_testmod_test_write 0x520c5322
#SYMVER bpf_fentry_shadow_test 0xa455f018
