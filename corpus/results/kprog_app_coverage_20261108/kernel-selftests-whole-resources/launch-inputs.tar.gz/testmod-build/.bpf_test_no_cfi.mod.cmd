savedcmd_bpf_test_no_cfi.mod := printf '%s\n'   bpf_test_no_cfi.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_test_no_cfi.mod
