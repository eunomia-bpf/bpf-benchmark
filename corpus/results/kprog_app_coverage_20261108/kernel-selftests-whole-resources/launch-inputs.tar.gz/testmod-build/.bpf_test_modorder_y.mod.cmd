savedcmd_bpf_test_modorder_y.mod := printf '%s\n'   bpf_test_modorder_y.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_test_modorder_y.mod
