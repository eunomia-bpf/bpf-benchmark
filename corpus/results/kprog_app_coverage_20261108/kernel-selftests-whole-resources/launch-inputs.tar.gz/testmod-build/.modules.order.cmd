savedcmd_modules.order := {   echo bpf_testmod.o;   echo bpf_test_no_cfi.o;   echo bpf_test_modorder_x.o;   echo bpf_test_modorder_y.o;   echo bpf_test_rqspinlock.o; :; } > modules.order
