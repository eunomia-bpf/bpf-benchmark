from pathlib import Path
import json,tarfile,subprocess
G=Path(__file__).resolve().parent;J=G.parent/'kernel-selftests-whole-resources';rows=json.loads((J/'out/submissions.json').read_text())['programs'];out=[]
for r in rows:
 if r['stage']=='compilation_failed':
  archive=Path(r['service']['failure_archive'])
  with tarfile.open(archive)as tf:
   for n in tf.getnames():
    if n.endswith('commands.jsonl'):
     for c in [json.loads(l)for l in tf.extractfile(n).read().splitlines()]:
      if c['returncode']:
       cmd=c['command'];source=G/(r['program']+'.bpf.c');member=next(n for n in tf.getnames()if n.endswith('/generated/trusted_x86.bpf.c'));source.write_bytes(tf.extractfile(member).read());cmd[cmd.index('-c')+1]=str(source);cmd[-1]=str(G/(r['program']+'.bpf.o'));p=subprocess.run(cmd,capture_output=True,text=True);out.append(dict(program=r['program'],command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(r['program'],p.returncode,flush=True)
(G/'compilation.json').write_text(json.dumps(out,indent=2)+'\n')
raise SystemExit(any(r['returncode']for r in out))
