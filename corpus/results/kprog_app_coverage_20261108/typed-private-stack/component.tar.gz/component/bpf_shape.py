from pathlib import Path
from elftools.elf.elffile import ELFFile
import json,struct,hashlib
D=Path(__file__).parent;out={}
for app in ['tetragon','otel','tetragon-event','tracee']:
 p=D/(app+'.bpf.o')
 with p.open('rb')as f:
  e=ELFFile(f);sections=[s for s in e.iter_sections()if s['sh_flags']&4];frame=[]
  for sec in sections:
   b=sec.data()
   for i in range(0,len(b),8):
    code,regs,off,imm=struct.unpack('<BBhi',b[i:i+8]);dst=regs&15;src=regs>>4
    if ((code&7)in[2,3]and dst==10 or(code&7)==1 and src==10)and off<0:frame.append(off)
  out[app]={'insns':sum(s['sh_size']//8 for s in sections),'deepest_direct_frame_offset':min(frame)if frame else 0,'object_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(D/'compiled-shape.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
