from pathlib import Path
from elftools.elf.elffile import ELFFile
D=Path(__file__).parent
with(D/'arithmetic.o').open('rb')as f:
 e=ELFFile(f);text=e.get_section_by_name('.text').data()
 for s in e.get_section_by_name('.symtab').iter_symbols():
  if s.name.startswith('lea_')and s['st_size']:(D/(s.name+'.bin')).write_bytes(text[s['st_value']:s['st_value']+s['st_size']])
