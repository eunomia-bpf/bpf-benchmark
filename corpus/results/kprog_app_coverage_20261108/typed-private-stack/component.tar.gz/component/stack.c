#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 64U
#include "read.h"
#include "candidate.h"
struct Input { __u64 value,index,readback,second; __u8 initial[64],arena[64]; };
__u64 stack_0_0(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),0,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_1(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),1,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_2(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),2,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_3(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),3,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_4(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),4,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_5(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),5,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_6(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),6,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_7(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),7,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_0_8(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,0,X86_MEM_AUX(X86_RBX,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,0,X86_MEM_AUX(X86_RBX,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_RBX,0),0,0,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_0(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),0,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_1(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),1,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_2(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),2,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_3(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),3,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_4(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),4,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_5(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),5,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_6(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),6,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_7(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),7,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_1_8(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,1,X86_MEM_AUX(X86_RBX,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,1,X86_MEM_AUX(X86_RBX,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_RBX,0),0,1,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_0(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),0,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_1(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),1,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_2(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),2,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_3(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),3,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_4(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),4,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_5(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),5,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_6(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),6,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_7(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),7,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_2_8(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,2,X86_MEM_AUX(X86_RBX,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,2,X86_MEM_AUX(X86_RBX,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_RBX,0),0,2,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_0(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),0,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_1(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),1,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_2(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),2,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_3(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),3,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_4(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),4,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_5(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),5,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_6(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),6,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_7(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),7,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_4_8(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,4,X86_MEM_AUX(X86_RBX,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,4,X86_MEM_AUX(X86_RBX,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_RBX,0),0,4,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_0(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),0,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_1(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),1,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_2(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),2ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),2,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_3(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),3ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),3,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_4(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),4ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),4,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_5(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),5ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),5,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_6(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),6ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),6,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_7(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_REG_NONE,0),7ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_REG_NONE,0),7,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
__u64 stack_8_8(struct Input *p) { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;
for(unsigned i=0;i<64;i++) __x86_stack_mem.b[i]=p->initial[i];
__x86_rsp.ptr=(void *)(long)-64; __x86_rax.ptr=(void *)(long)p->value; __x86_rbx.ptr=(void *)(long)p->index;
X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RSP,X86_RAX,8,X86_MEM_AUX(X86_RBX,0),0ULL);
X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RDX,X86_RSP,8,X86_MEM_AUX(X86_RBX,0),0ULL);
p->readback=X86_SIM_L_READ_REG(X86_RDX);
p->second=X86_SIM_L_READ_MEM_VALUE(X86_RSP,X86_MEM_AUX(X86_RBX,0),0,8,0ULL);
for(unsigned i=0;i<64;i++)p->arena[i]=__x86_stack_mem.b[i];return 0; }
