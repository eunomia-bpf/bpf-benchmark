set -eu
D=/workspaces/.agent-state/kprog-lanes/C/stack-typed-volatile-current
cd /workspaces/repository
trap 'echo $? > "$D/checks.exit"' EXIT
/usr/lib/llvm-18/bin/clang -O3 -mcpu=v4 -target bpf -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/stack.c" -o "$D/stack.o"
cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/stack.c" -o "$D/host.o"
c++ -O2 -std=c++20 -fsanitize=undefined -fno-sanitize-recover=undefined -Ivendor/llvmbpf/include -Ivendor/llvmbpf/src "$D/run.cpp" "$D/host.o" runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o -L/usr/lib/llvm-18/lib -lLLVM-18 -lspdlog -lfmt -ldl -pthread -o "$D/check"
python3 "$D/extract.py"
"$D/check" "$D"
for name in test_x86_stack_arm_route_host test_x86_stack_write_lanes_route_host; do
 cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -include "$D/read.h" -Ikprog/formal -Ikprog/formal/oracles -Ikprog/x86 -Ivendor/libbpf/src "$D/$name.c" -o "$D/$name"
 "$D/$name"
done
/usr/lib/llvm-18/bin/clang -O3 -mcpu=v4 -target bpf -c "$D/reads.c" -o "$D/reads.o"
cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -c "$D/reads.c" -o "$D/read-host.o"
c++ -O2 -std=c++20 -fsanitize=undefined -fno-sanitize-recover=undefined "$D/read-run.cpp" "$D/read-host.o" runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o -Ivendor/llvmbpf/include -Ivendor/llvmbpf/src -L/usr/lib/llvm-18/lib -lLLVM-18 -lspdlog -lfmt -ldl -pthread -o "$D/read-check"
python3 "$D/read-extract.py"
"$D/read-check" "$D"
/usr/lib/llvm-18/bin/clang -O3 -mcpu=v4 -target bpf -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/arithmetic.c" -o "$D/arithmetic.o"
cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/arithmetic.c" -o "$D/arithmetic-host.o"
c++ -O2 -std=c++20 -fsanitize=undefined -fno-sanitize-recover=undefined "$D/arithmetic-run.cpp" "$D/arithmetic-host.o" runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o -Ivendor/llvmbpf/include -Ivendor/llvmbpf/src -L/usr/lib/llvm-18/lib -lLLVM-18 -lspdlog -lfmt -ldl -pthread -o "$D/arithmetic-check"
python3 "$D/arithmetic-extract.py"
"$D/arithmetic-check" "$D"
for name in test_x86_mov_memory_frame_host test_x86_mov_load_route_host; do
 cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -include "$D/read.h" -Ikprog/formal -Ikprog/formal/oracles -Ikprog/x86 -Ivendor/libbpf/src "$D/$name.c" -o "$D/$name"
 "$D/$name"
done
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/tetragon.bpf.c" -o "$D/tetragon.bpf.o"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/otel.bpf.c" -o "$D/otel.bpf.o"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/tetragon-event.bpf.c" -o "$D/tetragon-event.bpf.o"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/tracee.bpf.c" -o "$D/tracee.bpf.o"
python3 "$D/bpf_shape.py"
