from pathlib import Path
from elftools.elf.elffile import ELFFile
import json
D=Path(__file__).parent
with (D/'stack.o').open('rb')as f:
 e=ELFFile(f);syms=e.get_section_by_name('.symtab');section=e.get_section_by_name('.text').data()
 for s in syms.iter_symbols():
  if s.name.startswith('stack_') and s['st_size']:
   (D/(s.name+'.bin')).write_bytes(section[s['st_value']:s['st_value']+s['st_size']])
