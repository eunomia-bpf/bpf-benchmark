#define X86_SIM_ENABLE_STACK 1
#include "read.h"
#include "candidate.h"
struct Arithmetic {__u64 value,result,flags,taken;};
__u64 lea_0(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_1(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_2(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_3(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_4(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_5(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_6(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_7(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_8(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_9(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_10(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_11(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_12(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_13(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_14(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_15(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_16(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_17(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_18(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_19(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,4,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,4,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_20(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_21(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_22(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_23(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551505ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_24(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_25(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_26(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_27(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744073709551615ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_28(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_29(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_30(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_31(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),0ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_32(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_33(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_34(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_35(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),1ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_36(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,0ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_37(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,110ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_38(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967186ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
__u64 lea_39(struct Arithmetic*p){X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=X86_SIM_ABI_KIND_RAW;__x86_rbx.ptr=(void*)(long)p->value;
X86_SIM_L_EXEC_LEA(X86_RAX,X86_RBX,8,X86_MEM_AUX(X86_REG_NONE,0),18446744071562067968ULL);
X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM,X86_RAX,8,4294967295ULL);
p->result=X86_SIM_L_READ_REG(X86_RAX);p->flags=__x86_cf|(__u64)__x86_pf<<2|(__u64)__x86_af<<4|(__u64)__x86_zf<<6|(__u64)__x86_sf<<7|(__u64)__x86_of<<11;p->taken=X86_SIM_L_EVAL_CC(X86_CC_AE);return 0;}
