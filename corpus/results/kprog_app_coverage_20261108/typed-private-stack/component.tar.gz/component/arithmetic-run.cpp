#include <llvmbpf.hpp>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
#include <string>
struct Arithmetic{uint64_t value,result,flags,taken;};
extern "C" uint64_t lea_0(Arithmetic*);
extern "C" uint64_t lea_1(Arithmetic*);
extern "C" uint64_t lea_2(Arithmetic*);
extern "C" uint64_t lea_3(Arithmetic*);
extern "C" uint64_t lea_4(Arithmetic*);
extern "C" uint64_t lea_5(Arithmetic*);
extern "C" uint64_t lea_6(Arithmetic*);
extern "C" uint64_t lea_7(Arithmetic*);
extern "C" uint64_t lea_8(Arithmetic*);
extern "C" uint64_t lea_9(Arithmetic*);
extern "C" uint64_t lea_10(Arithmetic*);
extern "C" uint64_t lea_11(Arithmetic*);
extern "C" uint64_t lea_12(Arithmetic*);
extern "C" uint64_t lea_13(Arithmetic*);
extern "C" uint64_t lea_14(Arithmetic*);
extern "C" uint64_t lea_15(Arithmetic*);
extern "C" uint64_t lea_16(Arithmetic*);
extern "C" uint64_t lea_17(Arithmetic*);
extern "C" uint64_t lea_18(Arithmetic*);
extern "C" uint64_t lea_19(Arithmetic*);
extern "C" uint64_t lea_20(Arithmetic*);
extern "C" uint64_t lea_21(Arithmetic*);
extern "C" uint64_t lea_22(Arithmetic*);
extern "C" uint64_t lea_23(Arithmetic*);
extern "C" uint64_t lea_24(Arithmetic*);
extern "C" uint64_t lea_25(Arithmetic*);
extern "C" uint64_t lea_26(Arithmetic*);
extern "C" uint64_t lea_27(Arithmetic*);
extern "C" uint64_t lea_28(Arithmetic*);
extern "C" uint64_t lea_29(Arithmetic*);
extern "C" uint64_t lea_30(Arithmetic*);
extern "C" uint64_t lea_31(Arithmetic*);
extern "C" uint64_t lea_32(Arithmetic*);
extern "C" uint64_t lea_33(Arithmetic*);
extern "C" uint64_t lea_34(Arithmetic*);
extern "C" uint64_t lea_35(Arithmetic*);
extern "C" uint64_t lea_36(Arithmetic*);
extern "C" uint64_t lea_37(Arithmetic*);
extern "C" uint64_t lea_38(Arithmetic*);
extern "C" uint64_t lea_39(Arithmetic*);
struct Case{const char*name;unsigned width;int64_t displacement;uint32_t bound;uint64_t(*host)(Arithmetic*);};
Case cases[]={
{"lea_0",4,-111LL,0U,lea_0},
{"lea_1",4,-111LL,110U,lea_1},
{"lea_2",4,-111LL,4294967186U,lea_2},
{"lea_3",4,-111LL,4294967295U,lea_3},
{"lea_4",4,-1LL,0U,lea_4},
{"lea_5",4,-1LL,110U,lea_5},
{"lea_6",4,-1LL,4294967186U,lea_6},
{"lea_7",4,-1LL,4294967295U,lea_7},
{"lea_8",4,0LL,0U,lea_8},
{"lea_9",4,0LL,110U,lea_9},
{"lea_10",4,0LL,4294967186U,lea_10},
{"lea_11",4,0LL,4294967295U,lea_11},
{"lea_12",4,1LL,0U,lea_12},
{"lea_13",4,1LL,110U,lea_13},
{"lea_14",4,1LL,4294967186U,lea_14},
{"lea_15",4,1LL,4294967295U,lea_15},
{"lea_16",4,-2147483648LL,0U,lea_16},
{"lea_17",4,-2147483648LL,110U,lea_17},
{"lea_18",4,-2147483648LL,4294967186U,lea_18},
{"lea_19",4,-2147483648LL,4294967295U,lea_19},
{"lea_20",8,-111LL,0U,lea_20},
{"lea_21",8,-111LL,110U,lea_21},
{"lea_22",8,-111LL,4294967186U,lea_22},
{"lea_23",8,-111LL,4294967295U,lea_23},
{"lea_24",8,-1LL,0U,lea_24},
{"lea_25",8,-1LL,110U,lea_25},
{"lea_26",8,-1LL,4294967186U,lea_26},
{"lea_27",8,-1LL,4294967295U,lea_27},
{"lea_28",8,0LL,0U,lea_28},
{"lea_29",8,0LL,110U,lea_29},
{"lea_30",8,0LL,4294967186U,lea_30},
{"lea_31",8,0LL,4294967295U,lea_31},
{"lea_32",8,1LL,0U,lea_32},
{"lea_33",8,1LL,110U,lea_33},
{"lea_34",8,1LL,4294967186U,lea_34},
{"lea_35",8,1LL,4294967295U,lea_35},
{"lea_36",8,-2147483648LL,0U,lea_36},
{"lea_37",8,-2147483648LL,110U,lea_37},
{"lea_38",8,-2147483648LL,4294967186U,lea_38},
{"lea_39",8,-2147483648LL,4294967295U,lea_39}};
struct Hardware{uint64_t result,flags;};
__attribute__((noinline)) Hardware cpu(uint64_t value,uint64_t offset,uint64_t bound,unsigned width){Hardware out{};
if(width==4)asm volatile("leal (%q2,%q3),%k0; cmpl %k4,%k0; pushfq; popq %1":"=&r"(out.result),"=&r"(out.flags):"r"(value),"r"(offset),"r"(bound):"cc","memory");
else asm volatile("leaq (%q2,%q3),%0; cmpq %4,%0; pushfq; popq %1":"=&r"(out.result),"=&r"(out.flags):"r"(value),"r"(offset),"r"(bound):"cc","memory");return out;}
int main(int argc,char**argv){if(argc!=2)return 2;std::string root=argv[1];std::ofstream bad(root+"/arithmetic-mismatches.jsonl");uint64_t total=0,fail=0;
for(auto&c:cases){std::ifstream in(root+"/"+c.name+".bin",std::ios::binary);std::vector<uint8_t>code((std::istreambuf_iterator<char>(in)),{});if(code.empty())return 3;
bpftime::llvmbpf_vm vm;if(vm.load_code(code.data(),code.size())<0||!vm.compile()){std::cerr<<vm.get_error_message()<<'\n';return 4;}
uint64_t state=0x123456789abcdef0ULL;uint64_t edges[]={0,1,2,109,110,111,112,0xffffffffULL,0x100000000ULL,0x100000001ULL,0xffffff91ULL,0xffffff92ULL,0x80000000ULL,~0ULL};
for(unsigned j=0;j<4096;j++){state=state*6364136223846793005ULL+1442695040888963407ULL;Arithmetic raw{j<14?edges[j]:state,~0ULL,~0ULL,~0ULL},host=raw,jit=raw,want=raw;
uint64_t bound=c.width==4?uint64_t(c.bound):uint64_t(int64_t(int32_t(c.bound)));Hardware hw=cpu(raw.value,uint64_t(c.displacement),bound,c.width);uint64_t numeric=raw.value+uint64_t(c.displacement);if(c.width==4)numeric=uint32_t(numeric);
want.result=numeric;want.flags=hw.flags&0x8d5;want.taken=(hw.flags&1)==0;uint64_t ret=1,hostret=c.host(&host);if(vm.exec(&jit,sizeof(jit),ret)<0)return 5;
if(hw.result!=numeric||ret||hostret||memcmp(&host,&want,sizeof(want))||memcmp(&jit,&want,sizeof(want))){fail++;bad<<"{\"form\":\""<<c.name<<"\",\"case\":"<<j<<",\"value\":"<<raw.value<<",\"hardware_flags\":"<<want.flags<<",\"jit_flags\":"<<jit.flags<<",\"host_flags\":"<<host.flags<<"}\n";}total++;}}
std::cout<<"scalar LEA/CMP hardware/BPF-JIT/host/integer oracle: "<<total<<" observations, differences="<<fail<<'\n';return fail?1:0;}
