from pathlib import Path
import os,select,subprocess,json,sys,threading,time
G=Path(__file__).parent;D=G.parent;R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((D/'remaining-corrected/queue.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
state=G/'broker'
with(G/'broker.log').open('wb')as log:server=subprocess.Popen(['taskset','-c','20-23',sys.executable,str(D/'frozen-python/trusted_compile.py'),'serve','--scope',str(D),'--state',str(state),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
(G/'broker.pid').write_text(str(server.pid)+'\n')
def monitor():
 rc=server.wait()
 if not(state/'STOP').exists():(state/'failed.json').write_text(json.dumps(dict(error='compiler exited',returncode=rc))+'\n')
threading.Thread(target=monitor,daemon=True).start()
try:
 while not(state/'ready.json').exists():
  if server.poll()is not None:raise RuntimeError('compiler startup exit '+str(server.returncode))
  time.sleep(.1)
 for key,app in [('cilium-xdp-helper','cilium/agent')]:
  a=D/key
  with(G/(key+'.log')).open('wb')as log:q=subprocess.run(['make','-f',str(a/'Makefile'),'corpus','STATE='+str(a),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS='+app,'SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (G/(key+'.exit')).write_text(str(q.returncode)+'\n')
  with(G/(key+'.collect.log')).open('wb')as log:q=subprocess.run([sys.executable,str(D/'collect.py'),key],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (G/(key+'.collect.exit')).write_text(str(q.returncode)+'\n')
finally:
 (state/'STOP').write_text('application cohort closed\n');server.wait()
(G/'queue.exit').write_text('0\n')
