set -eu
D=/workspaces/.agent-state/kprog-lanes/C/typed-read-successors/tetragon__observer
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/C/typed-read-successors/tetragon__observer/Makefile corpus STATE="$D" CPUS=20-23 VM_CPUS=8 VM_MEM=12G APPS=tetragon/observer SAMPLES=1 WORKLOAD_DURATION=2
