set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tracee-core-assets
trap 'echo $? > "$D/build.exit"' EXIT
cd /workspaces/repository
make -f "$D/Makefile" image
