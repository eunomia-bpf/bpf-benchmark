set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
trap 'echo $? > "$D/modules.exit"' EXIT
unshare --mount --propagation private sh "$D/inside.modules.sh"
release=$(cat "$D/build/include/config/kernel.release")
depmod -b "$D/runtime-modules" "$release"
python3 "$D/module-identities.py"
