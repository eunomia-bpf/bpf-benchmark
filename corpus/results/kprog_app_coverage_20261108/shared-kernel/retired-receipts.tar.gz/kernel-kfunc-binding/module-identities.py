from pathlib import Path
import json,hashlib
K=Path(__file__).parent;R=Path('/workspaces/repository');release=(K/'build/include/config/kernel.release').read_text().strip();files=[p for p in (K/'runtime-modules/lib/modules'/release).rglob('*.ko')]
assert files
pins={str(p.relative_to(K/'runtime-modules')):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
(K/'module-identities.json').write_text(json.dumps({'release':release,'modules':len(files),'sha256':pins,'kernel_btf_sha256':hashlib.sha256((K/'kernel.btf').read_bytes()).hexdigest(),'kernel_image_sha256':hashlib.sha256((K/'build/arch/x86/boot/bzImage').read_bytes()).hexdigest()},indent=2)+'\n')
