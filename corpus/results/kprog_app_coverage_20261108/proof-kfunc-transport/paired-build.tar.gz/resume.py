from pathlib import Path
import os,signal,subprocess,json,hashlib,shutil
D=Path(__file__).parent;Q=D.parent/'cilium-original-btf-replay';pid=4127958
try:
 with (D/'build.log').open('wb')as log:p=subprocess.run(['taskset','-c','20-23','bash',str(D/'build.sh')],stdout=log,stderr=subprocess.STDOUT)
 if p.returncode==0:
  old=Q/'original-btf-pair';old.mkdir()
  for name in ['libnative_loader.so','trusted-native-loader']:
   shutil.copy2(Q/name,old/name);shutil.copy2(D/name,Q/(name+'.next'));os.replace(Q/(name+'.next'),Q/name)
  (Q/'transport-inputs.json').write_text(json.dumps({'source':str(D),'head':json.loads((D/'inputs.json').read_text())['head'],'sha256':{n:hashlib.sha256((Q/n).read_bytes()).hexdigest()for n in ['libnative_loader.so','trusted-native-loader']}},indent=2)+'\n')
  cp=Q/'collect.py';s=cp.read_text();assert "'private-inputs.json'"in s;s=s.replace("'private-inputs.json'","'private-inputs.json','transport-inputs.json'");cp.write_text(s)
 (D/'adopt.exit').write_text(str(p.returncode)+'\n')
finally:
 os.kill(pid,signal.SIGCONT)
 (D/'queue-resumed').write_text(str(pid)+'\n')
