#include <cstdarg>
#include <cerrno>
#include <cstdio>
#include "candidate.cpp"
static int calls, injected_error;static bool observed_log;
extern "C" long syscall(long number, ...) noexcept {
 va_list ap;va_start(ap,number);int cmd=va_arg(ap,int);auto *attr=va_arg(ap,union bpf_attr*);(void)va_arg(ap,unsigned int);va_end(ap);
 if(number!=SYS_bpf||cmd!=BPF_PROG_LOAD){errno=ENOSYS;return -1;}
 calls++;observed_log=attr->log_buf&&attr->log_size==kMaxVerifierLogSize&&attr->log_level==1;attr->log_true_size=42;
 if(injected_error){errno=injected_error;return -1;}return 97;
}
int main(){
 StubLoadAttrs attrs{};std::vector<bpf_insn> insns(1);insns[0].code=BPF_JMP|BPF_EXIT;std::vector<int> refs;std::vector<char> log(kMaxVerifierLogSize);unsigned tests=0;
 for(int err:{0,EAGAIN,ENOSPC,EINVAL,ENOMEM,E2BIG}){calls=0;observed_log=false;injected_error=err;uint32_t size=0;int result=bpf_prog_load_native_stub_raw(BPF_PROG_TYPE_SOCKET_FILTER,attrs,-1,-1,-1,"single_attempt",insns,refs,log,size);if(calls!=1||!observed_log||size!=42||result!=(err?-err:97)){printf("mismatch err%d calls%d log%d size%u result%d\n",err,calls,observed_log,size,result);return 1;}tests++;}
 printf("native loader first-attempt log / exact syscall count / existing errno PASS %u cases\n",tests);
}
