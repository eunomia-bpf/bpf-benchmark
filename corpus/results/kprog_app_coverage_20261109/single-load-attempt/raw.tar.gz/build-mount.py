from pathlib import Path
import subprocess,os
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
subprocess.run(['mount','--bind',str(G/'candidate.cpp'),str(R/'kprog/libnativeloader/src/native_loader.cpp')],check=True)
subprocess.run(['mount','--bind',str(G/'build'),str(R/'kprog/libnativeloader/build')],check=True)
os.execvp('cmake',['cmake','--build',str(R/'kprog/libnativeloader/build'),'-j2'])
