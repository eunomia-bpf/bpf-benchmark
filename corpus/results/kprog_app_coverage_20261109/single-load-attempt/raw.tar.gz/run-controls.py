from pathlib import Path
import subprocess,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');cmd=['c++','-std=c++20','-O2','-ffunction-sections','-fdata-sections','-I'+str(R/'kprog/libnativeloader/include'),'-I'+str(R/'kprog/libnativeloader/src'),'-I'+str(R/'micro/programs/build-x86'),'-I'+str(R/'runner/build-llvmbpf/vendor/libbpf/prefix/include'),'-I'+str(R/'vendor/libbpf/include'),'-I'+str(R/'vendor/libbpf/include/uapi'),str(G/'syscall-count.cpp'),str(R/'runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a'),'-Wl,--gc-sections','-lelf','-lz','-ldl','-pthread','-o',str(G/'syscall-count')]
with(G/'controls-build.log').open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
row=dict(command=cmd,compile_exit=p.returncode)
if not p.returncode:
 with(G/'controls.log').open('w')as f:q=subprocess.run([str(G/'syscall-count')],stdout=f,stderr=subprocess.STDOUT)
 row['run_exit']=q.returncode
(G/'controls.json').write_text(json.dumps(row,indent=2)+'\n')
