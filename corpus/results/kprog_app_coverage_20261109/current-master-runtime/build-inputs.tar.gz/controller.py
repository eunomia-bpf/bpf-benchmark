from pathlib import Path
import subprocess,json,traceback,os,hashlib
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
def status(**x):(G/'status.json').write_text(json.dumps(x,indent=2)+'\n')
try:
 status(state='copying_warm_kernel_cache')
 for src,dst in [(R/'vendor/linux-framework',G/'kernel-src'),(R/'kprog/tv/build-kernel-x86',G/'kernel-build'),(R/'kprog/tv/build-x86',G/'module'),(R/'kprog/x86/native_lab/native_link/target',G/'native-target')]:
  dst.mkdir(exist_ok=True);subprocess.run(['rsync','-a','--exclude=.git',str(src)+'/',str(dst)+'/'],check=True)
 # Reconstruct patched files from the recorded vendor base; current master patch series supplies all native deltas.
 names=set()
 for n in ['native-proof-regions.patch','native-branch-thunks.patch']:
  for line in(G/'project/kprog/tv'/n).read_text().splitlines():
   if line.startswith('+++ b/'):names.add(line[6:])
 base=json.loads((G/'inputs.json').read_text())['kernel_base']
 for n in names:
  p=G/'kernel-src'/n;out=subprocess.run(['git','-C',str(R/'vendor/linux-framework'),'show',base+':'+n],capture_output=True)
  if out.returncode==0:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(out.stdout)
  elif p.exists():p.unlink()
 (G/'baseline-kernel-files.json').write_text(json.dumps(sorted(names),indent=2)+'\n')
 status(state='incremental_build')
 with(G/'build.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'build-in-namespace.py')],stdout=f,stderr=subprocess.STDOUT)
 (G/'build.exit').write_text(str(p.returncode)+'\n');p.check_returncode();status(state='built',head=json.loads((G/'inputs.json').read_text())['head'],artifacts=json.loads((G/'artifacts.json').read_text()))
except BaseException as e:status(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
