from pathlib import Path
import subprocess,os,shutil,json,hashlib
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');P=G/'project';inputs=json.loads((G/'inputs.json').read_text())
for physical,virtual in [(G/'kernel-src',R/'vendor/linux-framework'),(G/'kernel-build',R/'kprog/tv/build-kernel-x86'),(G/'module',R/'kprog/tv/build-x86'),(P/'kinsn/module',R/'kinsn/module')]:subprocess.run(['mount','--bind',str(physical),str(virtual)],check=True)
for n in ['native-proof-regions.patch','native-branch-thunks.patch','apply_kernel_patch.py','module.mk']:subprocess.run(['mount','--bind',str(P/'kprog/tv'/n),str(R/'kprog/tv'/n)],check=True)
subprocess.run(['python3',str(R/'kprog/tv/apply_kernel_patch.py')],check=True)
for args in [['bzImage'],['modules']]:subprocess.run(['make','-C',str(R/'vendor/linux-framework'),'O='+str(R/'kprog/tv/build-kernel-x86'),'ARCH=x86','-j4',*args],check=True)
kb=R/'kprog/tv/build-kernel-x86';shutil.copy2(kb/'vmlinux.symvers',kb/'Module.symvers')
shutil.copy2(P/'kprog/tv/module.mk',G/'module/Makefile');shutil.copy2(P/'kinsn/module/x86/bpf_x86_native_lab.c',G/'module/bpf_x86_native_lab.c')
subprocess.run(['make','-C',str(kb),'M='+str(R/'kprog/tv/build-x86'),'ARCH=x86','TV_ARCH=x86','-j4','modules'],check=True)
subprocess.run(['make','-C',str(R/'vendor/linux-framework'),'O='+str(kb),'ARCH=x86','INSTALL_MOD_PATH='+str(G/'modules-install'),'modules_install'],check=True)
subprocess.run(['mount','--bind',str(P/'kprog/x86/native_lab/native_link'),str(R/'kprog/x86/native_lab/native_link')],check=True)
subprocess.run(['cargo','build','--release','--manifest-path',str(R/'kprog/x86/native_lab/native_link/Cargo.toml')],env=dict(os.environ,CARGO_TARGET_DIR=str(G/'native-target')),check=True)
files=[G/'kernel-build/arch/x86/boot/bzImage',G/'kernel-build/vmlinux',G/'kernel-build/Module.symvers',G/'module/bpf_x86_native_lab.ko',G/'native-target/release/native-link']
(G/'artifacts.json').write_text(json.dumps({str(p.relative_to(G)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in files},indent=2)+'\n')
