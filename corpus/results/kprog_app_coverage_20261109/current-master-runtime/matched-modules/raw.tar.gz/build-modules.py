from pathlib import Path
import subprocess,json,hashlib,shutil,tarfile,sys,traceback,resource
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;K=Path('/var/tmp/kprog-tmp/C/master-x86-runtime');R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/current-master-runtime/matched-modules'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 (G/'build-status.json').write_text(json.dumps(dict(state='incremental_custom_modules'))+'\n')
 subprocess.run(['mount','--bind',str(K/'kernel-src'),str(R/'vendor/linux-framework')],check=True)
 subprocess.run(['make','-C',str(R/'vendor/linux-framework'),'O='+str(K/'kernel-build'),'ARCH=x86','outputmakefile'],check=True)
 command=['make','-C',str(R/'vendor/linux-framework'),'O='+str(K/'kernel-build'),'M='+str(K/'project/kinsn/module/x86'),'MO='+str(G/'custom-module-build'),'ARCH=x86','-j4','modules']
 with(G/'modules.log').open('w')as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 (G/'modules.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 dest=G/'image/kinsn';dest.mkdir()
 for p in sorted((G/'custom-module-build').glob('*.ko')):shutil.copy2(p,dest/p.name)
 shutil.copy2(dest/'bpf_x86_native_lab.ko',G/'runtime/bpf_x86_native_lab.ko')
 result=dict(kernel_release=(K/'kernel-build/include/config/kernel.release').read_text().strip(),command=command,make_exit=0,modules={p.name:dict(bytes=p.stat().st_size,sha256=sha(p),vermagic=subprocess.check_output(['modinfo','-F','vermagic',str(p)],text=True).strip())for p in dest.glob('*.ko')},prior_application_receipt='fc50455dc034711bb21f79b0dca8403857984864',prior_error='image7.0.0-rc2+ versus running7.0.0-rc2',image_manifest=json.loads((G/'image/manifest.json').read_text()))
 (G/'module-result.json').write_text(json.dumps(result,indent=2)+'\n');O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Current master complete matched x86 module set\n\nThe closed four-app receiptfc50455dc reaches the existing image installer with image7.0.0-rc2+ and running kernel7.0.0-rc2, before application startup. The corrected image manifest uses the actual kernel release and packages all842 ordinary modules from the warm build plus all'+str(len(result['modules']))+'custom x86 modules compiled against that same kernel source/object tree. Exact original native P, simulator, first-attempt loader, paired app artifacts and frozen framework retain bytes.\n\nThe complete custom module build exits0. summary.json carries every module hash/vermagic and the existing make command; raw.tar.gz retains module sources, all built modules, full compiler log, corrected image manifest and Dockerfile. Actual full application startup follows the dedicated matched image recipe.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for p in ['modules.log','modules.exit','build-modules.py','image/kinsn','image/Dockerfile','image/manifest.json']:t.add(G/p,arcname=p)
  for p in(K/'project/kinsn/module').rglob('*'):
   if p.is_file()and p.suffix in {'.c','.h'}:t.add(p,arcname='source/'+str(p.relative_to(K/'project')))
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Pair every x86 runtime module and image manifest with its actual kernel release',G/'modules-publication.json');(G/'build-status.json').write_text(json.dumps(dict(state='finished',commit=commit,modules=len(result['modules'])),indent=2)+'\n')
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V/S11/S15 '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' full matched current-master x8615custom/842ordinary module set and actual7.0.0-rc2 image manifest. Closedfc50455dc installer release mismatch remains raw. Same frozen source/native P and loader; private corrected four-app runtime follows at '+str(G)+'. Existing shared runtime and active owners retained; runtime predicates added0.\n')
except BaseException as e:(G/'build-status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
