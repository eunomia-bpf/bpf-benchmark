from pathlib import Path
import subprocess,os,select,json,datetime,shutil,sys,tarfile,hashlib,traceback
G=Path(__file__).resolve().parent;C=Path('/workspaces/.agent-state/kprog-lanes/C');R=Path('/workspaces/repository');D=C/'design-only/remaining-apps';Q=Path('/var/tmp/kprog-tmp/C/bcc-katran-constant-division');QV=D/'bcc-katran-constant-division';K=D/'bcc-katran-smap-recovery';O=R/'corpus/results/kprog_app_coverage_20261109/cilium-checksum-caller-frame/application'
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
def notice(t):
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/V/A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': '+t+'\n')
try:
 save('queued_after_constant_division_application')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:cmd=(proc/'cmdline').read_bytes().split(b'\0')
   except(FileNotFoundError,ProcessLookupError):continue
   if cmd and cmd[0].endswith(b'qemu-system-x86_64')and any(('path='+str(QV)+',').encode()in arg for arg in cmd):
    try:fd=os.pidfd_open(int(proc.name));select.select([fd],[],[]);os.close(fd)
    except ProcessLookupError:pass
 # The existing canonical source/runtime supplies the control epoch.
 for src in(K/'source').rglob('*'):
  if src.is_file()and'__pycache__'not in src.parts:
   dst=G/'source'/src.relative_to(K/'source');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 for relative,src in [('kprog/x86/x86_sim_local_bpf.h','recovery-header.h'),('kprog/x86/micro-prog/generate_micro_sim_proofs.py','generate_micro_sim_proofs.py')]:
  dst=G/'source'/relative;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(G/src,dst)
 save('original38')
 with(G/'original38.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'safety-control/mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'original38.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 rows=json.loads((G/'safety-control/safety/outcomes.json').read_text());safety=dict(cases=len(rows),make_exit=p.returncode,stages={s:sum(x['stage']==s for x in rows)for s in sorted({x['stage']for x in rows})},native_risk_executions=0);(G/'original38.json').write_text(json.dumps(safety,indent=2)+'\n')
 image=json.loads((K/'status.json').read_text())['image'];notice('Reusing canonical SMAP image '+image+' for complete Cilium replay with checksum/map caller-frame wrappers and captured S1 read-recovery source. P/application C and original38 inputs retain their definitions; actual original38 '+repr(safety)+'.')
 subprocess.run(['docker','tag',image,'bpf-benchmark/kprog-five-step-tracee:c-runner'],check=True)
 image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip()
 inputs=dict(image=image,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(p.relative_to(G)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(G/'source').rglob('*')if p.is_file()});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=cilium','SAMPLES=1','WORKLOAD_DURATION=2'];(G/'command.json').write_text(json.dumps(command,indent=2)+'\n');save('running',image=image)
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*command],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 with(G/'collect.log').open('w')as f:q=subprocess.run([sys.executable,str(D/'collect.py'),G.name],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=D/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
 for path in I.iterdir():
  if path.is_file():shutil.copy2(path,O/path.name)
 j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']];result=dict(make_exit=p.returncode,original38=safety,**{k:j[k]for k in ['native_requests','generated','compiled','installed','failed']},work=work,inputs=inputs);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Complete Cilium checksum caller-frame replay\n\nThe existing helper model preserves caller-allocated stack provenance across map update/delete and L3/L4 checksum replacement, retaining below-SP ghost erasure and every original SysV clobber. Kernel helper effects remain the actual helper calls, including packet-pointer invalidation. The original C/native ELF and captured canonical SMAP image retain their definitions; B uses the captured S1 read-recovery header/generator plus the four wrapper changes. Actual request counts '+repr({k:j[k]for k in ['native_requests','generated','compiled','installed','failed']})+'; original38 '+repr(safety)+'. Complete actual P/C/B/compiler/verifier and work records accompany the archives. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as tar:
  for n in ['Makefile','guest.py','clang','mount.py','controller.py','source','inputs.json','command.json','candidate.patch','recovery-header.h','generate_micro_sim_proofs.py','run.log','run.exit','collect.log','collect.exit','original38.json','original38.log','original38.exit','safety-control']:tar.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(x.relative_to(R))for x in O.iterdir()if x.is_file()],'Record whole Cilium checksum caller-frame replay',G/'publication.json');save('finished',commit=commit,counts={k:result[k]for k in ['native_requests','generated','compiled','installed','failed']});notice('PUSHED '+commit+' complete Cilium checksum caller-frame result '+repr({k:result[k]for k in ['native_requests','generated','compiled','installed','failed']})+'; every actual work/native/compiler/verifier record retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
