from pathlib import Path
import subprocess,os,json,tarfile,hashlib,datetime,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/cilium-checksum-caller-frame/source-update'
try:
 (G/'promote-status.json').write_text(json.dumps(dict(state='checking_exact_committed_header'))+'\n')
 command=['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),'head-after.h','make','-f',str(G/'Makefile'),'allocated'];(G/'head-command.json').write_text(json.dumps(command,indent=2)+'\n')
 with(G/'head-check.log').open('w')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'head-check.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(dict(base=json.loads((G/'head-source.json').read_text()),make_exit=p.returncode,allocated_frame_cases_per_compiler=67584,typed_route_cases=19458,earlier_all_sp_cases_per_compiler=608256,exact_SKB_compile='744bdd4f125af663595467ca99ee13fb21cc3b6f',queued_whole_Cilium='fc06240904baa1a398528c0a47a071723bca5fe8'),indent=2)+'\n')
 (O/'README.md').write_text('# Caller-frame preservation for checksum and map helpers\n\nFour helper wrappers use the existing caller-frame-preserving scalar result: map update/delete and L3/L4 checksum replacement. They keep the allocated caller stack provenance and invoke the existing call-frame treatment for released slots, alongside the original SysV register/flag/SIMD clobbers and actual helper effects. Packet-pointer invalidation stays with the actual BPF helper/verifier behavior.\n\nThe generic host component passes608256states each at its captured source. This source update additionally checks the exact committed header plus its four-line patch:67584allocated-frame states each on GCC/Clang UBSan and19458existing typed route cases. S7 owns released-slot/return lifetime semantics; allocated-frame checks retain that ownership boundary. Actual failing SKB native9ad3 and metadata compile successfully in744bdd4f1. Original38 and complete Cilium application receipts follow the captured serial queue fc0624090. Original C/native P/workload and every safety input retain their definitions. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for n in ['head-before.h','head-after.h','head-candidate.patch','head-source.json','head-command.json','allocated-frame.c','head-check.log','head-check.exit','Makefile','promote.py']:t.add(G/n,arcname=n)
 # Apply just these four model lines to the shared worktree.
 subprocess.run(['git','apply',str(G/'head-candidate.patch')],cwd=R,check=True)
 idx=G/'source-update.index';env=dict(os.environ,GIT_INDEX_FILE=str(idx))
 for attempt in range(30):
  parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();subprocess.run(['git','read-tree',parent],cwd=R,env=env,check=True)
  subprocess.run(['git','apply','--cached',str(G/'head-candidate.patch')],cwd=R,env=env,check=True)
  for path in sorted(O.iterdir()):
   if path.is_file():
    relative=str(path.relative_to(R));blob=subprocess.check_output(['git','hash-object','-w','--',relative],cwd=R,text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+relative],cwd=R,env=env,check=True)
  tree=subprocess.check_output(['git','write-tree'],cwd=R,env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],cwd=R,text=True,input='Preserve caller stack across checksum and map helpers\n').strip()
  if subprocess.run(['git','update-ref','refs/heads/master',commit,parent],cwd=R).returncode==0:break
 else:raise RuntimeError('Concurrent publication requires continuation')
 push=subprocess.run(['git','push','origin','master'],cwd=R,capture_output=True,text=True);print(push.stdout+push.stderr,flush=True)
 while push.returncode and'cannot lock ref'in push.stderr:
  push=subprocess.run(['git','push','origin','master'],cwd=R,capture_output=True,text=True);print(push.stdout+push.stderr,flush=True)
 push.check_returncode();remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/master'],cwd=R,text=True).split()[0];subprocess.run(['git','merge-base','--is-ancestor',commit,remote],cwd=R,check=True);idx.unlink()
 diff=subprocess.check_output(['git','diff',commit+'^',commit,'--','kprog/x86/x86_sim_local_bpf.h'],cwd=R,text=True);(G/'published-source.patch').write_text(diff)
 result=dict(state='finished',commit=commit,remote=remote,source_patch=diff);(G/'promote-status.json').write_text(json.dumps(result,indent=2)+'\n')
 notice='\n- LOCAL C FOR V/S7/S9/A/R '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' four helper-wrapper lines: map update/delete and L3/L4 checksum calls preserve allocated caller stack through the existing call-frame wrapper; actual helper effects and original SysV clobbers retained. Exact committed-header67584GCC+67584Clang allocated-frame cases/19458typedroutes pass; earlier608256each and actual failing SKB compilation744bdd4f1 retained. Private-index patch staged only these four lines plus source-update result files; S7 worktree lines retained. Complete Cilium/original38 remains queued2876280; current SMAP/Os/constant-div cohorts keep their captured source epochs. Runtime admission additions0.\n'
 for path in [C.parent/'COORDINATION.md',C/'last.md']:
  with path.open('a')as f:f.write(notice)
 print('PUSHED',commit,flush=True)
except BaseException as e:(G/'promote-status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()))+'\n');raise
