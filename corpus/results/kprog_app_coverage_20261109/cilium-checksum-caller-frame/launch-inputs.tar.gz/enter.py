from pathlib import Path
import subprocess,os
physical=Path('/var/tmp/kprog-tmp/C/cilium-checksum-caller-frame');virtual=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/cilium-checksum-caller-frame');collected=virtual.parent/'collected'/virtual.name
collected.mkdir(parents=True,exist_ok=True);(physical/'collected').mkdir(exist_ok=True)
subprocess.run(['mount','--bind',str(physical),str(virtual)],check=True)
subprocess.run(['mount','--bind',str(physical/'collected'),str(collected)],check=True)
os.execvp('python3',['python3',str(virtual/'controller.py')])
