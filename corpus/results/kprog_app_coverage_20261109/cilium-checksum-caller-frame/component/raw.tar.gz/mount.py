from pathlib import Path
import subprocess,os,sys
G=Path(__file__).resolve().parent
subprocess.run(['mount','--bind',str(G/sys.argv[1]),'/workspaces/repository/kprog/x86/x86_sim_local_bpf.h'],check=True)
os.execvp(sys.argv[2],sys.argv[2:])
