typedef unsigned char __u8; typedef unsigned short __u16; typedef unsigned int __u32; typedef unsigned long long __u64;
typedef signed char __s8; typedef signed short __s16; typedef signed int __s32; typedef signed long long __s64;
#define __always_inline inline
#define __BPF_HELPERS__ 1
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 64U
#include "/workspaces/repository/kprog/formal/oracles/x86_helper_environment_host.h"
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include <stdio.h>
#include <string.h>
static unsigned long cases;
static int check(unsigned id,int sp,unsigned tag,unsigned flags,unsigned pattern) {
 X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK();
 unsigned char raw[64];memset(raw,(unsigned char)(pattern*37),sizeof(raw));memcpy((void*)__x86_stack_mem.b,raw,sizeof(raw));
 __x86_rsp.ptr=(void*)(long)sp;__x86_rsp_tag=X86_SIM_TAG_STACK;
 __x86_rbx.ptr=(void*)0x88776655ULL;__x86_rbx_tag=X86_SIM_TAG_MAP_VALUE;
 __x86_r12.ptr=(void*)0xaabbccddULL;__x86_r12_tag=X86_SIM_TAG_ABI;
 __x86_cf=flags&1;__x86_zf=(flags>>1)&1;__x86_sf=(flags>>2)&1;__x86_of=(flags>>3)&1;__x86_pf=(flags>>4)&1;__x86_af=(flags>>5)&1;
 __x86_xmm0_lo=0x123456789abcdef0ULL;__x86_xmm0_hi=0xfedcba9876543210ULL;
 for(unsigned i=0;i<8;i++){X86_SIM_L_SV_TAG(i)=tag;X86_SIM_L_SV_PTR(i)=(void*)(0x1234567800000000ULL+i*8+pattern);}
 ora_called=0;
 switch(id){case 2:X86_SIM_BPF_CALL_bpf_map_update_elem();break;case 3:X86_SIM_BPF_CALL_bpf_map_delete_elem();break;case 10:X86_SIM_BPF_CALL_bpf_l3_csum_replace();break;case 11:X86_SIM_BPF_CALL_bpf_l4_csum_replace();break;}
 if(ora_called!=id||memcmp((const void*)__x86_stack_mem.b,raw,sizeof(raw))||__x86_rsp.ptr!=(void*)(long)sp||__x86_rbx.ptr!=(void*)0x88776655ULL||__x86_r12.ptr!=(void*)0xaabbccddULL||__x86_rbx_tag!=X86_SIM_TAG_MAP_VALUE||__x86_r12_tag!=X86_SIM_TAG_ABI)return 1;
 for(unsigned i=0;i<8;i++){
  unsigned expected=(int)(i*8)-64<sp?X86_SIM_TAG_SCALAR:tag;
  if(X86_SIM_L_SV_TAG(i)!=expected){fprintf(stderr,"frame id=%u sp=%d slot=%u tag=%u got=%u want=%u\n",id,sp,i,tag,X86_SIM_L_SV_TAG(i),expected);return 1;}
  if(X86_SIM_L_SV_PTR(i)!=(void*)(0x1234567800000000ULL+i*8+pattern))return 1;
 }
 if(__x86_cf||__x86_zf||__x86_sf||__x86_of||__x86_pf||__x86_af||__x86_xmm0_lo||__x86_xmm0_hi||__x86_rcx.ptr||__x86_rdx.ptr||__x86_rsi.ptr||__x86_rdi.ptr||__x86_r8.ptr||__x86_r9.ptr||__x86_r10.ptr||__x86_r11.ptr)return 1;
 cases++;return 0;
}
int main(void){unsigned ids[]={2,3,10,11};unsigned tags[]={X86_SIM_TAG_SCALAR,X86_SIM_TAG_STACK,X86_SIM_TAG_MAP_VALUE,X86_SIM_TAG_ABI};for(unsigned h=0;h<4;h++)for(int sp=-64;sp<=0;sp+=8)for(unsigned t=0;t<4;t++)for(unsigned f=0;f<64;f++)for(unsigned p=0;p<66;p++)if(check(ids[h],sp,tags[t],f,p))return 1;printf("helper caller-frame: %lu complete cases OK\n",cases);return 0;}
