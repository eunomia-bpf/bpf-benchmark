from pathlib import Path
import subprocess,json,traceback
G=Path(__file__).resolve().parent
try:
 for label,header,targets in [('control','before.h',['host']),('candidate','after.h',['host','component'])]:
  with(G/(label+'.log')).open('w')as f:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),header,'make','-f',str(G/'Makefile'),*targets],stdout=f,stderr=subprocess.STDOUT)
  (G/(label+'.exit')).write_text(str(p.returncode)+'\n')
  if label=='candidate':p.check_returncode()
 (G/'status.json').write_text(json.dumps(dict(state='finished'))+'\n')
except BaseException as e:(G/'status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()))+'\n');raise
