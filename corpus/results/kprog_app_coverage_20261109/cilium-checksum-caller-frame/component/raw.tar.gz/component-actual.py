from pathlib import Path
import sys,json
R=Path('/workspaces/repository');G=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
result=specialize((G/'actual-kernel.native.o').read_bytes(),'tail_ipv4_policy',json.loads((G/'actual-generation.metadata.json').read_text()),G/'actual-generated',R/'kprog/x86/native_lab/native_link/target/release/native-link')
(G/'actual-component.json').write_text(json.dumps(result,indent=2)+'\n')
