from pathlib import Path
import json,re,sys
source=Path(sys.argv[1]).read_text();bindings=json.loads(Path(sys.argv[2]).read_text());sites=[]
def replace(match):
 prefix,bits,name,tail=match.groups()
 if name not in bindings:return match[0]
 value=bindings[name];dbg=re.search(r'!dbg !\d+',tail)
 sites.append(dict(global_name=name,width=int(bits),value=value,original=match[0]))
 return prefix+'add i'+bits+' 0, '+str(value)+(', '+dbg[0]if dbg else'')
output=re.sub(r'(^\s*%[^\s=]+\s*=\s*)load volatile i(\d+), ptr @([A-Za-z_][A-Za-z_0-9]*)([^\n]*)',replace,source,flags=re.M)
Path(sys.argv[3]).write_text(output);Path(sys.argv[4]).write_text(json.dumps(dict(bindings=bindings,replaced_loads=sites),indent=2)+'\n')
