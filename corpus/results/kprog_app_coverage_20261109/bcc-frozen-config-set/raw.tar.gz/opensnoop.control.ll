; ModuleID = 'bcc/libbpf-tools/opensnoop.bpf.c'
source_filename = "bcc/libbpf-tools/opensnoop.bpf.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.anon = type { ptr, ptr, ptr, ptr }
%struct.anon.0 = type { ptr, ptr, ptr }
%struct.args_t = type { ptr, i32 }
%struct.trace_event_raw_sys_enter = type { %struct.trace_entry, i64, [6 x i64], [0 x i8] }
%struct.trace_entry = type { i16, i8, i8, i32 }
%struct.event = type { i64, i32, i32, i32, i32, [2 x i64], [16 x i8], [255 x i8] }
%struct.trace_event_raw_sys_exit = type { %struct.trace_entry, i64, i64, [0 x i8] }

@targ_pid = constant i32 0, align 4, !dbg !0
@targ_tgid = constant i32 0, align 4, !dbg !34
@targ_uid = constant i32 0, align 4, !dbg !40
@targ_failed = constant i8 0, align 1, !dbg !44
@start = global %struct.anon zeroinitializer, section ".maps", align 8, !dbg !55
@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !50
@events = global %struct.anon.0 zeroinitializer, section ".maps", align 8, !dbg !78
@llvm.compiler.used = appending global [7 x ptr] [ptr @LICENSE, ptr @events, ptr @start, ptr @tracepoint__syscalls__sys_enter_open, ptr @tracepoint__syscalls__sys_enter_openat, ptr @tracepoint__syscalls__sys_exit_open, ptr @tracepoint__syscalls__sys_exit_openat], section "llvm.metadata"

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_enter_open(ptr nocapture noundef readonly %0) #0 section "tracepoint/syscalls/sys_enter_open" !dbg !93 {
  %2 = alloca i32, align 4, !DIAssignID !129
  call void @llvm.dbg.assign(metadata i1 undef, metadata !125, metadata !DIExpression(), metadata !129, metadata ptr %2, metadata !DIExpression()), !dbg !130
  %3 = alloca %struct.args_t, align 8, !DIAssignID !131
  call void @llvm.dbg.assign(metadata i1 undef, metadata !126, metadata !DIExpression(), metadata !131, metadata ptr %3, metadata !DIExpression()), !dbg !132
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !119, metadata !DIExpression()), !dbg !130
  %4 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !133
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !120, metadata !DIExpression()), !dbg !130
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !124, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !130
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #7, !dbg !134
  %5 = trunc i64 %4 to i32, !dbg !135
  store i32 %5, ptr %2, align 4, !dbg !136, !tbaa !137, !DIAssignID !141
  call void @llvm.dbg.assign(metadata i32 %5, metadata !125, metadata !DIExpression(), metadata !141, metadata ptr %2, metadata !DIExpression()), !dbg !130
  call void @llvm.dbg.value(metadata i64 %4, metadata !142, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !149
  call void @llvm.dbg.value(metadata i32 %5, metadata !147, metadata !DIExpression()), !dbg !149
  %6 = load volatile i32, ptr @targ_tgid, align 4, !dbg !151, !tbaa !137
  %7 = icmp eq i32 %6, 0, !dbg !151
  br i1 %7, label %13, label %8, !dbg !153

8:                                                ; preds = %1
  %9 = lshr i64 %4, 32, !dbg !154
  tail call void @llvm.dbg.value(metadata i64 %9, metadata !124, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !130
  call void @llvm.dbg.value(metadata i64 %9, metadata !142, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !149
  %10 = trunc i64 %9 to i32, !dbg !155
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !124, metadata !DIExpression()), !dbg !130
  call void @llvm.dbg.value(metadata i32 %10, metadata !142, metadata !DIExpression()), !dbg !149
  %11 = load volatile i32, ptr @targ_tgid, align 4, !dbg !156, !tbaa !137
  %12 = icmp eq i32 %11, %10, !dbg !157
  br i1 %12, label %13, label %37, !dbg !158

13:                                               ; preds = %8, %1
  %14 = load volatile i32, ptr @targ_pid, align 4, !dbg !159, !tbaa !137
  %15 = icmp eq i32 %14, 0, !dbg !159
  br i1 %15, label %19, label %16, !dbg !161

16:                                               ; preds = %13
  %17 = load volatile i32, ptr @targ_pid, align 4, !dbg !162, !tbaa !137
  %18 = icmp eq i32 %17, %5, !dbg !163
  br i1 %18, label %19, label %37, !dbg !164

19:                                               ; preds = %16, %13
  %20 = load volatile i32, ptr @targ_uid, align 4, !dbg !165, !tbaa !137
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !167, metadata !DIExpression()), !dbg !172
  %21 = icmp eq i32 %20, -1, !dbg !174
  br i1 %21, label %27, label %22, !dbg !175

22:                                               ; preds = %19
  %23 = call i64 @bpf_get_current_uid_gid() #6, !dbg !176
  %24 = trunc i64 %23 to i32, !dbg !178
  call void @llvm.dbg.value(metadata i32 %24, metadata !148, metadata !DIExpression()), !dbg !149
  %25 = load volatile i32, ptr @targ_uid, align 4, !dbg !179, !tbaa !137
  %26 = icmp eq i32 %25, %24, !dbg !181
  br i1 %26, label %27, label %37, !dbg !182

27:                                               ; preds = %22, %19
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #7, !dbg !183
  %28 = getelementptr inbounds i8, ptr %3, i64 8, !dbg !184
  store i64 0, ptr %28, align 8, !dbg !184, !DIAssignID !185
  call void @llvm.dbg.assign(metadata i64 0, metadata !126, metadata !DIExpression(), metadata !185, metadata ptr %3, metadata !DIExpression()), !dbg !132
  call void @llvm.dbg.assign(metadata i8 0, metadata !126, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !186, metadata ptr undef, metadata !DIExpression()), !dbg !132
  %29 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, !dbg !187
  %30 = load i64, ptr %29, align 8, !dbg !188, !tbaa !189
  %31 = inttoptr i64 %30 to ptr, !dbg !191
  store ptr %31, ptr %3, align 8, !dbg !192, !tbaa !193, !DIAssignID !196
  call void @llvm.dbg.assign(metadata ptr %31, metadata !126, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !196, metadata ptr %3, metadata !DIExpression()), !dbg !132
  %32 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, i64 1, !dbg !197
  %33 = load i64, ptr %32, align 8, !dbg !197, !tbaa !189
  %34 = trunc i64 %33 to i32, !dbg !198
  %35 = getelementptr inbounds %struct.args_t, ptr %3, i64 0, i32 1, !dbg !199
  store i32 %34, ptr %35, align 8, !dbg !200, !tbaa !201, !DIAssignID !202
  call void @llvm.dbg.assign(metadata i32 %34, metadata !126, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !202, metadata ptr %35, metadata !DIExpression()), !dbg !132
  %36 = call i64 @bpf_map_update_elem(ptr noundef nonnull @start, ptr noundef nonnull %2, ptr noundef nonnull %3, i64 noundef 0) #6, !dbg !203
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #7, !dbg !204
  br label %37, !dbg !205

37:                                               ; preds = %22, %16, %8, %27
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #7, !dbg !206
  ret i32 0, !dbg !207
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: noredzone
declare !dbg !208 i64 @bpf_get_current_pid_tgid() local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: noredzone
declare !dbg !212 i64 @bpf_map_update_elem(ptr noundef, ptr noundef, ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_enter_openat(ptr nocapture noundef readonly %0) #0 section "tracepoint/syscalls/sys_enter_openat" !dbg !218 {
  %2 = alloca i32, align 4, !DIAssignID !227
  call void @llvm.dbg.assign(metadata i1 undef, metadata !223, metadata !DIExpression(), metadata !227, metadata ptr %2, metadata !DIExpression()), !dbg !228
  %3 = alloca %struct.args_t, align 8, !DIAssignID !229
  call void @llvm.dbg.assign(metadata i1 undef, metadata !224, metadata !DIExpression(), metadata !229, metadata ptr %3, metadata !DIExpression()), !dbg !230
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !220, metadata !DIExpression()), !dbg !228
  %4 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !231
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !221, metadata !DIExpression()), !dbg !228
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !222, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !228
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #7, !dbg !232
  %5 = trunc i64 %4 to i32, !dbg !233
  store i32 %5, ptr %2, align 4, !dbg !234, !tbaa !137, !DIAssignID !235
  call void @llvm.dbg.assign(metadata i32 %5, metadata !223, metadata !DIExpression(), metadata !235, metadata ptr %2, metadata !DIExpression()), !dbg !228
  call void @llvm.dbg.value(metadata i64 %4, metadata !142, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !236
  call void @llvm.dbg.value(metadata i32 %5, metadata !147, metadata !DIExpression()), !dbg !236
  %6 = load volatile i32, ptr @targ_tgid, align 4, !dbg !238, !tbaa !137
  %7 = icmp eq i32 %6, 0, !dbg !238
  br i1 %7, label %13, label %8, !dbg !239

8:                                                ; preds = %1
  %9 = lshr i64 %4, 32, !dbg !240
  tail call void @llvm.dbg.value(metadata i64 %9, metadata !222, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !228
  call void @llvm.dbg.value(metadata i64 %9, metadata !142, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !236
  %10 = trunc i64 %9 to i32, !dbg !241
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !222, metadata !DIExpression()), !dbg !228
  call void @llvm.dbg.value(metadata i32 %10, metadata !142, metadata !DIExpression()), !dbg !236
  %11 = load volatile i32, ptr @targ_tgid, align 4, !dbg !242, !tbaa !137
  %12 = icmp eq i32 %11, %10, !dbg !243
  br i1 %12, label %13, label %37, !dbg !244

13:                                               ; preds = %8, %1
  %14 = load volatile i32, ptr @targ_pid, align 4, !dbg !245, !tbaa !137
  %15 = icmp eq i32 %14, 0, !dbg !245
  br i1 %15, label %19, label %16, !dbg !246

16:                                               ; preds = %13
  %17 = load volatile i32, ptr @targ_pid, align 4, !dbg !247, !tbaa !137
  %18 = icmp eq i32 %17, %5, !dbg !248
  br i1 %18, label %19, label %37, !dbg !249

19:                                               ; preds = %16, %13
  %20 = load volatile i32, ptr @targ_uid, align 4, !dbg !250, !tbaa !137
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !167, metadata !DIExpression()), !dbg !251
  %21 = icmp eq i32 %20, -1, !dbg !253
  br i1 %21, label %27, label %22, !dbg !254

22:                                               ; preds = %19
  %23 = call i64 @bpf_get_current_uid_gid() #6, !dbg !255
  %24 = trunc i64 %23 to i32, !dbg !256
  call void @llvm.dbg.value(metadata i32 %24, metadata !148, metadata !DIExpression()), !dbg !236
  %25 = load volatile i32, ptr @targ_uid, align 4, !dbg !257, !tbaa !137
  %26 = icmp eq i32 %25, %24, !dbg !258
  br i1 %26, label %27, label %37, !dbg !259

27:                                               ; preds = %22, %19
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #7, !dbg !260
  %28 = getelementptr inbounds i8, ptr %3, i64 8, !dbg !261
  store i64 0, ptr %28, align 8, !dbg !261, !DIAssignID !262
  call void @llvm.dbg.assign(metadata i64 0, metadata !224, metadata !DIExpression(), metadata !262, metadata ptr %3, metadata !DIExpression()), !dbg !230
  call void @llvm.dbg.assign(metadata i8 0, metadata !224, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !263, metadata ptr undef, metadata !DIExpression()), !dbg !230
  %29 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, i64 1, !dbg !264
  %30 = load i64, ptr %29, align 8, !dbg !264, !tbaa !189
  %31 = inttoptr i64 %30 to ptr, !dbg !265
  store ptr %31, ptr %3, align 8, !dbg !266, !tbaa !193, !DIAssignID !267
  call void @llvm.dbg.assign(metadata ptr %31, metadata !224, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !267, metadata ptr %3, metadata !DIExpression()), !dbg !230
  %32 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, i64 2, !dbg !268
  %33 = load i64, ptr %32, align 8, !dbg !268, !tbaa !189
  %34 = trunc i64 %33 to i32, !dbg !269
  %35 = getelementptr inbounds %struct.args_t, ptr %3, i64 0, i32 1, !dbg !270
  store i32 %34, ptr %35, align 8, !dbg !271, !tbaa !201, !DIAssignID !272
  call void @llvm.dbg.assign(metadata i32 %34, metadata !224, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !272, metadata ptr %35, metadata !DIExpression()), !dbg !230
  %36 = call i64 @bpf_map_update_elem(ptr noundef nonnull @start, ptr noundef nonnull %2, ptr noundef nonnull %3, i64 noundef 0) #6, !dbg !273
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #7, !dbg !274
  br label %37, !dbg !275

37:                                               ; preds = %22, %16, %8, %27
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #7, !dbg !276
  ret i32 0, !dbg !277
}

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_exit_open(ptr noundef %0) #0 section "tracepoint/syscalls/sys_exit_open" !dbg !278 {
  %2 = alloca %struct.event, align 8, !DIAssignID !290
  %3 = alloca [3 x i64], align 16, !DIAssignID !291
  %4 = alloca i32, align 4, !DIAssignID !292
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !289, metadata !DIExpression()), !dbg !293
  call void @llvm.dbg.assign(metadata i1 undef, metadata !294, metadata !DIExpression(), metadata !290, metadata ptr %2, metadata !DIExpression()), !dbg !326
  call void @llvm.dbg.assign(metadata i1 undef, metadata !299, metadata !DIExpression(), metadata !291, metadata ptr %3, metadata !DIExpression()), !dbg !326
  call void @llvm.dbg.assign(metadata i1 undef, metadata !305, metadata !DIExpression(), metadata !292, metadata ptr %4, metadata !DIExpression()), !dbg !326
  call void @llvm.dbg.value(metadata ptr %0, metadata !297, metadata !DIExpression()), !dbg !326
  call void @llvm.lifetime.start.p0(i64 312, ptr nonnull %2) #7, !dbg !328
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(312) %2, i8 0, i64 312, i1 false), !dbg !329, !DIAssignID !330
  call void @llvm.dbg.assign(metadata i8 0, metadata !294, metadata !DIExpression(), metadata !330, metadata ptr %2, metadata !DIExpression()), !dbg !326
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %3) #7, !dbg !331
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #7, !dbg !332
  %5 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !333
  %6 = trunc i64 %5 to i32, !dbg !333
  store i32 %6, ptr %4, align 4, !dbg !334, !tbaa !137, !DIAssignID !335
  call void @llvm.dbg.assign(metadata i32 %6, metadata !305, metadata !DIExpression(), metadata !335, metadata ptr %4, metadata !DIExpression()), !dbg !326
  %7 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !336
  call void @llvm.dbg.value(metadata ptr %7, metadata !298, metadata !DIExpression()), !dbg !326
  %8 = icmp eq ptr %7, null, !dbg !337
  br i1 %8, label %44, label %9, !dbg !339

9:                                                ; preds = %1
  %10 = getelementptr inbounds %struct.trace_event_raw_sys_exit, ptr %0, i64 0, i32 2, !dbg !340
  %11 = load i64, ptr %10, align 8, !dbg !340, !tbaa !341
  %12 = trunc i64 %11 to i32, !dbg !345
  call void @llvm.dbg.value(metadata i32 %12, metadata !304, metadata !DIExpression()), !dbg !326
  %13 = load volatile i8, ptr @targ_failed, align 1, !dbg !346, !tbaa !348, !range !350, !noundef !351
  %14 = icmp ne i8 %13, 0, !dbg !346
  %15 = icmp sgt i32 %12, -1
  %16 = select i1 %14, i1 %15, i1 false, !dbg !352
  br i1 %16, label %42, label %17, !dbg !352

17:                                               ; preds = %9
  %18 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !353
  %19 = lshr i64 %18, 32, !dbg !354
  %20 = trunc i64 %19 to i32, !dbg !353
  %21 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 1, !dbg !355
  store i32 %20, ptr %21, align 8, !dbg !356, !tbaa !357, !DIAssignID !360
  call void @llvm.dbg.assign(metadata i32 %20, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !360, metadata ptr %21, metadata !DIExpression()), !dbg !326
  %22 = call i64 @bpf_get_current_uid_gid() #6, !dbg !361
  %23 = trunc i64 %22 to i32, !dbg !361
  %24 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 2, !dbg !362
  store i32 %23, ptr %24, align 4, !dbg !363, !tbaa !364, !DIAssignID !365
  call void @llvm.dbg.assign(metadata i32 %23, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !365, metadata ptr %24, metadata !DIExpression()), !dbg !326
  %25 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 6, !dbg !366
  %26 = call i64 @bpf_get_current_comm(ptr noundef nonnull %25, i32 noundef 16) #6, !dbg !367
  %27 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 7, !dbg !368
  %28 = load ptr, ptr %7, align 8, !dbg !369, !tbaa !193
  %29 = call i64 @bpf_probe_read_user_str(ptr noundef nonnull %27, i32 noundef 255, ptr noundef %28) #6, !dbg !370
  %30 = getelementptr inbounds %struct.args_t, ptr %7, i64 0, i32 1, !dbg !371
  %31 = load i32, ptr %30, align 8, !dbg !371, !tbaa !201
  %32 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 4, !dbg !372
  store i32 %31, ptr %32, align 4, !dbg !373, !tbaa !374, !DIAssignID !375
  call void @llvm.dbg.assign(metadata i32 %31, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 32), metadata !375, metadata ptr %32, metadata !DIExpression()), !dbg !326
  %33 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 3, !dbg !376
  store i32 %12, ptr %33, align 8, !dbg !377, !tbaa !378, !DIAssignID !379
  call void @llvm.dbg.assign(metadata i32 %12, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32), metadata !379, metadata ptr %33, metadata !DIExpression()), !dbg !326
  %34 = call i64 @bpf_get_stack(ptr noundef nonnull %0, ptr noundef nonnull %3, i32 noundef 24, i64 noundef 256) #6, !dbg !380
  %35 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 1, !dbg !381
  %36 = load i64, ptr %35, align 8, !dbg !381, !tbaa !189
  %37 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, !dbg !382
  store i64 %36, ptr %37, align 8, !dbg !383, !tbaa !384, !DIAssignID !385
  call void @llvm.dbg.assign(metadata i64 %36, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !385, metadata ptr %37, metadata !DIExpression()), !dbg !326
  %38 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 2, !dbg !386
  %39 = load i64, ptr %38, align 16, !dbg !386, !tbaa !189
  %40 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, i64 1, !dbg !387
  store i64 %39, ptr %40, align 8, !dbg !388, !tbaa !384, !DIAssignID !389
  call void @llvm.dbg.assign(metadata i64 %39, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64), metadata !389, metadata ptr %40, metadata !DIExpression()), !dbg !326
  %41 = call i64 @bpf_perf_event_output(ptr noundef nonnull %0, ptr noundef nonnull @events, i64 noundef 4294967295, ptr noundef nonnull %2, i64 noundef 312) #6, !dbg !390
  br label %42, !dbg !390

42:                                               ; preds = %17, %9
  call void @llvm.dbg.label(metadata !306), !dbg !391
  %43 = call i64 @bpf_map_delete_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !392
  br label %44, !dbg !393

44:                                               ; preds = %1, %42
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #7, !dbg !394
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %3) #7, !dbg !394
  call void @llvm.lifetime.end.p0(i64 312, ptr nonnull %2) #7, !dbg !394
  ret i32 0, !dbg !395
}

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_exit_openat(ptr noundef %0) #0 section "tracepoint/syscalls/sys_exit_openat" !dbg !396 {
  %2 = alloca %struct.event, align 8, !DIAssignID !399
  %3 = alloca [3 x i64], align 16, !DIAssignID !400
  %4 = alloca i32, align 4, !DIAssignID !401
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !398, metadata !DIExpression()), !dbg !402
  call void @llvm.dbg.assign(metadata i1 undef, metadata !294, metadata !DIExpression(), metadata !399, metadata ptr %2, metadata !DIExpression()), !dbg !403
  call void @llvm.dbg.assign(metadata i1 undef, metadata !299, metadata !DIExpression(), metadata !400, metadata ptr %3, metadata !DIExpression()), !dbg !403
  call void @llvm.dbg.assign(metadata i1 undef, metadata !305, metadata !DIExpression(), metadata !401, metadata ptr %4, metadata !DIExpression()), !dbg !403
  call void @llvm.dbg.value(metadata ptr %0, metadata !297, metadata !DIExpression()), !dbg !403
  call void @llvm.lifetime.start.p0(i64 312, ptr nonnull %2) #7, !dbg !405
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(312) %2, i8 0, i64 312, i1 false), !dbg !406, !DIAssignID !407
  call void @llvm.dbg.assign(metadata i8 0, metadata !294, metadata !DIExpression(), metadata !407, metadata ptr %2, metadata !DIExpression()), !dbg !403
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %3) #7, !dbg !408
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #7, !dbg !409
  %5 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !410
  %6 = trunc i64 %5 to i32, !dbg !410
  store i32 %6, ptr %4, align 4, !dbg !411, !tbaa !137, !DIAssignID !412
  call void @llvm.dbg.assign(metadata i32 %6, metadata !305, metadata !DIExpression(), metadata !412, metadata ptr %4, metadata !DIExpression()), !dbg !403
  %7 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !413
  call void @llvm.dbg.value(metadata ptr %7, metadata !298, metadata !DIExpression()), !dbg !403
  %8 = icmp eq ptr %7, null, !dbg !414
  br i1 %8, label %44, label %9, !dbg !415

9:                                                ; preds = %1
  %10 = getelementptr inbounds %struct.trace_event_raw_sys_exit, ptr %0, i64 0, i32 2, !dbg !416
  %11 = load i64, ptr %10, align 8, !dbg !416, !tbaa !341
  %12 = trunc i64 %11 to i32, !dbg !417
  call void @llvm.dbg.value(metadata i32 %12, metadata !304, metadata !DIExpression()), !dbg !403
  %13 = load volatile i8, ptr @targ_failed, align 1, !dbg !418, !tbaa !348, !range !350, !noundef !351
  %14 = icmp ne i8 %13, 0, !dbg !418
  %15 = icmp sgt i32 %12, -1
  %16 = select i1 %14, i1 %15, i1 false, !dbg !419
  br i1 %16, label %42, label %17, !dbg !419

17:                                               ; preds = %9
  %18 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !420
  %19 = lshr i64 %18, 32, !dbg !421
  %20 = trunc i64 %19 to i32, !dbg !420
  %21 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 1, !dbg !422
  store i32 %20, ptr %21, align 8, !dbg !423, !tbaa !357, !DIAssignID !424
  call void @llvm.dbg.assign(metadata i32 %20, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !424, metadata ptr %21, metadata !DIExpression()), !dbg !403
  %22 = call i64 @bpf_get_current_uid_gid() #6, !dbg !425
  %23 = trunc i64 %22 to i32, !dbg !425
  %24 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 2, !dbg !426
  store i32 %23, ptr %24, align 4, !dbg !427, !tbaa !364, !DIAssignID !428
  call void @llvm.dbg.assign(metadata i32 %23, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !428, metadata ptr %24, metadata !DIExpression()), !dbg !403
  %25 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 6, !dbg !429
  %26 = call i64 @bpf_get_current_comm(ptr noundef nonnull %25, i32 noundef 16) #6, !dbg !430
  %27 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 7, !dbg !431
  %28 = load ptr, ptr %7, align 8, !dbg !432, !tbaa !193
  %29 = call i64 @bpf_probe_read_user_str(ptr noundef nonnull %27, i32 noundef 255, ptr noundef %28) #6, !dbg !433
  %30 = getelementptr inbounds %struct.args_t, ptr %7, i64 0, i32 1, !dbg !434
  %31 = load i32, ptr %30, align 8, !dbg !434, !tbaa !201
  %32 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 4, !dbg !435
  store i32 %31, ptr %32, align 4, !dbg !436, !tbaa !374, !DIAssignID !437
  call void @llvm.dbg.assign(metadata i32 %31, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 32), metadata !437, metadata ptr %32, metadata !DIExpression()), !dbg !403
  %33 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 3, !dbg !438
  store i32 %12, ptr %33, align 8, !dbg !439, !tbaa !378, !DIAssignID !440
  call void @llvm.dbg.assign(metadata i32 %12, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32), metadata !440, metadata ptr %33, metadata !DIExpression()), !dbg !403
  %34 = call i64 @bpf_get_stack(ptr noundef nonnull %0, ptr noundef nonnull %3, i32 noundef 24, i64 noundef 256) #6, !dbg !441
  %35 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 1, !dbg !442
  %36 = load i64, ptr %35, align 8, !dbg !442, !tbaa !189
  %37 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, !dbg !443
  store i64 %36, ptr %37, align 8, !dbg !444, !tbaa !384, !DIAssignID !445
  call void @llvm.dbg.assign(metadata i64 %36, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !445, metadata ptr %37, metadata !DIExpression()), !dbg !403
  %38 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 2, !dbg !446
  %39 = load i64, ptr %38, align 16, !dbg !446, !tbaa !189
  %40 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, i64 1, !dbg !447
  store i64 %39, ptr %40, align 8, !dbg !448, !tbaa !384, !DIAssignID !449
  call void @llvm.dbg.assign(metadata i64 %39, metadata !294, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64), metadata !449, metadata ptr %40, metadata !DIExpression()), !dbg !403
  %41 = call i64 @bpf_perf_event_output(ptr noundef nonnull %0, ptr noundef nonnull @events, i64 noundef 4294967295, ptr noundef nonnull %2, i64 noundef 312) #6, !dbg !450
  br label %42, !dbg !450

42:                                               ; preds = %17, %9
  call void @llvm.dbg.label(metadata !306), !dbg !451
  %43 = call i64 @bpf_map_delete_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !452
  br label %44, !dbg !453

44:                                               ; preds = %1, %42
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #7, !dbg !454
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %3) #7, !dbg !454
  call void @llvm.lifetime.end.p0(i64 312, ptr nonnull %2) #7, !dbg !454
  ret i32 0, !dbg !455
}

; Function Attrs: noredzone
declare !dbg !456 i64 @bpf_get_current_uid_gid() local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !457 ptr @bpf_map_lookup_elem(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !460 i64 @bpf_get_current_comm(ptr noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !463 i64 @bpf_probe_read_user_str(ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !466 i64 @bpf_get_stack(ptr noundef, ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !469 i64 @bpf_perf_event_output(ptr noundef, ptr noundef, i64 noundef, ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #4

; Function Attrs: noredzone
declare !dbg !472 i64 @bpf_map_delete_elem(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #5

attributes #0 = { noredzone nounwind "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noredzone "disable-tail-calls"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { noredzone nounwind }
attributes #7 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!87, !88, !89, !90, !91}
!llvm.ident = !{!92}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "targ_pid", scope: !2, file: !3, line: 8, type: !36, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !24, globals: !33, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "bcc/libbpf-tools/opensnoop.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "45bd8c9c3bdef9fa392017765011339c")
!4 = !{!5, !11, !18}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 8948, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/include/vmlinux.h", directory: "", checksumkind: CSK_MD5, checksum: "3164748a8c8211744854e3e1972af8d4")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10}
!9 = !DIEnumerator(name: "false", value: 0)
!10 = !DIEnumerator(name: "true", value: 1)
!11 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 460, baseType: !7, size: 32, elements: !12)
!12 = !{!13, !14, !15, !16, !17}
!13 = !DIEnumerator(name: "BPF_F_SKIP_FIELD_MASK", value: 255)
!14 = !DIEnumerator(name: "BPF_F_USER_STACK", value: 256)
!15 = !DIEnumerator(name: "BPF_F_FAST_STACK_CMP", value: 512)
!16 = !DIEnumerator(name: "BPF_F_REUSE_STACKID", value: 1024)
!17 = !DIEnumerator(name: "BPF_F_USER_BUILD_ID", value: 2048)
!18 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 403, baseType: !19, size: 64, elements: !20)
!19 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!20 = !{!21, !22, !23}
!21 = !DIEnumerator(name: "BPF_F_INDEX_MASK", value: 4294967295, isUnsigned: true)
!22 = !DIEnumerator(name: "BPF_F_CURRENT_CPU", value: 4294967295, isUnsigned: true)
!23 = !DIEnumerator(name: "BPF_F_CTXLEN_MASK", value: 4503595332403200, isUnsigned: true)
!24 = !{!25, !28, !29, !31}
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !26, size: 64)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !27)
!27 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!28 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "u32", file: !6, line: 26605, baseType: !30)
!30 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !6, line: 26593, baseType: !7)
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "uid_t", file: !6, line: 26803, baseType: !32)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "__kernel_uid32_t", file: !6, line: 26643, baseType: !7)
!33 = !{!0, !34, !40, !44, !50, !55, !78}
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(name: "targ_tgid", scope: !2, file: !3, line: 9, type: !36, isLocal: false, isDefinition: true)
!36 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !37)
!37 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !38)
!38 = !DIDerivedType(tag: DW_TAG_typedef, name: "pid_t", file: !6, line: 26147, baseType: !39)
!39 = !DIDerivedType(tag: DW_TAG_typedef, name: "__kernel_pid_t", file: !6, line: 26081, baseType: !28)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "targ_uid", scope: !2, file: !3, line: 10, type: !42, isLocal: false, isDefinition: true)
!42 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !43)
!43 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !31)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(name: "targ_failed", scope: !2, file: !3, line: 11, type: !46, isLocal: false, isDefinition: true)
!46 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !47)
!47 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !48)
!48 = !DIDerivedType(tag: DW_TAG_typedef, name: "bool", file: !6, line: 26049, baseType: !49)
!49 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!50 = !DIGlobalVariableExpression(var: !51, expr: !DIExpression())
!51 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !3, line: 136, type: !52, isLocal: false, isDefinition: true)
!52 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 32, elements: !53)
!53 = !{!54}
!54 = !DISubrange(count: 4)
!55 = !DIGlobalVariableExpression(var: !56, expr: !DIExpression())
!56 = distinct !DIGlobalVariable(name: "start", scope: !2, file: !3, line: 18, type: !57, isLocal: false, isDefinition: true)
!57 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 13, size: 256, elements: !58)
!58 = !{!59, !64, !69, !71}
!59 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !57, file: !3, line: 14, baseType: !60, size: 64)
!60 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !61, size: 64)
!61 = !DICompositeType(tag: DW_TAG_array_type, baseType: !28, size: 32, elements: !62)
!62 = !{!63}
!63 = !DISubrange(count: 1)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !57, file: !3, line: 15, baseType: !65, size: 64, offset: 64)
!65 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !66, size: 64)
!66 = !DICompositeType(tag: DW_TAG_array_type, baseType: !28, size: 327680, elements: !67)
!67 = !{!68}
!68 = !DISubrange(count: 10240)
!69 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !57, file: !3, line: 16, baseType: !70, size: 64, offset: 128)
!70 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !57, file: !3, line: 17, baseType: !72, size: 64, offset: 192)
!72 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 64)
!73 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "args_t", file: !74, line: 9, size: 128, elements: !75)
!74 = !DIFile(filename: "bcc/libbpf-tools/opensnoop.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "0103892cbc9dc772f93d372f15ef3ee6")
!75 = !{!76, !77}
!76 = !DIDerivedType(tag: DW_TAG_member, name: "fname", scope: !73, file: !74, line: 10, baseType: !25, size: 64)
!77 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !73, file: !74, line: 11, baseType: !28, size: 32, offset: 64)
!78 = !DIGlobalVariableExpression(var: !79, expr: !DIExpression())
!79 = distinct !DIGlobalVariable(name: "events", scope: !2, file: !3, line: 24, type: !80, isLocal: false, isDefinition: true)
!80 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 20, size: 192, elements: !81)
!81 = !{!82, !85, !86}
!82 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !80, file: !3, line: 21, baseType: !83, size: 64)
!83 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64)
!84 = !DICompositeType(tag: DW_TAG_array_type, baseType: !28, size: 128, elements: !53)
!85 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !80, file: !3, line: 22, baseType: !83, size: 64, offset: 64)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !80, file: !3, line: 23, baseType: !83, size: 64, offset: 128)
!87 = !{i32 7, !"Dwarf Version", i32 5}
!88 = !{i32 2, !"Debug Info Version", i32 3}
!89 = !{i32 1, !"wchar_size", i32 4}
!90 = !{i32 8, !"PIC Level", i32 2}
!91 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!92 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!93 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_enter_open", scope: !3, file: !3, line: 50, type: !94, scopeLine: 51, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !118)
!94 = !DISubroutineType(types: !95)
!95 = !{!28, !96}
!96 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !97, size: 64)
!97 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_event_raw_sys_enter", file: !6, line: 119642, size: 512, elements: !98)
!98 = !{!99, !108, !110, !114}
!99 = !DIDerivedType(tag: DW_TAG_member, name: "ent", scope: !97, file: !6, line: 119643, baseType: !100, size: 64)
!100 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_entry", file: !6, line: 45382, size: 64, elements: !101)
!101 = !{!102, !104, !106, !107}
!102 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !100, file: !6, line: 45383, baseType: !103, size: 16)
!103 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !100, file: !6, line: 45384, baseType: !105, size: 8, offset: 16)
!105 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "preempt_count", scope: !100, file: !6, line: 45385, baseType: !105, size: 8, offset: 24)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "pid", scope: !100, file: !6, line: 45386, baseType: !28, size: 32, offset: 32)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !97, file: !6, line: 119644, baseType: !109, size: 64, offset: 64)
!109 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!110 = !DIDerivedType(tag: DW_TAG_member, name: "args", scope: !97, file: !6, line: 119645, baseType: !111, size: 384, offset: 128)
!111 = !DICompositeType(tag: DW_TAG_array_type, baseType: !19, size: 384, elements: !112)
!112 = !{!113}
!113 = !DISubrange(count: 6)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !97, file: !6, line: 119646, baseType: !115, offset: 512)
!115 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, elements: !116)
!116 = !{!117}
!117 = !DISubrange(count: 0)
!118 = !{!119, !120, !124, !125, !126}
!119 = !DILocalVariable(name: "ctx", arg: 1, scope: !93, file: !3, line: 50, type: !96)
!120 = !DILocalVariable(name: "id", scope: !93, file: !3, line: 52, type: !121)
!121 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !6, line: 26235, baseType: !122)
!122 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !6, line: 26227, baseType: !123)
!123 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!124 = !DILocalVariable(name: "tgid", scope: !93, file: !3, line: 54, type: !29)
!125 = !DILocalVariable(name: "pid", scope: !93, file: !3, line: 55, type: !29)
!126 = !DILocalVariable(name: "args", scope: !127, file: !3, line: 59, type: !73)
!127 = distinct !DILexicalBlock(scope: !128, file: !3, line: 58, column: 32)
!128 = distinct !DILexicalBlock(scope: !93, file: !3, line: 58, column: 6)
!129 = distinct !DIAssignID()
!130 = !DILocation(line: 0, scope: !93)
!131 = distinct !DIAssignID()
!132 = !DILocation(line: 0, scope: !127)
!133 = !DILocation(line: 52, column: 11, scope: !93)
!134 = !DILocation(line: 55, column: 2, scope: !93)
!135 = !DILocation(line: 55, column: 12, scope: !93)
!136 = !DILocation(line: 55, column: 6, scope: !93)
!137 = !{!138, !138, i64 0}
!138 = !{!"int", !139, i64 0}
!139 = !{!"omnipotent char", !140, i64 0}
!140 = !{!"Simple C/C++ TBAA"}
!141 = distinct !DIAssignID()
!142 = !DILocalVariable(name: "tgid", arg: 1, scope: !143, file: !3, line: 31, type: !29)
!143 = distinct !DISubprogram(name: "trace_allowed", scope: !3, file: !3, line: 31, type: !144, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !146)
!144 = !DISubroutineType(types: !145)
!145 = !{!48, !29, !29}
!146 = !{!142, !147, !148}
!147 = !DILocalVariable(name: "pid", arg: 2, scope: !143, file: !3, line: 31, type: !29)
!148 = !DILocalVariable(name: "uid", scope: !143, file: !3, line: 33, type: !29)
!149 = !DILocation(line: 0, scope: !143, inlinedAt: !150)
!150 = distinct !DILocation(line: 58, column: 6, scope: !128)
!151 = !DILocation(line: 36, column: 6, scope: !152, inlinedAt: !150)
!152 = distinct !DILexicalBlock(scope: !143, file: !3, line: 36, column: 6)
!153 = !DILocation(line: 36, column: 16, scope: !152, inlinedAt: !150)
!154 = !DILocation(line: 54, column: 16, scope: !93)
!155 = !DILocation(line: 54, column: 13, scope: !93)
!156 = !DILocation(line: 36, column: 19, scope: !152, inlinedAt: !150)
!157 = !DILocation(line: 36, column: 29, scope: !152, inlinedAt: !150)
!158 = !DILocation(line: 36, column: 6, scope: !143, inlinedAt: !150)
!159 = !DILocation(line: 38, column: 6, scope: !160, inlinedAt: !150)
!160 = distinct !DILexicalBlock(scope: !143, file: !3, line: 38, column: 6)
!161 = !DILocation(line: 38, column: 15, scope: !160, inlinedAt: !150)
!162 = !DILocation(line: 38, column: 18, scope: !160, inlinedAt: !150)
!163 = !DILocation(line: 38, column: 27, scope: !160, inlinedAt: !150)
!164 = !DILocation(line: 38, column: 6, scope: !143, inlinedAt: !150)
!165 = !DILocation(line: 40, column: 16, scope: !166, inlinedAt: !150)
!166 = distinct !DILexicalBlock(scope: !143, file: !3, line: 40, column: 6)
!167 = !DILocalVariable(name: "uid", arg: 1, scope: !168, file: !3, line: 26, type: !31)
!168 = distinct !DISubprogram(name: "valid_uid", scope: !3, file: !3, line: 26, type: !169, scopeLine: 26, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !171)
!169 = !DISubroutineType(types: !170)
!170 = !{!48, !31}
!171 = !{!167}
!172 = !DILocation(line: 0, scope: !168, inlinedAt: !173)
!173 = distinct !DILocation(line: 40, column: 6, scope: !166, inlinedAt: !150)
!174 = !DILocation(line: 27, column: 13, scope: !168, inlinedAt: !173)
!175 = !DILocation(line: 40, column: 6, scope: !143, inlinedAt: !150)
!176 = !DILocation(line: 41, column: 14, scope: !177, inlinedAt: !150)
!177 = distinct !DILexicalBlock(scope: !166, file: !3, line: 40, column: 27)
!178 = !DILocation(line: 41, column: 9, scope: !177, inlinedAt: !150)
!179 = !DILocation(line: 42, column: 7, scope: !180, inlinedAt: !150)
!180 = distinct !DILexicalBlock(scope: !177, file: !3, line: 42, column: 7)
!181 = !DILocation(line: 42, column: 16, scope: !180, inlinedAt: !150)
!182 = !DILocation(line: 42, column: 7, scope: !177, inlinedAt: !150)
!183 = !DILocation(line: 59, column: 3, scope: !127)
!184 = !DILocation(line: 59, column: 17, scope: !127)
!185 = distinct !DIAssignID()
!186 = distinct !DIAssignID()
!187 = !DILocation(line: 60, column: 35, scope: !127)
!188 = !DILocation(line: 60, column: 30, scope: !127)
!189 = !{!190, !190, i64 0}
!190 = !{!"long", !139, i64 0}
!191 = !DILocation(line: 60, column: 16, scope: !127)
!192 = !DILocation(line: 60, column: 14, scope: !127)
!193 = !{!194, !195, i64 0}
!194 = !{!"args_t", !195, i64 0, !138, i64 8}
!195 = !{!"any pointer", !139, i64 0}
!196 = distinct !DIAssignID()
!197 = !DILocation(line: 61, column: 21, scope: !127)
!198 = !DILocation(line: 61, column: 16, scope: !127)
!199 = !DILocation(line: 61, column: 8, scope: !127)
!200 = !DILocation(line: 61, column: 14, scope: !127)
!201 = !{!194, !138, i64 8}
!202 = distinct !DIAssignID()
!203 = !DILocation(line: 62, column: 3, scope: !127)
!204 = !DILocation(line: 63, column: 2, scope: !128)
!205 = !DILocation(line: 63, column: 2, scope: !127)
!206 = !DILocation(line: 65, column: 1, scope: !93)
!207 = !DILocation(line: 64, column: 2, scope: !93)
!208 = !DISubprogram(name: "bpf_get_current_pid_tgid", scope: !209, file: !209, line: 477, type: !210, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!209 = !DIFile(filename: "native_compat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "d60311c07fe0bcb85ac571d435aebf7a")
!210 = !DISubroutineType(types: !211)
!211 = !{!123}
!212 = !DISubprogram(name: "bpf_map_update_elem", scope: !209, file: !209, line: 459, type: !213, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!213 = !DISubroutineType(types: !214)
!214 = !{!109, !215, !216, !216, !123}
!215 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!216 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !217, size: 64)
!217 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!218 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_enter_openat", scope: !3, file: !3, line: 68, type: !94, scopeLine: 69, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !219)
!219 = !{!220, !221, !222, !223, !224}
!220 = !DILocalVariable(name: "ctx", arg: 1, scope: !218, file: !3, line: 68, type: !96)
!221 = !DILocalVariable(name: "id", scope: !218, file: !3, line: 70, type: !121)
!222 = !DILocalVariable(name: "tgid", scope: !218, file: !3, line: 72, type: !29)
!223 = !DILocalVariable(name: "pid", scope: !218, file: !3, line: 73, type: !29)
!224 = !DILocalVariable(name: "args", scope: !225, file: !3, line: 77, type: !73)
!225 = distinct !DILexicalBlock(scope: !226, file: !3, line: 76, column: 32)
!226 = distinct !DILexicalBlock(scope: !218, file: !3, line: 76, column: 6)
!227 = distinct !DIAssignID()
!228 = !DILocation(line: 0, scope: !218)
!229 = distinct !DIAssignID()
!230 = !DILocation(line: 0, scope: !225)
!231 = !DILocation(line: 70, column: 11, scope: !218)
!232 = !DILocation(line: 73, column: 2, scope: !218)
!233 = !DILocation(line: 73, column: 12, scope: !218)
!234 = !DILocation(line: 73, column: 6, scope: !218)
!235 = distinct !DIAssignID()
!236 = !DILocation(line: 0, scope: !143, inlinedAt: !237)
!237 = distinct !DILocation(line: 76, column: 6, scope: !226)
!238 = !DILocation(line: 36, column: 6, scope: !152, inlinedAt: !237)
!239 = !DILocation(line: 36, column: 16, scope: !152, inlinedAt: !237)
!240 = !DILocation(line: 72, column: 16, scope: !218)
!241 = !DILocation(line: 72, column: 13, scope: !218)
!242 = !DILocation(line: 36, column: 19, scope: !152, inlinedAt: !237)
!243 = !DILocation(line: 36, column: 29, scope: !152, inlinedAt: !237)
!244 = !DILocation(line: 36, column: 6, scope: !143, inlinedAt: !237)
!245 = !DILocation(line: 38, column: 6, scope: !160, inlinedAt: !237)
!246 = !DILocation(line: 38, column: 15, scope: !160, inlinedAt: !237)
!247 = !DILocation(line: 38, column: 18, scope: !160, inlinedAt: !237)
!248 = !DILocation(line: 38, column: 27, scope: !160, inlinedAt: !237)
!249 = !DILocation(line: 38, column: 6, scope: !143, inlinedAt: !237)
!250 = !DILocation(line: 40, column: 16, scope: !166, inlinedAt: !237)
!251 = !DILocation(line: 0, scope: !168, inlinedAt: !252)
!252 = distinct !DILocation(line: 40, column: 6, scope: !166, inlinedAt: !237)
!253 = !DILocation(line: 27, column: 13, scope: !168, inlinedAt: !252)
!254 = !DILocation(line: 40, column: 6, scope: !143, inlinedAt: !237)
!255 = !DILocation(line: 41, column: 14, scope: !177, inlinedAt: !237)
!256 = !DILocation(line: 41, column: 9, scope: !177, inlinedAt: !237)
!257 = !DILocation(line: 42, column: 7, scope: !180, inlinedAt: !237)
!258 = !DILocation(line: 42, column: 16, scope: !180, inlinedAt: !237)
!259 = !DILocation(line: 42, column: 7, scope: !177, inlinedAt: !237)
!260 = !DILocation(line: 77, column: 3, scope: !225)
!261 = !DILocation(line: 77, column: 17, scope: !225)
!262 = distinct !DIAssignID()
!263 = distinct !DIAssignID()
!264 = !DILocation(line: 78, column: 30, scope: !225)
!265 = !DILocation(line: 78, column: 16, scope: !225)
!266 = !DILocation(line: 78, column: 14, scope: !225)
!267 = distinct !DIAssignID()
!268 = !DILocation(line: 79, column: 21, scope: !225)
!269 = !DILocation(line: 79, column: 16, scope: !225)
!270 = !DILocation(line: 79, column: 8, scope: !225)
!271 = !DILocation(line: 79, column: 14, scope: !225)
!272 = distinct !DIAssignID()
!273 = !DILocation(line: 80, column: 3, scope: !225)
!274 = !DILocation(line: 81, column: 2, scope: !226)
!275 = !DILocation(line: 81, column: 2, scope: !225)
!276 = !DILocation(line: 83, column: 1, scope: !218)
!277 = !DILocation(line: 82, column: 2, scope: !218)
!278 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_exit_open", scope: !3, file: !3, line: 125, type: !279, scopeLine: 126, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !288)
!279 = !DISubroutineType(types: !280)
!280 = !{!28, !281}
!281 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !282, size: 64)
!282 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_event_raw_sys_exit", file: !6, line: 119649, size: 192, elements: !283)
!283 = !{!284, !285, !286, !287}
!284 = !DIDerivedType(tag: DW_TAG_member, name: "ent", scope: !282, file: !6, line: 119650, baseType: !100, size: 64)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !282, file: !6, line: 119651, baseType: !109, size: 64, offset: 64)
!286 = !DIDerivedType(tag: DW_TAG_member, name: "ret", scope: !282, file: !6, line: 119652, baseType: !109, size: 64, offset: 128)
!287 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !282, file: !6, line: 119653, baseType: !115, offset: 192)
!288 = !{!289}
!289 = !DILocalVariable(name: "ctx", arg: 1, scope: !278, file: !3, line: 125, type: !281)
!290 = distinct !DIAssignID()
!291 = distinct !DIAssignID()
!292 = distinct !DIAssignID()
!293 = !DILocation(line: 0, scope: !278)
!294 = !DILocalVariable(name: "event", scope: !295, file: !3, line: 88, type: !307)
!295 = distinct !DISubprogram(name: "trace_exit", scope: !3, file: !3, line: 86, type: !279, scopeLine: 87, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !296)
!296 = !{!297, !294, !298, !299, !304, !305, !306}
!297 = !DILocalVariable(name: "ctx", arg: 1, scope: !295, file: !3, line: 86, type: !281)
!298 = !DILocalVariable(name: "ap", scope: !295, file: !3, line: 89, type: !72)
!299 = !DILocalVariable(name: "stack", scope: !295, file: !3, line: 90, type: !300)
!300 = !DICompositeType(tag: DW_TAG_array_type, baseType: !301, size: 192, elements: !302)
!301 = !DIDerivedType(tag: DW_TAG_typedef, name: "uintptr_t", file: !6, line: 26421, baseType: !19)
!302 = !{!303}
!303 = !DISubrange(count: 3)
!304 = !DILocalVariable(name: "ret", scope: !295, file: !3, line: 91, type: !28)
!305 = !DILocalVariable(name: "pid", scope: !295, file: !3, line: 92, type: !29)
!306 = !DILabel(scope: !295, name: "cleanup", file: !3, line: 119)
!307 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !74, line: 14, size: 2496, elements: !308)
!308 = !{!309, !310, !311, !312, !313, !314, !318, !322}
!309 = !DIDerivedType(tag: DW_TAG_member, name: "ts", scope: !307, file: !74, line: 16, baseType: !122, size: 64)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "pid", scope: !307, file: !74, line: 17, baseType: !38, size: 32, offset: 64)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "uid", scope: !307, file: !74, line: 18, baseType: !31, size: 32, offset: 96)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "ret", scope: !307, file: !74, line: 19, baseType: !28, size: 32, offset: 128)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !307, file: !74, line: 20, baseType: !28, size: 32, offset: 160)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "callers", scope: !307, file: !74, line: 21, baseType: !315, size: 128, offset: 192)
!315 = !DICompositeType(tag: DW_TAG_array_type, baseType: !122, size: 128, elements: !316)
!316 = !{!317}
!317 = !DISubrange(count: 2)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "comm", scope: !307, file: !74, line: 22, baseType: !319, size: 128, offset: 320)
!319 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 128, elements: !320)
!320 = !{!321}
!321 = !DISubrange(count: 16)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "fname", scope: !307, file: !74, line: 23, baseType: !323, size: 2040, offset: 448)
!323 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 2040, elements: !324)
!324 = !{!325}
!325 = !DISubrange(count: 255)
!326 = !DILocation(line: 0, scope: !295, inlinedAt: !327)
!327 = distinct !DILocation(line: 127, column: 9, scope: !278)
!328 = !DILocation(line: 88, column: 2, scope: !295, inlinedAt: !327)
!329 = !DILocation(line: 88, column: 15, scope: !295, inlinedAt: !327)
!330 = distinct !DIAssignID()
!331 = !DILocation(line: 90, column: 2, scope: !295, inlinedAt: !327)
!332 = !DILocation(line: 92, column: 2, scope: !295, inlinedAt: !327)
!333 = !DILocation(line: 92, column: 12, scope: !295, inlinedAt: !327)
!334 = !DILocation(line: 92, column: 6, scope: !295, inlinedAt: !327)
!335 = distinct !DIAssignID()
!336 = !DILocation(line: 94, column: 7, scope: !295, inlinedAt: !327)
!337 = !DILocation(line: 95, column: 7, scope: !338, inlinedAt: !327)
!338 = distinct !DILexicalBlock(scope: !295, file: !3, line: 95, column: 6)
!339 = !DILocation(line: 95, column: 6, scope: !295, inlinedAt: !327)
!340 = !DILocation(line: 97, column: 13, scope: !295, inlinedAt: !327)
!341 = !{!342, !190, i64 16}
!342 = !{!"trace_event_raw_sys_exit", !343, i64 0, !190, i64 8, !190, i64 16, !139, i64 24}
!343 = !{!"trace_entry", !344, i64 0, !139, i64 2, !139, i64 3, !138, i64 4}
!344 = !{!"short", !139, i64 0}
!345 = !DILocation(line: 97, column: 8, scope: !295, inlinedAt: !327)
!346 = !DILocation(line: 98, column: 6, scope: !347, inlinedAt: !327)
!347 = distinct !DILexicalBlock(scope: !295, file: !3, line: 98, column: 6)
!348 = !{!349, !349, i64 0}
!349 = !{!"_Bool", !139, i64 0}
!350 = !{i8 0, i8 2}
!351 = !{}
!352 = !DILocation(line: 98, column: 18, scope: !347, inlinedAt: !327)
!353 = !DILocation(line: 102, column: 14, scope: !295, inlinedAt: !327)
!354 = !DILocation(line: 102, column: 41, scope: !295, inlinedAt: !327)
!355 = !DILocation(line: 102, column: 8, scope: !295, inlinedAt: !327)
!356 = !DILocation(line: 102, column: 12, scope: !295, inlinedAt: !327)
!357 = !{!358, !138, i64 8}
!358 = !{!"event", !359, i64 0, !138, i64 8, !138, i64 12, !138, i64 16, !138, i64 20, !139, i64 24, !139, i64 40, !139, i64 56}
!359 = !{!"long long", !139, i64 0}
!360 = distinct !DIAssignID()
!361 = !DILocation(line: 103, column: 14, scope: !295, inlinedAt: !327)
!362 = !DILocation(line: 103, column: 8, scope: !295, inlinedAt: !327)
!363 = !DILocation(line: 103, column: 12, scope: !295, inlinedAt: !327)
!364 = !{!358, !138, i64 12}
!365 = distinct !DIAssignID()
!366 = !DILocation(line: 104, column: 30, scope: !295, inlinedAt: !327)
!367 = !DILocation(line: 104, column: 2, scope: !295, inlinedAt: !327)
!368 = !DILocation(line: 105, column: 33, scope: !295, inlinedAt: !327)
!369 = !DILocation(line: 105, column: 65, scope: !295, inlinedAt: !327)
!370 = !DILocation(line: 105, column: 2, scope: !295, inlinedAt: !327)
!371 = !DILocation(line: 106, column: 20, scope: !295, inlinedAt: !327)
!372 = !DILocation(line: 106, column: 8, scope: !295, inlinedAt: !327)
!373 = !DILocation(line: 106, column: 14, scope: !295, inlinedAt: !327)
!374 = !{!358, !138, i64 20}
!375 = distinct !DIAssignID()
!376 = !DILocation(line: 107, column: 8, scope: !295, inlinedAt: !327)
!377 = !DILocation(line: 107, column: 12, scope: !295, inlinedAt: !327)
!378 = !{!358, !138, i64 16}
!379 = distinct !DIAssignID()
!380 = !DILocation(line: 109, column: 2, scope: !295, inlinedAt: !327)
!381 = !DILocation(line: 112, column: 21, scope: !295, inlinedAt: !327)
!382 = !DILocation(line: 112, column: 8, scope: !295, inlinedAt: !327)
!383 = !DILocation(line: 112, column: 19, scope: !295, inlinedAt: !327)
!384 = !{!359, !359, i64 0}
!385 = distinct !DIAssignID()
!386 = !DILocation(line: 113, column: 21, scope: !295, inlinedAt: !327)
!387 = !DILocation(line: 113, column: 2, scope: !295, inlinedAt: !327)
!388 = !DILocation(line: 113, column: 19, scope: !295, inlinedAt: !327)
!389 = distinct !DIAssignID()
!390 = !DILocation(line: 116, column: 2, scope: !295, inlinedAt: !327)
!391 = !DILocation(line: 119, column: 1, scope: !295, inlinedAt: !327)
!392 = !DILocation(line: 120, column: 2, scope: !295, inlinedAt: !327)
!393 = !DILocation(line: 121, column: 2, scope: !295, inlinedAt: !327)
!394 = !DILocation(line: 122, column: 1, scope: !295, inlinedAt: !327)
!395 = !DILocation(line: 127, column: 2, scope: !278)
!396 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_exit_openat", scope: !3, file: !3, line: 131, type: !279, scopeLine: 132, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !397)
!397 = !{!398}
!398 = !DILocalVariable(name: "ctx", arg: 1, scope: !396, file: !3, line: 131, type: !281)
!399 = distinct !DIAssignID()
!400 = distinct !DIAssignID()
!401 = distinct !DIAssignID()
!402 = !DILocation(line: 0, scope: !396)
!403 = !DILocation(line: 0, scope: !295, inlinedAt: !404)
!404 = distinct !DILocation(line: 133, column: 9, scope: !396)
!405 = !DILocation(line: 88, column: 2, scope: !295, inlinedAt: !404)
!406 = !DILocation(line: 88, column: 15, scope: !295, inlinedAt: !404)
!407 = distinct !DIAssignID()
!408 = !DILocation(line: 90, column: 2, scope: !295, inlinedAt: !404)
!409 = !DILocation(line: 92, column: 2, scope: !295, inlinedAt: !404)
!410 = !DILocation(line: 92, column: 12, scope: !295, inlinedAt: !404)
!411 = !DILocation(line: 92, column: 6, scope: !295, inlinedAt: !404)
!412 = distinct !DIAssignID()
!413 = !DILocation(line: 94, column: 7, scope: !295, inlinedAt: !404)
!414 = !DILocation(line: 95, column: 7, scope: !338, inlinedAt: !404)
!415 = !DILocation(line: 95, column: 6, scope: !295, inlinedAt: !404)
!416 = !DILocation(line: 97, column: 13, scope: !295, inlinedAt: !404)
!417 = !DILocation(line: 97, column: 8, scope: !295, inlinedAt: !404)
!418 = !DILocation(line: 98, column: 6, scope: !347, inlinedAt: !404)
!419 = !DILocation(line: 98, column: 18, scope: !347, inlinedAt: !404)
!420 = !DILocation(line: 102, column: 14, scope: !295, inlinedAt: !404)
!421 = !DILocation(line: 102, column: 41, scope: !295, inlinedAt: !404)
!422 = !DILocation(line: 102, column: 8, scope: !295, inlinedAt: !404)
!423 = !DILocation(line: 102, column: 12, scope: !295, inlinedAt: !404)
!424 = distinct !DIAssignID()
!425 = !DILocation(line: 103, column: 14, scope: !295, inlinedAt: !404)
!426 = !DILocation(line: 103, column: 8, scope: !295, inlinedAt: !404)
!427 = !DILocation(line: 103, column: 12, scope: !295, inlinedAt: !404)
!428 = distinct !DIAssignID()
!429 = !DILocation(line: 104, column: 30, scope: !295, inlinedAt: !404)
!430 = !DILocation(line: 104, column: 2, scope: !295, inlinedAt: !404)
!431 = !DILocation(line: 105, column: 33, scope: !295, inlinedAt: !404)
!432 = !DILocation(line: 105, column: 65, scope: !295, inlinedAt: !404)
!433 = !DILocation(line: 105, column: 2, scope: !295, inlinedAt: !404)
!434 = !DILocation(line: 106, column: 20, scope: !295, inlinedAt: !404)
!435 = !DILocation(line: 106, column: 8, scope: !295, inlinedAt: !404)
!436 = !DILocation(line: 106, column: 14, scope: !295, inlinedAt: !404)
!437 = distinct !DIAssignID()
!438 = !DILocation(line: 107, column: 8, scope: !295, inlinedAt: !404)
!439 = !DILocation(line: 107, column: 12, scope: !295, inlinedAt: !404)
!440 = distinct !DIAssignID()
!441 = !DILocation(line: 109, column: 2, scope: !295, inlinedAt: !404)
!442 = !DILocation(line: 112, column: 21, scope: !295, inlinedAt: !404)
!443 = !DILocation(line: 112, column: 8, scope: !295, inlinedAt: !404)
!444 = !DILocation(line: 112, column: 19, scope: !295, inlinedAt: !404)
!445 = distinct !DIAssignID()
!446 = !DILocation(line: 113, column: 21, scope: !295, inlinedAt: !404)
!447 = !DILocation(line: 113, column: 2, scope: !295, inlinedAt: !404)
!448 = !DILocation(line: 113, column: 19, scope: !295, inlinedAt: !404)
!449 = distinct !DIAssignID()
!450 = !DILocation(line: 116, column: 2, scope: !295, inlinedAt: !404)
!451 = !DILocation(line: 119, column: 1, scope: !295, inlinedAt: !404)
!452 = !DILocation(line: 120, column: 2, scope: !295, inlinedAt: !404)
!453 = !DILocation(line: 121, column: 2, scope: !295, inlinedAt: !404)
!454 = !DILocation(line: 122, column: 1, scope: !295, inlinedAt: !404)
!455 = !DILocation(line: 133, column: 2, scope: !396)
!456 = !DISubprogram(name: "bpf_get_current_uid_gid", scope: !209, file: !209, line: 478, type: !210, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!457 = !DISubprogram(name: "bpf_map_lookup_elem", scope: !209, file: !209, line: 458, type: !458, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!458 = !DISubroutineType(types: !459)
!459 = !{!215, !215, !216}
!460 = !DISubprogram(name: "bpf_get_current_comm", scope: !209, file: !209, line: 483, type: !461, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!461 = !DISubroutineType(types: !462)
!462 = !{!109, !215, !7}
!463 = !DISubprogram(name: "bpf_probe_read_user_str", scope: !209, file: !209, line: 473, type: !464, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!464 = !DISubroutineType(types: !465)
!465 = !{!109, !215, !7, !216}
!466 = !DISubprogram(name: "bpf_get_stack", scope: !209, file: !209, line: 494, type: !467, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!467 = !DISubroutineType(types: !468)
!468 = !{!109, !215, !215, !7, !123}
!469 = !DISubprogram(name: "bpf_perf_event_output", scope: !209, file: !209, line: 488, type: !470, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!470 = !DISubroutineType(types: !471)
!471 = !{!109, !215, !215, !123, !215, !123}
!472 = !DISubprogram(name: "bpf_map_delete_elem", scope: !209, file: !209, line: 461, type: !473, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!473 = !DISubroutineType(types: !474)
!474 = !{!109, !215, !216}
