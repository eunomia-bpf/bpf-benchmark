from pathlib import Path
from datetime import datetime,timezone
import subprocess,shlex,json,re,hashlib,sys,shutil,tarfile,traceback
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');G=Path(__file__).resolve().parent;N=Path('/var/tmp/kprog-tmp/C/native-constant-division');O=R/'corpus/results/kprog_app_coverage_20261109/bcc-frozen-config-set';commands=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(args,log,cwd=R):
 commands.append(dict(args=[str(x)for x in args],log=log,cwd=str(cwd)));(G/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with(G/log).open('w')as f:p=subprocess.run([str(x)for x in args],cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 (G/(log+'.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('target_kernel_btf_and_native_compile')
 btf=R/'kprog/tv/build-kernel-x86/vmlinux';tool=R/'vendor/build/x86/bpftool/bin/bpftool';args=[str(tool),'btf','dump','file',str(btf),'format','c'];commands.append(dict(args=args,output='include/vmlinux.h'));(G/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with(G/'include/vmlinux.h').open('w')as f:p=subprocess.run(args,stdout=f,stderr=subprocess.PIPE,text=True)
 (G/'btf-dump.stderr').write_text(p.stderr);(G/'btf-dump.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 bindings=json.loads((G/'bindings.json').read_text());log=(N/'control-native.log').read_text().replace('\\\n',' ');rows=[]
 codegen=['clang-18','-O3','-g','-fPIC','-c','-fomit-frame-pointer','-march=native','-mno-red-zone','-mgeneral-regs-only','-fno-stack-protector','-fno-asynchronous-unwind-tables','-fno-unwind-tables','-fno-jump-tables','-fno-optimize-sibling-calls','-mllvm','-switch-to-lookup=false']
 for name,values in bindings.items():
  (G/(name+'-bindings.json')).write_text(json.dumps(values,indent=2)+'\n');command=shlex.split(next(l for l in log.splitlines()if l.startswith('"clang-18"')and name+'.bpf.c'in l));command[1:1]=['-I'+str(G/'include')];command[command.index('-o')+1]=str(G/(name+'.control.ll'));command+=['-S','-emit-llvm'];run(command,name+'-emit-ir.log',R/'vendor/bpf')
  run(['python3',G/'specialize-ir.py',G/(name+'.control.ll'),G/(name+'-bindings.json'),G/(name+'.candidate.ll'),G/(name+'-replaced-loads.json')],name+'-specialize.log')
  for label in ['control','candidate']:
   target=G/label/'bcc';target.mkdir(parents=True,exist_ok=True);obj=target/(name+'.native.o');run([*codegen,G/(name+'.'+label+'.ll'),'-o',obj],name+'-'+label+'-codegen.log')
   with obj.open('rb')as f:
    elf=ELFFile(f);sections=[dict(name=s.name,bytes=s['sh_size'],sha256=hashlib.sha256(s.data()).hexdigest())for s in elf.iter_sections()if s['sh_flags']&4 and s['sh_size']]
   dis=subprocess.check_output(['llvm-objdump-18','-dr','--no-show-raw-insn',str(obj)],text=True);(G/(name+'.'+label+'.disassembly.txt')).write_text(dis);ins=[l for l in dis.splitlines()if re.match(r'^\s*[0-9a-f]+:\s+\S',l)]
   rows.append(dict(tool=name,label=label,elf_sha256=sha(obj),sections=sections,executable_bytes=sum(s['bytes']for s in sections),instructions=len(ins),conditional_branches=sum(bool(re.search(r'\tj(?!mp)[a-z]+\s',l))for l in ins),calls=sum('\tcall'in l for l in ins),rip_memory_ops=sum('(%rip)'in l for l in ins)))
  (G/'objects.json').write_text(json.dumps(rows,indent=2)+'\n');save('native_compile',completed_tools=name)
 for label in ['control','candidate']:
  target=G/label/'bcc';run(['python3',R/'vendor/bpf/write_native_manifest.py','--app','bcc','--llvm-nm','llvm-nm-18','--output',target/'manifest.json',*[arg for obj in sorted(target.glob('*.native.o'))for arg in ['--object',obj]]],label+'-manifest.log')
 inputs=dict(source_head=(G/'source-head').read_text().strip(),frozen_workload='9f3855f6f',syscount_arguments=['-L','-i','1'],other_tool_arguments=[],dynamic_configuration_retained=['capable.my_pid set by getpid at startup'],bindings=bindings,target_vmlinux=str(btf),target_vmlinux_sha256=sha(btf),target_vmlinux_h_sha256=sha(G/'include/vmlinux.h'),compiler='clang18 O3 original flags/division pass; target BTF from retained SMAP kernel; paired IR pipeline',files={str(p.relative_to(G/'source')):sha(p)for p in(G/'source').rglob('*')if p.is_file()});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 # Direct global volatile reads still include capable.my_pid in the specialized IR.
 observations=dict(capable_dynamic_my_pid_reads=[l.strip()for l in(G/'capable.candidate.ll').read_text().splitlines()if 'load volatile'in l and'@my_pid'in l],syscount_control_task_fields=[l.strip()for l in(G/'syscount.control.disassembly.txt').read_text().splitlines()if '0xb30'in l or'0xd10'in l or'0xbb8'in l or'0xd90'in l]);(G/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
 O.mkdir(parents=True,exist_ok=True);result=dict(inputs=inputs,objects=rows,observations=observations,replaced_loads={name:json.loads((G/(name+'-replaced-loads.json')).read_text())for name in bindings},native_executions=0,guest_executions=0);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 table='| Tool | Control bytes | Candidate bytes | Control instructions | Candidate instructions |\n| --- | ---: | ---: | ---: | ---: |\n'
 for name in bindings:
  a,b=[next(r for r in rows if r['tool']==name and r['label']==label)for label in ['control','candidate']];table+=f"| {name} | {a['executable_bytes']} | {b['executable_bytes']} | {a['instructions']} | {b['instructions']} |\n"
 (O/'README.md').write_text('# Complete BCC native producer from frozen configuration and target BTF\n\nThe frozen May29 eight-tool CLI supplies the captured stable read-only settings. The native compiler replaces only their scalar volatile IR reads before the existing O3 backend. Capable my_pid remains a live configuration read because startup getpid supplies its value. Every original tool/program remains in both complete manifests. Each paired compiler uses the same original C/flags/division pass and a vmlinux.h dumped from the retained SMAP kernel BTF, so kernel structure layout is an explicit native compiler input.\n\n'+table+'\nOriginal CLI/C/JIT/workload and same-copy kernel emission retain their definitions. summary.json records all field bindings, replaced loads, exact ELF/section hashes, dynamic reads and target kernel/header identities. raw.tar.gz carries native payloads, manifests, IR, disassembly, commands and source. These are compiler observations; actual generated B, verifier/application work and R frozen05-29 throughput follow separately. Production/runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tar:
  for p in sorted(G.iterdir()):
   if p.name not in ['controller.log','controller.pid','status.json','publication.json']:tar.add(p,arcname=p.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Compile the complete BCC set from frozen configuration and target BTF',G/'publication.json');save('finished',commit=commit,objects=rows)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' complete8tool BCC paired native compile from frozen stable configuration and actual retained SMAP kernel BTF. Both manifests preserve all programs; dynamic capable.my_pid stays live. Only pre-submit P compilation changes. Static native object/source/IR/codegen receipts retained; actual B/wholeapp and restored05-29 timing follow. Existing guest queue keeps its bytes. Runtime admission additions0.\n')
except BaseException as error:save('requires_continuation',error=str(error),traceback=traceback.format_exc());raise
