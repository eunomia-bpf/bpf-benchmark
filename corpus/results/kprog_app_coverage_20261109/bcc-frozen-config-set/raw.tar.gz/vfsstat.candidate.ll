; ModuleID = 'bcc/libbpf-tools/vfsstat.bpf.c'
source_filename = "bcc/libbpf-tools/vfsstat.bpf.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@stats = global [5 x i64] zeroinitializer, align 16, !dbg !0
@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !16
@llvm.compiler.used = appending global [11 x ptr] [ptr @LICENSE, ptr @fentry_vfs_create, ptr @fentry_vfs_fsync, ptr @fentry_vfs_open, ptr @fentry_vfs_read, ptr @fentry_vfs_write, ptr @kprobe_vfs_create, ptr @kprobe_vfs_fsync, ptr @kprobe_vfs_open, ptr @kprobe_vfs_read, ptr @kprobe_vfs_write], section "llvm.metadata"

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_read(ptr nocapture readnone %0) #0 section "kprobe/vfs_read" !dbg !34 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !95, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata ptr poison, metadata !97, metadata !DIExpression()), !dbg !100
  tail call void @llvm.dbg.value(metadata i32 0, metadata !102, metadata !DIExpression()), !dbg !107
  %2 = atomicrmw add ptr @stats, i64 1 monotonic, align 8, !dbg !109
  ret i32 0, !dbg !110
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_write(ptr nocapture readnone %0) #0 section "kprobe/vfs_write" !dbg !111 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !113, metadata !DIExpression()), !dbg !114
  call void @llvm.dbg.value(metadata ptr poison, metadata !115, metadata !DIExpression()), !dbg !118
  tail call void @llvm.dbg.value(metadata i32 1, metadata !102, metadata !DIExpression()), !dbg !120
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 1), i64 1 monotonic, align 8, !dbg !122
  ret i32 0, !dbg !123
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_fsync(ptr nocapture readnone %0) #0 section "kprobe/vfs_fsync" !dbg !124 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !126, metadata !DIExpression()), !dbg !127
  call void @llvm.dbg.value(metadata ptr poison, metadata !128, metadata !DIExpression()), !dbg !131
  tail call void @llvm.dbg.value(metadata i32 2, metadata !102, metadata !DIExpression()), !dbg !133
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 2), i64 1 monotonic, align 8, !dbg !135
  ret i32 0, !dbg !136
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_open(ptr nocapture readnone %0) #0 section "kprobe/vfs_open" !dbg !137 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !139, metadata !DIExpression()), !dbg !140
  call void @llvm.dbg.value(metadata ptr poison, metadata !141, metadata !DIExpression()), !dbg !144
  tail call void @llvm.dbg.value(metadata i32 3, metadata !102, metadata !DIExpression()), !dbg !146
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 3), i64 1 monotonic, align 8, !dbg !148
  ret i32 0, !dbg !149
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_create(ptr nocapture readnone %0) #0 section "kprobe/vfs_create" !dbg !150 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !152, metadata !DIExpression()), !dbg !153
  call void @llvm.dbg.value(metadata ptr poison, metadata !154, metadata !DIExpression()), !dbg !157
  tail call void @llvm.dbg.value(metadata i32 4, metadata !102, metadata !DIExpression()), !dbg !159
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 4), i64 1 monotonic, align 8, !dbg !161
  ret i32 0, !dbg !162
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_read(ptr nocapture readnone %0) #0 section "fentry/vfs_read" !dbg !163 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !168, metadata !DIExpression()), !dbg !169
  call void @llvm.dbg.value(metadata ptr poison, metadata !170, metadata !DIExpression()), !dbg !173
  tail call void @llvm.dbg.value(metadata i32 0, metadata !102, metadata !DIExpression()), !dbg !175
  %2 = atomicrmw add ptr @stats, i64 1 monotonic, align 8, !dbg !177
  ret i32 0, !dbg !178
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_write(ptr nocapture readnone %0) #0 section "fentry/vfs_write" !dbg !179 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !181, metadata !DIExpression()), !dbg !182
  call void @llvm.dbg.value(metadata ptr poison, metadata !183, metadata !DIExpression()), !dbg !186
  tail call void @llvm.dbg.value(metadata i32 1, metadata !102, metadata !DIExpression()), !dbg !188
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 1), i64 1 monotonic, align 8, !dbg !190
  ret i32 0, !dbg !191
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_fsync(ptr nocapture readnone %0) #0 section "fentry/vfs_fsync" !dbg !192 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !194, metadata !DIExpression()), !dbg !195
  call void @llvm.dbg.value(metadata ptr poison, metadata !196, metadata !DIExpression()), !dbg !199
  tail call void @llvm.dbg.value(metadata i32 2, metadata !102, metadata !DIExpression()), !dbg !201
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 2), i64 1 monotonic, align 8, !dbg !203
  ret i32 0, !dbg !204
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_open(ptr nocapture readnone %0) #0 section "fentry/vfs_open" !dbg !205 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !207, metadata !DIExpression()), !dbg !208
  call void @llvm.dbg.value(metadata ptr poison, metadata !209, metadata !DIExpression()), !dbg !212
  tail call void @llvm.dbg.value(metadata i32 3, metadata !102, metadata !DIExpression()), !dbg !214
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 3), i64 1 monotonic, align 8, !dbg !216
  ret i32 0, !dbg !217
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_create(ptr nocapture readnone %0) #0 section "fentry/vfs_create" !dbg !218 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !220, metadata !DIExpression()), !dbg !221
  call void @llvm.dbg.value(metadata ptr poison, metadata !222, metadata !DIExpression()), !dbg !225
  tail call void @llvm.dbg.value(metadata i32 4, metadata !102, metadata !DIExpression()), !dbg !227
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 4), i64 1 monotonic, align 8, !dbg !229
  ret i32 0, !dbg !230
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none) "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!28, !29, !30, !31, !32}
!llvm.ident = !{!33}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "stats", scope: !2, file: !3, line: 10, type: !22, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !15, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "bcc/libbpf-tools/vfsstat.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "ce19acfb17520776f7bc82b0d95b46af")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "stat_types", file: !6, line: 6, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "bcc/libbpf-tools/vfsstat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "44ced0bd604185dac7c30bfefa38c444")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14}
!9 = !DIEnumerator(name: "S_READ", value: 0)
!10 = !DIEnumerator(name: "S_WRITE", value: 1)
!11 = !DIEnumerator(name: "S_FSYNC", value: 2)
!12 = !DIEnumerator(name: "S_OPEN", value: 3)
!13 = !DIEnumerator(name: "S_CREATE", value: 4)
!14 = !DIEnumerator(name: "S_MAXSTAT", value: 5)
!15 = !{!0, !16}
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !3, line: 78, type: !18, isLocal: false, isDefinition: true)
!18 = !DICompositeType(tag: DW_TAG_array_type, baseType: !19, size: 32, elements: !20)
!19 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!20 = !{!21}
!21 = !DISubrange(count: 4)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 320, elements: !26)
!23 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !24, line: 26227, baseType: !25)
!24 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/include/vmlinux.h", directory: "", checksumkind: CSK_MD5, checksum: "3164748a8c8211744854e3e1972af8d4")
!25 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !{i32 7, !"Dwarf Version", i32 5}
!29 = !{i32 2, !"Debug Info Version", i32 3}
!30 = !{i32 1, !"wchar_size", i32 4}
!31 = !{i32 8, !"PIC Level", i32 2}
!32 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!33 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!34 = distinct !DISubprogram(name: "kprobe_vfs_read", scope: !3, file: !3, line: 19, type: !35, scopeLine: 19, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !94)
!35 = !DISubroutineType(types: !36)
!36 = !{!37, !38}
!37 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!38 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !39, size: 64)
!39 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "pt_regs", file: !24, line: 28398, size: 1344, elements: !40)
!40 = !{!41, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !74, !75, !76}
!41 = !DIDerivedType(tag: DW_TAG_member, name: "r15", scope: !39, file: !24, line: 28399, baseType: !42, size: 64)
!42 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "r14", scope: !39, file: !24, line: 28400, baseType: !42, size: 64, offset: 64)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "r13", scope: !39, file: !24, line: 28401, baseType: !42, size: 64, offset: 128)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "r12", scope: !39, file: !24, line: 28402, baseType: !42, size: 64, offset: 192)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "bp", scope: !39, file: !24, line: 28403, baseType: !42, size: 64, offset: 256)
!47 = !DIDerivedType(tag: DW_TAG_member, name: "bx", scope: !39, file: !24, line: 28404, baseType: !42, size: 64, offset: 320)
!48 = !DIDerivedType(tag: DW_TAG_member, name: "r11", scope: !39, file: !24, line: 28405, baseType: !42, size: 64, offset: 384)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "r10", scope: !39, file: !24, line: 28406, baseType: !42, size: 64, offset: 448)
!50 = !DIDerivedType(tag: DW_TAG_member, name: "r9", scope: !39, file: !24, line: 28407, baseType: !42, size: 64, offset: 512)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "r8", scope: !39, file: !24, line: 28408, baseType: !42, size: 64, offset: 576)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "ax", scope: !39, file: !24, line: 28409, baseType: !42, size: 64, offset: 640)
!53 = !DIDerivedType(tag: DW_TAG_member, name: "cx", scope: !39, file: !24, line: 28410, baseType: !42, size: 64, offset: 704)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "dx", scope: !39, file: !24, line: 28411, baseType: !42, size: 64, offset: 768)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "si", scope: !39, file: !24, line: 28412, baseType: !42, size: 64, offset: 832)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "di", scope: !39, file: !24, line: 28413, baseType: !42, size: 64, offset: 896)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "orig_ax", scope: !39, file: !24, line: 28414, baseType: !42, size: 64, offset: 960)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "ip", scope: !39, file: !24, line: 28415, baseType: !42, size: 64, offset: 1024)
!59 = !DIDerivedType(tag: DW_TAG_member, scope: !39, file: !24, line: 28416, baseType: !60, size: 64, offset: 1088)
!60 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !39, file: !24, line: 28416, size: 64, elements: !61)
!61 = !{!62, !66, !68}
!62 = !DIDerivedType(tag: DW_TAG_member, name: "cs", scope: !60, file: !24, line: 28417, baseType: !63, size: 16)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "u16", file: !24, line: 26447, baseType: !64)
!64 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !24, line: 26437, baseType: !65)
!65 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "csx", scope: !60, file: !24, line: 28418, baseType: !67, size: 64)
!67 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !24, line: 26235, baseType: !23)
!68 = !DIDerivedType(tag: DW_TAG_member, name: "fred_cs", scope: !60, file: !24, line: 28419, baseType: !69, size: 64)
!69 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "fred_cs", file: !24, line: 28375, size: 64, elements: !70)
!70 = !{!71, !72, !73}
!71 = !DIDerivedType(tag: DW_TAG_member, name: "cs", scope: !69, file: !24, line: 28376, baseType: !67, size: 16, flags: DIFlagBitField, extraData: i64 0)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "sl", scope: !69, file: !24, line: 28377, baseType: !67, size: 2, offset: 16, flags: DIFlagBitField, extraData: i64 0)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "wfe", scope: !69, file: !24, line: 28378, baseType: !67, size: 1, offset: 18, flags: DIFlagBitField, extraData: i64 0)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !39, file: !24, line: 28421, baseType: !42, size: 64, offset: 1152)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "sp", scope: !39, file: !24, line: 28422, baseType: !42, size: 64, offset: 1216)
!76 = !DIDerivedType(tag: DW_TAG_member, scope: !39, file: !24, line: 28423, baseType: !77, size: 64, offset: 1280)
!77 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !39, file: !24, line: 28423, size: 64, elements: !78)
!78 = !{!79, !80, !81}
!79 = !DIDerivedType(tag: DW_TAG_member, name: "ss", scope: !77, file: !24, line: 28424, baseType: !63, size: 16)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ssx", scope: !77, file: !24, line: 28425, baseType: !67, size: 64)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "fred_ss", scope: !77, file: !24, line: 28426, baseType: !82, size: 64)
!82 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "fred_ss", file: !24, line: 28381, size: 64, elements: !83)
!83 = !{!84, !85, !86, !87, !88, !89, !90, !91, !92, !93}
!84 = !DIDerivedType(tag: DW_TAG_member, name: "ss", scope: !82, file: !24, line: 28382, baseType: !67, size: 16, flags: DIFlagBitField, extraData: i64 0)
!85 = !DIDerivedType(tag: DW_TAG_member, name: "sti", scope: !82, file: !24, line: 28383, baseType: !67, size: 1, offset: 16, flags: DIFlagBitField, extraData: i64 0)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "swevent", scope: !82, file: !24, line: 28384, baseType: !67, size: 1, offset: 17, flags: DIFlagBitField, extraData: i64 0)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "nmi", scope: !82, file: !24, line: 28385, baseType: !67, size: 1, offset: 18, flags: DIFlagBitField, extraData: i64 0)
!88 = !DIDerivedType(tag: DW_TAG_member, name: "vector", scope: !82, file: !24, line: 28387, baseType: !67, size: 8, offset: 32, flags: DIFlagBitField, extraData: i64 0)
!89 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !82, file: !24, line: 28389, baseType: !67, size: 4, offset: 48, flags: DIFlagBitField, extraData: i64 0)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "enclave", scope: !82, file: !24, line: 28391, baseType: !67, size: 1, offset: 56, flags: DIFlagBitField, extraData: i64 0)
!91 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !82, file: !24, line: 28392, baseType: !67, size: 1, offset: 57, flags: DIFlagBitField, extraData: i64 0)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "nested", scope: !82, file: !24, line: 28393, baseType: !67, size: 1, offset: 58, flags: DIFlagBitField, extraData: i64 0)
!93 = !DIDerivedType(tag: DW_TAG_member, name: "insnlen", scope: !82, file: !24, line: 28395, baseType: !67, size: 4, offset: 60, flags: DIFlagBitField, extraData: i64 0)
!94 = !{!95}
!95 = !DILocalVariable(name: "ctx", arg: 1, scope: !34, file: !3, line: 19, type: !38)
!96 = !DILocation(line: 0, scope: !34)
!97 = !DILocalVariable(name: "ctx", arg: 1, scope: !98, file: !3, line: 19, type: !38)
!98 = distinct !DISubprogram(name: "____kprobe_vfs_read", scope: !3, file: !3, line: 19, type: !35, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !99)
!99 = !{!97}
!100 = !DILocation(line: 0, scope: !98, inlinedAt: !101)
!101 = distinct !DILocation(line: 19, column: 5, scope: !34)
!102 = !DILocalVariable(name: "key", arg: 1, scope: !103, file: !3, line: 12, type: !37)
!103 = distinct !DISubprogram(name: "inc_stats", scope: !3, file: !3, line: 12, type: !104, scopeLine: 13, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !106)
!104 = !DISubroutineType(types: !105)
!105 = !{!37, !37}
!106 = !{!102}
!107 = !DILocation(line: 0, scope: !103, inlinedAt: !108)
!108 = distinct !DILocation(line: 21, column: 9, scope: !98, inlinedAt: !101)
!109 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !108)
!110 = !DILocation(line: 19, column: 5, scope: !34)
!111 = distinct !DISubprogram(name: "kprobe_vfs_write", scope: !3, file: !3, line: 25, type: !35, scopeLine: 25, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !112)
!112 = !{!113}
!113 = !DILocalVariable(name: "ctx", arg: 1, scope: !111, file: !3, line: 25, type: !38)
!114 = !DILocation(line: 0, scope: !111)
!115 = !DILocalVariable(name: "ctx", arg: 1, scope: !116, file: !3, line: 25, type: !38)
!116 = distinct !DISubprogram(name: "____kprobe_vfs_write", scope: !3, file: !3, line: 25, type: !35, scopeLine: 26, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !117)
!117 = !{!115}
!118 = !DILocation(line: 0, scope: !116, inlinedAt: !119)
!119 = distinct !DILocation(line: 25, column: 5, scope: !111)
!120 = !DILocation(line: 0, scope: !103, inlinedAt: !121)
!121 = distinct !DILocation(line: 27, column: 9, scope: !116, inlinedAt: !119)
!122 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !121)
!123 = !DILocation(line: 25, column: 5, scope: !111)
!124 = distinct !DISubprogram(name: "kprobe_vfs_fsync", scope: !3, file: !3, line: 31, type: !35, scopeLine: 31, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !125)
!125 = !{!126}
!126 = !DILocalVariable(name: "ctx", arg: 1, scope: !124, file: !3, line: 31, type: !38)
!127 = !DILocation(line: 0, scope: !124)
!128 = !DILocalVariable(name: "ctx", arg: 1, scope: !129, file: !3, line: 31, type: !38)
!129 = distinct !DISubprogram(name: "____kprobe_vfs_fsync", scope: !3, file: !3, line: 31, type: !35, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !130)
!130 = !{!128}
!131 = !DILocation(line: 0, scope: !129, inlinedAt: !132)
!132 = distinct !DILocation(line: 31, column: 5, scope: !124)
!133 = !DILocation(line: 0, scope: !103, inlinedAt: !134)
!134 = distinct !DILocation(line: 33, column: 9, scope: !129, inlinedAt: !132)
!135 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !134)
!136 = !DILocation(line: 31, column: 5, scope: !124)
!137 = distinct !DISubprogram(name: "kprobe_vfs_open", scope: !3, file: !3, line: 37, type: !35, scopeLine: 37, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !138)
!138 = !{!139}
!139 = !DILocalVariable(name: "ctx", arg: 1, scope: !137, file: !3, line: 37, type: !38)
!140 = !DILocation(line: 0, scope: !137)
!141 = !DILocalVariable(name: "ctx", arg: 1, scope: !142, file: !3, line: 37, type: !38)
!142 = distinct !DISubprogram(name: "____kprobe_vfs_open", scope: !3, file: !3, line: 37, type: !35, scopeLine: 38, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !143)
!143 = !{!141}
!144 = !DILocation(line: 0, scope: !142, inlinedAt: !145)
!145 = distinct !DILocation(line: 37, column: 5, scope: !137)
!146 = !DILocation(line: 0, scope: !103, inlinedAt: !147)
!147 = distinct !DILocation(line: 39, column: 9, scope: !142, inlinedAt: !145)
!148 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !147)
!149 = !DILocation(line: 37, column: 5, scope: !137)
!150 = distinct !DISubprogram(name: "kprobe_vfs_create", scope: !3, file: !3, line: 43, type: !35, scopeLine: 43, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !151)
!151 = !{!152}
!152 = !DILocalVariable(name: "ctx", arg: 1, scope: !150, file: !3, line: 43, type: !38)
!153 = !DILocation(line: 0, scope: !150)
!154 = !DILocalVariable(name: "ctx", arg: 1, scope: !155, file: !3, line: 43, type: !38)
!155 = distinct !DISubprogram(name: "____kprobe_vfs_create", scope: !3, file: !3, line: 43, type: !35, scopeLine: 44, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !156)
!156 = !{!154}
!157 = !DILocation(line: 0, scope: !155, inlinedAt: !158)
!158 = distinct !DILocation(line: 43, column: 5, scope: !150)
!159 = !DILocation(line: 0, scope: !103, inlinedAt: !160)
!160 = distinct !DILocation(line: 45, column: 9, scope: !155, inlinedAt: !158)
!161 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !160)
!162 = !DILocation(line: 43, column: 5, scope: !150)
!163 = distinct !DISubprogram(name: "fentry_vfs_read", scope: !3, file: !3, line: 49, type: !164, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !167)
!164 = !DISubroutineType(types: !165)
!165 = !{!37, !166}
!166 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !25, size: 64)
!167 = !{!168}
!168 = !DILocalVariable(name: "ctx", arg: 1, scope: !163, file: !3, line: 49, type: !166)
!169 = !DILocation(line: 0, scope: !163)
!170 = !DILocalVariable(name: "ctx", arg: 1, scope: !171, file: !3, line: 49, type: !166)
!171 = distinct !DISubprogram(name: "____fentry_vfs_read", scope: !3, file: !3, line: 49, type: !164, scopeLine: 50, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !172)
!172 = !{!170}
!173 = !DILocation(line: 0, scope: !171, inlinedAt: !174)
!174 = distinct !DILocation(line: 49, column: 5, scope: !163)
!175 = !DILocation(line: 0, scope: !103, inlinedAt: !176)
!176 = distinct !DILocation(line: 51, column: 9, scope: !171, inlinedAt: !174)
!177 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !176)
!178 = !DILocation(line: 49, column: 5, scope: !163)
!179 = distinct !DISubprogram(name: "fentry_vfs_write", scope: !3, file: !3, line: 55, type: !164, scopeLine: 55, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !180)
!180 = !{!181}
!181 = !DILocalVariable(name: "ctx", arg: 1, scope: !179, file: !3, line: 55, type: !166)
!182 = !DILocation(line: 0, scope: !179)
!183 = !DILocalVariable(name: "ctx", arg: 1, scope: !184, file: !3, line: 55, type: !166)
!184 = distinct !DISubprogram(name: "____fentry_vfs_write", scope: !3, file: !3, line: 55, type: !164, scopeLine: 56, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !185)
!185 = !{!183}
!186 = !DILocation(line: 0, scope: !184, inlinedAt: !187)
!187 = distinct !DILocation(line: 55, column: 5, scope: !179)
!188 = !DILocation(line: 0, scope: !103, inlinedAt: !189)
!189 = distinct !DILocation(line: 57, column: 9, scope: !184, inlinedAt: !187)
!190 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !189)
!191 = !DILocation(line: 55, column: 5, scope: !179)
!192 = distinct !DISubprogram(name: "fentry_vfs_fsync", scope: !3, file: !3, line: 61, type: !164, scopeLine: 61, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !193)
!193 = !{!194}
!194 = !DILocalVariable(name: "ctx", arg: 1, scope: !192, file: !3, line: 61, type: !166)
!195 = !DILocation(line: 0, scope: !192)
!196 = !DILocalVariable(name: "ctx", arg: 1, scope: !197, file: !3, line: 61, type: !166)
!197 = distinct !DISubprogram(name: "____fentry_vfs_fsync", scope: !3, file: !3, line: 61, type: !164, scopeLine: 62, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !198)
!198 = !{!196}
!199 = !DILocation(line: 0, scope: !197, inlinedAt: !200)
!200 = distinct !DILocation(line: 61, column: 5, scope: !192)
!201 = !DILocation(line: 0, scope: !103, inlinedAt: !202)
!202 = distinct !DILocation(line: 63, column: 9, scope: !197, inlinedAt: !200)
!203 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !202)
!204 = !DILocation(line: 61, column: 5, scope: !192)
!205 = distinct !DISubprogram(name: "fentry_vfs_open", scope: !3, file: !3, line: 67, type: !164, scopeLine: 67, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !206)
!206 = !{!207}
!207 = !DILocalVariable(name: "ctx", arg: 1, scope: !205, file: !3, line: 67, type: !166)
!208 = !DILocation(line: 0, scope: !205)
!209 = !DILocalVariable(name: "ctx", arg: 1, scope: !210, file: !3, line: 67, type: !166)
!210 = distinct !DISubprogram(name: "____fentry_vfs_open", scope: !3, file: !3, line: 67, type: !164, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !211)
!211 = !{!209}
!212 = !DILocation(line: 0, scope: !210, inlinedAt: !213)
!213 = distinct !DILocation(line: 67, column: 5, scope: !205)
!214 = !DILocation(line: 0, scope: !103, inlinedAt: !215)
!215 = distinct !DILocation(line: 69, column: 9, scope: !210, inlinedAt: !213)
!216 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !215)
!217 = !DILocation(line: 67, column: 5, scope: !205)
!218 = distinct !DISubprogram(name: "fentry_vfs_create", scope: !3, file: !3, line: 73, type: !164, scopeLine: 73, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !219)
!219 = !{!220}
!220 = !DILocalVariable(name: "ctx", arg: 1, scope: !218, file: !3, line: 73, type: !166)
!221 = !DILocation(line: 0, scope: !218)
!222 = !DILocalVariable(name: "ctx", arg: 1, scope: !223, file: !3, line: 73, type: !166)
!223 = distinct !DISubprogram(name: "____fentry_vfs_create", scope: !3, file: !3, line: 73, type: !164, scopeLine: 74, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !224)
!224 = !{!222}
!225 = !DILocation(line: 0, scope: !223, inlinedAt: !226)
!226 = distinct !DILocation(line: 73, column: 5, scope: !218)
!227 = !DILocation(line: 0, scope: !103, inlinedAt: !228)
!228 = distinct !DILocation(line: 75, column: 9, scope: !223, inlinedAt: !226)
!229 = !DILocation(line: 14, column: 2, scope: !103, inlinedAt: !228)
!230 = !DILocation(line: 73, column: 5, scope: !218)
