; ModuleID = '/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/opensnoop.bpf.c'
source_filename = "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/opensnoop.bpf.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.anon = type { ptr, ptr, ptr, ptr }
%struct.anon.0 = type { ptr, ptr, ptr }
%struct.args_t = type { ptr, i32 }
%struct.trace_event_raw_sys_enter = type { %struct.trace_entry, i64, [6 x i64], [0 x i8] }
%struct.trace_entry = type { i16, i8, i8, i32 }
%struct.event = type { i64, i32, i32, i32, i32, [2 x i64], [16 x i8], [255 x i8] }
%struct.trace_event_raw_sys_exit = type { %struct.trace_entry, i64, i64, [0 x i8] }

@targ_pid = local_unnamed_addr constant i32 0, align 4, !dbg !0
@targ_tgid = local_unnamed_addr constant i32 0, align 4, !dbg !34
@targ_uid = local_unnamed_addr constant i32 -1, align 4, !dbg !40
@targ_failed = local_unnamed_addr constant i8 0, align 1, !dbg !43
@start = global %struct.anon zeroinitializer, section ".maps", align 8, !dbg !53
@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !48
@events = global %struct.anon.0 zeroinitializer, section ".maps", align 8, !dbg !76
@llvm.compiler.used = appending global [7 x ptr] [ptr @LICENSE, ptr @events, ptr @start, ptr @tracepoint__syscalls__sys_enter_open, ptr @tracepoint__syscalls__sys_enter_openat, ptr @tracepoint__syscalls__sys_exit_open, ptr @tracepoint__syscalls__sys_exit_openat], section "llvm.metadata"

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_enter_open(ptr nocapture noundef readonly %0) #0 section "tracepoint/syscalls/sys_enter_open" !dbg !91 {
  %2 = alloca i32, align 4, !DIAssignID !127
  call void @llvm.dbg.assign(metadata i1 undef, metadata !123, metadata !DIExpression(), metadata !127, metadata ptr %2, metadata !DIExpression()), !dbg !128
  %3 = alloca %struct.args_t, align 8, !DIAssignID !129
  call void @llvm.dbg.assign(metadata i1 undef, metadata !124, metadata !DIExpression(), metadata !129, metadata ptr %3, metadata !DIExpression()), !dbg !130
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !117, metadata !DIExpression()), !dbg !128
  %4 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !131
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !118, metadata !DIExpression()), !dbg !128
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !122, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !128
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #7, !dbg !132
  %5 = trunc i64 %4 to i32, !dbg !133
  store i32 %5, ptr %2, align 4, !dbg !134, !tbaa !135, !DIAssignID !139
  call void @llvm.dbg.assign(metadata i32 %5, metadata !123, metadata !DIExpression(), metadata !139, metadata ptr %2, metadata !DIExpression()), !dbg !128
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #7, !dbg !140
  %6 = getelementptr inbounds i8, ptr %3, i64 8, !dbg !141
  store i64 0, ptr %6, align 8, !dbg !141, !DIAssignID !142
  call void @llvm.dbg.assign(metadata i64 0, metadata !124, metadata !DIExpression(), metadata !142, metadata ptr %3, metadata !DIExpression()), !dbg !130
  call void @llvm.dbg.assign(metadata i8 0, metadata !124, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !143, metadata ptr undef, metadata !DIExpression()), !dbg !130
  %7 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, !dbg !144
  %8 = load i64, ptr %7, align 8, !dbg !145, !tbaa !146
  %9 = inttoptr i64 %8 to ptr, !dbg !148
  store ptr %9, ptr %3, align 8, !dbg !149, !tbaa !150, !DIAssignID !153
  call void @llvm.dbg.assign(metadata ptr %9, metadata !124, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !153, metadata ptr %3, metadata !DIExpression()), !dbg !130
  %10 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, i64 1, !dbg !154
  %11 = load i64, ptr %10, align 8, !dbg !154, !tbaa !146
  %12 = trunc i64 %11 to i32, !dbg !155
  %13 = getelementptr inbounds %struct.args_t, ptr %3, i64 0, i32 1, !dbg !156
  store i32 %12, ptr %13, align 8, !dbg !157, !tbaa !158, !DIAssignID !159
  call void @llvm.dbg.assign(metadata i32 %12, metadata !124, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !159, metadata ptr %13, metadata !DIExpression()), !dbg !130
  %14 = call i64 @bpf_map_update_elem(ptr noundef nonnull @start, ptr noundef nonnull %2, ptr noundef nonnull %3, i64 noundef 0) #6, !dbg !160
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #7, !dbg !161
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #7, !dbg !162
  ret i32 0, !dbg !163
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: noredzone
declare !dbg !164 i64 @bpf_get_current_pid_tgid() local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: noredzone
declare !dbg !168 i64 @bpf_map_update_elem(ptr noundef, ptr noundef, ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_enter_openat(ptr nocapture noundef readonly %0) #0 section "tracepoint/syscalls/sys_enter_openat" !dbg !174 {
  %2 = alloca i32, align 4, !DIAssignID !183
  call void @llvm.dbg.assign(metadata i1 undef, metadata !179, metadata !DIExpression(), metadata !183, metadata ptr %2, metadata !DIExpression()), !dbg !184
  %3 = alloca %struct.args_t, align 8, !DIAssignID !185
  call void @llvm.dbg.assign(metadata i1 undef, metadata !180, metadata !DIExpression(), metadata !185, metadata ptr %3, metadata !DIExpression()), !dbg !186
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !176, metadata !DIExpression()), !dbg !184
  %4 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !187
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !177, metadata !DIExpression()), !dbg !184
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !178, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !184
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #7, !dbg !188
  %5 = trunc i64 %4 to i32, !dbg !189
  store i32 %5, ptr %2, align 4, !dbg !190, !tbaa !135, !DIAssignID !191
  call void @llvm.dbg.assign(metadata i32 %5, metadata !179, metadata !DIExpression(), metadata !191, metadata ptr %2, metadata !DIExpression()), !dbg !184
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #7, !dbg !192
  %6 = getelementptr inbounds i8, ptr %3, i64 8, !dbg !193
  store i64 0, ptr %6, align 8, !dbg !193, !DIAssignID !194
  call void @llvm.dbg.assign(metadata i64 0, metadata !180, metadata !DIExpression(), metadata !194, metadata ptr %3, metadata !DIExpression()), !dbg !186
  call void @llvm.dbg.assign(metadata i8 0, metadata !180, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !195, metadata ptr undef, metadata !DIExpression()), !dbg !186
  %7 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, i64 1, !dbg !196
  %8 = load i64, ptr %7, align 8, !dbg !196, !tbaa !146
  %9 = inttoptr i64 %8 to ptr, !dbg !197
  store ptr %9, ptr %3, align 8, !dbg !198, !tbaa !150, !DIAssignID !199
  call void @llvm.dbg.assign(metadata ptr %9, metadata !180, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !199, metadata ptr %3, metadata !DIExpression()), !dbg !186
  %10 = getelementptr inbounds %struct.trace_event_raw_sys_enter, ptr %0, i64 0, i32 2, i64 2, !dbg !200
  %11 = load i64, ptr %10, align 8, !dbg !200, !tbaa !146
  %12 = trunc i64 %11 to i32, !dbg !201
  %13 = getelementptr inbounds %struct.args_t, ptr %3, i64 0, i32 1, !dbg !202
  store i32 %12, ptr %13, align 8, !dbg !203, !tbaa !158, !DIAssignID !204
  call void @llvm.dbg.assign(metadata i32 %12, metadata !180, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !204, metadata ptr %13, metadata !DIExpression()), !dbg !186
  %14 = call i64 @bpf_map_update_elem(ptr noundef nonnull @start, ptr noundef nonnull %2, ptr noundef nonnull %3, i64 noundef 0) #6, !dbg !205
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #7, !dbg !206
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #7, !dbg !207
  ret i32 0, !dbg !208
}

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_exit_open(ptr noundef %0) #0 section "tracepoint/syscalls/sys_exit_open" !dbg !209 {
  %2 = alloca %struct.event, align 8, !DIAssignID !221
  %3 = alloca [3 x i64], align 16, !DIAssignID !222
  %4 = alloca i32, align 4, !DIAssignID !223
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !220, metadata !DIExpression()), !dbg !224
  call void @llvm.dbg.assign(metadata i1 undef, metadata !225, metadata !DIExpression(), metadata !221, metadata ptr %2, metadata !DIExpression()), !dbg !257
  call void @llvm.dbg.assign(metadata i1 undef, metadata !230, metadata !DIExpression(), metadata !222, metadata ptr %3, metadata !DIExpression()), !dbg !257
  call void @llvm.dbg.assign(metadata i1 undef, metadata !236, metadata !DIExpression(), metadata !223, metadata ptr %4, metadata !DIExpression()), !dbg !257
  call void @llvm.dbg.value(metadata ptr %0, metadata !228, metadata !DIExpression()), !dbg !257
  call void @llvm.lifetime.start.p0(i64 312, ptr nonnull %2) #7, !dbg !259
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(312) %2, i8 0, i64 312, i1 false), !dbg !260, !DIAssignID !261
  call void @llvm.dbg.assign(metadata i8 0, metadata !225, metadata !DIExpression(), metadata !261, metadata ptr %2, metadata !DIExpression()), !dbg !257
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %3) #7, !dbg !262
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #7, !dbg !263
  %5 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !264
  %6 = trunc i64 %5 to i32, !dbg !264
  store i32 %6, ptr %4, align 4, !dbg !265, !tbaa !135, !DIAssignID !266
  call void @llvm.dbg.assign(metadata i32 %6, metadata !236, metadata !DIExpression(), metadata !266, metadata ptr %4, metadata !DIExpression()), !dbg !257
  %7 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !267
  call void @llvm.dbg.value(metadata ptr %7, metadata !229, metadata !DIExpression()), !dbg !257
  %8 = icmp eq ptr %7, null, !dbg !268
  br i1 %8, label %38, label %9, !dbg !270

9:                                                ; preds = %1
  %10 = getelementptr inbounds %struct.trace_event_raw_sys_exit, ptr %0, i64 0, i32 2, !dbg !271
  %11 = load i64, ptr %10, align 8, !dbg !271, !tbaa !272
  %12 = trunc i64 %11 to i32, !dbg !276
  call void @llvm.dbg.value(metadata i32 %12, metadata !235, metadata !DIExpression()), !dbg !257
  %13 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !277
  %14 = lshr i64 %13, 32, !dbg !278
  %15 = trunc i64 %14 to i32, !dbg !277
  %16 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 1, !dbg !279
  store i32 %15, ptr %16, align 8, !dbg !280, !tbaa !281, !DIAssignID !284
  call void @llvm.dbg.assign(metadata i32 %15, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !284, metadata ptr %16, metadata !DIExpression()), !dbg !257
  %17 = call i64 @bpf_get_current_uid_gid() #6, !dbg !285
  %18 = trunc i64 %17 to i32, !dbg !285
  %19 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 2, !dbg !286
  store i32 %18, ptr %19, align 4, !dbg !287, !tbaa !288, !DIAssignID !289
  call void @llvm.dbg.assign(metadata i32 %18, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !289, metadata ptr %19, metadata !DIExpression()), !dbg !257
  %20 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 6, !dbg !290
  %21 = call i64 @bpf_get_current_comm(ptr noundef nonnull %20, i32 noundef 16) #6, !dbg !291
  %22 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 7, !dbg !292
  %23 = load ptr, ptr %7, align 8, !dbg !293, !tbaa !150
  %24 = call i64 @bpf_probe_read_user_str(ptr noundef nonnull %22, i32 noundef 255, ptr noundef %23) #6, !dbg !294
  %25 = getelementptr inbounds %struct.args_t, ptr %7, i64 0, i32 1, !dbg !295
  %26 = load i32, ptr %25, align 8, !dbg !295, !tbaa !158
  %27 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 4, !dbg !296
  store i32 %26, ptr %27, align 4, !dbg !297, !tbaa !298, !DIAssignID !299
  call void @llvm.dbg.assign(metadata i32 %26, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 32), metadata !299, metadata ptr %27, metadata !DIExpression()), !dbg !257
  %28 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 3, !dbg !300
  store i32 %12, ptr %28, align 8, !dbg !301, !tbaa !302, !DIAssignID !303
  call void @llvm.dbg.assign(metadata i32 %12, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32), metadata !303, metadata ptr %28, metadata !DIExpression()), !dbg !257
  %29 = call i64 @bpf_get_stack(ptr noundef %0, ptr noundef nonnull %3, i32 noundef 24, i64 noundef 256) #6, !dbg !304
  %30 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 1, !dbg !305
  %31 = load i64, ptr %30, align 8, !dbg !305, !tbaa !146
  %32 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, !dbg !306
  store i64 %31, ptr %32, align 8, !dbg !307, !tbaa !308, !DIAssignID !309
  call void @llvm.dbg.assign(metadata i64 %31, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !309, metadata ptr %32, metadata !DIExpression()), !dbg !257
  %33 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 2, !dbg !310
  %34 = load i64, ptr %33, align 16, !dbg !310, !tbaa !146
  %35 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, i64 1, !dbg !311
  store i64 %34, ptr %35, align 8, !dbg !312, !tbaa !308, !DIAssignID !313
  call void @llvm.dbg.assign(metadata i64 %34, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64), metadata !313, metadata ptr %35, metadata !DIExpression()), !dbg !257
  %36 = call i64 @bpf_perf_event_output(ptr noundef %0, ptr noundef nonnull @events, i64 noundef 4294967295, ptr noundef nonnull %2, i64 noundef 312) #6, !dbg !314
  call void @llvm.dbg.label(metadata !237), !dbg !315
  %37 = call i64 @bpf_map_delete_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !316
  br label %38, !dbg !317

38:                                               ; preds = %1, %9
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #7, !dbg !318
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %3) #7, !dbg !318
  call void @llvm.lifetime.end.p0(i64 312, ptr nonnull %2) #7, !dbg !318
  ret i32 0, !dbg !319
}

; Function Attrs: noredzone nounwind
define noundef i32 @tracepoint__syscalls__sys_exit_openat(ptr noundef %0) #0 section "tracepoint/syscalls/sys_exit_openat" !dbg !320 {
  %2 = alloca %struct.event, align 8, !DIAssignID !323
  %3 = alloca [3 x i64], align 16, !DIAssignID !324
  %4 = alloca i32, align 4, !DIAssignID !325
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !322, metadata !DIExpression()), !dbg !326
  call void @llvm.dbg.assign(metadata i1 undef, metadata !225, metadata !DIExpression(), metadata !323, metadata ptr %2, metadata !DIExpression()), !dbg !327
  call void @llvm.dbg.assign(metadata i1 undef, metadata !230, metadata !DIExpression(), metadata !324, metadata ptr %3, metadata !DIExpression()), !dbg !327
  call void @llvm.dbg.assign(metadata i1 undef, metadata !236, metadata !DIExpression(), metadata !325, metadata ptr %4, metadata !DIExpression()), !dbg !327
  call void @llvm.dbg.value(metadata ptr %0, metadata !228, metadata !DIExpression()), !dbg !327
  call void @llvm.lifetime.start.p0(i64 312, ptr nonnull %2) #7, !dbg !329
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(312) %2, i8 0, i64 312, i1 false), !dbg !330, !DIAssignID !331
  call void @llvm.dbg.assign(metadata i8 0, metadata !225, metadata !DIExpression(), metadata !331, metadata ptr %2, metadata !DIExpression()), !dbg !327
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %3) #7, !dbg !332
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #7, !dbg !333
  %5 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !334
  %6 = trunc i64 %5 to i32, !dbg !334
  store i32 %6, ptr %4, align 4, !dbg !335, !tbaa !135, !DIAssignID !336
  call void @llvm.dbg.assign(metadata i32 %6, metadata !236, metadata !DIExpression(), metadata !336, metadata ptr %4, metadata !DIExpression()), !dbg !327
  %7 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !337
  call void @llvm.dbg.value(metadata ptr %7, metadata !229, metadata !DIExpression()), !dbg !327
  %8 = icmp eq ptr %7, null, !dbg !338
  br i1 %8, label %38, label %9, !dbg !339

9:                                                ; preds = %1
  %10 = getelementptr inbounds %struct.trace_event_raw_sys_exit, ptr %0, i64 0, i32 2, !dbg !340
  %11 = load i64, ptr %10, align 8, !dbg !340, !tbaa !272
  %12 = trunc i64 %11 to i32, !dbg !341
  call void @llvm.dbg.value(metadata i32 %12, metadata !235, metadata !DIExpression()), !dbg !327
  %13 = call i64 @bpf_get_current_pid_tgid() #6, !dbg !342
  %14 = lshr i64 %13, 32, !dbg !343
  %15 = trunc i64 %14 to i32, !dbg !342
  %16 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 1, !dbg !344
  store i32 %15, ptr %16, align 8, !dbg !345, !tbaa !281, !DIAssignID !346
  call void @llvm.dbg.assign(metadata i32 %15, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !346, metadata ptr %16, metadata !DIExpression()), !dbg !327
  %17 = call i64 @bpf_get_current_uid_gid() #6, !dbg !347
  %18 = trunc i64 %17 to i32, !dbg !347
  %19 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 2, !dbg !348
  store i32 %18, ptr %19, align 4, !dbg !349, !tbaa !288, !DIAssignID !350
  call void @llvm.dbg.assign(metadata i32 %18, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !350, metadata ptr %19, metadata !DIExpression()), !dbg !327
  %20 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 6, !dbg !351
  %21 = call i64 @bpf_get_current_comm(ptr noundef nonnull %20, i32 noundef 16) #6, !dbg !352
  %22 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 7, !dbg !353
  %23 = load ptr, ptr %7, align 8, !dbg !354, !tbaa !150
  %24 = call i64 @bpf_probe_read_user_str(ptr noundef nonnull %22, i32 noundef 255, ptr noundef %23) #6, !dbg !355
  %25 = getelementptr inbounds %struct.args_t, ptr %7, i64 0, i32 1, !dbg !356
  %26 = load i32, ptr %25, align 8, !dbg !356, !tbaa !158
  %27 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 4, !dbg !357
  store i32 %26, ptr %27, align 4, !dbg !358, !tbaa !298, !DIAssignID !359
  call void @llvm.dbg.assign(metadata i32 %26, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 32), metadata !359, metadata ptr %27, metadata !DIExpression()), !dbg !327
  %28 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 3, !dbg !360
  store i32 %12, ptr %28, align 8, !dbg !361, !tbaa !302, !DIAssignID !362
  call void @llvm.dbg.assign(metadata i32 %12, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32), metadata !362, metadata ptr %28, metadata !DIExpression()), !dbg !327
  %29 = call i64 @bpf_get_stack(ptr noundef %0, ptr noundef nonnull %3, i32 noundef 24, i64 noundef 256) #6, !dbg !363
  %30 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 1, !dbg !364
  %31 = load i64, ptr %30, align 8, !dbg !364, !tbaa !146
  %32 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, !dbg !365
  store i64 %31, ptr %32, align 8, !dbg !366, !tbaa !308, !DIAssignID !367
  call void @llvm.dbg.assign(metadata i64 %31, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !367, metadata ptr %32, metadata !DIExpression()), !dbg !327
  %33 = getelementptr inbounds [3 x i64], ptr %3, i64 0, i64 2, !dbg !368
  %34 = load i64, ptr %33, align 16, !dbg !368, !tbaa !146
  %35 = getelementptr inbounds %struct.event, ptr %2, i64 0, i32 5, i64 1, !dbg !369
  store i64 %34, ptr %35, align 8, !dbg !370, !tbaa !308, !DIAssignID !371
  call void @llvm.dbg.assign(metadata i64 %34, metadata !225, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64), metadata !371, metadata ptr %35, metadata !DIExpression()), !dbg !327
  %36 = call i64 @bpf_perf_event_output(ptr noundef %0, ptr noundef nonnull @events, i64 noundef 4294967295, ptr noundef nonnull %2, i64 noundef 312) #6, !dbg !372
  call void @llvm.dbg.label(metadata !237), !dbg !373
  %37 = call i64 @bpf_map_delete_elem(ptr noundef nonnull @start, ptr noundef nonnull %4) #6, !dbg !374
  br label %38, !dbg !375

38:                                               ; preds = %1, %9
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #7, !dbg !376
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %3) #7, !dbg !376
  call void @llvm.lifetime.end.p0(i64 312, ptr nonnull %2) #7, !dbg !376
  ret i32 0, !dbg !377
}

; Function Attrs: noredzone
declare !dbg !378 i64 @bpf_get_current_uid_gid() local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !379 ptr @bpf_map_lookup_elem(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !382 i64 @bpf_get_current_comm(ptr noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !385 i64 @bpf_probe_read_user_str(ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !388 i64 @bpf_get_stack(ptr noundef, ptr noundef, i32 noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !391 i64 @bpf_perf_event_output(ptr noundef, ptr noundef, i64 noundef, ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #4

; Function Attrs: noredzone
declare !dbg !394 i64 @bpf_map_delete_elem(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #5

attributes #0 = { noredzone nounwind "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noredzone "disable-tail-calls"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { noredzone nounwind }
attributes #7 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!85, !86, !87, !88, !89}
!llvm.ident = !{!90}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "targ_pid", scope: !2, file: !36, line: 8, type: !37, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !24, globals: !33, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/opensnoop.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "b753465233123dff2fda4277b72290a5")
!4 = !{!5, !11, !18}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 8948, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/include/vmlinux.h", directory: "", checksumkind: CSK_MD5, checksum: "3164748a8c8211744854e3e1972af8d4")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10}
!9 = !DIEnumerator(name: "false", value: 0)
!10 = !DIEnumerator(name: "true", value: 1)
!11 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 460, baseType: !7, size: 32, elements: !12)
!12 = !{!13, !14, !15, !16, !17}
!13 = !DIEnumerator(name: "BPF_F_SKIP_FIELD_MASK", value: 255)
!14 = !DIEnumerator(name: "BPF_F_USER_STACK", value: 256)
!15 = !DIEnumerator(name: "BPF_F_FAST_STACK_CMP", value: 512)
!16 = !DIEnumerator(name: "BPF_F_REUSE_STACKID", value: 1024)
!17 = !DIEnumerator(name: "BPF_F_USER_BUILD_ID", value: 2048)
!18 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 403, baseType: !19, size: 64, elements: !20)
!19 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!20 = !{!21, !22, !23}
!21 = !DIEnumerator(name: "BPF_F_INDEX_MASK", value: 4294967295, isUnsigned: true)
!22 = !DIEnumerator(name: "BPF_F_CURRENT_CPU", value: 4294967295, isUnsigned: true)
!23 = !DIEnumerator(name: "BPF_F_CTXLEN_MASK", value: 4503595332403200, isUnsigned: true)
!24 = !{!25, !28, !29, !31}
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !26, size: 64)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !27)
!27 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!28 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "u32", file: !6, line: 26605, baseType: !30)
!30 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !6, line: 26593, baseType: !7)
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "uid_t", file: !6, line: 26803, baseType: !32)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "__kernel_uid32_t", file: !6, line: 26643, baseType: !7)
!33 = !{!0, !34, !40, !43, !48, !53, !76}
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(name: "targ_tgid", scope: !2, file: !36, line: 9, type: !37, isLocal: false, isDefinition: true)
!36 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/opensnoop.bpf.c", directory: "", checksumkind: CSK_MD5, checksum: "b753465233123dff2fda4277b72290a5")
!37 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !38)
!38 = !DIDerivedType(tag: DW_TAG_typedef, name: "pid_t", file: !6, line: 26147, baseType: !39)
!39 = !DIDerivedType(tag: DW_TAG_typedef, name: "__kernel_pid_t", file: !6, line: 26081, baseType: !28)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "targ_uid", scope: !2, file: !36, line: 10, type: !42, isLocal: false, isDefinition: true)
!42 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !31)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "targ_failed", scope: !2, file: !36, line: 11, type: !45, isLocal: false, isDefinition: true)
!45 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !46)
!46 = !DIDerivedType(tag: DW_TAG_typedef, name: "bool", file: !6, line: 26049, baseType: !47)
!47 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!48 = !DIGlobalVariableExpression(var: !49, expr: !DIExpression())
!49 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !36, line: 136, type: !50, isLocal: false, isDefinition: true)
!50 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 32, elements: !51)
!51 = !{!52}
!52 = !DISubrange(count: 4)
!53 = !DIGlobalVariableExpression(var: !54, expr: !DIExpression())
!54 = distinct !DIGlobalVariable(name: "start", scope: !2, file: !36, line: 18, type: !55, isLocal: false, isDefinition: true)
!55 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !36, line: 13, size: 256, elements: !56)
!56 = !{!57, !62, !67, !69}
!57 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !55, file: !36, line: 14, baseType: !58, size: 64)
!58 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !59, size: 64)
!59 = !DICompositeType(tag: DW_TAG_array_type, baseType: !28, size: 32, elements: !60)
!60 = !{!61}
!61 = !DISubrange(count: 1)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !55, file: !36, line: 15, baseType: !63, size: 64, offset: 64)
!63 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !64, size: 64)
!64 = !DICompositeType(tag: DW_TAG_array_type, baseType: !28, size: 327680, elements: !65)
!65 = !{!66}
!66 = !DISubrange(count: 10240)
!67 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !55, file: !36, line: 16, baseType: !68, size: 64, offset: 128)
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64)
!69 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !55, file: !36, line: 17, baseType: !70, size: 64, offset: 192)
!70 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !71, size: 64)
!71 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "args_t", file: !72, line: 9, size: 128, elements: !73)
!72 = !DIFile(filename: "bcc/libbpf-tools/opensnoop.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "0103892cbc9dc772f93d372f15ef3ee6")
!73 = !{!74, !75}
!74 = !DIDerivedType(tag: DW_TAG_member, name: "fname", scope: !71, file: !72, line: 10, baseType: !25, size: 64)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !71, file: !72, line: 11, baseType: !28, size: 32, offset: 64)
!76 = !DIGlobalVariableExpression(var: !77, expr: !DIExpression())
!77 = distinct !DIGlobalVariable(name: "events", scope: !2, file: !36, line: 24, type: !78, isLocal: false, isDefinition: true)
!78 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !36, line: 20, size: 192, elements: !79)
!79 = !{!80, !83, !84}
!80 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !78, file: !36, line: 21, baseType: !81, size: 64)
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !82, size: 64)
!82 = !DICompositeType(tag: DW_TAG_array_type, baseType: !28, size: 128, elements: !51)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !78, file: !36, line: 22, baseType: !81, size: 64, offset: 64)
!84 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !78, file: !36, line: 23, baseType: !81, size: 64, offset: 128)
!85 = !{i32 7, !"Dwarf Version", i32 5}
!86 = !{i32 2, !"Debug Info Version", i32 3}
!87 = !{i32 1, !"wchar_size", i32 4}
!88 = !{i32 8, !"PIC Level", i32 2}
!89 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!90 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!91 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_enter_open", scope: !36, file: !36, line: 50, type: !92, scopeLine: 51, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !116)
!92 = !DISubroutineType(types: !93)
!93 = !{!28, !94}
!94 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !95, size: 64)
!95 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_event_raw_sys_enter", file: !6, line: 119642, size: 512, elements: !96)
!96 = !{!97, !106, !108, !112}
!97 = !DIDerivedType(tag: DW_TAG_member, name: "ent", scope: !95, file: !6, line: 119643, baseType: !98, size: 64)
!98 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_entry", file: !6, line: 45382, size: 64, elements: !99)
!99 = !{!100, !102, !104, !105}
!100 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !98, file: !6, line: 45383, baseType: !101, size: 16)
!101 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !98, file: !6, line: 45384, baseType: !103, size: 8, offset: 16)
!103 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "preempt_count", scope: !98, file: !6, line: 45385, baseType: !103, size: 8, offset: 24)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "pid", scope: !98, file: !6, line: 45386, baseType: !28, size: 32, offset: 32)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !95, file: !6, line: 119644, baseType: !107, size: 64, offset: 64)
!107 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "args", scope: !95, file: !6, line: 119645, baseType: !109, size: 384, offset: 128)
!109 = !DICompositeType(tag: DW_TAG_array_type, baseType: !19, size: 384, elements: !110)
!110 = !{!111}
!111 = !DISubrange(count: 6)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !95, file: !6, line: 119646, baseType: !113, offset: 512)
!113 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, elements: !114)
!114 = !{!115}
!115 = !DISubrange(count: 0)
!116 = !{!117, !118, !122, !123, !124}
!117 = !DILocalVariable(name: "ctx", arg: 1, scope: !91, file: !36, line: 50, type: !94)
!118 = !DILocalVariable(name: "id", scope: !91, file: !36, line: 52, type: !119)
!119 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !6, line: 26235, baseType: !120)
!120 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !6, line: 26227, baseType: !121)
!121 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!122 = !DILocalVariable(name: "tgid", scope: !91, file: !36, line: 54, type: !29)
!123 = !DILocalVariable(name: "pid", scope: !91, file: !36, line: 55, type: !29)
!124 = !DILocalVariable(name: "args", scope: !125, file: !36, line: 59, type: !71)
!125 = distinct !DILexicalBlock(scope: !126, file: !36, line: 58, column: 32)
!126 = distinct !DILexicalBlock(scope: !91, file: !36, line: 58, column: 6)
!127 = distinct !DIAssignID()
!128 = !DILocation(line: 0, scope: !91)
!129 = distinct !DIAssignID()
!130 = !DILocation(line: 0, scope: !125)
!131 = !DILocation(line: 52, column: 11, scope: !91)
!132 = !DILocation(line: 55, column: 2, scope: !91)
!133 = !DILocation(line: 55, column: 12, scope: !91)
!134 = !DILocation(line: 55, column: 6, scope: !91)
!135 = !{!136, !136, i64 0}
!136 = !{!"int", !137, i64 0}
!137 = !{!"omnipotent char", !138, i64 0}
!138 = !{!"Simple C/C++ TBAA"}
!139 = distinct !DIAssignID()
!140 = !DILocation(line: 59, column: 3, scope: !125)
!141 = !DILocation(line: 59, column: 17, scope: !125)
!142 = distinct !DIAssignID()
!143 = distinct !DIAssignID()
!144 = !DILocation(line: 60, column: 35, scope: !125)
!145 = !DILocation(line: 60, column: 30, scope: !125)
!146 = !{!147, !147, i64 0}
!147 = !{!"long", !137, i64 0}
!148 = !DILocation(line: 60, column: 16, scope: !125)
!149 = !DILocation(line: 60, column: 14, scope: !125)
!150 = !{!151, !152, i64 0}
!151 = !{!"args_t", !152, i64 0, !136, i64 8}
!152 = !{!"any pointer", !137, i64 0}
!153 = distinct !DIAssignID()
!154 = !DILocation(line: 61, column: 21, scope: !125)
!155 = !DILocation(line: 61, column: 16, scope: !125)
!156 = !DILocation(line: 61, column: 8, scope: !125)
!157 = !DILocation(line: 61, column: 14, scope: !125)
!158 = !{!151, !136, i64 8}
!159 = distinct !DIAssignID()
!160 = !DILocation(line: 62, column: 3, scope: !125)
!161 = !DILocation(line: 63, column: 2, scope: !126)
!162 = !DILocation(line: 65, column: 1, scope: !91)
!163 = !DILocation(line: 64, column: 2, scope: !91)
!164 = !DISubprogram(name: "bpf_get_current_pid_tgid", scope: !165, file: !165, line: 477, type: !166, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!165 = !DIFile(filename: "native_compat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "d60311c07fe0bcb85ac571d435aebf7a")
!166 = !DISubroutineType(types: !167)
!167 = !{!121}
!168 = !DISubprogram(name: "bpf_map_update_elem", scope: !165, file: !165, line: 459, type: !169, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!169 = !DISubroutineType(types: !170)
!170 = !{!107, !171, !172, !172, !121}
!171 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!172 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !173, size: 64)
!173 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!174 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_enter_openat", scope: !36, file: !36, line: 68, type: !92, scopeLine: 69, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !175)
!175 = !{!176, !177, !178, !179, !180}
!176 = !DILocalVariable(name: "ctx", arg: 1, scope: !174, file: !36, line: 68, type: !94)
!177 = !DILocalVariable(name: "id", scope: !174, file: !36, line: 70, type: !119)
!178 = !DILocalVariable(name: "tgid", scope: !174, file: !36, line: 72, type: !29)
!179 = !DILocalVariable(name: "pid", scope: !174, file: !36, line: 73, type: !29)
!180 = !DILocalVariable(name: "args", scope: !181, file: !36, line: 77, type: !71)
!181 = distinct !DILexicalBlock(scope: !182, file: !36, line: 76, column: 32)
!182 = distinct !DILexicalBlock(scope: !174, file: !36, line: 76, column: 6)
!183 = distinct !DIAssignID()
!184 = !DILocation(line: 0, scope: !174)
!185 = distinct !DIAssignID()
!186 = !DILocation(line: 0, scope: !181)
!187 = !DILocation(line: 70, column: 11, scope: !174)
!188 = !DILocation(line: 73, column: 2, scope: !174)
!189 = !DILocation(line: 73, column: 12, scope: !174)
!190 = !DILocation(line: 73, column: 6, scope: !174)
!191 = distinct !DIAssignID()
!192 = !DILocation(line: 77, column: 3, scope: !181)
!193 = !DILocation(line: 77, column: 17, scope: !181)
!194 = distinct !DIAssignID()
!195 = distinct !DIAssignID()
!196 = !DILocation(line: 78, column: 30, scope: !181)
!197 = !DILocation(line: 78, column: 16, scope: !181)
!198 = !DILocation(line: 78, column: 14, scope: !181)
!199 = distinct !DIAssignID()
!200 = !DILocation(line: 79, column: 21, scope: !181)
!201 = !DILocation(line: 79, column: 16, scope: !181)
!202 = !DILocation(line: 79, column: 8, scope: !181)
!203 = !DILocation(line: 79, column: 14, scope: !181)
!204 = distinct !DIAssignID()
!205 = !DILocation(line: 80, column: 3, scope: !181)
!206 = !DILocation(line: 81, column: 2, scope: !182)
!207 = !DILocation(line: 83, column: 1, scope: !174)
!208 = !DILocation(line: 82, column: 2, scope: !174)
!209 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_exit_open", scope: !36, file: !36, line: 125, type: !210, scopeLine: 126, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !219)
!210 = !DISubroutineType(types: !211)
!211 = !{!28, !212}
!212 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !213, size: 64)
!213 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_event_raw_sys_exit", file: !6, line: 119649, size: 192, elements: !214)
!214 = !{!215, !216, !217, !218}
!215 = !DIDerivedType(tag: DW_TAG_member, name: "ent", scope: !213, file: !6, line: 119650, baseType: !98, size: 64)
!216 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !213, file: !6, line: 119651, baseType: !107, size: 64, offset: 64)
!217 = !DIDerivedType(tag: DW_TAG_member, name: "ret", scope: !213, file: !6, line: 119652, baseType: !107, size: 64, offset: 128)
!218 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !213, file: !6, line: 119653, baseType: !113, offset: 192)
!219 = !{!220}
!220 = !DILocalVariable(name: "ctx", arg: 1, scope: !209, file: !36, line: 125, type: !212)
!221 = distinct !DIAssignID()
!222 = distinct !DIAssignID()
!223 = distinct !DIAssignID()
!224 = !DILocation(line: 0, scope: !209)
!225 = !DILocalVariable(name: "event", scope: !226, file: !36, line: 88, type: !238)
!226 = distinct !DISubprogram(name: "trace_exit", scope: !36, file: !36, line: 86, type: !210, scopeLine: 87, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !227)
!227 = !{!228, !225, !229, !230, !235, !236, !237}
!228 = !DILocalVariable(name: "ctx", arg: 1, scope: !226, file: !36, line: 86, type: !212)
!229 = !DILocalVariable(name: "ap", scope: !226, file: !36, line: 89, type: !70)
!230 = !DILocalVariable(name: "stack", scope: !226, file: !36, line: 90, type: !231)
!231 = !DICompositeType(tag: DW_TAG_array_type, baseType: !232, size: 192, elements: !233)
!232 = !DIDerivedType(tag: DW_TAG_typedef, name: "uintptr_t", file: !6, line: 26421, baseType: !19)
!233 = !{!234}
!234 = !DISubrange(count: 3)
!235 = !DILocalVariable(name: "ret", scope: !226, file: !36, line: 91, type: !28)
!236 = !DILocalVariable(name: "pid", scope: !226, file: !36, line: 92, type: !29)
!237 = !DILabel(scope: !226, name: "cleanup", file: !36, line: 119)
!238 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "event", file: !72, line: 14, size: 2496, elements: !239)
!239 = !{!240, !241, !242, !243, !244, !245, !249, !253}
!240 = !DIDerivedType(tag: DW_TAG_member, name: "ts", scope: !238, file: !72, line: 16, baseType: !120, size: 64)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "pid", scope: !238, file: !72, line: 17, baseType: !38, size: 32, offset: 64)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "uid", scope: !238, file: !72, line: 18, baseType: !31, size: 32, offset: 96)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "ret", scope: !238, file: !72, line: 19, baseType: !28, size: 32, offset: 128)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !238, file: !72, line: 20, baseType: !28, size: 32, offset: 160)
!245 = !DIDerivedType(tag: DW_TAG_member, name: "callers", scope: !238, file: !72, line: 21, baseType: !246, size: 128, offset: 192)
!246 = !DICompositeType(tag: DW_TAG_array_type, baseType: !120, size: 128, elements: !247)
!247 = !{!248}
!248 = !DISubrange(count: 2)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "comm", scope: !238, file: !72, line: 22, baseType: !250, size: 128, offset: 320)
!250 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 128, elements: !251)
!251 = !{!252}
!252 = !DISubrange(count: 16)
!253 = !DIDerivedType(tag: DW_TAG_member, name: "fname", scope: !238, file: !72, line: 23, baseType: !254, size: 2040, offset: 448)
!254 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 2040, elements: !255)
!255 = !{!256}
!256 = !DISubrange(count: 255)
!257 = !DILocation(line: 0, scope: !226, inlinedAt: !258)
!258 = distinct !DILocation(line: 127, column: 9, scope: !209)
!259 = !DILocation(line: 88, column: 2, scope: !226, inlinedAt: !258)
!260 = !DILocation(line: 88, column: 15, scope: !226, inlinedAt: !258)
!261 = distinct !DIAssignID()
!262 = !DILocation(line: 90, column: 2, scope: !226, inlinedAt: !258)
!263 = !DILocation(line: 92, column: 2, scope: !226, inlinedAt: !258)
!264 = !DILocation(line: 92, column: 12, scope: !226, inlinedAt: !258)
!265 = !DILocation(line: 92, column: 6, scope: !226, inlinedAt: !258)
!266 = distinct !DIAssignID()
!267 = !DILocation(line: 94, column: 7, scope: !226, inlinedAt: !258)
!268 = !DILocation(line: 95, column: 7, scope: !269, inlinedAt: !258)
!269 = distinct !DILexicalBlock(scope: !226, file: !36, line: 95, column: 6)
!270 = !DILocation(line: 95, column: 6, scope: !226, inlinedAt: !258)
!271 = !DILocation(line: 97, column: 13, scope: !226, inlinedAt: !258)
!272 = !{!273, !147, i64 16}
!273 = !{!"trace_event_raw_sys_exit", !274, i64 0, !147, i64 8, !147, i64 16, !137, i64 24}
!274 = !{!"trace_entry", !275, i64 0, !137, i64 2, !137, i64 3, !136, i64 4}
!275 = !{!"short", !137, i64 0}
!276 = !DILocation(line: 97, column: 8, scope: !226, inlinedAt: !258)
!277 = !DILocation(line: 102, column: 14, scope: !226, inlinedAt: !258)
!278 = !DILocation(line: 102, column: 41, scope: !226, inlinedAt: !258)
!279 = !DILocation(line: 102, column: 8, scope: !226, inlinedAt: !258)
!280 = !DILocation(line: 102, column: 12, scope: !226, inlinedAt: !258)
!281 = !{!282, !136, i64 8}
!282 = !{!"event", !283, i64 0, !136, i64 8, !136, i64 12, !136, i64 16, !136, i64 20, !137, i64 24, !137, i64 40, !137, i64 56}
!283 = !{!"long long", !137, i64 0}
!284 = distinct !DIAssignID()
!285 = !DILocation(line: 103, column: 14, scope: !226, inlinedAt: !258)
!286 = !DILocation(line: 103, column: 8, scope: !226, inlinedAt: !258)
!287 = !DILocation(line: 103, column: 12, scope: !226, inlinedAt: !258)
!288 = !{!282, !136, i64 12}
!289 = distinct !DIAssignID()
!290 = !DILocation(line: 104, column: 30, scope: !226, inlinedAt: !258)
!291 = !DILocation(line: 104, column: 2, scope: !226, inlinedAt: !258)
!292 = !DILocation(line: 105, column: 33, scope: !226, inlinedAt: !258)
!293 = !DILocation(line: 105, column: 65, scope: !226, inlinedAt: !258)
!294 = !DILocation(line: 105, column: 2, scope: !226, inlinedAt: !258)
!295 = !DILocation(line: 106, column: 20, scope: !226, inlinedAt: !258)
!296 = !DILocation(line: 106, column: 8, scope: !226, inlinedAt: !258)
!297 = !DILocation(line: 106, column: 14, scope: !226, inlinedAt: !258)
!298 = !{!282, !136, i64 20}
!299 = distinct !DIAssignID()
!300 = !DILocation(line: 107, column: 8, scope: !226, inlinedAt: !258)
!301 = !DILocation(line: 107, column: 12, scope: !226, inlinedAt: !258)
!302 = !{!282, !136, i64 16}
!303 = distinct !DIAssignID()
!304 = !DILocation(line: 109, column: 2, scope: !226, inlinedAt: !258)
!305 = !DILocation(line: 112, column: 21, scope: !226, inlinedAt: !258)
!306 = !DILocation(line: 112, column: 8, scope: !226, inlinedAt: !258)
!307 = !DILocation(line: 112, column: 19, scope: !226, inlinedAt: !258)
!308 = !{!283, !283, i64 0}
!309 = distinct !DIAssignID()
!310 = !DILocation(line: 113, column: 21, scope: !226, inlinedAt: !258)
!311 = !DILocation(line: 113, column: 2, scope: !226, inlinedAt: !258)
!312 = !DILocation(line: 113, column: 19, scope: !226, inlinedAt: !258)
!313 = distinct !DIAssignID()
!314 = !DILocation(line: 116, column: 2, scope: !226, inlinedAt: !258)
!315 = !DILocation(line: 119, column: 1, scope: !226, inlinedAt: !258)
!316 = !DILocation(line: 120, column: 2, scope: !226, inlinedAt: !258)
!317 = !DILocation(line: 121, column: 2, scope: !226, inlinedAt: !258)
!318 = !DILocation(line: 122, column: 1, scope: !226, inlinedAt: !258)
!319 = !DILocation(line: 127, column: 2, scope: !209)
!320 = distinct !DISubprogram(name: "tracepoint__syscalls__sys_exit_openat", scope: !36, file: !36, line: 131, type: !210, scopeLine: 132, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !321)
!321 = !{!322}
!322 = !DILocalVariable(name: "ctx", arg: 1, scope: !320, file: !36, line: 131, type: !212)
!323 = distinct !DIAssignID()
!324 = distinct !DIAssignID()
!325 = distinct !DIAssignID()
!326 = !DILocation(line: 0, scope: !320)
!327 = !DILocation(line: 0, scope: !226, inlinedAt: !328)
!328 = distinct !DILocation(line: 133, column: 9, scope: !320)
!329 = !DILocation(line: 88, column: 2, scope: !226, inlinedAt: !328)
!330 = !DILocation(line: 88, column: 15, scope: !226, inlinedAt: !328)
!331 = distinct !DIAssignID()
!332 = !DILocation(line: 90, column: 2, scope: !226, inlinedAt: !328)
!333 = !DILocation(line: 92, column: 2, scope: !226, inlinedAt: !328)
!334 = !DILocation(line: 92, column: 12, scope: !226, inlinedAt: !328)
!335 = !DILocation(line: 92, column: 6, scope: !226, inlinedAt: !328)
!336 = distinct !DIAssignID()
!337 = !DILocation(line: 94, column: 7, scope: !226, inlinedAt: !328)
!338 = !DILocation(line: 95, column: 7, scope: !269, inlinedAt: !328)
!339 = !DILocation(line: 95, column: 6, scope: !226, inlinedAt: !328)
!340 = !DILocation(line: 97, column: 13, scope: !226, inlinedAt: !328)
!341 = !DILocation(line: 97, column: 8, scope: !226, inlinedAt: !328)
!342 = !DILocation(line: 102, column: 14, scope: !226, inlinedAt: !328)
!343 = !DILocation(line: 102, column: 41, scope: !226, inlinedAt: !328)
!344 = !DILocation(line: 102, column: 8, scope: !226, inlinedAt: !328)
!345 = !DILocation(line: 102, column: 12, scope: !226, inlinedAt: !328)
!346 = distinct !DIAssignID()
!347 = !DILocation(line: 103, column: 14, scope: !226, inlinedAt: !328)
!348 = !DILocation(line: 103, column: 8, scope: !226, inlinedAt: !328)
!349 = !DILocation(line: 103, column: 12, scope: !226, inlinedAt: !328)
!350 = distinct !DIAssignID()
!351 = !DILocation(line: 104, column: 30, scope: !226, inlinedAt: !328)
!352 = !DILocation(line: 104, column: 2, scope: !226, inlinedAt: !328)
!353 = !DILocation(line: 105, column: 33, scope: !226, inlinedAt: !328)
!354 = !DILocation(line: 105, column: 65, scope: !226, inlinedAt: !328)
!355 = !DILocation(line: 105, column: 2, scope: !226, inlinedAt: !328)
!356 = !DILocation(line: 106, column: 20, scope: !226, inlinedAt: !328)
!357 = !DILocation(line: 106, column: 8, scope: !226, inlinedAt: !328)
!358 = !DILocation(line: 106, column: 14, scope: !226, inlinedAt: !328)
!359 = distinct !DIAssignID()
!360 = !DILocation(line: 107, column: 8, scope: !226, inlinedAt: !328)
!361 = !DILocation(line: 107, column: 12, scope: !226, inlinedAt: !328)
!362 = distinct !DIAssignID()
!363 = !DILocation(line: 109, column: 2, scope: !226, inlinedAt: !328)
!364 = !DILocation(line: 112, column: 21, scope: !226, inlinedAt: !328)
!365 = !DILocation(line: 112, column: 8, scope: !226, inlinedAt: !328)
!366 = !DILocation(line: 112, column: 19, scope: !226, inlinedAt: !328)
!367 = distinct !DIAssignID()
!368 = !DILocation(line: 113, column: 21, scope: !226, inlinedAt: !328)
!369 = !DILocation(line: 113, column: 2, scope: !226, inlinedAt: !328)
!370 = !DILocation(line: 113, column: 19, scope: !226, inlinedAt: !328)
!371 = distinct !DIAssignID()
!372 = !DILocation(line: 116, column: 2, scope: !226, inlinedAt: !328)
!373 = !DILocation(line: 119, column: 1, scope: !226, inlinedAt: !328)
!374 = !DILocation(line: 120, column: 2, scope: !226, inlinedAt: !328)
!375 = !DILocation(line: 121, column: 2, scope: !226, inlinedAt: !328)
!376 = !DILocation(line: 122, column: 1, scope: !226, inlinedAt: !328)
!377 = !DILocation(line: 133, column: 2, scope: !320)
!378 = !DISubprogram(name: "bpf_get_current_uid_gid", scope: !165, file: !165, line: 478, type: !166, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!379 = !DISubprogram(name: "bpf_map_lookup_elem", scope: !165, file: !165, line: 458, type: !380, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!380 = !DISubroutineType(types: !381)
!381 = !{!171, !171, !172}
!382 = !DISubprogram(name: "bpf_get_current_comm", scope: !165, file: !165, line: 483, type: !383, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!383 = !DISubroutineType(types: !384)
!384 = !{!107, !171, !7}
!385 = !DISubprogram(name: "bpf_probe_read_user_str", scope: !165, file: !165, line: 473, type: !386, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!386 = !DISubroutineType(types: !387)
!387 = !{!107, !171, !7, !172}
!388 = !DISubprogram(name: "bpf_get_stack", scope: !165, file: !165, line: 494, type: !389, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!389 = !DISubroutineType(types: !390)
!390 = !{!107, !171, !171, !7, !121}
!391 = !DISubprogram(name: "bpf_perf_event_output", scope: !165, file: !165, line: 488, type: !392, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!392 = !DISubroutineType(types: !393)
!393 = !{!107, !171, !171, !121, !171, !121}
!394 = !DISubprogram(name: "bpf_map_delete_elem", scope: !165, file: !165, line: 461, type: !395, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!395 = !DISubroutineType(types: !396)
!396 = !{!107, !171, !172}
