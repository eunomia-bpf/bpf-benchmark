; ModuleID = '/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/syscount.bpf.c'
source_filename = "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/syscount.bpf.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.anon = type { ptr, ptr, ptr, ptr }
%struct.data_t = type { i64, i64, [16 x i8] }
%struct.anon.0 = type { ptr, ptr, ptr, ptr }
%struct.anon.1 = type { ptr, ptr, ptr, ptr }
%struct.trace_event_raw_sys_exit = type { %struct.trace_entry, i64, i64, [0 x i8] }
%struct.trace_entry = type { i16, i8, i8, i32 }

@filter_cg = local_unnamed_addr constant i8 0, align 1, !dbg !0
@count_by_process = local_unnamed_addr constant i8 0, align 1, !dbg !16
@measure_latency = local_unnamed_addr constant i8 1, align 1, !dbg !22
@filter_failed = local_unnamed_addr constant i8 0, align 1, !dbg !24
@filter_errno = local_unnamed_addr constant i32 0, align 4, !dbg !26
@filter_pid = local_unnamed_addr constant i32 0, align 4, !dbg !30
@start = global %struct.anon zeroinitializer, section ".maps", align 8, !dbg !108
@sys_exit.zero = internal constant %struct.data_t zeroinitializer, align 8, !dbg !35
@data = global %struct.anon.0 zeroinitializer, section ".maps", align 8, !dbg !120
@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !86
@cgroup_map = global %struct.anon.1 zeroinitializer, section ".maps", align 8, !dbg !91
@llvm.compiler.used = appending global [6 x ptr] [ptr @LICENSE, ptr @cgroup_map, ptr @data, ptr @start, ptr @sys_enter, ptr @sys_exit], section "llvm.metadata"

; Function Attrs: noredzone nounwind
define noundef i32 @sys_enter(ptr nocapture readnone %0) #0 section "tracepoint/raw_syscalls/sys_enter" !dbg !134 {
  %2 = alloca i32, align 4, !DIAssignID !154
  call void @llvm.dbg.assign(metadata i1 undef, metadata !152, metadata !DIExpression(), metadata !154, metadata ptr %2, metadata !DIExpression()), !dbg !155
  %3 = alloca i64, align 8, !DIAssignID !156
  call void @llvm.dbg.assign(metadata i1 undef, metadata !153, metadata !DIExpression(), metadata !156, metadata ptr %3, metadata !DIExpression()), !dbg !155
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !149, metadata !DIExpression()), !dbg !155
  %4 = call i64 @bpf_get_current_pid_tgid() #5, !dbg !157
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !150, metadata !DIExpression()), !dbg !155
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !151, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !155
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #6, !dbg !158
  %5 = trunc i64 %4 to i32, !dbg !159
  store i32 %5, ptr %2, align 4, !dbg !160, !tbaa !161, !DIAssignID !165
  call void @llvm.dbg.assign(metadata i32 %5, metadata !152, metadata !DIExpression(), metadata !165, metadata ptr %2, metadata !DIExpression()), !dbg !155
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #6, !dbg !166
  %6 = call i64 @bpf_ktime_get_ns() #5, !dbg !167
  store i64 %6, ptr %3, align 8, !dbg !168, !tbaa !169, !DIAssignID !171
  call void @llvm.dbg.assign(metadata i64 %6, metadata !153, metadata !DIExpression(), metadata !171, metadata ptr %3, metadata !DIExpression()), !dbg !155
  %7 = call i64 @bpf_map_update_elem(ptr noundef nonnull @start, ptr noundef nonnull %2, ptr noundef nonnull %3, i64 noundef 0) #5, !dbg !172
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #6, !dbg !173
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #6, !dbg !173
  ret i32 0, !dbg !174
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: noredzone
declare !dbg !175 i64 @bpf_get_current_pid_tgid() local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !179 i64 @bpf_ktime_get_ns() local_unnamed_addr #2

; Function Attrs: noredzone
declare !dbg !180 i64 @bpf_map_update_elem(ptr noundef, ptr noundef, ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: noredzone nounwind
define noundef i32 @sys_exit(ptr nocapture noundef readonly %0) #0 section "tracepoint/raw_syscalls/sys_exit" !dbg !37 {
  %2 = alloca i32, align 4, !DIAssignID !186
  call void @llvm.dbg.assign(metadata i1 undef, metadata !81, metadata !DIExpression(), metadata !186, metadata ptr %2, metadata !DIExpression()), !dbg !187
  %3 = alloca i32, align 4, !DIAssignID !188
  call void @llvm.dbg.assign(metadata i1 undef, metadata !84, metadata !DIExpression(), metadata !188, metadata ptr %3, metadata !DIExpression()), !dbg !187
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !61, metadata !DIExpression()), !dbg !187
  %4 = call i64 @bpf_get_current_pid_tgid() #5, !dbg !189
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !62, metadata !DIExpression()), !dbg !187
  tail call void @llvm.dbg.value(metadata i64 %4, metadata !66, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !187
  tail call void @llvm.dbg.value(metadata i64 0, metadata !80, metadata !DIExpression()), !dbg !187
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #6, !dbg !190
  %5 = trunc i64 %4 to i32, !dbg !191
  store i32 %5, ptr %2, align 4, !dbg !192, !tbaa !161, !DIAssignID !193
  call void @llvm.dbg.assign(metadata i32 %5, metadata !81, metadata !DIExpression(), metadata !193, metadata ptr %2, metadata !DIExpression()), !dbg !187
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %3) #6, !dbg !194
  %6 = getelementptr inbounds %struct.trace_event_raw_sys_exit, ptr %0, i64 0, i32 1, !dbg !195
  %7 = load i64, ptr %6, align 8, !dbg !195, !tbaa !197
  %8 = icmp eq i64 %7, -1, !dbg !202
  br i1 %8, label %30, label %9, !dbg !203

9:                                                ; preds = %1
  %10 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @start, ptr noundef nonnull %2) #5, !dbg !204
  tail call void @llvm.dbg.value(metadata ptr %10, metadata !78, metadata !DIExpression()), !dbg !187
  %11 = icmp eq ptr %10, null, !dbg !207
  br i1 %11, label %30, label %12, !dbg !209

12:                                               ; preds = %9
  %13 = call i64 @bpf_ktime_get_ns() #5, !dbg !210
  %14 = load i64, ptr %10, align 8, !dbg !211, !tbaa !169
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %13, i64 %14), metadata !80, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !187
  %15 = load i64, ptr %6, align 8, !dbg !212, !tbaa !197
  %16 = trunc i64 %15 to i32, !dbg !213
  store i32 %16, ptr %3, align 4, !dbg !214, !tbaa !161, !DIAssignID !215
  call void @llvm.dbg.assign(metadata i32 %16, metadata !84, metadata !DIExpression(), metadata !215, metadata ptr %3, metadata !DIExpression()), !dbg !187
  call void @llvm.dbg.value(metadata ptr @data, metadata !216, metadata !DIExpression()), !dbg !226
  call void @llvm.dbg.value(metadata ptr %3, metadata !222, metadata !DIExpression()), !dbg !226
  call void @llvm.dbg.value(metadata ptr @sys_exit.zero, metadata !223, metadata !DIExpression()), !dbg !226
  %17 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @data, ptr noundef nonnull %3) #5, !dbg !228
  call void @llvm.dbg.value(metadata ptr %17, metadata !224, metadata !DIExpression()), !dbg !226
  %18 = icmp eq ptr %17, null, !dbg !229
  br i1 %18, label %19, label %24, !dbg !231

19:                                               ; preds = %12
  %20 = call i64 @bpf_map_update_elem(ptr noundef nonnull @data, ptr noundef nonnull %3, ptr noundef nonnull @sys_exit.zero, i64 noundef 1) #5, !dbg !232
  call void @llvm.dbg.value(metadata i64 %20, metadata !225, metadata !DIExpression()), !dbg !226
  switch i64 %20, label %30 [
    i64 -17, label %21
    i64 0, label %21
  ], !dbg !233

21:                                               ; preds = %19, %19
  %22 = call ptr @bpf_map_lookup_elem(ptr noundef nonnull @data, ptr noundef nonnull %3) #5, !dbg !235
  tail call void @llvm.dbg.value(metadata ptr %22, metadata !67, metadata !DIExpression()), !dbg !187
  %23 = icmp eq ptr %22, null, !dbg !236
  br i1 %23, label %30, label %24, !dbg !238

24:                                               ; preds = %12, %21
  %25 = phi ptr [ %22, %21 ], [ %17, %12 ]
  %26 = sub i64 %13, %14, !dbg !239
  tail call void @llvm.dbg.value(metadata i64 %26, metadata !80, metadata !DIExpression()), !dbg !187
  %27 = atomicrmw add ptr %25, i64 1 seq_cst, align 8, !dbg !240
  %28 = getelementptr inbounds %struct.data_t, ptr %25, i64 0, i32 1, !dbg !242
  %29 = atomicrmw add ptr %28, i64 %26 seq_cst, align 8, !dbg !244
  br label %30, !dbg !245

30:                                               ; preds = %19, %21, %24, %9, %1
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %3) #6, !dbg !246
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #6, !dbg !246
  ret i32 0, !dbg !246
}

; Function Attrs: noredzone
declare !dbg !247 ptr @bpf_map_lookup_elem(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #4

attributes #0 = { noredzone nounwind "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noredzone "disable-tail-calls"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { noredzone nounwind }
attributes #6 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!128, !129, !130, !131, !132}
!llvm.ident = !{!133}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "filter_cg", scope: !2, file: !18, line: 12, type: !19, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !15, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/syscount.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "f459ef92e357f1b8bed02aed0818160a")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 331, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/include/vmlinux.h", directory: "", checksumkind: CSK_MD5, checksum: "3164748a8c8211744854e3e1972af8d4")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14}
!9 = !DIEnumerator(name: "BPF_ANY", value: 0)
!10 = !DIEnumerator(name: "BPF_NOEXIST", value: 1)
!11 = !DIEnumerator(name: "BPF_EXIST", value: 2)
!12 = !DIEnumerator(name: "BPF_F_LOCK", value: 4)
!13 = !DIEnumerator(name: "BPF_F_CPU", value: 8)
!14 = !DIEnumerator(name: "BPF_F_ALL_CPUS", value: 16)
!15 = !{!0, !16, !22, !24, !26, !30, !35, !86, !91, !108, !120}
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "count_by_process", scope: !2, file: !18, line: 13, type: !19, isLocal: false, isDefinition: true)
!18 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/syscount.bpf.c", directory: "", checksumkind: CSK_MD5, checksum: "f459ef92e357f1b8bed02aed0818160a")
!19 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "bool", file: !6, line: 26049, baseType: !21)
!21 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(name: "measure_latency", scope: !2, file: !18, line: 14, type: !19, isLocal: false, isDefinition: true)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "filter_failed", scope: !2, file: !18, line: 15, type: !19, isLocal: false, isDefinition: true)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "filter_errno", scope: !2, file: !18, line: 16, type: !28, isLocal: false, isDefinition: true)
!28 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !29)
!29 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "filter_pid", scope: !2, file: !18, line: 17, type: !32, isLocal: false, isDefinition: true)
!32 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !33)
!33 = !DIDerivedType(tag: DW_TAG_typedef, name: "pid_t", file: !6, line: 26147, baseType: !34)
!34 = !DIDerivedType(tag: DW_TAG_typedef, name: "__kernel_pid_t", file: !6, line: 26081, baseType: !29)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "zero", scope: !37, file: !18, line: 78, type: !85, isLocal: true, isDefinition: true)
!37 = distinct !DISubprogram(name: "sys_exit", scope: !18, file: !18, line: 72, type: !38, scopeLine: 73, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !60)
!38 = !DISubroutineType(types: !39)
!39 = !{!29, !40}
!40 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!41 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_event_raw_sys_exit", file: !6, line: 119649, size: 192, elements: !42)
!42 = !{!43, !52, !54, !55}
!43 = !DIDerivedType(tag: DW_TAG_member, name: "ent", scope: !41, file: !6, line: 119650, baseType: !44, size: 64)
!44 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_entry", file: !6, line: 45382, size: 64, elements: !45)
!45 = !{!46, !48, !50, !51}
!46 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !44, file: !6, line: 45383, baseType: !47, size: 16)
!47 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!48 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !44, file: !6, line: 45384, baseType: !49, size: 8, offset: 16)
!49 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!50 = !DIDerivedType(tag: DW_TAG_member, name: "preempt_count", scope: !44, file: !6, line: 45385, baseType: !49, size: 8, offset: 24)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "pid", scope: !44, file: !6, line: 45386, baseType: !29, size: 32, offset: 32)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !41, file: !6, line: 119651, baseType: !53, size: 64, offset: 64)
!53 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "ret", scope: !41, file: !6, line: 119652, baseType: !53, size: 64, offset: 128)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !41, file: !6, line: 119653, baseType: !56, offset: 192)
!56 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, elements: !58)
!57 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!58 = !{!59}
!59 = !DISubrange(count: 0)
!60 = !{!61, !62, !66, !67, !78, !80, !81, !84}
!61 = !DILocalVariable(name: "args", arg: 1, scope: !37, file: !18, line: 72, type: !40)
!62 = !DILocalVariable(name: "id", scope: !37, file: !18, line: 77, type: !63)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !6, line: 26235, baseType: !64)
!64 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !6, line: 26227, baseType: !65)
!65 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!66 = !DILocalVariable(name: "pid", scope: !37, file: !18, line: 79, type: !33)
!67 = !DILocalVariable(name: "val", scope: !37, file: !18, line: 80, type: !68)
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !69, size: 64)
!69 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "data_t", file: !70, line: 10, size: 256, elements: !71)
!70 = !DIFile(filename: "bcc/libbpf-tools/syscount.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "f75968e9b1e134317b1e1bc4fe0c9b08")
!71 = !{!72, !73, !74}
!72 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !69, file: !70, line: 11, baseType: !64, size: 64)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "total_ns", scope: !69, file: !70, line: 12, baseType: !64, size: 64, offset: 64)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "comm", scope: !69, file: !70, line: 13, baseType: !75, size: 128, offset: 128)
!75 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 128, elements: !76)
!76 = !{!77}
!77 = !DISubrange(count: 16)
!78 = !DILocalVariable(name: "start_ts", scope: !37, file: !18, line: 81, type: !79)
!79 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !63, size: 64)
!80 = !DILocalVariable(name: "lat", scope: !37, file: !18, line: 81, type: !63)
!81 = !DILocalVariable(name: "tid", scope: !37, file: !18, line: 82, type: !82)
!82 = !DIDerivedType(tag: DW_TAG_typedef, name: "u32", file: !6, line: 26605, baseType: !83)
!83 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !6, line: 26593, baseType: !7)
!84 = !DILocalVariable(name: "key", scope: !37, file: !18, line: 83, type: !82)
!85 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !69)
!86 = !DIGlobalVariableExpression(var: !87, expr: !DIExpression())
!87 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !18, line: 115, type: !88, isLocal: false, isDefinition: true)
!88 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 32, elements: !89)
!89 = !{!90}
!90 = !DISubrange(count: 4)
!91 = !DIGlobalVariableExpression(var: !92, expr: !DIExpression())
!92 = distinct !DIGlobalVariable(name: "cgroup_map", scope: !2, file: !18, line: 24, type: !93, isLocal: false, isDefinition: true)
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !18, line: 19, size: 256, elements: !94)
!94 = !{!95, !100, !102, !103}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !93, file: !18, line: 20, baseType: !96, size: 64)
!96 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !97, size: 64)
!97 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 256, elements: !98)
!98 = !{!99}
!99 = !DISubrange(count: 8)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !93, file: !18, line: 21, baseType: !101, size: 64, offset: 64)
!101 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !82, size: 64)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !93, file: !18, line: 22, baseType: !101, size: 64, offset: 128)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !93, file: !18, line: 23, baseType: !104, size: 64, offset: 192)
!104 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !105, size: 64)
!105 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !106)
!106 = !{!107}
!107 = !DISubrange(count: 1)
!108 = !DIGlobalVariableExpression(var: !109, expr: !DIExpression())
!109 = distinct !DIGlobalVariable(name: "start", scope: !2, file: !18, line: 31, type: !110, isLocal: false, isDefinition: true)
!110 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !18, line: 26, size: 256, elements: !111)
!111 = !{!112, !113, !118, !119}
!112 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !110, file: !18, line: 27, baseType: !104, size: 64)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !110, file: !18, line: 28, baseType: !114, size: 64, offset: 64)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !115, size: 64)
!115 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 262144, elements: !116)
!116 = !{!117}
!117 = !DISubrange(count: 8192)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !110, file: !18, line: 29, baseType: !101, size: 64, offset: 128)
!119 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !110, file: !18, line: 30, baseType: !79, size: 64, offset: 192)
!120 = !DIGlobalVariableExpression(var: !121, expr: !DIExpression())
!121 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !18, line: 38, type: !122, isLocal: false, isDefinition: true)
!122 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !18, line: 33, size: 256, elements: !123)
!123 = !{!124, !125, !126, !127}
!124 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !122, file: !18, line: 34, baseType: !104, size: 64)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !122, file: !18, line: 35, baseType: !114, size: 64, offset: 64)
!126 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !122, file: !18, line: 36, baseType: !101, size: 64, offset: 128)
!127 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !122, file: !18, line: 37, baseType: !68, size: 64, offset: 192)
!128 = !{i32 7, !"Dwarf Version", i32 5}
!129 = !{i32 2, !"Debug Info Version", i32 3}
!130 = !{i32 1, !"wchar_size", i32 4}
!131 = !{i32 8, !"PIC Level", i32 2}
!132 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!133 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!134 = distinct !DISubprogram(name: "sys_enter", scope: !18, file: !18, line: 53, type: !135, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !148)
!135 = !DISubroutineType(types: !136)
!136 = !{!29, !137}
!137 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !138, size: 64)
!138 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "trace_event_raw_sys_enter", file: !6, line: 119642, size: 512, elements: !139)
!139 = !{!140, !141, !142, !147}
!140 = !DIDerivedType(tag: DW_TAG_member, name: "ent", scope: !138, file: !6, line: 119643, baseType: !44, size: 64)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !138, file: !6, line: 119644, baseType: !53, size: 64, offset: 64)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "args", scope: !138, file: !6, line: 119645, baseType: !143, size: 384, offset: 128)
!143 = !DICompositeType(tag: DW_TAG_array_type, baseType: !144, size: 384, elements: !145)
!144 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!145 = !{!146}
!146 = !DISubrange(count: 6)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "__data", scope: !138, file: !6, line: 119646, baseType: !56, offset: 512)
!148 = !{!149, !150, !151, !152, !153}
!149 = !DILocalVariable(name: "args", arg: 1, scope: !134, file: !18, line: 53, type: !137)
!150 = !DILocalVariable(name: "id", scope: !134, file: !18, line: 55, type: !63)
!151 = !DILocalVariable(name: "pid", scope: !134, file: !18, line: 56, type: !33)
!152 = !DILocalVariable(name: "tid", scope: !134, file: !18, line: 57, type: !82)
!153 = !DILocalVariable(name: "ts", scope: !134, file: !18, line: 58, type: !63)
!154 = distinct !DIAssignID()
!155 = !DILocation(line: 0, scope: !134)
!156 = distinct !DIAssignID()
!157 = !DILocation(line: 55, column: 11, scope: !134)
!158 = !DILocation(line: 57, column: 2, scope: !134)
!159 = !DILocation(line: 57, column: 12, scope: !134)
!160 = !DILocation(line: 57, column: 6, scope: !134)
!161 = !{!162, !162, i64 0}
!162 = !{!"int", !163, i64 0}
!163 = !{!"omnipotent char", !164, i64 0}
!164 = !{!"Simple C/C++ TBAA"}
!165 = distinct !DIAssignID()
!166 = !DILocation(line: 58, column: 2, scope: !134)
!167 = !DILocation(line: 66, column: 7, scope: !134)
!168 = !DILocation(line: 66, column: 5, scope: !134)
!169 = !{!170, !170, i64 0}
!170 = !{!"long long", !163, i64 0}
!171 = distinct !DIAssignID()
!172 = !DILocation(line: 67, column: 2, scope: !134)
!173 = !DILocation(line: 69, column: 1, scope: !134)
!174 = !DILocation(line: 68, column: 2, scope: !134)
!175 = !DISubprogram(name: "bpf_get_current_pid_tgid", scope: !176, file: !176, line: 477, type: !177, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!176 = !DIFile(filename: "native_compat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "d60311c07fe0bcb85ac571d435aebf7a")
!177 = !DISubroutineType(types: !178)
!178 = !{!65}
!179 = !DISubprogram(name: "bpf_ktime_get_ns", scope: !176, file: !176, line: 479, type: !177, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!180 = !DISubprogram(name: "bpf_map_update_elem", scope: !176, file: !176, line: 459, type: !181, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!181 = !DISubroutineType(types: !182)
!182 = !{!53, !183, !184, !184, !65}
!183 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!184 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !185, size: 64)
!185 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!186 = distinct !DIAssignID()
!187 = !DILocation(line: 0, scope: !37)
!188 = distinct !DIAssignID()
!189 = !DILocation(line: 77, column: 11, scope: !37)
!190 = !DILocation(line: 82, column: 2, scope: !37)
!191 = !DILocation(line: 82, column: 12, scope: !37)
!192 = !DILocation(line: 82, column: 6, scope: !37)
!193 = distinct !DIAssignID()
!194 = !DILocation(line: 83, column: 2, scope: !37)
!195 = !DILocation(line: 86, column: 12, scope: !196)
!196 = distinct !DILexicalBlock(scope: !37, file: !18, line: 86, column: 6)
!197 = !{!198, !201, i64 8}
!198 = !{!"trace_event_raw_sys_exit", !199, i64 0, !201, i64 8, !201, i64 16, !163, i64 24}
!199 = !{!"trace_entry", !200, i64 0, !163, i64 2, !163, i64 3, !162, i64 4}
!200 = !{!"short", !163, i64 0}
!201 = !{!"long", !163, i64 0}
!202 = !DILocation(line: 86, column: 15, scope: !196)
!203 = !DILocation(line: 86, column: 6, scope: !37)
!204 = !DILocation(line: 97, column: 14, scope: !205)
!205 = distinct !DILexicalBlock(scope: !206, file: !18, line: 96, column: 23)
!206 = distinct !DILexicalBlock(scope: !37, file: !18, line: 96, column: 6)
!207 = !DILocation(line: 98, column: 8, scope: !208)
!208 = distinct !DILexicalBlock(scope: !205, file: !18, line: 98, column: 7)
!209 = !DILocation(line: 98, column: 7, scope: !205)
!210 = !DILocation(line: 100, column: 9, scope: !205)
!211 = !DILocation(line: 100, column: 30, scope: !205)
!212 = !DILocation(line: 103, column: 41, scope: !37)
!213 = !DILocation(line: 103, column: 8, scope: !37)
!214 = !DILocation(line: 103, column: 6, scope: !37)
!215 = distinct !DIAssignID()
!216 = !DILocalVariable(name: "map", arg: 1, scope: !217, file: !218, line: 10, type: !183)
!217 = distinct !DISubprogram(name: "bpf_map_lookup_or_try_init", scope: !218, file: !218, line: 10, type: !219, scopeLine: 11, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !221)
!218 = !DIFile(filename: "bcc/libbpf-tools/maps.bpf.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "0261855390593d88d05096bfbc69061b")
!219 = !DISubroutineType(types: !220)
!220 = !{!183, !183, !184, !184}
!221 = !{!216, !222, !223, !224, !225}
!222 = !DILocalVariable(name: "key", arg: 2, scope: !217, file: !218, line: 10, type: !184)
!223 = !DILocalVariable(name: "init", arg: 3, scope: !217, file: !218, line: 10, type: !184)
!224 = !DILocalVariable(name: "val", scope: !217, file: !218, line: 12, type: !183)
!225 = !DILocalVariable(name: "err", scope: !217, file: !218, line: 13, type: !53)
!226 = !DILocation(line: 0, scope: !217, inlinedAt: !227)
!227 = distinct !DILocation(line: 104, column: 8, scope: !37)
!228 = !DILocation(line: 15, column: 8, scope: !217, inlinedAt: !227)
!229 = !DILocation(line: 16, column: 6, scope: !230, inlinedAt: !227)
!230 = distinct !DILexicalBlock(scope: !217, file: !218, line: 16, column: 6)
!231 = !DILocation(line: 16, column: 6, scope: !217, inlinedAt: !227)
!232 = !DILocation(line: 19, column: 8, scope: !217, inlinedAt: !227)
!233 = !DILocation(line: 20, column: 10, scope: !234, inlinedAt: !227)
!234 = distinct !DILexicalBlock(scope: !217, file: !218, line: 20, column: 6)
!235 = !DILocation(line: 23, column: 9, scope: !217, inlinedAt: !227)
!236 = !DILocation(line: 105, column: 6, scope: !237)
!237 = distinct !DILexicalBlock(scope: !37, file: !18, line: 105, column: 6)
!238 = !DILocation(line: 105, column: 6, scope: !37)
!239 = !DILocation(line: 100, column: 28, scope: !205)
!240 = !DILocation(line: 106, column: 3, scope: !241)
!241 = distinct !DILexicalBlock(scope: !237, file: !18, line: 105, column: 11)
!242 = !DILocation(line: 110, column: 31, scope: !243)
!243 = distinct !DILexicalBlock(scope: !241, file: !18, line: 109, column: 7)
!244 = !DILocation(line: 110, column: 4, scope: !243)
!245 = !DILocation(line: 111, column: 2, scope: !241)
!246 = !DILocation(line: 113, column: 1, scope: !37)
!247 = !DISubprogram(name: "bpf_map_lookup_elem", scope: !176, file: !176, line: 458, type: !248, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!248 = !DISubroutineType(types: !249)
!249 = !{!183, !183, !184}
