; ModuleID = '/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/vfsstat.bpf.c'
source_filename = "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/vfsstat.bpf.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@stats = global [5 x i64] zeroinitializer, align 16, !dbg !0
@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !16
@llvm.compiler.used = appending global [11 x ptr] [ptr @LICENSE, ptr @fentry_vfs_create, ptr @fentry_vfs_fsync, ptr @fentry_vfs_open, ptr @fentry_vfs_read, ptr @fentry_vfs_write, ptr @kprobe_vfs_create, ptr @kprobe_vfs_fsync, ptr @kprobe_vfs_open, ptr @kprobe_vfs_read, ptr @kprobe_vfs_write], section "llvm.metadata"

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_read(ptr nocapture readnone %0) #0 section "kprobe/vfs_read" !dbg !35 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !96, metadata !DIExpression()), !dbg !97
  call void @llvm.dbg.value(metadata ptr poison, metadata !98, metadata !DIExpression()), !dbg !101
  tail call void @llvm.dbg.value(metadata i32 0, metadata !103, metadata !DIExpression()), !dbg !108
  %2 = atomicrmw add ptr @stats, i64 1 monotonic, align 8, !dbg !110
  ret i32 0, !dbg !111
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_write(ptr nocapture readnone %0) #0 section "kprobe/vfs_write" !dbg !112 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !114, metadata !DIExpression()), !dbg !115
  call void @llvm.dbg.value(metadata ptr poison, metadata !116, metadata !DIExpression()), !dbg !119
  tail call void @llvm.dbg.value(metadata i32 1, metadata !103, metadata !DIExpression()), !dbg !121
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 1), i64 1 monotonic, align 8, !dbg !123
  ret i32 0, !dbg !124
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_fsync(ptr nocapture readnone %0) #0 section "kprobe/vfs_fsync" !dbg !125 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !127, metadata !DIExpression()), !dbg !128
  call void @llvm.dbg.value(metadata ptr poison, metadata !129, metadata !DIExpression()), !dbg !132
  tail call void @llvm.dbg.value(metadata i32 2, metadata !103, metadata !DIExpression()), !dbg !134
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 2), i64 1 monotonic, align 8, !dbg !136
  ret i32 0, !dbg !137
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_open(ptr nocapture readnone %0) #0 section "kprobe/vfs_open" !dbg !138 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !140, metadata !DIExpression()), !dbg !141
  call void @llvm.dbg.value(metadata ptr poison, metadata !142, metadata !DIExpression()), !dbg !145
  tail call void @llvm.dbg.value(metadata i32 3, metadata !103, metadata !DIExpression()), !dbg !147
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 3), i64 1 monotonic, align 8, !dbg !149
  ret i32 0, !dbg !150
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_create(ptr nocapture readnone %0) #0 section "kprobe/vfs_create" !dbg !151 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !153, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata ptr poison, metadata !155, metadata !DIExpression()), !dbg !158
  tail call void @llvm.dbg.value(metadata i32 4, metadata !103, metadata !DIExpression()), !dbg !160
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 4), i64 1 monotonic, align 8, !dbg !162
  ret i32 0, !dbg !163
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_read(ptr nocapture readnone %0) #0 section "fentry/vfs_read" !dbg !164 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !169, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata ptr poison, metadata !171, metadata !DIExpression()), !dbg !174
  tail call void @llvm.dbg.value(metadata i32 0, metadata !103, metadata !DIExpression()), !dbg !176
  %2 = atomicrmw add ptr @stats, i64 1 monotonic, align 8, !dbg !178
  ret i32 0, !dbg !179
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_write(ptr nocapture readnone %0) #0 section "fentry/vfs_write" !dbg !180 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !182, metadata !DIExpression()), !dbg !183
  call void @llvm.dbg.value(metadata ptr poison, metadata !184, metadata !DIExpression()), !dbg !187
  tail call void @llvm.dbg.value(metadata i32 1, metadata !103, metadata !DIExpression()), !dbg !189
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 1), i64 1 monotonic, align 8, !dbg !191
  ret i32 0, !dbg !192
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_fsync(ptr nocapture readnone %0) #0 section "fentry/vfs_fsync" !dbg !193 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !195, metadata !DIExpression()), !dbg !196
  call void @llvm.dbg.value(metadata ptr poison, metadata !197, metadata !DIExpression()), !dbg !200
  tail call void @llvm.dbg.value(metadata i32 2, metadata !103, metadata !DIExpression()), !dbg !202
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 2), i64 1 monotonic, align 8, !dbg !204
  ret i32 0, !dbg !205
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_open(ptr nocapture readnone %0) #0 section "fentry/vfs_open" !dbg !206 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !208, metadata !DIExpression()), !dbg !209
  call void @llvm.dbg.value(metadata ptr poison, metadata !210, metadata !DIExpression()), !dbg !213
  tail call void @llvm.dbg.value(metadata i32 3, metadata !103, metadata !DIExpression()), !dbg !215
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 3), i64 1 monotonic, align 8, !dbg !217
  ret i32 0, !dbg !218
}

; Function Attrs: mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_create(ptr nocapture readnone %0) #0 section "fentry/vfs_create" !dbg !219 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !221, metadata !DIExpression()), !dbg !222
  call void @llvm.dbg.value(metadata ptr poison, metadata !223, metadata !DIExpression()), !dbg !226
  tail call void @llvm.dbg.value(metadata i32 4, metadata !103, metadata !DIExpression()), !dbg !228
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 4), i64 1 monotonic, align 8, !dbg !230
  ret i32 0, !dbg !231
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { mustprogress nofree norecurse noredzone nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none) "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!29, !30, !31, !32, !33}
!llvm.ident = !{!34}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "stats", scope: !2, file: !18, line: 10, type: !23, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !15, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/vfsstat.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "ce19acfb17520776f7bc82b0d95b46af")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "stat_types", file: !6, line: 6, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "bcc/libbpf-tools/vfsstat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "44ced0bd604185dac7c30bfefa38c444")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14}
!9 = !DIEnumerator(name: "S_READ", value: 0)
!10 = !DIEnumerator(name: "S_WRITE", value: 1)
!11 = !DIEnumerator(name: "S_FSYNC", value: 2)
!12 = !DIEnumerator(name: "S_OPEN", value: 3)
!13 = !DIEnumerator(name: "S_CREATE", value: 4)
!14 = !DIEnumerator(name: "S_MAXSTAT", value: 5)
!15 = !{!0, !16}
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !18, line: 78, type: !19, isLocal: false, isDefinition: true)
!18 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/constant-profile/native-source/vfsstat.bpf.c", directory: "", checksumkind: CSK_MD5, checksum: "ce19acfb17520776f7bc82b0d95b46af")
!19 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 32, elements: !21)
!20 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!21 = !{!22}
!22 = !DISubrange(count: 4)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !24, size: 320, elements: !27)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !25, line: 26227, baseType: !26)
!25 = !DIFile(filename: "/var/tmp/kprog-tmp/C/bcc-frozen-config-set/include/vmlinux.h", directory: "", checksumkind: CSK_MD5, checksum: "3164748a8c8211744854e3e1972af8d4")
!26 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!27 = !{!28}
!28 = !DISubrange(count: 5)
!29 = !{i32 7, !"Dwarf Version", i32 5}
!30 = !{i32 2, !"Debug Info Version", i32 3}
!31 = !{i32 1, !"wchar_size", i32 4}
!32 = !{i32 8, !"PIC Level", i32 2}
!33 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!34 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!35 = distinct !DISubprogram(name: "kprobe_vfs_read", scope: !18, file: !18, line: 19, type: !36, scopeLine: 19, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !95)
!36 = !DISubroutineType(types: !37)
!37 = !{!38, !39}
!38 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 64)
!40 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "pt_regs", file: !25, line: 28398, size: 1344, elements: !41)
!41 = !{!42, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !75, !76, !77}
!42 = !DIDerivedType(tag: DW_TAG_member, name: "r15", scope: !40, file: !25, line: 28399, baseType: !43, size: 64)
!43 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "r14", scope: !40, file: !25, line: 28400, baseType: !43, size: 64, offset: 64)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "r13", scope: !40, file: !25, line: 28401, baseType: !43, size: 64, offset: 128)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "r12", scope: !40, file: !25, line: 28402, baseType: !43, size: 64, offset: 192)
!47 = !DIDerivedType(tag: DW_TAG_member, name: "bp", scope: !40, file: !25, line: 28403, baseType: !43, size: 64, offset: 256)
!48 = !DIDerivedType(tag: DW_TAG_member, name: "bx", scope: !40, file: !25, line: 28404, baseType: !43, size: 64, offset: 320)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "r11", scope: !40, file: !25, line: 28405, baseType: !43, size: 64, offset: 384)
!50 = !DIDerivedType(tag: DW_TAG_member, name: "r10", scope: !40, file: !25, line: 28406, baseType: !43, size: 64, offset: 448)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "r9", scope: !40, file: !25, line: 28407, baseType: !43, size: 64, offset: 512)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "r8", scope: !40, file: !25, line: 28408, baseType: !43, size: 64, offset: 576)
!53 = !DIDerivedType(tag: DW_TAG_member, name: "ax", scope: !40, file: !25, line: 28409, baseType: !43, size: 64, offset: 640)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "cx", scope: !40, file: !25, line: 28410, baseType: !43, size: 64, offset: 704)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "dx", scope: !40, file: !25, line: 28411, baseType: !43, size: 64, offset: 768)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "si", scope: !40, file: !25, line: 28412, baseType: !43, size: 64, offset: 832)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "di", scope: !40, file: !25, line: 28413, baseType: !43, size: 64, offset: 896)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "orig_ax", scope: !40, file: !25, line: 28414, baseType: !43, size: 64, offset: 960)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "ip", scope: !40, file: !25, line: 28415, baseType: !43, size: 64, offset: 1024)
!60 = !DIDerivedType(tag: DW_TAG_member, scope: !40, file: !25, line: 28416, baseType: !61, size: 64, offset: 1088)
!61 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !40, file: !25, line: 28416, size: 64, elements: !62)
!62 = !{!63, !67, !69}
!63 = !DIDerivedType(tag: DW_TAG_member, name: "cs", scope: !61, file: !25, line: 28417, baseType: !64, size: 16)
!64 = !DIDerivedType(tag: DW_TAG_typedef, name: "u16", file: !25, line: 26447, baseType: !65)
!65 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !25, line: 26437, baseType: !66)
!66 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!67 = !DIDerivedType(tag: DW_TAG_member, name: "csx", scope: !61, file: !25, line: 28418, baseType: !68, size: 64)
!68 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !25, line: 26235, baseType: !24)
!69 = !DIDerivedType(tag: DW_TAG_member, name: "fred_cs", scope: !61, file: !25, line: 28419, baseType: !70, size: 64)
!70 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "fred_cs", file: !25, line: 28375, size: 64, elements: !71)
!71 = !{!72, !73, !74}
!72 = !DIDerivedType(tag: DW_TAG_member, name: "cs", scope: !70, file: !25, line: 28376, baseType: !68, size: 16, flags: DIFlagBitField, extraData: i64 0)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "sl", scope: !70, file: !25, line: 28377, baseType: !68, size: 2, offset: 16, flags: DIFlagBitField, extraData: i64 0)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "wfe", scope: !70, file: !25, line: 28378, baseType: !68, size: 1, offset: 18, flags: DIFlagBitField, extraData: i64 0)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !40, file: !25, line: 28421, baseType: !43, size: 64, offset: 1152)
!76 = !DIDerivedType(tag: DW_TAG_member, name: "sp", scope: !40, file: !25, line: 28422, baseType: !43, size: 64, offset: 1216)
!77 = !DIDerivedType(tag: DW_TAG_member, scope: !40, file: !25, line: 28423, baseType: !78, size: 64, offset: 1280)
!78 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !40, file: !25, line: 28423, size: 64, elements: !79)
!79 = !{!80, !81, !82}
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ss", scope: !78, file: !25, line: 28424, baseType: !64, size: 16)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "ssx", scope: !78, file: !25, line: 28425, baseType: !68, size: 64)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "fred_ss", scope: !78, file: !25, line: 28426, baseType: !83, size: 64)
!83 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "fred_ss", file: !25, line: 28381, size: 64, elements: !84)
!84 = !{!85, !86, !87, !88, !89, !90, !91, !92, !93, !94}
!85 = !DIDerivedType(tag: DW_TAG_member, name: "ss", scope: !83, file: !25, line: 28382, baseType: !68, size: 16, flags: DIFlagBitField, extraData: i64 0)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "sti", scope: !83, file: !25, line: 28383, baseType: !68, size: 1, offset: 16, flags: DIFlagBitField, extraData: i64 0)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "swevent", scope: !83, file: !25, line: 28384, baseType: !68, size: 1, offset: 17, flags: DIFlagBitField, extraData: i64 0)
!88 = !DIDerivedType(tag: DW_TAG_member, name: "nmi", scope: !83, file: !25, line: 28385, baseType: !68, size: 1, offset: 18, flags: DIFlagBitField, extraData: i64 0)
!89 = !DIDerivedType(tag: DW_TAG_member, name: "vector", scope: !83, file: !25, line: 28387, baseType: !68, size: 8, offset: 32, flags: DIFlagBitField, extraData: i64 0)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !83, file: !25, line: 28389, baseType: !68, size: 4, offset: 48, flags: DIFlagBitField, extraData: i64 0)
!91 = !DIDerivedType(tag: DW_TAG_member, name: "enclave", scope: !83, file: !25, line: 28391, baseType: !68, size: 1, offset: 56, flags: DIFlagBitField, extraData: i64 0)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "l", scope: !83, file: !25, line: 28392, baseType: !68, size: 1, offset: 57, flags: DIFlagBitField, extraData: i64 0)
!93 = !DIDerivedType(tag: DW_TAG_member, name: "nested", scope: !83, file: !25, line: 28393, baseType: !68, size: 1, offset: 58, flags: DIFlagBitField, extraData: i64 0)
!94 = !DIDerivedType(tag: DW_TAG_member, name: "insnlen", scope: !83, file: !25, line: 28395, baseType: !68, size: 4, offset: 60, flags: DIFlagBitField, extraData: i64 0)
!95 = !{!96}
!96 = !DILocalVariable(name: "ctx", arg: 1, scope: !35, file: !18, line: 19, type: !39)
!97 = !DILocation(line: 0, scope: !35)
!98 = !DILocalVariable(name: "ctx", arg: 1, scope: !99, file: !18, line: 19, type: !39)
!99 = distinct !DISubprogram(name: "____kprobe_vfs_read", scope: !18, file: !18, line: 19, type: !36, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !100)
!100 = !{!98}
!101 = !DILocation(line: 0, scope: !99, inlinedAt: !102)
!102 = distinct !DILocation(line: 19, column: 5, scope: !35)
!103 = !DILocalVariable(name: "key", arg: 1, scope: !104, file: !18, line: 12, type: !38)
!104 = distinct !DISubprogram(name: "inc_stats", scope: !18, file: !18, line: 12, type: !105, scopeLine: 13, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !107)
!105 = !DISubroutineType(types: !106)
!106 = !{!38, !38}
!107 = !{!103}
!108 = !DILocation(line: 0, scope: !104, inlinedAt: !109)
!109 = distinct !DILocation(line: 21, column: 9, scope: !99, inlinedAt: !102)
!110 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !109)
!111 = !DILocation(line: 19, column: 5, scope: !35)
!112 = distinct !DISubprogram(name: "kprobe_vfs_write", scope: !18, file: !18, line: 25, type: !36, scopeLine: 25, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !113)
!113 = !{!114}
!114 = !DILocalVariable(name: "ctx", arg: 1, scope: !112, file: !18, line: 25, type: !39)
!115 = !DILocation(line: 0, scope: !112)
!116 = !DILocalVariable(name: "ctx", arg: 1, scope: !117, file: !18, line: 25, type: !39)
!117 = distinct !DISubprogram(name: "____kprobe_vfs_write", scope: !18, file: !18, line: 25, type: !36, scopeLine: 26, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !118)
!118 = !{!116}
!119 = !DILocation(line: 0, scope: !117, inlinedAt: !120)
!120 = distinct !DILocation(line: 25, column: 5, scope: !112)
!121 = !DILocation(line: 0, scope: !104, inlinedAt: !122)
!122 = distinct !DILocation(line: 27, column: 9, scope: !117, inlinedAt: !120)
!123 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !122)
!124 = !DILocation(line: 25, column: 5, scope: !112)
!125 = distinct !DISubprogram(name: "kprobe_vfs_fsync", scope: !18, file: !18, line: 31, type: !36, scopeLine: 31, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !126)
!126 = !{!127}
!127 = !DILocalVariable(name: "ctx", arg: 1, scope: !125, file: !18, line: 31, type: !39)
!128 = !DILocation(line: 0, scope: !125)
!129 = !DILocalVariable(name: "ctx", arg: 1, scope: !130, file: !18, line: 31, type: !39)
!130 = distinct !DISubprogram(name: "____kprobe_vfs_fsync", scope: !18, file: !18, line: 31, type: !36, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !131)
!131 = !{!129}
!132 = !DILocation(line: 0, scope: !130, inlinedAt: !133)
!133 = distinct !DILocation(line: 31, column: 5, scope: !125)
!134 = !DILocation(line: 0, scope: !104, inlinedAt: !135)
!135 = distinct !DILocation(line: 33, column: 9, scope: !130, inlinedAt: !133)
!136 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !135)
!137 = !DILocation(line: 31, column: 5, scope: !125)
!138 = distinct !DISubprogram(name: "kprobe_vfs_open", scope: !18, file: !18, line: 37, type: !36, scopeLine: 37, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !139)
!139 = !{!140}
!140 = !DILocalVariable(name: "ctx", arg: 1, scope: !138, file: !18, line: 37, type: !39)
!141 = !DILocation(line: 0, scope: !138)
!142 = !DILocalVariable(name: "ctx", arg: 1, scope: !143, file: !18, line: 37, type: !39)
!143 = distinct !DISubprogram(name: "____kprobe_vfs_open", scope: !18, file: !18, line: 37, type: !36, scopeLine: 38, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !144)
!144 = !{!142}
!145 = !DILocation(line: 0, scope: !143, inlinedAt: !146)
!146 = distinct !DILocation(line: 37, column: 5, scope: !138)
!147 = !DILocation(line: 0, scope: !104, inlinedAt: !148)
!148 = distinct !DILocation(line: 39, column: 9, scope: !143, inlinedAt: !146)
!149 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !148)
!150 = !DILocation(line: 37, column: 5, scope: !138)
!151 = distinct !DISubprogram(name: "kprobe_vfs_create", scope: !18, file: !18, line: 43, type: !36, scopeLine: 43, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !152)
!152 = !{!153}
!153 = !DILocalVariable(name: "ctx", arg: 1, scope: !151, file: !18, line: 43, type: !39)
!154 = !DILocation(line: 0, scope: !151)
!155 = !DILocalVariable(name: "ctx", arg: 1, scope: !156, file: !18, line: 43, type: !39)
!156 = distinct !DISubprogram(name: "____kprobe_vfs_create", scope: !18, file: !18, line: 43, type: !36, scopeLine: 44, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !157)
!157 = !{!155}
!158 = !DILocation(line: 0, scope: !156, inlinedAt: !159)
!159 = distinct !DILocation(line: 43, column: 5, scope: !151)
!160 = !DILocation(line: 0, scope: !104, inlinedAt: !161)
!161 = distinct !DILocation(line: 45, column: 9, scope: !156, inlinedAt: !159)
!162 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !161)
!163 = !DILocation(line: 43, column: 5, scope: !151)
!164 = distinct !DISubprogram(name: "fentry_vfs_read", scope: !18, file: !18, line: 49, type: !165, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !168)
!165 = !DISubroutineType(types: !166)
!166 = !{!38, !167}
!167 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !26, size: 64)
!168 = !{!169}
!169 = !DILocalVariable(name: "ctx", arg: 1, scope: !164, file: !18, line: 49, type: !167)
!170 = !DILocation(line: 0, scope: !164)
!171 = !DILocalVariable(name: "ctx", arg: 1, scope: !172, file: !18, line: 49, type: !167)
!172 = distinct !DISubprogram(name: "____fentry_vfs_read", scope: !18, file: !18, line: 49, type: !165, scopeLine: 50, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !173)
!173 = !{!171}
!174 = !DILocation(line: 0, scope: !172, inlinedAt: !175)
!175 = distinct !DILocation(line: 49, column: 5, scope: !164)
!176 = !DILocation(line: 0, scope: !104, inlinedAt: !177)
!177 = distinct !DILocation(line: 51, column: 9, scope: !172, inlinedAt: !175)
!178 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !177)
!179 = !DILocation(line: 49, column: 5, scope: !164)
!180 = distinct !DISubprogram(name: "fentry_vfs_write", scope: !18, file: !18, line: 55, type: !165, scopeLine: 55, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !181)
!181 = !{!182}
!182 = !DILocalVariable(name: "ctx", arg: 1, scope: !180, file: !18, line: 55, type: !167)
!183 = !DILocation(line: 0, scope: !180)
!184 = !DILocalVariable(name: "ctx", arg: 1, scope: !185, file: !18, line: 55, type: !167)
!185 = distinct !DISubprogram(name: "____fentry_vfs_write", scope: !18, file: !18, line: 55, type: !165, scopeLine: 56, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !186)
!186 = !{!184}
!187 = !DILocation(line: 0, scope: !185, inlinedAt: !188)
!188 = distinct !DILocation(line: 55, column: 5, scope: !180)
!189 = !DILocation(line: 0, scope: !104, inlinedAt: !190)
!190 = distinct !DILocation(line: 57, column: 9, scope: !185, inlinedAt: !188)
!191 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !190)
!192 = !DILocation(line: 55, column: 5, scope: !180)
!193 = distinct !DISubprogram(name: "fentry_vfs_fsync", scope: !18, file: !18, line: 61, type: !165, scopeLine: 61, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !194)
!194 = !{!195}
!195 = !DILocalVariable(name: "ctx", arg: 1, scope: !193, file: !18, line: 61, type: !167)
!196 = !DILocation(line: 0, scope: !193)
!197 = !DILocalVariable(name: "ctx", arg: 1, scope: !198, file: !18, line: 61, type: !167)
!198 = distinct !DISubprogram(name: "____fentry_vfs_fsync", scope: !18, file: !18, line: 61, type: !165, scopeLine: 62, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !199)
!199 = !{!197}
!200 = !DILocation(line: 0, scope: !198, inlinedAt: !201)
!201 = distinct !DILocation(line: 61, column: 5, scope: !193)
!202 = !DILocation(line: 0, scope: !104, inlinedAt: !203)
!203 = distinct !DILocation(line: 63, column: 9, scope: !198, inlinedAt: !201)
!204 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !203)
!205 = !DILocation(line: 61, column: 5, scope: !193)
!206 = distinct !DISubprogram(name: "fentry_vfs_open", scope: !18, file: !18, line: 67, type: !165, scopeLine: 67, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !207)
!207 = !{!208}
!208 = !DILocalVariable(name: "ctx", arg: 1, scope: !206, file: !18, line: 67, type: !167)
!209 = !DILocation(line: 0, scope: !206)
!210 = !DILocalVariable(name: "ctx", arg: 1, scope: !211, file: !18, line: 67, type: !167)
!211 = distinct !DISubprogram(name: "____fentry_vfs_open", scope: !18, file: !18, line: 67, type: !165, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !212)
!212 = !{!210}
!213 = !DILocation(line: 0, scope: !211, inlinedAt: !214)
!214 = distinct !DILocation(line: 67, column: 5, scope: !206)
!215 = !DILocation(line: 0, scope: !104, inlinedAt: !216)
!216 = distinct !DILocation(line: 69, column: 9, scope: !211, inlinedAt: !214)
!217 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !216)
!218 = !DILocation(line: 67, column: 5, scope: !206)
!219 = distinct !DISubprogram(name: "fentry_vfs_create", scope: !18, file: !18, line: 73, type: !165, scopeLine: 73, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !220)
!220 = !{!221}
!221 = !DILocalVariable(name: "ctx", arg: 1, scope: !219, file: !18, line: 73, type: !167)
!222 = !DILocation(line: 0, scope: !219)
!223 = !DILocalVariable(name: "ctx", arg: 1, scope: !224, file: !18, line: 73, type: !167)
!224 = distinct !DISubprogram(name: "____fentry_vfs_create", scope: !18, file: !18, line: 73, type: !165, scopeLine: 74, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !225)
!225 = !{!223}
!226 = !DILocation(line: 0, scope: !224, inlinedAt: !227)
!227 = distinct !DILocation(line: 73, column: 5, scope: !219)
!228 = !DILocation(line: 0, scope: !104, inlinedAt: !229)
!229 = distinct !DILocation(line: 75, column: 9, scope: !224, inlinedAt: !227)
!230 = !DILocation(line: 14, column: 2, scope: !104, inlinedAt: !229)
!231 = !DILocation(line: 73, column: 5, scope: !219)
