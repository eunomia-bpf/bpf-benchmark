from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,shlex,sys,re,difflib,hashlib,tarfile,os,traceback
from elftools.elf.elffile import ELFFile
G=Path(__file__).resolve().parent;P=G.parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');N=Path('/var/tmp/kprog-tmp/C/native-constant-division');O=R/'corpus/results/kprog_app_coverage_20261109/bcc-frozen-config-set/constant-profile';commands=[]
def run(args,log,cwd=R):
 commands.append(dict(args=[str(x)for x in args],log=log,cwd=str(cwd)));(G/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with(G/log).open('w')as f:p=subprocess.run([str(x)for x in args],cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 (G/(log+'.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('native_compile')
 bindings=json.loads((P/'bindings.json').read_text());log=(N/'control-native.log').read_text().replace('\\\n',' ');rows=[];patches=[]
 for name,values in bindings.items():
  src=P/'source/vendor/bpf/bcc/libbpf-tools'/(name+'.bpf.c');before=src.read_text();lines=[]
  for line in before.splitlines(True):
   for field,value in values.items():
    if line.startswith('const volatile ')and re.search(r'\b'+field+r'\b',line):line=line.split('=',1)[0].replace('const volatile ','const ',1).rstrip()+' = '+str(value)+';\n'
   lines.append(line)
  after=''.join(lines);out=G/'native-source'/(name+'.bpf.c');out.parent.mkdir(exist_ok=True);out.write_text(after);patches.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original/'+name+'.bpf.c',tofile='native-compiler-profile/'+name+'.bpf.c')))
  target=G/'candidate/bcc';target.mkdir(parents=True,exist_ok=True);obj=target/(name+'.native.o');command=shlex.split(next(l for l in log.splitlines()if l.startswith('"clang-18"')and name+'.bpf.c'in l));command[1:1]=['-I'+str(P/'include')];command=[('-fpass-plugin='+str(N/'candidate.so'))if a.startswith('-fpass-plugin=')else a for a in command];command[command.index('-o')+1]=str(obj);command[-1]=str(out);run(command,name+'-native.log',R/'vendor/bpf')
  ir=command[:];ir[ir.index('-o')+1]=str(G/(name+'.ll'));ir+=['-S','-emit-llvm'];run(ir,name+'-ir.log',R/'vendor/bpf')
  with obj.open('rb')as f:
   e=ELFFile(f);sections=[dict(name=s.name,bytes=s['sh_size'],sha256=hashlib.sha256(s.data()).hexdigest())for s in e.iter_sections()if s['sh_flags']&4 and s['sh_size']]
  dis=subprocess.check_output(['llvm-objdump-18','-dr','--no-show-raw-insn',str(obj)],text=True);(G/(name+'.disassembly.txt')).write_text(dis);ins=[l for l in dis.splitlines()if re.match(r'^\s*[0-9a-f]+:\s+\S',l)];rows.append(dict(tool=name,native_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),sections=sections,executable_bytes=sum(s['bytes']for s in sections),instructions=len(ins),division_instructions=[l.strip()for l in ins if re.search(r'\t(?:i?div)[bwlq]?\s',l)]))
 (G/'native-projection.patch').write_text(''.join(patches));(G/'objects.json').write_text(json.dumps(rows,indent=2)+'\n');target=G/'candidate/bcc';run(['python3',R/'vendor/bpf/write_native_manifest.py','--app','bcc','--llvm-nm','llvm-nm-18','--output',target/'manifest.json',*[v for obj in sorted(target.glob('*.native.o'))for v in ['--object',obj]]],'manifest.log')
 result=dict(parent_producer='7ccdcff49e9cc87e553d1ad3ad00fc3be0ed7831',constant_division_pass='68b47d23849a633b705fbe573ad84bd5516148b7',bindings=bindings,objects=rows,source='Original captured C; native compiler input freezes34 stable scalar declarations before its existing early division pass/O3',dynamic_read_retained='capable.my_pid keeps original volatile declaration and startup-selected value',kernel=json.loads((P/'inputs.json').read_text())['target_vmlinux_sha256'],native_executions=0);O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# BCC stable configuration before native division lowering\n\nThe actual complete-set B compiler receipt83eaec613 has24compiled/1generation diagnostic per arm: runqlat sched_switch reaches signed IDIV emitted by the existing early division pass. This candidate supplies the same34 captured fixed fields to the native frontend before that pass, through private const-initialized declarations. Original upstream/JIT C and workload retain their bytes. The existing defined-constant divisor pass68b47d238 can therefore preserve compile-time positive denominators for LLVM arithmetic lowering, while variable/zero/signed-1 divisions keep its existing guarded route. Capable my_pid retains its original volatile declaration.\n\nAll eight native objects and the complete manifest remain present. Full native compiler input projection, field bindings, IR, source hashes and actual P disassembly are retained. This is pre-submission P compilation from stable configuration; original runtime/helper/kernel same-copy emission retain their definitions. Actual service-input B compilation and stock verifier/application work follow separately. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tar:
  for path in G.iterdir():
   if path.name not in ['controller.log','controller.pid','status.json','publication.json']:tar.add(path,arcname=path.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Compile stable BCC configuration before native division lowering',G/'publication.json');save('native_finished',commit=commit,objects=rows)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' native frontend stable-config specialization before existing early division pass68b47d238. Original34bindings targetBTF/source/workload stay captured; only native compiler input declares their fixed values as const, capable.my_pid stays volatile. Complete8objects/manifests retained. Previous IR-after-pass profile83ea has24/25B compiles per arm, frontier signed IDIV in runqlat sched_switch; actual successor B generation follows. Native runtime admission additions0.\n')
except BaseException as error:save('requires_continuation',error=str(error),traceback=traceback.format_exc());raise
