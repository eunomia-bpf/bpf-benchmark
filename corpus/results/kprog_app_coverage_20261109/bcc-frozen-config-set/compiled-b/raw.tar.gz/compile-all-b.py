from pathlib import Path
import json,sys,subprocess,tarfile,io,hashlib,traceback
from elftools.elf.elffile import ELFFile
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');K=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/bcc-katran-smap-recovery');sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
objects={}
for obj in(G/'candidate/bcc').glob('*.native.o'):
 with obj.open('rb')as f:
  for symbol in ELFFile(f).get_section_by_name('.symtab').iter_symbols():
   if symbol['st_info']['type']=='STT_FUNC'and symbol['st_shndx']!='SHN_UNDEF':objects[symbol.name]=obj.name
archive=K/json.loads((K/'summary.json').read_text())['archive'];inputs=[];rows=[]
with tarfile.open(archive)as tar:
 ledger=[json.loads(l)for l in tar.extractfile('corpus/requests/requests.jsonl').read().splitlines()]
 for record in ledger:
  name=Path(record.get('artifact_archive',record.get('failure_archive'))).name
  with tarfile.open(fileobj=io.BytesIO(tar.extractfile('corpus/requests/'+name).read()))as request:
   entry=request.extractfile('request/kernel.entry').read().decode().strip()
   if entry not in objects:continue
   target=G/'actual-inputs'/str(record['request_id']);target.mkdir(parents=True,exist_ok=True)
   for n in ['kernel.native.o','kernel.entry','generation.metadata.json','kernel.facts.json','kernel.metadata.json']:(target/n).write_bytes(request.extractfile('request/'+n).read())
   inputs.append(dict(request_id=record['request_id'],entry=entry,object=objects[entry],archive=str(archive),member='corpus/requests/'+name,canonical_native_sha256=record['native_sha256']))
(G/'actual-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
for label in ['control','candidate']:
 for item in inputs:
  destination=G/'generated-v2'/label/str(item['request_id']);destination.parent.mkdir(parents=True,exist_ok=True);metadata=json.loads((G/'actual-inputs'/str(item['request_id'])/'generation.metadata.json').read_text());obj=G/label/'bcc'/item['object'];row=dict(label=label,**item,native_sha256=hashlib.sha256(obj.read_bytes()).hexdigest())
  try:
   row['result']=specialize(obj.read_bytes(),item['entry'],metadata,destination,R/'kprog/x86/native_lab/native_link/target/release/native-link');row['status']='compiled'
  except BaseException as error:row.update(status='diagnostic',error=str(error),traceback=traceback.format_exc())
  rows.append(row);(G/'compiled-b.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({k:row.get(k)for k in ['label','request_id','entry','status','error']}),flush=True)
