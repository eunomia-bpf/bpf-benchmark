from pathlib import Path
import json,sys,subprocess
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
rows=[]
for item in json.loads((G/'actual-inputs.json').read_text()):
 d=Path(item['path']);out=G/'generated'/str(item['request_id']);out.parent.mkdir(parents=True,exist_ok=True);row=dict(item)
 try:
  row['result']=specialize((d/'kernel.native.o').read_bytes(),item['entry'],json.loads((d/'generation.metadata.json').read_text()),out,Path('/var/tmp/kprog-tmp/C/tail-helper-reaching-frame/native-link'));row['status']='compiled'
  text=subprocess.check_output(['llvm-objdump-18','-d',str(out/'trusted_x86.bpf.o')],text=True);(out/'B.disassembly').write_text(text);row['fault_stores']=text.count('*(u64 *)(r0 + 0x0) = r0')
 except BaseException as e:row.update(status='diagnostic',error=str(e))
 rows.append(row);(G/'compiled.json').write_text(json.dumps(rows,indent=2)+'\n');print(item['entry'],row['status'],row.get('fault_stores'),row.get('error'),flush=True)
