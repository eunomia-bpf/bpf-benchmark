from pathlib import Path
import subprocess,json,os,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');commands=[]
try:
 (G/'status.json').write_text(json.dumps(dict(state='host_cpu_oracle'))+'\n')
 for compiler in ['gcc','clang-18']:
  cmd=[compiler,'-O2','-g','-mno-red-zone','-fsanitize=undefined','-fno-sanitize-recover=undefined','-I'+str(R/'kprog/formal'),'-I'+str(R/'kprog/formal/oracles'),'-I'+str(R/'vendor/libbpf/src'),str(G/'host.c'),'-o',str(G/(compiler+'-host'))];commands.append(cmd)
  with(G/(compiler+'-build.log')).open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*cmd],stdout=f,stderr=subprocess.STDOUT)
  (G/(compiler+'-build.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
  with(G/(compiler+'-run.log')).open('w')as f:p=subprocess.run([str(G/(compiler+'-host'))],stdout=f,stderr=subprocess.STDOUT)
  (G/(compiler+'-run.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
 (G/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(G/'status.json').write_text(json.dumps(dict(state='host_finished',compilers=['gcc','clang-18']),indent=2)+'\n')
except BaseException as error:(G/'status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(error),traceback=traceback.format_exc()),indent=2)+'\n');raise
