from pathlib import Path
import sys,json,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
rows=[]
for item in json.loads((G/'actual-inputs.json').read_text()):
 source=G/'actual-inputs'/str(item['request']);metadata=json.loads((source/'generation.metadata.json').read_text());out=G/'generated-final'/str(item['request']);row=dict(item)
 try:row.update(status='compiled',result=specialize((source/'kernel.native.o').read_bytes(),item['entry'],metadata,out,R/'kprog/x86/native_lab/native_link/target/release/native-link'))
 except BaseException as error:row.update(status='diagnostic',error=str(error),traceback=traceback.format_exc())
 rows.append(row);(G/'compiled-b.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
