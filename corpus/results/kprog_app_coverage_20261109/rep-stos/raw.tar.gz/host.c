#define X86_SIM_ENABLE_STACK
#define __always_inline inline
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef unsigned long long __u64;
typedef signed char __s8;
typedef short __s16;
typedef int __s32;
typedef signed long long __s64;
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include "/workspaces/repository/kprog/formal/oracles/x86_no_helpers_host.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#define FMASK 0x8d5ULL
static __u8 cpu_mem[8192],sim_mem[8192];
static unsigned long cases;
static unsigned flag_bits(unsigned bits) {
    return ((bits&1)?1:0)|((bits&2)?4:0)|((bits&4)?16:0)|
           ((bits&8)?64:0)|((bits&16)?128:0)|((bits&32)?2048:0);
}
#define CPU_STOS(SUFFIX) __asm__ volatile( \
 "pushfq; popq %%r11; andq $-2262, %%r11; orq %[flags], %%r11; " \
 "pushq %%r11; popfq; cld; rep stos" SUFFIX "; pushfq; popq %[out]" \
 : "+D"(dst), "+c"(count), "+a"(value), [out]"=r"(out_flags) \
 : [flags]"r"((__u64)flags) : "r11", "cc", "memory")
static int check(unsigned width,__u64 n,unsigned offset,__u64 seed,unsigned flags) {
    __u8 *dst=cpu_mem+offset; __u64 count=n,value=seed,out_flags;
    memset(cpu_mem,0xa5,sizeof(cpu_mem));memset(sim_mem,0xa5,sizeof(sim_mem));
    switch(width) {case 1:CPU_STOS("b");break;case 2:CPU_STOS("w");break;
                  case 4:CPU_STOS("l");break;default:CPU_STOS("q");break;}
    if(count||value!=seed||dst!=cpu_mem+offset+n*width||
       (out_flags&FMASK)!=flags){puts("CPU control mismatch");return 1;}
    X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();
    memset((void *)&__x86_stack_mem,0,sizeof(__x86_stack_mem));
    for(unsigned i=0;i<16;i++) X86_SIM_L_WRITE_REG_WIDTH(i,0x123400+i,X86_WIDTH_64);
    X86_SIM_L_WRITE_REG_WIDTH(X86_RSP,0,X86_WIDTH_64);
    X86_SIM_L_WRITE_REG_WIDTH(X86_RAX,seed,X86_WIDTH_64);
    X86_SIM_L_WRITE_REG_WIDTH(X86_RCX,n,X86_WIDTH_64);
    X86_SIM_L_WRITE_REG_PTR_TAG(X86_RDI,sim_mem+offset,X86_SIM_TAG_ABI);
    __x86_cf=!!(flags&1);__x86_pf=!!(flags&4);__x86_af=!!(flags&16);
    __x86_zf=!!(flags&64);__x86_sf=!!(flags&128);__x86_of=!!(flags&2048);
    __u64 regs[16];__u8 tags[16];
    for(unsigned i=0;i<16;i++){regs[i]=X86_SIM_L_READ_REG(i);tags[i]=X86_SIM_L_REG_TAG(i);}
    X86_SIM_L_EXEC_REP_STOS(width);
    for(unsigned i=0;i<16;i++) {
       __u64 expected=i==X86_RCX?0:i==X86_RDI?regs[i]+n*width:regs[i];
       __u8 tag=i==X86_RCX?X86_SIM_TAG_SCALAR:tags[i];
       if(X86_SIM_L_READ_REG(i)!=expected||X86_SIM_L_REG_TAG(i)!=tag){
          printf("register mismatch w%u n%llu reg%u got%llx expected%llx\n",width,n,i,X86_SIM_L_READ_REG(i),expected);return 1;}
    }
    unsigned final=__x86_cf|(__x86_pf<<2)|(__x86_af<<4)|(__x86_zf<<6)|(__x86_sf<<7)|(__x86_of<<11);
    if(final!=flags||memcmp(cpu_mem,sim_mem,sizeof(cpu_mem))){printf("state mismatch w%u n%llu off%u flags%x/%x\n",width,n,offset,final,flags);return 1;}
    ++cases;return 0;
}
int main(void) {
 __u64 ns[]={0,1,2,3,7,8,15,16,31,32,63,64,65,127,128,255,256};
 __u64 vals[]={0,1,~0ULL,0x8000000000000000ULL,0x1122334455667788ULL,0xaa55aa55aa55aa55ULL};
 for(unsigned width=1;width<=8;width*=2)for(unsigned c=0;c<sizeof(ns)/sizeof(*ns);c++)
 for(unsigned off=0;off<8;off++)for(unsigned v=0;v<sizeof(vals)/sizeof(*vals);v++)
 for(unsigned f=0;f<64;f++)if(check(width,ns[c],off,vals[v],flag_bits(f)))return 1;
 printf("REP STOS CPU/model full-state: PASS %lu cases\n",cases);return 0;
}
