from pathlib import Path
import importlib.util,sys,re,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/x86/micro-prog'))
spec=importlib.util.spec_from_file_location('rep_stos_generator',G/'source/kprog/x86/micro-prog/generate_micro_sim_proofs.py');gen=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gen;spec.loader.exec_module(gen)
rows=[];expected=['X86_WIDTH_8','X86_WIDTH_16','X86_WIDTH_32','X86_WIDTH_64']
for line in(G/'forms.disassembly').read_text().splitlines():
 if 'rep stos'not in line:continue
 raw=line.split('\t')[-1].strip();ops=raw[len('rep '):].split(',');ins=gen.NativeInsn(0,raw,'rep',tuple(x.strip()for x in ops));lines=[]
 try:gen.append_step(lines,ins);row=dict(raw=raw,status='emitted',lines=lines)
 except ValueError as error:row=dict(raw=raw,status='legacy_generation_form',error=str(error))
 rows.append(row)
for row,width in zip(rows[:4],expected):
 if row['status']!='emitted'or'X86_SIM_L_EXEC_REP_STOS('+width+');'not in row['lines'][-1]:raise RuntimeError('machine-decoder width mismatch: '+repr(row))
if rows[-1]['status']!='legacy_generation_form':raise RuntimeError('Address-size32 selector crossed the modeled64-bit form')
(G/'decoder.json').write_text(json.dumps(rows,indent=2)+'\n');print('REP STOS machine forms:4 emitted widths,1 prior-mode generation outcome')
