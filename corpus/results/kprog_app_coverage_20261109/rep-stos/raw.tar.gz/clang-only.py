from pathlib import Path
import subprocess,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
cmd=['clang-18','-O2','-g','-mno-red-zone','-fsanitize=undefined','-fno-sanitize-recover=undefined','-fno-sanitize-link-runtime','-I'+str(R/'kprog/formal'),'-I'+str(R/'kprog/formal/oracles'),'-I'+str(R/'vendor/libbpf/src'),str(G/'host.c'),'-lubsan','-o',str(G/'clang-18-host')]
with(G/'clang-18-build.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*cmd],stdout=f,stderr=subprocess.STDOUT)
(G/'clang-18-build.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
with(G/'clang-18-run.log').open('w')as f:p=subprocess.run([str(G/'clang-18-host')],stdout=f,stderr=subprocess.STDOUT)
(G/'clang-18-run.exit').write_text(str(p.returncode)+'\n');p.check_returncode();(G/'clang-command.json').write_text(json.dumps(cmd,indent=2)+'\n');(G/'status.json').write_text(json.dumps(dict(state='host_finished',gcc_cases=208896,clang_cases=208896,runtime='Existing GCC libubsan supplies Clang sanitizer ABI'),indent=2)+'\n')
