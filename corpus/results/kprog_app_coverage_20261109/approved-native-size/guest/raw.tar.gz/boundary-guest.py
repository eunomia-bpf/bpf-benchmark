from pathlib import Path
import subprocess,fcntl,struct,os,json,errno,hashlib,traceback,ctypes
E=Path(__file__).resolve().parent;O=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/bcc-katran-constant-division/safety-control/approved-copy-boundary.json');rows=[]
result=dict(module_sha256=hashlib.sha256((E/'bpf_x86_native_lab.ko').read_bytes()).hexdigest(),cases=rows,source_commit='c2b96d6c313fb7bf7e6df48caffa8df694b40b05',native_executions=0);loaded=False;service=None;application=None
sizes=[0,64,(1<<30)-1,1<<30,(1<<30)+1,(1<<31)-1,1<<31,(1<<32)-1]
def call(fd,number,data):return fcntl.ioctl(fd,0xc0000000|(len(data)<<16)|(ord('N')<<8)|number,data,True)
def req(size,source,native=0,entry=0,entry_size=0):return bytearray(struct.pack('<IIIIQIIIIQQQ',1,1,source,0,0,size,entry_size,0,0,native,entry,0))
try:
 p=subprocess.run(['insmod',str(E/'bpf_x86_native_lab.ko')],capture_output=True,text=True);result['insmod']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);loaded=p.returncode==0
 if loaded:
  service=os.open('/sys/kernel/debug/bpf_x86_native_lab/specializer',os.O_RDWR)
  for resources in [False,True]:
   for size in sizes:
    data=req(size,0xffffffff)
    if resources:data+=struct.pack('<IIQ',0,0,0)
    fd=os.open('/sys/kernel/debug/bpf_x86_native_lab/native_submit',os.O_RDWR)
    try:
     try:call(fd,0x77 if resources else 0x70,data);actual=0
     except OSError as error:actual=error.errno
    finally:os.close(fd)
    rows.append(dict(route='SUBMIT_RESOURCES'if resources else'SUBMIT',native_size=size,expected_errno=errno.ENOENT,actual_errno=actual,matches=actual==errno.ENOENT))
  # A copied one-byte capsule supplies the actual active CHUNK route. It is only copied.
  native=ctypes.create_string_buffer(b'\xc3');entry=ctypes.create_string_buffer(b'p');application=os.open('/sys/kernel/debug/bpf_x86_native_lab/native_submit',os.O_RDWR)
  data=req(1,0,ctypes.addressof(native),ctypes.addressof(entry),1);call(application,0x70,data);request_id=struct.unpack_from('<Q',data,16)[0]
  out_native=ctypes.create_string_buffer(1);out_entry=ctypes.create_string_buffer(1);next_req=req(1,0,ctypes.addressof(out_native),ctypes.addressof(out_entry),1);call(service,0x71,next_req)
  result['active_request_id']=request_id
  for size in sizes:
   # The existing invalid load-site copy supplies EFAULT below the bound, using eight bytes.
   data=bytearray(struct.pack('<QQQQIIIIQII',request_id,0,0,0,size,0,0,0,0,1,0));expected=errno.E2BIG if size>=1<<30 else errno.EFAULT
   try:call(service,0x78,data);actual=0
   except OSError as error:actual=error.errno
   rows.append(dict(route='CHUNK',native_size=size,load_site_count=1,load_sites_user=0,expected_errno=expected,actual_errno=actual,matches=actual==expected))
  result['status']='passed'if all(x['matches']for x in rows)else'finding'
 else:result['status']='setup_error'
except BaseException as error:result.update(status='setup_error',error=str(error),traceback=traceback.format_exc())
finally:
 if application is not None:os.close(application)
 if service is not None:os.close(service)
 if loaded:
  p=subprocess.run(['rmmod','bpf_x86_native_lab'],capture_output=True,text=True);result['rmmod']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
  if p.returncode:result['status']='setup_error'
 O.write_text(json.dumps(result,indent=2)+'\n');print('APPROVED_COPY_BOUNDARY',json.dumps(result),flush=True)
