from pathlib import Path
import subprocess,fcntl,struct,os,json,errno,hashlib,traceback
E=Path(__file__).resolve().parent;O=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/bcc-katran-constant-division/safety-control/approved-copy-boundary.json');rows=[]
result=dict(module_sha256=hashlib.sha256((E/'bpf_x86_native_lab.ko').read_bytes()).hexdigest(),cases=rows,source_commit='c3d6523f80887e49e79c786fecc3a166cc4325d4')
loaded=False
try:
 p=subprocess.run(['insmod',str(E/'bpf_x86_native_lab.ko')],capture_output=True,text=True);result['insmod']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);loaded=p.returncode==0
 if loaded:
  for resources in [False,True]:
   for size in [0,64,(1<<30)-1,1<<30,(1<<30)+1,(1<<31)-1,1<<31,(1<<32)-1]:
    request=struct.pack('<IIIIQIIIIQQQ',1,1,0xffffffff,0,0,size,0,0,0,0,0,0)
    if resources:request+=struct.pack('<IIQ',0,0,0)
    command=0xc0000000|(len(request)<<16)|(ord('N')<<8)|(0x77 if resources else 0x70);expected=errno.E2BIG if size>=1<<30 else errno.ENOENT
    with(E/'open-marker').open('w')as marker:marker.write(str(size))
    fd=os.open('/sys/kernel/debug/bpf_x86_native_lab/native_submit',os.O_RDWR)
    try:
     try:fcntl.ioctl(fd,command,bytearray(request),True);actual=0
     except OSError as error:actual=error.errno
    finally:os.close(fd)
    rows.append(dict(resources=resources,native_size=size,expected_errno=expected,actual_errno=actual,matches=actual==expected))
  result['status']='passed' if all(x['matches']for x in rows)else'finding'
 else:result['status']='setup_error'
except BaseException as error:result.update(status='setup_error',error=str(error),traceback=traceback.format_exc())
finally:
 if loaded:
  p=subprocess.run(['rmmod','bpf_x86_native_lab'],capture_output=True,text=True);result['rmmod']=dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
  if p.returncode:result['status']='setup_error'
 O.write_text(json.dumps(result,indent=2)+'\n');print('APPROVED_COPY_BOUNDARY',json.dumps(result),flush=True)
