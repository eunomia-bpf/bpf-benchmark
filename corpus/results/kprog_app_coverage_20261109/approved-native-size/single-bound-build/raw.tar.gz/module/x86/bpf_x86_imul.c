// SPDX-License-Identifier: GPL-2.0
/*
 * BpfReJIT x86 kinsn: IMUL.
 */

#include "kinsn_x86_emit.h"

__bpf_kfunc_start_defs();
__bpf_kfunc void bpf_x86_imulq(void) {}
__bpf_kfunc_end_defs();

BTF_KFUNCS_START(bpf_x86_imul_kfunc_ids)
BTF_ID_FLAGS(func, bpf_x86_imulq)
BTF_KFUNCS_END(bpf_x86_imul_kfunc_ids)

#define X86_FORM_RR		1
#define X86_FORM_ARCH_RR	12

static __always_inline int decode_imul_rr_payload(u64 payload, u8 *dst_reg,
						  u8 *src_reg,
						  bool *arch_reg)
{
	payload = kinsn_payload_decode(payload);
	*arch_reg = (payload & 0xf) == X86_FORM_ARCH_RR;
	if ((payload & 0xf) != X86_FORM_RR &&
	    (payload & 0xf) != X86_FORM_ARCH_RR)
		return -EINVAL;
	*dst_reg = kinsn_payload_reg(payload, 4);
	*src_reg = kinsn_payload_reg(payload, 8);

	if (payload >> 12)
		return -EINVAL;
	if (!kinsn_x86_operand_valid(*dst_reg) ||
	    !kinsn_x86_operand_valid(*src_reg))
		return -EINVAL;

	return 0;
}

static int instantiate_imulq_rr(u64 payload, struct bpf_insn *insn_buf)
{
	u8 dst_reg, src_reg;
	bool arch_reg;
	int err;

	err = decode_imul_rr_payload(payload, &dst_reg, &src_reg, &arch_reg);
	if (err)
		return err;

	insn_buf[0] = BPF_ALU64_REG(BPF_MUL, dst_reg, src_reg);
	return 1;
}

static int emit_imulq_rr_x86(u8 *image, u32 *off, bool emit, u64 payload,
			     const struct bpf_prog *prog,
			 const u8 *final_ip)
{
	u8 dst_reg, src_reg;
	u8 buf[4];
	bool arch_reg;
	u32 len = 0;
	int err;

	err = decode_imul_rr_payload(payload, &dst_reg, &src_reg, &arch_reg);
	if (err)
		return err;

	if (!arch_reg) {
		dst_reg = kinsn_x86_reg_for_prog(prog, dst_reg);
		src_reg = kinsn_x86_reg_for_prog(prog, src_reg);
	}
	if (!kinsn_x86_valid(dst_reg) || !kinsn_x86_valid(src_reg))
		return -EINVAL;

	kinsn_emit_rex_rr(buf, &len, true, dst_reg, src_reg);
	kinsn_emit_u8(buf, &len, 0x0f);
	kinsn_emit_u8(buf, &len, 0xaf);
	kinsn_emit_u8(buf, &len, 0xc0 |
		      (kinsn_x86_code(dst_reg) << 3) |
		      kinsn_x86_code(src_reg));

	return kinsn_emit_finish(image, off, emit, buf, len);
}

const struct bpf_kinsn bpf_x86_imulq_desc = {
	.owner = THIS_MODULE,
	.max_insn_cnt = 1,
	.max_emit_bytes = 4,
	.instantiate_insn = instantiate_imulq_rr,
	.emit_x86 = emit_imulq_rr_x86,
};

static const struct bpf_kinsn * const bpf_x86_imul_kinsn_descs[] = {
	&bpf_x86_imulq_desc,
};

DEFINE_KINSN_V2_MODULE(bpf_x86_imul, "BpfReJIT x86 kinsn: IMUL",
		       bpf_x86_imul_kfunc_ids, bpf_x86_imul_kinsn_descs);
