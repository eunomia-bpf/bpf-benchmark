from pathlib import Path
import json,subprocess,sys,hashlib,shutil,tarfile,traceback,resource
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/current-abi-app-payloads/cilium';sys.path.insert(0,str(G));import cilium_native_build as build
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(**d):(G/'status.json').write_text(json.dumps(d,indent=2)+'\n')
try:
 save(state='compiling_captured_configs')
 payload=G/'payloads/cilium';shutil.copytree(G/'captured',payload)
 for parity in sorted(payload.glob('parity/*/*/parity.json')):
  d=json.loads(parity.read_text());base=parity.parent;overlay=base/'native-abi-overlay';source=overlay/(base.parent.name+'.c');headers=base/'live-headers';headers.mkdir()
  for h in d['headers']:shutil.copy2(base/h['archive'],headers/Path(h['source']).name)
  args=[]
  for arg in d['bpf_command'][1:]:
   if arg.startswith('-I/var/tmp/ciliumrunner_'):args.append('-I'+str(headers))
   elif arg.startswith('-I/var/lib/cilium/bpf'):args.append(arg.replace('/var/lib/cilium/bpf',str(overlay)))
   elif arg.startswith('/var/lib/cilium/bpf/'):args.append(str(source))
   else:args.append(arg)
  old=d['native_command'][d['native_command'].index('-o')+1]
  marker='/details/cilium-native-config/';rel=old.split(marker,1)[1];output=payload/rel;output.parent.mkdir(parents=True,exist_ok=True)
  extras=[x for x in d['native_command']if x.startswith('-DBPFBENCH_')]
  command=['clang-18',*build.native_compile_args(args,output,G/'native_compat.h',overlay,source,extras)]
  with(base/'current-abi.compile.log').open('w')as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
  row=dict(family=base.parent.name,configuration=base.name,command=command,compile_exit=p.returncode,output=str(output),sha256=sha(output)if output.exists()else None,original_parity_sha256=sha(parity));rows.append(row);(G/'compiles.json').write_text(json.dumps(rows,indent=2)+'\n');p.check_returncode()
 manifest=json.loads((payload/'manifest.json').read_text());files={str(p.relative_to(payload)):sha(p)for p in payload.rglob('*.native.o')};O.mkdir(parents=True,exist_ok=True)
 result=dict(inputs=json.loads((G/'inputs.json').read_text()),compiles=rows,native_files=files,manifest_entries=len(manifest['objects']),payload=str(payload),runtime='actual current startup configurations replay; R live-config producer owns new configurations',native_executions=0)
 (O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 (O/'README.md').write_text('# Cilium actual startup configuration native producer\n\nEvery captured Cilium startup configuration is recompiled through the current native_compile_args function, retaining its original paired BPF command, configuration headers and native ABI source overlay. The current helper and external branch/return thunk flags produce P before submission. Captured families '+str(len(rows))+'; native files '+str(len(files))+'; full manifest entries '+str(len(manifest['objects']))+'. Configuration identities remain in their original paths and manifest records.\n\nThe complete captured payload is `'+str(payload)+'`. R can place it at `/artifacts/user/native-bpf/x86_64/cilium/` for the corresponding captured configuration. A fresh live startup uses its actual new configuration headers and the existing paired runtime compiler; current native_compat.h, native_division.so, writer and exact native_compile_args source are preserved in producer.tar.gz. The live producer supplies any further family selected by application startup. Frozen May29 workload and application selection retain their definitions. This receipt records compiler outputs; original startup, stock-verifier and actual workload observations follow the runtime.\n')
 (O/'timing-request.md').write_text('# Cilium current native input handoff\n\nCaptured full configuration payload: `'+str(payload)+'`, image destination `/artifacts/user/native-bpf/x86_64/cilium/`. Use the recorded configuration identity for this payload. The existing live paired compiler builds fresh configurations at startup from their actual headers; its current compiler/native-source closure accompanies producer.tar.gz. Retain the restored May29 workload/launcher and current external-thunk flags when producing P. R owns complete startup and packet/action/work accounting.\n\n```sh\nmake -C /workspaces/repository __runtime-vm-corpus PLATFORM=kvm ARCH=x86 RUNTIME_CONTAINER_IMAGE="$R_IMAGE_WITH_C_P" SAMPLES=3 WORKLOAD_DURATION=180\n```\n')
 with tarfile.open(O/'producer.tar.gz','w:gz')as t:
  for n in ['inputs.json','build.py','compiles.json','native_compat.h','native_division.cpp','native_division.so','write_native_manifest.py','cilium_native_build.py']:t.add(G/n,arcname=n)
  t.add(payload,arcname='native-bpf/cilium')
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Prepare Cilium actual startup configurations on current x86 native ABI',G/'publication.json')
 with tarfile.open(O/'producer.tar.gz')as t:
  for n,h in files.items():assert hashlib.sha256(t.extractfile('native-bpf/cilium/'+n).read()).hexdigest()==h
 save(state='finished',commit=commit,families=len(rows),manifest_entries=len(manifest['objects']))
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' Cilium all'+str(len(rows))+'actual captured startup config families/current-ABI native recompile, full'+str(len(manifest['objects']))+'manifest rows, retained config identities at '+str(payload)+'. Current native_compile_args/helper/plugin/source closure in producer.tar.gz. Fresh startup keeps existing live paired compiler for new configs. R handoff current-abi-app-payloads/cilium/timing-request.md; actual verifier/startup/packet-work follows runtime. Frozen framework bytes retained.\n')
except BaseException as e:save(state='requires_continuation',error=str(e),traceback=traceback.format_exc(),compiles=rows);raise
