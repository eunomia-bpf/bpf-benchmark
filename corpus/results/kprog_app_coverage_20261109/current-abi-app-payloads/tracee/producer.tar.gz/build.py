from pathlib import Path
import subprocess,json,shutil,hashlib,sys,tarfile,traceback,resource
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/current-abi-app-payloads'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(**d):(G/'status.json').write_text(json.dumps(d,indent=2)+'\n')
def run(args,name,cwd=R):
 with(G/(name+'.log')).open('w')as f:p=subprocess.run([str(x)for x in args],cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 (G/(name+'.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
def notice(s):
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': '+s+'\n')
try:
 save(state='compiling',app='otelcol-ebpf-profiler')
 for local,virtual in [(G/'source/otel',R/'vendor/bpf/otel'),(G/'source/tracee',R/'vendor/bpf/tracee/pkg/ebpf/c'),(G/'source/tetragon',R/'vendor/bpf/tetragon/bpf')]:
  run(['mount','--bind',local,virtual],'mount-'+local.name)
 for n in ['native_compat.h','write_native_manifest.py']:
  run(['mount','--bind',G/'source'/n,R/'vendor/bpf'/n],'mount-'+n)
 # All layouts come from the actual newly built x86 runtime BTF.
 with(G/'target-vmlinux.h').open('w')as f:subprocess.run([str(R/'vendor/build/x86/bpftool/bin/bpftool'),'btf','dump','file',json.loads((G/'inputs.json').read_text())['target_kernel'],'format','c'],stdout=f,check=True)
 s=(G/'target-vmlinux.h').read_text().replace('__VMLINUX_H__','__VMLINUX_GENERATED_X86_H__');(G/'source/tetragon/include/vmlinux_generated_x86.h').write_text(s)
 out=G/'native';payload=G/'payloads';payload.mkdir()
 common=['make','-C',str(R/'vendor/bpf'),'-f',str(G/'native-only.mk'),'ARCH=x86','KERNEL_RELEASE=7.0.0-rc2+','NATIVE_OUT='+str(out),'NATIVE_DIVISION_PLUGIN='+str(G/'source/native_division.so'),'NATIVE_LINK=/var/tmp/kprog-tmp/C/master-x86-runtime/native-target/release/native-link','TETRAGON_VMLINUX_H='+str(G/'source/tetragon/include/vmlinux_generated_x86.h')]
 rows=[]
 for app in ['otelcol-ebpf-profiler','tracee','tetragon']:
  save(state='compiling',app=app,completed=rows)
  if app=='otelcol-ebpf-profiler':
   targets=[out/'otel/otelcol-ebpf-profiler.native.o'];run(common+targets,'compile-otel')
   p=payload/app;p.mkdir()
   for x in(out/'otel').glob('*.native.o'):shutil.copy2(x,p/x.name)
   args=['--object',p/'otelcol-ebpf-profiler.native.o']+[v for x in sorted(p.glob('*.native.o'))if x.name!='otelcol-ebpf-profiler.native.o' for v in ['--data-object',x]]
  elif app=='tracee':
   targets=[out/'tracee/tracee.native.o',out/'tracee/lsm_support/kprobe_check.native.o',out/'tracee/lsm_support/lsm_check.native.o'];run(common+targets,'compile-tracee')
   p=payload/app;p.mkdir()
   for x in targets:shutil.copy2(x,p/x.name)
   args=['--dedupe-program','last']+[v for x in [p/'tracee.native.o',p/'kprobe_check.native.o',p/'lsm_check.native.o']for v in ['--object',x]]
  else:
   run(common+['native-tetragon','TETRAGON_NATIVE_STAGE_OUT='+str(G/'tetragon-stage')],'compile-tetragon')
   p=payload/app;p.mkdir()
   for x in(out/'tetragon').glob('*.native.o'):shutil.copy2(x,p/x.name)
   args=['--dedupe-program','last','--source-object-root',G/'paired-tetragon-bpf','--helper-disambiguate','174']+[v for x in sorted(p.glob('*.native.o'))for v in ['--object',x]]
  run(['python3',G/'source/write_native_manifest.py','--app',app,'--llvm-nm','llvm-nm-18','--output',p/'manifest.json',*args],'manifest-'+app)
  manifest=json.loads((p/'manifest.json').read_text());undefined={}
  for x in sorted(p.glob('*.native.o')):
   undefined[x.name]=subprocess.check_output(['llvm-nm-18','--undefined-only',str(x)],text=True)
  (G/(app+'-undefined-symbols.json')).write_text(json.dumps(undefined,indent=2)+'\n')
  row=dict(app=app,path=str(p),native_objects=len(list(p.glob('*.native.o'))),manifest_entries=len(manifest['objects']),files={x.name:dict(sha256=sha(x),bytes=x.stat().st_size)for x in p.iterdir()if x.is_file()});rows.append(row)
  ao=O/app;ao.mkdir(parents=True,exist_ok=True)
  result=dict(inputs=json.loads((G/'inputs.json').read_text()),producer=row,source_hashes={str(x.relative_to(G/'source')):sha(x)for x in(G/'source').rglob('*')if x.is_file()},target_vmlinux_h_sha256=sha(G/'target-vmlinux.h'),application_runtime='R restored-May29 replay follows',generated_at_load='registered specializer',native_executions=0)
  (ao/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
  (ao/'README.md').write_text('# '+app+' current x86 native producer\n\nThe complete O3 native producer uses the current native helper, external branch/return thunks and target-kernel BTF. Native objects '+str(row['native_objects'])+'; manifest entries '+str(row['manifest_entries'])+'. Every selected program retains its manifest identity. Native compilation precedes submission of P; the live service generates B from the copied P and the stock verifier decides.\n\nThe payload directory is `'+str(p)+'`. Overlay its complete contents into `/artifacts/user/native-bpf/x86_64/'+app+'/` of R existing restored-May29 image. Tracee and Tetragon use the recorded paired application source epochs, with their baseline artifacts paired to that source. R retains the original CLI/workload and per-phase actual work accounting. The producer archive records source, compiler flags, logs, native ELF/manifests and target-kernel layout. Runtime results follow the actual original application startup.\n')
  (ao/'timing-request.md').write_text('# '+app+' native input handoff\n\nComplete native input: `'+str(p)+'`. Image destination: `/artifacts/user/native-bpf/x86_64/'+app+'/`. Current producer source and artifact identities are in summary.json. Existing command shape, with R retaining its restored image and original arm controls:\n\n```sh\nmake -C /workspaces/repository __runtime-vm-corpus PLATFORM=kvm ARCH=x86 RUNTIME_CONTAINER_IMAGE="$R_IMAGE_WITH_C_P" SAMPLES=3 WORKLOAD_DURATION=180\n```\n\nR records complete startup and work counters before attributing throughput. This handoff records native compiler outputs; current verifier and whole-work outcomes retain their own actual service receipts.\n')
  with tarfile.open(ao/'producer.tar.gz','w:gz')as t:
   t.add(p,arcname='native-bpf/'+app)
   for n in ['inputs.json','build.py','native-only.mk','target-vmlinux.h','source'] :t.add(G/n,arcname=n)
   for x in G.iterdir():
    if x.is_file()and (x.name.endswith('.log')or x.name.endswith('.exit')or x.name.endswith('-undefined-symbols.json')):t.add(x,arcname=x.name)
  sys.path.insert(0,str(C));from publish_owned import publish
  commit=publish([str(x.relative_to(R))for x in ao.iterdir()if x.is_file()],'Prepare '+app+' complete native input on current x86 ABI',G/(app+'-publication.json'))
  with tarfile.open(ao/'producer.tar.gz','r:gz')as t:
   for x in p.iterdir():
    if x.is_file():assert hashlib.sha256(t.extractfile('native-bpf/'+app+'/'+x.name).read()).hexdigest()==sha(x)
  notice('PUSHED '+commit+' '+app+' current-ABI complete producer '+str(row['native_objects'])+'objects/'+str(row['manifest_entries'])+'manifest rows at '+str(p)+'. R input handoff '+str((ao/'timing-request.md').relative_to(R))+'. Compiler outputs/source/actual commands retained; original application startup/work and restored-May29 throughput follow R. Frozen framework retains bytes.')
 save(state='finished',apps=rows)
except BaseException as e:save(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
