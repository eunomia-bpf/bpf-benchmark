#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#include "kprog/x86/x86_sim_local_bpf.h"
#include <stdio.h>
unsigned long native_lab_entry_input(unsigned int kind) { return 0; }
int main(void) {
 X86_SIM_L_DECLARE_STACK_VALUES();
 unsigned cases=0;
 for (unsigned tag=0;tag<256;tag++) for (unsigned valid=0;valid<2;valid++) {
  X86_SIM_L_SV_STATE(0)=tag|(valid<<8);
  if (X86_SIM_L_SV_TAG(0)!=tag || X86_SIM_L_SC_VALID(0)!=valid) return 1;
  __u64 __x86_sv_at=0; __u8 __x86_sv_tag=255-tag; void *__x86_sv_pointer=(void*)0x1230;
  X86_SIM_L_SV_SAVE_ONE(0);
  if (X86_SIM_L_SV_TAG(0)!=255-tag || X86_SIM_L_SC_VALID(0)!=valid) return 2;
  __u64 __x86_sc_at=0, __x86_sc_value=0xf0123456789abcdeULL;
  X86_SIM_L_SC_SAVE_ONE(0);
  if (X86_SIM_L_SV_TAG(0)!=255-tag || X86_SIM_L_SC_VALID(0)!=1 || X86_SIM_L_SC_VALUE(0)!=__x86_sc_value) return 3;
  X86_SIM_L_SV_CLEAR_ONE(0);
  if (X86_SIM_L_SV_TAG(0)!=0 || X86_SIM_L_SC_VALID(0)!=0 || X86_SIM_L_SC_VALUE(0)!=__x86_sc_value) return 4;
  cases++;
 }
 printf("PASS %u complete tag/valid states\n",cases);
 return 0;
}
