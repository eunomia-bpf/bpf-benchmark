#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 40U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4)
#include "/var/tmp/kprog-tmp/A/resident-census/source/kprog/x86/x86_sim_local_bpf.h"

extern __u8 data[] __ksym;
extern __u8 start[] __ksym;
static const __u8 __x86_rodata_0[48] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(7):.rodata\",\"size\":48}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       __x86_ro_value = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       __x86_ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \
   __x86_ro_value; })

SEC("census/program")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_9:
	/* 0x9: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_c:
	/* 0xc: call   11 <sys_exit+0x11> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_15:
	/* 0x15: cmp    QWORD PTR [r14+0x8],0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38654705663ULL);
x86_l_1a:
	/* 0x1a: je     6a <sys_exit+0x6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a, 0x6a, x86_l_6a);
x86_l_1c:
	/* 0x1c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_23:
	/* 0x23: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_28:
	/* 0x28: call   2d <sys_exit+0x2d> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d:
	/* 0x2d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_30:
	/* 0x30: je     6a <sys_exit+0x6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30, 0x6a, x86_l_6a);
x86_l_32:
	/* 0x32: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_35:
	/* 0x35: call   3a <sys_exit+0x3a> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_3a:
	/* 0x3a: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_3d:
	/* 0x3d: mov    r15,QWORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40:
	/* 0x40: mov    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_44:
	/* 0x44: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_48:
	/* 0x48: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data));
x86_l_4f:
	/* 0x4f: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_54:
	/* 0x54: call   59 <sys_exit+0x59> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_59:
	/* 0x59: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5c:
	/* 0x5c: je     7a <sys_exit+0x7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c, 0x7a, x86_l_7a);
x86_l_5e:
	/* 0x5e: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_62:
	/* 0x62: sub    rbx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_65:
	/* 0x65: add QWORD PTR [rax+0x8],rbx */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RAX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_6a:
	/* 0x6a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6c:
	/* 0x6c: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_70:
	/* 0x70: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_71:
	/* 0x71: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_73:
	/* 0x73: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_75:
	/* 0x75: jmp    ba <sys_exit+0xba> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_7a:
	/* 0x7a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data));
x86_l_81:
	/* 0x81: lea    rdx,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (16))));
x86_l_88:
	/* 0x88: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8d:
	/* 0x8d: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_92:
	/* 0x92: call   97 <sys_exit+0x97> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_update_elem);
x86_l_97:
	/* 0x97: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_9a:
	/* 0x9a: je     a2 <sys_exit+0xa2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a, 0xa2, x86_l_a2);
x86_l_9c:
	/* 0x9c: cmp    rax,0xffffffffffffffef */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551599ULL);
x86_l_a0:
	/* 0xa0: jne    6a <sys_exit+0x6a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa0, 0x6a, x86_l_6a);
x86_l_a2:
	/* 0xa2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data));
x86_l_a9:
	/* 0xa9: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ae:
	/* 0xae: call   b3 <sys_exit+0xb3> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b3:
	/* 0xb3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b6:
	/* 0xb6: jne    5e <sys_exit+0x5e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb6, 0x5e, x86_l_5e);
x86_l_b8:
	/* 0xb8: jmp    6a <sys_exit+0x6a> */
	X86_SIM_X86_JMP(0xb8, 0x6a, x86_l_6a);
x86_l_ba:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
