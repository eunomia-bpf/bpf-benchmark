#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6)
#include "/var/tmp/kprog-tmp/A/resident-census/source/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 __config_enable_xdp_prefilter[] __ksym;
extern __u8 __config_tracing_ip_option_type[] __ksym;
extern __u8 cilium_cidr_v4_dyn[] __ksym;
extern __u8 cilium_cidr_v4_fix[] __ksym;
extern __u8 cilium_percpu_trace_id[] __ksym;
extern __u8 cilium_xdp_scratch[] __ksym;
SEC("census/program")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_11:
	/* 0x11: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)__config_tracing_ip_option_type));
x86_l_18:
	/* 0x18: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b:
	/* 0x1b: je     5f <cil_xdp_entry+0x5f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b, 0x5f, x86_l_5f);
x86_l_1d:
	/* 0x1d: movzx  ebp,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_20:
	/* 0x20: mov    rcx,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23:
	/* 0x23: mov    rdx,QWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27:
	/* 0x27: lea    rax,[rcx+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_2b:
	/* 0x2b: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_2e:
	/* 0x2e: jbe    16a <cil_xdp_entry+0x16a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2e, 0x16a, x86_l_16a);
x86_l_34:
	/* 0x34: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3c:
	/* 0x3c: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_42:
	/* 0x42: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_percpu_trace_id));
x86_l_49:
	/* 0x49: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e:
	/* 0x4e: call   53 <cil_xdp_entry+0x53> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56:
	/* 0x56: je     5f <cil_xdp_entry+0x5f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x5f, x86_l_5f);
x86_l_58:
	/* 0x58: mov    QWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5f:
	/* 0x5f: mov    rcx,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_62:
	/* 0x62: lea    rdx,[rcx+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_66:
	/* 0x66: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_6b:
	/* 0x6b: cmp    rdx,QWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_6f:
	/* 0x6f: ja     212 <cil_xdp_entry+0x212> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6f, 0x212, x86_l_212);
x86_l_75:
	/* 0x75: movzx  ebp,WORD PTR [rcx+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 12ULL);
x86_l_79:
	/* 0x79: cmp    bp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_16, 6ULL);
x86_l_7d:
	/* 0x7d: jb     212 <cil_xdp_entry+0x212> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7d, 0x212, x86_l_212);
x86_l_83:
	/* 0x83: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_8b:
	/* 0x8b: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_91:
	/* 0x91: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_98:
	/* 0x98: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9d:
	/* 0x9d: call   a2 <cil_xdp_entry+0xa2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a2:
	/* 0xa2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_a5:
	/* 0xa5: je     ae <cil_xdp_entry+0xae> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5, 0xae, x86_l_ae);
x86_l_a7:
	/* 0xa7: mov    DWORD PTR [rax+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ae:
	/* 0xae: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_b6:
	/* 0xb6: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_bc:
	/* 0xbc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_c3:
	/* 0xc3: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c8:
	/* 0xc8: call   cd <cil_xdp_entry+0xcd> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_cd:
	/* 0xcd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_d0:
	/* 0xd0: je     d9 <cil_xdp_entry+0xd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd0, 0xd9, x86_l_d9);
x86_l_d2:
	/* 0xd2: mov    DWORD PTR [rax+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_d9:
	/* 0xd9: cmp    bp,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_16, 8ULL);
x86_l_dd:
	/* 0xdd: jne    1c7 <cil_xdp_entry+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdd, 0x1c7, x86_l_1c7);
x86_l_e3:
	/* 0xe3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)__config_enable_xdp_prefilter));
x86_l_ea:
	/* 0xea: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ed:
	/* 0xed: je     1c7 <cil_xdp_entry+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed, 0x1c7, x86_l_1c7);
x86_l_f3:
	/* 0xf3: mov    rcx,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f6:
	/* 0xf6: lea    rax,[rcx+0x22] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_fa:
	/* 0xfa: cmp    rax,QWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_fe:
	/* 0xfe: ja     160 <cil_xdp_entry+0x160> */
	X86_SIM_X86_JCC(X86_CC_A, 0xfe, 0x160, x86_l_160);
x86_l_100:
	/* 0x100: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_105:
	/* 0x105: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_10a:
	/* 0x10a: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10c:
	/* 0x10c: div    rsi */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10f:
	/* 0x10f: cmp    rdx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 1ULL);
x86_l_113:
	/* 0x113: je     462 <cil_xdp_entry+0x462> */
	X86_SIM_X86_JCC(X86_CC_E, 0x113, 0x462, x86_l_462);
x86_l_119:
	/* 0x119: mov    eax,DWORD PTR [rcx+0x1a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_11c:
	/* 0x11c: mov    DWORD PTR [rsp+0x14],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_120:
	/* 0x120: mov    DWORD PTR [rsp+0x10],0x20 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476768ULL);
x86_l_128:
	/* 0x128: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_12e:
	/* 0x12e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_cidr_v4_dyn));
x86_l_135:
	/* 0x135: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13a:
	/* 0x13a: call   13f <cil_xdp_entry+0x13f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13f:
	/* 0x13f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_142:
	/* 0x142: jne    160 <cil_xdp_entry+0x160> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x142, 0x160, x86_l_160);
x86_l_144:
	/* 0x144: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_14a:
	/* 0x14a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_cidr_v4_fix));
x86_l_151:
	/* 0x151: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_156:
	/* 0x156: call   15b <cil_xdp_entry+0x15b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15b:
	/* 0x15b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_15e:
	/* 0x15e: je     1c7 <cil_xdp_entry+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15e, 0x1c7, x86_l_1c7);
x86_l_160:
	/* 0x160: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_165:
	/* 0x165: jmp    212 <cil_xdp_entry+0x212> */
	X86_SIM_X86_JMP(0x165, 0x212, x86_l_212);
x86_l_16a:
	/* 0x16a: cmp    WORD PTR [rcx+0xc],0x8 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 51539607560ULL);
x86_l_16f:
	/* 0x16f: jne    34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16f, 0x34, x86_l_34);
x86_l_175:
	/* 0x175: add    rcx,0x22 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 34ULL);
x86_l_179:
	/* 0x179: cmp    rcx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_17c:
	/* 0x17c: ja     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17c, 0x34, x86_l_34);
x86_l_182:
	/* 0x182: movzx  r15d,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_186:
	/* 0x186: and    r15d,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_18a:
	/* 0x18a: cmp    r15b,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_8, 6ULL);
x86_l_18e:
	/* 0x18e: jae    221 <cil_xdp_entry+0x221> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x18e, 0x221, x86_l_221);
x86_l_194:
	/* 0x194: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_197:
	/* 0x197: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_19f:
	/* 0x19f: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_1a5:
	/* 0x1a5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_percpu_trace_id));
x86_l_1ac:
	/* 0x1ac: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b1:
	/* 0x1b1: call   1b6 <cil_xdp_entry+0x1b6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b6:
	/* 0x1b6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1b9:
	/* 0x1b9: je     5f <cil_xdp_entry+0x5f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b9, 0x5f, x86_l_5f);
x86_l_1bf:
	/* 0x1bf: mov    QWORD PTR [rax],r14 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c2:
	/* 0x1c2: jmp    5f <cil_xdp_entry+0x5f> */
	X86_SIM_X86_JMP(0x1c2, 0x5f, x86_l_5f);
x86_l_1c7:
	/* 0x1c7: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1cf:
	/* 0x1cf: mov    r11d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1ULL);
x86_l_1d5:
	/* 0x1d5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_1dc:
	/* 0x1dc: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e1:
	/* 0x1e1: call   1e6 <cil_xdp_entry+0x1e6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e6:
	/* 0x1e6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1e9:
	/* 0x1e9: je     20d <cil_xdp_entry+0x20d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e9, 0x20d, x86_l_20d);
x86_l_1eb:
	/* 0x1eb: mov    ebp,DWORD PTR [rax+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ee:
	/* 0x1ee: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_1f0:
	/* 0x1f0: je     20d <cil_xdp_entry+0x20d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f0, 0x20d, x86_l_20d);
x86_l_1f2:
	/* 0x1f2: mov    r11d,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 54ULL);
x86_l_1f8:
	/* 0x1f8: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_1fb:
	/* 0x1fb: mov    esi,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4294967292ULL);
x86_l_200:
	/* 0x200: call   205 <cil_xdp_entry+0x205> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x36ULL: X86_SIM_BPF_CALL_bpf_xdp_adjust_meta(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x36ULL: X86_SIM_BPF_CALL_bpf_xdp_adjust_meta(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_205:
	/* 0x205: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_207:
	/* 0x207: je     2e7 <cil_xdp_entry+0x2e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207, 0x2e7, x86_l_2e7);
x86_l_20d:
	/* 0x20d: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_212:
	/* 0x212: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_216:
	/* 0x216: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_217:
	/* 0x217: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_219:
	/* 0x219: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_21b:
	/* 0x21b: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_21c:
	/* 0x21c: jmp    221 <cil_xdp_entry+0x221> */
	X86_SIM_X86_RET();
x86_l_221:
	/* 0x221: lea    rdx,[rsp+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_226:
	/* 0x226: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_22c:
	/* 0x22c: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_22f:
	/* 0x22f: mov    esi,0x22 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 34ULL);
x86_l_234:
	/* 0x234: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_239:
	/* 0x239: call   23e <cil_xdp_entry+0x23e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23e:
	/* 0x23e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_240:
	/* 0x240: js     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x240, 0x34, x86_l_34);
x86_l_246:
	/* 0x246: movzx  eax,BYTE PTR [rsp+0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_24b:
	/* 0x24b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_24d:
	/* 0x24d: je     194 <cil_xdp_entry+0x194> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d, 0x194, x86_l_194);
x86_l_253:
	/* 0x253: mov    r14d,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 35ULL);
x86_l_259:
	/* 0x259: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_25c:
	/* 0x25c: je     30e <cil_xdp_entry+0x30e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c, 0x30e, x86_l_30e);
x86_l_262:
	/* 0x262: lea    rdx,[rsp+0xf] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
x86_l_267:
	/* 0x267: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_26d:
	/* 0x26d: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_270:
	/* 0x270: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_275:
	/* 0x275: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_27a:
	/* 0x27a: call   27f <cil_xdp_entry+0x27f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_27f:
	/* 0x27f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_281:
	/* 0x281: js     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x281, 0x34, x86_l_34);
x86_l_287:
	/* 0x287: mov    r14d,0x22 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 34ULL);
x86_l_28d:
	/* 0x28d: cmp    BYTE PTR [rsp+0xe],bpl */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_292:
	/* 0x292: jne    304 <cil_xdp_entry+0x304> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x292, 0x304, x86_l_304);
x86_l_294:
	/* 0x294: movzx  eax,BYTE PTR [rsp+0xf] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_299:
	/* 0x299: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_29c:
	/* 0x29c: je     426 <cil_xdp_entry+0x426> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29c, 0x426, x86_l_426);
x86_l_2a2:
	/* 0x2a2: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_2a5:
	/* 0x2a5: je     3f6 <cil_xdp_entry+0x3f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a5, 0x3f6, x86_l_3f6);
x86_l_2ab:
	/* 0x2ab: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2ae:
	/* 0x2ae: jne    34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ae, 0x34, x86_l_34);
x86_l_2b4:
	/* 0x2b4: add    r14d,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_2b8:
	/* 0x2b8: lea    rdx,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bd:
	/* 0x2bd: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_2c3:
	/* 0x2c3: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_2c6:
	/* 0x2c6: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_2c9:
	/* 0x2c9: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2ce:
	/* 0x2ce: call   2d3 <cil_xdp_entry+0x2d3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d3:
	/* 0x2d3: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d6:
	/* 0x2d6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2d8:
	/* 0x2d8: movbe  cx,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RCX, X86_RSP, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_2df:
	/* 0x2df: movzx  ecx,cx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_2e2:
	/* 0x2e2: jmp    451 <cil_xdp_entry+0x451> */
	X86_SIM_X86_JMP(0x2e2, 0x451, x86_l_451);
x86_l_2e7:
	/* 0x2e7: mov    rcx,QWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2eb:
	/* 0x2eb: lea    rax,[rcx+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2ef:
	/* 0x2ef: cmp    rax,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 0ULL);
x86_l_2f2:
	/* 0x2f2: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2f7:
	/* 0x2f7: ja     212 <cil_xdp_entry+0x212> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2f7, 0x212, x86_l_212);
x86_l_2fd:
	/* 0x2fd: mov    DWORD PTR [rcx],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff:
	/* 0x2ff: jmp    212 <cil_xdp_entry+0x212> */
	X86_SIM_X86_JMP(0x2ff, 0x212, x86_l_212);
x86_l_304:
	/* 0x304: movzx  r14d,BYTE PTR [rsp+0xf] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_30a:
	/* 0x30a: add    r14d,0x22 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_ADD, 34ULL);
x86_l_30e:
	/* 0x30e: lea    r15d,[r15*4+0x22] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 34ULL);
x86_l_316:
	/* 0x316: cmp    r14d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R14, X86_R15, X86_WIDTH_32);
x86_l_319:
	/* 0x319: jae    194 <cil_xdp_entry+0x194> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x319, 0x194, x86_l_194);
x86_l_31f:
	/* 0x31f: lea    rdx,[rsp+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_324:
	/* 0x324: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_32a:
	/* 0x32a: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_32d:
	/* 0x32d: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_330:
	/* 0x330: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_335:
	/* 0x335: call   33a <cil_xdp_entry+0x33a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33a:
	/* 0x33a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_33c:
	/* 0x33c: js     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x33c, 0x34, x86_l_34);
x86_l_342:
	/* 0x342: movzx  eax,BYTE PTR [rsp+0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_347:
	/* 0x347: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_349:
	/* 0x349: je     194 <cil_xdp_entry+0x194> */
	X86_SIM_X86_JCC(X86_CC_E, 0x349, 0x194, x86_l_194);
x86_l_34f:
	/* 0x34f: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_352:
	/* 0x352: je     388 <cil_xdp_entry+0x388> */
	X86_SIM_X86_JCC(X86_CC_E, 0x352, 0x388, x86_l_388);
x86_l_354:
	/* 0x354: lea    esi,[r14+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_358:
	/* 0x358: lea    rdx,[rsp+0xf] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
x86_l_35d:
	/* 0x35d: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_363:
	/* 0x363: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_366:
	/* 0x366: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_36b:
	/* 0x36b: call   370 <cil_xdp_entry+0x370> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_370:
	/* 0x370: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_372:
	/* 0x372: js     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x372, 0x34, x86_l_34);
x86_l_378:
	/* 0x378: cmp    BYTE PTR [rsp+0xe],bpl */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_37d:
	/* 0x37d: je     294 <cil_xdp_entry+0x294> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37d, 0x294, x86_l_294);
x86_l_383:
	/* 0x383: movzx  eax,BYTE PTR [rsp+0xf] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_388:
	/* 0x388: add    r14d,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RAX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_38b:
	/* 0x38b: cmp    r14d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R14, X86_R15, X86_WIDTH_32);
x86_l_38e:
	/* 0x38e: jae    194 <cil_xdp_entry+0x194> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x38e, 0x194, x86_l_194);
x86_l_394:
	/* 0x394: lea    rdx,[rsp+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_399:
	/* 0x399: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_39f:
	/* 0x39f: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_3a2:
	/* 0x3a2: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_3a5:
	/* 0x3a5: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_3aa:
	/* 0x3aa: call   3af <cil_xdp_entry+0x3af> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3af:
	/* 0x3af: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3b1:
	/* 0x3b1: js     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3b1, 0x34, x86_l_34);
x86_l_3b7:
	/* 0x3b7: cmp    BYTE PTR [rsp+0xe],0x2 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 60129542146ULL);
x86_l_3bc:
	/* 0x3bc: jb     194 <cil_xdp_entry+0x194> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3bc, 0x194, x86_l_194);
x86_l_3c2:
	/* 0x3c2: lea    esi,[r14+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3c6:
	/* 0x3c6: lea    rdx,[rsp+0xf] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
x86_l_3cb:
	/* 0x3cb: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_3d1:
	/* 0x3d1: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_3d4:
	/* 0x3d4: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_3d9:
	/* 0x3d9: call   3de <cil_xdp_entry+0x3de> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3de:
	/* 0x3de: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3e0:
	/* 0x3e0: js     34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3e0, 0x34, x86_l_34);
x86_l_3e6:
	/* 0x3e6: cmp    BYTE PTR [rsp+0xe],bpl */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_3eb:
	/* 0x3eb: jne    194 <cil_xdp_entry+0x194> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3eb, 0x194, x86_l_194);
x86_l_3f1:
	/* 0x3f1: jmp    294 <cil_xdp_entry+0x294> */
	X86_SIM_X86_JMP(0x3f1, 0x294, x86_l_294);
x86_l_3f6:
	/* 0x3f6: add    r14d,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_3fa:
	/* 0x3fa: lea    rdx,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ff:
	/* 0x3ff: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_405:
	/* 0x405: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_408:
	/* 0x408: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_40b:
	/* 0x40b: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_410:
	/* 0x410: call   415 <cil_xdp_entry+0x415> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_415:
	/* 0x415: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_417:
	/* 0x417: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_419:
	/* 0x419: movbe  r14d,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_420:
	/* 0x420: cmovs  r14d,ecx */
	X86_SIM_L_EXEC_CMOV(X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_424:
	/* 0x424: jmp    455 <cil_xdp_entry+0x455> */
	X86_SIM_X86_JMP(0x424, 0x455, x86_l_455);
x86_l_426:
	/* 0x426: add    r14d,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_42a:
	/* 0x42a: lea    rdx,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_42f:
	/* 0x42f: mov    r11d,0xbd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 189ULL);
x86_l_435:
	/* 0x435: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_438:
	/* 0x438: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_43b:
	/* 0x43b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_440:
	/* 0x440: call   445 <cil_xdp_entry+0x445> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xbdULL: X86_SIM_BPF_CALL_bpf_xdp_load_bytes(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_445:
	/* 0x445: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_448:
	/* 0x448: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_44a:
	/* 0x44a: movbe  rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_451:
	/* 0x451: cmovns r14,rcx */
	X86_SIM_L_EXEC_CMOV(X86_R14, X86_RCX, X86_WIDTH_64, X86_CC_NS);
x86_l_455:
	/* 0x455: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_457:
	/* 0x457: jns    197 <cil_xdp_entry+0x197> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x457, 0x197, x86_l_197);
x86_l_45d:
	/* 0x45d: jmp    34 <cil_xdp_entry+0x34> */
	X86_SIM_X86_JMP(0x45d, 0x34, x86_l_34);
x86_l_462:
	/* 0x462: ud2 */
	X86_SIM_L_INVALID_OPCODE_FAULT();
x86_l_464:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
