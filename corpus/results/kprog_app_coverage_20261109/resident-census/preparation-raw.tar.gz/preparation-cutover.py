from pathlib import Path
import os,select,signal,time,json,datetime
D=Path('/var/tmp/kprog-tmp/A/resident-census')
parent=3817966
p=Path('/proc')/str(parent)
children=(p/'task'/str(parent)/'children').read_text().split() if p.exists() else []
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),preparation_parent=parent,children=children,reason='close preparatory compiler cohort after current operation; stock pass covers all549')
if p.exists():
 for child in children:
  try:
   fd=os.pidfd_open(int(child));select.select([fd],[],[]);os.close(fd)
  except ProcessLookupError:pass
 while p.exists():
  try:
   table=json.loads((D/'generated/progress.json').read_text())
   if table['attempted']>=26:break
  except (FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(0.05)
 if p.exists():os.kill(parent,signal.SIGTERM)
receipt['closed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(D/'preparation-cutover.json').write_text(json.dumps(receipt,indent=2)+'\n')
