from pathlib import Path
import ctypes as c,hashlib,importlib.util,json,os,collections
from elftools.elf.elffile import ELFFile
R=Path("/workspaces/repository");D=Path("/var/tmp/kprog-tmp/A/resource-local-entries")
spec=importlib.util.spec_from_file_location("native_submit",R/"kprog/selftests/submit.py")
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
lib=c.CDLL("/var/tmp/kprog-tmp/A/resident-census/stock-runtime/libnative_loader.so",use_errno=True)
for name,result,args in [
 ("bpf_object__open_file",c.c_void_p,[c.c_char_p,c.c_void_p]),
 ("libbpf_get_error",c.c_long,[c.c_void_p]),
 ("bpf_object__close",None,[c.c_void_p]),
 ("bpf_object__next_program",c.c_void_p,[c.c_void_p,c.c_void_p]),
 ("bpf_program__set_autoload",c.c_int,[c.c_void_p,c.c_bool]),
 ("bpf_program__autoload",c.c_bool,[c.c_void_p]),
 ("bpf_program__name",c.c_char_p,[c.c_void_p]),
 ("bpf_program__type",c.c_uint32,[c.c_void_p]),
 ("bpf_program__section_name",c.c_char_p,[c.c_void_p])]:
 f=getattr(lib,name);f.restype=result;f.argtypes=args
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def opened(path):
 obj=lib.bpf_object__open_file(os.fsencode(path),None)
 err=lib.libbpf_get_error(obj)
 return obj,int(err or (-c.get_errno() if not obj else 0))
index=json.loads((R/"corpus/results/kprog_app_coverage_20261109/resident-census/resource-index.json").read_text())["programs"]
groups=collections.defaultdict(list)
for row in index:
 if row.get("resource_stage")=="source_object_captured":groups[row["bpf_object"]].append(row)
rows=[]
for name,instances in groups.items():
 path=Path(name);original_sha=sha(path);obj,error=opened(path)
 if obj and not error:lib.bpf_object__close(obj)
 before={}
 with path.open("rb") as fp:
  elf=ELFFile(fp)
  for s in elf.iter_sections():
   if s["sh_flags"]&2 or s.name in (".BTF",".BTF.ext"):before[s.name]=hashlib.sha256(s.data()).hexdigest()
 with m.libbpf_resource_object(path,D) as (resource,symbols):
  obj,after_error=opened(resource)
  programs=[]
  try:
   if obj and not after_error:
    prog=None
    while True:
     prog=lib.bpf_object__next_program(obj,prog)
     if not prog:break
     rc=lib.bpf_program__set_autoload(prog,False)
     assert rc==0
     programs.append(dict(name=lib.bpf_program__name(prog).decode(),section=lib.bpf_program__section_name(prog).decode(),prog_type=lib.bpf_program__type(prog),autoload=bool(lib.bpf_program__autoload(prog))))
   with resource.open("rb") as fp:
    elf=ELFFile(fp)
    after={s.name:hashlib.sha256(s.data()).hexdigest() for s in elf.iter_sections() if s["sh_flags"]&2 or s.name in (".BTF",".BTF.ext")}
   assert before==after
   assert all(not p["autoload"] for p in programs)
   assert sha(path)==original_sha
   if not after_error:assert all(any(p["name"]==r["entry"] for p in programs) for r in instances)
   rows.append(dict(source=str(path),source_sha256=original_sha,application=instances[0]["application"],resident_instances=len(instances),original_open_errno=error,adapted_open_errno=after_error,globalized_entries=symbols,resource_sha256=sha(resource),preserved_sections=before,programs=programs))
  finally:
   if obj and not after_error:lib.bpf_object__close(obj)
 (D/"progress.json").write_text(json.dumps(dict(objects=len(rows),programs=rows),indent=2)+"\n")
result=dict(objects=len(rows),resident_instances=sum(r["resident_instances"] for r in rows),recovered_instances=sum(r["resident_instances"] for r in rows if r["original_open_errno"] and not r["adapted_open_errno"]),all_objects_opened=all(r["adapted_open_errno"]==0 for r in rows),native_execution_requests=0,bpf_program_load_calls=0,programs=rows)
(D/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="programs"}))
