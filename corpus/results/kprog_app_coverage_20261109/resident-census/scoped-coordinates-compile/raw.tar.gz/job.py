from pathlib import Path
import os,subprocess,json,struct,hashlib,time,concurrent.futures,threading
from elftools.elf.elffile import ELFFile
R=Path("/workspaces/repository");D=Path("/var/tmp/kprog-tmp/A/forwarding-scoped-coordinates")
source=json.loads((D/"source.json").read_text())
os.unshare(os.CLONE_NEWNS);subprocess.run(["mount","--make-rprivate","/"],check=True)
for rel in source["files"]:
 if rel.endswith(".h"):subprocess.run(["mount","--bind",str(D/"source"/rel),str(R/rel)],check=True)
results=[];lock=threading.Lock()
def compile_one(program):
 p=D/str(program);obj=p/"trusted_x86.bpf.o";input=source["inputs"][str(program)]
 command=[str(D/"source/kprog/stock-path/bin/clang"),"-g","-O3","-mcpu=v4","-target","bpf","-mllvm","-bpf-stack-size=4096","-D__TARGET_ARCH_x86","-I",str(R/"vendor/libbpf/include/uapi"),"-I",str(R/"vendor/libbpf/src"),"-I","/usr/include/x86_64-linux-gnu","-c",str(p/"trusted_x86.bpf.c"),"-o",str(obj)]
 started=time.time()
 with (p/"compiler.stdout").open("w") as stdout,(p/"compiler.stderr").open("w") as stderr:
  done=subprocess.run(command,stdout=stdout,stderr=stderr)
 result=dict(program=program,command=command,returncode=done.returncode,elapsed_seconds=time.time()-started,source_head=source["source_head"],source_sha256=hashlib.sha256((p/"trusted_x86.bpf.c").read_bytes()).hexdigest(),forwarding_cells=input["new_cells"],native_proof_sha256=input["native_proof_sha256"])
 if done.returncode==0:
  offsets=[]
  with obj.open("rb") as f:
   elf=ELFFile(f)
   for section in elf.iter_sections():
    if section["sh_flags"]&4:
     data=section.data()
     for i in range(0,len(data)-7,8):
      code,regs,off,imm=struct.unpack_from("<BBhi",data,i);dst,src=regs&15,regs>>4
      if (code&7==1 and src==10) or (code&7 in {2,3} and dst==10):offsets.append(off)
  result["minimum_direct_r10_offset"]=min(offsets,default=0);result["object_sha256"]=hashlib.sha256(obj.read_bytes()).hexdigest()
 (p/"compiler-result.json").write_text(json.dumps(result,indent=2)+"\n")
 with lock:
  results.append(result);(D/"progress.json").write_text(json.dumps(results,indent=2)+"\n")
 print(json.dumps(result),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:list(pool.map(compile_one,[104,103,101,105,100]))
(D/"result.json").write_text(json.dumps(results,indent=2)+"\n")
