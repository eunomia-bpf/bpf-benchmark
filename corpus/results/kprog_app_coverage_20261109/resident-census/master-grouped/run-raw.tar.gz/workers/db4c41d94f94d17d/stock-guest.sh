#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/census-claude/workers/db4c41d94f94d17d
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/census-claude/workers/db4c41d94f94d17d/driver.py guest --scratch "$D"
