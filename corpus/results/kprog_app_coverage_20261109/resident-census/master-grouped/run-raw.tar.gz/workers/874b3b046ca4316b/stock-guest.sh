#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/census-claude/workers/874b3b046ca4316b
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/census-claude/workers/874b3b046ca4316b/driver.py guest --scratch "$D"
