#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/census-claude/workers/631ca45048c0efd6
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/census-claude/workers/631ca45048c0efd6/driver.py guest --scratch "$D"
