#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/census-claude/workers/82d340a6c24557e5
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/census-claude/workers/82d340a6c24557e5/driver.py guest --scratch "$D"
