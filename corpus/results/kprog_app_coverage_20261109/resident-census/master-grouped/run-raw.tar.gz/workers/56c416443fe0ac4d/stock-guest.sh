#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/census-claude/workers/56c416443fe0ac4d
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/census-claude/workers/56c416443fe0ac4d/driver.py guest --scratch "$D"
