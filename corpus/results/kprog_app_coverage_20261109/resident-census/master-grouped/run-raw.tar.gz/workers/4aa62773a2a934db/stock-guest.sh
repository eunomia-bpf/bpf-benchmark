#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/census-claude/workers/4aa62773a2a934db
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/census-claude/workers/4aa62773a2a934db/driver.py guest --scratch "$D"
