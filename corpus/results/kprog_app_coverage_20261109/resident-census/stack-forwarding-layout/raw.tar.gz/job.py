from pathlib import Path
import sys,json,tarfile,importlib.util,hashlib,traceback
R=Path("/workspaces/repository");D=Path("/var/tmp/kprog-tmp/A/stack-forwarding")
sys.path.insert(0,str(R/"kprog"));sys.path.insert(0,str(R/"kprog/x86/micro-prog"))
spec=importlib.util.spec_from_file_location("sparse_gen",R/"kprog/x86/micro-prog/generate_micro_sim_proofs.py")
gen=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gen;spec.loader.exec_module(gen)
from trusted_generation import context_kind
rows=json.loads((R/"corpus/results/kprog_app_coverage_20261109/resident-census/linked-progress-8/result.json").read_text())["programs"]
results=[]
for row in rows:
 svc=row["submission"]["service"];archive=Path(svc.get("failure_archive",svc.get("artifact_archive")))
 out=D/str(row["source_prog_id"]);out.mkdir()
 with tarfile.open(archive) as t:
  proof=t.extractfile("request/generated/trusted_x86.proof.o").read()
  (out/"trusted_x86.proof.o").write_bytes(proof)
  old=t.extractfile("request/generated/trusted_x86.bpf.c").read().decode()
  md=json.loads(t.extractfile("request/generation.metadata.json").read())
 insns,functions,exit_addr,rodata=gen.parse_native_linked_program("trusted_x86",out)
 text=gen.render_program("trusted_x86",insns,functions,kind=context_kind(md["prog_type"]),exit_addr=exit_addr,rodata16=rodata,program_section=md["section"],trusted_map_bindings=[dict(native_symbol=m["name"],value_offset=m.get("value_offset")) for m in md["maps"]])
 text=text.replace('#include "../x86_sim_local_bpf.h"','#include '+json.dumps(str(R/"kprog/x86/x86_sim_local_bpf.h")))
 (out/"trusted_x86.bpf.c").write_text(text)
 def words(s):return next(l for l in s.splitlines() if l.startswith("#define X86_SIM_STACK_VALUE_WORDS")).count("M(")-1
 def strip(s):return "\n".join(l for l in s.splitlines() if not l.startswith("#define X86_SIM_STACK_VALUE_WORDS"))
 r=dict(id=row["source_prog_id"],name=row["name"],stage=row["stage"],old_cells=words(old),new_cells=words(text),other_generated_lines_equal=strip(old)==strip(text),source_bytes=len(text),source_sha256=hashlib.sha256(text.encode()).hexdigest(),native_proof_sha256=hashlib.sha256(proof).hexdigest())
 results.append(r);print(json.dumps(r),flush=True)
 (D/"progress.json").write_text(json.dumps(results,indent=2)+"\n")
(D/"result.json").write_text(json.dumps(results,indent=2)+"\n")
