#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 8);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} cgroup_map SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 8192);
    __uint(map_flags, 0);
} start SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 32);
    __uint(max_entries, 8192);
    __uint(map_flags, 0);
} data SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_3 __asm__("5fe91415.rodata") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_cg SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} count_by_process SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} measure_latency SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_failed SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_errno SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_pid SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_10 __asm__("sys_exit.zero") SEC(".maps");
