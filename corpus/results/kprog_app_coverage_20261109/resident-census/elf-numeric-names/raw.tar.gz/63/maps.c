#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 8);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} birth SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 20);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} idents SEC(".maps");
struct {
    __uint(type, 4);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 2);
    __uint(map_flags, 0);
} events SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_3 __asm__("4d3a9b75.rodata") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_sport SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_dport SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} target_sports SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} target_dports SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} target_pid SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4106);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} target_family SEC(".maps");
