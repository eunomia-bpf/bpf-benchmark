#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 8);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} cgroup_map SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 20);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} infobyreq SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 24);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} start SEC(".maps");
struct {
    __uint(type, 4);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 2);
    __uint(map_flags, 0);
} events SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_4 __asm__("86e13806.rodata") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_cg SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_queued SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_dev SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_dev SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_9 __asm__("86e1380.kconfig") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} LINUX_KERNEL_VERSION SEC(".maps");
