#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 3);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 13);
    __uint(map_flags, 0);
} retkprobe_calls SEC(".maps");
struct {
    __uint(type, 4);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 2);
    __uint(map_flags, 0);
} tcpmon_map SEC(".maps");
struct {
    __uint(type, 27);
    __uint(key_size, 0);
    __uint(value_size, 0);
    __uint(max_entries, 4096);
    __uint(map_flags, 0);
} tg_rb_events SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 4352);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} buffer_heap_map SEC(".maps");
struct __trusted_inner_0 {
    __uint(type, 1);
    __uint(key_size, 25);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_0);
} string_maps_0 SEC(".maps");
struct __trusted_inner_1 {
    __uint(type, 1);
    __uint(key_size, 49);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_1);
} string_maps_1 SEC(".maps");
struct __trusted_inner_2 {
    __uint(type, 1);
    __uint(key_size, 73);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_2);
} string_maps_2 SEC(".maps");
struct __trusted_inner_3 {
    __uint(type, 1);
    __uint(key_size, 97);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_3);
} string_maps_3 SEC(".maps");
struct __trusted_inner_4 {
    __uint(type, 1);
    __uint(key_size, 121);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_4);
} string_maps_4 SEC(".maps");
struct __trusted_inner_5 {
    __uint(type, 1);
    __uint(key_size, 145);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_5);
} string_maps_5 SEC(".maps");
struct __trusted_inner_6 {
    __uint(type, 1);
    __uint(key_size, 258);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_6);
} string_maps_6 SEC(".maps");
struct __trusted_inner_7 {
    __uint(type, 1);
    __uint(key_size, 514);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_7);
} string_maps_7 SEC(".maps");
struct __trusted_inner_8 {
    __uint(type, 1);
    __uint(key_size, 1026);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_8);
} string_maps_8 SEC(".maps");
struct __trusted_inner_9 {
    __uint(type, 1);
    __uint(key_size, 2050);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_9);
} string_maps_9 SEC(".maps");
struct __trusted_inner_10 {
    __uint(type, 1);
    __uint(key_size, 4098);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_10);
} string_maps_10 SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 16384);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} string_maps_heap SEC(".maps");
struct __trusted_inner_11 {
    __uint(type, 11);
    __uint(key_size, 260);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 1);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_11);
} string_prefix_maps SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 260);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} string_prefix_maps_heap SEC(".maps");
struct __trusted_inner_12 {
    __uint(type, 11);
    __uint(key_size, 132);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 1);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_12);
} string_postfix_maps SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 132);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} string_postfix_maps_heap SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 100);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} substring_map SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} policy_conf SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 80);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} policy_stats SEC(".maps");
struct {
    __uint(type, 10);
    __uint(key_size, 12);
    __uint(value_size, 4);
    __uint(max_entries, 1024);
    __uint(map_flags, 0);
} tg_errmetrics_map SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 48);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_conf_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 6224);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} execve_msg_heap_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 792);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_binary_heap SEC(".maps");
struct {
    __uint(type, 9);
    __uint(key_size, 4);
    __uint(value_size, 792);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_parents_bin SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 896);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} execve_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 3);
    __uint(map_flags, 0);
} execve_map_stats SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 896);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} execve_val SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 4112);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} execve_heap SEC(".maps");
struct {
    __uint(type, 9);
    __uint(key_size, 8);
    __uint(value_size, 16);
    __uint(max_entries, 8192);
    __uint(map_flags, 0);
} tg_execve_joined_info_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 3);
    __uint(map_flags, 0);
} tg_execve_joined_info_map_stats SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 14336);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_stats_map SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 16);
    __uint(value_size, 24);
    __uint(max_entries, 1024);
    __uint(map_flags, 0);
} retprobe_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_ipv6_ext_heap SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 144);
    __uint(max_entries, 32768);
    __uint(map_flags, 0);
} tg_cgrps_tracking_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 144);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_cgrps_tracking_heap SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 4312);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_cgrps_msg_heap SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_cgtracker_map SEC(".maps");
struct __trusted_inner_13 {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_13);
} argfilter_maps SEC(".maps");
struct __trusted_inner_14 {
    __uint(type, 11);
    __uint(key_size, 8);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 1);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_14);
} addr4lpm_maps SEC(".maps");
struct __trusted_inner_15 {
    __uint(type, 11);
    __uint(key_size, 20);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 1);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 8);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_15);
} addr6lpm_maps SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} enforcer_data SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 12);
    __uint(value_size, 4);
    __uint(max_entries, 128);
    __uint(map_flags, 0);
} enforcer_missed_notifications SEC(".maps");
struct {
    __uint(type, 9);
    __uint(key_size, 224);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} ratelimit_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 352);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} ratelimit_heap SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 16384);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} heap_ro_zero SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 4104);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} heap SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 256);
    __uint(value_size, 8);
    __uint(max_entries, 1024);
    __uint(map_flags, 0);
} tg_mbset_map SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} tg_mbset_gen SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 25632);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} process_call_heap SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 4);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} override_tasks SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 32768);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} data_heap SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4096);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} filter_map SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 736);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} config_map SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 10);
    __uint(map_flags, 0);
} tg_mb_sel_opts SEC(".maps");
struct __trusted_inner_16 {
    __uint(type, 1);
    __uint(key_size, 256);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 10);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_16);
} tg_mb_paths SEC(".maps");
struct {
    __uint(type, 9);
    __uint(key_size, 16);
    __uint(value_size, 4104);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} fdinstall_map SEC(".maps");
struct {
    __uint(type, 9);
    __uint(key_size, 8);
    __uint(value_size, 16);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} socktrack_map SEC(".maps");
struct {
    __uint(type, 7);
    __uint(key_size, 4);
    __uint(value_size, 1016);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} stack_trace_map SEC(".maps");
struct __trusted_inner_17 {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 1);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 13);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 128);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_17);
} policy_filter_maps SEC(".maps");
struct __trusted_inner_18 {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 1);
    __uint(max_entries, 128);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 13);
    __uint(key_size, 8);
    __uint(value_size, 4);
    __uint(max_entries, 1024);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_18);
} policy_filter_cgroup_maps SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 8);
    __uint(value_size, 4100);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} sleepable_preload SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 2);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_65 __asm__("8242be00.rodata") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 2);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} CONFIG_ITER_NUM SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 2);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} PARENTS_MAP_ENABLED SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 11);
    __uint(max_entries, 1);
    __uint(map_flags, 128);
} __trusted_map_decl_68 __asm__(".rodata.str1.1") SEC(".maps");
