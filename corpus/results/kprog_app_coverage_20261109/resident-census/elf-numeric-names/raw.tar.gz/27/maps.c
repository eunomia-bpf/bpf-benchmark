#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 16);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} start SEC(".maps");
struct {
    __uint(type, 4);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 2);
    __uint(map_flags, 0);
} events SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 13);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_2 __asm__("34c994c5.rodata") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 13);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_pid SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 13);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_tgid SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 13);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_uid SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 13);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_failed SEC(".maps");
