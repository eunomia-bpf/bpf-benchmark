#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 8);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} cgroup_map SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} start SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 120);
    __uint(max_entries, 10240);
    __uint(map_flags, 0);
} hists SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} __trusted_map_decl_3 __asm__("34cefcb6.rodata") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} filter_cg SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_per_process SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_per_thread SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_per_pidns SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_ms SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 12);
    __uint(max_entries, 1);
    __uint(map_flags, 1152);
} targ_tgid SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 120);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} __trusted_map_decl_10 __asm__("34cefcb6.bss") SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 120);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} zero SEC(".maps");
