from pathlib import Path
import subprocess,concurrent.futures,json,collections,gzip,datetime,sys,traceback
D=Path(__file__).resolve().parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261109/resident-census/aee6-comparison'

def run(w):
 with (w/'controller.log').open('w') as log:
  r=subprocess.run([sys.executable,str(D/'driver.py'),'namespace','--scratch',str(w)],stdout=log,stderr=subprocess.STDOUT)
 (w/'controller.exit').write_text(str(r.returncode)+'\n')
 return w,r.returncode
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  futures=[pool.submit(run,w) for w in sorted(D.glob('shard-*'))]
  for f in concurrent.futures.as_completed(futures):
   w,code=f.result();print(w.name,code,flush=True)
 O.mkdir(parents=True,exist_ok=True)
 spec=__import__('importlib.util',fromlist=['']).spec_from_file_location('census',D/'driver.py');census=__import__('importlib.util',fromlist=['']).module_from_spec(spec);spec.loader.exec_module(census)
 baseline=json.loads((R/'corpus/results/kprog_app_coverage_20261109/resident-census/grouped-static/all-instances.json').read_text());before={(r['application'],r['source_prog_id']):r for r in baseline['programs']}
 rows=[]
 for w in sorted(D.glob('shard-*')):
  payload=json.loads((w/'stock-results.json').read_text())
  for row in payload['programs']:
   row['compiler_failures']=census.compiler_failures(row);row['failure_class']=census.failure_class(row);rows.append(row)
 rows.sort(key=lambda r:(r['application'],r['source_prog_id']))
 family=lambda r:('bpf_stack_storage' if r['failure_class'] in ['verifier_stack_access','compiler_stack_storage'] else r['failure_class'])
 changes=[]
 for row in rows:
  old=before[(row['application'],row['source_prog_id'])]
  changes.append(dict(application=row['application'],source_prog_id=row['source_prog_id'],name=row['name'],model_4f5=old,model_aee6={k:row[k] for k in ['stage','failure_class','generated','compiled']},aee6_family=family(row)))
 families=sorted(set(family(r) for r in rows)|set(r.get('failure_family',r['failure_class']) for r in before.values()))
 table=[]
 for label in families:
  group=[r for r in changes if r['model_4f5'].get('failure_family',r['model_4f5']['failure_class'])==label]
  table.append(dict(family=label,at_4f5=len(group),at_aee6=sum(family(r)==label for r in rows),same_family=sum(r['aee6_family']==label for r in group),aee6_installed=sum(r['model_aee6']['stage']=='installed' for r in group),transitions=dict(collections.Counter(r['aee6_family'] for r in group))))
 report=dict(model_head=json.loads((D/'provenance.json').read_text())['model_head'],programs=549,attempted=len(rows),stages=dict(collections.Counter(r['stage'] for r in rows)),families=table,instance_comparisons=changes,native_execution_requests=0)
 (O/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
 payload=gzip.compress((json.dumps(dict(programs=rows),indent=2)+'\n').encode(),mtime=0)
 for i,start in enumerate(range(0,len(payload),48000000)):(O/('raw-outcomes.json.gz'+('.part'+str(i).zfill(3) if len(payload)>48000000 else ''))).write_bytes(payload[start:start+48000000])
 lines=['# Model aee6b236d against 4f5b7ae6d','','All549originalapplication/program-ID pairs retain their input identities. The aee6 pass submits every instance separately once; the4f5 reference retains274individual rows and275body-weighted rows. Original source-resource preparation and native-link runtime are held at their retained baseline versions. Native execution requests:0.','','| Family | 4f5 instances | aee6 instances | 4f5 members accepted by aee6 | aee6 outcome of the 4f5 members |','| --- | ---: | ---: | ---: | --- |']
 for r in table:lines.append('| '+r['family']+' | '+str(r['at_4f5'])+' | '+str(r['at_aee6'])+' | '+str(r['aee6_installed'])+' | '+json.dumps(r['transitions'],sort_keys=True)+' |')
 lines+=['','The revisions contain several intervening changes. Counts describe observed version transitions; the class of a former rejection identifies the observed family. comparison.json retains each instance and both outcomes. Resource preparation failures retain their original reached phase.','']
 (O/'README.md').write_text('\n'.join(lines))
 (O/'provenance.json').write_text((D/'provenance.json').read_text())
 (D/'complete.json').write_text(json.dumps(dict(attempted=len(rows),stages=report['stages'],raw_gzip_bytes=len(payload)),indent=2)+'\n')
 print('COMPLETE',report['stages'],flush=True)
except BaseException:
 (D/'error.txt').write_text(traceback.format_exc());raise
