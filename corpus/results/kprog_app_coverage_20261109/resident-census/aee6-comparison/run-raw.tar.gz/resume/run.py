from pathlib import Path
import concurrent.futures,subprocess,os,sys,json
N=Path(__file__).resolve().parent;D=N.parent
os.environ['PATH']=str(N/'bin')+':'+os.environ['PATH']
def run(w):
 with (w/'controller.log').open('w') as f:r=subprocess.run([sys.executable,str(w/'driver.py'),'namespace','--scratch',str(w)],stdout=f,stderr=subprocess.STDOUT)
 (w/'controller.exit').write_text(str(r.returncode)+'\n');print(w.name,r.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(run,sorted(N.glob('shard-*'))))
(N/'complete.json').write_text(json.dumps({'complete':True})+'\n')
