#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/A/census-aee6/shard-6
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /var/tmp/kprog-tmp/A/census-aee6/shard-6/driver.py guest --scratch "$D"

dmesg > "$D/dmesg"
