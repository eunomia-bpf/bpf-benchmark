#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retkprobe_calls[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
extern __u8 substring_map[] __ksym;
SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d:
	/* 0xd: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: sub    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_12:
	/* 0x12: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_15:
	/* 0x15: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_1d:
	/* 0x1d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_24:
	/* 0x24: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_29:
	/* 0x29: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2e:
	/* 0x2e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_31:
	/* 0x31: call   36 <generic_retkprobe_filter_arg+0x36> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36:
	/* 0x36: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_39:
	/* 0x39: je     3a3 <generic_retkprobe_filter_arg+0x3a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39, 0x3a3, x86_l_3a3);
x86_l_3f:
	/* 0x3f: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_42:
	/* 0x42: mov    r12d,DWORD PTR [rax+0x5f00] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_49:
	/* 0x49: lea    rsi,[rax+0x5ef8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_50:
	/* 0x50: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)filter_map));
x86_l_57:
	/* 0x57: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5c:
	/* 0x5c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_5f:
	/* 0x5f: call   64 <generic_retkprobe_filter_arg+0x64> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_64:
	/* 0x64: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_67:
	/* 0x67: je     382 <generic_retkprobe_filter_arg+0x382> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67, 0x382, x86_l_382);
x86_l_6d:
	/* 0x6d: cmp    BYTE PTR [r14+0x5ee0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104316165685248ULL);
x86_l_75:
	/* 0x75: je     382 <generic_retkprobe_filter_arg+0x382> */
	X86_SIM_X86_JCC(X86_CC_E, 0x75, 0x382, x86_l_382);
x86_l_7b:
	/* 0x7b: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_7e:
	/* 0x7e: mov    eax,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_32);
x86_l_81:
	/* 0x81: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_84:
	/* 0x84: cmp    BYTE PTR [r14+rax*1+0x5ec1],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 104183021699072ULL);
x86_l_8d:
	/* 0x8d: je     c7 <generic_retkprobe_filter_arg+0xc7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8d, 0xc7, x86_l_c7);
x86_l_8f:
	/* 0x8f: mov    eax,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_91:
	/* 0x91: mov    ecx,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_96:
	/* 0x96: lea    r13,[rcx+rax*4] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_9a:
	/* 0x9a: add    r13,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_9e:
	/* 0x9e: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_a1:
	/* 0xa1: mov    QWORD PTR [rsp+0x10],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a6:
	/* 0xa6: and    r13d,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_ad:
	/* 0xad: cmp    DWORD PTR [r15+r13*1],0x19 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 25ULL);
x86_l_b2:
	/* 0xb2: jae    11c <generic_retkprobe_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xb2, 0x11c, x86_l_11c);
x86_l_b4:
	/* 0xb4: cmp    r13,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 1ULL);
x86_l_b8:
	/* 0xb8: je     382 <generic_retkprobe_filter_arg+0x382> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8, 0x382, x86_l_382);
x86_l_be:
	/* 0xbe: test   r13d,r13d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32);
x86_l_c1:
	/* 0xc1: jne    35a <generic_retkprobe_filter_arg+0x35a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc1, 0x35a, x86_l_35a);
x86_l_c7:
	/* 0xc7: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_cb:
	/* 0xcb: jg     ec <generic_retkprobe_filter_arg+0xec> */
	X86_SIM_X86_JCC(X86_CC_G, 0xcb, 0xec, x86_l_ec);
x86_l_cd:
	/* 0xcd: cmp    r12d,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4294967295ULL);
x86_l_d1:
	/* 0xd1: je     3b8 <generic_retkprobe_filter_arg+0x3b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd1, 0x3b8, x86_l_3b8);
x86_l_d7:
	/* 0xd7: test   r12d,r12d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32);
x86_l_da:
	/* 0xda: je     3c5 <generic_retkprobe_filter_arg+0x3c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda, 0x3c5, x86_l_3c5);
x86_l_e0:
	/* 0xe0: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_e4:
	/* 0xe4: je     3d5 <generic_retkprobe_filter_arg+0x3d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4, 0x3d5, x86_l_3d5);
x86_l_ea:
	/* 0xea: jmp    10a <generic_retkprobe_filter_arg+0x10a> */
	X86_SIM_X86_JMP(0xea, 0x10a, x86_l_10a);
x86_l_ec:
	/* 0xec: cmp    r12d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 2ULL);
x86_l_f0:
	/* 0xf0: je     3e5 <generic_retkprobe_filter_arg+0x3e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf0, 0x3e5, x86_l_3e5);
x86_l_f6:
	/* 0xf6: cmp    r12d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 3ULL);
x86_l_fa:
	/* 0xfa: je     3f5 <generic_retkprobe_filter_arg+0x3f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfa, 0x3f5, x86_l_3f5);
x86_l_100:
	/* 0x100: cmp    r12d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4ULL);
x86_l_104:
	/* 0x104: je     405 <generic_retkprobe_filter_arg+0x405> */
	X86_SIM_X86_JCC(X86_CC_E, 0x104, 0x405, x86_l_405);
x86_l_10a:
	/* 0x10a: cmp    r12d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4ULL);
x86_l_10e:
	/* 0x10e: jg     43d <generic_retkprobe_filter_arg+0x43d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x10e, 0x43d, x86_l_43d);
x86_l_114:
	/* 0x114: inc    r12d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_117:
	/* 0x117: jmp    415 <generic_retkprobe_filter_arg+0x415> */
	X86_SIM_X86_JMP(0x117, 0x415, x86_l_415);
x86_l_11c:
	/* 0x11c: lea    rax,[r15+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_120:
	/* 0x120: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_125:
	/* 0x125: mov    ebp,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 1ULL);
x86_l_12a:
	/* 0x12a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12f:
	/* 0x12f: mov    edi,DWORD PTR [rax+rbp*4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 0ULL);
x86_l_132:
	/* 0x132: test   edi,0x3ff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RDI, X86_WIDTH_32, 1023ULL);
x86_l_138:
	/* 0x138: je     b4 <generic_retkprobe_filter_arg+0xb4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x138, 0xb4, x86_l_b4);
x86_l_13e:
	/* 0x13e: add    edi,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_142:
	/* 0x142: and    edi,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_148:
	/* 0x148: mov    ecx,DWORD PTR [r15+rdi*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 4ULL);
x86_l_14d:
	/* 0x14d: cmp    ecx,0x23 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 35ULL);
x86_l_150:
	/* 0x150: je     c7 <generic_retkprobe_filter_arg+0xc7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x150, 0xc7, x86_l_c7);
x86_l_156:
	/* 0x156: add    rdi,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_159:
	/* 0x159: mov    eax,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b:
	/* 0x15b: cmp    rax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4ULL);
x86_l_15f:
	/* 0x15f: ja     c7 <generic_retkprobe_filter_arg+0xc7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x15f, 0xc7, x86_l_c7);
x86_l_165:
	/* 0x165: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_16e:
	/* 0x16e: jne    c7 <generic_retkprobe_filter_arg+0xc7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16e, 0xc7, x86_l_c7);
x86_l_174:
	/* 0x174: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_17c:
	/* 0x17c: and    eax,0x7ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_181:
	/* 0x181: lea    rsi,[r14+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_185:
	/* 0x185: add    rsi,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_18c:
	/* 0x18c: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_18f:
	/* 0x18f: cmp    eax,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_192:
	/* 0x192: jle    1b3 <generic_retkprobe_filter_arg+0x1b3> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x192, 0x1b3, x86_l_1b3);
x86_l_194:
	/* 0x194: cmp    eax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_197:
	/* 0x197: jg     1e3 <generic_retkprobe_filter_arg+0x1e3> */
	X86_SIM_X86_JCC(X86_CC_G, 0x197, 0x1e3, x86_l_1e3);
x86_l_199:
	/* 0x199: lea    edx,[rax-0x1c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551588ULL);
x86_l_19c:
	/* 0x19c: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_19f:
	/* 0x19f: jb     229 <generic_retkprobe_filter_arg+0x229> */
	X86_SIM_X86_JCC(X86_CC_B, 0x19f, 0x229, x86_l_229);
x86_l_1a5:
	/* 0x1a5: cmp    eax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_1a8:
	/* 0x1a8: je     30c <generic_retkprobe_filter_arg+0x30c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8, 0x30c, x86_l_30c);
x86_l_1ae:
	/* 0x1ae: jmp    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JMP(0x1ae, 0x348, x86_l_348);
x86_l_1b3:
	/* 0x1b3: cmp    eax,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 9ULL);
x86_l_1b6:
	/* 0x1b6: jle    209 <generic_retkprobe_filter_arg+0x209> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1b6, 0x209, x86_l_209);
x86_l_1b8:
	/* 0x1b8: lea    edx,[rax-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_1bb:
	/* 0x1bb: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_1be:
	/* 0x1be: jb     229 <generic_retkprobe_filter_arg+0x229> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1be, 0x229, x86_l_229);
x86_l_1c0:
	/* 0x1c0: lea    ecx,[rax-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_1c3:
	/* 0x1c3: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1c6:
	/* 0x1c6: jb     30c <generic_retkprobe_filter_arg+0x30c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c6, 0x30c, x86_l_30c);
x86_l_1cc:
	/* 0x1cc: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1cf:
	/* 0x1cf: jne    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cf, 0x348, x86_l_348);
x86_l_1d5:
	/* 0x1d5: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1d9:
	/* 0x1d9: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_498, 0x1deULL);
x86_l_1de:
	/* 0x1de: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x1de, 0x33f, x86_l_33f);
x86_l_1e3:
	/* 0x1e3: cmp    eax,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 41ULL);
x86_l_1e6:
	/* 0x1e6: jg     2fb <generic_retkprobe_filter_arg+0x2fb> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e6, 0x2fb, x86_l_2fb);
x86_l_1ec:
	/* 0x1ec: lea    ecx,[rax-0x26] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_1ef:
	/* 0x1ef: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1f2:
	/* 0x1f2: jb     2b6 <generic_retkprobe_filter_arg+0x2b6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f2, 0x2b6, x86_l_2b6);
x86_l_1f8:
	/* 0x1f8: add    eax,0xffffffd8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 4294967256ULL);
x86_l_1fb:
	/* 0x1fb: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1fe:
	/* 0x1fe: jb     2ac <generic_retkprobe_filter_arg+0x2ac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1fe, 0x2ac, x86_l_2ac);
x86_l_204:
	/* 0x204: jmp    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JMP(0x204, 0x348, x86_l_348);
x86_l_209:
	/* 0x209: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_20c:
	/* 0x20c: jg     299 <generic_retkprobe_filter_arg+0x299> */
	X86_SIM_X86_JCC(X86_CC_G, 0x20c, 0x299, x86_l_299);
x86_l_212:
	/* 0x212: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_215:
	/* 0x215: je     229 <generic_retkprobe_filter_arg+0x229> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215, 0x229, x86_l_229);
x86_l_217:
	/* 0x217: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_21a:
	/* 0x21a: je     329 <generic_retkprobe_filter_arg+0x329> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a, 0x329, x86_l_329);
x86_l_220:
	/* 0x220: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_223:
	/* 0x223: jne    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x223, 0x348, x86_l_348);
x86_l_229:
	/* 0x229: cmp    eax,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 11ULL);
x86_l_22c:
	/* 0x22c: jle    276 <generic_retkprobe_filter_arg+0x276> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x22c, 0x276, x86_l_276);
x86_l_22e:
	/* 0x22e: cmp    eax,0x24 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 36ULL);
x86_l_231:
	/* 0x231: ja     313 <generic_retkprobe_filter_arg+0x313> */
	X86_SIM_X86_JCC(X86_CC_A, 0x231, 0x313, x86_l_313);
x86_l_237:
	/* 0x237: mov    edx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_239:
	/* 0x239: movabs r8,0x1e00000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_64, 128849018880ULL);
x86_l_243:
	/* 0x243: bt     r8,rdx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RDX, X86_WIDTH_64);
x86_l_247:
	/* 0x247: jb     2bd <generic_retkprobe_filter_arg+0x2bd> */
	X86_SIM_X86_JCC(X86_CC_B, 0x247, 0x2bd, x86_l_2bd);
x86_l_249:
	/* 0x249: mov    ecx,0x60000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1610612736ULL);
x86_l_24e:
	/* 0x24e: bt     rcx,rdx */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_252:
	/* 0x252: jb     322 <generic_retkprobe_filter_arg+0x322> */
	X86_SIM_X86_JCC(X86_CC_B, 0x252, 0x322, x86_l_322);
x86_l_258:
	/* 0x258: movabs rcx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 6442450944ULL);
x86_l_262:
	/* 0x262: bt     rcx,rdx */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_266:
	/* 0x266: jae    313 <generic_retkprobe_filter_arg+0x313> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x266, 0x313, x86_l_313);
x86_l_26c:
	/* 0x26c: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_563, 0x271ULL);
x86_l_271:
	/* 0x271: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x271, 0x33f, x86_l_33f);
x86_l_276:
	/* 0x276: lea    ecx,[rax-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_279:
	/* 0x279: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_27c:
	/* 0x27c: jb     33a <generic_retkprobe_filter_arg+0x33a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27c, 0x33a, x86_l_33a);
x86_l_282:
	/* 0x282: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_285:
	/* 0x285: je     31b <generic_retkprobe_filter_arg+0x31b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x285, 0x31b, x86_l_31b);
x86_l_28b:
	/* 0x28b: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_28e:
	/* 0x28e: je     31b <generic_retkprobe_filter_arg+0x31b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28e, 0x31b, x86_l_31b);
x86_l_294:
	/* 0x294: jmp    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JMP(0x294, 0x348, x86_l_348);
x86_l_299:
	/* 0x299: cmp    eax,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 5ULL);
x86_l_29c:
	/* 0x29c: je     2ac <generic_retkprobe_filter_arg+0x2ac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29c, 0x2ac, x86_l_2ac);
x86_l_29e:
	/* 0x29e: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_2a1:
	/* 0x2a1: je     2b6 <generic_retkprobe_filter_arg+0x2b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a1, 0x2b6, x86_l_2b6);
x86_l_2a3:
	/* 0x2a3: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_2a6:
	/* 0x2a6: jne    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a6, 0x348, x86_l_348);
x86_l_2ac:
	/* 0x2ac: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_5b6, 0x2b1ULL);
x86_l_2b1:
	/* 0x2b1: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x2b1, 0x33f, x86_l_33f);
x86_l_2b6:
	/* 0x2b6: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_2bb:
	/* 0x2bb: jmp    32e <generic_retkprobe_filter_arg+0x32e> */
	X86_SIM_X86_JMP(0x2bb, 0x32e, x86_l_32e);
x86_l_2bd:
	/* 0x2bd: cmp    ecx,0x1e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 30ULL);
x86_l_2c0:
	/* 0x2c0: jne    33a <generic_retkprobe_filter_arg+0x33a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c0, 0x33a, x86_l_33a);
x86_l_2c2:
	/* 0x2c2: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c5:
	/* 0x2c5: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_2c8:
	/* 0x2c8: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_2ca:
	/* 0x2ca: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_2d3:
	/* 0x2d3: jne    c7 <generic_retkprobe_filter_arg+0xc7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d3, 0xc7, x86_l_c7);
x86_l_2d9:
	/* 0x2d9: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dc:
	/* 0x2dc: mov    rdx,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_2e4:
	/* 0x2e4: and    edx,0x7ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_2ea:
	/* 0x2ea: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2ec:
	/* 0x2ec: andn   rcx,rcx,QWORD PTR [r14+rdx*1+0x90] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RCX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_R14)), 618475290624ULL);
x86_l_2f6:
	/* 0x2f6: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_2f9:
	/* 0x2f9: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x2f9, 0x33f, x86_l_33f);
x86_l_2fb:
	/* 0x2fb: cmp    eax,0x2a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 42ULL);
x86_l_2fe:
	/* 0x2fe: je     30c <generic_retkprobe_filter_arg+0x30c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fe, 0x30c, x86_l_30c);
x86_l_300:
	/* 0x300: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_303:
	/* 0x303: jne    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x303, 0x348, x86_l_348);
x86_l_305:
	/* 0x305: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_920, 0x30aULL);
x86_l_30a:
	/* 0x30a: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x30a, 0x33f, x86_l_33f);
x86_l_30c:
	/* 0x30c: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_498, 0x311ULL);
x86_l_311:
	/* 0x311: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x311, 0x33f, x86_l_33f);
x86_l_313:
	/* 0x313: lea    ecx,[rax-0xc] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_316:
	/* 0x316: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_319:
	/* 0x319: jae    335 <generic_retkprobe_filter_arg+0x335> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x319, 0x335, x86_l_335);
x86_l_31b:
	/* 0x31b: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_9d7, 0x320ULL);
x86_l_320:
	/* 0x320: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x320, 0x33f, x86_l_33f);
x86_l_322:
	/* 0x322: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a2a, 0x327ULL);
x86_l_327:
	/* 0x327: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x327, 0x33f, x86_l_33f);
x86_l_329:
	/* 0x329: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_32e:
	/* 0x32e: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a7d, 0x333ULL);
x86_l_333:
	/* 0x333: jmp    33f <generic_retkprobe_filter_arg+0x33f> */
	X86_SIM_X86_JMP(0x333, 0x33f, x86_l_33f);
x86_l_335:
	/* 0x335: cmp    eax,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 28ULL);
x86_l_338:
	/* 0x338: jne    348 <generic_retkprobe_filter_arg+0x348> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x338, 0x348, x86_l_348);
x86_l_33a:
	/* 0x33a: call   0 <generic_retkprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_b24, 0x33fULL);
x86_l_33f:
	/* 0x33f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_342:
	/* 0x342: je     c7 <generic_retkprobe_filter_arg+0xc7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x342, 0xc7, x86_l_c7);
x86_l_348:
	/* 0x348: inc    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_34b:
	/* 0x34b: cmp    rbp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 6ULL);
x86_l_34f:
	/* 0x34f: jne    12a <generic_retkprobe_filter_arg+0x12a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34f, 0x12a, x86_l_12a);
x86_l_355:
	/* 0x355: jmp    b4 <generic_retkprobe_filter_arg+0xb4> */
	X86_SIM_X86_JMP(0x355, 0xb4, x86_l_b4);
x86_l_35a:
	/* 0x35a: mov    DWORD PTR [r14+0x5f04],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_361:
	/* 0x361: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)retkprobe_calls));
x86_l_368:
	/* 0x368: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_36d:
	/* 0x36d: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_372:
	/* 0x372: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_375:
	/* 0x375: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_37a:
	/* 0x37a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_37d:
	/* 0x37d: call   382 <generic_retkprobe_filter_arg+0x382> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_382:
	/* 0x382: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)retkprobe_calls));
x86_l_389:
	/* 0x389: mov    ecx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_38e:
	/* 0x38e: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_393:
	/* 0x393: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_396:
	/* 0x396: mov    edx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_39b:
	/* 0x39b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_39e:
	/* 0x39e: call   3a3 <generic_retkprobe_filter_arg+0x3a3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3a3:
	/* 0x3a3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3a5:
	/* 0x3a5: add    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_3a9:
	/* 0x3a9: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3aa:
	/* 0x3aa: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3ac:
	/* 0x3ac: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3ae:
	/* 0x3ae: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3b0:
	/* 0x3b0: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3b2:
	/* 0x3b2: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3b3:
	/* 0x3b3: jmp    3b8 <generic_retkprobe_filter_arg+0x3b8> */
	X86_SIM_X86_RET();
x86_l_3b8:
	/* 0x3b8: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3bb:
	/* 0x3bb: cmp    BYTE PTR [r14+0x5ec1],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104183021699072ULL);
x86_l_3c3:
	/* 0x3c3: jne    415 <generic_retkprobe_filter_arg+0x415> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c3, 0x415, x86_l_415);
x86_l_3c5:
	/* 0x3c5: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_3cb:
	/* 0x3cb: cmp    BYTE PTR [r14+0x5ec2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104187316666368ULL);
x86_l_3d3:
	/* 0x3d3: jne    415 <generic_retkprobe_filter_arg+0x415> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d3, 0x415, x86_l_415);
x86_l_3d5:
	/* 0x3d5: mov    r12d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 2ULL);
x86_l_3db:
	/* 0x3db: cmp    BYTE PTR [r14+0x5ec3],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104191611633664ULL);
x86_l_3e3:
	/* 0x3e3: jne    415 <generic_retkprobe_filter_arg+0x415> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e3, 0x415, x86_l_415);
x86_l_3e5:
	/* 0x3e5: mov    r12d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 3ULL);
x86_l_3eb:
	/* 0x3eb: cmp    BYTE PTR [r14+0x5ec4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104195906600960ULL);
x86_l_3f3:
	/* 0x3f3: jne    415 <generic_retkprobe_filter_arg+0x415> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f3, 0x415, x86_l_415);
x86_l_3f5:
	/* 0x3f5: mov    r12d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4ULL);
x86_l_3fb:
	/* 0x3fb: cmp    BYTE PTR [r14+0x5ec5],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104200201568256ULL);
x86_l_403:
	/* 0x403: jne    415 <generic_retkprobe_filter_arg+0x415> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x403, 0x415, x86_l_415);
x86_l_405:
	/* 0x405: mov    r12d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 5ULL);
x86_l_40b:
	/* 0x40b: cmp    BYTE PTR [r14+0x5ec6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104204496535552ULL);
x86_l_413:
	/* 0x413: je     43d <generic_retkprobe_filter_arg+0x43d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x413, 0x43d, x86_l_43d);
x86_l_415:
	/* 0x415: mov    DWORD PTR [r14+0x5f00],r12d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_41c:
	/* 0x41c: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)retkprobe_calls));
x86_l_423:
	/* 0x423: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_428:
	/* 0x428: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_42d:
	/* 0x42d: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_430:
	/* 0x430: mov    edx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_435:
	/* 0x435: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_438:
	/* 0x438: call   43d <generic_retkprobe_filter_arg+0x43d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_43d:
	/* 0x43d: mov    rbx,QWORD PTR [r14+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_441:
	/* 0x441: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_446:
	/* 0x446: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_449:
	/* 0x449: call   44e <generic_retkprobe_filter_arg+0x44e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_44e:
	/* 0x44e: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_453:
	/* 0x453: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_458:
	/* 0x458: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)retprobe_map));
x86_l_45f:
	/* 0x45f: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_464:
	/* 0x464: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_469:
	/* 0x469: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_46c:
	/* 0x46c: call   471 <generic_retkprobe_filter_arg+0x471> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_471:
	/* 0x471: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_474:
	/* 0x474: je     3a3 <generic_retkprobe_filter_arg+0x3a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x474, 0x3a3, x86_l_3a3);
x86_l_47a:
	/* 0x47a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)retprobe_map));
x86_l_481:
	/* 0x481: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_486:
	/* 0x486: mov    eax,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_48b:
	/* 0x48b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_48e:
	/* 0x48e: call   493 <generic_retkprobe_filter_arg+0x493> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_493:
	/* 0x493: jmp    3a3 <generic_retkprobe_filter_arg+0x3a3> */
	X86_SIM_X86_JMP(0x493, 0x3a3, x86_l_3a3);
x86_l_2652:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_498 */
x86_l_498:
	/* 0x498: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_499:
	/* 0x499: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_49c:
	/* 0x49c: mov    edx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49e:
	/* 0x49e: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4a1:
	/* 0x4a1: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_4a3:
	/* 0x4a3: jne    4b7 <filter_file_buf+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4a3, 0x4b7, x86_l_4b7);
x86_l_4a5:
	/* 0x4a5: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_4a7:
	/* 0x4a7: and    eax,0xfffffffe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_4aa:
	/* 0x4aa: cmp    eax,0x24 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 36ULL);
x86_l_4ad:
	/* 0x4ad: je     4b7 <filter_file_buf+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4ad, 0x4b7, x86_l_4b7);
x86_l_4af:
	/* 0x4af: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4b1:
	/* 0x4b1: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4b2:
	/* 0x4b2: jmp    4b7 <filter_file_buf+0x1f> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_4b7:
	/* 0x4b7: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_4ba:
	/* 0x4ba: ja     4f6 <filter_file_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4ba, 0x4f6, x86_l_4f6);
x86_l_4bc:
	/* 0x4bc: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_4be:
	/* 0x4be: mov    edi,0x4000100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 67109120ULL);
x86_l_4c3:
	/* 0x4c3: bt     rdi,rax */
	X86_SIM_L_EXEC_BT(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4c7:
	/* 0x4c7: jb     52a <filter_file_buf+0x92> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4c7, 0x52a, x86_l_52a);
x86_l_4c9:
	/* 0x4c9: mov    edi,0x8000200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 134218240ULL);
x86_l_4ce:
	/* 0x4ce: bt     rdi,rax */
	X86_SIM_L_EXEC_BT(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4d2:
	/* 0x4d2: jb     514 <filter_file_buf+0x7c> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4d2, 0x514, x86_l_514);
x86_l_4d4:
	/* 0x4d4: movabs rdi,0x3000000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_64, 206158430208ULL);
x86_l_4de:
	/* 0x4de: bt     rdi,rax */
	X86_SIM_L_EXEC_BT(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4e2:
	/* 0x4e2: jae    4f6 <filter_file_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x4e2, 0x4f6, x86_l_4f6);
x86_l_4e4:
	/* 0x4e4: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_4e7:
	/* 0x4e7: call   25a0 <filter_file_type> */
	X86_SIM_X86_CALL(x86_l_25a0, 0x4ecULL);
x86_l_4ec:
	/* 0x4ec: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4ef:
	/* 0x4ef: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_4f2:
	/* 0x4f2: jbe    547 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4f2, 0x547, x86_l_547);
x86_l_4f4:
	/* 0x4f4: jmp    55d <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x4f4, 0x55d, x86_l_55d);
x86_l_4f6:
	/* 0x4f6: lea    eax,[rcx-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_4f9:
	/* 0x4f9: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_4fc:
	/* 0x4fc: jae    540 <filter_file_buf+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x4fc, 0x540, x86_l_540);
x86_l_4fe:
	/* 0x4fe: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_502:
	/* 0x502: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_505:
	/* 0x505: call   1246 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1246, 0x50aULL);
x86_l_50a:
	/* 0x50a: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_50d:
	/* 0x50d: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_510:
	/* 0x510: jbe    547 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x510, 0x547, x86_l_547);
x86_l_512:
	/* 0x512: jmp    55d <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x512, 0x55d, x86_l_55d);
x86_l_514:
	/* 0x514: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_518:
	/* 0x518: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_51b:
	/* 0x51b: call   102c <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_102c, 0x520ULL);
x86_l_520:
	/* 0x520: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_523:
	/* 0x523: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_526:
	/* 0x526: jbe    547 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x526, 0x547, x86_l_547);
x86_l_528:
	/* 0x528: jmp    55d <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x528, 0x55d, x86_l_55d);
x86_l_52a:
	/* 0x52a: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_52e:
	/* 0x52e: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_531:
	/* 0x531: call   118a <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_118a, 0x536ULL);
x86_l_536:
	/* 0x536: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_539:
	/* 0x539: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_53c:
	/* 0x53c: jbe    547 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x53c, 0x547, x86_l_547);
x86_l_53e:
	/* 0x53e: jmp    55d <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x53e, 0x55d, x86_l_55d);
x86_l_540:
	/* 0x540: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_542:
	/* 0x542: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_545:
	/* 0x545: ja     55d <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x545, 0x55d, x86_l_55d);
x86_l_547:
	/* 0x547: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_549:
	/* 0x549: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_553:
	/* 0x553: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_557:
	/* 0x557: jae    55d <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x557, 0x55d, x86_l_55d);
x86_l_559:
	/* 0x559: xor    rax,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_55d:
	/* 0x55d: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_55e:
	/* 0x55e: jmp    563 <filter_8ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_563 */
x86_l_563:
	/* 0x563: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_564:
	/* 0x564: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_567:
	/* 0x567: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_569:
	/* 0x569: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_56d:
	/* 0x56d: ja     5b0 <filter_8ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x56d, 0x5b0, x86_l_5b0);
x86_l_56f:
	/* 0x56f: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_574:
	/* 0x574: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_578:
	/* 0x578: jae    585 <filter_8ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x578, 0x585, x86_l_585);
x86_l_57a:
	/* 0x57a: call   2120 <filter_8ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_2120, 0x57fULL);
x86_l_57f:
	/* 0x57f: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_580:
	/* 0x580: jmp    585 <filter_8ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_585:
	/* 0x585: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_58a:
	/* 0x58a: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_58e:
	/* 0x58e: jb     5ab <filter_8ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x58e, 0x5ab, x86_l_5ab);
x86_l_590:
	/* 0x590: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_59a:
	/* 0x59a: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_59e:
	/* 0x59e: jae    5b0 <filter_8ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x59e, 0x5b0, x86_l_5b0);
x86_l_5a0:
	/* 0x5a0: call   2346 <filter_8ty_range> */
	X86_SIM_X86_CALL(x86_l_2346, 0x5a5ULL);
x86_l_5a5:
	/* 0x5a5: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5a6:
	/* 0x5a6: jmp    5ab <filter_8ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_5ab:
	/* 0x5ab: call   2506 <filter_8ty_map> */
	X86_SIM_X86_CALL(x86_l_2506, 0x5b0ULL);
x86_l_5b0:
	/* 0x5b0: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5b1:
	/* 0x5b1: jmp    5b6 <filter_inet> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_5b6 */
x86_l_5b6:
	/* 0x5b6: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5b8:
	/* 0x5b8: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5ba:
	/* 0x5ba: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5bc:
	/* 0x5bc: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5bd:
	/* 0x5bd: sub    rsp,0x48 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_5c1:
	/* 0x5c1: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_5ca:
	/* 0x5ca: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_5d3:
	/* 0x5d3: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_5dc:
	/* 0x5dc: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_5e5:
	/* 0x5e5: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_5ee:
	/* 0x5ee: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5f5:
	/* 0x5f5: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_5fd:
	/* 0x5fd: mov    edx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_600:
	/* 0x600: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_602:
	/* 0x602: cmp    edx,0x27 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 39ULL);
x86_l_605:
	/* 0x605: jg     61d <filter_inet+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x605, 0x61d, x86_l_61d);
x86_l_607:
	/* 0x607: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_60a:
	/* 0x60a: je     6a2 <filter_inet+0xec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x60a, 0x6a2, x86_l_6a2);
x86_l_610:
	/* 0x610: mov    r8,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RSI, X86_WIDTH_64);
x86_l_613:
	/* 0x613: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_616:
	/* 0x616: je     62e <filter_inet+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x616, 0x62e, x86_l_62e);
x86_l_618:
	/* 0x618: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x618, 0x8d8, x86_l_8d8);
x86_l_61d:
	/* 0x61d: cmp    edx,0x28 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 40ULL);
x86_l_620:
	/* 0x620: je     67a <filter_inet+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x620, 0x67a, x86_l_67a);
x86_l_622:
	/* 0x622: mov    r8,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RSI, X86_WIDTH_64);
x86_l_625:
	/* 0x625: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_628:
	/* 0x628: jne    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x628, 0x8d8, x86_l_8d8);
x86_l_62e:
	/* 0x62e: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_631:
	/* 0x631: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_633:
	/* 0x633: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_636:
	/* 0x636: jle    6af <filter_inet+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x636, 0x6af, x86_l_6af);
x86_l_638:
	/* 0x638: cmp    ecx,0x17 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 23ULL);
x86_l_63b:
	/* 0x63b: jg     65a <filter_inet+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x63b, 0x65a, x86_l_65a);
x86_l_63d:
	/* 0x63d: lea    edx,[rcx-0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_640:
	/* 0x640: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_643:
	/* 0x643: jb     700 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x643, 0x700, x86_l_700);
x86_l_649:
	/* 0x649: lea    edx,[rcx-0x16] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_64c:
	/* 0x64c: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_64f:
	/* 0x64f: jb     6fa <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x64f, 0x6fa, x86_l_6fa);
x86_l_655:
	/* 0x655: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x655, 0x8d8, x86_l_8d8);
x86_l_65a:
	/* 0x65a: cmp    ecx,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 27ULL);
x86_l_65d:
	/* 0x65d: jg     73d <filter_inet+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x65d, 0x73d, x86_l_73d);
x86_l_663:
	/* 0x663: cmp    ecx,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 24ULL);
x86_l_666:
	/* 0x666: je     770 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x666, 0x770, x86_l_770);
x86_l_66c:
	/* 0x66c: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_66f:
	/* 0x66f: je     766 <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x66f, 0x766, x86_l_766);
x86_l_675:
	/* 0x675: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x675, 0x8d8, x86_l_8d8);
x86_l_67a:
	/* 0x67a: movzx  eax,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_67d:
	/* 0x67d: mov    WORD PTR [rsp+0x46],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_682:
	/* 0x682: movzx  eax,WORD PTR [rsi+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_686:
	/* 0x686: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_68b:
	/* 0x68b: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_68f:
	/* 0x68f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_694:
	/* 0x694: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_698:
	/* 0x698: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_69d:
	/* 0x69d: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6a2:
	/* 0x6a2: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6a5:
	/* 0x6a5: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_6a8:
	/* 0x6a8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6aa:
	/* 0x6aa: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_6ad:
	/* 0x6ad: jg     638 <filter_inet+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6ad, 0x638, x86_l_638);
x86_l_6af:
	/* 0x6af: cmp    ecx,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 15ULL);
x86_l_6b2:
	/* 0x6b2: jle    6d0 <filter_inet+0x11a> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x6b2, 0x6d0, x86_l_6d0);
x86_l_6b4:
	/* 0x6b4: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_6b7:
	/* 0x6b7: jg     6ec <filter_inet+0x136> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6b7, 0x6ec, x86_l_6ec);
x86_l_6b9:
	/* 0x6b9: cmp    ecx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_6bc:
	/* 0x6bc: je     6fa <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6bc, 0x6fa, x86_l_6fa);
x86_l_6be:
	/* 0x6be: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_6c1:
	/* 0x6c1: jne    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6c1, 0x8d8, x86_l_8d8);
x86_l_6c7:
	/* 0x6c7: movzx  eax,WORD PTR [rsi+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_6cb:
	/* 0x6cb: jmp    8cd <filter_inet+0x317> */
	X86_SIM_X86_SUB_JMP(0x6cb, 0x8cd, x86_l_8cd);
x86_l_6d0:
	/* 0x6d0: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_6d3:
	/* 0x6d3: je     770 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6d3, 0x770, x86_l_770);
x86_l_6d9:
	/* 0x6d9: cmp    ecx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 14ULL);
x86_l_6dc:
	/* 0x6dc: je     766 <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6dc, 0x766, x86_l_766);
x86_l_6e2:
	/* 0x6e2: cmp    ecx,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 15ULL);
x86_l_6e5:
	/* 0x6e5: je     700 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6e5, 0x700, x86_l_700);
x86_l_6e7:
	/* 0x6e7: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x6e7, 0x8d8, x86_l_8d8);
x86_l_6ec:
	/* 0x6ec: cmp    ecx,0x12 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 18ULL);
x86_l_6ef:
	/* 0x6ef: je     700 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6ef, 0x700, x86_l_700);
x86_l_6f1:
	/* 0x6f1: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_6f4:
	/* 0x6f4: jne    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6f4, 0x8d8, x86_l_8d8);
x86_l_6fa:
	/* 0x6fa: movzx  edx,WORD PTR [rsi+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_6fe:
	/* 0x6fe: jmp    704 <filter_inet+0x14e> */
	X86_SIM_X86_SUB_JMP(0x6fe, 0x704, x86_l_704);
x86_l_700:
	/* 0x700: movzx  edx,WORD PTR [rsi+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_704:
	/* 0x704: mov    DWORD PTR [rsp+0x4],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_708:
	/* 0x708: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_70a:
	/* 0x70a: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_70d:
	/* 0x70d: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_710:
	/* 0x710: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_712:
	/* 0x712: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_715:
	/* 0x715: jg     787 <filter_inet+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x715, 0x787, x86_l_787);
x86_l_717:
	/* 0x717: lea    edx,[rcx-0xd] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_71a:
	/* 0x71a: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_71d:
	/* 0x71d: jb     7ba <filter_inet+0x204> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x71d, 0x7ba, x86_l_7ba);
x86_l_723:
	/* 0x723: lea    edx,[rcx-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_726:
	/* 0x726: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_729:
	/* 0x729: jb     81c <filter_inet+0x266> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x729, 0x81c, x86_l_81c);
x86_l_72f:
	/* 0x72f: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_732:
	/* 0x732: je     8d0 <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x732, 0x8d0, x86_l_8d0);
x86_l_738:
	/* 0x738: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x738, 0x8d8, x86_l_8d8);
x86_l_73d:
	/* 0x73d: cmp    ecx,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 28ULL);
x86_l_740:
	/* 0x740: je     8c9 <filter_inet+0x313> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x740, 0x8c9, x86_l_8c9);
x86_l_746:
	/* 0x746: cmp    ecx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 29ULL);
x86_l_749:
	/* 0x749: jne    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x749, 0x8d8, x86_l_8d8);
x86_l_74f:
	/* 0x74f: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_752:
	/* 0x752: jne    900 <filter_inet+0x34a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x752, 0x900, x86_l_900);
x86_l_758:
	/* 0x758: test   r8,r8 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64);
x86_l_75b:
	/* 0x75b: jne    90a <filter_inet+0x354> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x75b, 0x90a, x86_l_90a);
x86_l_761:
	/* 0x761: jmp    8d0 <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JMP(0x761, 0x8d0, x86_l_8d0);
x86_l_766:
	/* 0x766: mov    rbx,QWORD PTR [rsi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76a:
	/* 0x76a: mov    r14,QWORD PTR [rsi+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_76e:
	/* 0x76e: jmp    777 <filter_inet+0x1c1> */
	X86_SIM_X86_SUB_JMP(0x76e, 0x777, x86_l_777);
x86_l_770:
	/* 0x770: mov    rbx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_773:
	/* 0x773: mov    r14,QWORD PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_777:
	/* 0x777: mov    r15,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RBX, X86_WIDTH_64);
x86_l_77a:
	/* 0x77a: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_77e:
	/* 0x77e: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_780:
	/* 0x780: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_782:
	/* 0x782: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_785:
	/* 0x785: jle    717 <filter_inet+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x785, 0x717, x86_l_717);
x86_l_787:
	/* 0x787: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_78a:
	/* 0x78a: ja     810 <filter_inet+0x25a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x78a, 0x810, x86_l_810);
x86_l_790:
	/* 0x790: mov    r8d,0x500000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5242880ULL);
x86_l_796:
	/* 0x796: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_79a:
	/* 0x79a: jb     826 <filter_inet+0x270> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x79a, 0x826, x86_l_826);
x86_l_7a0:
	/* 0x7a0: mov    r8d,0xa00000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 10485760ULL);
x86_l_7a6:
	/* 0x7a6: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_7aa:
	/* 0x7aa: jb     836 <filter_inet+0x280> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x7aa, 0x836, x86_l_836);
x86_l_7b0:
	/* 0x7b0: mov    edx,0x3000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 50331648ULL);
x86_l_7b5:
	/* 0x7b5: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_7b8:
	/* 0x7b8: jae    810 <filter_inet+0x25a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x7b8, 0x810, x86_l_810);
x86_l_7ba:
	/* 0x7ba: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_7be:
	/* 0x7be: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_7c1:
	/* 0x7c1: je     846 <filter_inet+0x290> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7c1, 0x846, x86_l_846);
x86_l_7c7:
	/* 0x7c7: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_7ca:
	/* 0x7ca: jne    8c2 <filter_inet+0x30c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7ca, 0x8c2, x86_l_8c2);
x86_l_7d0:
	/* 0x7d0: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_7d3:
	/* 0x7d3: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d6:
	/* 0x7d6: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7da:
	/* 0x7da: mov    rdi,QWORD PTR [rip+0x1748] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)addr4lpm_maps));
x86_l_7e1:
	/* 0x7e1: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7e6:
	/* 0x7e6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_7eb:
	/* 0x7eb: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_7ee:
	/* 0x7ee: call   7f3 <filter_inet+0x23d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7f3:
	/* 0x7f3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f6:
	/* 0x7f6: je     8e8 <filter_inet+0x332> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7f6, 0x8e8, x86_l_8e8);
x86_l_7fc:
	/* 0x7fc: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_7ff:
	/* 0x7ff: mov    DWORD PTR [rsp+0xc],0x20 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_807:
	/* 0x807: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_80b:
	/* 0x80b: jmp    890 <filter_inet+0x2da> */
	X86_SIM_X86_SUB_JMP(0x80b, 0x890, x86_l_890);
x86_l_810:
	/* 0x810: add    ecx,0xffffffee */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_813:
	/* 0x813: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_816:
	/* 0x816: jae    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x816, 0x8d8, x86_l_8d8);
x86_l_81c:
	/* 0x81c: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_821:
	/* 0x821: jmp    8d3 <filter_inet+0x31d> */
	X86_SIM_X86_SUB_JMP(0x821, 0x8d3, x86_l_8d3);
x86_l_826:
	/* 0x826: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_828:
	/* 0x828: cmp    edx,0x400 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_82e:
	/* 0x82e: setb   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_B);
x86_l_831:
	/* 0x831: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x831, 0x8d8, x86_l_8d8);
x86_l_836:
	/* 0x836: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_838:
	/* 0x838: cmp    edx,0x400 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_83e:
	/* 0x83e: setae  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_AE);
x86_l_841:
	/* 0x841: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x841, 0x8d8, x86_l_8d8);
x86_l_846:
	/* 0x846: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_849:
	/* 0x849: mov    eax,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_84c:
	/* 0x84c: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_850:
	/* 0x850: mov    rdi,QWORD PTR [rip+0x1748] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)addr6lpm_maps));
x86_l_857:
	/* 0x857: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_85c:
	/* 0x85c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_861:
	/* 0x861: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_864:
	/* 0x864: call   869 <filter_inet+0x2b3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_869:
	/* 0x869: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_86c:
	/* 0x86c: je     8e8 <filter_inet+0x332> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x86c, 0x8e8, x86_l_8e8);
x86_l_86e:
	/* 0x86e: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_871:
	/* 0x871: mov    DWORD PTR [rsp+0xc],0x80 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607680ULL);
x86_l_879:
	/* 0x879: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_87d:
	/* 0x87d: mov    DWORD PTR [rsp+0x14],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_882:
	/* 0x882: mov    DWORD PTR [rsp+0x18],r14d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_887:
	/* 0x887: shr    r14,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_88b:
	/* 0x88b: mov    DWORD PTR [rsp+0x1c],r14d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_890:
	/* 0x890: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_895:
	/* 0x895: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_89a:
	/* 0x89a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_89d:
	/* 0x89d: call   8a2 <filter_inet+0x2ec> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8a2:
	/* 0x8a2: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8a7:
	/* 0x8a7: lea    edx,[rcx-0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_8aa:
	/* 0x8aa: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_8ad:
	/* 0x8ad: jb     8f5 <filter_inet+0x33f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x8ad, 0x8f5, x86_l_8f5);
x86_l_8af:
	/* 0x8af: add    ecx,0xfffffff3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_8b2:
	/* 0x8b2: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_8b5:
	/* 0x8b5: ja     8c2 <filter_inet+0x30c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x8b5, 0x8c2, x86_l_8c2);
x86_l_8b7:
	/* 0x8b7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8ba:
	/* 0x8ba: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_8bd:
	/* 0x8bd: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_8c0:
	/* 0x8c0: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x8c0, 0x8d8, x86_l_8d8);
x86_l_8c2:
	/* 0x8c2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8c4:
	/* 0x8c4: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_8c7:
	/* 0x8c7: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x8c7, 0x8d8, x86_l_8d8);
x86_l_8c9:
	/* 0x8c9: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_8cd:
	/* 0x8cd: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8d0:
	/* 0x8d0: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_8d3:
	/* 0x8d3: call   2087 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_2087, 0x8d8ULL);
x86_l_8d8:
	/* 0x8d8: add    rsp,0x48 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_8dc:
	/* 0x8dc: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_8dd:
	/* 0x8dd: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8df:
	/* 0x8df: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_8e1:
	/* 0x8e1: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_8e3:
	/* 0x8e3: jmp    8e8 <filter_inet+0x332> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_8e8:
	/* 0x8e8: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8ed:
	/* 0x8ed: and    eax,0xfffffffe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_8f0:
	/* 0x8f0: cmp    eax,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 24ULL);
x86_l_8f3:
	/* 0x8f3: jmp    8f8 <filter_inet+0x342> */
	X86_SIM_X86_SUB_JMP(0x8f3, 0x8f8, x86_l_8f8);
x86_l_8f5:
	/* 0x8f5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8f8:
	/* 0x8f8: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_8fb:
	/* 0x8fb: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_8fe:
	/* 0x8fe: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x8fe, 0x8d8, x86_l_8d8);
x86_l_900:
	/* 0x900: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_903:
	/* 0x903: jne    912 <filter_inet+0x35c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x903, 0x912, x86_l_912);
x86_l_905:
	/* 0x905: test   r8,r8 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64);
x86_l_908:
	/* 0x908: je     912 <filter_inet+0x35c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x908, 0x912, x86_l_912);
x86_l_90a:
	/* 0x90a: movzx  eax,BYTE PTR [r8+0x3a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_90f:
	/* 0x90f: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_912:
	/* 0x912: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_915:
	/* 0x915: je     8d0 <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x915, 0x8d0, x86_l_8d0);
x86_l_917:
	/* 0x917: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_91a:
	/* 0x91a: je     8d0 <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x91a, 0x8d0, x86_l_8d0);
x86_l_91c:
	/* 0x91c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_91e:
	/* 0x91e: jmp    8d8 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x91e, 0x8d8, x86_l_8d8);

	/* native subroutine native_link_sub_920 */
x86_l_920:
	/* 0x920: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_921:
	/* 0x921: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_925:
	/* 0x925: mov    rcx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RSI, X86_WIDTH_64);
x86_l_928:
	/* 0x928: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_92c:
	/* 0x92c: movzx  edx,BYTE PTR [rcx+0x3] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_930:
	/* 0x930: mov    r8d,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_934:
	/* 0x934: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_936:
	/* 0x936: cmp    r8d,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 25ULL);
x86_l_93a:
	/* 0x93a: jg     974 <filter_sockaddr_un+0x54> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x93a, 0x974, x86_l_974);
x86_l_93c:
	/* 0x93c: lea    ecx,[r8-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_940:
	/* 0x940: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_943:
	/* 0x943: jae    982 <filter_sockaddr_un+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x943, 0x982, x86_l_982);
x86_l_945:
	/* 0x945: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_948:
	/* 0x948: call   1246 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1246, 0x94dULL);
x86_l_94d:
	/* 0x94d: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_950:
	/* 0x950: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_954:
	/* 0x954: ja     96a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x954, 0x96a, x86_l_96a);
x86_l_956:
	/* 0x956: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_960:
	/* 0x960: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_964:
	/* 0x964: jae    96a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x964, 0x96a, x86_l_96a);
x86_l_966:
	/* 0x966: xor    rax,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_96a:
	/* 0x96a: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_96e:
	/* 0x96e: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_96f:
	/* 0x96f: jmp    974 <filter_sockaddr_un+0x54> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_974:
	/* 0x974: cmp    r8d,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 28ULL);
x86_l_978:
	/* 0x978: je     9bc <filter_sockaddr_un+0x9c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x978, 0x9bc, x86_l_9bc);
x86_l_97a:
	/* 0x97a: cmp    r8d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 26ULL);
x86_l_97e:
	/* 0x97e: je     988 <filter_sockaddr_un+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x97e, 0x988, x86_l_988);
x86_l_980:
	/* 0x980: jmp    96a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JMP(0x980, 0x96a, x86_l_96a);
x86_l_982:
	/* 0x982: cmp    r8d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 8ULL);
x86_l_986:
	/* 0x986: jne    96a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x986, 0x96a, x86_l_96a);
x86_l_988:
	/* 0x988: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_98b:
	/* 0x98b: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_98e:
	/* 0x98e: mov    edi,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_32);
x86_l_990:
	/* 0x990: call   118a <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_118a, 0x995ULL);
x86_l_995:
	/* 0x995: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_998:
	/* 0x998: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_99c:
	/* 0x99c: ja     96a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x99c, 0x96a, x86_l_96a);
x86_l_99e:
	/* 0x99e: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_9a8:
	/* 0x9a8: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_9ac:
	/* 0x9ac: jae    96a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9ac, 0x96a, x86_l_96a);
x86_l_9ae:
	/* 0x9ae: xor    rax,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_9b2:
	/* 0x9b2: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_9b6:
	/* 0x9b6: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9b7:
	/* 0x9b7: jmp    9bc <filter_sockaddr_un+0x9c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_9bc:
	/* 0x9bc: movzx  eax,WORD PTR [rcx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_9bf:
	/* 0x9bf: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_9c3:
	/* 0x9c3: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_9c8:
	/* 0x9c8: call   2087 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_2087, 0x9cdULL);
x86_l_9cd:
	/* 0x9cd: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_9d1:
	/* 0x9d1: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9d2:
	/* 0x9d2: jmp    9d7 <filter_32ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_9d7 */
x86_l_9d7:
	/* 0x9d7: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9d8:
	/* 0x9d8: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9db:
	/* 0x9db: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_9dd:
	/* 0x9dd: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_9e1:
	/* 0x9e1: ja     a24 <filter_32ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x9e1, 0xa24, x86_l_a24);
x86_l_9e3:
	/* 0x9e3: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_9e8:
	/* 0x9e8: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_9ec:
	/* 0x9ec: jae    9f9 <filter_32ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9ec, 0x9f9, x86_l_9f9);
x86_l_9ee:
	/* 0x9ee: call   1ca9 <filter_32ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1ca9, 0x9f3ULL);
x86_l_9f3:
	/* 0x9f3: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9f4:
	/* 0x9f4: jmp    9f9 <filter_32ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_9f9:
	/* 0x9f9: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_9fe:
	/* 0x9fe: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a02:
	/* 0xa02: jb     a1f <filter_32ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa02, 0xa1f, x86_l_a1f);
x86_l_a04:
	/* 0xa04: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_a0e:
	/* 0xa0e: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a12:
	/* 0xa12: jae    a24 <filter_32ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa12, 0xa24, x86_l_a24);
x86_l_a14:
	/* 0xa14: call   1ec9 <filter_32ty_range> */
	X86_SIM_X86_CALL(x86_l_1ec9, 0xa19ULL);
x86_l_a19:
	/* 0xa19: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a1a:
	/* 0xa1a: jmp    a1f <filter_32ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_a1f:
	/* 0xa1f: call   2087 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_2087, 0xa24ULL);
x86_l_a24:
	/* 0xa24: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a25:
	/* 0xa25: jmp    a2a <filter_16ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_a2a */
x86_l_a2a:
	/* 0xa2a: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a2b:
	/* 0xa2b: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a2e:
	/* 0xa2e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a30:
	/* 0xa30: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_a34:
	/* 0xa34: ja     a77 <filter_16ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa34, 0xa77, x86_l_a77);
x86_l_a36:
	/* 0xa36: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_a3b:
	/* 0xa3b: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a3f:
	/* 0xa3f: jae    a4c <filter_16ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa3f, 0xa4c, x86_l_a4c);
x86_l_a41:
	/* 0xa41: call   1829 <filter_16ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1829, 0xa46ULL);
x86_l_a46:
	/* 0xa46: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a47:
	/* 0xa47: jmp    a4c <filter_16ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_a4c:
	/* 0xa4c: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_a51:
	/* 0xa51: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a55:
	/* 0xa55: jb     a72 <filter_16ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa55, 0xa72, x86_l_a72);
x86_l_a57:
	/* 0xa57: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_a61:
	/* 0xa61: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a65:
	/* 0xa65: jae    a77 <filter_16ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa65, 0xa77, x86_l_a77);
x86_l_a67:
	/* 0xa67: call   1a4f <filter_16ty_range> */
	X86_SIM_X86_CALL(x86_l_1a4f, 0xa6cULL);
x86_l_a6c:
	/* 0xa6c: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a6d:
	/* 0xa6d: jmp    a72 <filter_16ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_a72:
	/* 0xa72: call   1c0f <filter_16ty_map> */
	X86_SIM_X86_CALL(x86_l_1c0f, 0xa77ULL);
x86_l_a77:
	/* 0xa77: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a78:
	/* 0xa78: jmp    a7d <filter_char_buf> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_a7d */
x86_l_a7d:
	/* 0xa7d: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a7e:
	/* 0xa7e: mov    rax,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_64);
x86_l_a81:
	/* 0xa81: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_a84:
	/* 0xa84: movsxd rcx,edx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_a87:
	/* 0xa87: mov    edx,DWORD PTR [rsi+rcx*1-0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 18446744073709551612ULL);
x86_l_a8b:
	/* 0xa8b: mov    esi,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_a8d:
	/* 0xa8d: add    rsi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_a90:
	/* 0xa90: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a93:
	/* 0xa93: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a95:
	/* 0xa95: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_a98:
	/* 0xa98: jg     aae <filter_char_buf+0x31> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xa98, 0xaae, x86_l_aae);
x86_l_a9a:
	/* 0xa9a: lea    edi,[rcx-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_a9d:
	/* 0xa9d: cmp    edi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_aa0:
	/* 0xaa0: jb     ae5 <filter_char_buf+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xaa0, 0xae5, x86_l_ae5);
x86_l_aa2:
	/* 0xaa2: cmp    ecx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_aa5:
	/* 0xaa5: je     adb <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaa5, 0xadb, x86_l_adb);
x86_l_aa7:
	/* 0xaa7: cmp    ecx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_aaa:
	/* 0xaaa: je     abd <filter_char_buf+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaaa, 0xabd, x86_l_abd);
x86_l_aac:
	/* 0xaac: jmp    afc <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JMP(0xaac, 0xafc, x86_l_afc);
x86_l_aae:
	/* 0xaae: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_ab1:
	/* 0xab1: jg     ac7 <filter_char_buf+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xab1, 0xac7, x86_l_ac7);
x86_l_ab3:
	/* 0xab3: cmp    ecx,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 26ULL);
x86_l_ab6:
	/* 0xab6: je     adb <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xab6, 0xadb, x86_l_adb);
x86_l_ab8:
	/* 0xab8: cmp    ecx,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 27ULL);
x86_l_abb:
	/* 0xabb: jne    afc <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xabb, 0xafc, x86_l_afc);
x86_l_abd:
	/* 0xabd: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ac0:
	/* 0xac0: call   102c <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_102c, 0xac5ULL);
x86_l_ac5:
	/* 0xac5: jmp    af9 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xac5, 0xaf9, x86_l_af9);
x86_l_ac7:
	/* 0xac7: cmp    ecx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 33ULL);
x86_l_aca:
	/* 0xaca: je     aef <filter_char_buf+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaca, 0xaef, x86_l_aef);
x86_l_acc:
	/* 0xacc: cmp    ecx,0x22 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 34ULL);
x86_l_acf:
	/* 0xacf: jne    afc <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xacf, 0xafc, x86_l_afc);
x86_l_ad1:
	/* 0xad1: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_ad4:
	/* 0xad4: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_ad9:
	/* 0xad9: jmp    af4 <filter_char_buf+0x77> */
	X86_SIM_X86_SUB_JMP(0xad9, 0xaf4, x86_l_af4);
x86_l_adb:
	/* 0xadb: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ade:
	/* 0xade: call   118a <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_118a, 0xae3ULL);
x86_l_ae3:
	/* 0xae3: jmp    af9 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xae3, 0xaf9, x86_l_af9);
x86_l_ae5:
	/* 0xae5: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_ae8:
	/* 0xae8: call   1246 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1246, 0xaedULL);
x86_l_aed:
	/* 0xaed: jmp    af9 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xaed, 0xaf9, x86_l_af9);
x86_l_aef:
	/* 0xaef: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_af2:
	/* 0xaf2: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_af4:
	/* 0xaf4: call   15f7 <filter_char_substring> */
	X86_SIM_X86_CALL(x86_l_15f7, 0xaf9ULL);
x86_l_af9:
	/* 0xaf9: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_afc:
	/* 0xafc: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_aff:
	/* 0xaff: ja     b1e <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xaff, 0xb1e, x86_l_b1e);
x86_l_b01:
	/* 0xb01: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_b03:
	/* 0xb03: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_b0d:
	/* 0xb0d: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b11:
	/* 0xb11: jae    b1e <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb11, 0xb1e, x86_l_b1e);
x86_l_b13:
	/* 0xb13: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b15:
	/* 0xb15: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b18:
	/* 0xb18: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_b1b:
	/* 0xb1b: mov    rax,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_b1e:
	/* 0xb1e: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b1f:
	/* 0xb1f: jmp    b24 <filter_64ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_b24 */
x86_l_b24:
	/* 0xb24: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b25:
	/* 0xb25: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b28:
	/* 0xb28: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b2a:
	/* 0xb2a: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_b2e:
	/* 0xb2e: ja     b71 <filter_64ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb2e, 0xb71, x86_l_b71);
x86_l_b30:
	/* 0xb30: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_b35:
	/* 0xb35: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b39:
	/* 0xb39: jae    b46 <filter_64ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb39, 0xb46, x86_l_b46);
x86_l_b3b:
	/* 0xb3b: call   b77 <filter_64ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_b77, 0xb40ULL);
x86_l_b40:
	/* 0xb40: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b41:
	/* 0xb41: jmp    b46 <filter_64ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_b46:
	/* 0xb46: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_b4b:
	/* 0xb4b: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b4f:
	/* 0xb4f: jb     b6c <filter_64ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb4f, 0xb6c, x86_l_b6c);
x86_l_b51:
	/* 0xb51: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_b5b:
	/* 0xb5b: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b5f:
	/* 0xb5f: jae    b71 <filter_64ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb5f, 0xb71, x86_l_b71);
x86_l_b61:
	/* 0xb61: call   db9 <filter_64ty_range> */
	X86_SIM_X86_CALL(x86_l_db9, 0xb66ULL);
x86_l_b66:
	/* 0xb66: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b67:
	/* 0xb67: jmp    b6c <filter_64ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_b6c:
	/* 0xb6c: call   fa0 <filter_64ty_map> */
	X86_SIM_X86_CALL(x86_l_fa0, 0xb71ULL);
x86_l_b71:
	/* 0xb71: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b72:
	/* 0xb72: jmp    b77 <filter_64ty_selector_val> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_b77 */
x86_l_b77:
	/* 0xb77: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b7a:
	/* 0xb7a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b7f:
	/* 0xb7f: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_b83:
	/* 0xb83: ja     c07 <filter_64ty_selector_val+0x90> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb83, 0xc07, x86_l_c07);
x86_l_b89:
	/* 0xb89: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_b93:
	/* 0xb93: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b97:
	/* 0xb97: jae    b9e <filter_64ty_selector_val+0x27> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb97, 0xb9e, x86_l_b9e);
x86_l_b99:
	/* 0xb99: jmp    b9e <filter_64ty_selector_val+0x27> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_b9e:
	/* 0xb9e: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_ba3:
	/* 0xba3: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_ba7:
	/* 0xba7: jae    bc3 <filter_64ty_selector_val+0x4c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xba7, 0xbc3, x86_l_bc3);
x86_l_ba9:
	/* 0xba9: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bac:
	/* 0xbac: cmp    rdx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_bb0:
	/* 0xbb0: jne    ce5 <filter_64ty_selector_val+0x16e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbb0, 0xce5, x86_l_ce5);
x86_l_bb6:
	/* 0xbb6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_bb8:
	/* 0xbb8: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_bbb:
	/* 0xbbb: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_bbe:
	/* 0xbbe: jmp    bc3 <filter_64ty_selector_val+0x4c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_bc3:
	/* 0xbc3: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_bc7:
	/* 0xbc7: jne    c07 <filter_64ty_selector_val+0x90> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbc7, 0xc07, x86_l_c07);
x86_l_bc9:
	/* 0xbc9: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bcc:
	/* 0xbcc: test   QWORD PTR [rdi+0x10],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_bd0:
	/* 0xbd0: jne    b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbd0, 0xb99, x86_l_b99);
x86_l_bd2:
	/* 0xbd2: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bd5:
	/* 0xbd5: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_bd8:
	/* 0xbd8: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbd8, 0xdb2, x86_l_db2);
x86_l_bde:
	/* 0xbde: test   QWORD PTR [rdi+0x18],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_be2:
	/* 0xbe2: jne    b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbe2, 0xb99, x86_l_b99);
x86_l_be4:
	/* 0xbe4: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_be7:
	/* 0xbe7: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbe7, 0xdb2, x86_l_db2);
x86_l_bed:
	/* 0xbed: test   QWORD PTR [rdi+0x20],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_bf1:
	/* 0xbf1: jne    b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbf1, 0xb99, x86_l_b99);
x86_l_bf3:
	/* 0xbf3: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_bf6:
	/* 0xbf6: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbf6, 0xdb2, x86_l_db2);
x86_l_bfc:
	/* 0xbfc: test   QWORD PTR [rdi+0x28],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_c00:
	/* 0xc00: jne    b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc00, 0xb99, x86_l_b99);
x86_l_c02:
	/* 0xc02: jmp    db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xc02, 0xdb2, x86_l_db2);
x86_l_c07:
	/* 0xc07: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_c0a:
	/* 0xc0a: je     c7d <filter_64ty_selector_val+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc0a, 0xc7d, x86_l_c7d);
x86_l_c0c:
	/* 0xc0c: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_c0f:
	/* 0xc0f: jne    db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc0f, 0xdb2, x86_l_db2);
x86_l_c15:
	/* 0xc15: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_c18:
	/* 0xc18: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_c1b:
	/* 0xc1b: ja     d75 <filter_64ty_selector_val+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc1b, 0xd75, x86_l_d75);
x86_l_c21:
	/* 0xc21: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_c26:
	/* 0xc26: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_c29:
	/* 0xc29: jae    d75 <filter_64ty_selector_val+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xc29, 0xd75, x86_l_d75);
x86_l_c2f:
	/* 0xc2f: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c32:
	/* 0xc32: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c36:
	/* 0xc36: jl     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc36, 0xb99, x86_l_b99);
x86_l_c3c:
	/* 0xc3c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c3f:
	/* 0xc3f: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_c42:
	/* 0xc42: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc42, 0xdb2, x86_l_db2);
x86_l_c48:
	/* 0xc48: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c4c:
	/* 0xc4c: jl     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc4c, 0xb99, x86_l_b99);
x86_l_c52:
	/* 0xc52: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_c55:
	/* 0xc55: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc55, 0xdb2, x86_l_db2);
x86_l_c5b:
	/* 0xc5b: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c5f:
	/* 0xc5f: jl     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc5f, 0xb99, x86_l_b99);
x86_l_c65:
	/* 0xc65: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_c68:
	/* 0xc68: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc68, 0xdb2, x86_l_db2);
x86_l_c6e:
	/* 0xc6e: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c72:
	/* 0xc72: jl     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc72, 0xb99, x86_l_b99);
x86_l_c78:
	/* 0xc78: jmp    db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xc78, 0xdb2, x86_l_db2);
x86_l_c7d:
	/* 0xc7d: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_c80:
	/* 0xc80: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_c83:
	/* 0xc83: ja     d36 <filter_64ty_selector_val+0x1bf> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc83, 0xd36, x86_l_d36);
x86_l_c89:
	/* 0xc89: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_c8e:
	/* 0xc8e: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_c91:
	/* 0xc91: jae    d36 <filter_64ty_selector_val+0x1bf> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xc91, 0xd36, x86_l_d36);
x86_l_c97:
	/* 0xc97: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9a:
	/* 0xc9a: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c9e:
	/* 0xc9e: jg     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc9e, 0xb99, x86_l_b99);
x86_l_ca4:
	/* 0xca4: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ca7:
	/* 0xca7: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_caa:
	/* 0xcaa: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcaa, 0xdb2, x86_l_db2);
x86_l_cb0:
	/* 0xcb0: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_cb4:
	/* 0xcb4: jg     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xcb4, 0xb99, x86_l_b99);
x86_l_cba:
	/* 0xcba: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_cbd:
	/* 0xcbd: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcbd, 0xdb2, x86_l_db2);
x86_l_cc3:
	/* 0xcc3: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_cc7:
	/* 0xcc7: jg     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xcc7, 0xb99, x86_l_b99);
x86_l_ccd:
	/* 0xccd: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_cd0:
	/* 0xcd0: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcd0, 0xdb2, x86_l_db2);
x86_l_cd6:
	/* 0xcd6: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_cda:
	/* 0xcda: jg     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xcda, 0xb99, x86_l_b99);
x86_l_ce0:
	/* 0xce0: jmp    db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xce0, 0xdb2, x86_l_db2);
x86_l_ce5:
	/* 0xce5: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ce8:
	/* 0xce8: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_ceb:
	/* 0xceb: jb     d15 <filter_64ty_selector_val+0x19e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xceb, 0xd15, x86_l_d15);
x86_l_ced:
	/* 0xced: cmp    rdx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_cf1:
	/* 0xcf1: je     bb6 <filter_64ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xcf1, 0xbb6, x86_l_bb6);
x86_l_cf7:
	/* 0xcf7: cmp    esi,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 25ULL);
x86_l_cfa:
	/* 0xcfa: jb     d15 <filter_64ty_selector_val+0x19e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcfa, 0xd15, x86_l_d15);
x86_l_cfc:
	/* 0xcfc: cmp    rdx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d00:
	/* 0xd00: je     bb6 <filter_64ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd00, 0xbb6, x86_l_bb6);
x86_l_d06:
	/* 0xd06: cmp    esi,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 33ULL);
x86_l_d09:
	/* 0xd09: jb     d15 <filter_64ty_selector_val+0x19e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd09, 0xd15, x86_l_d15);
x86_l_d0b:
	/* 0xd0b: cmp    rdx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d0f:
	/* 0xd0f: je     bb6 <filter_64ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd0f, 0xbb6, x86_l_bb6);
x86_l_d15:
	/* 0xd15: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_d18:
	/* 0xd18: ja     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd18, 0xdb2, x86_l_db2);
x86_l_d1e:
	/* 0xd1e: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_d20:
	/* 0xd20: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_d2a:
	/* 0xd2a: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_d2e:
	/* 0xd2e: jb     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd2e, 0xb99, x86_l_b99);
x86_l_d34:
	/* 0xd34: jmp    db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xd34, 0xdb2, x86_l_db2);
x86_l_d36:
	/* 0xd36: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d39:
	/* 0xd39: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_d3d:
	/* 0xd3d: ja     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd3d, 0xb99, x86_l_b99);
x86_l_d43:
	/* 0xd43: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d46:
	/* 0xd46: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_d49:
	/* 0xd49: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd49, 0xdb2, x86_l_db2);
x86_l_d4b:
	/* 0xd4b: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d4f:
	/* 0xd4f: ja     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd4f, 0xb99, x86_l_b99);
x86_l_d55:
	/* 0xd55: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_d58:
	/* 0xd58: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd58, 0xdb2, x86_l_db2);
x86_l_d5a:
	/* 0xd5a: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d5e:
	/* 0xd5e: ja     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd5e, 0xb99, x86_l_b99);
x86_l_d64:
	/* 0xd64: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_d67:
	/* 0xd67: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd67, 0xdb2, x86_l_db2);
x86_l_d69:
	/* 0xd69: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d6d:
	/* 0xd6d: ja     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd6d, 0xb99, x86_l_b99);
x86_l_d73:
	/* 0xd73: jmp    db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xd73, 0xdb2, x86_l_db2);
x86_l_d75:
	/* 0xd75: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d78:
	/* 0xd78: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_d7c:
	/* 0xd7c: jb     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd7c, 0xb99, x86_l_b99);
x86_l_d82:
	/* 0xd82: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d85:
	/* 0xd85: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_d88:
	/* 0xd88: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd88, 0xdb2, x86_l_db2);
x86_l_d8a:
	/* 0xd8a: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d8e:
	/* 0xd8e: jb     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd8e, 0xb99, x86_l_b99);
x86_l_d94:
	/* 0xd94: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_d97:
	/* 0xd97: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd97, 0xdb2, x86_l_db2);
x86_l_d99:
	/* 0xd99: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d9d:
	/* 0xd9d: jb     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd9d, 0xb99, x86_l_b99);
x86_l_da3:
	/* 0xda3: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_da6:
	/* 0xda6: jb     db2 <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xda6, 0xdb2, x86_l_db2);
x86_l_da8:
	/* 0xda8: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_dac:
	/* 0xdac: jb     b99 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdac, 0xb99, x86_l_b99);
x86_l_db2:
	/* 0xdb2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_db4:
	/* 0xdb4: jmp    db9 <filter_64ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_db9 */
x86_l_db9:
	/* 0xdb9: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_dbc:
	/* 0xdbc: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_dbf:
	/* 0xdbf: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_dc2:
	/* 0xdc2: ja     ebc <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdc2, 0xebc, x86_l_ebc);
x86_l_dc8:
	/* 0xdc8: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_dcd:
	/* 0xdcd: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_dd0:
	/* 0xdd0: jae    ebc <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xdd0, 0xebc, x86_l_ebc);
x86_l_dd6:
	/* 0xdd6: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dd9:
	/* 0xdd9: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_ddc:
	/* 0xddc: jne    e4c <filter_64ty_range+0x93> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xddc, 0xe4c, x86_l_e4c);
x86_l_dde:
	/* 0xdde: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_de3:
	/* 0xde3: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_de7:
	/* 0xde7: jg     df3 <filter_64ty_range+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xde7, 0xdf3, x86_l_df3);
x86_l_de9:
	/* 0xde9: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_ded:
	/* 0xded: jle    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xded, 0xed5, x86_l_ed5);
x86_l_df3:
	/* 0xdf3: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_df6:
	/* 0xdf6: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_df9:
	/* 0xdf9: jb     f8b <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdf9, 0xf8b, x86_l_f8b);
x86_l_dff:
	/* 0xdff: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e03:
	/* 0xe03: jg     e0f <filter_64ty_range+0x56> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe03, 0xe0f, x86_l_e0f);
x86_l_e05:
	/* 0xe05: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e09:
	/* 0xe09: jle    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe09, 0xed5, x86_l_ed5);
x86_l_e0f:
	/* 0xe0f: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_e12:
	/* 0xe12: jb     f8b <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe12, 0xf8b, x86_l_f8b);
x86_l_e18:
	/* 0xe18: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e1c:
	/* 0xe1c: jg     e28 <filter_64ty_range+0x6f> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe1c, 0xe28, x86_l_e28);
x86_l_e1e:
	/* 0xe1e: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e22:
	/* 0xe22: jle    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe22, 0xed5, x86_l_ed5);
x86_l_e28:
	/* 0xe28: cmp    edx,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 57ULL);
x86_l_e2b:
	/* 0xe2b: jb     f8b <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe2b, 0xf8b, x86_l_f8b);
x86_l_e31:
	/* 0xe31: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e33:
	/* 0xe33: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e37:
	/* 0xe37: jg     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe37, 0xf8d, x86_l_f8d);
x86_l_e3d:
	/* 0xe3d: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_e41:
	/* 0xe41: jle    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe41, 0xed5, x86_l_ed5);
x86_l_e47:
	/* 0xe47: jmp    f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JMP(0xe47, 0xf8d, x86_l_f8d);
x86_l_e4c:
	/* 0xe4c: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e4f:
	/* 0xe4f: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e53:
	/* 0xe53: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_e57:
	/* 0xe57: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e5b:
	/* 0xe5b: setle  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_LE);
x86_l_e5e:
	/* 0xe5e: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_e61:
	/* 0xe61: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_e64:
	/* 0xe64: jb     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe64, 0xf8d, x86_l_f8d);
x86_l_e6a:
	/* 0xe6a: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e6e:
	/* 0xe6e: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_e72:
	/* 0xe72: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e76:
	/* 0xe76: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_e7a:
	/* 0xe7a: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_e7d:
	/* 0xe7d: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_e80:
	/* 0xe80: cmp    eax,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 41ULL);
x86_l_e83:
	/* 0xe83: jb     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe83, 0xf8d, x86_l_f8d);
x86_l_e89:
	/* 0xe89: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e8d:
	/* 0xe8d: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_e91:
	/* 0xe91: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e95:
	/* 0xe95: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_e99:
	/* 0xe99: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_e9c:
	/* 0xe9c: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_e9f:
	/* 0xe9f: cmp    eax,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 57ULL);
x86_l_ea2:
	/* 0xea2: jb     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xea2, 0xf8d, x86_l_f8d);
x86_l_ea8:
	/* 0xea8: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_eac:
	/* 0xeac: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_eaf:
	/* 0xeaf: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_eb3:
	/* 0xeb3: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_eb7:
	/* 0xeb7: jmp    f3d <filter_64ty_range+0x184> */
	X86_SIM_X86_SUB_JMP(0xeb7, 0xf3d, x86_l_f3d);
x86_l_ebc:
	/* 0xebc: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ebf:
	/* 0xebf: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_ec2:
	/* 0xec2: jne    eda <filter_64ty_range+0x121> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xec2, 0xeda, x86_l_eda);
x86_l_ec4:
	/* 0xec4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_ec9:
	/* 0xec9: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ecd:
	/* 0xecd: ja     f45 <filter_64ty_range+0x18c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xecd, 0xf45, x86_l_f45);
x86_l_ecf:
	/* 0xecf: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_ed3:
	/* 0xed3: ja     f45 <filter_64ty_range+0x18c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xed3, 0xf45, x86_l_f45);
x86_l_ed5:
	/* 0xed5: jmp    eda <filter_64ty_range+0x121> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_eda:
	/* 0xeda: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_edd:
	/* 0xedd: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ee1:
	/* 0xee1: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_ee5:
	/* 0xee5: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_ee9:
	/* 0xee9: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_eec:
	/* 0xeec: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_eef:
	/* 0xeef: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_ef2:
	/* 0xef2: jb     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xef2, 0xf8d, x86_l_f8d);
x86_l_ef8:
	/* 0xef8: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_efc:
	/* 0xefc: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_f00:
	/* 0xf00: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_f04:
	/* 0xf04: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_f08:
	/* 0xf08: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_f0b:
	/* 0xf0b: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_f0e:
	/* 0xf0e: cmp    eax,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 41ULL);
x86_l_f11:
	/* 0xf11: jb     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf11, 0xf8d, x86_l_f8d);
x86_l_f13:
	/* 0xf13: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f17:
	/* 0xf17: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_f1b:
	/* 0xf1b: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_f1f:
	/* 0xf1f: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_f23:
	/* 0xf23: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_f26:
	/* 0xf26: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_f29:
	/* 0xf29: cmp    eax,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 57ULL);
x86_l_f2c:
	/* 0xf2c: jb     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf2c, 0xf8d, x86_l_f8d);
x86_l_f2e:
	/* 0xf2e: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f32:
	/* 0xf32: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_f35:
	/* 0xf35: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_f39:
	/* 0xf39: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_f3d:
	/* 0xf3d: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_f40:
	/* 0xf40: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_f43:
	/* 0xf43: jmp    f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JMP(0xf43, 0xf8d, x86_l_f8d);
x86_l_f45:
	/* 0xf45: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f48:
	/* 0xf48: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_f4b:
	/* 0xf4b: jb     f8b <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf4b, 0xf8b, x86_l_f8b);
x86_l_f4d:
	/* 0xf4d: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f51:
	/* 0xf51: ja     f5d <filter_64ty_range+0x1a4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf51, 0xf5d, x86_l_f5d);
x86_l_f53:
	/* 0xf53: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_f57:
	/* 0xf57: jbe    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xf57, 0xed5, x86_l_ed5);
x86_l_f5d:
	/* 0xf5d: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_f60:
	/* 0xf60: jb     f8b <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf60, 0xf8b, x86_l_f8b);
x86_l_f62:
	/* 0xf62: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f66:
	/* 0xf66: ja     f72 <filter_64ty_range+0x1b9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf66, 0xf72, x86_l_f72);
x86_l_f68:
	/* 0xf68: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_f6c:
	/* 0xf6c: jbe    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xf6c, 0xed5, x86_l_ed5);
x86_l_f72:
	/* 0xf72: cmp    edx,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 57ULL);
x86_l_f75:
	/* 0xf75: jb     f8b <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf75, 0xf8b, x86_l_f8b);
x86_l_f77:
	/* 0xf77: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_f79:
	/* 0xf79: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f7d:
	/* 0xf7d: ja     f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf7d, 0xf8d, x86_l_f8d);
x86_l_f7f:
	/* 0xf7f: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_f83:
	/* 0xf83: jbe    ed5 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xf83, 0xed5, x86_l_ed5);
x86_l_f89:
	/* 0xf89: jmp    f8d <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JMP(0xf89, 0xf8d, x86_l_f8d);
x86_l_f8b:
	/* 0xf8b: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_f8d:
	/* 0xf8d: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_f90:
	/* 0xf90: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_f93:
	/* 0xf93: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_f96:
	/* 0xf96: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_f98:
	/* 0xf98: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_f9b:
	/* 0xf9b: jmp    fa0 <filter_64ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_fa0 */
x86_l_fa0:
	/* 0xfa0: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_fa2:
	/* 0xfa2: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fa3:
	/* 0xfa3: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_fa7:
	/* 0xfa7: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_faa:
	/* 0xfaa: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_fad:
	/* 0xfad: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_fb1:
	/* 0xfb1: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_fb5:
	/* 0xfb5: mov    rdi,QWORD PTR [rip+0x5b0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_fbc:
	/* 0xfbc: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_fc1:
	/* 0xfc1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_fc6:
	/* 0xfc6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_fc9:
	/* 0xfc9: call   fce <filter_64ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_fce:
	/* 0xfce: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_fd1:
	/* 0xfd1: je     1005 <filter_64ty_map+0x65> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfd1, 0x1005, x86_l_1005);
x86_l_fd3:
	/* 0xfd3: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_fd6:
	/* 0xfd6: mov    rax,QWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fd9:
	/* 0xfd9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fde:
	/* 0xfde: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fe3:
	/* 0xfe3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_fe8:
	/* 0xfe8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_feb:
	/* 0xfeb: call   ff0 <filter_64ty_map+0x50> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ff0:
	/* 0xff0: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ff3:
	/* 0xff3: cmp    ecx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 11ULL);
x86_l_ff6:
	/* 0xff6: je     1013 <filter_64ty_map+0x73> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xff6, 0x1013, x86_l_1013);
x86_l_ff8:
	/* 0xff8: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_ffb:
	/* 0xffb: jne    101b <filter_64ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xffb, 0x101b, x86_l_101b);
x86_l_ffd:
	/* 0xffd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1000:
	/* 0x1000: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_1003:
	/* 0x1003: jmp    101d <filter_64ty_map+0x7d> */
	X86_SIM_X86_SUB_JMP(0x1003, 0x101d, x86_l_101d);
x86_l_1005:
	/* 0x1005: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1007:
	/* 0x1007: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_100b:
	/* 0x100b: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_100c:
	/* 0x100c: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_100e:
	/* 0x100e: jmp    1013 <filter_64ty_map+0x73> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1013:
	/* 0x1013: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1016:
	/* 0x1016: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1019:
	/* 0x1019: jmp    101d <filter_64ty_map+0x7d> */
	X86_SIM_X86_SUB_JMP(0x1019, 0x101d, x86_l_101d);
x86_l_101b:
	/* 0x101b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_101d:
	/* 0x101d: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1020:
	/* 0x1020: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1024:
	/* 0x1024: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1025:
	/* 0x1025: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1027:
	/* 0x1027: jmp    102c <filter_char_buf_postfix> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_102c */
x86_l_102c:
	/* 0x102c: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_102e:
	/* 0x102e: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1030:
	/* 0x1030: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1031:
	/* 0x1031: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_1035:
	/* 0x1035: mov    ebx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDX, X86_WIDTH_32);
x86_l_1037:
	/* 0x1037: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_103a:
	/* 0x103a: mov    DWORD PTR [rsp+0xc],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_103e:
	/* 0x103e: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1046:
	/* 0x1046: mov    rdi,QWORD PTR [rip+0x1ff0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_postfix_maps));
x86_l_104d:
	/* 0x104d: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1052:
	/* 0x1052: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1057:
	/* 0x1057: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_105a:
	/* 0x105a: call   105f <filter_char_buf_postfix+0x33> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_105f:
	/* 0x105f: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1062:
	/* 0x1062: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1064:
	/* 0x1064: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
x86_l_1066:
	/* 0x1066: je     117c <filter_char_buf_postfix+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1066, 0x117c, x86_l_117c);
x86_l_106c:
	/* 0x106c: test   r15,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64);
x86_l_106f:
	/* 0x106f: je     117c <filter_char_buf_postfix+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x106f, 0x117c, x86_l_117c);
x86_l_1075:
	/* 0x1075: mov    rdi,QWORD PTR [rip+0x1ff0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_postfix_maps_heap));
x86_l_107c:
	/* 0x107c: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1081:
	/* 0x1081: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1086:
	/* 0x1086: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1089:
	/* 0x1089: call   108e <filter_char_buf_postfix+0x62> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_108e:
	/* 0x108e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1091:
	/* 0x1091: je     117a <filter_char_buf_postfix+0x14e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1091, 0x117a, x86_l_117a);
x86_l_1097:
	/* 0x1097: mov    rsi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_109a:
	/* 0x109a: cmp    ebx,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 127ULL);
x86_l_109d:
	/* 0x109d: mov    eax,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 127ULL);
x86_l_10a2:
	/* 0x10a2: cmovb  eax,ebx */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RBX, X86_WIDTH_32, X86_CC_B);
x86_l_10a5:
	/* 0x10a5: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_10a8:
	/* 0x10a8: mov    DWORD PTR [rsi],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10aa:
	/* 0x10aa: mov    eax,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_32);
x86_l_10ac:
	/* 0x10ac: lea    ecx,[rbx-0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_10af:
	/* 0x10af: mov    rdx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_10b2:
	/* 0x10b2: add    rdx,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_10b6:
	/* 0x10b6: lea    edi,[rbx-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_10b9:
	/* 0x10b9: lea    r8d,[rbx-0x2] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_10bd:
	/* 0x10bd: dec    ebx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_10bf:
	/* 0x10bf: mov    r9,0xfffffffffffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_64, 18446744073709551613ULL);
x86_l_10c6:
	/* 0x10c6: lea    r10d,[rbx+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_10ca:
	/* 0x10ca: add    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_10ce:
	/* 0x10ce: and    r10d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_10d5:
	/* 0x10d5: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_10da:
	/* 0x10da: mov    BYTE PTR [rdx-0x3],r10b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_10de:
	/* 0x10de: lea    r10,[rax+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_10e2:
	/* 0x10e2: cmp    r10,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 18446744073709551614ULL);
x86_l_10e6:
	/* 0x10e6: je     115d <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10e6, 0x115d, x86_l_115d);
x86_l_10e8:
	/* 0x10e8: lea    r11d,[r8+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_10ec:
	/* 0x10ec: add    r11d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_10f0:
	/* 0x10f0: and    r11d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_10f7:
	/* 0x10f7: movzx  r11d,BYTE PTR [r14+r11*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_10fc:
	/* 0x10fc: mov    BYTE PTR [rdx-0x2],r11b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_1100:
	/* 0x1100: cmp    r10,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_1104:
	/* 0x1104: je     115d <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1104, 0x115d, x86_l_115d);
x86_l_1106:
	/* 0x1106: lea    r10d,[rdi+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_110a:
	/* 0x110a: add    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_110e:
	/* 0x110e: and    r10d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1115:
	/* 0x1115: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_111a:
	/* 0x111a: mov    BYTE PTR [rdx-0x1],r10b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_111e:
	/* 0x111e: mov    r10,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RAX, X86_WIDTH_64);
x86_l_1121:
	/* 0x1121: add    r10,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1124:
	/* 0x1124: je     115d <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1124, 0x115d, x86_l_115d);
x86_l_1126:
	/* 0x1126: cmp    r9,0xffffffffffffff81 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_64, 18446744073709551489ULL);
x86_l_112a:
	/* 0x112a: je     115d <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x112a, 0x115d, x86_l_115d);
x86_l_112c:
	/* 0x112c: lea    r10d,[rcx+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1130:
	/* 0x1130: add    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1134:
	/* 0x1134: and    r10d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_113b:
	/* 0x113b: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1140:
	/* 0x1140: mov    BYTE PTR [rdx],r10b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1143:
	/* 0x1143: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1147:
	/* 0x1147: lea    r10,[rax+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_114b:
	/* 0x114b: add    r10,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_114f:
	/* 0x114f: add    r9,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_1153:
	/* 0x1153: cmp    r10,0xfffffffffffffffd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 18446744073709551613ULL);
x86_l_1157:
	/* 0x1157: jne    10c6 <filter_char_buf_postfix+0x9a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1157, 0x10c6, x86_l_10c6);
x86_l_115d:
	/* 0x115d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1162:
	/* 0x1162: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1165:
	/* 0x1165: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1168:
	/* 0x1168: call   116d <filter_char_buf_postfix+0x141> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_116d:
	/* 0x116d: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1170:
	/* 0x1170: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1172:
	/* 0x1172: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_1175:
	/* 0x1175: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_1178:
	/* 0x1178: jmp    117c <filter_char_buf_postfix+0x150> */
	X86_SIM_X86_SUB_JMP(0x1178, 0x117c, x86_l_117c);
x86_l_117a:
	/* 0x117a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_117c:
	/* 0x117c: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1180:
	/* 0x1180: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1181:
	/* 0x1181: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1183:
	/* 0x1183: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1185:
	/* 0x1185: jmp    118a <filter_char_buf_prefix> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_118a */
x86_l_118a:
	/* 0x118a: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_118b:
	/* 0x118b: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_118d:
	/* 0x118d: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_118f:
	/* 0x118f: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1190:
	/* 0x1190: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1191:
	/* 0x1191: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_1193:
	/* 0x1193: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_1196:
	/* 0x1196: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_119a:
	/* 0x119a: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11a1:
	/* 0x11a1: mov    rdi,QWORD PTR [rip+0x1f30] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_prefix_maps));
x86_l_11a8:
	/* 0x11a8: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11ad:
	/* 0x11ad: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_11b2:
	/* 0x11b2: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_11b5:
	/* 0x11b5: call   11ba <filter_char_buf_prefix+0x30> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11ba:
	/* 0x11ba: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_11bd:
	/* 0x11bd: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11bf:
	/* 0x11bf: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_11c1:
	/* 0x11c1: je     1237 <filter_char_buf_prefix+0xad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11c1, 0x1237, x86_l_1237);
x86_l_11c3:
	/* 0x11c3: test   r14,r14 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64);
x86_l_11c6:
	/* 0x11c6: je     1237 <filter_char_buf_prefix+0xad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11c6, 0x1237, x86_l_1237);
x86_l_11c8:
	/* 0x11c8: mov    rdi,QWORD PTR [rip+0x1f30] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_11cf:
	/* 0x11cf: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_11d2:
	/* 0x11d2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_11d7:
	/* 0x11d7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_11da:
	/* 0x11da: call   11df <filter_char_buf_prefix+0x55> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11df:
	/* 0x11df: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_11e2:
	/* 0x11e2: je     1235 <filter_char_buf_prefix+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11e2, 0x1235, x86_l_1235);
x86_l_11e4:
	/* 0x11e4: cmp    ebp,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 255ULL);
x86_l_11ea:
	/* 0x11ea: mov    esi,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 255ULL);
x86_l_11ef:
	/* 0x11ef: cmovb  esi,ebp */
	X86_SIM_L_EXEC_CMOV(X86_RSI, X86_RBP, X86_WIDTH_32, X86_CC_B);
x86_l_11f2:
	/* 0x11f2: lea    ecx,[rsi*8+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_11f9:
	/* 0x11f9: mov    DWORD PTR [rax],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11fb:
	/* 0x11fb: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_11fe:
	/* 0x11fe: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1202:
	/* 0x1202: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1205:
	/* 0x1205: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_120a:
	/* 0x120a: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_120d:
	/* 0x120d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1210:
	/* 0x1210: call   1215 <filter_char_buf_prefix+0x8b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1215:
	/* 0x1215: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_121a:
	/* 0x121a: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_121d:
	/* 0x121d: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_1220:
	/* 0x1220: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1223:
	/* 0x1223: call   1228 <filter_char_buf_prefix+0x9e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1228:
	/* 0x1228: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_122b:
	/* 0x122b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_122d:
	/* 0x122d: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_1230:
	/* 0x1230: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_1233:
	/* 0x1233: jmp    1237 <filter_char_buf_prefix+0xad> */
	X86_SIM_X86_SUB_JMP(0x1233, 0x1237, x86_l_1237);
x86_l_1235:
	/* 0x1235: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1237:
	/* 0x1237: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_123b:
	/* 0x123b: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_123c:
	/* 0x123c: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_123e:
	/* 0x123e: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1240:
	/* 0x1240: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1241:
	/* 0x1241: jmp    1246 <filter_char_buf_equal> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1246 */
x86_l_1246:
	/* 0x1246: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1247:
	/* 0x1247: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1249:
	/* 0x1249: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_124b:
	/* 0x124b: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_124d:
	/* 0x124d: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_124f:
	/* 0x124f: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1250:
	/* 0x1250: sub    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_1254:
	/* 0x1254: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_125c:
	/* 0x125c: cmp    edx,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4096ULL);
x86_l_1262:
	/* 0x1262: ja     15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1262, 0x15e2, x86_l_15e2);
x86_l_1268:
	/* 0x1268: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_126a:
	/* 0x126a: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_126d:
	/* 0x126d: cmp    eax,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 144ULL);
x86_l_1272:
	/* 0x1272: ja     12bb <filter_char_buf_equal+0x75> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1272, 0x12bb, x86_l_12bb);
x86_l_1274:
	/* 0x1274: test   bp,bp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_16);
x86_l_1277:
	/* 0x1277: je     128a <filter_char_buf_equal+0x44> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1277, 0x128a, x86_l_128a);
x86_l_1279:
	/* 0x1279: mov    ecx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 24ULL);
x86_l_127e:
	/* 0x127e: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_1280:
	/* 0x1280: cdq */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 31) & 1ULL)));
x86_l_1281:
	/* 0x1281: idiv   ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, X86_DIV_AUX_SIGNED, 0);
x86_l_1283:
	/* 0x1283: mov    r14d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBP, X86_WIDTH_32);
x86_l_1286:
	/* 0x1286: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_1288:
	/* 0x1288: je     12aa <filter_char_buf_equal+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1288, 0x12aa, x86_l_12aa);
x86_l_128a:
	/* 0x128a: mov    ecx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 24ULL);
x86_l_128f:
	/* 0x128f: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_1291:
	/* 0x1291: cdq */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 31) & 1ULL)));
x86_l_1292:
	/* 0x1292: idiv   ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, X86_DIV_AUX_SIGNED, 0);
x86_l_1294:
	/* 0x1294: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1297:
	/* 0x1297: lea    eax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_129a:
	/* 0x129a: add    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_129d:
	/* 0x129d: movzx  r14d,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_12a1:
	/* 0x12a1: cmp    r14d,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 144ULL);
x86_l_12a8:
	/* 0x12a8: ja     12f9 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x12a8, 0x12f9, x86_l_12f9);
x86_l_12aa:
	/* 0x12aa: mov    eax,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R14, X86_WIDTH_32);
x86_l_12ad:
	/* 0x12ad: cdq */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 31) & 1ULL)));
x86_l_12ae:
	/* 0x12ae: idiv   ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, X86_DIV_AUX_SIGNED, 0);
x86_l_12b0:
	/* 0x12b0: mov    r15d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_32);
x86_l_12b3:
	/* 0x12b3: dec    r15d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_12b6:
	/* 0x12b6: jmp    1344 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x12b6, 0x1344, x86_l_1344);
x86_l_12bb:
	/* 0x12bb: mov    r14d,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 256ULL);
x86_l_12c1:
	/* 0x12c1: cmp    eax,0x101 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 257ULL);
x86_l_12c6:
	/* 0x12c6: jb     12f9 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x12c6, 0x12f9, x86_l_12f9);
x86_l_12c8:
	/* 0x12c8: mov    r14d,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 512ULL);
x86_l_12ce:
	/* 0x12ce: cmp    eax,0x201 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 513ULL);
x86_l_12d3:
	/* 0x12d3: jb     12f9 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x12d3, 0x12f9, x86_l_12f9);
x86_l_12d5:
	/* 0x12d5: mov    r14d,0x400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 1024ULL);
x86_l_12db:
	/* 0x12db: cmp    eax,0x401 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1025ULL);
x86_l_12e0:
	/* 0x12e0: jb     12f9 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x12e0, 0x12f9, x86_l_12f9);
x86_l_12e2:
	/* 0x12e2: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_12e5:
	/* 0x12e5: cmp    eax,0x801 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2049ULL);
x86_l_12ea:
	/* 0x12ea: setae  r14b */
	X86_SIM_L_EXEC_SETCC(X86_R14, X86_CC_AE);
x86_l_12ee:
	/* 0x12ee: shl    r14d,0xb */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_12f2:
	/* 0x12f2: add    r14d,0x800 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_12f9:
	/* 0x12f9: lea    eax,[r14-0x100] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_1300:
	/* 0x1300: rorx   eax,eax,0x8 */
	X86_SIM_L_EXEC_RORX(X86_RAX, X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1306:
	/* 0x1306: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1309:
	/* 0x1309: jg     131c <filter_char_buf_equal+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1309, 0x131c, x86_l_131c);
x86_l_130b:
	/* 0x130b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_130d:
	/* 0x130d: je     1336 <filter_char_buf_equal+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x130d, 0x1336, x86_l_1336);
x86_l_130f:
	/* 0x130f: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1312:
	/* 0x1312: jne    132e <filter_char_buf_equal+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1312, 0x132e, x86_l_132e);
x86_l_1314:
	/* 0x1314: mov    r15d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 7ULL);
x86_l_131a:
	/* 0x131a: jmp    1344 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x131a, 0x1344, x86_l_1344);
x86_l_131c:
	/* 0x131c: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_131f:
	/* 0x131f: je     133e <filter_char_buf_equal+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x131f, 0x133e, x86_l_133e);
x86_l_1321:
	/* 0x1321: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_1324:
	/* 0x1324: jne    132e <filter_char_buf_equal+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1324, 0x132e, x86_l_132e);
x86_l_1326:
	/* 0x1326: mov    r15d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 9ULL);
x86_l_132c:
	/* 0x132c: jmp    1344 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x132c, 0x1344, x86_l_1344);
x86_l_132e:
	/* 0x132e: mov    r15d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 10ULL);
x86_l_1334:
	/* 0x1334: jmp    1344 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x1334, 0x1344, x86_l_1344);
x86_l_1336:
	/* 0x1336: mov    r15d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 6ULL);
x86_l_133c:
	/* 0x133c: jmp    1344 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x133c, 0x1344, x86_l_1344);
x86_l_133e:
	/* 0x133e: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_1344:
	/* 0x1344: mov    eax,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_32);
x86_l_1347:
	/* 0x1347: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_134a:
	/* 0x134a: mov    r13d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_134f:
	/* 0x134f: cmp    r13d,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 4294967295ULL);
x86_l_1353:
	/* 0x1353: je     15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1353, 0x15e2, x86_l_15e2);
x86_l_1359:
	/* 0x1359: mov    QWORD PTR [rsp+0x20],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_135e:
	/* 0x135e: mov    rdi,QWORD PTR [rip+0x1b80] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_heap));
x86_l_1365:
	/* 0x1365: lea    r12,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_136a:
	/* 0x136a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_136f:
	/* 0x136f: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_1372:
	/* 0x1372: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1375:
	/* 0x1375: call   137a <filter_char_buf_equal+0x134> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_137a:
	/* 0x137a: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_137d:
	/* 0x137d: mov    rdi,QWORD PTR [rip+0x1b80] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)heap_ro_zero));
x86_l_1384:
	/* 0x1384: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1389:
	/* 0x1389: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_138c:
	/* 0x138c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_138f:
	/* 0x138f: call   1394 <filter_char_buf_equal+0x14e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1394:
	/* 0x1394: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1397:
	/* 0x1397: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1399:
	/* 0x1399: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_139e:
	/* 0x139e: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
x86_l_13a1:
	/* 0x13a1: je     15e4 <filter_char_buf_equal+0x39e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13a1, 0x15e4, x86_l_15e4);
x86_l_13a7:
	/* 0x13a7: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_13aa:
	/* 0x13aa: je     15e4 <filter_char_buf_equal+0x39e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13aa, 0x15e4, x86_l_15e4);
x86_l_13b0:
	/* 0x13b0: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_13b5:
	/* 0x13b5: cmp    r15d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 5ULL);
x86_l_13b9:
	/* 0x13b9: jg     1402 <filter_char_buf_equal+0x1bc> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x13b9, 0x1402, x86_l_1402);
x86_l_13bb:
	/* 0x13bb: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13c0:
	/* 0x13c0: mov    BYTE PTR [rax],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13c3:
	/* 0x13c3: lea    rdi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_13c7:
	/* 0x13c7: mov    r12d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_13ca:
	/* 0x13ca: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_13cf:
	/* 0x13cf: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13d4:
	/* 0x13d4: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_13d6:
	/* 0x13d6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_13d9:
	/* 0x13d9: call   13de <filter_char_buf_equal+0x198> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13de:
	/* 0x13de: sub    r14d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_13e1:
	/* 0x13e1: jbe    1453 <filter_char_buf_equal+0x20d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x13e1, 0x1453, x86_l_1453);
x86_l_13e3:
	/* 0x13e3: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13e8:
	/* 0x13e8: lea    rdi,[rax+r12*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_13ec:
	/* 0x13ec: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_13ef:
	/* 0x13ef: and    r14d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_13f6:
	/* 0x13f6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_13fb:
	/* 0x13fb: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1400:
	/* 0x1400: jmp    1448 <filter_char_buf_equal+0x202> */
	X86_SIM_X86_SUB_JMP(0x1400, 0x1448, x86_l_1448);
x86_l_1402:
	/* 0x1402: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1407:
	/* 0x1407: mov    WORD PTR [rax],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_140a:
	/* 0x140a: lea    rdi,[rax+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_140e:
	/* 0x140e: mov    r12d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_1411:
	/* 0x1411: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1416:
	/* 0x1416: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_141b:
	/* 0x141b: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_141d:
	/* 0x141d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1420:
	/* 0x1420: call   1425 <filter_char_buf_equal+0x1df> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1425:
	/* 0x1425: sub    r14d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1428:
	/* 0x1428: jbe    1453 <filter_char_buf_equal+0x20d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1428, 0x1453, x86_l_1453);
x86_l_142a:
	/* 0x142a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_142f:
	/* 0x142f: lea    rdi,[rax+r12*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_1433:
	/* 0x1433: add    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_1437:
	/* 0x1437: and    r14d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_143e:
	/* 0x143e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1443:
	/* 0x1443: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1448:
	/* 0x1448: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_144b:
	/* 0x144b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_144e:
	/* 0x144e: call   1453 <filter_char_buf_equal+0x20d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1453:
	/* 0x1453: mov    DWORD PTR [rsp+0x4],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1458:
	/* 0x1458: cmp    r15d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 4ULL);
x86_l_145c:
	/* 0x145c: jle    1498 <filter_char_buf_equal+0x252> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x145c, 0x1498, x86_l_1498);
x86_l_145e:
	/* 0x145e: cmp    r15d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 7ULL);
x86_l_1462:
	/* 0x1462: jg     14d2 <filter_char_buf_equal+0x28c> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1462, 0x14d2, x86_l_14d2);
x86_l_1464:
	/* 0x1464: cmp    r15d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 5ULL);
x86_l_1468:
	/* 0x1468: je     158a <filter_char_buf_equal+0x344> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1468, 0x158a, x86_l_158a);
x86_l_146e:
	/* 0x146e: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_1472:
	/* 0x1472: je     1551 <filter_char_buf_equal+0x30b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1472, 0x1551, x86_l_1551);
x86_l_1478:
	/* 0x1478: cmp    r15d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 7ULL);
x86_l_147c:
	/* 0x147c: jne    15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x147c, 0x15e2, x86_l_15e2);
x86_l_1482:
	/* 0x1482: mov    rdi,QWORD PTR [rip+0x1b80] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_7));
x86_l_1489:
	/* 0x1489: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_148e:
	/* 0x148e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1493:
	/* 0x1493: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1493, 0x15ae, x86_l_15ae);
x86_l_1498:
	/* 0x1498: cmp    r15d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 1ULL);
x86_l_149c:
	/* 0x149c: jle    1506 <filter_char_buf_equal+0x2c0> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x149c, 0x1506, x86_l_1506);
x86_l_149e:
	/* 0x149e: cmp    r15d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 2ULL);
x86_l_14a2:
	/* 0x14a2: je     1577 <filter_char_buf_equal+0x331> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14a2, 0x1577, x86_l_1577);
x86_l_14a8:
	/* 0x14a8: cmp    r15d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 3ULL);
x86_l_14ac:
	/* 0x14ac: je     153e <filter_char_buf_equal+0x2f8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14ac, 0x153e, x86_l_153e);
x86_l_14b2:
	/* 0x14b2: cmp    r15d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 4ULL);
x86_l_14b6:
	/* 0x14b6: jne    15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14b6, 0x15e2, x86_l_15e2);
x86_l_14bc:
	/* 0x14bc: mov    rdi,QWORD PTR [rip+0x1b80] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_4));
x86_l_14c3:
	/* 0x14c3: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_14c8:
	/* 0x14c8: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_14cd:
	/* 0x14cd: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x14cd, 0x15ae, x86_l_15ae);
x86_l_14d2:
	/* 0x14d2: cmp    r15d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 8ULL);
x86_l_14d6:
	/* 0x14d6: je     159d <filter_char_buf_equal+0x357> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14d6, 0x159d, x86_l_159d);
x86_l_14dc:
	/* 0x14dc: cmp    r15d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 9ULL);
x86_l_14e0:
	/* 0x14e0: je     1564 <filter_char_buf_equal+0x31e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14e0, 0x1564, x86_l_1564);
x86_l_14e6:
	/* 0x14e6: cmp    r15d,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 10ULL);
x86_l_14ea:
	/* 0x14ea: jne    15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14ea, 0x15e2, x86_l_15e2);
x86_l_14f0:
	/* 0x14f0: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_10));
x86_l_14f7:
	/* 0x14f7: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_14fc:
	/* 0x14fc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1501:
	/* 0x1501: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1501, 0x15ae, x86_l_15ae);
x86_l_1506:
	/* 0x1506: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_1509:
	/* 0x1509: je     152b <filter_char_buf_equal+0x2e5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1509, 0x152b, x86_l_152b);
x86_l_150b:
	/* 0x150b: cmp    r15d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 1ULL);
x86_l_150f:
	/* 0x150f: jne    15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x150f, 0x15e2, x86_l_15e2);
x86_l_1515:
	/* 0x1515: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_1));
x86_l_151c:
	/* 0x151c: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1521:
	/* 0x1521: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1526:
	/* 0x1526: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1526, 0x15ae, x86_l_15ae);
x86_l_152b:
	/* 0x152b: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_0));
x86_l_1532:
	/* 0x1532: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1537:
	/* 0x1537: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_153c:
	/* 0x153c: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x153c, 0x15ae, x86_l_15ae);
x86_l_153e:
	/* 0x153e: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_3));
x86_l_1545:
	/* 0x1545: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_154a:
	/* 0x154a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_154f:
	/* 0x154f: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x154f, 0x15ae, x86_l_15ae);
x86_l_1551:
	/* 0x1551: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_6));
x86_l_1558:
	/* 0x1558: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_155d:
	/* 0x155d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1562:
	/* 0x1562: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1562, 0x15ae, x86_l_15ae);
x86_l_1564:
	/* 0x1564: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_9));
x86_l_156b:
	/* 0x156b: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1570:
	/* 0x1570: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1575:
	/* 0x1575: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1575, 0x15ae, x86_l_15ae);
x86_l_1577:
	/* 0x1577: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_2));
x86_l_157e:
	/* 0x157e: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1583:
	/* 0x1583: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1588:
	/* 0x1588: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1588, 0x15ae, x86_l_15ae);
x86_l_158a:
	/* 0x158a: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_5));
x86_l_1591:
	/* 0x1591: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1596:
	/* 0x1596: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_159b:
	/* 0x159b: jmp    15ae <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x159b, 0x15ae, x86_l_15ae);
x86_l_159d:
	/* 0x159d: mov    rdi,QWORD PTR [rip+0x1b7c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_8));
x86_l_15a4:
	/* 0x15a4: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15a9:
	/* 0x15a9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15ae:
	/* 0x15ae: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15b3:
	/* 0x15b3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_15b6:
	/* 0x15b6: call   15bb <filter_char_buf_equal+0x375> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15bb:
	/* 0x15bb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_15be:
	/* 0x15be: je     15e2 <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15be, 0x15e2, x86_l_15e2);
x86_l_15c0:
	/* 0x15c0: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_15c3:
	/* 0x15c3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15c8:
	/* 0x15c8: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15cd:
	/* 0x15cd: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_15d0:
	/* 0x15d0: call   15d5 <filter_char_buf_equal+0x38f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15d5:
	/* 0x15d5: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_15d8:
	/* 0x15d8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_15da:
	/* 0x15da: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_15dd:
	/* 0x15dd: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_15e0:
	/* 0x15e0: jmp    15e4 <filter_char_buf_equal+0x39e> */
	X86_SIM_X86_SUB_JMP(0x15e0, 0x15e4, x86_l_15e4);
x86_l_15e2:
	/* 0x15e2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_15e4:
	/* 0x15e4: add    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_15e8:
	/* 0x15e8: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_15e9:
	/* 0x15e9: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_15eb:
	/* 0x15eb: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_15ed:
	/* 0x15ed: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_15ef:
	/* 0x15ef: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_15f1:
	/* 0x15f1: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_15f2:
	/* 0x15f2: jmp    15f7 <filter_char_substring> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_15f7 */
x86_l_15f7:
	/* 0x15f7: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_15f8:
	/* 0x15f8: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_15fa:
	/* 0x15fa: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_15fc:
	/* 0x15fc: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_15fe:
	/* 0x15fe: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1600:
	/* 0x1600: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1601:
	/* 0x1601: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1602:
	/* 0x1602: mov    r15,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RSI, X86_WIDTH_64);
x86_l_1605:
	/* 0x1605: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_1608:
	/* 0x1608: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_160a:
	/* 0x160a: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_160c:
	/* 0x160c: je     16da <filter_char_substring+0xe3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x160c, 0x16da, x86_l_16da);
x86_l_1612:
	/* 0x1612: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_1614:
	/* 0x1614: je     177d <filter_char_substring+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1614, 0x177d, x86_l_177d);
x86_l_161a:
	/* 0x161a: lea    r13,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_161f:
	/* 0x161f: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1621:
	/* 0x1621: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1624:
	/* 0x1624: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_1629:
	/* 0x1629: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_162d:
	/* 0x162d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1632:
	/* 0x1632: mov    rdi,QWORD PTR [rip+0x2223] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)substring_map));
x86_l_1639:
	/* 0x1639: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_163c:
	/* 0x163c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_163f:
	/* 0x163f: call   1644 <filter_char_substring+0x4d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1644:
	/* 0x1644: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1647:
	/* 0x1647: je     180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1647, 0x180d, x86_l_180d);
x86_l_164d:
	/* 0x164d: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1650:
	/* 0x1650: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1652:
	/* 0x1652: jmp    165f <filter_char_substring+0x68> */
	X86_SIM_X86_SUB_JMP(0x1652, 0x165f, x86_l_165f);
x86_l_1654:
	/* 0x1654: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1657:
	/* 0x1657: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_165a:
	/* 0x165a: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_165d:
	/* 0x165d: je     16b5 <filter_char_substring+0xbe> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x165d, 0x16b5, x86_l_16b5);
x86_l_165f:
	/* 0x165f: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1661:
	/* 0x1661: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1665:
	/* 0x1665: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_1668:
	/* 0x1668: jae    1654 <filter_char_substring+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1668, 0x1654, x86_l_1654);
x86_l_166a:
	/* 0x166a: movsx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_166e:
	/* 0x166e: test   edi,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32);
x86_l_1670:
	/* 0x1670: je     16ad <filter_char_substring+0xb6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1670, 0x16ad, x86_l_16ad);
x86_l_1672:
	/* 0x1672: movsx  r9d,BYTE PTR [rdx+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1677:
	/* 0x1677: lea    r10d,[r9-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_167b:
	/* 0x167b: mov    r8d,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R9, X86_WIDTH_32);
x86_l_167e:
	/* 0x167e: or     r8d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_1682:
	/* 0x1682: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_1686:
	/* 0x1686: cmovae r8d,r9d */
	X86_SIM_L_EXEC_CMOV(X86_R8, X86_R9, X86_WIDTH_32, X86_CC_AE);
x86_l_168a:
	/* 0x168a: lea    r10d,[rdi-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_168e:
	/* 0x168e: mov    r9d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RDI, X86_WIDTH_32);
x86_l_1691:
	/* 0x1691: or     r9d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_1695:
	/* 0x1695: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_1699:
	/* 0x1699: cmovae r9d,edi */
	X86_SIM_L_EXEC_CMOV(X86_R9, X86_RDI, X86_WIDTH_32, X86_CC_AE);
x86_l_169d:
	/* 0x169d: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_16a1:
	/* 0x16a1: ja     1654 <filter_char_substring+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x16a1, 0x1654, x86_l_1654);
x86_l_16a3:
	/* 0x16a3: inc    rsi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16a6:
	/* 0x16a6: cmp    r8d,r9d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_R9, X86_WIDTH_32);
x86_l_16a9:
	/* 0x16a9: je     1661 <filter_char_substring+0x6a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16a9, 0x1661, x86_l_1661);
x86_l_16ab:
	/* 0x16ab: jmp    1654 <filter_char_substring+0x5d> */
	X86_SIM_X86_SUB_JMP(0x16ab, 0x1654, x86_l_1654);
x86_l_16ad:
	/* 0x16ad: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_16af:
	/* 0x16af: jns    1822 <filter_char_substring+0x22b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x16af, 0x1822, x86_l_1822);
x86_l_16b5:
	/* 0x16b5: lea    eax,[r12+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_16ba:
	/* 0x16ba: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_16be:
	/* 0x16be: jae    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x16be, 0x180d, x86_l_180d);
x86_l_16c4:
	/* 0x16c4: add    r12d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_16c8:
	/* 0x16c8: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16cb:
	/* 0x16cb: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_16cf:
	/* 0x16cf: jne    1624 <filter_char_substring+0x2d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x16cf, 0x1624, x86_l_1624);
x86_l_16d5:
	/* 0x16d5: jmp    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JMP(0x16d5, 0x180d, x86_l_180d);
x86_l_16da:
	/* 0x16da: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_16dc:
	/* 0x16dc: je     17c6 <filter_char_substring+0x1cf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16dc, 0x17c6, x86_l_17c6);
x86_l_16e2:
	/* 0x16e2: lea    r13,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16e7:
	/* 0x16e7: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16e9:
	/* 0x16e9: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16ec:
	/* 0x16ec: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_16f1:
	/* 0x16f1: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16f5:
	/* 0x16f5: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_16fa:
	/* 0x16fa: mov    rdi,QWORD PTR [rip+0x222b] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)substring_map));
x86_l_1701:
	/* 0x1701: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_1704:
	/* 0x1704: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1707:
	/* 0x1707: call   170c <filter_char_substring+0x115> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_170c:
	/* 0x170c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_170f:
	/* 0x170f: je     180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x170f, 0x180d, x86_l_180d);
x86_l_1715:
	/* 0x1715: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1718:
	/* 0x1718: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_171a:
	/* 0x171a: jmp    1727 <filter_char_substring+0x130> */
	X86_SIM_X86_SUB_JMP(0x171a, 0x1727, x86_l_1727);
x86_l_171c:
	/* 0x171c: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_171f:
	/* 0x171f: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1722:
	/* 0x1722: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_1725:
	/* 0x1725: je     1758 <filter_char_substring+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1725, 0x1758, x86_l_1758);
x86_l_1727:
	/* 0x1727: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1729:
	/* 0x1729: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_172d:
	/* 0x172d: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_1730:
	/* 0x1730: jae    171c <filter_char_substring+0x125> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1730, 0x171c, x86_l_171c);
x86_l_1732:
	/* 0x1732: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1736:
	/* 0x1736: test   dil,dil */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8);
x86_l_1739:
	/* 0x1739: je     1750 <filter_char_substring+0x159> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1739, 0x1750, x86_l_1750);
x86_l_173b:
	/* 0x173b: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_173f:
	/* 0x173f: ja     171c <filter_char_substring+0x125> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x173f, 0x171c, x86_l_171c);
x86_l_1741:
	/* 0x1741: lea    r8,[rsi+0x1] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1745:
	/* 0x1745: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1749:
	/* 0x1749: mov    rsi,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R8, X86_WIDTH_64);
x86_l_174c:
	/* 0x174c: je     1729 <filter_char_substring+0x132> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x174c, 0x1729, x86_l_1729);
x86_l_174e:
	/* 0x174e: jmp    171c <filter_char_substring+0x125> */
	X86_SIM_X86_SUB_JMP(0x174e, 0x171c, x86_l_171c);
x86_l_1750:
	/* 0x1750: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1752:
	/* 0x1752: jns    1822 <filter_char_substring+0x22b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1752, 0x1822, x86_l_1822);
x86_l_1758:
	/* 0x1758: lea    eax,[r12+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_175d:
	/* 0x175d: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1761:
	/* 0x1761: jae    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1761, 0x180d, x86_l_180d);
x86_l_1767:
	/* 0x1767: add    r12d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_176b:
	/* 0x176b: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_176e:
	/* 0x176e: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_1772:
	/* 0x1772: jne    16ec <filter_char_substring+0xf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1772, 0x16ec, x86_l_16ec);
x86_l_1778:
	/* 0x1778: jmp    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JMP(0x1778, 0x180d, x86_l_180d);
x86_l_177d:
	/* 0x177d: mov    ebx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 16ULL);
x86_l_1782:
	/* 0x1782: mov    r15,QWORD PTR [rip+0x2237] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, 0, ((__u64)(long)substring_map));
x86_l_1789:
	/* 0x1789: lea    r12,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_178e:
	/* 0x178e: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1792:
	/* 0x1792: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1796:
	/* 0x1796: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_179b:
	/* 0x179b: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_179e:
	/* 0x179e: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_17a1:
	/* 0x17a1: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_17a4:
	/* 0x17a4: call   17a9 <filter_char_substring+0x1b2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17a9:
	/* 0x17a9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17ac:
	/* 0x17ac: je     180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17ac, 0x180d, x86_l_180d);
x86_l_17ae:
	/* 0x17ae: add    rbx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_17b2:
	/* 0x17b2: lea    eax,[rbx-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_17b5:
	/* 0x17b5: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_17b9:
	/* 0x17b9: jae    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x17b9, 0x180d, x86_l_180d);
x86_l_17bb:
	/* 0x17bb: cmp    rbx,0x1a0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 416ULL);
x86_l_17c2:
	/* 0x17c2: jne    178e <filter_char_substring+0x197> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x17c2, 0x178e, x86_l_178e);
x86_l_17c4:
	/* 0x17c4: jmp    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JMP(0x17c4, 0x180d, x86_l_180d);
x86_l_17c6:
	/* 0x17c6: mov    ebx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 16ULL);
x86_l_17cb:
	/* 0x17cb: mov    r15,QWORD PTR [rip+0x2239] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, 0, ((__u64)(long)substring_map));
x86_l_17d2:
	/* 0x17d2: lea    r12,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17d7:
	/* 0x17d7: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_17db:
	/* 0x17db: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17df:
	/* 0x17df: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_17e4:
	/* 0x17e4: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_17e7:
	/* 0x17e7: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_17ea:
	/* 0x17ea: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_17ed:
	/* 0x17ed: call   17f2 <filter_char_substring+0x1fb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17f2:
	/* 0x17f2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17f5:
	/* 0x17f5: je     180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17f5, 0x180d, x86_l_180d);
x86_l_17f7:
	/* 0x17f7: add    rbx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_17fb:
	/* 0x17fb: lea    eax,[rbx-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_17fe:
	/* 0x17fe: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1802:
	/* 0x1802: jae    180d <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1802, 0x180d, x86_l_180d);
x86_l_1804:
	/* 0x1804: cmp    rbx,0x1a0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 416ULL);
x86_l_180b:
	/* 0x180b: jne    17d7 <filter_char_substring+0x1e0> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x180b, 0x17d7, x86_l_17d7);
x86_l_180d:
	/* 0x180d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_180f:
	/* 0x180f: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1813:
	/* 0x1813: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1814:
	/* 0x1814: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1816:
	/* 0x1816: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1818:
	/* 0x1818: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_181a:
	/* 0x181a: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_181c:
	/* 0x181c: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_181d:
	/* 0x181d: jmp    1822 <filter_char_substring+0x22b> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1822:
	/* 0x1822: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1827:
	/* 0x1827: jmp    180f <filter_char_substring+0x218> */
	X86_SIM_X86_SUB_JMP(0x1827, 0x180f, x86_l_180f);

	/* native subroutine native_link_sub_1829 */
x86_l_1829:
	/* 0x1829: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_182c:
	/* 0x182c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1831:
	/* 0x1831: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_1835:
	/* 0x1835: ja     18b0 <filter_16ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1835, 0x18b0, x86_l_18b0);
x86_l_1837:
	/* 0x1837: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_1841:
	/* 0x1841: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1845:
	/* 0x1845: jae    184c <filter_16ty_selector_val+0x23> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1845, 0x184c, x86_l_184c);
x86_l_1847:
	/* 0x1847: jmp    184c <filter_16ty_selector_val+0x23> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_184c:
	/* 0x184c: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_1851:
	/* 0x1851: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1855:
	/* 0x1855: jae    1870 <filter_16ty_selector_val+0x47> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1855, 0x1870, x86_l_1870);
x86_l_1857:
	/* 0x1857: movzx  edx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_185a:
	/* 0x185a: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_185d:
	/* 0x185d: jne    1986 <filter_16ty_selector_val+0x15d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x185d, 0x1986, x86_l_1986);
x86_l_1863:
	/* 0x1863: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1865:
	/* 0x1865: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_1868:
	/* 0x1868: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_186b:
	/* 0x186b: jmp    1870 <filter_16ty_selector_val+0x47> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1870:
	/* 0x1870: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_1874:
	/* 0x1874: jne    18b0 <filter_16ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1874, 0x18b0, x86_l_18b0);
x86_l_1876:
	/* 0x1876: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1879:
	/* 0x1879: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_187c:
	/* 0x187c: jne    1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x187c, 0x1847, x86_l_1847);
x86_l_187e:
	/* 0x187e: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1881:
	/* 0x1881: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1884:
	/* 0x1884: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1884, 0x1a48, x86_l_1a48);
x86_l_188a:
	/* 0x188a: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_188d:
	/* 0x188d: jne    1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x188d, 0x1847, x86_l_1847);
x86_l_188f:
	/* 0x188f: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1892:
	/* 0x1892: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1892, 0x1a48, x86_l_1a48);
x86_l_1898:
	/* 0x1898: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_189b:
	/* 0x189b: jne    1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x189b, 0x1847, x86_l_1847);
x86_l_189d:
	/* 0x189d: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_18a0:
	/* 0x18a0: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18a0, 0x1a48, x86_l_1a48);
x86_l_18a6:
	/* 0x18a6: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_18a9:
	/* 0x18a9: jne    1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18a9, 0x1847, x86_l_1847);
x86_l_18ab:
	/* 0x18ab: jmp    1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x18ab, 0x1a48, x86_l_1a48);
x86_l_18b0:
	/* 0x18b0: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_18b3:
	/* 0x18b3: je     1922 <filter_16ty_selector_val+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18b3, 0x1922, x86_l_1922);
x86_l_18b5:
	/* 0x18b5: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_18b8:
	/* 0x18b8: jne    1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18b8, 0x1a48, x86_l_1a48);
x86_l_18be:
	/* 0x18be: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_18c1:
	/* 0x18c1: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_18c4:
	/* 0x18c4: ja     1a0f <filter_16ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x18c4, 0x1a0f, x86_l_1a0f);
x86_l_18ca:
	/* 0x18ca: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_18cf:
	/* 0x18cf: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_18d2:
	/* 0x18d2: jae    1a0f <filter_16ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18d2, 0x1a0f, x86_l_1a0f);
x86_l_18d8:
	/* 0x18d8: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_18db:
	/* 0x18db: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18de:
	/* 0x18de: jg     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x18de, 0x1847, x86_l_1847);
x86_l_18e4:
	/* 0x18e4: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18e7:
	/* 0x18e7: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_18ea:
	/* 0x18ea: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18ea, 0x1a48, x86_l_1a48);
x86_l_18f0:
	/* 0x18f0: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_18f3:
	/* 0x18f3: jg     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x18f3, 0x1847, x86_l_1847);
x86_l_18f9:
	/* 0x18f9: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_18fc:
	/* 0x18fc: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18fc, 0x1a48, x86_l_1a48);
x86_l_1902:
	/* 0x1902: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1905:
	/* 0x1905: jg     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1905, 0x1847, x86_l_1847);
x86_l_190b:
	/* 0x190b: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_190e:
	/* 0x190e: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x190e, 0x1a48, x86_l_1a48);
x86_l_1914:
	/* 0x1914: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1917:
	/* 0x1917: jg     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1917, 0x1847, x86_l_1847);
x86_l_191d:
	/* 0x191d: jmp    1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x191d, 0x1a48, x86_l_1a48);
x86_l_1922:
	/* 0x1922: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1925:
	/* 0x1925: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1928:
	/* 0x1928: ja     19d4 <filter_16ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1928, 0x19d4, x86_l_19d4);
x86_l_192e:
	/* 0x192e: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1933:
	/* 0x1933: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1936:
	/* 0x1936: jae    19d4 <filter_16ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1936, 0x19d4, x86_l_19d4);
x86_l_193c:
	/* 0x193c: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_193f:
	/* 0x193f: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1942:
	/* 0x1942: jl     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1942, 0x1847, x86_l_1847);
x86_l_1948:
	/* 0x1948: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_194b:
	/* 0x194b: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_194e:
	/* 0x194e: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x194e, 0x1a48, x86_l_1a48);
x86_l_1954:
	/* 0x1954: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1957:
	/* 0x1957: jl     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1957, 0x1847, x86_l_1847);
x86_l_195d:
	/* 0x195d: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1960:
	/* 0x1960: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1960, 0x1a48, x86_l_1a48);
x86_l_1966:
	/* 0x1966: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1969:
	/* 0x1969: jl     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1969, 0x1847, x86_l_1847);
x86_l_196f:
	/* 0x196f: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1972:
	/* 0x1972: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1972, 0x1a48, x86_l_1a48);
x86_l_1978:
	/* 0x1978: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_197b:
	/* 0x197b: jl     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x197b, 0x1847, x86_l_1847);
x86_l_1981:
	/* 0x1981: jmp    1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x1981, 0x1a48, x86_l_1a48);
x86_l_1986:
	/* 0x1986: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1989:
	/* 0x1989: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_198c:
	/* 0x198c: jb     19b3 <filter_16ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x198c, 0x19b3, x86_l_19b3);
x86_l_198e:
	/* 0x198e: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1991:
	/* 0x1991: je     1863 <filter_16ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1991, 0x1863, x86_l_1863);
x86_l_1997:
	/* 0x1997: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_199a:
	/* 0x199a: jb     19b3 <filter_16ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x199a, 0x19b3, x86_l_19b3);
x86_l_199c:
	/* 0x199c: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_199f:
	/* 0x199f: je     1863 <filter_16ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x199f, 0x1863, x86_l_1863);
x86_l_19a5:
	/* 0x19a5: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_19a8:
	/* 0x19a8: jb     19b3 <filter_16ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19a8, 0x19b3, x86_l_19b3);
x86_l_19aa:
	/* 0x19aa: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_19ad:
	/* 0x19ad: je     1863 <filter_16ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x19ad, 0x1863, x86_l_1863);
x86_l_19b3:
	/* 0x19b3: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_19b6:
	/* 0x19b6: ja     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x19b6, 0x1a48, x86_l_1a48);
x86_l_19bc:
	/* 0x19bc: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_19be:
	/* 0x19be: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_19c8:
	/* 0x19c8: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_19cc:
	/* 0x19cc: jb     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19cc, 0x1847, x86_l_1847);
x86_l_19d2:
	/* 0x19d2: jmp    1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x19d2, 0x1a48, x86_l_1a48);
x86_l_19d4:
	/* 0x19d4: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_19d7:
	/* 0x19d7: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19da:
	/* 0x19da: jb     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19da, 0x1847, x86_l_1847);
x86_l_19e0:
	/* 0x19e0: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19e3:
	/* 0x19e3: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_19e6:
	/* 0x19e6: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19e6, 0x1a48, x86_l_1a48);
x86_l_19e8:
	/* 0x19e8: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19eb:
	/* 0x19eb: jb     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19eb, 0x1847, x86_l_1847);
x86_l_19f1:
	/* 0x19f1: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_19f4:
	/* 0x19f4: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19f4, 0x1a48, x86_l_1a48);
x86_l_19f6:
	/* 0x19f6: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19f9:
	/* 0x19f9: jb     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19f9, 0x1847, x86_l_1847);
x86_l_19ff:
	/* 0x19ff: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1a02:
	/* 0x1a02: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a02, 0x1a48, x86_l_1a48);
x86_l_1a04:
	/* 0x1a04: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a07:
	/* 0x1a07: jb     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a07, 0x1847, x86_l_1847);
x86_l_1a0d:
	/* 0x1a0d: jmp    1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x1a0d, 0x1a48, x86_l_1a48);
x86_l_1a0f:
	/* 0x1a0f: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a12:
	/* 0x1a12: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a15:
	/* 0x1a15: ja     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a15, 0x1847, x86_l_1847);
x86_l_1a1b:
	/* 0x1a1b: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a1e:
	/* 0x1a1e: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1a21:
	/* 0x1a21: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a21, 0x1a48, x86_l_1a48);
x86_l_1a23:
	/* 0x1a23: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a26:
	/* 0x1a26: ja     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a26, 0x1847, x86_l_1847);
x86_l_1a2c:
	/* 0x1a2c: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1a2f:
	/* 0x1a2f: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a2f, 0x1a48, x86_l_1a48);
x86_l_1a31:
	/* 0x1a31: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a34:
	/* 0x1a34: ja     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a34, 0x1847, x86_l_1847);
x86_l_1a3a:
	/* 0x1a3a: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1a3d:
	/* 0x1a3d: jb     1a48 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a3d, 0x1a48, x86_l_1a48);
x86_l_1a3f:
	/* 0x1a3f: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a42:
	/* 0x1a42: ja     1847 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a42, 0x1847, x86_l_1847);
x86_l_1a48:
	/* 0x1a48: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1a4a:
	/* 0x1a4a: jmp    1a4f <filter_16ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1a4f */
x86_l_1a4f:
	/* 0x1a4f: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a52:
	/* 0x1a52: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1a55:
	/* 0x1a55: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1a58:
	/* 0x1a58: ja     1b3f <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a58, 0x1b3f, x86_l_1b3f);
x86_l_1a5e:
	/* 0x1a5e: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1a63:
	/* 0x1a63: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1a66:
	/* 0x1a66: jae    1b3f <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1a66, 0x1b3f, x86_l_1b3f);
x86_l_1a6c:
	/* 0x1a6c: movsx  esi,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a6f:
	/* 0x1a6f: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1a72:
	/* 0x1a72: jne    1ada <filter_16ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1a72, 0x1ada, x86_l_1ada);
x86_l_1a74:
	/* 0x1a74: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1a79:
	/* 0x1a79: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a7c:
	/* 0x1a7c: jg     1a87 <filter_16ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1a7c, 0x1a87, x86_l_1a87);
x86_l_1a7e:
	/* 0x1a7e: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a81:
	/* 0x1a81: jge    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1a81, 0x1b56, x86_l_1b56);
x86_l_1a87:
	/* 0x1a87: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a8a:
	/* 0x1a8a: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1a8d:
	/* 0x1a8d: jb     1bfa <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a8d, 0x1bfa, x86_l_1bfa);
x86_l_1a93:
	/* 0x1a93: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a96:
	/* 0x1a96: jg     1aa1 <filter_16ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1a96, 0x1aa1, x86_l_1aa1);
x86_l_1a98:
	/* 0x1a98: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a9b:
	/* 0x1a9b: jge    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1a9b, 0x1b56, x86_l_1b56);
x86_l_1aa1:
	/* 0x1aa1: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1aa4:
	/* 0x1aa4: jb     1bfa <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1aa4, 0x1bfa, x86_l_1bfa);
x86_l_1aaa:
	/* 0x1aaa: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1aad:
	/* 0x1aad: jg     1ab8 <filter_16ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1aad, 0x1ab8, x86_l_1ab8);
x86_l_1aaf:
	/* 0x1aaf: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1ab2:
	/* 0x1ab2: jge    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1ab2, 0x1b56, x86_l_1b56);
x86_l_1ab8:
	/* 0x1ab8: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1abb:
	/* 0x1abb: jb     1bfa <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1abb, 0x1bfa, x86_l_1bfa);
x86_l_1ac1:
	/* 0x1ac1: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1ac3:
	/* 0x1ac3: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ac6:
	/* 0x1ac6: jg     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1ac6, 0x1bfc, x86_l_1bfc);
x86_l_1acc:
	/* 0x1acc: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1acf:
	/* 0x1acf: jge    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1acf, 0x1b56, x86_l_1b56);
x86_l_1ad5:
	/* 0x1ad5: jmp    1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x1ad5, 0x1bfc, x86_l_1bfc);
x86_l_1ada:
	/* 0x1ada: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1add:
	/* 0x1add: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ae0:
	/* 0x1ae0: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1ae4:
	/* 0x1ae4: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1ae7:
	/* 0x1ae7: setge  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_GE);
x86_l_1aea:
	/* 0x1aea: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1aed:
	/* 0x1aed: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1af0:
	/* 0x1af0: jb     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1af0, 0x1bfc, x86_l_1bfc);
x86_l_1af6:
	/* 0x1af6: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1af9:
	/* 0x1af9: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1afd:
	/* 0x1afd: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b00:
	/* 0x1b00: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_1b04:
	/* 0x1b04: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b07:
	/* 0x1b07: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1b0a:
	/* 0x1b0a: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1b0d:
	/* 0x1b0d: jb     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b0d, 0x1bfc, x86_l_1bfc);
x86_l_1b13:
	/* 0x1b13: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b16:
	/* 0x1b16: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1b1a:
	/* 0x1b1a: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b1d:
	/* 0x1b1d: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_1b21:
	/* 0x1b21: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b24:
	/* 0x1b24: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1b27:
	/* 0x1b27: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1b2a:
	/* 0x1b2a: jb     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b2a, 0x1bfc, x86_l_1bfc);
x86_l_1b30:
	/* 0x1b30: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b33:
	/* 0x1b33: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_1b36:
	/* 0x1b36: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1b39:
	/* 0x1b39: setge  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_GE);
x86_l_1b3d:
	/* 0x1b3d: jmp    1bb6 <filter_16ty_range+0x167> */
	X86_SIM_X86_SUB_JMP(0x1b3d, 0x1bb6, x86_l_1bb6);
x86_l_1b3f:
	/* 0x1b3f: movzx  esi,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1b42:
	/* 0x1b42: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1b45:
	/* 0x1b45: jne    1b5b <filter_16ty_range+0x10c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1b45, 0x1b5b, x86_l_1b5b);
x86_l_1b47:
	/* 0x1b47: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1b4c:
	/* 0x1b4c: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b4f:
	/* 0x1b4f: ja     1bbe <filter_16ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1b4f, 0x1bbe, x86_l_1bbe);
x86_l_1b51:
	/* 0x1b51: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b54:
	/* 0x1b54: jb     1bbe <filter_16ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b54, 0x1bbe, x86_l_1bbe);
x86_l_1b56:
	/* 0x1b56: jmp    1b5b <filter_16ty_range+0x10c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1b5b:
	/* 0x1b5b: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b5e:
	/* 0x1b5e: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b61:
	/* 0x1b61: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1b65:
	/* 0x1b65: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b68:
	/* 0x1b68: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_1b6b:
	/* 0x1b6b: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b6e:
	/* 0x1b6e: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1b71:
	/* 0x1b71: jb     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b71, 0x1bfc, x86_l_1bfc);
x86_l_1b77:
	/* 0x1b77: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b7a:
	/* 0x1b7a: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1b7e:
	/* 0x1b7e: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b81:
	/* 0x1b81: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_1b85:
	/* 0x1b85: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b88:
	/* 0x1b88: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1b8b:
	/* 0x1b8b: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1b8e:
	/* 0x1b8e: jb     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b8e, 0x1bfc, x86_l_1bfc);
x86_l_1b90:
	/* 0x1b90: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b93:
	/* 0x1b93: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1b97:
	/* 0x1b97: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b9a:
	/* 0x1b9a: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_1b9e:
	/* 0x1b9e: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1ba1:
	/* 0x1ba1: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1ba4:
	/* 0x1ba4: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1ba7:
	/* 0x1ba7: jb     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ba7, 0x1bfc, x86_l_1bfc);
x86_l_1ba9:
	/* 0x1ba9: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1bac:
	/* 0x1bac: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_1baf:
	/* 0x1baf: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1bb2:
	/* 0x1bb2: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_1bb6:
	/* 0x1bb6: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1bb9:
	/* 0x1bb9: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_1bbc:
	/* 0x1bbc: jmp    1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x1bbc, 0x1bfc, x86_l_1bfc);
x86_l_1bbe:
	/* 0x1bbe: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bc1:
	/* 0x1bc1: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1bc4:
	/* 0x1bc4: jb     1bfa <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bc4, 0x1bfa, x86_l_1bfa);
x86_l_1bc6:
	/* 0x1bc6: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bc9:
	/* 0x1bc9: ja     1bd0 <filter_16ty_range+0x181> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bc9, 0x1bd0, x86_l_1bd0);
x86_l_1bcb:
	/* 0x1bcb: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1bce:
	/* 0x1bce: jae    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1bce, 0x1b56, x86_l_1b56);
x86_l_1bd0:
	/* 0x1bd0: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1bd3:
	/* 0x1bd3: jb     1bfa <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bd3, 0x1bfa, x86_l_1bfa);
x86_l_1bd5:
	/* 0x1bd5: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bd8:
	/* 0x1bd8: ja     1be3 <filter_16ty_range+0x194> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bd8, 0x1be3, x86_l_1be3);
x86_l_1bda:
	/* 0x1bda: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1bdd:
	/* 0x1bdd: jae    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1bdd, 0x1b56, x86_l_1b56);
x86_l_1be3:
	/* 0x1be3: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1be6:
	/* 0x1be6: jb     1bfa <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1be6, 0x1bfa, x86_l_1bfa);
x86_l_1be8:
	/* 0x1be8: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1bea:
	/* 0x1bea: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1bed:
	/* 0x1bed: ja     1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bed, 0x1bfc, x86_l_1bfc);
x86_l_1bef:
	/* 0x1bef: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1bf2:
	/* 0x1bf2: jae    1b56 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1bf2, 0x1b56, x86_l_1b56);
x86_l_1bf8:
	/* 0x1bf8: jmp    1bfc <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x1bf8, 0x1bfc, x86_l_1bfc);
x86_l_1bfa:
	/* 0x1bfa: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1bfc:
	/* 0x1bfc: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_1bff:
	/* 0x1bff: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1c02:
	/* 0x1c02: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_1c05:
	/* 0x1c05: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1c07:
	/* 0x1c07: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1c0a:
	/* 0x1c0a: jmp    1c0f <filter_16ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1c0f */
x86_l_1c0f:
	/* 0x1c0f: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c11:
	/* 0x1c11: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c12:
	/* 0x1c12: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1c16:
	/* 0x1c16: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_1c19:
	/* 0x1c19: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_1c1c:
	/* 0x1c1c: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1c20:
	/* 0x1c20: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c24:
	/* 0x1c24: mov    rdi,QWORD PTR [rip+0xee0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_1c2b:
	/* 0x1c2b: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c30:
	/* 0x1c30: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1c35:
	/* 0x1c35: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1c38:
	/* 0x1c38: call   1c3d <filter_16ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c3d:
	/* 0x1c3d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1c40:
	/* 0x1c40: je     1c7c <filter_16ty_map+0x6d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c40, 0x1c7c, x86_l_1c7c);
x86_l_1c42:
	/* 0x1c42: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1c45:
	/* 0x1c45: movzx  eax,WORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1c49:
	/* 0x1c49: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c4e:
	/* 0x1c4e: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c53:
	/* 0x1c53: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1c58:
	/* 0x1c58: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1c5b:
	/* 0x1c5b: call   1c60 <filter_16ty_map+0x51> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c60:
	/* 0x1c60: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c63:
	/* 0x1c63: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c65:
	/* 0x1c65: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_1c68:
	/* 0x1c68: ja     1c9a <filter_16ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c68, 0x1c9a, x86_l_1c9a);
x86_l_1c6a:
	/* 0x1c6a: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_1c6f:
	/* 0x1c6f: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1c72:
	/* 0x1c72: jae    1c8a <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c72, 0x1c8a, x86_l_1c8a);
x86_l_1c74:
	/* 0x1c74: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1c77:
	/* 0x1c77: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_1c7a:
	/* 0x1c7a: jmp    1c9a <filter_16ty_map+0x8b> */
	X86_SIM_X86_SUB_JMP(0x1c7a, 0x1c9a, x86_l_1c9a);
x86_l_1c7c:
	/* 0x1c7c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c7e:
	/* 0x1c7e: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1c82:
	/* 0x1c82: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c83:
	/* 0x1c83: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c85:
	/* 0x1c85: jmp    1c8a <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1c8a:
	/* 0x1c8a: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_1c8f:
	/* 0x1c8f: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1c92:
	/* 0x1c92: jae    1c9a <filter_16ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c92, 0x1c9a, x86_l_1c9a);
x86_l_1c94:
	/* 0x1c94: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1c97:
	/* 0x1c97: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_1c9a:
	/* 0x1c9a: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1c9d:
	/* 0x1c9d: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1ca1:
	/* 0x1ca1: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ca2:
	/* 0x1ca2: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ca4:
	/* 0x1ca4: jmp    1ca9 <filter_32ty_selector_val> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1ca9 */
x86_l_1ca9:
	/* 0x1ca9: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cac:
	/* 0x1cac: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1cb1:
	/* 0x1cb1: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_1cb5:
	/* 0x1cb5: ja     1d2e <filter_32ty_selector_val+0x85> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1cb5, 0x1d2e, x86_l_1d2e);
x86_l_1cb7:
	/* 0x1cb7: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_1cc1:
	/* 0x1cc1: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1cc5:
	/* 0x1cc5: jae    1ccc <filter_32ty_selector_val+0x23> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1cc5, 0x1ccc, x86_l_1ccc);
x86_l_1cc7:
	/* 0x1cc7: jmp    1ccc <filter_32ty_selector_val+0x23> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1ccc:
	/* 0x1ccc: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_1cd1:
	/* 0x1cd1: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1cd5:
	/* 0x1cd5: jae    1cef <filter_32ty_selector_val+0x46> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1cd5, 0x1cef, x86_l_1cef);
x86_l_1cd7:
	/* 0x1cd7: mov    edx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd9:
	/* 0x1cd9: cmp    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1cdc:
	/* 0x1cdc: jne    1e02 <filter_32ty_selector_val+0x159> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1cdc, 0x1e02, x86_l_1e02);
x86_l_1ce2:
	/* 0x1ce2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1ce4:
	/* 0x1ce4: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_1ce7:
	/* 0x1ce7: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1cea:
	/* 0x1cea: jmp    1cef <filter_32ty_selector_val+0x46> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1cef:
	/* 0x1cef: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_1cf3:
	/* 0x1cf3: jne    1d2e <filter_32ty_selector_val+0x85> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1cf3, 0x1d2e, x86_l_1d2e);
x86_l_1cf5:
	/* 0x1cf5: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cf7:
	/* 0x1cf7: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1cfa:
	/* 0x1cfa: jne    1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1cfa, 0x1cc7, x86_l_1cc7);
x86_l_1cfc:
	/* 0x1cfc: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cff:
	/* 0x1cff: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1d02:
	/* 0x1d02: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d02, 0x1ec2, x86_l_1ec2);
x86_l_1d08:
	/* 0x1d08: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1d0b:
	/* 0x1d0b: jne    1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d0b, 0x1cc7, x86_l_1cc7);
x86_l_1d0d:
	/* 0x1d0d: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1d10:
	/* 0x1d10: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d10, 0x1ec2, x86_l_1ec2);
x86_l_1d16:
	/* 0x1d16: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1d19:
	/* 0x1d19: jne    1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d19, 0x1cc7, x86_l_1cc7);
x86_l_1d1b:
	/* 0x1d1b: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1d1e:
	/* 0x1d1e: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d1e, 0x1ec2, x86_l_1ec2);
x86_l_1d24:
	/* 0x1d24: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1d27:
	/* 0x1d27: jne    1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d27, 0x1cc7, x86_l_1cc7);
x86_l_1d29:
	/* 0x1d29: jmp    1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1d29, 0x1ec2, x86_l_1ec2);
x86_l_1d2e:
	/* 0x1d2e: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1d31:
	/* 0x1d31: je     1d9f <filter_32ty_selector_val+0xf6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1d31, 0x1d9f, x86_l_1d9f);
x86_l_1d33:
	/* 0x1d33: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1d36:
	/* 0x1d36: jne    1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d36, 0x1ec2, x86_l_1ec2);
x86_l_1d3c:
	/* 0x1d3c: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d3f:
	/* 0x1d3f: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1d42:
	/* 0x1d42: ja     1e8a <filter_32ty_selector_val+0x1e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d42, 0x1e8a, x86_l_1e8a);
x86_l_1d48:
	/* 0x1d48: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1d4d:
	/* 0x1d4d: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1d50:
	/* 0x1d50: jae    1e8a <filter_32ty_selector_val+0x1e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d50, 0x1e8a, x86_l_1e8a);
x86_l_1d56:
	/* 0x1d56: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d58:
	/* 0x1d58: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d5b:
	/* 0x1d5b: jl     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1d5b, 0x1cc7, x86_l_1cc7);
x86_l_1d61:
	/* 0x1d61: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d64:
	/* 0x1d64: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1d67:
	/* 0x1d67: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d67, 0x1ec2, x86_l_1ec2);
x86_l_1d6d:
	/* 0x1d6d: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1d70:
	/* 0x1d70: jl     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1d70, 0x1cc7, x86_l_1cc7);
x86_l_1d76:
	/* 0x1d76: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1d79:
	/* 0x1d79: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d79, 0x1ec2, x86_l_1ec2);
x86_l_1d7f:
	/* 0x1d7f: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1d82:
	/* 0x1d82: jl     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1d82, 0x1cc7, x86_l_1cc7);
x86_l_1d88:
	/* 0x1d88: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1d8b:
	/* 0x1d8b: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d8b, 0x1ec2, x86_l_1ec2);
x86_l_1d91:
	/* 0x1d91: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1d94:
	/* 0x1d94: jl     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1d94, 0x1cc7, x86_l_1cc7);
x86_l_1d9a:
	/* 0x1d9a: jmp    1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1d9a, 0x1ec2, x86_l_1ec2);
x86_l_1d9f:
	/* 0x1d9f: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1da2:
	/* 0x1da2: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1da5:
	/* 0x1da5: ja     1e50 <filter_32ty_selector_val+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1da5, 0x1e50, x86_l_1e50);
x86_l_1dab:
	/* 0x1dab: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1db0:
	/* 0x1db0: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1db3:
	/* 0x1db3: jae    1e50 <filter_32ty_selector_val+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1db3, 0x1e50, x86_l_1e50);
x86_l_1db9:
	/* 0x1db9: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dbb:
	/* 0x1dbb: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1dbe:
	/* 0x1dbe: jg     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1dbe, 0x1cc7, x86_l_1cc7);
x86_l_1dc4:
	/* 0x1dc4: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dc7:
	/* 0x1dc7: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1dca:
	/* 0x1dca: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1dca, 0x1ec2, x86_l_1ec2);
x86_l_1dd0:
	/* 0x1dd0: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1dd3:
	/* 0x1dd3: jg     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1dd3, 0x1cc7, x86_l_1cc7);
x86_l_1dd9:
	/* 0x1dd9: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1ddc:
	/* 0x1ddc: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ddc, 0x1ec2, x86_l_1ec2);
x86_l_1de2:
	/* 0x1de2: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1de5:
	/* 0x1de5: jg     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1de5, 0x1cc7, x86_l_1cc7);
x86_l_1deb:
	/* 0x1deb: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1dee:
	/* 0x1dee: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1dee, 0x1ec2, x86_l_1ec2);
x86_l_1df4:
	/* 0x1df4: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1df7:
	/* 0x1df7: jg     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1df7, 0x1cc7, x86_l_1cc7);
x86_l_1dfd:
	/* 0x1dfd: jmp    1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1dfd, 0x1ec2, x86_l_1ec2);
x86_l_1e02:
	/* 0x1e02: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e05:
	/* 0x1e05: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_1e08:
	/* 0x1e08: jb     1e2f <filter_32ty_selector_val+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e08, 0x1e2f, x86_l_1e2f);
x86_l_1e0a:
	/* 0x1e0a: cmp    edx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e0d:
	/* 0x1e0d: je     1ce2 <filter_32ty_selector_val+0x39> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e0d, 0x1ce2, x86_l_1ce2);
x86_l_1e13:
	/* 0x1e13: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_1e16:
	/* 0x1e16: jb     1e2f <filter_32ty_selector_val+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e16, 0x1e2f, x86_l_1e2f);
x86_l_1e18:
	/* 0x1e18: cmp    edx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e1b:
	/* 0x1e1b: je     1ce2 <filter_32ty_selector_val+0x39> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e1b, 0x1ce2, x86_l_1ce2);
x86_l_1e21:
	/* 0x1e21: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_1e24:
	/* 0x1e24: jb     1e2f <filter_32ty_selector_val+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e24, 0x1e2f, x86_l_1e2f);
x86_l_1e26:
	/* 0x1e26: cmp    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e29:
	/* 0x1e29: je     1ce2 <filter_32ty_selector_val+0x39> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e29, 0x1ce2, x86_l_1ce2);
x86_l_1e2f:
	/* 0x1e2f: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_1e32:
	/* 0x1e32: ja     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e32, 0x1ec2, x86_l_1ec2);
x86_l_1e38:
	/* 0x1e38: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1e3a:
	/* 0x1e3a: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_1e44:
	/* 0x1e44: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1e48:
	/* 0x1e48: jb     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e48, 0x1cc7, x86_l_1cc7);
x86_l_1e4e:
	/* 0x1e4e: jmp    1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1e4e, 0x1ec2, x86_l_1ec2);
x86_l_1e50:
	/* 0x1e50: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e52:
	/* 0x1e52: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1e55:
	/* 0x1e55: ja     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e55, 0x1cc7, x86_l_1cc7);
x86_l_1e5b:
	/* 0x1e5b: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e5e:
	/* 0x1e5e: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1e61:
	/* 0x1e61: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e61, 0x1ec2, x86_l_1ec2);
x86_l_1e63:
	/* 0x1e63: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e66:
	/* 0x1e66: ja     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e66, 0x1cc7, x86_l_1cc7);
x86_l_1e6c:
	/* 0x1e6c: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1e6f:
	/* 0x1e6f: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e6f, 0x1ec2, x86_l_1ec2);
x86_l_1e71:
	/* 0x1e71: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e74:
	/* 0x1e74: ja     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e74, 0x1cc7, x86_l_1cc7);
x86_l_1e7a:
	/* 0x1e7a: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1e7d:
	/* 0x1e7d: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e7d, 0x1ec2, x86_l_1ec2);
x86_l_1e7f:
	/* 0x1e7f: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e82:
	/* 0x1e82: ja     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e82, 0x1cc7, x86_l_1cc7);
x86_l_1e88:
	/* 0x1e88: jmp    1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1e88, 0x1ec2, x86_l_1ec2);
x86_l_1e8a:
	/* 0x1e8a: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8c:
	/* 0x1e8c: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1e8f:
	/* 0x1e8f: jb     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e8f, 0x1cc7, x86_l_1cc7);
x86_l_1e95:
	/* 0x1e95: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e98:
	/* 0x1e98: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1e9b:
	/* 0x1e9b: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e9b, 0x1ec2, x86_l_1ec2);
x86_l_1e9d:
	/* 0x1e9d: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ea0:
	/* 0x1ea0: jb     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ea0, 0x1cc7, x86_l_1cc7);
x86_l_1ea6:
	/* 0x1ea6: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1ea9:
	/* 0x1ea9: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ea9, 0x1ec2, x86_l_1ec2);
x86_l_1eab:
	/* 0x1eab: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1eae:
	/* 0x1eae: jb     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eae, 0x1cc7, x86_l_1cc7);
x86_l_1eb4:
	/* 0x1eb4: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1eb7:
	/* 0x1eb7: jb     1ec2 <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eb7, 0x1ec2, x86_l_1ec2);
x86_l_1eb9:
	/* 0x1eb9: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1ebc:
	/* 0x1ebc: jb     1cc7 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ebc, 0x1cc7, x86_l_1cc7);
x86_l_1ec2:
	/* 0x1ec2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1ec4:
	/* 0x1ec4: jmp    1ec9 <filter_32ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1ec9 */
x86_l_1ec9:
	/* 0x1ec9: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ecc:
	/* 0x1ecc: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1ecf:
	/* 0x1ecf: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1ed2:
	/* 0x1ed2: ja     1fb8 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ed2, 0x1fb8, x86_l_1fb8);
x86_l_1ed8:
	/* 0x1ed8: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1edd:
	/* 0x1edd: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1ee0:
	/* 0x1ee0: jae    1fb8 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1ee0, 0x1fb8, x86_l_1fb8);
x86_l_1ee6:
	/* 0x1ee6: mov    esi,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee8:
	/* 0x1ee8: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1eeb:
	/* 0x1eeb: jne    1f53 <filter_32ty_range+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1eeb, 0x1f53, x86_l_1f53);
x86_l_1eed:
	/* 0x1eed: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ef2:
	/* 0x1ef2: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ef5:
	/* 0x1ef5: jg     1f00 <filter_32ty_range+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1ef5, 0x1f00, x86_l_1f00);
x86_l_1ef7:
	/* 0x1ef7: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1efa:
	/* 0x1efa: jle    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1efa, 0x1fce, x86_l_1fce);
x86_l_1f00:
	/* 0x1f00: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f03:
	/* 0x1f03: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1f06:
	/* 0x1f06: jb     2072 <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f06, 0x2072, x86_l_2072);
x86_l_1f0c:
	/* 0x1f0c: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f0f:
	/* 0x1f0f: jg     1f1a <filter_32ty_range+0x51> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f0f, 0x1f1a, x86_l_1f1a);
x86_l_1f11:
	/* 0x1f11: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f14:
	/* 0x1f14: jle    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f14, 0x1fce, x86_l_1fce);
x86_l_1f1a:
	/* 0x1f1a: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1f1d:
	/* 0x1f1d: jb     2072 <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f1d, 0x2072, x86_l_2072);
x86_l_1f23:
	/* 0x1f23: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f26:
	/* 0x1f26: jg     1f31 <filter_32ty_range+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f26, 0x1f31, x86_l_1f31);
x86_l_1f28:
	/* 0x1f28: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1f2b:
	/* 0x1f2b: jle    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f2b, 0x1fce, x86_l_1fce);
x86_l_1f31:
	/* 0x1f31: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1f34:
	/* 0x1f34: jb     2072 <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f34, 0x2072, x86_l_2072);
x86_l_1f3a:
	/* 0x1f3a: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f3c:
	/* 0x1f3c: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f3f:
	/* 0x1f3f: jg     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f3f, 0x2074, x86_l_2074);
x86_l_1f45:
	/* 0x1f45: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1f48:
	/* 0x1f48: jle    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f48, 0x1fce, x86_l_1fce);
x86_l_1f4e:
	/* 0x1f4e: jmp    2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JMP(0x1f4e, 0x2074, x86_l_2074);
x86_l_1f53:
	/* 0x1f53: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f56:
	/* 0x1f56: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f59:
	/* 0x1f59: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1f5d:
	/* 0x1f5d: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f60:
	/* 0x1f60: setle  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_LE);
x86_l_1f63:
	/* 0x1f63: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1f66:
	/* 0x1f66: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1f69:
	/* 0x1f69: jb     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f69, 0x2074, x86_l_2074);
x86_l_1f6f:
	/* 0x1f6f: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f72:
	/* 0x1f72: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1f76:
	/* 0x1f76: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f79:
	/* 0x1f79: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_1f7d:
	/* 0x1f7d: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1f80:
	/* 0x1f80: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1f83:
	/* 0x1f83: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1f86:
	/* 0x1f86: jb     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f86, 0x2074, x86_l_2074);
x86_l_1f8c:
	/* 0x1f8c: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f8f:
	/* 0x1f8f: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1f93:
	/* 0x1f93: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1f96:
	/* 0x1f96: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_1f9a:
	/* 0x1f9a: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1f9d:
	/* 0x1f9d: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1fa0:
	/* 0x1fa0: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1fa3:
	/* 0x1fa3: jb     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fa3, 0x2074, x86_l_2074);
x86_l_1fa9:
	/* 0x1fa9: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1fac:
	/* 0x1fac: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_1faf:
	/* 0x1faf: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1fb2:
	/* 0x1fb2: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_1fb6:
	/* 0x1fb6: jmp    202e <filter_32ty_range+0x165> */
	X86_SIM_X86_SUB_JMP(0x1fb6, 0x202e, x86_l_202e);
x86_l_1fb8:
	/* 0x1fb8: mov    esi,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fba:
	/* 0x1fba: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1fbd:
	/* 0x1fbd: jne    1fd3 <filter_32ty_range+0x10a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1fbd, 0x1fd3, x86_l_1fd3);
x86_l_1fbf:
	/* 0x1fbf: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1fc4:
	/* 0x1fc4: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fc7:
	/* 0x1fc7: ja     2036 <filter_32ty_range+0x16d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fc7, 0x2036, x86_l_2036);
x86_l_1fc9:
	/* 0x1fc9: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1fcc:
	/* 0x1fcc: ja     2036 <filter_32ty_range+0x16d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fcc, 0x2036, x86_l_2036);
x86_l_1fce:
	/* 0x1fce: jmp    1fd3 <filter_32ty_range+0x10a> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1fd3:
	/* 0x1fd3: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fd6:
	/* 0x1fd6: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fd9:
	/* 0x1fd9: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1fdd:
	/* 0x1fdd: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1fe0:
	/* 0x1fe0: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_1fe3:
	/* 0x1fe3: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1fe6:
	/* 0x1fe6: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1fe9:
	/* 0x1fe9: jb     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fe9, 0x2074, x86_l_2074);
x86_l_1fef:
	/* 0x1fef: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ff2:
	/* 0x1ff2: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1ff6:
	/* 0x1ff6: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1ff9:
	/* 0x1ff9: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_1ffd:
	/* 0x1ffd: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2000:
	/* 0x2000: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_2003:
	/* 0x2003: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2006:
	/* 0x2006: jb     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2006, 0x2074, x86_l_2074);
x86_l_2008:
	/* 0x2008: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_200b:
	/* 0x200b: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_200f:
	/* 0x200f: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_2012:
	/* 0x2012: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_2016:
	/* 0x2016: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2019:
	/* 0x2019: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_201c:
	/* 0x201c: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_201f:
	/* 0x201f: jb     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x201f, 0x2074, x86_l_2074);
x86_l_2021:
	/* 0x2021: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2024:
	/* 0x2024: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_2027:
	/* 0x2027: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_202a:
	/* 0x202a: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_202e:
	/* 0x202e: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_2031:
	/* 0x2031: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2034:
	/* 0x2034: jmp    2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JMP(0x2034, 0x2074, x86_l_2074);
x86_l_2036:
	/* 0x2036: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2039:
	/* 0x2039: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_203c:
	/* 0x203c: jb     2072 <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x203c, 0x2072, x86_l_2072);
x86_l_203e:
	/* 0x203e: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2041:
	/* 0x2041: ja     2048 <filter_32ty_range+0x17f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2041, 0x2048, x86_l_2048);
x86_l_2043:
	/* 0x2043: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_2046:
	/* 0x2046: jbe    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2046, 0x1fce, x86_l_1fce);
x86_l_2048:
	/* 0x2048: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_204b:
	/* 0x204b: jb     2072 <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x204b, 0x2072, x86_l_2072);
x86_l_204d:
	/* 0x204d: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2050:
	/* 0x2050: ja     205b <filter_32ty_range+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2050, 0x205b, x86_l_205b);
x86_l_2052:
	/* 0x2052: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_2055:
	/* 0x2055: jbe    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2055, 0x1fce, x86_l_1fce);
x86_l_205b:
	/* 0x205b: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_205e:
	/* 0x205e: jb     2072 <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x205e, 0x2072, x86_l_2072);
x86_l_2060:
	/* 0x2060: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2062:
	/* 0x2062: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2065:
	/* 0x2065: ja     2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2065, 0x2074, x86_l_2074);
x86_l_2067:
	/* 0x2067: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_206a:
	/* 0x206a: jbe    1fce <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x206a, 0x1fce, x86_l_1fce);
x86_l_2070:
	/* 0x2070: jmp    2074 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JMP(0x2070, 0x2074, x86_l_2074);
x86_l_2072:
	/* 0x2072: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2074:
	/* 0x2074: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_2077:
	/* 0x2077: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_207a:
	/* 0x207a: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_207d:
	/* 0x207d: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_207f:
	/* 0x207f: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_2082:
	/* 0x2082: jmp    2087 <filter_32ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_2087 */
x86_l_2087:
	/* 0x2087: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2089:
	/* 0x2089: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_208a:
	/* 0x208a: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_208e:
	/* 0x208e: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_2091:
	/* 0x2091: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_2094:
	/* 0x2094: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_2098:
	/* 0x2098: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_209c:
	/* 0x209c: mov    rdi,QWORD PTR [rip+0xa50] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_20a3:
	/* 0x20a3: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_20a8:
	/* 0x20a8: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_20ad:
	/* 0x20ad: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_20b0:
	/* 0x20b0: call   20b5 <filter_32ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20b5:
	/* 0x20b5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_20b8:
	/* 0x20b8: je     20f3 <filter_32ty_map+0x6c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x20b8, 0x20f3, x86_l_20f3);
x86_l_20ba:
	/* 0x20ba: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_20bd:
	/* 0x20bd: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c0:
	/* 0x20c0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20c5:
	/* 0x20c5: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20ca:
	/* 0x20ca: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_20cf:
	/* 0x20cf: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_20d2:
	/* 0x20d2: call   20d7 <filter_32ty_map+0x50> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20d7:
	/* 0x20d7: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_20da:
	/* 0x20da: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20dc:
	/* 0x20dc: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_20df:
	/* 0x20df: ja     2111 <filter_32ty_map+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20df, 0x2111, x86_l_2111);
x86_l_20e1:
	/* 0x20e1: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_20e6:
	/* 0x20e6: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_20e9:
	/* 0x20e9: jae    2101 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x20e9, 0x2101, x86_l_2101);
x86_l_20eb:
	/* 0x20eb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_20ee:
	/* 0x20ee: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_20f1:
	/* 0x20f1: jmp    2111 <filter_32ty_map+0x8a> */
	X86_SIM_X86_SUB_JMP(0x20f1, 0x2111, x86_l_2111);
x86_l_20f3:
	/* 0x20f3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20f5:
	/* 0x20f5: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_20f9:
	/* 0x20f9: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20fa:
	/* 0x20fa: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_20fc:
	/* 0x20fc: jmp    2101 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2101:
	/* 0x2101: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_2106:
	/* 0x2106: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_2109:
	/* 0x2109: jae    2111 <filter_32ty_map+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2109, 0x2111, x86_l_2111);
x86_l_210b:
	/* 0x210b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_210e:
	/* 0x210e: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_2111:
	/* 0x2111: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_2114:
	/* 0x2114: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2118:
	/* 0x2118: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2119:
	/* 0x2119: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_211b:
	/* 0x211b: jmp    2120 <filter_8ty_selector_val> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_2120 */
x86_l_2120:
	/* 0x2120: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2123:
	/* 0x2123: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2128:
	/* 0x2128: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_212c:
	/* 0x212c: ja     21a7 <filter_8ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x212c, 0x21a7, x86_l_21a7);
x86_l_212e:
	/* 0x212e: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_2138:
	/* 0x2138: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_213c:
	/* 0x213c: jae    2143 <filter_8ty_selector_val+0x23> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x213c, 0x2143, x86_l_2143);
x86_l_213e:
	/* 0x213e: jmp    2143 <filter_8ty_selector_val+0x23> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2143:
	/* 0x2143: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_2148:
	/* 0x2148: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_214c:
	/* 0x214c: jae    2167 <filter_8ty_selector_val+0x47> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x214c, 0x2167, x86_l_2167);
x86_l_214e:
	/* 0x214e: movzx  edx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2151:
	/* 0x2151: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2154:
	/* 0x2154: jne    227d <filter_8ty_selector_val+0x15d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2154, 0x227d, x86_l_227d);
x86_l_215a:
	/* 0x215a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_215c:
	/* 0x215c: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_215f:
	/* 0x215f: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_2162:
	/* 0x2162: jmp    2167 <filter_8ty_selector_val+0x47> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2167:
	/* 0x2167: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_216b:
	/* 0x216b: jne    21a7 <filter_8ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x216b, 0x21a7, x86_l_21a7);
x86_l_216d:
	/* 0x216d: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2170:
	/* 0x2170: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2173:
	/* 0x2173: jne    213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2173, 0x213e, x86_l_213e);
x86_l_2175:
	/* 0x2175: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2178:
	/* 0x2178: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_217b:
	/* 0x217b: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x217b, 0x233f, x86_l_233f);
x86_l_2181:
	/* 0x2181: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2184:
	/* 0x2184: jne    213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2184, 0x213e, x86_l_213e);
x86_l_2186:
	/* 0x2186: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2189:
	/* 0x2189: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2189, 0x233f, x86_l_233f);
x86_l_218f:
	/* 0x218f: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2192:
	/* 0x2192: jne    213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2192, 0x213e, x86_l_213e);
x86_l_2194:
	/* 0x2194: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2197:
	/* 0x2197: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2197, 0x233f, x86_l_233f);
x86_l_219d:
	/* 0x219d: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_21a0:
	/* 0x21a0: jne    213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21a0, 0x213e, x86_l_213e);
x86_l_21a2:
	/* 0x21a2: jmp    233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x21a2, 0x233f, x86_l_233f);
x86_l_21a7:
	/* 0x21a7: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_21aa:
	/* 0x21aa: je     2219 <filter_8ty_selector_val+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x21aa, 0x2219, x86_l_2219);
x86_l_21ac:
	/* 0x21ac: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_21af:
	/* 0x21af: jne    233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21af, 0x233f, x86_l_233f);
x86_l_21b5:
	/* 0x21b5: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_21b8:
	/* 0x21b8: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_21bb:
	/* 0x21bb: ja     2306 <filter_8ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21bb, 0x2306, x86_l_2306);
x86_l_21c1:
	/* 0x21c1: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_21c6:
	/* 0x21c6: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_21c9:
	/* 0x21c9: jae    2306 <filter_8ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x21c9, 0x2306, x86_l_2306);
x86_l_21cf:
	/* 0x21cf: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21d2:
	/* 0x21d2: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21d5:
	/* 0x21d5: jg     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x21d5, 0x213e, x86_l_213e);
x86_l_21db:
	/* 0x21db: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21de:
	/* 0x21de: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_21e1:
	/* 0x21e1: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21e1, 0x233f, x86_l_233f);
x86_l_21e7:
	/* 0x21e7: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_21ea:
	/* 0x21ea: jg     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x21ea, 0x213e, x86_l_213e);
x86_l_21f0:
	/* 0x21f0: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_21f3:
	/* 0x21f3: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21f3, 0x233f, x86_l_233f);
x86_l_21f9:
	/* 0x21f9: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21fc:
	/* 0x21fc: jg     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x21fc, 0x213e, x86_l_213e);
x86_l_2202:
	/* 0x2202: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2205:
	/* 0x2205: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2205, 0x233f, x86_l_233f);
x86_l_220b:
	/* 0x220b: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_220e:
	/* 0x220e: jg     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x220e, 0x213e, x86_l_213e);
x86_l_2214:
	/* 0x2214: jmp    233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x2214, 0x233f, x86_l_233f);
x86_l_2219:
	/* 0x2219: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_221c:
	/* 0x221c: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_221f:
	/* 0x221f: ja     22cb <filter_8ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x221f, 0x22cb, x86_l_22cb);
x86_l_2225:
	/* 0x2225: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_222a:
	/* 0x222a: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_222d:
	/* 0x222d: jae    22cb <filter_8ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x222d, 0x22cb, x86_l_22cb);
x86_l_2233:
	/* 0x2233: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2236:
	/* 0x2236: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2239:
	/* 0x2239: jl     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2239, 0x213e, x86_l_213e);
x86_l_223f:
	/* 0x223f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2242:
	/* 0x2242: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2245:
	/* 0x2245: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2245, 0x233f, x86_l_233f);
x86_l_224b:
	/* 0x224b: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_224e:
	/* 0x224e: jl     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x224e, 0x213e, x86_l_213e);
x86_l_2254:
	/* 0x2254: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2257:
	/* 0x2257: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2257, 0x233f, x86_l_233f);
x86_l_225d:
	/* 0x225d: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2260:
	/* 0x2260: jl     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2260, 0x213e, x86_l_213e);
x86_l_2266:
	/* 0x2266: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2269:
	/* 0x2269: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2269, 0x233f, x86_l_233f);
x86_l_226f:
	/* 0x226f: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2272:
	/* 0x2272: jl     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2272, 0x213e, x86_l_213e);
x86_l_2278:
	/* 0x2278: jmp    233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x2278, 0x233f, x86_l_233f);
x86_l_227d:
	/* 0x227d: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2280:
	/* 0x2280: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_2283:
	/* 0x2283: jb     22aa <filter_8ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2283, 0x22aa, x86_l_22aa);
x86_l_2285:
	/* 0x2285: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2288:
	/* 0x2288: je     215a <filter_8ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2288, 0x215a, x86_l_215a);
x86_l_228e:
	/* 0x228e: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_2291:
	/* 0x2291: jb     22aa <filter_8ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2291, 0x22aa, x86_l_22aa);
x86_l_2293:
	/* 0x2293: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2296:
	/* 0x2296: je     215a <filter_8ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2296, 0x215a, x86_l_215a);
x86_l_229c:
	/* 0x229c: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_229f:
	/* 0x229f: jb     22aa <filter_8ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x229f, 0x22aa, x86_l_22aa);
x86_l_22a1:
	/* 0x22a1: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_22a4:
	/* 0x22a4: je     215a <filter_8ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22a4, 0x215a, x86_l_215a);
x86_l_22aa:
	/* 0x22aa: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_22ad:
	/* 0x22ad: ja     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x22ad, 0x233f, x86_l_233f);
x86_l_22b3:
	/* 0x22b3: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_22b5:
	/* 0x22b5: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_22bf:
	/* 0x22bf: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_22c3:
	/* 0x22c3: jb     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22c3, 0x213e, x86_l_213e);
x86_l_22c9:
	/* 0x22c9: jmp    233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x22c9, 0x233f, x86_l_233f);
x86_l_22cb:
	/* 0x22cb: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_22ce:
	/* 0x22ce: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22d1:
	/* 0x22d1: jb     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22d1, 0x213e, x86_l_213e);
x86_l_22d7:
	/* 0x22d7: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22da:
	/* 0x22da: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_22dd:
	/* 0x22dd: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22dd, 0x233f, x86_l_233f);
x86_l_22df:
	/* 0x22df: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_22e2:
	/* 0x22e2: jb     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22e2, 0x213e, x86_l_213e);
x86_l_22e8:
	/* 0x22e8: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_22eb:
	/* 0x22eb: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22eb, 0x233f, x86_l_233f);
x86_l_22ed:
	/* 0x22ed: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22f0:
	/* 0x22f0: jb     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22f0, 0x213e, x86_l_213e);
x86_l_22f6:
	/* 0x22f6: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_22f9:
	/* 0x22f9: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22f9, 0x233f, x86_l_233f);
x86_l_22fb:
	/* 0x22fb: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_22fe:
	/* 0x22fe: jb     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22fe, 0x213e, x86_l_213e);
x86_l_2304:
	/* 0x2304: jmp    233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x2304, 0x233f, x86_l_233f);
x86_l_2306:
	/* 0x2306: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2309:
	/* 0x2309: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_230c:
	/* 0x230c: ja     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x230c, 0x213e, x86_l_213e);
x86_l_2312:
	/* 0x2312: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2315:
	/* 0x2315: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2318:
	/* 0x2318: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2318, 0x233f, x86_l_233f);
x86_l_231a:
	/* 0x231a: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_231d:
	/* 0x231d: ja     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x231d, 0x213e, x86_l_213e);
x86_l_2323:
	/* 0x2323: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2326:
	/* 0x2326: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2326, 0x233f, x86_l_233f);
x86_l_2328:
	/* 0x2328: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_232b:
	/* 0x232b: ja     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x232b, 0x213e, x86_l_213e);
x86_l_2331:
	/* 0x2331: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2334:
	/* 0x2334: jb     233f <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2334, 0x233f, x86_l_233f);
x86_l_2336:
	/* 0x2336: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2339:
	/* 0x2339: ja     213e <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2339, 0x213e, x86_l_213e);
x86_l_233f:
	/* 0x233f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2341:
	/* 0x2341: jmp    2346 <filter_8ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_2346 */
x86_l_2346:
	/* 0x2346: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2349:
	/* 0x2349: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_234c:
	/* 0x234c: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_234f:
	/* 0x234f: ja     2436 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x234f, 0x2436, x86_l_2436);
x86_l_2355:
	/* 0x2355: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_235a:
	/* 0x235a: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_235d:
	/* 0x235d: jae    2436 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x235d, 0x2436, x86_l_2436);
x86_l_2363:
	/* 0x2363: movsx  esi,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2366:
	/* 0x2366: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_2369:
	/* 0x2369: jne    23d1 <filter_8ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2369, 0x23d1, x86_l_23d1);
x86_l_236b:
	/* 0x236b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2370:
	/* 0x2370: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2373:
	/* 0x2373: jg     237e <filter_8ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2373, 0x237e, x86_l_237e);
x86_l_2375:
	/* 0x2375: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2378:
	/* 0x2378: jge    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2378, 0x244d, x86_l_244d);
x86_l_237e:
	/* 0x237e: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2381:
	/* 0x2381: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2384:
	/* 0x2384: jb     24f1 <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2384, 0x24f1, x86_l_24f1);
x86_l_238a:
	/* 0x238a: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_238d:
	/* 0x238d: jg     2398 <filter_8ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x238d, 0x2398, x86_l_2398);
x86_l_238f:
	/* 0x238f: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2392:
	/* 0x2392: jge    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2392, 0x244d, x86_l_244d);
x86_l_2398:
	/* 0x2398: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_239b:
	/* 0x239b: jb     24f1 <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x239b, 0x24f1, x86_l_24f1);
x86_l_23a1:
	/* 0x23a1: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23a4:
	/* 0x23a4: jg     23af <filter_8ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23a4, 0x23af, x86_l_23af);
x86_l_23a6:
	/* 0x23a6: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_23a9:
	/* 0x23a9: jge    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23a9, 0x244d, x86_l_244d);
x86_l_23af:
	/* 0x23af: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_23b2:
	/* 0x23b2: jb     24f1 <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23b2, 0x24f1, x86_l_24f1);
x86_l_23b8:
	/* 0x23b8: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_23ba:
	/* 0x23ba: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23bd:
	/* 0x23bd: jg     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23bd, 0x24f3, x86_l_24f3);
x86_l_23c3:
	/* 0x23c3: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_23c6:
	/* 0x23c6: jge    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23c6, 0x244d, x86_l_244d);
x86_l_23cc:
	/* 0x23cc: jmp    24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x23cc, 0x24f3, x86_l_24f3);
x86_l_23d1:
	/* 0x23d1: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23d4:
	/* 0x23d4: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23d7:
	/* 0x23d7: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_23db:
	/* 0x23db: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_23de:
	/* 0x23de: setge  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_GE);
x86_l_23e1:
	/* 0x23e1: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_23e4:
	/* 0x23e4: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_23e7:
	/* 0x23e7: jb     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23e7, 0x24f3, x86_l_24f3);
x86_l_23ed:
	/* 0x23ed: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23f0:
	/* 0x23f0: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_23f4:
	/* 0x23f4: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23f7:
	/* 0x23f7: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_23fb:
	/* 0x23fb: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_23fe:
	/* 0x23fe: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_2401:
	/* 0x2401: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2404:
	/* 0x2404: jb     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2404, 0x24f3, x86_l_24f3);
x86_l_240a:
	/* 0x240a: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_240d:
	/* 0x240d: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_2411:
	/* 0x2411: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2414:
	/* 0x2414: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_2418:
	/* 0x2418: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_241b:
	/* 0x241b: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_241e:
	/* 0x241e: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_2421:
	/* 0x2421: jb     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2421, 0x24f3, x86_l_24f3);
x86_l_2427:
	/* 0x2427: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_242a:
	/* 0x242a: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_242d:
	/* 0x242d: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2430:
	/* 0x2430: setge  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_GE);
x86_l_2434:
	/* 0x2434: jmp    24ad <filter_8ty_range+0x167> */
	X86_SIM_X86_SUB_JMP(0x2434, 0x24ad, x86_l_24ad);
x86_l_2436:
	/* 0x2436: movzx  esi,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2439:
	/* 0x2439: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_243c:
	/* 0x243c: jne    2452 <filter_8ty_range+0x10c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x243c, 0x2452, x86_l_2452);
x86_l_243e:
	/* 0x243e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2443:
	/* 0x2443: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2446:
	/* 0x2446: ja     24b5 <filter_8ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2446, 0x24b5, x86_l_24b5);
x86_l_2448:
	/* 0x2448: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_244b:
	/* 0x244b: jb     24b5 <filter_8ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x244b, 0x24b5, x86_l_24b5);
x86_l_244d:
	/* 0x244d: jmp    2452 <filter_8ty_range+0x10c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2452:
	/* 0x2452: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2455:
	/* 0x2455: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2458:
	/* 0x2458: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_245c:
	/* 0x245c: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_245f:
	/* 0x245f: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_2462:
	/* 0x2462: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2465:
	/* 0x2465: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_2468:
	/* 0x2468: jb     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2468, 0x24f3, x86_l_24f3);
x86_l_246e:
	/* 0x246e: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2471:
	/* 0x2471: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2475:
	/* 0x2475: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2478:
	/* 0x2478: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_247c:
	/* 0x247c: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_247f:
	/* 0x247f: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_2482:
	/* 0x2482: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2485:
	/* 0x2485: jb     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2485, 0x24f3, x86_l_24f3);
x86_l_2487:
	/* 0x2487: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_248a:
	/* 0x248a: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_248e:
	/* 0x248e: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2491:
	/* 0x2491: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_2495:
	/* 0x2495: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2498:
	/* 0x2498: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_249b:
	/* 0x249b: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_249e:
	/* 0x249e: jb     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x249e, 0x24f3, x86_l_24f3);
x86_l_24a0:
	/* 0x24a0: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24a3:
	/* 0x24a3: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_24a6:
	/* 0x24a6: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_24a9:
	/* 0x24a9: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_24ad:
	/* 0x24ad: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_24b0:
	/* 0x24b0: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_24b3:
	/* 0x24b3: jmp    24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x24b3, 0x24f3, x86_l_24f3);
x86_l_24b5:
	/* 0x24b5: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24b8:
	/* 0x24b8: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_24bb:
	/* 0x24bb: jb     24f1 <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24bb, 0x24f1, x86_l_24f1);
x86_l_24bd:
	/* 0x24bd: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24c0:
	/* 0x24c0: ja     24c7 <filter_8ty_range+0x181> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24c0, 0x24c7, x86_l_24c7);
x86_l_24c2:
	/* 0x24c2: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24c5:
	/* 0x24c5: jae    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x24c5, 0x244d, x86_l_244d);
x86_l_24c7:
	/* 0x24c7: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_24ca:
	/* 0x24ca: jb     24f1 <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24ca, 0x24f1, x86_l_24f1);
x86_l_24cc:
	/* 0x24cc: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24cf:
	/* 0x24cf: ja     24da <filter_8ty_range+0x194> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24cf, 0x24da, x86_l_24da);
x86_l_24d1:
	/* 0x24d1: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_24d4:
	/* 0x24d4: jae    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x24d4, 0x244d, x86_l_244d);
x86_l_24da:
	/* 0x24da: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_24dd:
	/* 0x24dd: jb     24f1 <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24dd, 0x24f1, x86_l_24f1);
x86_l_24df:
	/* 0x24df: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24e1:
	/* 0x24e1: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24e4:
	/* 0x24e4: ja     24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24e4, 0x24f3, x86_l_24f3);
x86_l_24e6:
	/* 0x24e6: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_24e9:
	/* 0x24e9: jae    244d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x24e9, 0x244d, x86_l_244d);
x86_l_24ef:
	/* 0x24ef: jmp    24f3 <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x24ef, 0x24f3, x86_l_24f3);
x86_l_24f1:
	/* 0x24f1: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24f3:
	/* 0x24f3: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_24f6:
	/* 0x24f6: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_24f9:
	/* 0x24f9: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_24fc:
	/* 0x24fc: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_24fe:
	/* 0x24fe: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_2501:
	/* 0x2501: jmp    2506 <filter_8ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_2506 */
x86_l_2506:
	/* 0x2506: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2508:
	/* 0x2508: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2509:
	/* 0x2509: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_250d:
	/* 0x250d: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_2510:
	/* 0x2510: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_2513:
	/* 0x2513: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_2517:
	/* 0x2517: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_251b:
	/* 0x251b: mov    rdi,QWORD PTR [rip+0x1370] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_2522:
	/* 0x2522: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2527:
	/* 0x2527: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_252c:
	/* 0x252c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_252f:
	/* 0x252f: call   2534 <filter_8ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2534:
	/* 0x2534: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2537:
	/* 0x2537: je     2573 <filter_8ty_map+0x6d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2537, 0x2573, x86_l_2573);
x86_l_2539:
	/* 0x2539: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_253c:
	/* 0x253c: movzx  eax,BYTE PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2540:
	/* 0x2540: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2545:
	/* 0x2545: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_254a:
	/* 0x254a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_254f:
	/* 0x254f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2552:
	/* 0x2552: call   2557 <filter_8ty_map+0x51> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2557:
	/* 0x2557: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_255a:
	/* 0x255a: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_255c:
	/* 0x255c: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_255f:
	/* 0x255f: ja     2591 <filter_8ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x255f, 0x2591, x86_l_2591);
x86_l_2561:
	/* 0x2561: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_2566:
	/* 0x2566: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_2569:
	/* 0x2569: jae    2581 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2569, 0x2581, x86_l_2581);
x86_l_256b:
	/* 0x256b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_256e:
	/* 0x256e: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_2571:
	/* 0x2571: jmp    2591 <filter_8ty_map+0x8b> */
	X86_SIM_X86_SUB_JMP(0x2571, 0x2591, x86_l_2591);
x86_l_2573:
	/* 0x2573: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2575:
	/* 0x2575: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2579:
	/* 0x2579: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_257a:
	/* 0x257a: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_257c:
	/* 0x257c: jmp    2581 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2581:
	/* 0x2581: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_2586:
	/* 0x2586: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_2589:
	/* 0x2589: jae    2591 <filter_8ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2589, 0x2591, x86_l_2591);
x86_l_258b:
	/* 0x258b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_258e:
	/* 0x258e: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_2591:
	/* 0x2591: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_2594:
	/* 0x2594: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2598:
	/* 0x2598: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2599:
	/* 0x2599: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_259b:
	/* 0x259b: jmp    25a0 <filter_file_type> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_25a0 */
x86_l_25a0:
	/* 0x25a0: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25a1:
	/* 0x25a1: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_25a5:
	/* 0x25a5: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_25ac:
	/* 0x25ac: mov    eax,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ae:
	/* 0x25ae: cmp    rax,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4096ULL);
x86_l_25b4:
	/* 0x25b4: ja     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x25b4, 0x2646, x86_l_2646);
x86_l_25ba:
	/* 0x25ba: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_25bd:
	/* 0x25bd: lea    rcx,[rsi+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_25c1:
	/* 0x25c1: add    rcx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_25c5:
	/* 0x25c5: lea    rdi,[rsp+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_25ca:
	/* 0x25ca: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_25cf:
	/* 0x25cf: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_25d4:
	/* 0x25d4: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25d6:
	/* 0x25d6: lea    rdx,[rsi+rcx*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_25da:
	/* 0x25da: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_25de:
	/* 0x25de: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_25e3:
	/* 0x25e3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_25e6:
	/* 0x25e6: call   25eb <filter_file_type+0x4b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25eb:
	/* 0x25eb: mov    edx,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25ee:
	/* 0x25ee: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_25f0:
	/* 0x25f0: je     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x25f0, 0x2646, x86_l_2646);
x86_l_25f2:
	/* 0x25f2: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_25f7:
	/* 0x25f7: and    ecx,0xf000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_25fd:
	/* 0x25fd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2602:
	/* 0x2602: cmp    edx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2604:
	/* 0x2604: je     2648 <filter_file_type+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2604, 0x2648, x86_l_2648);
x86_l_2606:
	/* 0x2606: mov    edx,DWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2609:
	/* 0x2609: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_260c:
	/* 0x260c: jbe    2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x260c, 0x2646, x86_l_2646);
x86_l_260e:
	/* 0x260e: mov    esi,DWORD PTR [rbx+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2611:
	/* 0x2611: test   esi,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32);
x86_l_2613:
	/* 0x2613: je     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2613, 0x2646, x86_l_2646);
x86_l_2615:
	/* 0x2615: cmp    esi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_2617:
	/* 0x2617: je     2648 <filter_file_type+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2617, 0x2648, x86_l_2648);
x86_l_2619:
	/* 0x2619: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_261c:
	/* 0x261c: jb     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x261c, 0x2646, x86_l_2646);
x86_l_261e:
	/* 0x261e: mov    esi,DWORD PTR [rbx+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2621:
	/* 0x2621: test   esi,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32);
x86_l_2623:
	/* 0x2623: je     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2623, 0x2646, x86_l_2646);
x86_l_2625:
	/* 0x2625: cmp    esi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_2627:
	/* 0x2627: je     2648 <filter_file_type+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2627, 0x2648, x86_l_2648);
x86_l_2629:
	/* 0x2629: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_262c:
	/* 0x262c: jb     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x262c, 0x2646, x86_l_2646);
x86_l_262e:
	/* 0x262e: mov    edx,DWORD PTR [rbx+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2631:
	/* 0x2631: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_2633:
	/* 0x2633: je     2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2633, 0x2646, x86_l_2646);
x86_l_2635:
	/* 0x2635: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2637:
	/* 0x2637: cmp    edx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2639:
	/* 0x2639: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_263c:
	/* 0x263c: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2640:
	/* 0x2640: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2641:
	/* 0x2641: jmp    2646 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2646:
	/* 0x2646: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2648:
	/* 0x2648: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_264c:
	/* 0x264c: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_264d:
	/* 0x264d: jmp    2652 <filter_file_type+0xb2> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x1deULL: goto x86_l_1de;
	case 0x271ULL: goto x86_l_271;
	case 0x2b1ULL: goto x86_l_2b1;
	case 0x30aULL: goto x86_l_30a;
	case 0x311ULL: goto x86_l_311;
	case 0x320ULL: goto x86_l_320;
	case 0x327ULL: goto x86_l_327;
	case 0x333ULL: goto x86_l_333;
	case 0x33fULL: goto x86_l_33f;
	case 0x4ecULL: goto x86_l_4ec;
	case 0x50aULL: goto x86_l_50a;
	case 0x520ULL: goto x86_l_520;
	case 0x536ULL: goto x86_l_536;
	case 0x57fULL: goto x86_l_57f;
	case 0x5a5ULL: goto x86_l_5a5;
	case 0x5b0ULL: goto x86_l_5b0;
	case 0x8d8ULL: goto x86_l_8d8;
	case 0x94dULL: goto x86_l_94d;
	case 0x995ULL: goto x86_l_995;
	case 0x9cdULL: goto x86_l_9cd;
	case 0x9f3ULL: goto x86_l_9f3;
	case 0xa19ULL: goto x86_l_a19;
	case 0xa24ULL: goto x86_l_a24;
	case 0xa46ULL: goto x86_l_a46;
	case 0xa6cULL: goto x86_l_a6c;
	case 0xa77ULL: goto x86_l_a77;
	case 0xac5ULL: goto x86_l_ac5;
	case 0xae3ULL: goto x86_l_ae3;
	case 0xaedULL: goto x86_l_aed;
	case 0xaf9ULL: goto x86_l_af9;
	case 0xb40ULL: goto x86_l_b40;
	case 0xb66ULL: goto x86_l_b66;
	case 0xb71ULL: goto x86_l_b71;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
