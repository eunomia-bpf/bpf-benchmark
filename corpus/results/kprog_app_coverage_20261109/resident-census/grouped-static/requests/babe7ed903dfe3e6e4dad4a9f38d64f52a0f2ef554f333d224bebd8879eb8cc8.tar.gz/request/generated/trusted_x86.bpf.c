#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
extern __u8 substring_map[] __ksym;
extern __u8 tp_calls[] __ksym;
SEC("raw_tracepoint/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d:
	/* 0xd: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: sub    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_12:
	/* 0x12: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_15:
	/* 0x15: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_1d:
	/* 0x1d: mov    rdi,QWORD PTR [rip+0x61d0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_24:
	/* 0x24: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_29:
	/* 0x29: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2e:
	/* 0x2e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_31:
	/* 0x31: call   36 <generic_rawtp_filter_arg+0x36> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36:
	/* 0x36: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_39:
	/* 0x39: je     3ff <generic_rawtp_filter_arg+0x3ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39, 0x3ff, x86_l_3ff);
x86_l_3f:
	/* 0x3f: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_42:
	/* 0x42: mov    r12d,DWORD PTR [rax+0x5f00] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_49:
	/* 0x49: lea    rsi,[rax+0x5ef8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_50:
	/* 0x50: mov    rdi,QWORD PTR [rip+0x61d0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)filter_map));
x86_l_57:
	/* 0x57: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5c:
	/* 0x5c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_5f:
	/* 0x5f: call   64 <generic_rawtp_filter_arg+0x64> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_64:
	/* 0x64: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_67:
	/* 0x67: je     3de <generic_rawtp_filter_arg+0x3de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67, 0x3de, x86_l_3de);
x86_l_6d:
	/* 0x6d: cmp    BYTE PTR [r14+0x5ee0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104316165685248ULL);
x86_l_75:
	/* 0x75: je     3de <generic_rawtp_filter_arg+0x3de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x75, 0x3de, x86_l_3de);
x86_l_7b:
	/* 0x7b: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_7e:
	/* 0x7e: mov    eax,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_32);
x86_l_81:
	/* 0x81: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_84:
	/* 0x84: cmp    BYTE PTR [r14+rax*1+0x5ec1],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 104183021699072ULL);
x86_l_8d:
	/* 0x8d: je     11c <generic_rawtp_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8d, 0x11c, x86_l_11c);
x86_l_93:
	/* 0x93: mov    eax,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_95:
	/* 0x95: mov    ecx,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_9a:
	/* 0x9a: lea    rdx,[rcx+rax*4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_9e:
	/* 0x9e: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_a2:
	/* 0xa2: lea    rax,[rcx+rax*4] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_a6:
	/* 0xa6: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_aa:
	/* 0xaa: and    eax,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_af:
	/* 0xaf: mov    eax,DWORD PTR [rax+r15*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_b3:
	/* 0xb3: add    rax,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_b6:
	/* 0xb6: add    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_ba:
	/* 0xba: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_bc:
	/* 0xbc: and    ecx,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_c2:
	/* 0xc2: mov    ecx,DWORD PTR [rcx+r15*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_c6:
	/* 0xc6: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_c9:
	/* 0xc9: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_cb:
	/* 0xcb: and    eax,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_d0:
	/* 0xd0: mov    eax,DWORD PTR [rax+r15*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_d4:
	/* 0xd4: add    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_d7:
	/* 0xd7: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_d9:
	/* 0xd9: and    ecx,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_df:
	/* 0xdf: mov    ecx,DWORD PTR [rcx+r15*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_e3:
	/* 0xe3: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_e6:
	/* 0xe6: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_e8:
	/* 0xe8: and    eax,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_ed:
	/* 0xed: mov    ebp,DWORD PTR [rax+r15*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_f1:
	/* 0xf1: add    rbp,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_f4:
	/* 0xf4: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_f6:
	/* 0xf6: and    eax,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_fb:
	/* 0xfb: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ff:
	/* 0xff: cmp    DWORD PTR [r15+rax*1],0x19 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 25ULL);
x86_l_104:
	/* 0x104: jae    171 <generic_rawtp_filter_arg+0x171> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x104, 0x171, x86_l_171);
x86_l_106:
	/* 0x106: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10a:
	/* 0x10a: cmp    rax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 1ULL);
x86_l_10e:
	/* 0x10e: je     3de <generic_rawtp_filter_arg+0x3de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e, 0x3de, x86_l_3de);
x86_l_114:
	/* 0x114: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_116:
	/* 0x116: jne    3b2 <generic_rawtp_filter_arg+0x3b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x116, 0x3b2, x86_l_3b2);
x86_l_11c:
	/* 0x11c: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_120:
	/* 0x120: jg     141 <generic_rawtp_filter_arg+0x141> */
	X86_SIM_X86_JCC(X86_CC_G, 0x120, 0x141, x86_l_141);
x86_l_122:
	/* 0x122: cmp    r12d,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4294967295ULL);
x86_l_126:
	/* 0x126: je     414 <generic_rawtp_filter_arg+0x414> */
	X86_SIM_X86_JCC(X86_CC_E, 0x126, 0x414, x86_l_414);
x86_l_12c:
	/* 0x12c: test   r12d,r12d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32);
x86_l_12f:
	/* 0x12f: je     421 <generic_rawtp_filter_arg+0x421> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12f, 0x421, x86_l_421);
x86_l_135:
	/* 0x135: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_139:
	/* 0x139: je     431 <generic_rawtp_filter_arg+0x431> */
	X86_SIM_X86_JCC(X86_CC_E, 0x139, 0x431, x86_l_431);
x86_l_13f:
	/* 0x13f: jmp    15f <generic_rawtp_filter_arg+0x15f> */
	X86_SIM_X86_JMP(0x13f, 0x15f, x86_l_15f);
x86_l_141:
	/* 0x141: cmp    r12d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 2ULL);
x86_l_145:
	/* 0x145: je     441 <generic_rawtp_filter_arg+0x441> */
	X86_SIM_X86_JCC(X86_CC_E, 0x145, 0x441, x86_l_441);
x86_l_14b:
	/* 0x14b: cmp    r12d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 3ULL);
x86_l_14f:
	/* 0x14f: je     451 <generic_rawtp_filter_arg+0x451> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14f, 0x451, x86_l_451);
x86_l_155:
	/* 0x155: cmp    r12d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4ULL);
x86_l_159:
	/* 0x159: je     461 <generic_rawtp_filter_arg+0x461> */
	X86_SIM_X86_JCC(X86_CC_E, 0x159, 0x461, x86_l_461);
x86_l_15f:
	/* 0x15f: cmp    r12d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4ULL);
x86_l_163:
	/* 0x163: jg     499 <generic_rawtp_filter_arg+0x499> */
	X86_SIM_X86_JCC(X86_CC_G, 0x163, 0x499, x86_l_499);
x86_l_169:
	/* 0x169: inc    r12d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_16c:
	/* 0x16c: jmp    471 <generic_rawtp_filter_arg+0x471> */
	X86_SIM_X86_JMP(0x16c, 0x471, x86_l_471);
x86_l_171:
	/* 0x171: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_175:
	/* 0x175: add    rax,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_178:
	/* 0x178: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17d:
	/* 0x17d: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_183:
	/* 0x183: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_188:
	/* 0x188: mov    edi,DWORD PTR [rax+r13*4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 0ULL);
x86_l_18c:
	/* 0x18c: test   edi,0x3ff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RDI, X86_WIDTH_32, 1023ULL);
x86_l_192:
	/* 0x192: je     106 <generic_rawtp_filter_arg+0x106> */
	X86_SIM_X86_JCC(X86_CC_E, 0x192, 0x106, x86_l_106);
x86_l_198:
	/* 0x198: add    edi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_32, X86_ALU_ADD);
x86_l_19a:
	/* 0x19a: and    edi,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_1a0:
	/* 0x1a0: mov    ecx,DWORD PTR [r15+rdi*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 4ULL);
x86_l_1a5:
	/* 0x1a5: cmp    ecx,0x23 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 35ULL);
x86_l_1a8:
	/* 0x1a8: je     11c <generic_rawtp_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8, 0x11c, x86_l_11c);
x86_l_1ae:
	/* 0x1ae: add    rdi,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1b1:
	/* 0x1b1: mov    eax,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b3:
	/* 0x1b3: cmp    rax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4ULL);
x86_l_1b7:
	/* 0x1b7: ja     11c <generic_rawtp_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1b7, 0x11c, x86_l_11c);
x86_l_1bd:
	/* 0x1bd: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_1c6:
	/* 0x1c6: jne    11c <generic_rawtp_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c6, 0x11c, x86_l_11c);
x86_l_1cc:
	/* 0x1cc: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_1d4:
	/* 0x1d4: and    eax,0x7ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_1d9:
	/* 0x1d9: lea    rsi,[r14+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1dd:
	/* 0x1dd: add    rsi,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_1e4:
	/* 0x1e4: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1e7:
	/* 0x1e7: cmp    eax,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_1ea:
	/* 0x1ea: jle    20b <generic_rawtp_filter_arg+0x20b> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1ea, 0x20b, x86_l_20b);
x86_l_1ec:
	/* 0x1ec: cmp    eax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_1ef:
	/* 0x1ef: jg     23b <generic_rawtp_filter_arg+0x23b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1ef, 0x23b, x86_l_23b);
x86_l_1f1:
	/* 0x1f1: lea    edx,[rax-0x1c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551588ULL);
x86_l_1f4:
	/* 0x1f4: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_1f7:
	/* 0x1f7: jb     281 <generic_rawtp_filter_arg+0x281> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f7, 0x281, x86_l_281);
x86_l_1fd:
	/* 0x1fd: cmp    eax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_200:
	/* 0x200: je     364 <generic_rawtp_filter_arg+0x364> */
	X86_SIM_X86_JCC(X86_CC_E, 0x200, 0x364, x86_l_364);
x86_l_206:
	/* 0x206: jmp    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JMP(0x206, 0x3a0, x86_l_3a0);
x86_l_20b:
	/* 0x20b: cmp    eax,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 9ULL);
x86_l_20e:
	/* 0x20e: jle    261 <generic_rawtp_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x20e, 0x261, x86_l_261);
x86_l_210:
	/* 0x210: lea    edx,[rax-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_213:
	/* 0x213: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_216:
	/* 0x216: jb     281 <generic_rawtp_filter_arg+0x281> */
	X86_SIM_X86_JCC(X86_CC_B, 0x216, 0x281, x86_l_281);
x86_l_218:
	/* 0x218: lea    ecx,[rax-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_21b:
	/* 0x21b: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_21e:
	/* 0x21e: jb     364 <generic_rawtp_filter_arg+0x364> */
	X86_SIM_X86_JCC(X86_CC_B, 0x21e, 0x364, x86_l_364);
x86_l_224:
	/* 0x224: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_227:
	/* 0x227: jne    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x227, 0x3a0, x86_l_3a0);
x86_l_22d:
	/* 0x22d: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_231:
	/* 0x231: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_4f4, 0x236ULL);
x86_l_236:
	/* 0x236: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x236, 0x397, x86_l_397);
x86_l_23b:
	/* 0x23b: cmp    eax,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 41ULL);
x86_l_23e:
	/* 0x23e: jg     353 <generic_rawtp_filter_arg+0x353> */
	X86_SIM_X86_JCC(X86_CC_G, 0x23e, 0x353, x86_l_353);
x86_l_244:
	/* 0x244: lea    ecx,[rax-0x26] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_247:
	/* 0x247: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_24a:
	/* 0x24a: jb     30e <generic_rawtp_filter_arg+0x30e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x24a, 0x30e, x86_l_30e);
x86_l_250:
	/* 0x250: add    eax,0xffffffd8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 4294967256ULL);
x86_l_253:
	/* 0x253: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_256:
	/* 0x256: jb     304 <generic_rawtp_filter_arg+0x304> */
	X86_SIM_X86_JCC(X86_CC_B, 0x256, 0x304, x86_l_304);
x86_l_25c:
	/* 0x25c: jmp    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JMP(0x25c, 0x3a0, x86_l_3a0);
x86_l_261:
	/* 0x261: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_264:
	/* 0x264: jg     2f1 <generic_rawtp_filter_arg+0x2f1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x264, 0x2f1, x86_l_2f1);
x86_l_26a:
	/* 0x26a: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_26d:
	/* 0x26d: je     281 <generic_rawtp_filter_arg+0x281> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d, 0x281, x86_l_281);
x86_l_26f:
	/* 0x26f: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_272:
	/* 0x272: je     381 <generic_rawtp_filter_arg+0x381> */
	X86_SIM_X86_JCC(X86_CC_E, 0x272, 0x381, x86_l_381);
x86_l_278:
	/* 0x278: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_27b:
	/* 0x27b: jne    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27b, 0x3a0, x86_l_3a0);
x86_l_281:
	/* 0x281: cmp    eax,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 11ULL);
x86_l_284:
	/* 0x284: jle    2ce <generic_rawtp_filter_arg+0x2ce> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x284, 0x2ce, x86_l_2ce);
x86_l_286:
	/* 0x286: cmp    eax,0x24 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 36ULL);
x86_l_289:
	/* 0x289: ja     36b <generic_rawtp_filter_arg+0x36b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x289, 0x36b, x86_l_36b);
x86_l_28f:
	/* 0x28f: mov    edx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_291:
	/* 0x291: movabs r8,0x1e00000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_64, 128849018880ULL);
x86_l_29b:
	/* 0x29b: bt     r8,rdx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RDX, X86_WIDTH_64);
x86_l_29f:
	/* 0x29f: jb     315 <generic_rawtp_filter_arg+0x315> */
	X86_SIM_X86_JCC(X86_CC_B, 0x29f, 0x315, x86_l_315);
x86_l_2a1:
	/* 0x2a1: mov    ecx,0x60000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1610612736ULL);
x86_l_2a6:
	/* 0x2a6: bt     rcx,rdx */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_2aa:
	/* 0x2aa: jb     37a <generic_rawtp_filter_arg+0x37a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2aa, 0x37a, x86_l_37a);
x86_l_2b0:
	/* 0x2b0: movabs rcx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 6442450944ULL);
x86_l_2ba:
	/* 0x2ba: bt     rcx,rdx */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_2be:
	/* 0x2be: jae    36b <generic_rawtp_filter_arg+0x36b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2be, 0x36b, x86_l_36b);
x86_l_2c4:
	/* 0x2c4: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_5bf, 0x2c9ULL);
x86_l_2c9:
	/* 0x2c9: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x2c9, 0x397, x86_l_397);
x86_l_2ce:
	/* 0x2ce: lea    ecx,[rax-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_2d1:
	/* 0x2d1: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2d4:
	/* 0x2d4: jb     392 <generic_rawtp_filter_arg+0x392> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d4, 0x392, x86_l_392);
x86_l_2da:
	/* 0x2da: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2dd:
	/* 0x2dd: je     373 <generic_rawtp_filter_arg+0x373> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dd, 0x373, x86_l_373);
x86_l_2e3:
	/* 0x2e3: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2e6:
	/* 0x2e6: je     373 <generic_rawtp_filter_arg+0x373> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e6, 0x373, x86_l_373);
x86_l_2ec:
	/* 0x2ec: jmp    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JMP(0x2ec, 0x3a0, x86_l_3a0);
x86_l_2f1:
	/* 0x2f1: cmp    eax,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 5ULL);
x86_l_2f4:
	/* 0x2f4: je     304 <generic_rawtp_filter_arg+0x304> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f4, 0x304, x86_l_304);
x86_l_2f6:
	/* 0x2f6: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_2f9:
	/* 0x2f9: je     30e <generic_rawtp_filter_arg+0x30e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f9, 0x30e, x86_l_30e);
x86_l_2fb:
	/* 0x2fb: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_2fe:
	/* 0x2fe: jne    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fe, 0x3a0, x86_l_3a0);
x86_l_304:
	/* 0x304: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_612, 0x309ULL);
x86_l_309:
	/* 0x309: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x309, 0x397, x86_l_397);
x86_l_30e:
	/* 0x30e: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_313:
	/* 0x313: jmp    386 <generic_rawtp_filter_arg+0x386> */
	X86_SIM_X86_JMP(0x313, 0x386, x86_l_386);
x86_l_315:
	/* 0x315: cmp    ecx,0x1e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 30ULL);
x86_l_318:
	/* 0x318: jne    392 <generic_rawtp_filter_arg+0x392> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x318, 0x392, x86_l_392);
x86_l_31a:
	/* 0x31a: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31d:
	/* 0x31d: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_320:
	/* 0x320: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_322:
	/* 0x322: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_32b:
	/* 0x32b: jne    11c <generic_rawtp_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32b, 0x11c, x86_l_11c);
x86_l_331:
	/* 0x331: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_334:
	/* 0x334: mov    rdx,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_33c:
	/* 0x33c: and    edx,0x7ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_342:
	/* 0x342: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_344:
	/* 0x344: andn   rcx,rcx,QWORD PTR [r14+rdx*1+0x90] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RCX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_R14)), 618475290624ULL);
x86_l_34e:
	/* 0x34e: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_351:
	/* 0x351: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x351, 0x397, x86_l_397);
x86_l_353:
	/* 0x353: cmp    eax,0x2a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 42ULL);
x86_l_356:
	/* 0x356: je     364 <generic_rawtp_filter_arg+0x364> */
	X86_SIM_X86_JCC(X86_CC_E, 0x356, 0x364, x86_l_364);
x86_l_358:
	/* 0x358: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_35b:
	/* 0x35b: jne    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35b, 0x3a0, x86_l_3a0);
x86_l_35d:
	/* 0x35d: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_97c, 0x362ULL);
x86_l_362:
	/* 0x362: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x362, 0x397, x86_l_397);
x86_l_364:
	/* 0x364: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_4f4, 0x369ULL);
x86_l_369:
	/* 0x369: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x369, 0x397, x86_l_397);
x86_l_36b:
	/* 0x36b: lea    ecx,[rax-0xc] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_36e:
	/* 0x36e: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_371:
	/* 0x371: jae    38d <generic_rawtp_filter_arg+0x38d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x371, 0x38d, x86_l_38d);
x86_l_373:
	/* 0x373: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a33, 0x378ULL);
x86_l_378:
	/* 0x378: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x378, 0x397, x86_l_397);
x86_l_37a:
	/* 0x37a: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a86, 0x37fULL);
x86_l_37f:
	/* 0x37f: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x37f, 0x397, x86_l_397);
x86_l_381:
	/* 0x381: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_386:
	/* 0x386: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_ad9, 0x38bULL);
x86_l_38b:
	/* 0x38b: jmp    397 <generic_rawtp_filter_arg+0x397> */
	X86_SIM_X86_JMP(0x38b, 0x397, x86_l_397);
x86_l_38d:
	/* 0x38d: cmp    eax,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 28ULL);
x86_l_390:
	/* 0x390: jne    3a0 <generic_rawtp_filter_arg+0x3a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x390, 0x3a0, x86_l_3a0);
x86_l_392:
	/* 0x392: call   0 <generic_rawtp_filter_arg> */
	X86_SIM_X86_CALL(x86_l_b80, 0x397ULL);
x86_l_397:
	/* 0x397: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_39a:
	/* 0x39a: je     11c <generic_rawtp_filter_arg+0x11c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39a, 0x11c, x86_l_11c);
x86_l_3a0:
	/* 0x3a0: inc    r13 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_3a3:
	/* 0x3a3: cmp    r13,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 6ULL);
x86_l_3a7:
	/* 0x3a7: jne    183 <generic_rawtp_filter_arg+0x183> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a7, 0x183, x86_l_183);
x86_l_3ad:
	/* 0x3ad: jmp    106 <generic_rawtp_filter_arg+0x106> */
	X86_SIM_X86_JMP(0x3ad, 0x106, x86_l_106);
x86_l_3b2:
	/* 0x3b2: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b6:
	/* 0x3b6: mov    DWORD PTR [r14+0x5f04],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_3bd:
	/* 0x3bd: mov    rsi,QWORD PTR [rip+0x61e9] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tp_calls));
x86_l_3c4:
	/* 0x3c4: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_3c9:
	/* 0x3c9: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_3ce:
	/* 0x3ce: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_3d1:
	/* 0x3d1: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_3d6:
	/* 0x3d6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3d9:
	/* 0x3d9: call   3de <generic_rawtp_filter_arg+0x3de> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3de:
	/* 0x3de: mov    rsi,QWORD PTR [rip+0x61e9] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tp_calls));
x86_l_3e5:
	/* 0x3e5: mov    ecx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_3ea:
	/* 0x3ea: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_3ef:
	/* 0x3ef: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_3f2:
	/* 0x3f2: mov    edx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_3f7:
	/* 0x3f7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3fa:
	/* 0x3fa: call   3ff <generic_rawtp_filter_arg+0x3ff> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3ff:
	/* 0x3ff: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_401:
	/* 0x401: add    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_405:
	/* 0x405: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_406:
	/* 0x406: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_408:
	/* 0x408: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_40a:
	/* 0x40a: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_40c:
	/* 0x40c: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_40e:
	/* 0x40e: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_40f:
	/* 0x40f: jmp    414 <generic_rawtp_filter_arg+0x414> */
	X86_SIM_X86_RET();
x86_l_414:
	/* 0x414: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_417:
	/* 0x417: cmp    BYTE PTR [r14+0x5ec1],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104183021699072ULL);
x86_l_41f:
	/* 0x41f: jne    471 <generic_rawtp_filter_arg+0x471> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41f, 0x471, x86_l_471);
x86_l_421:
	/* 0x421: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_427:
	/* 0x427: cmp    BYTE PTR [r14+0x5ec2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104187316666368ULL);
x86_l_42f:
	/* 0x42f: jne    471 <generic_rawtp_filter_arg+0x471> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42f, 0x471, x86_l_471);
x86_l_431:
	/* 0x431: mov    r12d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 2ULL);
x86_l_437:
	/* 0x437: cmp    BYTE PTR [r14+0x5ec3],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104191611633664ULL);
x86_l_43f:
	/* 0x43f: jne    471 <generic_rawtp_filter_arg+0x471> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43f, 0x471, x86_l_471);
x86_l_441:
	/* 0x441: mov    r12d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 3ULL);
x86_l_447:
	/* 0x447: cmp    BYTE PTR [r14+0x5ec4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104195906600960ULL);
x86_l_44f:
	/* 0x44f: jne    471 <generic_rawtp_filter_arg+0x471> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44f, 0x471, x86_l_471);
x86_l_451:
	/* 0x451: mov    r12d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4ULL);
x86_l_457:
	/* 0x457: cmp    BYTE PTR [r14+0x5ec5],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104200201568256ULL);
x86_l_45f:
	/* 0x45f: jne    471 <generic_rawtp_filter_arg+0x471> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45f, 0x471, x86_l_471);
x86_l_461:
	/* 0x461: mov    r12d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 5ULL);
x86_l_467:
	/* 0x467: cmp    BYTE PTR [r14+0x5ec6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104204496535552ULL);
x86_l_46f:
	/* 0x46f: je     499 <generic_rawtp_filter_arg+0x499> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46f, 0x499, x86_l_499);
x86_l_471:
	/* 0x471: mov    DWORD PTR [r14+0x5f00],r12d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_478:
	/* 0x478: mov    rsi,QWORD PTR [rip+0x61e9] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tp_calls));
x86_l_47f:
	/* 0x47f: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_484:
	/* 0x484: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_489:
	/* 0x489: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_48c:
	/* 0x48c: mov    edx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_491:
	/* 0x491: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_494:
	/* 0x494: call   499 <generic_rawtp_filter_arg+0x499> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_499:
	/* 0x499: mov    rbx,QWORD PTR [r14+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_49d:
	/* 0x49d: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_4a2:
	/* 0x4a2: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_4a5:
	/* 0x4a5: call   4aa <generic_rawtp_filter_arg+0x4aa> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4aa:
	/* 0x4aa: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4af:
	/* 0x4af: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4b4:
	/* 0x4b4: mov    rdi,QWORD PTR [rip+0x61e9] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)retprobe_map));
x86_l_4bb:
	/* 0x4bb: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c0:
	/* 0x4c0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4c5:
	/* 0x4c5: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_4c8:
	/* 0x4c8: call   4cd <generic_rawtp_filter_arg+0x4cd> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4cd:
	/* 0x4cd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4d0:
	/* 0x4d0: je     3ff <generic_rawtp_filter_arg+0x3ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d0, 0x3ff, x86_l_3ff);
x86_l_4d6:
	/* 0x4d6: mov    rdi,QWORD PTR [rip+0x61e9] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)retprobe_map));
x86_l_4dd:
	/* 0x4dd: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4e2:
	/* 0x4e2: mov    eax,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_4e7:
	/* 0x4e7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_4ea:
	/* 0x4ea: call   4ef <generic_rawtp_filter_arg+0x4ef> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4ef:
	/* 0x4ef: jmp    3ff <generic_rawtp_filter_arg+0x3ff> */
	X86_SIM_X86_JMP(0x4ef, 0x3ff, x86_l_3ff);
x86_l_26ae:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_4f4 */
x86_l_4f4:
	/* 0x4f4: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4f5:
	/* 0x4f5: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_4f8:
	/* 0x4f8: mov    edx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fa:
	/* 0x4fa: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4fd:
	/* 0x4fd: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_4ff:
	/* 0x4ff: jne    513 <filter_file_buf+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4ff, 0x513, x86_l_513);
x86_l_501:
	/* 0x501: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_503:
	/* 0x503: and    eax,0xfffffffe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_506:
	/* 0x506: cmp    eax,0x24 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 36ULL);
x86_l_509:
	/* 0x509: je     513 <filter_file_buf+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x509, 0x513, x86_l_513);
x86_l_50b:
	/* 0x50b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_50d:
	/* 0x50d: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_50e:
	/* 0x50e: jmp    513 <filter_file_buf+0x1f> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_513:
	/* 0x513: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_516:
	/* 0x516: ja     552 <filter_file_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x516, 0x552, x86_l_552);
x86_l_518:
	/* 0x518: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_51a:
	/* 0x51a: mov    edi,0x4000100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 67109120ULL);
x86_l_51f:
	/* 0x51f: bt     rdi,rax */
	X86_SIM_L_EXEC_BT(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_523:
	/* 0x523: jb     586 <filter_file_buf+0x92> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x523, 0x586, x86_l_586);
x86_l_525:
	/* 0x525: mov    edi,0x8000200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 134218240ULL);
x86_l_52a:
	/* 0x52a: bt     rdi,rax */
	X86_SIM_L_EXEC_BT(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_52e:
	/* 0x52e: jb     570 <filter_file_buf+0x7c> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x52e, 0x570, x86_l_570);
x86_l_530:
	/* 0x530: movabs rdi,0x3000000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_64, 206158430208ULL);
x86_l_53a:
	/* 0x53a: bt     rdi,rax */
	X86_SIM_L_EXEC_BT(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_53e:
	/* 0x53e: jae    552 <filter_file_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x53e, 0x552, x86_l_552);
x86_l_540:
	/* 0x540: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_543:
	/* 0x543: call   25fc <filter_file_type> */
	X86_SIM_X86_CALL(x86_l_25fc, 0x548ULL);
x86_l_548:
	/* 0x548: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_54b:
	/* 0x54b: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_54e:
	/* 0x54e: jbe    5a3 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x54e, 0x5a3, x86_l_5a3);
x86_l_550:
	/* 0x550: jmp    5b9 <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x550, 0x5b9, x86_l_5b9);
x86_l_552:
	/* 0x552: lea    eax,[rcx-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_555:
	/* 0x555: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_558:
	/* 0x558: jae    59c <filter_file_buf+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x558, 0x59c, x86_l_59c);
x86_l_55a:
	/* 0x55a: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_55e:
	/* 0x55e: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_561:
	/* 0x561: call   12a2 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_12a2, 0x566ULL);
x86_l_566:
	/* 0x566: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_569:
	/* 0x569: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_56c:
	/* 0x56c: jbe    5a3 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x56c, 0x5a3, x86_l_5a3);
x86_l_56e:
	/* 0x56e: jmp    5b9 <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x56e, 0x5b9, x86_l_5b9);
x86_l_570:
	/* 0x570: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_574:
	/* 0x574: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_577:
	/* 0x577: call   1088 <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_1088, 0x57cULL);
x86_l_57c:
	/* 0x57c: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_57f:
	/* 0x57f: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_582:
	/* 0x582: jbe    5a3 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x582, 0x5a3, x86_l_5a3);
x86_l_584:
	/* 0x584: jmp    5b9 <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x584, 0x5b9, x86_l_5b9);
x86_l_586:
	/* 0x586: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_58a:
	/* 0x58a: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58d:
	/* 0x58d: call   11e6 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_11e6, 0x592ULL);
x86_l_592:
	/* 0x592: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_595:
	/* 0x595: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_598:
	/* 0x598: jbe    5a3 <filter_file_buf+0xaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x598, 0x5a3, x86_l_5a3);
x86_l_59a:
	/* 0x59a: jmp    5b9 <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JMP(0x59a, 0x5b9, x86_l_5b9);
x86_l_59c:
	/* 0x59c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_59e:
	/* 0x59e: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_5a1:
	/* 0x5a1: ja     5b9 <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x5a1, 0x5b9, x86_l_5b9);
x86_l_5a3:
	/* 0x5a3: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_5a5:
	/* 0x5a5: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_5af:
	/* 0x5af: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5b3:
	/* 0x5b3: jae    5b9 <filter_file_buf+0xc5> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x5b3, 0x5b9, x86_l_5b9);
x86_l_5b5:
	/* 0x5b5: xor    rax,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_5b9:
	/* 0x5b9: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5ba:
	/* 0x5ba: jmp    5bf <filter_8ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_5bf */
x86_l_5bf:
	/* 0x5bf: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c0:
	/* 0x5c0: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5c3:
	/* 0x5c3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c5:
	/* 0x5c5: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_5c9:
	/* 0x5c9: ja     60c <filter_8ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x5c9, 0x60c, x86_l_60c);
x86_l_5cb:
	/* 0x5cb: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_5d0:
	/* 0x5d0: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5d4:
	/* 0x5d4: jae    5e1 <filter_8ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x5d4, 0x5e1, x86_l_5e1);
x86_l_5d6:
	/* 0x5d6: call   217c <filter_8ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_217c, 0x5dbULL);
x86_l_5db:
	/* 0x5db: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5dc:
	/* 0x5dc: jmp    5e1 <filter_8ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_5e1:
	/* 0x5e1: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_5e6:
	/* 0x5e6: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5ea:
	/* 0x5ea: jb     607 <filter_8ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x5ea, 0x607, x86_l_607);
x86_l_5ec:
	/* 0x5ec: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_5f6:
	/* 0x5f6: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5fa:
	/* 0x5fa: jae    60c <filter_8ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x5fa, 0x60c, x86_l_60c);
x86_l_5fc:
	/* 0x5fc: call   23a2 <filter_8ty_range> */
	X86_SIM_X86_CALL(x86_l_23a2, 0x601ULL);
x86_l_601:
	/* 0x601: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_602:
	/* 0x602: jmp    607 <filter_8ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_607:
	/* 0x607: call   2562 <filter_8ty_map> */
	X86_SIM_X86_CALL(x86_l_2562, 0x60cULL);
x86_l_60c:
	/* 0x60c: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_60d:
	/* 0x60d: jmp    612 <filter_inet> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_612 */
x86_l_612:
	/* 0x612: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_614:
	/* 0x614: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_616:
	/* 0x616: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_618:
	/* 0x618: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_619:
	/* 0x619: sub    rsp,0x48 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_61d:
	/* 0x61d: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_626:
	/* 0x626: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_62f:
	/* 0x62f: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_638:
	/* 0x638: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_641:
	/* 0x641: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_64a:
	/* 0x64a: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_651:
	/* 0x651: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_659:
	/* 0x659: mov    edx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_65c:
	/* 0x65c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_65e:
	/* 0x65e: cmp    edx,0x27 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 39ULL);
x86_l_661:
	/* 0x661: jg     679 <filter_inet+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x661, 0x679, x86_l_679);
x86_l_663:
	/* 0x663: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_666:
	/* 0x666: je     6fe <filter_inet+0xec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x666, 0x6fe, x86_l_6fe);
x86_l_66c:
	/* 0x66c: mov    r8,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RSI, X86_WIDTH_64);
x86_l_66f:
	/* 0x66f: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_672:
	/* 0x672: je     68a <filter_inet+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x672, 0x68a, x86_l_68a);
x86_l_674:
	/* 0x674: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x674, 0x934, x86_l_934);
x86_l_679:
	/* 0x679: cmp    edx,0x28 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 40ULL);
x86_l_67c:
	/* 0x67c: je     6d6 <filter_inet+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x67c, 0x6d6, x86_l_6d6);
x86_l_67e:
	/* 0x67e: mov    r8,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RSI, X86_WIDTH_64);
x86_l_681:
	/* 0x681: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_684:
	/* 0x684: jne    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x684, 0x934, x86_l_934);
x86_l_68a:
	/* 0x68a: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_68d:
	/* 0x68d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_68f:
	/* 0x68f: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_692:
	/* 0x692: jle    70b <filter_inet+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x692, 0x70b, x86_l_70b);
x86_l_694:
	/* 0x694: cmp    ecx,0x17 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 23ULL);
x86_l_697:
	/* 0x697: jg     6b6 <filter_inet+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x697, 0x6b6, x86_l_6b6);
x86_l_699:
	/* 0x699: lea    edx,[rcx-0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_69c:
	/* 0x69c: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_69f:
	/* 0x69f: jb     75c <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x69f, 0x75c, x86_l_75c);
x86_l_6a5:
	/* 0x6a5: lea    edx,[rcx-0x16] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_6a8:
	/* 0x6a8: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_6ab:
	/* 0x6ab: jb     756 <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x6ab, 0x756, x86_l_756);
x86_l_6b1:
	/* 0x6b1: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x6b1, 0x934, x86_l_934);
x86_l_6b6:
	/* 0x6b6: cmp    ecx,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 27ULL);
x86_l_6b9:
	/* 0x6b9: jg     799 <filter_inet+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6b9, 0x799, x86_l_799);
x86_l_6bf:
	/* 0x6bf: cmp    ecx,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 24ULL);
x86_l_6c2:
	/* 0x6c2: je     7cc <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6c2, 0x7cc, x86_l_7cc);
x86_l_6c8:
	/* 0x6c8: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_6cb:
	/* 0x6cb: je     7c2 <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6cb, 0x7c2, x86_l_7c2);
x86_l_6d1:
	/* 0x6d1: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x6d1, 0x934, x86_l_934);
x86_l_6d6:
	/* 0x6d6: movzx  eax,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_6d9:
	/* 0x6d9: mov    WORD PTR [rsp+0x46],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_6de:
	/* 0x6de: movzx  eax,WORD PTR [rsi+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_6e2:
	/* 0x6e2: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6e7:
	/* 0x6e7: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6eb:
	/* 0x6eb: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6f0:
	/* 0x6f0: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6f4:
	/* 0x6f4: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6f9:
	/* 0x6f9: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6fe:
	/* 0x6fe: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_701:
	/* 0x701: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_704:
	/* 0x704: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_706:
	/* 0x706: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_709:
	/* 0x709: jg     694 <filter_inet+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x709, 0x694, x86_l_694);
x86_l_70b:
	/* 0x70b: cmp    ecx,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 15ULL);
x86_l_70e:
	/* 0x70e: jle    72c <filter_inet+0x11a> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x70e, 0x72c, x86_l_72c);
x86_l_710:
	/* 0x710: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_713:
	/* 0x713: jg     748 <filter_inet+0x136> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x713, 0x748, x86_l_748);
x86_l_715:
	/* 0x715: cmp    ecx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_718:
	/* 0x718: je     756 <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x718, 0x756, x86_l_756);
x86_l_71a:
	/* 0x71a: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_71d:
	/* 0x71d: jne    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x71d, 0x934, x86_l_934);
x86_l_723:
	/* 0x723: movzx  eax,WORD PTR [rsi+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_727:
	/* 0x727: jmp    929 <filter_inet+0x317> */
	X86_SIM_X86_SUB_JMP(0x727, 0x929, x86_l_929);
x86_l_72c:
	/* 0x72c: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_72f:
	/* 0x72f: je     7cc <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x72f, 0x7cc, x86_l_7cc);
x86_l_735:
	/* 0x735: cmp    ecx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 14ULL);
x86_l_738:
	/* 0x738: je     7c2 <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x738, 0x7c2, x86_l_7c2);
x86_l_73e:
	/* 0x73e: cmp    ecx,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 15ULL);
x86_l_741:
	/* 0x741: je     75c <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x741, 0x75c, x86_l_75c);
x86_l_743:
	/* 0x743: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x743, 0x934, x86_l_934);
x86_l_748:
	/* 0x748: cmp    ecx,0x12 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 18ULL);
x86_l_74b:
	/* 0x74b: je     75c <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x74b, 0x75c, x86_l_75c);
x86_l_74d:
	/* 0x74d: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_750:
	/* 0x750: jne    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x750, 0x934, x86_l_934);
x86_l_756:
	/* 0x756: movzx  edx,WORD PTR [rsi+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_75a:
	/* 0x75a: jmp    760 <filter_inet+0x14e> */
	X86_SIM_X86_SUB_JMP(0x75a, 0x760, x86_l_760);
x86_l_75c:
	/* 0x75c: movzx  edx,WORD PTR [rsi+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_760:
	/* 0x760: mov    DWORD PTR [rsp+0x4],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_764:
	/* 0x764: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_766:
	/* 0x766: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_769:
	/* 0x769: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_76c:
	/* 0x76c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_76e:
	/* 0x76e: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_771:
	/* 0x771: jg     7e3 <filter_inet+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x771, 0x7e3, x86_l_7e3);
x86_l_773:
	/* 0x773: lea    edx,[rcx-0xd] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_776:
	/* 0x776: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_779:
	/* 0x779: jb     816 <filter_inet+0x204> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x779, 0x816, x86_l_816);
x86_l_77f:
	/* 0x77f: lea    edx,[rcx-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_782:
	/* 0x782: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_785:
	/* 0x785: jb     878 <filter_inet+0x266> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x785, 0x878, x86_l_878);
x86_l_78b:
	/* 0x78b: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_78e:
	/* 0x78e: je     92c <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x78e, 0x92c, x86_l_92c);
x86_l_794:
	/* 0x794: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x794, 0x934, x86_l_934);
x86_l_799:
	/* 0x799: cmp    ecx,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 28ULL);
x86_l_79c:
	/* 0x79c: je     925 <filter_inet+0x313> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x79c, 0x925, x86_l_925);
x86_l_7a2:
	/* 0x7a2: cmp    ecx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 29ULL);
x86_l_7a5:
	/* 0x7a5: jne    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7a5, 0x934, x86_l_934);
x86_l_7ab:
	/* 0x7ab: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_7ae:
	/* 0x7ae: jne    95c <filter_inet+0x34a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7ae, 0x95c, x86_l_95c);
x86_l_7b4:
	/* 0x7b4: test   r8,r8 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64);
x86_l_7b7:
	/* 0x7b7: jne    966 <filter_inet+0x354> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7b7, 0x966, x86_l_966);
x86_l_7bd:
	/* 0x7bd: jmp    92c <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JMP(0x7bd, 0x92c, x86_l_92c);
x86_l_7c2:
	/* 0x7c2: mov    rbx,QWORD PTR [rsi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7c6:
	/* 0x7c6: mov    r14,QWORD PTR [rsi+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7ca:
	/* 0x7ca: jmp    7d3 <filter_inet+0x1c1> */
	X86_SIM_X86_SUB_JMP(0x7ca, 0x7d3, x86_l_7d3);
x86_l_7cc:
	/* 0x7cc: mov    rbx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7cf:
	/* 0x7cf: mov    r14,QWORD PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7d3:
	/* 0x7d3: mov    r15,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RBX, X86_WIDTH_64);
x86_l_7d6:
	/* 0x7d6: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_7da:
	/* 0x7da: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7dc:
	/* 0x7dc: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7de:
	/* 0x7de: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_7e1:
	/* 0x7e1: jle    773 <filter_inet+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x7e1, 0x773, x86_l_773);
x86_l_7e3:
	/* 0x7e3: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_7e6:
	/* 0x7e6: ja     86c <filter_inet+0x25a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x7e6, 0x86c, x86_l_86c);
x86_l_7ec:
	/* 0x7ec: mov    r8d,0x500000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5242880ULL);
x86_l_7f2:
	/* 0x7f2: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_7f6:
	/* 0x7f6: jb     882 <filter_inet+0x270> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x7f6, 0x882, x86_l_882);
x86_l_7fc:
	/* 0x7fc: mov    r8d,0xa00000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 10485760ULL);
x86_l_802:
	/* 0x802: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_806:
	/* 0x806: jb     892 <filter_inet+0x280> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x806, 0x892, x86_l_892);
x86_l_80c:
	/* 0x80c: mov    edx,0x3000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 50331648ULL);
x86_l_811:
	/* 0x811: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_814:
	/* 0x814: jae    86c <filter_inet+0x25a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x814, 0x86c, x86_l_86c);
x86_l_816:
	/* 0x816: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_81a:
	/* 0x81a: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_81d:
	/* 0x81d: je     8a2 <filter_inet+0x290> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x81d, 0x8a2, x86_l_8a2);
x86_l_823:
	/* 0x823: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_826:
	/* 0x826: jne    91e <filter_inet+0x30c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x826, 0x91e, x86_l_91e);
x86_l_82c:
	/* 0x82c: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_82f:
	/* 0x82f: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_832:
	/* 0x832: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_836:
	/* 0x836: mov    rdi,QWORD PTR [rip+0x1c68] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)addr4lpm_maps));
x86_l_83d:
	/* 0x83d: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_842:
	/* 0x842: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_847:
	/* 0x847: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_84a:
	/* 0x84a: call   84f <filter_inet+0x23d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_84f:
	/* 0x84f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_852:
	/* 0x852: je     944 <filter_inet+0x332> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x852, 0x944, x86_l_944);
x86_l_858:
	/* 0x858: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_85b:
	/* 0x85b: mov    DWORD PTR [rsp+0xc],0x20 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_863:
	/* 0x863: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_867:
	/* 0x867: jmp    8ec <filter_inet+0x2da> */
	X86_SIM_X86_SUB_JMP(0x867, 0x8ec, x86_l_8ec);
x86_l_86c:
	/* 0x86c: add    ecx,0xffffffee */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_86f:
	/* 0x86f: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_872:
	/* 0x872: jae    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x872, 0x934, x86_l_934);
x86_l_878:
	/* 0x878: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_87d:
	/* 0x87d: jmp    92f <filter_inet+0x31d> */
	X86_SIM_X86_SUB_JMP(0x87d, 0x92f, x86_l_92f);
x86_l_882:
	/* 0x882: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_884:
	/* 0x884: cmp    edx,0x400 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_88a:
	/* 0x88a: setb   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_B);
x86_l_88d:
	/* 0x88d: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x88d, 0x934, x86_l_934);
x86_l_892:
	/* 0x892: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_894:
	/* 0x894: cmp    edx,0x400 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_89a:
	/* 0x89a: setae  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_AE);
x86_l_89d:
	/* 0x89d: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x89d, 0x934, x86_l_934);
x86_l_8a2:
	/* 0x8a2: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_8a5:
	/* 0x8a5: mov    eax,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_8a8:
	/* 0x8a8: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8ac:
	/* 0x8ac: mov    rdi,QWORD PTR [rip+0x1c68] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)addr6lpm_maps));
x86_l_8b3:
	/* 0x8b3: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8b8:
	/* 0x8b8: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_8bd:
	/* 0x8bd: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_8c0:
	/* 0x8c0: call   8c5 <filter_inet+0x2b3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8c5:
	/* 0x8c5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8c8:
	/* 0x8c8: je     944 <filter_inet+0x332> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8c8, 0x944, x86_l_944);
x86_l_8ca:
	/* 0x8ca: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_8cd:
	/* 0x8cd: mov    DWORD PTR [rsp+0xc],0x80 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607680ULL);
x86_l_8d5:
	/* 0x8d5: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8d9:
	/* 0x8d9: mov    DWORD PTR [rsp+0x14],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_8de:
	/* 0x8de: mov    DWORD PTR [rsp+0x18],r14d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8e3:
	/* 0x8e3: shr    r14,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_8e7:
	/* 0x8e7: mov    DWORD PTR [rsp+0x1c],r14d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_8ec:
	/* 0x8ec: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_8f1:
	/* 0x8f1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_8f6:
	/* 0x8f6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_8f9:
	/* 0x8f9: call   8fe <filter_inet+0x2ec> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8fe:
	/* 0x8fe: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_903:
	/* 0x903: lea    edx,[rcx-0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_906:
	/* 0x906: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_909:
	/* 0x909: jb     951 <filter_inet+0x33f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x909, 0x951, x86_l_951);
x86_l_90b:
	/* 0x90b: add    ecx,0xfffffff3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_90e:
	/* 0x90e: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_911:
	/* 0x911: ja     91e <filter_inet+0x30c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x911, 0x91e, x86_l_91e);
x86_l_913:
	/* 0x913: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_916:
	/* 0x916: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_919:
	/* 0x919: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_91c:
	/* 0x91c: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x91c, 0x934, x86_l_934);
x86_l_91e:
	/* 0x91e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_920:
	/* 0x920: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_923:
	/* 0x923: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x923, 0x934, x86_l_934);
x86_l_925:
	/* 0x925: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_929:
	/* 0x929: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_92c:
	/* 0x92c: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_92f:
	/* 0x92f: call   20e3 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_20e3, 0x934ULL);
x86_l_934:
	/* 0x934: add    rsp,0x48 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_938:
	/* 0x938: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_939:
	/* 0x939: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_93b:
	/* 0x93b: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_93d:
	/* 0x93d: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_93f:
	/* 0x93f: jmp    944 <filter_inet+0x332> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_944:
	/* 0x944: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_949:
	/* 0x949: and    eax,0xfffffffe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_94c:
	/* 0x94c: cmp    eax,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 24ULL);
x86_l_94f:
	/* 0x94f: jmp    954 <filter_inet+0x342> */
	X86_SIM_X86_SUB_JMP(0x94f, 0x954, x86_l_954);
x86_l_951:
	/* 0x951: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_954:
	/* 0x954: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_957:
	/* 0x957: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_95a:
	/* 0x95a: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x95a, 0x934, x86_l_934);
x86_l_95c:
	/* 0x95c: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_95f:
	/* 0x95f: jne    96e <filter_inet+0x35c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x95f, 0x96e, x86_l_96e);
x86_l_961:
	/* 0x961: test   r8,r8 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64);
x86_l_964:
	/* 0x964: je     96e <filter_inet+0x35c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x964, 0x96e, x86_l_96e);
x86_l_966:
	/* 0x966: movzx  eax,BYTE PTR [r8+0x3a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_96b:
	/* 0x96b: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_96e:
	/* 0x96e: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_971:
	/* 0x971: je     92c <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x971, 0x92c, x86_l_92c);
x86_l_973:
	/* 0x973: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_976:
	/* 0x976: je     92c <filter_inet+0x31a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x976, 0x92c, x86_l_92c);
x86_l_978:
	/* 0x978: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_97a:
	/* 0x97a: jmp    934 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JMP(0x97a, 0x934, x86_l_934);

	/* native subroutine native_link_sub_97c */
x86_l_97c:
	/* 0x97c: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_97d:
	/* 0x97d: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_981:
	/* 0x981: mov    rcx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RSI, X86_WIDTH_64);
x86_l_984:
	/* 0x984: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_988:
	/* 0x988: movzx  edx,BYTE PTR [rcx+0x3] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_98c:
	/* 0x98c: mov    r8d,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_990:
	/* 0x990: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_992:
	/* 0x992: cmp    r8d,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 25ULL);
x86_l_996:
	/* 0x996: jg     9d0 <filter_sockaddr_un+0x54> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x996, 0x9d0, x86_l_9d0);
x86_l_998:
	/* 0x998: lea    ecx,[r8-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_99c:
	/* 0x99c: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_99f:
	/* 0x99f: jae    9de <filter_sockaddr_un+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x99f, 0x9de, x86_l_9de);
x86_l_9a1:
	/* 0x9a1: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_9a4:
	/* 0x9a4: call   12a2 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_12a2, 0x9a9ULL);
x86_l_9a9:
	/* 0x9a9: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9ac:
	/* 0x9ac: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_9b0:
	/* 0x9b0: ja     9c6 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x9b0, 0x9c6, x86_l_9c6);
x86_l_9b2:
	/* 0x9b2: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_9bc:
	/* 0x9bc: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_9c0:
	/* 0x9c0: jae    9c6 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9c0, 0x9c6, x86_l_9c6);
x86_l_9c2:
	/* 0x9c2: xor    rax,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_9c6:
	/* 0x9c6: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_9ca:
	/* 0x9ca: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9cb:
	/* 0x9cb: jmp    9d0 <filter_sockaddr_un+0x54> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_9d0:
	/* 0x9d0: cmp    r8d,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 28ULL);
x86_l_9d4:
	/* 0x9d4: je     a18 <filter_sockaddr_un+0x9c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9d4, 0xa18, x86_l_a18);
x86_l_9d6:
	/* 0x9d6: cmp    r8d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 26ULL);
x86_l_9da:
	/* 0x9da: je     9e4 <filter_sockaddr_un+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9da, 0x9e4, x86_l_9e4);
x86_l_9dc:
	/* 0x9dc: jmp    9c6 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JMP(0x9dc, 0x9c6, x86_l_9c6);
x86_l_9de:
	/* 0x9de: cmp    r8d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 8ULL);
x86_l_9e2:
	/* 0x9e2: jne    9c6 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x9e2, 0x9c6, x86_l_9c6);
x86_l_9e4:
	/* 0x9e4: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9e7:
	/* 0x9e7: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_9ea:
	/* 0x9ea: mov    edi,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_32);
x86_l_9ec:
	/* 0x9ec: call   11e6 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_11e6, 0x9f1ULL);
x86_l_9f1:
	/* 0x9f1: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9f4:
	/* 0x9f4: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_9f8:
	/* 0x9f8: ja     9c6 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x9f8, 0x9c6, x86_l_9c6);
x86_l_9fa:
	/* 0x9fa: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_a04:
	/* 0xa04: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a08:
	/* 0xa08: jae    9c6 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa08, 0x9c6, x86_l_9c6);
x86_l_a0a:
	/* 0xa0a: xor    rax,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_a0e:
	/* 0xa0e: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_a12:
	/* 0xa12: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a13:
	/* 0xa13: jmp    a18 <filter_sockaddr_un+0x9c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_a18:
	/* 0xa18: movzx  eax,WORD PTR [rcx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_a1b:
	/* 0xa1b: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a1f:
	/* 0xa1f: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a24:
	/* 0xa24: call   20e3 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_20e3, 0xa29ULL);
x86_l_a29:
	/* 0xa29: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_a2d:
	/* 0xa2d: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a2e:
	/* 0xa2e: jmp    a33 <filter_32ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_a33 */
x86_l_a33:
	/* 0xa33: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a34:
	/* 0xa34: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a37:
	/* 0xa37: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a39:
	/* 0xa39: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_a3d:
	/* 0xa3d: ja     a80 <filter_32ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa3d, 0xa80, x86_l_a80);
x86_l_a3f:
	/* 0xa3f: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_a44:
	/* 0xa44: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a48:
	/* 0xa48: jae    a55 <filter_32ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa48, 0xa55, x86_l_a55);
x86_l_a4a:
	/* 0xa4a: call   1d05 <filter_32ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1d05, 0xa4fULL);
x86_l_a4f:
	/* 0xa4f: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a50:
	/* 0xa50: jmp    a55 <filter_32ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_a55:
	/* 0xa55: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_a5a:
	/* 0xa5a: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a5e:
	/* 0xa5e: jb     a7b <filter_32ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa5e, 0xa7b, x86_l_a7b);
x86_l_a60:
	/* 0xa60: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_a6a:
	/* 0xa6a: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a6e:
	/* 0xa6e: jae    a80 <filter_32ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa6e, 0xa80, x86_l_a80);
x86_l_a70:
	/* 0xa70: call   1f25 <filter_32ty_range> */
	X86_SIM_X86_CALL(x86_l_1f25, 0xa75ULL);
x86_l_a75:
	/* 0xa75: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a76:
	/* 0xa76: jmp    a7b <filter_32ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_a7b:
	/* 0xa7b: call   20e3 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_20e3, 0xa80ULL);
x86_l_a80:
	/* 0xa80: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a81:
	/* 0xa81: jmp    a86 <filter_16ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_a86 */
x86_l_a86:
	/* 0xa86: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a87:
	/* 0xa87: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a8a:
	/* 0xa8a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a8c:
	/* 0xa8c: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_a90:
	/* 0xa90: ja     ad3 <filter_16ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa90, 0xad3, x86_l_ad3);
x86_l_a92:
	/* 0xa92: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_a97:
	/* 0xa97: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a9b:
	/* 0xa9b: jae    aa8 <filter_16ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa9b, 0xaa8, x86_l_aa8);
x86_l_a9d:
	/* 0xa9d: call   1885 <filter_16ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1885, 0xaa2ULL);
x86_l_aa2:
	/* 0xaa2: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_aa3:
	/* 0xaa3: jmp    aa8 <filter_16ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_aa8:
	/* 0xaa8: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_aad:
	/* 0xaad: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_ab1:
	/* 0xab1: jb     ace <filter_16ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xab1, 0xace, x86_l_ace);
x86_l_ab3:
	/* 0xab3: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_abd:
	/* 0xabd: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_ac1:
	/* 0xac1: jae    ad3 <filter_16ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xac1, 0xad3, x86_l_ad3);
x86_l_ac3:
	/* 0xac3: call   1aab <filter_16ty_range> */
	X86_SIM_X86_CALL(x86_l_1aab, 0xac8ULL);
x86_l_ac8:
	/* 0xac8: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ac9:
	/* 0xac9: jmp    ace <filter_16ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_ace:
	/* 0xace: call   1c6b <filter_16ty_map> */
	X86_SIM_X86_CALL(x86_l_1c6b, 0xad3ULL);
x86_l_ad3:
	/* 0xad3: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ad4:
	/* 0xad4: jmp    ad9 <filter_char_buf> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_ad9 */
x86_l_ad9:
	/* 0xad9: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ada:
	/* 0xada: mov    rax,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_64);
x86_l_add:
	/* 0xadd: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_ae0:
	/* 0xae0: movsxd rcx,edx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_ae3:
	/* 0xae3: mov    edx,DWORD PTR [rsi+rcx*1-0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 18446744073709551612ULL);
x86_l_ae7:
	/* 0xae7: mov    esi,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_ae9:
	/* 0xae9: add    rsi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_aec:
	/* 0xaec: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_aef:
	/* 0xaef: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_af1:
	/* 0xaf1: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_af4:
	/* 0xaf4: jg     b0a <filter_char_buf+0x31> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xaf4, 0xb0a, x86_l_b0a);
x86_l_af6:
	/* 0xaf6: lea    edi,[rcx-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_af9:
	/* 0xaf9: cmp    edi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_afc:
	/* 0xafc: jb     b41 <filter_char_buf+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xafc, 0xb41, x86_l_b41);
x86_l_afe:
	/* 0xafe: cmp    ecx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_b01:
	/* 0xb01: je     b37 <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb01, 0xb37, x86_l_b37);
x86_l_b03:
	/* 0xb03: cmp    ecx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_b06:
	/* 0xb06: je     b19 <filter_char_buf+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb06, 0xb19, x86_l_b19);
x86_l_b08:
	/* 0xb08: jmp    b58 <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JMP(0xb08, 0xb58, x86_l_b58);
x86_l_b0a:
	/* 0xb0a: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_b0d:
	/* 0xb0d: jg     b23 <filter_char_buf+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xb0d, 0xb23, x86_l_b23);
x86_l_b0f:
	/* 0xb0f: cmp    ecx,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 26ULL);
x86_l_b12:
	/* 0xb12: je     b37 <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb12, 0xb37, x86_l_b37);
x86_l_b14:
	/* 0xb14: cmp    ecx,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 27ULL);
x86_l_b17:
	/* 0xb17: jne    b58 <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb17, 0xb58, x86_l_b58);
x86_l_b19:
	/* 0xb19: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b1c:
	/* 0xb1c: call   1088 <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_1088, 0xb21ULL);
x86_l_b21:
	/* 0xb21: jmp    b55 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xb21, 0xb55, x86_l_b55);
x86_l_b23:
	/* 0xb23: cmp    ecx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 33ULL);
x86_l_b26:
	/* 0xb26: je     b4b <filter_char_buf+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb26, 0xb4b, x86_l_b4b);
x86_l_b28:
	/* 0xb28: cmp    ecx,0x22 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 34ULL);
x86_l_b2b:
	/* 0xb2b: jne    b58 <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb2b, 0xb58, x86_l_b58);
x86_l_b2d:
	/* 0xb2d: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_b30:
	/* 0xb30: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_b35:
	/* 0xb35: jmp    b50 <filter_char_buf+0x77> */
	X86_SIM_X86_SUB_JMP(0xb35, 0xb50, x86_l_b50);
x86_l_b37:
	/* 0xb37: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b3a:
	/* 0xb3a: call   11e6 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_11e6, 0xb3fULL);
x86_l_b3f:
	/* 0xb3f: jmp    b55 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xb3f, 0xb55, x86_l_b55);
x86_l_b41:
	/* 0xb41: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_b44:
	/* 0xb44: call   12a2 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_12a2, 0xb49ULL);
x86_l_b49:
	/* 0xb49: jmp    b55 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xb49, 0xb55, x86_l_b55);
x86_l_b4b:
	/* 0xb4b: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_b4e:
	/* 0xb4e: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b50:
	/* 0xb50: call   1653 <filter_char_substring> */
	X86_SIM_X86_CALL(x86_l_1653, 0xb55ULL);
x86_l_b55:
	/* 0xb55: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b58:
	/* 0xb58: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_b5b:
	/* 0xb5b: ja     b7a <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb5b, 0xb7a, x86_l_b7a);
x86_l_b5d:
	/* 0xb5d: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_b5f:
	/* 0xb5f: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_b69:
	/* 0xb69: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b6d:
	/* 0xb6d: jae    b7a <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb6d, 0xb7a, x86_l_b7a);
x86_l_b6f:
	/* 0xb6f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b71:
	/* 0xb71: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b74:
	/* 0xb74: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_b77:
	/* 0xb77: mov    rax,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_b7a:
	/* 0xb7a: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b7b:
	/* 0xb7b: jmp    b80 <filter_64ty> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_b80 */
x86_l_b80:
	/* 0xb80: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b81:
	/* 0xb81: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b84:
	/* 0xb84: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b86:
	/* 0xb86: cmp    rcx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32ULL);
x86_l_b8a:
	/* 0xb8a: ja     bcd <filter_64ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb8a, 0xbcd, x86_l_bcd);
x86_l_b8c:
	/* 0xb8c: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_b91:
	/* 0xb91: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_b95:
	/* 0xb95: jae    ba2 <filter_64ty+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb95, 0xba2, x86_l_ba2);
x86_l_b97:
	/* 0xb97: call   bd3 <filter_64ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_bd3, 0xb9cULL);
x86_l_b9c:
	/* 0xb9c: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b9d:
	/* 0xb9d: jmp    ba2 <filter_64ty+0x22> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_ba2:
	/* 0xba2: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_ba7:
	/* 0xba7: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_bab:
	/* 0xbab: jb     bc8 <filter_64ty+0x48> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbab, 0xbc8, x86_l_bc8);
x86_l_bad:
	/* 0xbad: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_bb7:
	/* 0xbb7: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_bbb:
	/* 0xbbb: jae    bcd <filter_64ty+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xbbb, 0xbcd, x86_l_bcd);
x86_l_bbd:
	/* 0xbbd: call   e15 <filter_64ty_range> */
	X86_SIM_X86_CALL(x86_l_e15, 0xbc2ULL);
x86_l_bc2:
	/* 0xbc2: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bc3:
	/* 0xbc3: jmp    bc8 <filter_64ty+0x48> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_bc8:
	/* 0xbc8: call   ffc <filter_64ty_map> */
	X86_SIM_X86_CALL(x86_l_ffc, 0xbcdULL);
x86_l_bcd:
	/* 0xbcd: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bce:
	/* 0xbce: jmp    bd3 <filter_64ty_selector_val> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_bd3 */
x86_l_bd3:
	/* 0xbd3: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_bd6:
	/* 0xbd6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_bdb:
	/* 0xbdb: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_bdf:
	/* 0xbdf: ja     c63 <filter_64ty_selector_val+0x90> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xbdf, 0xc63, x86_l_c63);
x86_l_be5:
	/* 0xbe5: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_bef:
	/* 0xbef: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_bf3:
	/* 0xbf3: jae    bfa <filter_64ty_selector_val+0x27> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xbf3, 0xbfa, x86_l_bfa);
x86_l_bf5:
	/* 0xbf5: jmp    bfa <filter_64ty_selector_val+0x27> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_bfa:
	/* 0xbfa: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_bff:
	/* 0xbff: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_c03:
	/* 0xc03: jae    c1f <filter_64ty_selector_val+0x4c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xc03, 0xc1f, x86_l_c1f);
x86_l_c05:
	/* 0xc05: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c08:
	/* 0xc08: cmp    rdx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c0c:
	/* 0xc0c: jne    d41 <filter_64ty_selector_val+0x16e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc0c, 0xd41, x86_l_d41);
x86_l_c12:
	/* 0xc12: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c14:
	/* 0xc14: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_c17:
	/* 0xc17: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_c1a:
	/* 0xc1a: jmp    c1f <filter_64ty_selector_val+0x4c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_c1f:
	/* 0xc1f: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_c23:
	/* 0xc23: jne    c63 <filter_64ty_selector_val+0x90> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc23, 0xc63, x86_l_c63);
x86_l_c25:
	/* 0xc25: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c28:
	/* 0xc28: test   QWORD PTR [rdi+0x10],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_c2c:
	/* 0xc2c: jne    bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc2c, 0xbf5, x86_l_bf5);
x86_l_c2e:
	/* 0xc2e: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c31:
	/* 0xc31: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_c34:
	/* 0xc34: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc34, 0xe0e, x86_l_e0e);
x86_l_c3a:
	/* 0xc3a: test   QWORD PTR [rdi+0x18],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_c3e:
	/* 0xc3e: jne    bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc3e, 0xbf5, x86_l_bf5);
x86_l_c40:
	/* 0xc40: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_c43:
	/* 0xc43: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc43, 0xe0e, x86_l_e0e);
x86_l_c49:
	/* 0xc49: test   QWORD PTR [rdi+0x20],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_c4d:
	/* 0xc4d: jne    bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc4d, 0xbf5, x86_l_bf5);
x86_l_c4f:
	/* 0xc4f: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_c52:
	/* 0xc52: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc52, 0xe0e, x86_l_e0e);
x86_l_c58:
	/* 0xc58: test   QWORD PTR [rdi+0x28],rcx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_c5c:
	/* 0xc5c: jne    bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc5c, 0xbf5, x86_l_bf5);
x86_l_c5e:
	/* 0xc5e: jmp    e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xc5e, 0xe0e, x86_l_e0e);
x86_l_c63:
	/* 0xc63: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_c66:
	/* 0xc66: je     cd9 <filter_64ty_selector_val+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc66, 0xcd9, x86_l_cd9);
x86_l_c68:
	/* 0xc68: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_c6b:
	/* 0xc6b: jne    e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc6b, 0xe0e, x86_l_e0e);
x86_l_c71:
	/* 0xc71: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_c74:
	/* 0xc74: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_c77:
	/* 0xc77: ja     dd1 <filter_64ty_selector_val+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc77, 0xdd1, x86_l_dd1);
x86_l_c7d:
	/* 0xc7d: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_c82:
	/* 0xc82: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_c85:
	/* 0xc85: jae    dd1 <filter_64ty_selector_val+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xc85, 0xdd1, x86_l_dd1);
x86_l_c8b:
	/* 0xc8b: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c8e:
	/* 0xc8e: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c92:
	/* 0xc92: jl     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc92, 0xbf5, x86_l_bf5);
x86_l_c98:
	/* 0xc98: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c9b:
	/* 0xc9b: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_c9e:
	/* 0xc9e: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc9e, 0xe0e, x86_l_e0e);
x86_l_ca4:
	/* 0xca4: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_ca8:
	/* 0xca8: jl     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xca8, 0xbf5, x86_l_bf5);
x86_l_cae:
	/* 0xcae: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_cb1:
	/* 0xcb1: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcb1, 0xe0e, x86_l_e0e);
x86_l_cb7:
	/* 0xcb7: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_cbb:
	/* 0xcbb: jl     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xcbb, 0xbf5, x86_l_bf5);
x86_l_cc1:
	/* 0xcc1: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_cc4:
	/* 0xcc4: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcc4, 0xe0e, x86_l_e0e);
x86_l_cca:
	/* 0xcca: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_cce:
	/* 0xcce: jl     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xcce, 0xbf5, x86_l_bf5);
x86_l_cd4:
	/* 0xcd4: jmp    e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xcd4, 0xe0e, x86_l_e0e);
x86_l_cd9:
	/* 0xcd9: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_cdc:
	/* 0xcdc: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_cdf:
	/* 0xcdf: ja     d92 <filter_64ty_selector_val+0x1bf> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcdf, 0xd92, x86_l_d92);
x86_l_ce5:
	/* 0xce5: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_cea:
	/* 0xcea: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_ced:
	/* 0xced: jae    d92 <filter_64ty_selector_val+0x1bf> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xced, 0xd92, x86_l_d92);
x86_l_cf3:
	/* 0xcf3: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cf6:
	/* 0xcf6: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_cfa:
	/* 0xcfa: jg     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xcfa, 0xbf5, x86_l_bf5);
x86_l_d00:
	/* 0xd00: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d03:
	/* 0xd03: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_d06:
	/* 0xd06: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd06, 0xe0e, x86_l_e0e);
x86_l_d0c:
	/* 0xd0c: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d10:
	/* 0xd10: jg     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd10, 0xbf5, x86_l_bf5);
x86_l_d16:
	/* 0xd16: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_d19:
	/* 0xd19: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd19, 0xe0e, x86_l_e0e);
x86_l_d1f:
	/* 0xd1f: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d23:
	/* 0xd23: jg     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd23, 0xbf5, x86_l_bf5);
x86_l_d29:
	/* 0xd29: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_d2c:
	/* 0xd2c: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd2c, 0xe0e, x86_l_e0e);
x86_l_d32:
	/* 0xd32: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d36:
	/* 0xd36: jg     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd36, 0xbf5, x86_l_bf5);
x86_l_d3c:
	/* 0xd3c: jmp    e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xd3c, 0xe0e, x86_l_e0e);
x86_l_d41:
	/* 0xd41: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d44:
	/* 0xd44: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_d47:
	/* 0xd47: jb     d71 <filter_64ty_selector_val+0x19e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd47, 0xd71, x86_l_d71);
x86_l_d49:
	/* 0xd49: cmp    rdx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d4d:
	/* 0xd4d: je     c12 <filter_64ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd4d, 0xc12, x86_l_c12);
x86_l_d53:
	/* 0xd53: cmp    esi,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 25ULL);
x86_l_d56:
	/* 0xd56: jb     d71 <filter_64ty_selector_val+0x19e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd56, 0xd71, x86_l_d71);
x86_l_d58:
	/* 0xd58: cmp    rdx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d5c:
	/* 0xd5c: je     c12 <filter_64ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd5c, 0xc12, x86_l_c12);
x86_l_d62:
	/* 0xd62: cmp    esi,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 33ULL);
x86_l_d65:
	/* 0xd65: jb     d71 <filter_64ty_selector_val+0x19e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd65, 0xd71, x86_l_d71);
x86_l_d67:
	/* 0xd67: cmp    rdx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d6b:
	/* 0xd6b: je     c12 <filter_64ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd6b, 0xc12, x86_l_c12);
x86_l_d71:
	/* 0xd71: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_d74:
	/* 0xd74: ja     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd74, 0xe0e, x86_l_e0e);
x86_l_d7a:
	/* 0xd7a: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_d7c:
	/* 0xd7c: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_d86:
	/* 0xd86: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_d8a:
	/* 0xd8a: jb     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd8a, 0xbf5, x86_l_bf5);
x86_l_d90:
	/* 0xd90: jmp    e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xd90, 0xe0e, x86_l_e0e);
x86_l_d92:
	/* 0xd92: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d95:
	/* 0xd95: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_d99:
	/* 0xd99: ja     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd99, 0xbf5, x86_l_bf5);
x86_l_d9f:
	/* 0xd9f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_da2:
	/* 0xda2: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_da5:
	/* 0xda5: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xda5, 0xe0e, x86_l_e0e);
x86_l_da7:
	/* 0xda7: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_dab:
	/* 0xdab: ja     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdab, 0xbf5, x86_l_bf5);
x86_l_db1:
	/* 0xdb1: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_db4:
	/* 0xdb4: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdb4, 0xe0e, x86_l_e0e);
x86_l_db6:
	/* 0xdb6: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_dba:
	/* 0xdba: ja     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdba, 0xbf5, x86_l_bf5);
x86_l_dc0:
	/* 0xdc0: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_dc3:
	/* 0xdc3: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdc3, 0xe0e, x86_l_e0e);
x86_l_dc5:
	/* 0xdc5: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_dc9:
	/* 0xdc9: ja     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdc9, 0xbf5, x86_l_bf5);
x86_l_dcf:
	/* 0xdcf: jmp    e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JMP(0xdcf, 0xe0e, x86_l_e0e);
x86_l_dd1:
	/* 0xdd1: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dd4:
	/* 0xdd4: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_dd8:
	/* 0xdd8: jb     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdd8, 0xbf5, x86_l_bf5);
x86_l_dde:
	/* 0xdde: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_de1:
	/* 0xde1: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_de4:
	/* 0xde4: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xde4, 0xe0e, x86_l_e0e);
x86_l_de6:
	/* 0xde6: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_dea:
	/* 0xdea: jb     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdea, 0xbf5, x86_l_bf5);
x86_l_df0:
	/* 0xdf0: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_df3:
	/* 0xdf3: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdf3, 0xe0e, x86_l_e0e);
x86_l_df5:
	/* 0xdf5: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_df9:
	/* 0xdf9: jb     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdf9, 0xbf5, x86_l_bf5);
x86_l_dff:
	/* 0xdff: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_e02:
	/* 0xe02: jb     e0e <filter_64ty_selector_val+0x23b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe02, 0xe0e, x86_l_e0e);
x86_l_e04:
	/* 0xe04: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e08:
	/* 0xe08: jb     bf5 <filter_64ty_selector_val+0x22> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe08, 0xbf5, x86_l_bf5);
x86_l_e0e:
	/* 0xe0e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e10:
	/* 0xe10: jmp    e15 <filter_64ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_e15 */
x86_l_e15:
	/* 0xe15: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e18:
	/* 0xe18: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_e1b:
	/* 0xe1b: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_e1e:
	/* 0xe1e: ja     f18 <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe1e, 0xf18, x86_l_f18);
x86_l_e24:
	/* 0xe24: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_e29:
	/* 0xe29: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_e2c:
	/* 0xe2c: jae    f18 <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xe2c, 0xf18, x86_l_f18);
x86_l_e32:
	/* 0xe32: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e35:
	/* 0xe35: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_e38:
	/* 0xe38: jne    ea8 <filter_64ty_range+0x93> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xe38, 0xea8, x86_l_ea8);
x86_l_e3a:
	/* 0xe3a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_e3f:
	/* 0xe3f: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e43:
	/* 0xe43: jg     e4f <filter_64ty_range+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe43, 0xe4f, x86_l_e4f);
x86_l_e45:
	/* 0xe45: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e49:
	/* 0xe49: jle    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe49, 0xf31, x86_l_f31);
x86_l_e4f:
	/* 0xe4f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e52:
	/* 0xe52: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_e55:
	/* 0xe55: jb     fe7 <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe55, 0xfe7, x86_l_fe7);
x86_l_e5b:
	/* 0xe5b: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e5f:
	/* 0xe5f: jg     e6b <filter_64ty_range+0x56> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe5f, 0xe6b, x86_l_e6b);
x86_l_e61:
	/* 0xe61: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e65:
	/* 0xe65: jle    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe65, 0xf31, x86_l_f31);
x86_l_e6b:
	/* 0xe6b: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_e6e:
	/* 0xe6e: jb     fe7 <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe6e, 0xfe7, x86_l_fe7);
x86_l_e74:
	/* 0xe74: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e78:
	/* 0xe78: jg     e84 <filter_64ty_range+0x6f> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe78, 0xe84, x86_l_e84);
x86_l_e7a:
	/* 0xe7a: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e7e:
	/* 0xe7e: jle    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe7e, 0xf31, x86_l_f31);
x86_l_e84:
	/* 0xe84: cmp    edx,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 57ULL);
x86_l_e87:
	/* 0xe87: jb     fe7 <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe87, 0xfe7, x86_l_fe7);
x86_l_e8d:
	/* 0xe8d: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e8f:
	/* 0xe8f: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e93:
	/* 0xe93: jg     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xe93, 0xfe9, x86_l_fe9);
x86_l_e99:
	/* 0xe99: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_e9d:
	/* 0xe9d: jle    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xe9d, 0xf31, x86_l_f31);
x86_l_ea3:
	/* 0xea3: jmp    fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JMP(0xea3, 0xfe9, x86_l_fe9);
x86_l_ea8:
	/* 0xea8: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_eab:
	/* 0xeab: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eaf:
	/* 0xeaf: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_eb3:
	/* 0xeb3: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_eb7:
	/* 0xeb7: setle  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_LE);
x86_l_eba:
	/* 0xeba: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_ebd:
	/* 0xebd: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_ec0:
	/* 0xec0: jb     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xec0, 0xfe9, x86_l_fe9);
x86_l_ec6:
	/* 0xec6: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_eca:
	/* 0xeca: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_ece:
	/* 0xece: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_ed2:
	/* 0xed2: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_ed6:
	/* 0xed6: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_ed9:
	/* 0xed9: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_edc:
	/* 0xedc: cmp    eax,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 41ULL);
x86_l_edf:
	/* 0xedf: jb     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xedf, 0xfe9, x86_l_fe9);
x86_l_ee5:
	/* 0xee5: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ee9:
	/* 0xee9: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_eed:
	/* 0xeed: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_ef1:
	/* 0xef1: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_ef5:
	/* 0xef5: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_ef8:
	/* 0xef8: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_efb:
	/* 0xefb: cmp    eax,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 57ULL);
x86_l_efe:
	/* 0xefe: jb     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xefe, 0xfe9, x86_l_fe9);
x86_l_f04:
	/* 0xf04: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f08:
	/* 0xf08: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_f0b:
	/* 0xf0b: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_f0f:
	/* 0xf0f: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_f13:
	/* 0xf13: jmp    f99 <filter_64ty_range+0x184> */
	X86_SIM_X86_SUB_JMP(0xf13, 0xf99, x86_l_f99);
x86_l_f18:
	/* 0xf18: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f1b:
	/* 0xf1b: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_f1e:
	/* 0xf1e: jne    f36 <filter_64ty_range+0x121> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xf1e, 0xf36, x86_l_f36);
x86_l_f20:
	/* 0xf20: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_f25:
	/* 0xf25: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f29:
	/* 0xf29: ja     fa1 <filter_64ty_range+0x18c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf29, 0xfa1, x86_l_fa1);
x86_l_f2b:
	/* 0xf2b: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_f2f:
	/* 0xf2f: ja     fa1 <filter_64ty_range+0x18c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf2f, 0xfa1, x86_l_fa1);
x86_l_f31:
	/* 0xf31: jmp    f36 <filter_64ty_range+0x121> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_f36:
	/* 0xf36: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f39:
	/* 0xf39: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f3d:
	/* 0xf3d: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_f41:
	/* 0xf41: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_f45:
	/* 0xf45: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_f48:
	/* 0xf48: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_f4b:
	/* 0xf4b: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_f4e:
	/* 0xf4e: jb     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf4e, 0xfe9, x86_l_fe9);
x86_l_f54:
	/* 0xf54: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f58:
	/* 0xf58: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_f5c:
	/* 0xf5c: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_f60:
	/* 0xf60: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_f64:
	/* 0xf64: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_f67:
	/* 0xf67: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_f6a:
	/* 0xf6a: cmp    eax,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 41ULL);
x86_l_f6d:
	/* 0xf6d: jb     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf6d, 0xfe9, x86_l_fe9);
x86_l_f6f:
	/* 0xf6f: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f73:
	/* 0xf73: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_f77:
	/* 0xf77: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_f7b:
	/* 0xf7b: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_f7f:
	/* 0xf7f: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_f82:
	/* 0xf82: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_f85:
	/* 0xf85: cmp    eax,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 57ULL);
x86_l_f88:
	/* 0xf88: jb     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf88, 0xfe9, x86_l_fe9);
x86_l_f8a:
	/* 0xf8a: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f8e:
	/* 0xf8e: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_f91:
	/* 0xf91: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_f95:
	/* 0xf95: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_f99:
	/* 0xf99: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_f9c:
	/* 0xf9c: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_f9f:
	/* 0xf9f: jmp    fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JMP(0xf9f, 0xfe9, x86_l_fe9);
x86_l_fa1:
	/* 0xfa1: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fa4:
	/* 0xfa4: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_fa7:
	/* 0xfa7: jb     fe7 <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xfa7, 0xfe7, x86_l_fe7);
x86_l_fa9:
	/* 0xfa9: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_fad:
	/* 0xfad: ja     fb9 <filter_64ty_range+0x1a4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xfad, 0xfb9, x86_l_fb9);
x86_l_faf:
	/* 0xfaf: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_fb3:
	/* 0xfb3: jbe    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xfb3, 0xf31, x86_l_f31);
x86_l_fb9:
	/* 0xfb9: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_fbc:
	/* 0xfbc: jb     fe7 <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xfbc, 0xfe7, x86_l_fe7);
x86_l_fbe:
	/* 0xfbe: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_fc2:
	/* 0xfc2: ja     fce <filter_64ty_range+0x1b9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xfc2, 0xfce, x86_l_fce);
x86_l_fc4:
	/* 0xfc4: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_fc8:
	/* 0xfc8: jbe    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xfc8, 0xf31, x86_l_f31);
x86_l_fce:
	/* 0xfce: cmp    edx,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 57ULL);
x86_l_fd1:
	/* 0xfd1: jb     fe7 <filter_64ty_range+0x1d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xfd1, 0xfe7, x86_l_fe7);
x86_l_fd3:
	/* 0xfd3: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_fd5:
	/* 0xfd5: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_fd9:
	/* 0xfd9: ja     fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xfd9, 0xfe9, x86_l_fe9);
x86_l_fdb:
	/* 0xfdb: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_fdf:
	/* 0xfdf: jbe    f31 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xfdf, 0xf31, x86_l_f31);
x86_l_fe5:
	/* 0xfe5: jmp    fe9 <filter_64ty_range+0x1d4> */
	X86_SIM_X86_SUB_JMP(0xfe5, 0xfe9, x86_l_fe9);
x86_l_fe7:
	/* 0xfe7: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_fe9:
	/* 0xfe9: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_fec:
	/* 0xfec: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_fef:
	/* 0xfef: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_ff2:
	/* 0xff2: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_ff4:
	/* 0xff4: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_ff7:
	/* 0xff7: jmp    ffc <filter_64ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_ffc */
x86_l_ffc:
	/* 0xffc: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_ffe:
	/* 0xffe: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fff:
	/* 0xfff: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1003:
	/* 0x1003: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_1006:
	/* 0x1006: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_1009:
	/* 0x1009: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_100d:
	/* 0x100d: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1011:
	/* 0x1011: mov    rdi,QWORD PTR [rip+0xad0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_1018:
	/* 0x1018: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_101d:
	/* 0x101d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1022:
	/* 0x1022: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1025:
	/* 0x1025: call   102a <filter_64ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_102a:
	/* 0x102a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_102d:
	/* 0x102d: je     1061 <filter_64ty_map+0x65> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x102d, 0x1061, x86_l_1061);
x86_l_102f:
	/* 0x102f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1032:
	/* 0x1032: mov    rax,QWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1035:
	/* 0x1035: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_103a:
	/* 0x103a: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_103f:
	/* 0x103f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1044:
	/* 0x1044: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1047:
	/* 0x1047: call   104c <filter_64ty_map+0x50> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_104c:
	/* 0x104c: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_104f:
	/* 0x104f: cmp    ecx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 11ULL);
x86_l_1052:
	/* 0x1052: je     106f <filter_64ty_map+0x73> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1052, 0x106f, x86_l_106f);
x86_l_1054:
	/* 0x1054: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_1057:
	/* 0x1057: jne    1077 <filter_64ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1057, 0x1077, x86_l_1077);
x86_l_1059:
	/* 0x1059: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_105c:
	/* 0x105c: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_105f:
	/* 0x105f: jmp    1079 <filter_64ty_map+0x7d> */
	X86_SIM_X86_SUB_JMP(0x105f, 0x1079, x86_l_1079);
x86_l_1061:
	/* 0x1061: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1063:
	/* 0x1063: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1067:
	/* 0x1067: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1068:
	/* 0x1068: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_106a:
	/* 0x106a: jmp    106f <filter_64ty_map+0x73> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_106f:
	/* 0x106f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1072:
	/* 0x1072: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1075:
	/* 0x1075: jmp    1079 <filter_64ty_map+0x7d> */
	X86_SIM_X86_SUB_JMP(0x1075, 0x1079, x86_l_1079);
x86_l_1077:
	/* 0x1077: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1079:
	/* 0x1079: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_107c:
	/* 0x107c: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1080:
	/* 0x1080: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1081:
	/* 0x1081: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1083:
	/* 0x1083: jmp    1088 <filter_char_buf_postfix> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1088 */
x86_l_1088:
	/* 0x1088: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_108a:
	/* 0x108a: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_108c:
	/* 0x108c: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_108d:
	/* 0x108d: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_1091:
	/* 0x1091: mov    ebx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDX, X86_WIDTH_32);
x86_l_1093:
	/* 0x1093: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_1096:
	/* 0x1096: mov    DWORD PTR [rsp+0xc],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_109a:
	/* 0x109a: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_10a2:
	/* 0x10a2: mov    rdi,QWORD PTR [rip+0x2510] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_postfix_maps));
x86_l_10a9:
	/* 0x10a9: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_10ae:
	/* 0x10ae: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_10b3:
	/* 0x10b3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_10b6:
	/* 0x10b6: call   10bb <filter_char_buf_postfix+0x33> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10bb:
	/* 0x10bb: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_10be:
	/* 0x10be: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10c0:
	/* 0x10c0: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
x86_l_10c2:
	/* 0x10c2: je     11d8 <filter_char_buf_postfix+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10c2, 0x11d8, x86_l_11d8);
x86_l_10c8:
	/* 0x10c8: test   r15,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64);
x86_l_10cb:
	/* 0x10cb: je     11d8 <filter_char_buf_postfix+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10cb, 0x11d8, x86_l_11d8);
x86_l_10d1:
	/* 0x10d1: mov    rdi,QWORD PTR [rip+0x2510] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_postfix_maps_heap));
x86_l_10d8:
	/* 0x10d8: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10dd:
	/* 0x10dd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_10e2:
	/* 0x10e2: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_10e5:
	/* 0x10e5: call   10ea <filter_char_buf_postfix+0x62> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10ea:
	/* 0x10ea: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_10ed:
	/* 0x10ed: je     11d6 <filter_char_buf_postfix+0x14e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10ed, 0x11d6, x86_l_11d6);
x86_l_10f3:
	/* 0x10f3: mov    rsi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_10f6:
	/* 0x10f6: cmp    ebx,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 127ULL);
x86_l_10f9:
	/* 0x10f9: mov    eax,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 127ULL);
x86_l_10fe:
	/* 0x10fe: cmovb  eax,ebx */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RBX, X86_WIDTH_32, X86_CC_B);
x86_l_1101:
	/* 0x1101: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1104:
	/* 0x1104: mov    DWORD PTR [rsi],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1106:
	/* 0x1106: mov    eax,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_32);
x86_l_1108:
	/* 0x1108: lea    ecx,[rbx-0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_110b:
	/* 0x110b: mov    rdx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_110e:
	/* 0x110e: add    rdx,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_1112:
	/* 0x1112: lea    edi,[rbx-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1115:
	/* 0x1115: lea    r8d,[rbx-0x2] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_1119:
	/* 0x1119: dec    ebx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_111b:
	/* 0x111b: mov    r9,0xfffffffffffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_64, 18446744073709551613ULL);
x86_l_1122:
	/* 0x1122: lea    r10d,[rbx+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1126:
	/* 0x1126: add    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_112a:
	/* 0x112a: and    r10d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1131:
	/* 0x1131: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1136:
	/* 0x1136: mov    BYTE PTR [rdx-0x3],r10b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_113a:
	/* 0x113a: lea    r10,[rax+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_113e:
	/* 0x113e: cmp    r10,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 18446744073709551614ULL);
x86_l_1142:
	/* 0x1142: je     11b9 <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1142, 0x11b9, x86_l_11b9);
x86_l_1144:
	/* 0x1144: lea    r11d,[r8+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1148:
	/* 0x1148: add    r11d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_114c:
	/* 0x114c: and    r11d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1153:
	/* 0x1153: movzx  r11d,BYTE PTR [r14+r11*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1158:
	/* 0x1158: mov    BYTE PTR [rdx-0x2],r11b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_115c:
	/* 0x115c: cmp    r10,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_1160:
	/* 0x1160: je     11b9 <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1160, 0x11b9, x86_l_11b9);
x86_l_1162:
	/* 0x1162: lea    r10d,[rdi+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1166:
	/* 0x1166: add    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_116a:
	/* 0x116a: and    r10d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1171:
	/* 0x1171: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1176:
	/* 0x1176: mov    BYTE PTR [rdx-0x1],r10b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_117a:
	/* 0x117a: mov    r10,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RAX, X86_WIDTH_64);
x86_l_117d:
	/* 0x117d: add    r10,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1180:
	/* 0x1180: je     11b9 <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1180, 0x11b9, x86_l_11b9);
x86_l_1182:
	/* 0x1182: cmp    r9,0xffffffffffffff81 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_64, 18446744073709551489ULL);
x86_l_1186:
	/* 0x1186: je     11b9 <filter_char_buf_postfix+0x131> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1186, 0x11b9, x86_l_11b9);
x86_l_1188:
	/* 0x1188: lea    r10d,[rcx+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_118c:
	/* 0x118c: add    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1190:
	/* 0x1190: and    r10d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1197:
	/* 0x1197: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_119c:
	/* 0x119c: mov    BYTE PTR [rdx],r10b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_119f:
	/* 0x119f: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_11a3:
	/* 0x11a3: lea    r10,[rax+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_11a7:
	/* 0x11a7: add    r10,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_11ab:
	/* 0x11ab: add    r9,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_11af:
	/* 0x11af: cmp    r10,0xfffffffffffffffd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 18446744073709551613ULL);
x86_l_11b3:
	/* 0x11b3: jne    1122 <filter_char_buf_postfix+0x9a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x11b3, 0x1122, x86_l_1122);
x86_l_11b9:
	/* 0x11b9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_11be:
	/* 0x11be: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_11c1:
	/* 0x11c1: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_11c4:
	/* 0x11c4: call   11c9 <filter_char_buf_postfix+0x141> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11c9:
	/* 0x11c9: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_11cc:
	/* 0x11cc: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11ce:
	/* 0x11ce: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_11d1:
	/* 0x11d1: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_11d4:
	/* 0x11d4: jmp    11d8 <filter_char_buf_postfix+0x150> */
	X86_SIM_X86_SUB_JMP(0x11d4, 0x11d8, x86_l_11d8);
x86_l_11d6:
	/* 0x11d6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11d8:
	/* 0x11d8: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_11dc:
	/* 0x11dc: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11dd:
	/* 0x11dd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_11df:
	/* 0x11df: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11e1:
	/* 0x11e1: jmp    11e6 <filter_char_buf_prefix> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_11e6 */
x86_l_11e6:
	/* 0x11e6: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_11e7:
	/* 0x11e7: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11e9:
	/* 0x11e9: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_11eb:
	/* 0x11eb: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11ec:
	/* 0x11ec: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11ed:
	/* 0x11ed: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_11ef:
	/* 0x11ef: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_11f2:
	/* 0x11f2: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11f6:
	/* 0x11f6: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11fd:
	/* 0x11fd: mov    rdi,QWORD PTR [rip+0x2450] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_prefix_maps));
x86_l_1204:
	/* 0x1204: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1209:
	/* 0x1209: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_120e:
	/* 0x120e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1211:
	/* 0x1211: call   1216 <filter_char_buf_prefix+0x30> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1216:
	/* 0x1216: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_1219:
	/* 0x1219: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_121b:
	/* 0x121b: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_121d:
	/* 0x121d: je     1293 <filter_char_buf_prefix+0xad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x121d, 0x1293, x86_l_1293);
x86_l_121f:
	/* 0x121f: test   r14,r14 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64);
x86_l_1222:
	/* 0x1222: je     1293 <filter_char_buf_prefix+0xad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1222, 0x1293, x86_l_1293);
x86_l_1224:
	/* 0x1224: mov    rdi,QWORD PTR [rip+0x2450] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_122b:
	/* 0x122b: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_122e:
	/* 0x122e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1233:
	/* 0x1233: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1236:
	/* 0x1236: call   123b <filter_char_buf_prefix+0x55> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_123b:
	/* 0x123b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_123e:
	/* 0x123e: je     1291 <filter_char_buf_prefix+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x123e, 0x1291, x86_l_1291);
x86_l_1240:
	/* 0x1240: cmp    ebp,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 255ULL);
x86_l_1246:
	/* 0x1246: mov    esi,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 255ULL);
x86_l_124b:
	/* 0x124b: cmovb  esi,ebp */
	X86_SIM_L_EXEC_CMOV(X86_RSI, X86_RBP, X86_WIDTH_32, X86_CC_B);
x86_l_124e:
	/* 0x124e: lea    ecx,[rsi*8+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_1255:
	/* 0x1255: mov    DWORD PTR [rax],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1257:
	/* 0x1257: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_125a:
	/* 0x125a: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_125e:
	/* 0x125e: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1261:
	/* 0x1261: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1266:
	/* 0x1266: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_1269:
	/* 0x1269: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_126c:
	/* 0x126c: call   1271 <filter_char_buf_prefix+0x8b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1271:
	/* 0x1271: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1276:
	/* 0x1276: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_1279:
	/* 0x1279: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_127c:
	/* 0x127c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_127f:
	/* 0x127f: call   1284 <filter_char_buf_prefix+0x9e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1284:
	/* 0x1284: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1287:
	/* 0x1287: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1289:
	/* 0x1289: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_128c:
	/* 0x128c: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_128f:
	/* 0x128f: jmp    1293 <filter_char_buf_prefix+0xad> */
	X86_SIM_X86_SUB_JMP(0x128f, 0x1293, x86_l_1293);
x86_l_1291:
	/* 0x1291: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1293:
	/* 0x1293: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1297:
	/* 0x1297: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1298:
	/* 0x1298: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_129a:
	/* 0x129a: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_129c:
	/* 0x129c: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_129d:
	/* 0x129d: jmp    12a2 <filter_char_buf_equal> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_12a2 */
x86_l_12a2:
	/* 0x12a2: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_12a3:
	/* 0x12a3: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12a5:
	/* 0x12a5: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12a7:
	/* 0x12a7: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_12a9:
	/* 0x12a9: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_12ab:
	/* 0x12ab: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12ac:
	/* 0x12ac: sub    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_12b0:
	/* 0x12b0: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_12b8:
	/* 0x12b8: cmp    edx,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4096ULL);
x86_l_12be:
	/* 0x12be: ja     163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x12be, 0x163e, x86_l_163e);
x86_l_12c4:
	/* 0x12c4: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_12c6:
	/* 0x12c6: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_12c9:
	/* 0x12c9: cmp    eax,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 144ULL);
x86_l_12ce:
	/* 0x12ce: ja     1317 <filter_char_buf_equal+0x75> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x12ce, 0x1317, x86_l_1317);
x86_l_12d0:
	/* 0x12d0: test   bp,bp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_16);
x86_l_12d3:
	/* 0x12d3: je     12e6 <filter_char_buf_equal+0x44> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12d3, 0x12e6, x86_l_12e6);
x86_l_12d5:
	/* 0x12d5: mov    ecx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 24ULL);
x86_l_12da:
	/* 0x12da: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_12dc:
	/* 0x12dc: cdq */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 31) & 1ULL)));
x86_l_12dd:
	/* 0x12dd: idiv   ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, X86_DIV_AUX_SIGNED, 0);
x86_l_12df:
	/* 0x12df: mov    r14d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBP, X86_WIDTH_32);
x86_l_12e2:
	/* 0x12e2: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_12e4:
	/* 0x12e4: je     1306 <filter_char_buf_equal+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12e4, 0x1306, x86_l_1306);
x86_l_12e6:
	/* 0x12e6: mov    ecx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 24ULL);
x86_l_12eb:
	/* 0x12eb: mov    eax,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_12ed:
	/* 0x12ed: cdq */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 31) & 1ULL)));
x86_l_12ee:
	/* 0x12ee: idiv   ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, X86_DIV_AUX_SIGNED, 0);
x86_l_12f0:
	/* 0x12f0: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_12f3:
	/* 0x12f3: lea    eax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_12f6:
	/* 0x12f6: add    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_12f9:
	/* 0x12f9: movzx  r14d,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_12fd:
	/* 0x12fd: cmp    r14d,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 144ULL);
x86_l_1304:
	/* 0x1304: ja     1355 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1304, 0x1355, x86_l_1355);
x86_l_1306:
	/* 0x1306: mov    eax,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R14, X86_WIDTH_32);
x86_l_1309:
	/* 0x1309: cdq */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 31) & 1ULL)));
x86_l_130a:
	/* 0x130a: idiv   ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, X86_DIV_AUX_SIGNED, 0);
x86_l_130c:
	/* 0x130c: mov    r15d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_32);
x86_l_130f:
	/* 0x130f: dec    r15d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1312:
	/* 0x1312: jmp    13a0 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x1312, 0x13a0, x86_l_13a0);
x86_l_1317:
	/* 0x1317: mov    r14d,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 256ULL);
x86_l_131d:
	/* 0x131d: cmp    eax,0x101 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 257ULL);
x86_l_1322:
	/* 0x1322: jb     1355 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1322, 0x1355, x86_l_1355);
x86_l_1324:
	/* 0x1324: mov    r14d,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 512ULL);
x86_l_132a:
	/* 0x132a: cmp    eax,0x201 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 513ULL);
x86_l_132f:
	/* 0x132f: jb     1355 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x132f, 0x1355, x86_l_1355);
x86_l_1331:
	/* 0x1331: mov    r14d,0x400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 1024ULL);
x86_l_1337:
	/* 0x1337: cmp    eax,0x401 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1025ULL);
x86_l_133c:
	/* 0x133c: jb     1355 <filter_char_buf_equal+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x133c, 0x1355, x86_l_1355);
x86_l_133e:
	/* 0x133e: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1341:
	/* 0x1341: cmp    eax,0x801 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2049ULL);
x86_l_1346:
	/* 0x1346: setae  r14b */
	X86_SIM_L_EXEC_SETCC(X86_R14, X86_CC_AE);
x86_l_134a:
	/* 0x134a: shl    r14d,0xb */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_134e:
	/* 0x134e: add    r14d,0x800 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_1355:
	/* 0x1355: lea    eax,[r14-0x100] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_135c:
	/* 0x135c: rorx   eax,eax,0x8 */
	X86_SIM_L_EXEC_RORX(X86_RAX, X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1362:
	/* 0x1362: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1365:
	/* 0x1365: jg     1378 <filter_char_buf_equal+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1365, 0x1378, x86_l_1378);
x86_l_1367:
	/* 0x1367: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1369:
	/* 0x1369: je     1392 <filter_char_buf_equal+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1369, 0x1392, x86_l_1392);
x86_l_136b:
	/* 0x136b: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_136e:
	/* 0x136e: jne    138a <filter_char_buf_equal+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x136e, 0x138a, x86_l_138a);
x86_l_1370:
	/* 0x1370: mov    r15d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 7ULL);
x86_l_1376:
	/* 0x1376: jmp    13a0 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x1376, 0x13a0, x86_l_13a0);
x86_l_1378:
	/* 0x1378: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_137b:
	/* 0x137b: je     139a <filter_char_buf_equal+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x137b, 0x139a, x86_l_139a);
x86_l_137d:
	/* 0x137d: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_1380:
	/* 0x1380: jne    138a <filter_char_buf_equal+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1380, 0x138a, x86_l_138a);
x86_l_1382:
	/* 0x1382: mov    r15d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 9ULL);
x86_l_1388:
	/* 0x1388: jmp    13a0 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x1388, 0x13a0, x86_l_13a0);
x86_l_138a:
	/* 0x138a: mov    r15d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 10ULL);
x86_l_1390:
	/* 0x1390: jmp    13a0 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x1390, 0x13a0, x86_l_13a0);
x86_l_1392:
	/* 0x1392: mov    r15d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 6ULL);
x86_l_1398:
	/* 0x1398: jmp    13a0 <filter_char_buf_equal+0xfe> */
	X86_SIM_X86_SUB_JMP(0x1398, 0x13a0, x86_l_13a0);
x86_l_139a:
	/* 0x139a: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_13a0:
	/* 0x13a0: mov    eax,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_32);
x86_l_13a3:
	/* 0x13a3: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_13a6:
	/* 0x13a6: mov    r13d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_13ab:
	/* 0x13ab: cmp    r13d,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 4294967295ULL);
x86_l_13af:
	/* 0x13af: je     163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13af, 0x163e, x86_l_163e);
x86_l_13b5:
	/* 0x13b5: mov    QWORD PTR [rsp+0x20],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13ba:
	/* 0x13ba: mov    rdi,QWORD PTR [rip+0x20a0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_heap));
x86_l_13c1:
	/* 0x13c1: lea    r12,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_13c6:
	/* 0x13c6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_13cb:
	/* 0x13cb: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_13ce:
	/* 0x13ce: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_13d1:
	/* 0x13d1: call   13d6 <filter_char_buf_equal+0x134> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13d6:
	/* 0x13d6: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_13d9:
	/* 0x13d9: mov    rdi,QWORD PTR [rip+0x20a0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)heap_ro_zero));
x86_l_13e0:
	/* 0x13e0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_13e5:
	/* 0x13e5: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_13e8:
	/* 0x13e8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_13eb:
	/* 0x13eb: call   13f0 <filter_char_buf_equal+0x14e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13f0:
	/* 0x13f0: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_13f3:
	/* 0x13f3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13f5:
	/* 0x13f5: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13fa:
	/* 0x13fa: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
x86_l_13fd:
	/* 0x13fd: je     1640 <filter_char_buf_equal+0x39e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13fd, 0x1640, x86_l_1640);
x86_l_1403:
	/* 0x1403: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_1406:
	/* 0x1406: je     1640 <filter_char_buf_equal+0x39e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1406, 0x1640, x86_l_1640);
x86_l_140c:
	/* 0x140c: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1411:
	/* 0x1411: cmp    r15d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 5ULL);
x86_l_1415:
	/* 0x1415: jg     145e <filter_char_buf_equal+0x1bc> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1415, 0x145e, x86_l_145e);
x86_l_1417:
	/* 0x1417: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_141c:
	/* 0x141c: mov    BYTE PTR [rax],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_141f:
	/* 0x141f: lea    rdi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1423:
	/* 0x1423: mov    r12d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_1426:
	/* 0x1426: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_142b:
	/* 0x142b: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1430:
	/* 0x1430: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_1432:
	/* 0x1432: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1435:
	/* 0x1435: call   143a <filter_char_buf_equal+0x198> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_143a:
	/* 0x143a: sub    r14d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_143d:
	/* 0x143d: jbe    14af <filter_char_buf_equal+0x20d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x143d, 0x14af, x86_l_14af);
x86_l_143f:
	/* 0x143f: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1444:
	/* 0x1444: lea    rdi,[rax+r12*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_1448:
	/* 0x1448: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_144b:
	/* 0x144b: and    r14d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1452:
	/* 0x1452: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1457:
	/* 0x1457: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_145c:
	/* 0x145c: jmp    14a4 <filter_char_buf_equal+0x202> */
	X86_SIM_X86_SUB_JMP(0x145c, 0x14a4, x86_l_14a4);
x86_l_145e:
	/* 0x145e: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1463:
	/* 0x1463: mov    WORD PTR [rax],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1466:
	/* 0x1466: lea    rdi,[rax+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_146a:
	/* 0x146a: mov    r12d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_146d:
	/* 0x146d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1472:
	/* 0x1472: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1477:
	/* 0x1477: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_1479:
	/* 0x1479: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_147c:
	/* 0x147c: call   1481 <filter_char_buf_equal+0x1df> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1481:
	/* 0x1481: sub    r14d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1484:
	/* 0x1484: jbe    14af <filter_char_buf_equal+0x20d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1484, 0x14af, x86_l_14af);
x86_l_1486:
	/* 0x1486: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_148b:
	/* 0x148b: lea    rdi,[rax+r12*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_148f:
	/* 0x148f: add    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_1493:
	/* 0x1493: and    r14d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_149a:
	/* 0x149a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_149f:
	/* 0x149f: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_14a4:
	/* 0x14a4: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_14a7:
	/* 0x14a7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_14aa:
	/* 0x14aa: call   14af <filter_char_buf_equal+0x20d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_14af:
	/* 0x14af: mov    DWORD PTR [rsp+0x4],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_14b4:
	/* 0x14b4: cmp    r15d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 4ULL);
x86_l_14b8:
	/* 0x14b8: jle    14f4 <filter_char_buf_equal+0x252> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x14b8, 0x14f4, x86_l_14f4);
x86_l_14ba:
	/* 0x14ba: cmp    r15d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 7ULL);
x86_l_14be:
	/* 0x14be: jg     152e <filter_char_buf_equal+0x28c> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x14be, 0x152e, x86_l_152e);
x86_l_14c0:
	/* 0x14c0: cmp    r15d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 5ULL);
x86_l_14c4:
	/* 0x14c4: je     15e6 <filter_char_buf_equal+0x344> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14c4, 0x15e6, x86_l_15e6);
x86_l_14ca:
	/* 0x14ca: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_14ce:
	/* 0x14ce: je     15ad <filter_char_buf_equal+0x30b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14ce, 0x15ad, x86_l_15ad);
x86_l_14d4:
	/* 0x14d4: cmp    r15d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 7ULL);
x86_l_14d8:
	/* 0x14d8: jne    163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14d8, 0x163e, x86_l_163e);
x86_l_14de:
	/* 0x14de: mov    rdi,QWORD PTR [rip+0x20a0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_7));
x86_l_14e5:
	/* 0x14e5: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_14ea:
	/* 0x14ea: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_14ef:
	/* 0x14ef: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x14ef, 0x160a, x86_l_160a);
x86_l_14f4:
	/* 0x14f4: cmp    r15d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 1ULL);
x86_l_14f8:
	/* 0x14f8: jle    1562 <filter_char_buf_equal+0x2c0> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x14f8, 0x1562, x86_l_1562);
x86_l_14fa:
	/* 0x14fa: cmp    r15d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 2ULL);
x86_l_14fe:
	/* 0x14fe: je     15d3 <filter_char_buf_equal+0x331> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14fe, 0x15d3, x86_l_15d3);
x86_l_1504:
	/* 0x1504: cmp    r15d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 3ULL);
x86_l_1508:
	/* 0x1508: je     159a <filter_char_buf_equal+0x2f8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1508, 0x159a, x86_l_159a);
x86_l_150e:
	/* 0x150e: cmp    r15d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 4ULL);
x86_l_1512:
	/* 0x1512: jne    163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1512, 0x163e, x86_l_163e);
x86_l_1518:
	/* 0x1518: mov    rdi,QWORD PTR [rip+0x20a0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_4));
x86_l_151f:
	/* 0x151f: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1524:
	/* 0x1524: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1529:
	/* 0x1529: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1529, 0x160a, x86_l_160a);
x86_l_152e:
	/* 0x152e: cmp    r15d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 8ULL);
x86_l_1532:
	/* 0x1532: je     15f9 <filter_char_buf_equal+0x357> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1532, 0x15f9, x86_l_15f9);
x86_l_1538:
	/* 0x1538: cmp    r15d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 9ULL);
x86_l_153c:
	/* 0x153c: je     15c0 <filter_char_buf_equal+0x31e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x153c, 0x15c0, x86_l_15c0);
x86_l_1542:
	/* 0x1542: cmp    r15d,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 10ULL);
x86_l_1546:
	/* 0x1546: jne    163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1546, 0x163e, x86_l_163e);
x86_l_154c:
	/* 0x154c: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_10));
x86_l_1553:
	/* 0x1553: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1558:
	/* 0x1558: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_155d:
	/* 0x155d: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x155d, 0x160a, x86_l_160a);
x86_l_1562:
	/* 0x1562: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_1565:
	/* 0x1565: je     1587 <filter_char_buf_equal+0x2e5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1565, 0x1587, x86_l_1587);
x86_l_1567:
	/* 0x1567: cmp    r15d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 1ULL);
x86_l_156b:
	/* 0x156b: jne    163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x156b, 0x163e, x86_l_163e);
x86_l_1571:
	/* 0x1571: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_1));
x86_l_1578:
	/* 0x1578: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_157d:
	/* 0x157d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1582:
	/* 0x1582: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1582, 0x160a, x86_l_160a);
x86_l_1587:
	/* 0x1587: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_0));
x86_l_158e:
	/* 0x158e: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1593:
	/* 0x1593: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1598:
	/* 0x1598: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x1598, 0x160a, x86_l_160a);
x86_l_159a:
	/* 0x159a: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_3));
x86_l_15a1:
	/* 0x15a1: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15a6:
	/* 0x15a6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15ab:
	/* 0x15ab: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x15ab, 0x160a, x86_l_160a);
x86_l_15ad:
	/* 0x15ad: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_6));
x86_l_15b4:
	/* 0x15b4: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15b9:
	/* 0x15b9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15be:
	/* 0x15be: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x15be, 0x160a, x86_l_160a);
x86_l_15c0:
	/* 0x15c0: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_9));
x86_l_15c7:
	/* 0x15c7: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15cc:
	/* 0x15cc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15d1:
	/* 0x15d1: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x15d1, 0x160a, x86_l_160a);
x86_l_15d3:
	/* 0x15d3: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_2));
x86_l_15da:
	/* 0x15da: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15df:
	/* 0x15df: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15e4:
	/* 0x15e4: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x15e4, 0x160a, x86_l_160a);
x86_l_15e6:
	/* 0x15e6: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_5));
x86_l_15ed:
	/* 0x15ed: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15f2:
	/* 0x15f2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15f7:
	/* 0x15f7: jmp    160a <filter_char_buf_equal+0x368> */
	X86_SIM_X86_SUB_JMP(0x15f7, 0x160a, x86_l_160a);
x86_l_15f9:
	/* 0x15f9: mov    rdi,QWORD PTR [rip+0x209c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)string_maps_8));
x86_l_1600:
	/* 0x1600: lea    rcx,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1605:
	/* 0x1605: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_160a:
	/* 0x160a: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_160f:
	/* 0x160f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1612:
	/* 0x1612: call   1617 <filter_char_buf_equal+0x375> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1617:
	/* 0x1617: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_161a:
	/* 0x161a: je     163e <filter_char_buf_equal+0x39c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x161a, 0x163e, x86_l_163e);
x86_l_161c:
	/* 0x161c: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_161f:
	/* 0x161f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1624:
	/* 0x1624: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1629:
	/* 0x1629: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_162c:
	/* 0x162c: call   1631 <filter_char_buf_equal+0x38f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1631:
	/* 0x1631: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1634:
	/* 0x1634: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1636:
	/* 0x1636: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_1639:
	/* 0x1639: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_163c:
	/* 0x163c: jmp    1640 <filter_char_buf_equal+0x39e> */
	X86_SIM_X86_SUB_JMP(0x163c, 0x1640, x86_l_1640);
x86_l_163e:
	/* 0x163e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1640:
	/* 0x1640: add    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1644:
	/* 0x1644: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1645:
	/* 0x1645: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1647:
	/* 0x1647: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1649:
	/* 0x1649: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_164b:
	/* 0x164b: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_164d:
	/* 0x164d: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_164e:
	/* 0x164e: jmp    1653 <filter_char_substring> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1653 */
x86_l_1653:
	/* 0x1653: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1654:
	/* 0x1654: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1656:
	/* 0x1656: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1658:
	/* 0x1658: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_165a:
	/* 0x165a: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_165c:
	/* 0x165c: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_165d:
	/* 0x165d: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_165e:
	/* 0x165e: mov    r15,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RSI, X86_WIDTH_64);
x86_l_1661:
	/* 0x1661: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_1664:
	/* 0x1664: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_1666:
	/* 0x1666: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1668:
	/* 0x1668: je     1736 <filter_char_substring+0xe3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1668, 0x1736, x86_l_1736);
x86_l_166e:
	/* 0x166e: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_1670:
	/* 0x1670: je     17d9 <filter_char_substring+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1670, 0x17d9, x86_l_17d9);
x86_l_1676:
	/* 0x1676: lea    r13,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_167b:
	/* 0x167b: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_167d:
	/* 0x167d: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1680:
	/* 0x1680: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_1685:
	/* 0x1685: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1689:
	/* 0x1689: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_168e:
	/* 0x168e: mov    rdi,QWORD PTR [rip+0x2743] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)substring_map));
x86_l_1695:
	/* 0x1695: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_1698:
	/* 0x1698: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_169b:
	/* 0x169b: call   16a0 <filter_char_substring+0x4d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16a0:
	/* 0x16a0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16a3:
	/* 0x16a3: je     1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16a3, 0x1869, x86_l_1869);
x86_l_16a9:
	/* 0x16a9: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_16ac:
	/* 0x16ac: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16ae:
	/* 0x16ae: jmp    16bb <filter_char_substring+0x68> */
	X86_SIM_X86_SUB_JMP(0x16ae, 0x16bb, x86_l_16bb);
x86_l_16b0:
	/* 0x16b0: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16b3:
	/* 0x16b3: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16b6:
	/* 0x16b6: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_16b9:
	/* 0x16b9: je     1711 <filter_char_substring+0xbe> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16b9, 0x1711, x86_l_1711);
x86_l_16bb:
	/* 0x16bb: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16bd:
	/* 0x16bd: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_16c1:
	/* 0x16c1: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_16c4:
	/* 0x16c4: jae    16b0 <filter_char_substring+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x16c4, 0x16b0, x86_l_16b0);
x86_l_16c6:
	/* 0x16c6: movsx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_16ca:
	/* 0x16ca: test   edi,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32);
x86_l_16cc:
	/* 0x16cc: je     1709 <filter_char_substring+0xb6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16cc, 0x1709, x86_l_1709);
x86_l_16ce:
	/* 0x16ce: movsx  r9d,BYTE PTR [rdx+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_16d3:
	/* 0x16d3: lea    r10d,[r9-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_16d7:
	/* 0x16d7: mov    r8d,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R9, X86_WIDTH_32);
x86_l_16da:
	/* 0x16da: or     r8d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_16de:
	/* 0x16de: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_16e2:
	/* 0x16e2: cmovae r8d,r9d */
	X86_SIM_L_EXEC_CMOV(X86_R8, X86_R9, X86_WIDTH_32, X86_CC_AE);
x86_l_16e6:
	/* 0x16e6: lea    r10d,[rdi-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_16ea:
	/* 0x16ea: mov    r9d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RDI, X86_WIDTH_32);
x86_l_16ed:
	/* 0x16ed: or     r9d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_16f1:
	/* 0x16f1: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_16f5:
	/* 0x16f5: cmovae r9d,edi */
	X86_SIM_L_EXEC_CMOV(X86_R9, X86_RDI, X86_WIDTH_32, X86_CC_AE);
x86_l_16f9:
	/* 0x16f9: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_16fd:
	/* 0x16fd: ja     16b0 <filter_char_substring+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x16fd, 0x16b0, x86_l_16b0);
x86_l_16ff:
	/* 0x16ff: inc    rsi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1702:
	/* 0x1702: cmp    r8d,r9d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_R9, X86_WIDTH_32);
x86_l_1705:
	/* 0x1705: je     16bd <filter_char_substring+0x6a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1705, 0x16bd, x86_l_16bd);
x86_l_1707:
	/* 0x1707: jmp    16b0 <filter_char_substring+0x5d> */
	X86_SIM_X86_SUB_JMP(0x1707, 0x16b0, x86_l_16b0);
x86_l_1709:
	/* 0x1709: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_170b:
	/* 0x170b: jns    187e <filter_char_substring+0x22b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x170b, 0x187e, x86_l_187e);
x86_l_1711:
	/* 0x1711: lea    eax,[r12+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1716:
	/* 0x1716: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_171a:
	/* 0x171a: jae    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x171a, 0x1869, x86_l_1869);
x86_l_1720:
	/* 0x1720: add    r12d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_1724:
	/* 0x1724: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1727:
	/* 0x1727: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_172b:
	/* 0x172b: jne    1680 <filter_char_substring+0x2d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x172b, 0x1680, x86_l_1680);
x86_l_1731:
	/* 0x1731: jmp    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JMP(0x1731, 0x1869, x86_l_1869);
x86_l_1736:
	/* 0x1736: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_1738:
	/* 0x1738: je     1822 <filter_char_substring+0x1cf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1738, 0x1822, x86_l_1822);
x86_l_173e:
	/* 0x173e: lea    r13,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1743:
	/* 0x1743: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1745:
	/* 0x1745: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1748:
	/* 0x1748: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_174d:
	/* 0x174d: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1751:
	/* 0x1751: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1756:
	/* 0x1756: mov    rdi,QWORD PTR [rip+0x274b] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)substring_map));
x86_l_175d:
	/* 0x175d: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_1760:
	/* 0x1760: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1763:
	/* 0x1763: call   1768 <filter_char_substring+0x115> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1768:
	/* 0x1768: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_176b:
	/* 0x176b: je     1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x176b, 0x1869, x86_l_1869);
x86_l_1771:
	/* 0x1771: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1774:
	/* 0x1774: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1776:
	/* 0x1776: jmp    1783 <filter_char_substring+0x130> */
	X86_SIM_X86_SUB_JMP(0x1776, 0x1783, x86_l_1783);
x86_l_1778:
	/* 0x1778: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_177b:
	/* 0x177b: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_177e:
	/* 0x177e: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_1781:
	/* 0x1781: je     17b4 <filter_char_substring+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1781, 0x17b4, x86_l_17b4);
x86_l_1783:
	/* 0x1783: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1785:
	/* 0x1785: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1789:
	/* 0x1789: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_178c:
	/* 0x178c: jae    1778 <filter_char_substring+0x125> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x178c, 0x1778, x86_l_1778);
x86_l_178e:
	/* 0x178e: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1792:
	/* 0x1792: test   dil,dil */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8);
x86_l_1795:
	/* 0x1795: je     17ac <filter_char_substring+0x159> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1795, 0x17ac, x86_l_17ac);
x86_l_1797:
	/* 0x1797: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_179b:
	/* 0x179b: ja     1778 <filter_char_substring+0x125> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x179b, 0x1778, x86_l_1778);
x86_l_179d:
	/* 0x179d: lea    r8,[rsi+0x1] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17a1:
	/* 0x17a1: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_17a5:
	/* 0x17a5: mov    rsi,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R8, X86_WIDTH_64);
x86_l_17a8:
	/* 0x17a8: je     1785 <filter_char_substring+0x132> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17a8, 0x1785, x86_l_1785);
x86_l_17aa:
	/* 0x17aa: jmp    1778 <filter_char_substring+0x125> */
	X86_SIM_X86_SUB_JMP(0x17aa, 0x1778, x86_l_1778);
x86_l_17ac:
	/* 0x17ac: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_17ae:
	/* 0x17ae: jns    187e <filter_char_substring+0x22b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x17ae, 0x187e, x86_l_187e);
x86_l_17b4:
	/* 0x17b4: lea    eax,[r12+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_17b9:
	/* 0x17b9: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_17bd:
	/* 0x17bd: jae    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x17bd, 0x1869, x86_l_1869);
x86_l_17c3:
	/* 0x17c3: add    r12d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_17c7:
	/* 0x17c7: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17ca:
	/* 0x17ca: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_17ce:
	/* 0x17ce: jne    1748 <filter_char_substring+0xf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x17ce, 0x1748, x86_l_1748);
x86_l_17d4:
	/* 0x17d4: jmp    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JMP(0x17d4, 0x1869, x86_l_1869);
x86_l_17d9:
	/* 0x17d9: mov    ebx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 16ULL);
x86_l_17de:
	/* 0x17de: mov    r15,QWORD PTR [rip+0x2757] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, 0, ((__u64)(long)substring_map));
x86_l_17e5:
	/* 0x17e5: lea    r12,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17ea:
	/* 0x17ea: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_17ee:
	/* 0x17ee: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17f2:
	/* 0x17f2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_17f7:
	/* 0x17f7: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_17fa:
	/* 0x17fa: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_17fd:
	/* 0x17fd: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1800:
	/* 0x1800: call   1805 <filter_char_substring+0x1b2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1805:
	/* 0x1805: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1808:
	/* 0x1808: je     1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1808, 0x1869, x86_l_1869);
x86_l_180a:
	/* 0x180a: add    rbx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_180e:
	/* 0x180e: lea    eax,[rbx-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_1811:
	/* 0x1811: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1815:
	/* 0x1815: jae    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1815, 0x1869, x86_l_1869);
x86_l_1817:
	/* 0x1817: cmp    rbx,0x1a0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 416ULL);
x86_l_181e:
	/* 0x181e: jne    17ea <filter_char_substring+0x197> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x181e, 0x17ea, x86_l_17ea);
x86_l_1820:
	/* 0x1820: jmp    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JMP(0x1820, 0x1869, x86_l_1869);
x86_l_1822:
	/* 0x1822: mov    ebx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 16ULL);
x86_l_1827:
	/* 0x1827: mov    r15,QWORD PTR [rip+0x2759] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, 0, ((__u64)(long)substring_map));
x86_l_182e:
	/* 0x182e: lea    r12,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1833:
	/* 0x1833: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1837:
	/* 0x1837: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_183b:
	/* 0x183b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1840:
	/* 0x1840: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1843:
	/* 0x1843: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_1846:
	/* 0x1846: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1849:
	/* 0x1849: call   184e <filter_char_substring+0x1fb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_184e:
	/* 0x184e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1851:
	/* 0x1851: je     1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1851, 0x1869, x86_l_1869);
x86_l_1853:
	/* 0x1853: add    rbx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1857:
	/* 0x1857: lea    eax,[rbx-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_185a:
	/* 0x185a: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_185e:
	/* 0x185e: jae    1869 <filter_char_substring+0x216> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x185e, 0x1869, x86_l_1869);
x86_l_1860:
	/* 0x1860: cmp    rbx,0x1a0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 416ULL);
x86_l_1867:
	/* 0x1867: jne    1833 <filter_char_substring+0x1e0> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1867, 0x1833, x86_l_1833);
x86_l_1869:
	/* 0x1869: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_186b:
	/* 0x186b: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_186f:
	/* 0x186f: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1870:
	/* 0x1870: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1872:
	/* 0x1872: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1874:
	/* 0x1874: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1876:
	/* 0x1876: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1878:
	/* 0x1878: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1879:
	/* 0x1879: jmp    187e <filter_char_substring+0x22b> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_187e:
	/* 0x187e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1883:
	/* 0x1883: jmp    186b <filter_char_substring+0x218> */
	X86_SIM_X86_SUB_JMP(0x1883, 0x186b, x86_l_186b);

	/* native subroutine native_link_sub_1885 */
x86_l_1885:
	/* 0x1885: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1888:
	/* 0x1888: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_188d:
	/* 0x188d: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_1891:
	/* 0x1891: ja     190c <filter_16ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1891, 0x190c, x86_l_190c);
x86_l_1893:
	/* 0x1893: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_189d:
	/* 0x189d: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_18a1:
	/* 0x18a1: jae    18a8 <filter_16ty_selector_val+0x23> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18a1, 0x18a8, x86_l_18a8);
x86_l_18a3:
	/* 0x18a3: jmp    18a8 <filter_16ty_selector_val+0x23> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_18a8:
	/* 0x18a8: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_18ad:
	/* 0x18ad: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_18b1:
	/* 0x18b1: jae    18cc <filter_16ty_selector_val+0x47> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18b1, 0x18cc, x86_l_18cc);
x86_l_18b3:
	/* 0x18b3: movzx  edx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_18b6:
	/* 0x18b6: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18b9:
	/* 0x18b9: jne    19e2 <filter_16ty_selector_val+0x15d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18b9, 0x19e2, x86_l_19e2);
x86_l_18bf:
	/* 0x18bf: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_18c1:
	/* 0x18c1: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_18c4:
	/* 0x18c4: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_18c7:
	/* 0x18c7: jmp    18cc <filter_16ty_selector_val+0x47> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_18cc:
	/* 0x18cc: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_18d0:
	/* 0x18d0: jne    190c <filter_16ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18d0, 0x190c, x86_l_190c);
x86_l_18d2:
	/* 0x18d2: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_18d5:
	/* 0x18d5: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_18d8:
	/* 0x18d8: jne    18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18d8, 0x18a3, x86_l_18a3);
x86_l_18da:
	/* 0x18da: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18dd:
	/* 0x18dd: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_18e0:
	/* 0x18e0: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18e0, 0x1aa4, x86_l_1aa4);
x86_l_18e6:
	/* 0x18e6: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_18e9:
	/* 0x18e9: jne    18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18e9, 0x18a3, x86_l_18a3);
x86_l_18eb:
	/* 0x18eb: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_18ee:
	/* 0x18ee: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18ee, 0x1aa4, x86_l_1aa4);
x86_l_18f4:
	/* 0x18f4: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_18f7:
	/* 0x18f7: jne    18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18f7, 0x18a3, x86_l_18a3);
x86_l_18f9:
	/* 0x18f9: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_18fc:
	/* 0x18fc: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18fc, 0x1aa4, x86_l_1aa4);
x86_l_1902:
	/* 0x1902: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1905:
	/* 0x1905: jne    18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1905, 0x18a3, x86_l_18a3);
x86_l_1907:
	/* 0x1907: jmp    1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x1907, 0x1aa4, x86_l_1aa4);
x86_l_190c:
	/* 0x190c: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_190f:
	/* 0x190f: je     197e <filter_16ty_selector_val+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x190f, 0x197e, x86_l_197e);
x86_l_1911:
	/* 0x1911: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1914:
	/* 0x1914: jne    1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1914, 0x1aa4, x86_l_1aa4);
x86_l_191a:
	/* 0x191a: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_191d:
	/* 0x191d: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1920:
	/* 0x1920: ja     1a6b <filter_16ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1920, 0x1a6b, x86_l_1a6b);
x86_l_1926:
	/* 0x1926: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_192b:
	/* 0x192b: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_192e:
	/* 0x192e: jae    1a6b <filter_16ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x192e, 0x1a6b, x86_l_1a6b);
x86_l_1934:
	/* 0x1934: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1937:
	/* 0x1937: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_193a:
	/* 0x193a: jg     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x193a, 0x18a3, x86_l_18a3);
x86_l_1940:
	/* 0x1940: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1943:
	/* 0x1943: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1946:
	/* 0x1946: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1946, 0x1aa4, x86_l_1aa4);
x86_l_194c:
	/* 0x194c: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_194f:
	/* 0x194f: jg     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x194f, 0x18a3, x86_l_18a3);
x86_l_1955:
	/* 0x1955: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1958:
	/* 0x1958: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1958, 0x1aa4, x86_l_1aa4);
x86_l_195e:
	/* 0x195e: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1961:
	/* 0x1961: jg     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1961, 0x18a3, x86_l_18a3);
x86_l_1967:
	/* 0x1967: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_196a:
	/* 0x196a: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x196a, 0x1aa4, x86_l_1aa4);
x86_l_1970:
	/* 0x1970: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1973:
	/* 0x1973: jg     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1973, 0x18a3, x86_l_18a3);
x86_l_1979:
	/* 0x1979: jmp    1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x1979, 0x1aa4, x86_l_1aa4);
x86_l_197e:
	/* 0x197e: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1981:
	/* 0x1981: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1984:
	/* 0x1984: ja     1a30 <filter_16ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1984, 0x1a30, x86_l_1a30);
x86_l_198a:
	/* 0x198a: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_198f:
	/* 0x198f: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1992:
	/* 0x1992: jae    1a30 <filter_16ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1992, 0x1a30, x86_l_1a30);
x86_l_1998:
	/* 0x1998: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_199b:
	/* 0x199b: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_199e:
	/* 0x199e: jl     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x199e, 0x18a3, x86_l_18a3);
x86_l_19a4:
	/* 0x19a4: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19a7:
	/* 0x19a7: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_19aa:
	/* 0x19aa: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19aa, 0x1aa4, x86_l_1aa4);
x86_l_19b0:
	/* 0x19b0: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19b3:
	/* 0x19b3: jl     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19b3, 0x18a3, x86_l_18a3);
x86_l_19b9:
	/* 0x19b9: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_19bc:
	/* 0x19bc: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19bc, 0x1aa4, x86_l_1aa4);
x86_l_19c2:
	/* 0x19c2: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19c5:
	/* 0x19c5: jl     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19c5, 0x18a3, x86_l_18a3);
x86_l_19cb:
	/* 0x19cb: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_19ce:
	/* 0x19ce: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19ce, 0x1aa4, x86_l_1aa4);
x86_l_19d4:
	/* 0x19d4: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_19d7:
	/* 0x19d7: jl     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19d7, 0x18a3, x86_l_18a3);
x86_l_19dd:
	/* 0x19dd: jmp    1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x19dd, 0x1aa4, x86_l_1aa4);
x86_l_19e2:
	/* 0x19e2: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19e5:
	/* 0x19e5: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_19e8:
	/* 0x19e8: jb     1a0f <filter_16ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19e8, 0x1a0f, x86_l_1a0f);
x86_l_19ea:
	/* 0x19ea: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19ed:
	/* 0x19ed: je     18bf <filter_16ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x19ed, 0x18bf, x86_l_18bf);
x86_l_19f3:
	/* 0x19f3: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_19f6:
	/* 0x19f6: jb     1a0f <filter_16ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19f6, 0x1a0f, x86_l_1a0f);
x86_l_19f8:
	/* 0x19f8: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19fb:
	/* 0x19fb: je     18bf <filter_16ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x19fb, 0x18bf, x86_l_18bf);
x86_l_1a01:
	/* 0x1a01: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_1a04:
	/* 0x1a04: jb     1a0f <filter_16ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a04, 0x1a0f, x86_l_1a0f);
x86_l_1a06:
	/* 0x1a06: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a09:
	/* 0x1a09: je     18bf <filter_16ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a09, 0x18bf, x86_l_18bf);
x86_l_1a0f:
	/* 0x1a0f: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_1a12:
	/* 0x1a12: ja     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a12, 0x1aa4, x86_l_1aa4);
x86_l_1a18:
	/* 0x1a18: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1a1a:
	/* 0x1a1a: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_1a24:
	/* 0x1a24: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1a28:
	/* 0x1a28: jb     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a28, 0x18a3, x86_l_18a3);
x86_l_1a2e:
	/* 0x1a2e: jmp    1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x1a2e, 0x1aa4, x86_l_1aa4);
x86_l_1a30:
	/* 0x1a30: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a33:
	/* 0x1a33: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a36:
	/* 0x1a36: jb     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a36, 0x18a3, x86_l_18a3);
x86_l_1a3c:
	/* 0x1a3c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a3f:
	/* 0x1a3f: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1a42:
	/* 0x1a42: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a42, 0x1aa4, x86_l_1aa4);
x86_l_1a44:
	/* 0x1a44: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a47:
	/* 0x1a47: jb     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a47, 0x18a3, x86_l_18a3);
x86_l_1a4d:
	/* 0x1a4d: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1a50:
	/* 0x1a50: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a50, 0x1aa4, x86_l_1aa4);
x86_l_1a52:
	/* 0x1a52: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a55:
	/* 0x1a55: jb     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a55, 0x18a3, x86_l_18a3);
x86_l_1a5b:
	/* 0x1a5b: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1a5e:
	/* 0x1a5e: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a5e, 0x1aa4, x86_l_1aa4);
x86_l_1a60:
	/* 0x1a60: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a63:
	/* 0x1a63: jb     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a63, 0x18a3, x86_l_18a3);
x86_l_1a69:
	/* 0x1a69: jmp    1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x1a69, 0x1aa4, x86_l_1aa4);
x86_l_1a6b:
	/* 0x1a6b: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a6e:
	/* 0x1a6e: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a71:
	/* 0x1a71: ja     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a71, 0x18a3, x86_l_18a3);
x86_l_1a77:
	/* 0x1a77: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a7a:
	/* 0x1a7a: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1a7d:
	/* 0x1a7d: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a7d, 0x1aa4, x86_l_1aa4);
x86_l_1a7f:
	/* 0x1a7f: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a82:
	/* 0x1a82: ja     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a82, 0x18a3, x86_l_18a3);
x86_l_1a88:
	/* 0x1a88: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1a8b:
	/* 0x1a8b: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a8b, 0x1aa4, x86_l_1aa4);
x86_l_1a8d:
	/* 0x1a8d: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a90:
	/* 0x1a90: ja     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a90, 0x18a3, x86_l_18a3);
x86_l_1a96:
	/* 0x1a96: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1a99:
	/* 0x1a99: jb     1aa4 <filter_16ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a99, 0x1aa4, x86_l_1aa4);
x86_l_1a9b:
	/* 0x1a9b: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a9e:
	/* 0x1a9e: ja     18a3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a9e, 0x18a3, x86_l_18a3);
x86_l_1aa4:
	/* 0x1aa4: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1aa6:
	/* 0x1aa6: jmp    1aab <filter_16ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1aab */
x86_l_1aab:
	/* 0x1aab: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1aae:
	/* 0x1aae: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1ab1:
	/* 0x1ab1: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1ab4:
	/* 0x1ab4: ja     1b9b <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ab4, 0x1b9b, x86_l_1b9b);
x86_l_1aba:
	/* 0x1aba: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1abf:
	/* 0x1abf: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1ac2:
	/* 0x1ac2: jae    1b9b <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1ac2, 0x1b9b, x86_l_1b9b);
x86_l_1ac8:
	/* 0x1ac8: movsx  esi,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1acb:
	/* 0x1acb: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1ace:
	/* 0x1ace: jne    1b36 <filter_16ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1ace, 0x1b36, x86_l_1b36);
x86_l_1ad0:
	/* 0x1ad0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ad5:
	/* 0x1ad5: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ad8:
	/* 0x1ad8: jg     1ae3 <filter_16ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1ad8, 0x1ae3, x86_l_1ae3);
x86_l_1ada:
	/* 0x1ada: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1add:
	/* 0x1add: jge    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1add, 0x1bb2, x86_l_1bb2);
x86_l_1ae3:
	/* 0x1ae3: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ae6:
	/* 0x1ae6: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1ae9:
	/* 0x1ae9: jb     1c56 <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ae9, 0x1c56, x86_l_1c56);
x86_l_1aef:
	/* 0x1aef: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1af2:
	/* 0x1af2: jg     1afd <filter_16ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1af2, 0x1afd, x86_l_1afd);
x86_l_1af4:
	/* 0x1af4: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1af7:
	/* 0x1af7: jge    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1af7, 0x1bb2, x86_l_1bb2);
x86_l_1afd:
	/* 0x1afd: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1b00:
	/* 0x1b00: jb     1c56 <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b00, 0x1c56, x86_l_1c56);
x86_l_1b06:
	/* 0x1b06: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b09:
	/* 0x1b09: jg     1b14 <filter_16ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b09, 0x1b14, x86_l_1b14);
x86_l_1b0b:
	/* 0x1b0b: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b0e:
	/* 0x1b0e: jge    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b0e, 0x1bb2, x86_l_1bb2);
x86_l_1b14:
	/* 0x1b14: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1b17:
	/* 0x1b17: jb     1c56 <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b17, 0x1c56, x86_l_1c56);
x86_l_1b1d:
	/* 0x1b1d: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1b1f:
	/* 0x1b1f: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b22:
	/* 0x1b22: jg     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b22, 0x1c58, x86_l_1c58);
x86_l_1b28:
	/* 0x1b28: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1b2b:
	/* 0x1b2b: jge    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b2b, 0x1bb2, x86_l_1bb2);
x86_l_1b31:
	/* 0x1b31: jmp    1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x1b31, 0x1c58, x86_l_1c58);
x86_l_1b36:
	/* 0x1b36: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b39:
	/* 0x1b39: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b3c:
	/* 0x1b3c: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1b40:
	/* 0x1b40: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b43:
	/* 0x1b43: setge  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_GE);
x86_l_1b46:
	/* 0x1b46: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b49:
	/* 0x1b49: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1b4c:
	/* 0x1b4c: jb     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b4c, 0x1c58, x86_l_1c58);
x86_l_1b52:
	/* 0x1b52: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b55:
	/* 0x1b55: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1b59:
	/* 0x1b59: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b5c:
	/* 0x1b5c: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_1b60:
	/* 0x1b60: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b63:
	/* 0x1b63: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1b66:
	/* 0x1b66: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1b69:
	/* 0x1b69: jb     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b69, 0x1c58, x86_l_1c58);
x86_l_1b6f:
	/* 0x1b6f: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b72:
	/* 0x1b72: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1b76:
	/* 0x1b76: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b79:
	/* 0x1b79: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_1b7d:
	/* 0x1b7d: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b80:
	/* 0x1b80: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1b83:
	/* 0x1b83: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1b86:
	/* 0x1b86: jb     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b86, 0x1c58, x86_l_1c58);
x86_l_1b8c:
	/* 0x1b8c: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b8f:
	/* 0x1b8f: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_1b92:
	/* 0x1b92: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1b95:
	/* 0x1b95: setge  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_GE);
x86_l_1b99:
	/* 0x1b99: jmp    1c12 <filter_16ty_range+0x167> */
	X86_SIM_X86_SUB_JMP(0x1b99, 0x1c12, x86_l_1c12);
x86_l_1b9b:
	/* 0x1b9b: movzx  esi,WORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1b9e:
	/* 0x1b9e: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1ba1:
	/* 0x1ba1: jne    1bb7 <filter_16ty_range+0x10c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1ba1, 0x1bb7, x86_l_1bb7);
x86_l_1ba3:
	/* 0x1ba3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ba8:
	/* 0x1ba8: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bab:
	/* 0x1bab: ja     1c1a <filter_16ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bab, 0x1c1a, x86_l_1c1a);
x86_l_1bad:
	/* 0x1bad: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1bb0:
	/* 0x1bb0: jb     1c1a <filter_16ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bb0, 0x1c1a, x86_l_1c1a);
x86_l_1bb2:
	/* 0x1bb2: jmp    1bb7 <filter_16ty_range+0x10c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1bb7:
	/* 0x1bb7: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bba:
	/* 0x1bba: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bbd:
	/* 0x1bbd: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1bc1:
	/* 0x1bc1: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1bc4:
	/* 0x1bc4: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_1bc7:
	/* 0x1bc7: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1bca:
	/* 0x1bca: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1bcd:
	/* 0x1bcd: jb     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bcd, 0x1c58, x86_l_1c58);
x86_l_1bd3:
	/* 0x1bd3: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bd6:
	/* 0x1bd6: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1bda:
	/* 0x1bda: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1bdd:
	/* 0x1bdd: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_1be1:
	/* 0x1be1: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1be4:
	/* 0x1be4: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1be7:
	/* 0x1be7: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1bea:
	/* 0x1bea: jb     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bea, 0x1c58, x86_l_1c58);
x86_l_1bec:
	/* 0x1bec: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bef:
	/* 0x1bef: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1bf3:
	/* 0x1bf3: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1bf6:
	/* 0x1bf6: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_1bfa:
	/* 0x1bfa: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1bfd:
	/* 0x1bfd: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1c00:
	/* 0x1c00: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1c03:
	/* 0x1c03: jb     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c03, 0x1c58, x86_l_1c58);
x86_l_1c05:
	/* 0x1c05: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c08:
	/* 0x1c08: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_1c0b:
	/* 0x1c0b: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1c0e:
	/* 0x1c0e: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_1c12:
	/* 0x1c12: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1c15:
	/* 0x1c15: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_1c18:
	/* 0x1c18: jmp    1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x1c18, 0x1c58, x86_l_1c58);
x86_l_1c1a:
	/* 0x1c1a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c1d:
	/* 0x1c1d: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1c20:
	/* 0x1c20: jb     1c56 <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c20, 0x1c56, x86_l_1c56);
x86_l_1c22:
	/* 0x1c22: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c25:
	/* 0x1c25: ja     1c2c <filter_16ty_range+0x181> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c25, 0x1c2c, x86_l_1c2c);
x86_l_1c27:
	/* 0x1c27: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1c2a:
	/* 0x1c2a: jae    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c2a, 0x1bb2, x86_l_1bb2);
x86_l_1c2c:
	/* 0x1c2c: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1c2f:
	/* 0x1c2f: jb     1c56 <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c2f, 0x1c56, x86_l_1c56);
x86_l_1c31:
	/* 0x1c31: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c34:
	/* 0x1c34: ja     1c3f <filter_16ty_range+0x194> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c34, 0x1c3f, x86_l_1c3f);
x86_l_1c36:
	/* 0x1c36: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c39:
	/* 0x1c39: jae    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c39, 0x1bb2, x86_l_1bb2);
x86_l_1c3f:
	/* 0x1c3f: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1c42:
	/* 0x1c42: jb     1c56 <filter_16ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c42, 0x1c56, x86_l_1c56);
x86_l_1c44:
	/* 0x1c44: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c46:
	/* 0x1c46: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c49:
	/* 0x1c49: ja     1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c49, 0x1c58, x86_l_1c58);
x86_l_1c4b:
	/* 0x1c4b: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1c4e:
	/* 0x1c4e: jae    1bb2 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c4e, 0x1bb2, x86_l_1bb2);
x86_l_1c54:
	/* 0x1c54: jmp    1c58 <filter_16ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x1c54, 0x1c58, x86_l_1c58);
x86_l_1c56:
	/* 0x1c56: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c58:
	/* 0x1c58: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_1c5b:
	/* 0x1c5b: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1c5e:
	/* 0x1c5e: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_1c61:
	/* 0x1c61: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1c63:
	/* 0x1c63: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1c66:
	/* 0x1c66: jmp    1c6b <filter_16ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1c6b */
x86_l_1c6b:
	/* 0x1c6b: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c6d:
	/* 0x1c6d: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c6e:
	/* 0x1c6e: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1c72:
	/* 0x1c72: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_1c75:
	/* 0x1c75: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_1c78:
	/* 0x1c78: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1c7c:
	/* 0x1c7c: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c80:
	/* 0x1c80: mov    rdi,QWORD PTR [rip+0x1400] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_1c87:
	/* 0x1c87: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c8c:
	/* 0x1c8c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1c91:
	/* 0x1c91: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1c94:
	/* 0x1c94: call   1c99 <filter_16ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c99:
	/* 0x1c99: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1c9c:
	/* 0x1c9c: je     1cd8 <filter_16ty_map+0x6d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c9c, 0x1cd8, x86_l_1cd8);
x86_l_1c9e:
	/* 0x1c9e: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1ca1:
	/* 0x1ca1: movzx  eax,WORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ca5:
	/* 0x1ca5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1caa:
	/* 0x1caa: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1caf:
	/* 0x1caf: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1cb4:
	/* 0x1cb4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1cb7:
	/* 0x1cb7: call   1cbc <filter_16ty_map+0x51> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cbc:
	/* 0x1cbc: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cbf:
	/* 0x1cbf: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1cc1:
	/* 0x1cc1: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_1cc4:
	/* 0x1cc4: ja     1cf6 <filter_16ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1cc4, 0x1cf6, x86_l_1cf6);
x86_l_1cc6:
	/* 0x1cc6: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_1ccb:
	/* 0x1ccb: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1cce:
	/* 0x1cce: jae    1ce6 <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1cce, 0x1ce6, x86_l_1ce6);
x86_l_1cd0:
	/* 0x1cd0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1cd3:
	/* 0x1cd3: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_1cd6:
	/* 0x1cd6: jmp    1cf6 <filter_16ty_map+0x8b> */
	X86_SIM_X86_SUB_JMP(0x1cd6, 0x1cf6, x86_l_1cf6);
x86_l_1cd8:
	/* 0x1cd8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1cda:
	/* 0x1cda: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1cde:
	/* 0x1cde: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1cdf:
	/* 0x1cdf: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ce1:
	/* 0x1ce1: jmp    1ce6 <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1ce6:
	/* 0x1ce6: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_1ceb:
	/* 0x1ceb: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1cee:
	/* 0x1cee: jae    1cf6 <filter_16ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1cee, 0x1cf6, x86_l_1cf6);
x86_l_1cf0:
	/* 0x1cf0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1cf3:
	/* 0x1cf3: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_1cf6:
	/* 0x1cf6: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1cf9:
	/* 0x1cf9: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1cfd:
	/* 0x1cfd: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1cfe:
	/* 0x1cfe: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d00:
	/* 0x1d00: jmp    1d05 <filter_32ty_selector_val> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1d05 */
x86_l_1d05:
	/* 0x1d05: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d08:
	/* 0x1d08: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1d0d:
	/* 0x1d0d: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_1d11:
	/* 0x1d11: ja     1d8a <filter_32ty_selector_val+0x85> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d11, 0x1d8a, x86_l_1d8a);
x86_l_1d13:
	/* 0x1d13: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_1d1d:
	/* 0x1d1d: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1d21:
	/* 0x1d21: jae    1d28 <filter_32ty_selector_val+0x23> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d21, 0x1d28, x86_l_1d28);
x86_l_1d23:
	/* 0x1d23: jmp    1d28 <filter_32ty_selector_val+0x23> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1d28:
	/* 0x1d28: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_1d2d:
	/* 0x1d2d: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1d31:
	/* 0x1d31: jae    1d4b <filter_32ty_selector_val+0x46> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d31, 0x1d4b, x86_l_1d4b);
x86_l_1d33:
	/* 0x1d33: mov    edx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d35:
	/* 0x1d35: cmp    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d38:
	/* 0x1d38: jne    1e5e <filter_32ty_selector_val+0x159> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d38, 0x1e5e, x86_l_1e5e);
x86_l_1d3e:
	/* 0x1d3e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1d40:
	/* 0x1d40: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_1d43:
	/* 0x1d43: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1d46:
	/* 0x1d46: jmp    1d4b <filter_32ty_selector_val+0x46> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1d4b:
	/* 0x1d4b: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_1d4f:
	/* 0x1d4f: jne    1d8a <filter_32ty_selector_val+0x85> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d4f, 0x1d8a, x86_l_1d8a);
x86_l_1d51:
	/* 0x1d51: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d53:
	/* 0x1d53: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1d56:
	/* 0x1d56: jne    1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d56, 0x1d23, x86_l_1d23);
x86_l_1d58:
	/* 0x1d58: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d5b:
	/* 0x1d5b: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1d5e:
	/* 0x1d5e: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d5e, 0x1f1e, x86_l_1f1e);
x86_l_1d64:
	/* 0x1d64: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1d67:
	/* 0x1d67: jne    1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d67, 0x1d23, x86_l_1d23);
x86_l_1d69:
	/* 0x1d69: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1d6c:
	/* 0x1d6c: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d6c, 0x1f1e, x86_l_1f1e);
x86_l_1d72:
	/* 0x1d72: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1d75:
	/* 0x1d75: jne    1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d75, 0x1d23, x86_l_1d23);
x86_l_1d77:
	/* 0x1d77: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1d7a:
	/* 0x1d7a: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d7a, 0x1f1e, x86_l_1f1e);
x86_l_1d80:
	/* 0x1d80: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1d83:
	/* 0x1d83: jne    1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d83, 0x1d23, x86_l_1d23);
x86_l_1d85:
	/* 0x1d85: jmp    1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1d85, 0x1f1e, x86_l_1f1e);
x86_l_1d8a:
	/* 0x1d8a: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1d8d:
	/* 0x1d8d: je     1dfb <filter_32ty_selector_val+0xf6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1d8d, 0x1dfb, x86_l_1dfb);
x86_l_1d8f:
	/* 0x1d8f: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1d92:
	/* 0x1d92: jne    1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d92, 0x1f1e, x86_l_1f1e);
x86_l_1d98:
	/* 0x1d98: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d9b:
	/* 0x1d9b: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1d9e:
	/* 0x1d9e: ja     1ee6 <filter_32ty_selector_val+0x1e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d9e, 0x1ee6, x86_l_1ee6);
x86_l_1da4:
	/* 0x1da4: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1da9:
	/* 0x1da9: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1dac:
	/* 0x1dac: jae    1ee6 <filter_32ty_selector_val+0x1e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1dac, 0x1ee6, x86_l_1ee6);
x86_l_1db2:
	/* 0x1db2: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1db4:
	/* 0x1db4: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1db7:
	/* 0x1db7: jl     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1db7, 0x1d23, x86_l_1d23);
x86_l_1dbd:
	/* 0x1dbd: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dc0:
	/* 0x1dc0: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1dc3:
	/* 0x1dc3: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1dc3, 0x1f1e, x86_l_1f1e);
x86_l_1dc9:
	/* 0x1dc9: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1dcc:
	/* 0x1dcc: jl     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1dcc, 0x1d23, x86_l_1d23);
x86_l_1dd2:
	/* 0x1dd2: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1dd5:
	/* 0x1dd5: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1dd5, 0x1f1e, x86_l_1f1e);
x86_l_1ddb:
	/* 0x1ddb: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1dde:
	/* 0x1dde: jl     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1dde, 0x1d23, x86_l_1d23);
x86_l_1de4:
	/* 0x1de4: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1de7:
	/* 0x1de7: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1de7, 0x1f1e, x86_l_1f1e);
x86_l_1ded:
	/* 0x1ded: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1df0:
	/* 0x1df0: jl     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1df0, 0x1d23, x86_l_1d23);
x86_l_1df6:
	/* 0x1df6: jmp    1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1df6, 0x1f1e, x86_l_1f1e);
x86_l_1dfb:
	/* 0x1dfb: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1dfe:
	/* 0x1dfe: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1e01:
	/* 0x1e01: ja     1eac <filter_32ty_selector_val+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e01, 0x1eac, x86_l_1eac);
x86_l_1e07:
	/* 0x1e07: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1e0c:
	/* 0x1e0c: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1e0f:
	/* 0x1e0f: jae    1eac <filter_32ty_selector_val+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1e0f, 0x1eac, x86_l_1eac);
x86_l_1e15:
	/* 0x1e15: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e17:
	/* 0x1e17: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1e1a:
	/* 0x1e1a: jg     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e1a, 0x1d23, x86_l_1d23);
x86_l_1e20:
	/* 0x1e20: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e23:
	/* 0x1e23: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1e26:
	/* 0x1e26: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e26, 0x1f1e, x86_l_1f1e);
x86_l_1e2c:
	/* 0x1e2c: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e2f:
	/* 0x1e2f: jg     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e2f, 0x1d23, x86_l_1d23);
x86_l_1e35:
	/* 0x1e35: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1e38:
	/* 0x1e38: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e38, 0x1f1e, x86_l_1f1e);
x86_l_1e3e:
	/* 0x1e3e: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e41:
	/* 0x1e41: jg     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e41, 0x1d23, x86_l_1d23);
x86_l_1e47:
	/* 0x1e47: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1e4a:
	/* 0x1e4a: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e4a, 0x1f1e, x86_l_1f1e);
x86_l_1e50:
	/* 0x1e50: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e53:
	/* 0x1e53: jg     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e53, 0x1d23, x86_l_1d23);
x86_l_1e59:
	/* 0x1e59: jmp    1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1e59, 0x1f1e, x86_l_1f1e);
x86_l_1e5e:
	/* 0x1e5e: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e61:
	/* 0x1e61: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_1e64:
	/* 0x1e64: jb     1e8b <filter_32ty_selector_val+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e64, 0x1e8b, x86_l_1e8b);
x86_l_1e66:
	/* 0x1e66: cmp    edx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e69:
	/* 0x1e69: je     1d3e <filter_32ty_selector_val+0x39> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e69, 0x1d3e, x86_l_1d3e);
x86_l_1e6f:
	/* 0x1e6f: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_1e72:
	/* 0x1e72: jb     1e8b <filter_32ty_selector_val+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e72, 0x1e8b, x86_l_1e8b);
x86_l_1e74:
	/* 0x1e74: cmp    edx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e77:
	/* 0x1e77: je     1d3e <filter_32ty_selector_val+0x39> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e77, 0x1d3e, x86_l_1d3e);
x86_l_1e7d:
	/* 0x1e7d: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_1e80:
	/* 0x1e80: jb     1e8b <filter_32ty_selector_val+0x186> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e80, 0x1e8b, x86_l_1e8b);
x86_l_1e82:
	/* 0x1e82: cmp    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e85:
	/* 0x1e85: je     1d3e <filter_32ty_selector_val+0x39> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e85, 0x1d3e, x86_l_1d3e);
x86_l_1e8b:
	/* 0x1e8b: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_1e8e:
	/* 0x1e8e: ja     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e8e, 0x1f1e, x86_l_1f1e);
x86_l_1e94:
	/* 0x1e94: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1e96:
	/* 0x1e96: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_1ea0:
	/* 0x1ea0: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1ea4:
	/* 0x1ea4: jb     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ea4, 0x1d23, x86_l_1d23);
x86_l_1eaa:
	/* 0x1eaa: jmp    1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1eaa, 0x1f1e, x86_l_1f1e);
x86_l_1eac:
	/* 0x1eac: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eae:
	/* 0x1eae: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1eb1:
	/* 0x1eb1: ja     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1eb1, 0x1d23, x86_l_1d23);
x86_l_1eb7:
	/* 0x1eb7: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eba:
	/* 0x1eba: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1ebd:
	/* 0x1ebd: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ebd, 0x1f1e, x86_l_1f1e);
x86_l_1ebf:
	/* 0x1ebf: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ec2:
	/* 0x1ec2: ja     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ec2, 0x1d23, x86_l_1d23);
x86_l_1ec8:
	/* 0x1ec8: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1ecb:
	/* 0x1ecb: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ecb, 0x1f1e, x86_l_1f1e);
x86_l_1ecd:
	/* 0x1ecd: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1ed0:
	/* 0x1ed0: ja     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ed0, 0x1d23, x86_l_1d23);
x86_l_1ed6:
	/* 0x1ed6: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1ed9:
	/* 0x1ed9: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ed9, 0x1f1e, x86_l_1f1e);
x86_l_1edb:
	/* 0x1edb: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1ede:
	/* 0x1ede: ja     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ede, 0x1d23, x86_l_1d23);
x86_l_1ee4:
	/* 0x1ee4: jmp    1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JMP(0x1ee4, 0x1f1e, x86_l_1f1e);
x86_l_1ee6:
	/* 0x1ee6: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee8:
	/* 0x1ee8: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1eeb:
	/* 0x1eeb: jb     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eeb, 0x1d23, x86_l_1d23);
x86_l_1ef1:
	/* 0x1ef1: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ef4:
	/* 0x1ef4: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1ef7:
	/* 0x1ef7: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ef7, 0x1f1e, x86_l_1f1e);
x86_l_1ef9:
	/* 0x1ef9: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1efc:
	/* 0x1efc: jb     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1efc, 0x1d23, x86_l_1d23);
x86_l_1f02:
	/* 0x1f02: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1f05:
	/* 0x1f05: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f05, 0x1f1e, x86_l_1f1e);
x86_l_1f07:
	/* 0x1f07: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1f0a:
	/* 0x1f0a: jb     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f0a, 0x1d23, x86_l_1d23);
x86_l_1f10:
	/* 0x1f10: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1f13:
	/* 0x1f13: jb     1f1e <filter_32ty_selector_val+0x219> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f13, 0x1f1e, x86_l_1f1e);
x86_l_1f15:
	/* 0x1f15: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f18:
	/* 0x1f18: jb     1d23 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f18, 0x1d23, x86_l_1d23);
x86_l_1f1e:
	/* 0x1f1e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f20:
	/* 0x1f20: jmp    1f25 <filter_32ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1f25 */
x86_l_1f25:
	/* 0x1f25: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1f28:
	/* 0x1f28: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1f2b:
	/* 0x1f2b: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1f2e:
	/* 0x1f2e: ja     2014 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f2e, 0x2014, x86_l_2014);
x86_l_1f34:
	/* 0x1f34: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1f39:
	/* 0x1f39: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1f3c:
	/* 0x1f3c: jae    2014 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1f3c, 0x2014, x86_l_2014);
x86_l_1f42:
	/* 0x1f42: mov    esi,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f44:
	/* 0x1f44: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1f47:
	/* 0x1f47: jne    1faf <filter_32ty_range+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1f47, 0x1faf, x86_l_1faf);
x86_l_1f49:
	/* 0x1f49: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1f4e:
	/* 0x1f4e: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f51:
	/* 0x1f51: jg     1f5c <filter_32ty_range+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f51, 0x1f5c, x86_l_1f5c);
x86_l_1f53:
	/* 0x1f53: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f56:
	/* 0x1f56: jle    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f56, 0x202a, x86_l_202a);
x86_l_1f5c:
	/* 0x1f5c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f5f:
	/* 0x1f5f: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1f62:
	/* 0x1f62: jb     20ce <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f62, 0x20ce, x86_l_20ce);
x86_l_1f68:
	/* 0x1f68: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f6b:
	/* 0x1f6b: jg     1f76 <filter_32ty_range+0x51> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f6b, 0x1f76, x86_l_1f76);
x86_l_1f6d:
	/* 0x1f6d: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f70:
	/* 0x1f70: jle    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f70, 0x202a, x86_l_202a);
x86_l_1f76:
	/* 0x1f76: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1f79:
	/* 0x1f79: jb     20ce <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f79, 0x20ce, x86_l_20ce);
x86_l_1f7f:
	/* 0x1f7f: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f82:
	/* 0x1f82: jg     1f8d <filter_32ty_range+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f82, 0x1f8d, x86_l_1f8d);
x86_l_1f84:
	/* 0x1f84: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1f87:
	/* 0x1f87: jle    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f87, 0x202a, x86_l_202a);
x86_l_1f8d:
	/* 0x1f8d: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1f90:
	/* 0x1f90: jb     20ce <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f90, 0x20ce, x86_l_20ce);
x86_l_1f96:
	/* 0x1f96: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f98:
	/* 0x1f98: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f9b:
	/* 0x1f9b: jg     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f9b, 0x20d0, x86_l_20d0);
x86_l_1fa1:
	/* 0x1fa1: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1fa4:
	/* 0x1fa4: jle    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1fa4, 0x202a, x86_l_202a);
x86_l_1faa:
	/* 0x1faa: jmp    20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JMP(0x1faa, 0x20d0, x86_l_20d0);
x86_l_1faf:
	/* 0x1faf: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fb2:
	/* 0x1fb2: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fb5:
	/* 0x1fb5: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1fb9:
	/* 0x1fb9: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1fbc:
	/* 0x1fbc: setle  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_LE);
x86_l_1fbf:
	/* 0x1fbf: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1fc2:
	/* 0x1fc2: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1fc5:
	/* 0x1fc5: jb     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fc5, 0x20d0, x86_l_20d0);
x86_l_1fcb:
	/* 0x1fcb: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1fce:
	/* 0x1fce: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1fd2:
	/* 0x1fd2: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1fd5:
	/* 0x1fd5: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_1fd9:
	/* 0x1fd9: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1fdc:
	/* 0x1fdc: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1fdf:
	/* 0x1fdf: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1fe2:
	/* 0x1fe2: jb     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fe2, 0x20d0, x86_l_20d0);
x86_l_1fe8:
	/* 0x1fe8: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1feb:
	/* 0x1feb: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1fef:
	/* 0x1fef: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1ff2:
	/* 0x1ff2: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_1ff6:
	/* 0x1ff6: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1ff9:
	/* 0x1ff9: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1ffc:
	/* 0x1ffc: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1fff:
	/* 0x1fff: jb     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fff, 0x20d0, x86_l_20d0);
x86_l_2005:
	/* 0x2005: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2008:
	/* 0x2008: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_200b:
	/* 0x200b: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_200e:
	/* 0x200e: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_2012:
	/* 0x2012: jmp    208a <filter_32ty_range+0x165> */
	X86_SIM_X86_SUB_JMP(0x2012, 0x208a, x86_l_208a);
x86_l_2014:
	/* 0x2014: mov    esi,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2016:
	/* 0x2016: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_2019:
	/* 0x2019: jne    202f <filter_32ty_range+0x10a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2019, 0x202f, x86_l_202f);
x86_l_201b:
	/* 0x201b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2020:
	/* 0x2020: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2023:
	/* 0x2023: ja     2092 <filter_32ty_range+0x16d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2023, 0x2092, x86_l_2092);
x86_l_2025:
	/* 0x2025: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2028:
	/* 0x2028: ja     2092 <filter_32ty_range+0x16d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2028, 0x2092, x86_l_2092);
x86_l_202a:
	/* 0x202a: jmp    202f <filter_32ty_range+0x10a> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_202f:
	/* 0x202f: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2032:
	/* 0x2032: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2035:
	/* 0x2035: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2039:
	/* 0x2039: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_203c:
	/* 0x203c: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_203f:
	/* 0x203f: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2042:
	/* 0x2042: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_2045:
	/* 0x2045: jb     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2045, 0x20d0, x86_l_20d0);
x86_l_204b:
	/* 0x204b: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_204e:
	/* 0x204e: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2052:
	/* 0x2052: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_2055:
	/* 0x2055: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_2059:
	/* 0x2059: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_205c:
	/* 0x205c: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_205f:
	/* 0x205f: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2062:
	/* 0x2062: jb     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2062, 0x20d0, x86_l_20d0);
x86_l_2064:
	/* 0x2064: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2067:
	/* 0x2067: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_206b:
	/* 0x206b: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_206e:
	/* 0x206e: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_2072:
	/* 0x2072: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2075:
	/* 0x2075: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_2078:
	/* 0x2078: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_207b:
	/* 0x207b: jb     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x207b, 0x20d0, x86_l_20d0);
x86_l_207d:
	/* 0x207d: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2080:
	/* 0x2080: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_2083:
	/* 0x2083: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_2086:
	/* 0x2086: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_208a:
	/* 0x208a: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_208d:
	/* 0x208d: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2090:
	/* 0x2090: jmp    20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JMP(0x2090, 0x20d0, x86_l_20d0);
x86_l_2092:
	/* 0x2092: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2095:
	/* 0x2095: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2098:
	/* 0x2098: jb     20ce <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2098, 0x20ce, x86_l_20ce);
x86_l_209a:
	/* 0x209a: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_209d:
	/* 0x209d: ja     20a4 <filter_32ty_range+0x17f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x209d, 0x20a4, x86_l_20a4);
x86_l_209f:
	/* 0x209f: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_20a2:
	/* 0x20a2: jbe    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x20a2, 0x202a, x86_l_202a);
x86_l_20a4:
	/* 0x20a4: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_20a7:
	/* 0x20a7: jb     20ce <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20a7, 0x20ce, x86_l_20ce);
x86_l_20a9:
	/* 0x20a9: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20ac:
	/* 0x20ac: ja     20b7 <filter_32ty_range+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20ac, 0x20b7, x86_l_20b7);
x86_l_20ae:
	/* 0x20ae: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_20b1:
	/* 0x20b1: jbe    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x20b1, 0x202a, x86_l_202a);
x86_l_20b7:
	/* 0x20b7: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_20ba:
	/* 0x20ba: jb     20ce <filter_32ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20ba, 0x20ce, x86_l_20ce);
x86_l_20bc:
	/* 0x20bc: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20be:
	/* 0x20be: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20c1:
	/* 0x20c1: ja     20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20c1, 0x20d0, x86_l_20d0);
x86_l_20c3:
	/* 0x20c3: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_20c6:
	/* 0x20c6: jbe    202a <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x20c6, 0x202a, x86_l_202a);
x86_l_20cc:
	/* 0x20cc: jmp    20d0 <filter_32ty_range+0x1ab> */
	X86_SIM_X86_SUB_JMP(0x20cc, 0x20d0, x86_l_20d0);
x86_l_20ce:
	/* 0x20ce: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20d0:
	/* 0x20d0: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_20d3:
	/* 0x20d3: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_20d6:
	/* 0x20d6: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_20d9:
	/* 0x20d9: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_20db:
	/* 0x20db: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_20de:
	/* 0x20de: jmp    20e3 <filter_32ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_20e3 */
x86_l_20e3:
	/* 0x20e3: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_20e5:
	/* 0x20e5: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20e6:
	/* 0x20e6: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_20ea:
	/* 0x20ea: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_20ed:
	/* 0x20ed: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_20f0:
	/* 0x20f0: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_20f4:
	/* 0x20f4: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_20f8:
	/* 0x20f8: mov    rdi,QWORD PTR [rip+0xf70] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_20ff:
	/* 0x20ff: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2104:
	/* 0x2104: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2109:
	/* 0x2109: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_210c:
	/* 0x210c: call   2111 <filter_32ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2111:
	/* 0x2111: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2114:
	/* 0x2114: je     214f <filter_32ty_map+0x6c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2114, 0x214f, x86_l_214f);
x86_l_2116:
	/* 0x2116: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2119:
	/* 0x2119: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_211c:
	/* 0x211c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2121:
	/* 0x2121: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2126:
	/* 0x2126: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_212b:
	/* 0x212b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_212e:
	/* 0x212e: call   2133 <filter_32ty_map+0x50> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2133:
	/* 0x2133: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2136:
	/* 0x2136: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2138:
	/* 0x2138: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_213b:
	/* 0x213b: ja     216d <filter_32ty_map+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x213b, 0x216d, x86_l_216d);
x86_l_213d:
	/* 0x213d: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_2142:
	/* 0x2142: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_2145:
	/* 0x2145: jae    215d <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2145, 0x215d, x86_l_215d);
x86_l_2147:
	/* 0x2147: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_214a:
	/* 0x214a: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_214d:
	/* 0x214d: jmp    216d <filter_32ty_map+0x8a> */
	X86_SIM_X86_SUB_JMP(0x214d, 0x216d, x86_l_216d);
x86_l_214f:
	/* 0x214f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2151:
	/* 0x2151: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2155:
	/* 0x2155: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2156:
	/* 0x2156: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2158:
	/* 0x2158: jmp    215d <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_215d:
	/* 0x215d: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_2162:
	/* 0x2162: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_2165:
	/* 0x2165: jae    216d <filter_32ty_map+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2165, 0x216d, x86_l_216d);
x86_l_2167:
	/* 0x2167: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_216a:
	/* 0x216a: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_216d:
	/* 0x216d: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_2170:
	/* 0x2170: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2174:
	/* 0x2174: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2175:
	/* 0x2175: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2177:
	/* 0x2177: jmp    217c <filter_8ty_selector_val> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_217c */
x86_l_217c:
	/* 0x217c: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_217f:
	/* 0x217f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2184:
	/* 0x2184: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_2188:
	/* 0x2188: ja     2203 <filter_8ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2188, 0x2203, x86_l_2203);
x86_l_218a:
	/* 0x218a: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_2194:
	/* 0x2194: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_2198:
	/* 0x2198: jae    219f <filter_8ty_selector_val+0x23> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2198, 0x219f, x86_l_219f);
x86_l_219a:
	/* 0x219a: jmp    219f <filter_8ty_selector_val+0x23> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_219f:
	/* 0x219f: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_21a4:
	/* 0x21a4: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_21a8:
	/* 0x21a8: jae    21c3 <filter_8ty_selector_val+0x47> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x21a8, 0x21c3, x86_l_21c3);
x86_l_21aa:
	/* 0x21aa: movzx  edx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21ad:
	/* 0x21ad: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21b0:
	/* 0x21b0: jne    22d9 <filter_8ty_selector_val+0x15d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21b0, 0x22d9, x86_l_22d9);
x86_l_21b6:
	/* 0x21b6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_21b8:
	/* 0x21b8: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_21bb:
	/* 0x21bb: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_21be:
	/* 0x21be: jmp    21c3 <filter_8ty_selector_val+0x47> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_21c3:
	/* 0x21c3: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_21c7:
	/* 0x21c7: jne    2203 <filter_8ty_selector_val+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21c7, 0x2203, x86_l_2203);
x86_l_21c9:
	/* 0x21c9: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21cc:
	/* 0x21cc: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_21cf:
	/* 0x21cf: jne    219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21cf, 0x219a, x86_l_219a);
x86_l_21d1:
	/* 0x21d1: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21d4:
	/* 0x21d4: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_21d7:
	/* 0x21d7: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21d7, 0x239b, x86_l_239b);
x86_l_21dd:
	/* 0x21dd: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_21e0:
	/* 0x21e0: jne    219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21e0, 0x219a, x86_l_219a);
x86_l_21e2:
	/* 0x21e2: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_21e5:
	/* 0x21e5: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21e5, 0x239b, x86_l_239b);
x86_l_21eb:
	/* 0x21eb: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_21ee:
	/* 0x21ee: jne    219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21ee, 0x219a, x86_l_219a);
x86_l_21f0:
	/* 0x21f0: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_21f3:
	/* 0x21f3: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21f3, 0x239b, x86_l_239b);
x86_l_21f9:
	/* 0x21f9: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_21fc:
	/* 0x21fc: jne    219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21fc, 0x219a, x86_l_219a);
x86_l_21fe:
	/* 0x21fe: jmp    239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x21fe, 0x239b, x86_l_239b);
x86_l_2203:
	/* 0x2203: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_2206:
	/* 0x2206: je     2275 <filter_8ty_selector_val+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2206, 0x2275, x86_l_2275);
x86_l_2208:
	/* 0x2208: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_220b:
	/* 0x220b: jne    239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x220b, 0x239b, x86_l_239b);
x86_l_2211:
	/* 0x2211: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2214:
	/* 0x2214: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2217:
	/* 0x2217: ja     2362 <filter_8ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2217, 0x2362, x86_l_2362);
x86_l_221d:
	/* 0x221d: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_2222:
	/* 0x2222: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2225:
	/* 0x2225: jae    2362 <filter_8ty_selector_val+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2225, 0x2362, x86_l_2362);
x86_l_222b:
	/* 0x222b: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_222e:
	/* 0x222e: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2231:
	/* 0x2231: jg     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2231, 0x219a, x86_l_219a);
x86_l_2237:
	/* 0x2237: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_223a:
	/* 0x223a: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_223d:
	/* 0x223d: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x223d, 0x239b, x86_l_239b);
x86_l_2243:
	/* 0x2243: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2246:
	/* 0x2246: jg     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2246, 0x219a, x86_l_219a);
x86_l_224c:
	/* 0x224c: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_224f:
	/* 0x224f: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x224f, 0x239b, x86_l_239b);
x86_l_2255:
	/* 0x2255: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2258:
	/* 0x2258: jg     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2258, 0x219a, x86_l_219a);
x86_l_225e:
	/* 0x225e: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2261:
	/* 0x2261: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2261, 0x239b, x86_l_239b);
x86_l_2267:
	/* 0x2267: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_226a:
	/* 0x226a: jg     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x226a, 0x219a, x86_l_219a);
x86_l_2270:
	/* 0x2270: jmp    239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x2270, 0x239b, x86_l_239b);
x86_l_2275:
	/* 0x2275: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2278:
	/* 0x2278: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_227b:
	/* 0x227b: ja     2327 <filter_8ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x227b, 0x2327, x86_l_2327);
x86_l_2281:
	/* 0x2281: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_2286:
	/* 0x2286: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2289:
	/* 0x2289: jae    2327 <filter_8ty_selector_val+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2289, 0x2327, x86_l_2327);
x86_l_228f:
	/* 0x228f: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2292:
	/* 0x2292: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2295:
	/* 0x2295: jl     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2295, 0x219a, x86_l_219a);
x86_l_229b:
	/* 0x229b: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_229e:
	/* 0x229e: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_22a1:
	/* 0x22a1: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22a1, 0x239b, x86_l_239b);
x86_l_22a7:
	/* 0x22a7: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_22aa:
	/* 0x22aa: jl     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x22aa, 0x219a, x86_l_219a);
x86_l_22b0:
	/* 0x22b0: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_22b3:
	/* 0x22b3: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22b3, 0x239b, x86_l_239b);
x86_l_22b9:
	/* 0x22b9: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22bc:
	/* 0x22bc: jl     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x22bc, 0x219a, x86_l_219a);
x86_l_22c2:
	/* 0x22c2: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_22c5:
	/* 0x22c5: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22c5, 0x239b, x86_l_239b);
x86_l_22cb:
	/* 0x22cb: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_22ce:
	/* 0x22ce: jl     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x22ce, 0x219a, x86_l_219a);
x86_l_22d4:
	/* 0x22d4: jmp    239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x22d4, 0x239b, x86_l_239b);
x86_l_22d9:
	/* 0x22d9: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22dc:
	/* 0x22dc: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_22df:
	/* 0x22df: jb     2306 <filter_8ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22df, 0x2306, x86_l_2306);
x86_l_22e1:
	/* 0x22e1: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_22e4:
	/* 0x22e4: je     21b6 <filter_8ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22e4, 0x21b6, x86_l_21b6);
x86_l_22ea:
	/* 0x22ea: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_22ed:
	/* 0x22ed: jb     2306 <filter_8ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22ed, 0x2306, x86_l_2306);
x86_l_22ef:
	/* 0x22ef: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22f2:
	/* 0x22f2: je     21b6 <filter_8ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22f2, 0x21b6, x86_l_21b6);
x86_l_22f8:
	/* 0x22f8: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_22fb:
	/* 0x22fb: jb     2306 <filter_8ty_selector_val+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22fb, 0x2306, x86_l_2306);
x86_l_22fd:
	/* 0x22fd: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2300:
	/* 0x2300: je     21b6 <filter_8ty_selector_val+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2300, 0x21b6, x86_l_21b6);
x86_l_2306:
	/* 0x2306: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_2309:
	/* 0x2309: ja     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2309, 0x239b, x86_l_239b);
x86_l_230f:
	/* 0x230f: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_2311:
	/* 0x2311: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_231b:
	/* 0x231b: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_231f:
	/* 0x231f: jb     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x231f, 0x219a, x86_l_219a);
x86_l_2325:
	/* 0x2325: jmp    239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x2325, 0x239b, x86_l_239b);
x86_l_2327:
	/* 0x2327: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_232a:
	/* 0x232a: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_232d:
	/* 0x232d: jb     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x232d, 0x219a, x86_l_219a);
x86_l_2333:
	/* 0x2333: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2336:
	/* 0x2336: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2339:
	/* 0x2339: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2339, 0x239b, x86_l_239b);
x86_l_233b:
	/* 0x233b: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_233e:
	/* 0x233e: jb     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x233e, 0x219a, x86_l_219a);
x86_l_2344:
	/* 0x2344: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2347:
	/* 0x2347: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2347, 0x239b, x86_l_239b);
x86_l_2349:
	/* 0x2349: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_234c:
	/* 0x234c: jb     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x234c, 0x219a, x86_l_219a);
x86_l_2352:
	/* 0x2352: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2355:
	/* 0x2355: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2355, 0x239b, x86_l_239b);
x86_l_2357:
	/* 0x2357: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_235a:
	/* 0x235a: jb     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x235a, 0x219a, x86_l_219a);
x86_l_2360:
	/* 0x2360: jmp    239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JMP(0x2360, 0x239b, x86_l_239b);
x86_l_2362:
	/* 0x2362: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2365:
	/* 0x2365: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2368:
	/* 0x2368: ja     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2368, 0x219a, x86_l_219a);
x86_l_236e:
	/* 0x236e: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2371:
	/* 0x2371: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2374:
	/* 0x2374: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2374, 0x239b, x86_l_239b);
x86_l_2376:
	/* 0x2376: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2379:
	/* 0x2379: ja     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2379, 0x219a, x86_l_219a);
x86_l_237f:
	/* 0x237f: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2382:
	/* 0x2382: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2382, 0x239b, x86_l_239b);
x86_l_2384:
	/* 0x2384: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2387:
	/* 0x2387: ja     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2387, 0x219a, x86_l_219a);
x86_l_238d:
	/* 0x238d: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2390:
	/* 0x2390: jb     239b <filter_8ty_selector_val+0x21f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2390, 0x239b, x86_l_239b);
x86_l_2392:
	/* 0x2392: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2395:
	/* 0x2395: ja     219a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2395, 0x219a, x86_l_219a);
x86_l_239b:
	/* 0x239b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_239d:
	/* 0x239d: jmp    23a2 <filter_8ty_range> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_23a2 */
x86_l_23a2:
	/* 0x23a2: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23a5:
	/* 0x23a5: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_23a8:
	/* 0x23a8: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_23ab:
	/* 0x23ab: ja     2492 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x23ab, 0x2492, x86_l_2492);
x86_l_23b1:
	/* 0x23b1: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_23b6:
	/* 0x23b6: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_23b9:
	/* 0x23b9: jae    2492 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x23b9, 0x2492, x86_l_2492);
x86_l_23bf:
	/* 0x23bf: movsx  esi,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_23c2:
	/* 0x23c2: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_23c5:
	/* 0x23c5: jne    242d <filter_8ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x23c5, 0x242d, x86_l_242d);
x86_l_23c7:
	/* 0x23c7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_23cc:
	/* 0x23cc: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23cf:
	/* 0x23cf: jg     23da <filter_8ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23cf, 0x23da, x86_l_23da);
x86_l_23d1:
	/* 0x23d1: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_23d4:
	/* 0x23d4: jge    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23d4, 0x24a9, x86_l_24a9);
x86_l_23da:
	/* 0x23da: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23dd:
	/* 0x23dd: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_23e0:
	/* 0x23e0: jb     254d <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23e0, 0x254d, x86_l_254d);
x86_l_23e6:
	/* 0x23e6: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23e9:
	/* 0x23e9: jg     23f4 <filter_8ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23e9, 0x23f4, x86_l_23f4);
x86_l_23eb:
	/* 0x23eb: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23ee:
	/* 0x23ee: jge    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23ee, 0x24a9, x86_l_24a9);
x86_l_23f4:
	/* 0x23f4: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_23f7:
	/* 0x23f7: jb     254d <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23f7, 0x254d, x86_l_254d);
x86_l_23fd:
	/* 0x23fd: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2400:
	/* 0x2400: jg     240b <filter_8ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2400, 0x240b, x86_l_240b);
x86_l_2402:
	/* 0x2402: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2405:
	/* 0x2405: jge    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2405, 0x24a9, x86_l_24a9);
x86_l_240b:
	/* 0x240b: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_240e:
	/* 0x240e: jb     254d <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x240e, 0x254d, x86_l_254d);
x86_l_2414:
	/* 0x2414: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2416:
	/* 0x2416: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2419:
	/* 0x2419: jg     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2419, 0x254f, x86_l_254f);
x86_l_241f:
	/* 0x241f: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2422:
	/* 0x2422: jge    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2422, 0x24a9, x86_l_24a9);
x86_l_2428:
	/* 0x2428: jmp    254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x2428, 0x254f, x86_l_254f);
x86_l_242d:
	/* 0x242d: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2430:
	/* 0x2430: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2433:
	/* 0x2433: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_2437:
	/* 0x2437: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_243a:
	/* 0x243a: setge  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_GE);
x86_l_243d:
	/* 0x243d: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2440:
	/* 0x2440: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_2443:
	/* 0x2443: jb     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2443, 0x254f, x86_l_254f);
x86_l_2449:
	/* 0x2449: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_244c:
	/* 0x244c: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_2450:
	/* 0x2450: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2453:
	/* 0x2453: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_2457:
	/* 0x2457: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_245a:
	/* 0x245a: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_245d:
	/* 0x245d: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2460:
	/* 0x2460: jb     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2460, 0x254f, x86_l_254f);
x86_l_2466:
	/* 0x2466: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2469:
	/* 0x2469: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_246d:
	/* 0x246d: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2470:
	/* 0x2470: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_2474:
	/* 0x2474: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2477:
	/* 0x2477: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_247a:
	/* 0x247a: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_247d:
	/* 0x247d: jb     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x247d, 0x254f, x86_l_254f);
x86_l_2483:
	/* 0x2483: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2486:
	/* 0x2486: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_2489:
	/* 0x2489: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_248c:
	/* 0x248c: setge  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_GE);
x86_l_2490:
	/* 0x2490: jmp    2509 <filter_8ty_range+0x167> */
	X86_SIM_X86_SUB_JMP(0x2490, 0x2509, x86_l_2509);
x86_l_2492:
	/* 0x2492: movzx  esi,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2495:
	/* 0x2495: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_2498:
	/* 0x2498: jne    24ae <filter_8ty_range+0x10c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2498, 0x24ae, x86_l_24ae);
x86_l_249a:
	/* 0x249a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_249f:
	/* 0x249f: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24a2:
	/* 0x24a2: ja     2511 <filter_8ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24a2, 0x2511, x86_l_2511);
x86_l_24a4:
	/* 0x24a4: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24a7:
	/* 0x24a7: jb     2511 <filter_8ty_range+0x16f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24a7, 0x2511, x86_l_2511);
x86_l_24a9:
	/* 0x24a9: jmp    24ae <filter_8ty_range+0x10c> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_24ae:
	/* 0x24ae: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24b1:
	/* 0x24b1: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24b4:
	/* 0x24b4: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_24b8:
	/* 0x24b8: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24bb:
	/* 0x24bb: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_24be:
	/* 0x24be: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_24c1:
	/* 0x24c1: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_24c4:
	/* 0x24c4: jb     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24c4, 0x254f, x86_l_254f);
x86_l_24ca:
	/* 0x24ca: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24cd:
	/* 0x24cd: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_24d1:
	/* 0x24d1: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24d4:
	/* 0x24d4: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_24d8:
	/* 0x24d8: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_24db:
	/* 0x24db: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_24de:
	/* 0x24de: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_24e1:
	/* 0x24e1: jb     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24e1, 0x254f, x86_l_254f);
x86_l_24e3:
	/* 0x24e3: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24e6:
	/* 0x24e6: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_24ea:
	/* 0x24ea: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_24ed:
	/* 0x24ed: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_24f1:
	/* 0x24f1: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_24f4:
	/* 0x24f4: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_24f7:
	/* 0x24f7: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_24fa:
	/* 0x24fa: jb     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24fa, 0x254f, x86_l_254f);
x86_l_24fc:
	/* 0x24fc: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24ff:
	/* 0x24ff: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_2502:
	/* 0x2502: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2505:
	/* 0x2505: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_2509:
	/* 0x2509: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_250c:
	/* 0x250c: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_250f:
	/* 0x250f: jmp    254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x250f, 0x254f, x86_l_254f);
x86_l_2511:
	/* 0x2511: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2514:
	/* 0x2514: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2517:
	/* 0x2517: jb     254d <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2517, 0x254d, x86_l_254d);
x86_l_2519:
	/* 0x2519: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_251c:
	/* 0x251c: ja     2523 <filter_8ty_range+0x181> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x251c, 0x2523, x86_l_2523);
x86_l_251e:
	/* 0x251e: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2521:
	/* 0x2521: jae    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2521, 0x24a9, x86_l_24a9);
x86_l_2523:
	/* 0x2523: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_2526:
	/* 0x2526: jb     254d <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2526, 0x254d, x86_l_254d);
x86_l_2528:
	/* 0x2528: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_252b:
	/* 0x252b: ja     2536 <filter_8ty_range+0x194> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x252b, 0x2536, x86_l_2536);
x86_l_252d:
	/* 0x252d: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2530:
	/* 0x2530: jae    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2530, 0x24a9, x86_l_24a9);
x86_l_2536:
	/* 0x2536: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_2539:
	/* 0x2539: jb     254d <filter_8ty_range+0x1ab> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2539, 0x254d, x86_l_254d);
x86_l_253b:
	/* 0x253b: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_253d:
	/* 0x253d: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2540:
	/* 0x2540: ja     254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2540, 0x254f, x86_l_254f);
x86_l_2542:
	/* 0x2542: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2545:
	/* 0x2545: jae    24a9 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2545, 0x24a9, x86_l_24a9);
x86_l_254b:
	/* 0x254b: jmp    254f <filter_8ty_range+0x1ad> */
	X86_SIM_X86_SUB_JMP(0x254b, 0x254f, x86_l_254f);
x86_l_254d:
	/* 0x254d: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_254f:
	/* 0x254f: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_2552:
	/* 0x2552: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_2555:
	/* 0x2555: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_2558:
	/* 0x2558: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_255a:
	/* 0x255a: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_255d:
	/* 0x255d: jmp    2562 <filter_8ty_map> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_2562 */
x86_l_2562:
	/* 0x2562: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2564:
	/* 0x2564: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2565:
	/* 0x2565: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_2569:
	/* 0x2569: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_256c:
	/* 0x256c: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_256f:
	/* 0x256f: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_2573:
	/* 0x2573: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2577:
	/* 0x2577: mov    rdi,QWORD PTR [rip+0x1890] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_257e:
	/* 0x257e: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2583:
	/* 0x2583: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2588:
	/* 0x2588: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_258b:
	/* 0x258b: call   2590 <filter_8ty_map+0x2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2590:
	/* 0x2590: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2593:
	/* 0x2593: je     25cf <filter_8ty_map+0x6d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2593, 0x25cf, x86_l_25cf);
x86_l_2595:
	/* 0x2595: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2598:
	/* 0x2598: movzx  eax,BYTE PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_259c:
	/* 0x259c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a1:
	/* 0x25a1: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a6:
	/* 0x25a6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_25ab:
	/* 0x25ab: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_25ae:
	/* 0x25ae: call   25b3 <filter_8ty_map+0x51> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25b3:
	/* 0x25b3: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25b6:
	/* 0x25b6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_25b8:
	/* 0x25b8: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_25bb:
	/* 0x25bb: ja     25ed <filter_8ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x25bb, 0x25ed, x86_l_25ed);
x86_l_25bd:
	/* 0x25bd: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_25c2:
	/* 0x25c2: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_25c5:
	/* 0x25c5: jae    25dd <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x25c5, 0x25dd, x86_l_25dd);
x86_l_25c7:
	/* 0x25c7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_25ca:
	/* 0x25ca: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_25cd:
	/* 0x25cd: jmp    25ed <filter_8ty_map+0x8b> */
	X86_SIM_X86_SUB_JMP(0x25cd, 0x25ed, x86_l_25ed);
x86_l_25cf:
	/* 0x25cf: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_25d1:
	/* 0x25d1: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_25d5:
	/* 0x25d5: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25d6:
	/* 0x25d6: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_25d8:
	/* 0x25d8: jmp    25dd <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_25dd:
	/* 0x25dd: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_25e2:
	/* 0x25e2: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_25e5:
	/* 0x25e5: jae    25ed <filter_8ty_map+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x25e5, 0x25ed, x86_l_25ed);
x86_l_25e7:
	/* 0x25e7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_25ea:
	/* 0x25ea: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_25ed:
	/* 0x25ed: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_25f0:
	/* 0x25f0: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_25f4:
	/* 0x25f4: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25f5:
	/* 0x25f5: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_25f7:
	/* 0x25f7: jmp    25fc <filter_file_type> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_25fc */
x86_l_25fc:
	/* 0x25fc: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25fd:
	/* 0x25fd: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_2601:
	/* 0x2601: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_2608:
	/* 0x2608: mov    eax,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260a:
	/* 0x260a: cmp    rax,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4096ULL);
x86_l_2610:
	/* 0x2610: ja     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2610, 0x26a2, x86_l_26a2);
x86_l_2616:
	/* 0x2616: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_2619:
	/* 0x2619: lea    rcx,[rsi+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_261d:
	/* 0x261d: add    rcx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2621:
	/* 0x2621: lea    rdi,[rsp+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_2626:
	/* 0x2626: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_262b:
	/* 0x262b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2630:
	/* 0x2630: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2632:
	/* 0x2632: lea    rdx,[rsi+rcx*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2636:
	/* 0x2636: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_263a:
	/* 0x263a: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_263f:
	/* 0x263f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2642:
	/* 0x2642: call   2647 <filter_file_type+0x4b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2647:
	/* 0x2647: mov    edx,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_264a:
	/* 0x264a: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_264c:
	/* 0x264c: je     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x264c, 0x26a2, x86_l_26a2);
x86_l_264e:
	/* 0x264e: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2653:
	/* 0x2653: and    ecx,0xf000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_2659:
	/* 0x2659: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_265e:
	/* 0x265e: cmp    edx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2660:
	/* 0x2660: je     26a4 <filter_file_type+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2660, 0x26a4, x86_l_26a4);
x86_l_2662:
	/* 0x2662: mov    edx,DWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2665:
	/* 0x2665: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_2668:
	/* 0x2668: jbe    26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2668, 0x26a2, x86_l_26a2);
x86_l_266a:
	/* 0x266a: mov    esi,DWORD PTR [rbx+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_266d:
	/* 0x266d: test   esi,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32);
x86_l_266f:
	/* 0x266f: je     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x266f, 0x26a2, x86_l_26a2);
x86_l_2671:
	/* 0x2671: cmp    esi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_2673:
	/* 0x2673: je     26a4 <filter_file_type+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2673, 0x26a4, x86_l_26a4);
x86_l_2675:
	/* 0x2675: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2678:
	/* 0x2678: jb     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2678, 0x26a2, x86_l_26a2);
x86_l_267a:
	/* 0x267a: mov    esi,DWORD PTR [rbx+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_267d:
	/* 0x267d: test   esi,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32);
x86_l_267f:
	/* 0x267f: je     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x267f, 0x26a2, x86_l_26a2);
x86_l_2681:
	/* 0x2681: cmp    esi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_2683:
	/* 0x2683: je     26a4 <filter_file_type+0xa8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2683, 0x26a4, x86_l_26a4);
x86_l_2685:
	/* 0x2685: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2688:
	/* 0x2688: jb     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2688, 0x26a2, x86_l_26a2);
x86_l_268a:
	/* 0x268a: mov    edx,DWORD PTR [rbx+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_268d:
	/* 0x268d: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_268f:
	/* 0x268f: je     26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x268f, 0x26a2, x86_l_26a2);
x86_l_2691:
	/* 0x2691: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2693:
	/* 0x2693: cmp    edx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2695:
	/* 0x2695: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_2698:
	/* 0x2698: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_269c:
	/* 0x269c: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_269d:
	/* 0x269d: jmp    26a2 <filter_file_type+0xa6> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_26a2:
	/* 0x26a2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_26a4:
	/* 0x26a4: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_26a8:
	/* 0x26a8: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26a9:
	/* 0x26a9: jmp    26ae <filter_file_type+0xb2> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x236ULL: goto x86_l_236;
	case 0x2c9ULL: goto x86_l_2c9;
	case 0x309ULL: goto x86_l_309;
	case 0x362ULL: goto x86_l_362;
	case 0x369ULL: goto x86_l_369;
	case 0x378ULL: goto x86_l_378;
	case 0x37fULL: goto x86_l_37f;
	case 0x38bULL: goto x86_l_38b;
	case 0x397ULL: goto x86_l_397;
	case 0x548ULL: goto x86_l_548;
	case 0x566ULL: goto x86_l_566;
	case 0x57cULL: goto x86_l_57c;
	case 0x592ULL: goto x86_l_592;
	case 0x5dbULL: goto x86_l_5db;
	case 0x601ULL: goto x86_l_601;
	case 0x60cULL: goto x86_l_60c;
	case 0x934ULL: goto x86_l_934;
	case 0x9a9ULL: goto x86_l_9a9;
	case 0x9f1ULL: goto x86_l_9f1;
	case 0xa29ULL: goto x86_l_a29;
	case 0xa4fULL: goto x86_l_a4f;
	case 0xa75ULL: goto x86_l_a75;
	case 0xa80ULL: goto x86_l_a80;
	case 0xaa2ULL: goto x86_l_aa2;
	case 0xac8ULL: goto x86_l_ac8;
	case 0xad3ULL: goto x86_l_ad3;
	case 0xb21ULL: goto x86_l_b21;
	case 0xb3fULL: goto x86_l_b3f;
	case 0xb49ULL: goto x86_l_b49;
	case 0xb55ULL: goto x86_l_b55;
	case 0xb9cULL: goto x86_l_b9c;
	case 0xbc2ULL: goto x86_l_bc2;
	case 0xbcdULL: goto x86_l_bcd;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
