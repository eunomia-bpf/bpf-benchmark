#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 504U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30) M(31) M(32) M(33) M(34) M(35) M(36) M(37) M(38) M(39) M(40) M(41) M(42) M(43) M(44) M(45) M(46) M(47) M(48) M(49) M(50) M(51) M(52) M(53) M(54) M(55) M(56) M(57) M(58) M(59) M(60) M(61) M(62)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 CONFIG_ITER_NUM[] __ksym;
extern __u8 buffer_heap_map[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 data_heap[] __ksym;
extern __u8 fdinstall_map[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 socktrack_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 tg_ipv6_ext_heap[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
extern __u8 tp_calls[] __ksym;
SEC("raw_tracepoint/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d:
	/* 0xd: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: sub    rsp,0x108 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 264ULL);
x86_l_15:
	/* 0x15: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_18:
	/* 0x18: mov    DWORD PTR [rsp+0xec],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_23:
	/* 0x23: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_2a:
	/* 0x2a: lea    rsi,[rsp+0xec] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236ULL);
x86_l_32:
	/* 0x32: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_37:
	/* 0x37: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3a:
	/* 0x3a: call   3f <generic_rawtp_process_event+0x3f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3f:
	/* 0x3f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_42:
	/* 0x42: je     e34 <generic_rawtp_process_event+0xe34> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42, 0xe34, x86_l_e34);
x86_l_48:
	/* 0x48: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_4b:
	/* 0x4b: mov    r12d,DWORD PTR [rax+0x5efc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24316ULL);
x86_l_52:
	/* 0x52: mov    ebp,DWORD PTR [rax+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_55:
	/* 0x55: cmp    rbp,0x2327 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 8999ULL);
x86_l_5c:
	/* 0x5c: ja     d79 <generic_rawtp_process_event+0xd79> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5c, 0xd79, x86_l_d79);
x86_l_62:
	/* 0x62: mov    DWORD PTR [rsp+0xf0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1030792151040ULL);
x86_l_6d:
	/* 0x6d: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_74:
	/* 0x74: lea    rsi,[rsp+0xf0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_7c:
	/* 0x7c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_81:
	/* 0x81: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_84:
	/* 0x84: call   89 <generic_rawtp_process_event+0x89> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_89:
	/* 0x89: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8c:
	/* 0x8c: je     d79 <generic_rawtp_process_event+0xd79> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c, 0xd79, x86_l_d79);
x86_l_92:
	/* 0x92: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_95:
	/* 0x95: lea    rsi,[rax+0x5ef8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_9c:
	/* 0x9c: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)config_map));
x86_l_a3:
	/* 0xa3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_a8:
	/* 0xa8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_ab:
	/* 0xab: call   b0 <generic_rawtp_process_event+0xb0> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b0:
	/* 0xb0: cmp    r12d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 4ULL);
x86_l_b4:
	/* 0xb4: jg     d79 <generic_rawtp_process_event+0xd79> */
	X86_SIM_X86_JCC(X86_CC_G, 0xb4, 0xd79, x86_l_d79);
x86_l_ba:
	/* 0xba: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_bd:
	/* 0xbd: je     d79 <generic_rawtp_process_event+0xd79> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd, 0xd79, x86_l_d79);
x86_l_c3:
	/* 0xc3: mov    QWORD PTR [rsp+0x18],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c8:
	/* 0xc8: mov    edx,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_32);
x86_l_cb:
	/* 0xcb: and    edx,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_ce:
	/* 0xce: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_d0:
	/* 0xd0: mov    r13d,DWORD PTR [rax+rbp*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 4ULL);
x86_l_d5:
	/* 0xd5: movsxd rsi,DWORD PTR [rax+rbp*4+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_RBP, 2, X86_WIDTH_32), 24ULL);
x86_l_da:
	/* 0xda: mov    ecx,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RSI, X86_WIDTH_32);
x86_l_dc:
	/* 0xdc: mov    DWORD PTR [r15+rbp*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 104041287778304ULL);
x86_l_e8:
	/* 0xe8: test   esi,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RSI, X86_WIDTH_32, 256ULL);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rsp],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f2:
	/* 0xf2: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f7:
	/* 0xf7: mov    QWORD PTR [rsp+0x30],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_fc:
	/* 0xfc: jne    119 <generic_rawtp_process_event+0x119> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfc, 0x119, x86_l_119);
x86_l_fe:
	/* 0xfe: test   cl,cl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8);
x86_l_100:
	/* 0x100: js     12c <generic_rawtp_process_event+0x12c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x100, 0x12c, x86_l_12c);
x86_l_102:
	/* 0x102: test   sil,0x40 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RSI, X86_WIDTH_8, 64ULL);
x86_l_106:
	/* 0x106: jne    13c <generic_rawtp_process_event+0x13c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x106, 0x13c, x86_l_13c);
x86_l_108:
	/* 0x108: mov    ecx,DWORD PTR [rax+rdx*4+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 2), 64ULL);
x86_l_10c:
	/* 0x10c: and    ecx,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_10f:
	/* 0x10f: mov    rsi,QWORD PTR [r15+rcx*8+0x5e50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 3), 24144ULL);
x86_l_117:
	/* 0x117: jmp    166 <generic_rawtp_process_event+0x166> */
	X86_SIM_X86_JMP(0x117, 0x166, x86_l_166);
x86_l_119:
	/* 0x119: mov    QWORD PTR [rsp+0xd8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 927712935936ULL);
x86_l_125:
	/* 0x125: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_127:
	/* 0x127: jmp    26a <generic_rawtp_process_event+0x26a> */
	X86_SIM_X86_JMP(0x127, 0x26a, x86_l_26a);
x86_l_12c:
	/* 0x12c: mov    QWORD PTR [rsp+0xd8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 927712935936ULL);
x86_l_138:
	/* 0x138: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13a:
	/* 0x13a: jmp    16e <generic_rawtp_process_event+0x16e> */
	X86_SIM_X86_JMP(0x13a, 0x16e, x86_l_16e);
x86_l_13c:
	/* 0x13c: mov    QWORD PTR [rsp+0x38],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_141:
	/* 0x141: mov    r12,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBX, X86_WIDTH_64);
x86_l_144:
	/* 0x144: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_147:
	/* 0x147: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_14c:
	/* 0x14c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_14f:
	/* 0x14f: call   154 <generic_rawtp_process_event+0x154> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_154:
	/* 0x154: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158:
	/* 0x158: mov    rsi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_15b:
	/* 0x15b: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_15e:
	/* 0x15e: mov    rbx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R12, X86_WIDTH_64);
x86_l_161:
	/* 0x161: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_166:
	/* 0x166: mov    QWORD PTR [rsp+0xd8],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_16e:
	/* 0x16e: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_171:
	/* 0x171: ja     26a <generic_rawtp_process_event+0x26a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x171, 0x26a, x86_l_26a);
x86_l_177:
	/* 0x177: lea    rcx,[rdx+rdx*4] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 2), 0ULL);
x86_l_17b:
	/* 0x17b: shl    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_17e:
	/* 0x17e: cmp    WORD PTR [rax+rcx*1+0x76],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 506806140928ULL);
x86_l_184:
	/* 0x184: je     26a <generic_rawtp_process_event+0x26a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184, 0x26a, x86_l_26a);
x86_l_18a:
	/* 0x18a: add    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_18d:
	/* 0x18d: add    rax,0x70 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_191:
	/* 0x191: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_196:
	/* 0x196: lea    rax,[rsp+0xd8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_19e:
	/* 0x19e: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1a3:
	/* 0x1a3: mov    BYTE PTR [rsp+0x78],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_1a8:
	/* 0x1a8: lea    rax,[r15+rbp*4] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 2), 0ULL);
x86_l_1ac:
	/* 0x1ac: add    rax,0x5ea0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 24224ULL);
x86_l_1b2:
	/* 0x1b2: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1ba:
	/* 0x1ba: mov    rax,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)CONFIG_ITER_NUM));
x86_l_1c1:
	/* 0x1c1: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c4:
	/* 0x1c4: je     22b <generic_rawtp_process_event+0x22b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4, 0x22b, x86_l_22b);
x86_l_1c6:
	/* 0x1c6: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c9:
	/* 0x1c9: mov    ebp,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 8ULL);
x86_l_1ce:
	/* 0x1ce: jmp    1f7 <generic_rawtp_process_event+0x1f7> */
	X86_SIM_X86_JMP(0x1ce, 0x1f7, x86_l_1f7);
x86_l_1d0:
	/* 0x1d0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d5:
	/* 0x1d5: mov    rdi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1da:
	/* 0x1da: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd:
	/* 0x1dd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1e2:
	/* 0x1e2: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1e5:
	/* 0x1e5: call   1ea <generic_rawtp_process_event+0x1ea> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ea:
	/* 0x1ea: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1ec:
	/* 0x1ec: js     254 <generic_rawtp_process_event+0x254> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ec, 0x254, x86_l_254);
x86_l_1ee:
	/* 0x1ee: inc    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1f1:
	/* 0x1f1: cmp    r15,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_64, 10ULL);
x86_l_1f5:
	/* 0x1f5: je     262 <generic_rawtp_process_event+0x262> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f5, 0x262, x86_l_262);
x86_l_1f7:
	/* 0x1f7: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1fc:
	/* 0x1fc: cmp    WORD PTR [rax+r15*8+0x6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_R15, 3), 25769803776ULL);
x86_l_203:
	/* 0x203: je     262 <generic_rawtp_process_event+0x262> */
	X86_SIM_X86_JCC(X86_CC_E, 0x203, 0x262, x86_l_262);
x86_l_205:
	/* 0x205: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_20a:
	/* 0x20a: mov    edx,DWORD PTR [rax+r15*8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 3), 0ULL);
x86_l_20e:
	/* 0x20e: add    rdx,QWORD PTR [rcx] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_211:
	/* 0x211: mov    QWORD PTR [rcx],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_214:
	/* 0x214: cmp    WORD PTR [rax+r15*8+0x4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_R15, 3), 17179869184ULL);
x86_l_21b:
	/* 0x21b: je     1ee <generic_rawtp_process_event+0x1ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b, 0x1ee, x86_l_1ee);
x86_l_21d:
	/* 0x21d: cmp    BYTE PTR [rsp+0x78],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_222:
	/* 0x222: je     1d0 <generic_rawtp_process_event+0x1d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222, 0x1d0, x86_l_1d0);
x86_l_224:
	/* 0x224: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_229:
	/* 0x229: jmp    1d5 <generic_rawtp_process_event+0x1d5> */
	X86_SIM_X86_JMP(0x229, 0x1d5, x86_l_1d5);
x86_l_22b:
	/* 0x22b: lea    rsi,[rip+0x35a9] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x37dbULL);
x86_l_232:
	/* 0x232: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_234:
	/* 0x234: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_239:
	/* 0x239: mov    edi,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 10ULL);
x86_l_23e:
	/* 0x23e: mov    eax,0xb5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 181ULL);
x86_l_243:
	/* 0x243: mov    edi,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 10ULL);
x86_l_248:
	/* 0x248: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24a:
	/* 0x24a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_24d:
	/* 0x24d: call   252 <generic_rawtp_process_event+0x252> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xb5ULL: X86_SIM_BPF_CALL_bpf_loop(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xb5ULL: X86_SIM_BPF_CALL_bpf_loop(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_252:
	/* 0x252: jmp    262 <generic_rawtp_process_event+0x262> */
	X86_SIM_X86_JMP(0x252, 0x262, x86_l_262);
x86_l_254:
	/* 0x254: inc    r15d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_257:
	/* 0x257: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_25f:
	/* 0x25f: mov    DWORD PTR [rax],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_262:
	/* 0x262: mov    rsi,QWORD PTR [rsp+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_26a:
	/* 0x26a: mov    r15d,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4096ULL);
x86_l_270:
	/* 0x270: cmp    r13d,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 21ULL);
x86_l_274:
	/* 0x274: jg     2b1 <generic_rawtp_process_event+0x2b1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x274, 0x2b1, x86_l_2b1);
x86_l_276:
	/* 0x276: cmp    r13d,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 11ULL);
x86_l_27a:
	/* 0x27a: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_27f:
	/* 0x27f: jg     2ec <generic_rawtp_process_event+0x2ec> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27f, 0x2ec, x86_l_2ec);
x86_l_281:
	/* 0x281: cmp    r13d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 5ULL);
x86_l_285:
	/* 0x285: jg     375 <generic_rawtp_process_event+0x375> */
	X86_SIM_X86_JCC(X86_CC_G, 0x285, 0x375, x86_l_375);
x86_l_28b:
	/* 0x28b: cmp    r13d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 3ULL);
x86_l_28f:
	/* 0x28f: jg     3fe <generic_rawtp_process_event+0x3fe> */
	X86_SIM_X86_JCC(X86_CC_G, 0x28f, 0x3fe, x86_l_3fe);
x86_l_295:
	/* 0x295: lea    eax,[r13-0x2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_299:
	/* 0x299: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_29c:
	/* 0x29c: jb     3c4 <generic_rawtp_process_event+0x3c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x29c, 0x3c4, x86_l_3c4);
x86_l_2a2:
	/* 0x2a2: cmp    r13d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 1ULL);
x86_l_2a6:
	/* 0x2a6: je     3c4 <generic_rawtp_process_event+0x3c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a6, 0x3c4, x86_l_3c4);
x86_l_2ac:
	/* 0x2ac: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x2ac, 0x430, x86_l_430);
x86_l_2b1:
	/* 0x2b1: cmp    r13d,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 32ULL);
x86_l_2b5:
	/* 0x2b5: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ba:
	/* 0x2ba: jle    315 <generic_rawtp_process_event+0x315> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2ba, 0x315, x86_l_315);
x86_l_2bc:
	/* 0x2bc: cmp    r13d,0x27 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 39ULL);
x86_l_2c0:
	/* 0x2c0: jg     342 <generic_rawtp_process_event+0x342> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2c0, 0x342, x86_l_342);
x86_l_2c6:
	/* 0x2c6: lea    eax,[r13-0x21] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551583ULL);
x86_l_2ca:
	/* 0x2ca: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2cd:
	/* 0x2cd: jb     412 <generic_rawtp_process_event+0x412> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2cd, 0x412, x86_l_412);
x86_l_2d3:
	/* 0x2d3: cmp    r13d,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 37ULL);
x86_l_2d7:
	/* 0x2d7: je     433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d7, 0x433, x86_l_433);
x86_l_2dd:
	/* 0x2dd: cmp    r13d,0x27 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 39ULL);
x86_l_2e1:
	/* 0x2e1: je     3cc <generic_rawtp_process_event+0x3cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e1, 0x3cc, x86_l_3cc);
x86_l_2e7:
	/* 0x2e7: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x2e7, 0x430, x86_l_430);
x86_l_2ec:
	/* 0x2ec: cmp    r13d,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 17ULL);
x86_l_2f0:
	/* 0x2f0: jg     39e <generic_rawtp_process_event+0x39e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2f0, 0x39e, x86_l_39e);
x86_l_2f6:
	/* 0x2f6: lea    eax,[r13-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_2fa:
	/* 0x2fa: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_2fd:
	/* 0x2fd: jb     433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2fd, 0x433, x86_l_433);
x86_l_303:
	/* 0x303: lea    eax,[r13-0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_307:
	/* 0x307: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_30a:
	/* 0x30a: jb     3c4 <generic_rawtp_process_event+0x3c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x30a, 0x3c4, x86_l_3c4);
x86_l_310:
	/* 0x310: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x310, 0x430, x86_l_430);
x86_l_315:
	/* 0x315: cmp    r13d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 26ULL);
x86_l_319:
	/* 0x319: jg     3bb <generic_rawtp_process_event+0x3bb> */
	X86_SIM_X86_JCC(X86_CC_G, 0x319, 0x3bb, x86_l_3bb);
x86_l_31f:
	/* 0x31f: cmp    r13d,0x16 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 22ULL);
x86_l_323:
	/* 0x323: je     3cc <generic_rawtp_process_event+0x3cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x323, 0x3cc, x86_l_3cc);
x86_l_329:
	/* 0x329: cmp    r13d,0x17 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 23ULL);
x86_l_32d:
	/* 0x32d: je     412 <generic_rawtp_process_event+0x412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32d, 0x412, x86_l_412);
x86_l_333:
	/* 0x333: cmp    r13d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 26ULL);
x86_l_337:
	/* 0x337: je     428 <generic_rawtp_process_event+0x428> */
	X86_SIM_X86_JCC(X86_CC_E, 0x337, 0x428, x86_l_428);
x86_l_33d:
	/* 0x33d: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x33d, 0x430, x86_l_430);
x86_l_342:
	/* 0x342: cmp    r13d,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 41ULL);
x86_l_346:
	/* 0x346: jle    3e8 <generic_rawtp_process_event+0x3e8> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x346, 0x3e8, x86_l_3e8);
x86_l_34c:
	/* 0x34c: cmp    r13d,0x2a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 42ULL);
x86_l_350:
	/* 0x350: je     433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JCC(X86_CC_E, 0x350, 0x433, x86_l_433);
x86_l_356:
	/* 0x356: cmp    r13d,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 43ULL);
x86_l_35a:
	/* 0x35a: je     3f6 <generic_rawtp_process_event+0x3f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35a, 0x3f6, x86_l_3f6);
x86_l_360:
	/* 0x360: cmp    r13d,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 44ULL);
x86_l_364:
	/* 0x364: jne    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x364, 0x430, x86_l_430);
x86_l_36a:
	/* 0x36a: mov    r15d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 112ULL);
x86_l_370:
	/* 0x370: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x370, 0x433, x86_l_433);
x86_l_375:
	/* 0x375: cmp    r13d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 9ULL);
x86_l_379:
	/* 0x379: jg     412 <generic_rawtp_process_event+0x412> */
	X86_SIM_X86_JCC(X86_CC_G, 0x379, 0x412, x86_l_412);
x86_l_37f:
	/* 0x37f: cmp    r13d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 6ULL);
x86_l_383:
	/* 0x383: je     433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JCC(X86_CC_E, 0x383, 0x433, x86_l_433);
x86_l_389:
	/* 0x389: cmp    r13d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 7ULL);
x86_l_38d:
	/* 0x38d: je     40a <generic_rawtp_process_event+0x40a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38d, 0x40a, x86_l_40a);
x86_l_38f:
	/* 0x38f: cmp    r13d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 8ULL);
x86_l_393:
	/* 0x393: je     428 <generic_rawtp_process_event+0x428> */
	X86_SIM_X86_JCC(X86_CC_E, 0x393, 0x428, x86_l_428);
x86_l_399:
	/* 0x399: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x399, 0x430, x86_l_430);
x86_l_39e:
	/* 0x39e: cmp    r13d,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 19ULL);
x86_l_3a2:
	/* 0x3a2: jg     3d4 <generic_rawtp_process_event+0x3d4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3a2, 0x3d4, x86_l_3d4);
x86_l_3a4:
	/* 0x3a4: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3a9:
	/* 0x3a9: cmp    r13d,0x12 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 18ULL);
x86_l_3ad:
	/* 0x3ad: je     433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ad, 0x433, x86_l_433);
x86_l_3b3:
	/* 0x3b3: cmp    r13d,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 19ULL);
x86_l_3b7:
	/* 0x3b7: je     3f6 <generic_rawtp_process_event+0x3f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b7, 0x3f6, x86_l_3f6);
x86_l_3b9:
	/* 0x3b9: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x3b9, 0x430, x86_l_430);
x86_l_3bb:
	/* 0x3bb: lea    eax,[r13-0x1d] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551587ULL);
x86_l_3bf:
	/* 0x3bf: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3c2:
	/* 0x3c2: jae    422 <generic_rawtp_process_event+0x422> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3c2, 0x422, x86_l_422);
x86_l_3c4:
	/* 0x3c4: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_3ca:
	/* 0x3ca: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x3ca, 0x433, x86_l_433);
x86_l_3cc:
	/* 0x3cc: mov    r15d,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 16ULL);
x86_l_3d2:
	/* 0x3d2: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x3d2, 0x433, x86_l_433);
x86_l_3d4:
	/* 0x3d4: cmp    r13d,0x14 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 20ULL);
x86_l_3d8:
	/* 0x3d8: je     41a <generic_rawtp_process_event+0x41a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d8, 0x41a, x86_l_41a);
x86_l_3da:
	/* 0x3da: cmp    r13d,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 21ULL);
x86_l_3de:
	/* 0x3de: jne    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3de, 0x430, x86_l_430);
x86_l_3e0:
	/* 0x3e0: mov    r15d,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 32ULL);
x86_l_3e6:
	/* 0x3e6: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x3e6, 0x433, x86_l_433);
x86_l_3e8:
	/* 0x3e8: cmp    r13d,0x28 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 40ULL);
x86_l_3ec:
	/* 0x3ec: je     3f6 <generic_rawtp_process_event+0x3f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ec, 0x3f6, x86_l_3f6);
x86_l_3ee:
	/* 0x3ee: cmp    r13d,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 41ULL);
x86_l_3f2:
	/* 0x3f2: je     40a <generic_rawtp_process_event+0x40a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f2, 0x40a, x86_l_40a);
x86_l_3f4:
	/* 0x3f4: jmp    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JMP(0x3f4, 0x430, x86_l_430);
x86_l_3f6:
	/* 0x3f6: mov    r15d,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 24ULL);
x86_l_3fc:
	/* 0x3fc: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x3fc, 0x433, x86_l_433);
x86_l_3fe:
	/* 0x3fe: cmp    r13d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 4ULL);
x86_l_402:
	/* 0x402: je     412 <generic_rawtp_process_event+0x412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x402, 0x412, x86_l_412);
x86_l_404:
	/* 0x404: cmp    r13d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 5ULL);
x86_l_408:
	/* 0x408: jne    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x408, 0x430, x86_l_430);
x86_l_40a:
	/* 0x40a: mov    r15d,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 64ULL);
x86_l_410:
	/* 0x410: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x410, 0x433, x86_l_433);
x86_l_412:
	/* 0x412: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_418:
	/* 0x418: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x418, 0x433, x86_l_433);
x86_l_41a:
	/* 0x41a: mov    r15d,0x98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 152ULL);
x86_l_420:
	/* 0x420: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x420, 0x433, x86_l_433);
x86_l_422:
	/* 0x422: cmp    r13d,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 27ULL);
x86_l_426:
	/* 0x426: jne    430 <generic_rawtp_process_event+0x430> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x426, 0x430, x86_l_430);
x86_l_428:
	/* 0x428: mov    r15d,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 80ULL);
x86_l_42e:
	/* 0x42e: jmp    433 <generic_rawtp_process_event+0x433> */
	X86_SIM_X86_JMP(0x42e, 0x433, x86_l_433);
x86_l_430:
	/* 0x430: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_433:
	/* 0x433: mov    QWORD PTR [rsp+0x20],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_438:
	/* 0x438: mov    DWORD PTR [rsp+0xf4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_443:
	/* 0x443: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_44a:
	/* 0x44a: lea    rsi,[rsp+0xf4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244ULL);
x86_l_452:
	/* 0x452: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_457:
	/* 0x457: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_45a:
	/* 0x45a: call   45f <generic_rawtp_process_event+0x45f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_45f:
	/* 0x45f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_462:
	/* 0x462: je     d79 <generic_rawtp_process_event+0xd79> */
	X86_SIM_X86_JCC(X86_CC_E, 0x462, 0xd79, x86_l_d79);
x86_l_468:
	/* 0x468: mov    ecx,0x3ffb */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16379ULL);
x86_l_46d:
	/* 0x46d: sub    rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_470:
	/* 0x470: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_473:
	/* 0x473: jbe    d79 <generic_rawtp_process_event+0xd79> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x473, 0xd79, x86_l_d79);
x86_l_479:
	/* 0x479: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47d:
	/* 0x47d: mov    ecx,DWORD PTR [rax+rdx*4+0x5ea0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 2), 24224ULL);
x86_l_484:
	/* 0x484: mov    DWORD PTR [rax+rbp*1+0x90],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 144ULL);
x86_l_48b:
	/* 0x48b: lea    r15,[rbp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_48f:
	/* 0x48f: mov    QWORD PTR [rax+rdx*8+0x5e78],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 24184ULL);
x86_l_497:
	/* 0x497: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_49c:
	/* 0x49c: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_49e:
	/* 0x49e: jne    d75 <generic_rawtp_process_event+0xd75> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49e, 0xd75, x86_l_d75);
x86_l_4a4:
	/* 0x4a4: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_4a7:
	/* 0x4a7: add    rbp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_4ae:
	/* 0x4ae: and    r15d,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_4b5:
	/* 0x4b5: add    rbp,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4b8:
	/* 0x4b8: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4bd:
	/* 0x4bd: mov    QWORD PTR [rsp+0x68],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4c2:
	/* 0x4c2: mov    QWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_4ce:
	/* 0x4ce: cmp    r13d,0x17 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 23ULL);
x86_l_4d2:
	/* 0x4d2: mov    QWORD PTR [rsp+0x28],r14 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4d7:
	/* 0x4d7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4dc:
	/* 0x4dc: mov    QWORD PTR [rsp+0x38],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4e1:
	/* 0x4e1: jle    51e <generic_rawtp_process_event+0x51e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4e1, 0x51e, x86_l_51e);
x86_l_4e3:
	/* 0x4e3: cmp    r13d,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 24ULL);
x86_l_4e7:
	/* 0x4e7: je     539 <generic_rawtp_process_event+0x539> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e7, 0x539, x86_l_539);
x86_l_4e9:
	/* 0x4e9: cmp    r13d,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 37ULL);
x86_l_4ed:
	/* 0x4ed: je     57d <generic_rawtp_process_event+0x57d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ed, 0x57d, x86_l_57d);
x86_l_4f3:
	/* 0x4f3: cmp    r13d,0x2a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 42ULL);
x86_l_4f7:
	/* 0x4f7: jne    b3e <generic_rawtp_process_event+0xb3e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f7, 0xb3e, x86_l_b3e);
x86_l_4fd:
	/* 0x4fd: mov    QWORD PTR [rsp+0xf8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1065151889408ULL);
x86_l_509:
	/* 0x509: mov    QWORD PTR [rsp+0x100],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_511:
	/* 0x511: lea    rax,[rsp+0xf8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_519:
	/* 0x519: jmp    5b0 <generic_rawtp_process_event+0x5b0> */
	X86_SIM_X86_JMP(0x519, 0x5b0, x86_l_5b0);
x86_l_51e:
	/* 0x51e: cmp    r13d,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 15ULL);
x86_l_522:
	/* 0x522: je     a5a <generic_rawtp_process_event+0xa5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x522, 0xa5a, x86_l_a5a);
x86_l_528:
	/* 0x528: cmp    r13d,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 16ULL);
x86_l_52c:
	/* 0x52c: jne    b3e <generic_rawtp_process_event+0xb3e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x52c, 0xb3e, x86_l_b3e);
x86_l_532:
	/* 0x532: lea    r15,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_537:
	/* 0x537: jmp    567 <generic_rawtp_process_event+0x567> */
	X86_SIM_X86_JMP(0x537, 0x567, x86_l_567);
x86_l_539:
	/* 0x539: lea    r15,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_53e:
	/* 0x53e: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_543:
	/* 0x543: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_548:
	/* 0x548: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_54d:
	/* 0x54d: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_550:
	/* 0x550: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_555:
	/* 0x555: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_558:
	/* 0x558: call   55d <generic_rawtp_process_event+0x55d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_55d:
	/* 0x55d: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_562:
	/* 0x562: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_567:
	/* 0x567: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_56c:
	/* 0x56c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_571:
	/* 0x571: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_576:
	/* 0x576: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_57b:
	/* 0x57b: jmp    59a <generic_rawtp_process_event+0x59a> */
	X86_SIM_X86_JMP(0x57b, 0x59a, x86_l_59a);
x86_l_57d:
	/* 0x57d: add    rdx,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_581:
	/* 0x581: mov    QWORD PTR [rsp+0x68],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_586:
	/* 0x586: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_58b:
	/* 0x58b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_590:
	/* 0x590: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_595:
	/* 0x595: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_59a:
	/* 0x59a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_59f:
	/* 0x59f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_5a2:
	/* 0x5a2: call   5a7 <generic_rawtp_process_event+0x5a7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5a7:
	/* 0x5a7: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5ac:
	/* 0x5ac: add    rax,0x40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_5b0:
	/* 0x5b0: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5b5:
	/* 0x5b5: mov    DWORD PTR [rsp+0xbc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_5c0:
	/* 0x5c0: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)buffer_heap_map));
x86_l_5c7:
	/* 0x5c7: lea    rsi,[rsp+0xbc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_5cf:
	/* 0x5cf: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5d4:
	/* 0x5d4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_5d7:
	/* 0x5d7: call   5dc <generic_rawtp_process_event+0x5dc> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5dc:
	/* 0x5dc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5df:
	/* 0x5df: je     6a6 <generic_rawtp_process_event+0x6a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5df, 0x6a6, x86_l_6a6);
x86_l_5e5:
	/* 0x5e5: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_5e8:
	/* 0x5e8: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5ed:
	/* 0x5ed: add    rax,0x1000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 4096ULL);
x86_l_5f3:
	/* 0x5f3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f8:
	/* 0x5f8: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_5fd:
	/* 0x5fd: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_600:
	/* 0x600: call   605 <generic_rawtp_process_event+0x605> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_605:
	/* 0x605: lea    rdx,[rax+0xdd8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3544ULL);
x86_l_60c:
	/* 0x60c: lea    rdi,[rsp+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_614:
	/* 0x614: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_619:
	/* 0x619: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_61e:
	/* 0x61e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_623:
	/* 0x623: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_626:
	/* 0x626: call   62b <generic_rawtp_process_event+0x62b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_62b:
	/* 0x62b: mov    r12,QWORD PTR [rsp+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_633:
	/* 0x633: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_638:
	/* 0x638: lea    rdx,[rax+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_63c:
	/* 0x63c: lea    rdi,[rsp+0xc0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_644:
	/* 0x644: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_649:
	/* 0x649: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_64e:
	/* 0x64e: lea    rcx,[r12+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_653:
	/* 0x653: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_658:
	/* 0x658: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_65d:
	/* 0x65d: mov    QWORD PTR [rsp+0x30],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_662:
	/* 0x662: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_665:
	/* 0x665: call   66a <generic_rawtp_process_event+0x66a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_66a:
	/* 0x66a: mov    r15,QWORD PTR [rsp+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_672:
	/* 0x672: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_676:
	/* 0x676: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_67b:
	/* 0x67b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_680:
	/* 0x680: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_685:
	/* 0x685: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_68a:
	/* 0x68a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_68d:
	/* 0x68d: call   692 <generic_rawtp_process_event+0x692> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_692:
	/* 0x692: cmp    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_698:
	/* 0x698: mov    ebp,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4096ULL);
x86_l_69d:
	/* 0x69d: je     6b3 <generic_rawtp_process_event+0x6b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x69d, 0x6b3, x86_l_6b3);
x86_l_69f:
	/* 0x69f: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6a4:
	/* 0x6a4: jmp    709 <generic_rawtp_process_event+0x709> */
	X86_SIM_X86_JMP(0x6a4, 0x709, x86_l_709);
x86_l_6a6:
	/* 0x6a6: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6a9:
	/* 0x6a9: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_6ae:
	/* 0x6ae: jmp    d62 <generic_rawtp_process_event+0xd62> */
	X86_SIM_X86_JMP(0x6ae, 0xd62, x86_l_d62);
x86_l_6b3:
	/* 0x6b3: lea    rdx,[r15+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6b7:
	/* 0x6b7: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_6bc:
	/* 0x6bc: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_6c1:
	/* 0x6c1: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_6c6:
	/* 0x6c6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_6cb:
	/* 0x6cb: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_6ce:
	/* 0x6ce: call   6d3 <generic_rawtp_process_event+0x6d3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6d3:
	/* 0x6d3: cmp    QWORD PTR [rsp+0x68],r15 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_6d8:
	/* 0x6d8: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6dd:
	/* 0x6dd: je     709 <generic_rawtp_process_event+0x709> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6dd, 0x709, x86_l_709);
x86_l_6df:
	/* 0x6df: mov    rcx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R13, X86_WIDTH_64);
x86_l_6e2:
	/* 0x6e2: add    rcx,0xff6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 4086ULL);
x86_l_6e9:
	/* 0x6e9: movabs rax,0x6574656c65642820 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310579611361093664ULL);
x86_l_6f3:
	/* 0x6f3: mov    QWORD PTR [r13+0xff6],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4086ULL);
x86_l_6fa:
	/* 0x6fa: mov    WORD PTR [r13+0xffe],0x2964 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 17583596120420ULL);
x86_l_704:
	/* 0x704: mov    ebp,0xff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4086ULL);
x86_l_709:
	/* 0x709: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_712:
	/* 0x712: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_71b:
	/* 0x71b: mov    QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_720:
	/* 0x720: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_72c:
	/* 0x72c: mov    QWORD PTR [rsp+0x88],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_738:
	/* 0x738: mov    QWORD PTR [rsp+0x90],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_744:
	/* 0x744: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_749:
	/* 0x749: mov    QWORD PTR [rsp+0x98],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_751:
	/* 0x751: mov    DWORD PTR [rsp+0xa0],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_758:
	/* 0x758: mov    BYTE PTR [rsp+0xa4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_760:
	/* 0x760: add    r12,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_764:
	/* 0x764: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_769:
	/* 0x769: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_76e:
	/* 0x76e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_773:
	/* 0x773: lea    r13,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_778:
	/* 0x778: lea    r15,[rsp+0x80] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_780:
	/* 0x780: lea    rbp,[rsp+0x88] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_788:
	/* 0x788: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_78d:
	/* 0x78d: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_790:
	/* 0x790: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_793:
	/* 0x793: call   798 <generic_rawtp_process_event+0x798> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_798:
	/* 0x798: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_79d:
	/* 0x79d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_7a2:
	/* 0x7a2: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7a7:
	/* 0x7a7: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_7aa:
	/* 0x7aa: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_7af:
	/* 0x7af: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_7b2:
	/* 0x7b2: call   7b7 <generic_rawtp_process_event+0x7b7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7b7:
	/* 0x7b7: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_7bc:
	/* 0x7bc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_7c1:
	/* 0x7c1: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7c6:
	/* 0x7c6: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_7c9:
	/* 0x7c9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_7ce:
	/* 0x7ce: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_7d1:
	/* 0x7d1: call   7d6 <generic_rawtp_process_event+0x7d6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7d6:
	/* 0x7d6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_7db:
	/* 0x7db: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_7e0:
	/* 0x7e0: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7e5:
	/* 0x7e5: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_7e8:
	/* 0x7e8: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_7ed:
	/* 0x7ed: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_7f0:
	/* 0x7f0: call   7f5 <generic_rawtp_process_event+0x7f5> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7f5:
	/* 0x7f5: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_7fd:
	/* 0x7fd: add    rax,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_801:
	/* 0x801: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_809:
	/* 0x809: mov    rax,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)CONFIG_ITER_NUM));
x86_l_810:
	/* 0x810: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_813:
	/* 0x813: je     a2e <generic_rawtp_process_event+0xa2e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x813, 0xa2e, x86_l_a2e);
x86_l_819:
	/* 0x819: mov    ebp,0x800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 2048ULL);
x86_l_81e:
	/* 0x81e: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_824:
	/* 0x824: mov    r13,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_82c:
	/* 0x82c: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_834:
	/* 0x834: mov    r12,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_83c:
	/* 0x83c: cmp    r13,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 104ULL);
x86_l_841:
	/* 0x841: jne    84e <generic_rawtp_process_event+0x84e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x841, 0x84e, x86_l_84e);
x86_l_843:
	/* 0x843: cmp    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 112ULL);
x86_l_848:
	/* 0x848: je     c0d <generic_rawtp_process_event+0xc0d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x848, 0xc0d, x86_l_c0d);
x86_l_84e:
	/* 0x84e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_853:
	/* 0x853: lea    rdi,[rsp+0xd0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_85b:
	/* 0x85b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_860:
	/* 0x860: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_863:
	/* 0x863: call   868 <generic_rawtp_process_event+0x868> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_868:
	/* 0x868: cmp    r13,QWORD PTR [rsp+0xd0] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 208ULL);
x86_l_870:
	/* 0x870: mov    r14d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 8ULL);
x86_l_876:
	/* 0x876: je     9ad <generic_rawtp_process_event+0x9ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x876, 0x9ad, x86_l_9ad);
x86_l_87c:
	/* 0x87c: lea    r15,[r13+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_880:
	/* 0x880: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_885:
	/* 0x885: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_88a:
	/* 0x88a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_88f:
	/* 0x88f: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_892:
	/* 0x892: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_895:
	/* 0x895: call   89a <generic_rawtp_process_event+0x89a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_89a:
	/* 0x89a: cmp    QWORD PTR [rsp+0x58],r13 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_89f:
	/* 0x89f: je     9ad <generic_rawtp_process_event+0x9ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x89f, 0x9ad, x86_l_9ad);
x86_l_8a5:
	/* 0x8a5: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_8aa:
	/* 0x8aa: lea    rdi,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_8af:
	/* 0x8af: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_8b4:
	/* 0x8b4: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_8b7:
	/* 0x8b7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_8ba:
	/* 0x8ba: call   8bf <generic_rawtp_process_event+0x8bf> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8bf:
	/* 0x8bf: add    r13,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_8c3:
	/* 0x8c3: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_8c8:
	/* 0x8c8: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_8d0:
	/* 0x8d0: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_8d5:
	/* 0x8d5: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_8da:
	/* 0x8da: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_8dd:
	/* 0x8dd: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_8e0:
	/* 0x8e0: call   8e5 <generic_rawtp_process_event+0x8e5> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8e5:
	/* 0x8e5: mov    r15,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_8ea:
	/* 0x8ea: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_8f2:
	/* 0x8f2: mov    r12d,DWORD PTR [rsp+0xac] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_8fa:
	/* 0x8fa: sub    rax,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_8fd:
	/* 0x8fd: mov    r13d,DWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_905:
	/* 0x905: mov    edx,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_32);
x86_l_908:
	/* 0x908: sub    edx,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R13, X86_WIDTH_32, X86_ALU_SUB);
x86_l_90b:
	/* 0x90b: mov    ecx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 0ULL);
x86_l_910:
	/* 0x910: cmovb  edx,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RCX, X86_WIDTH_32, X86_CC_B);
x86_l_913:
	/* 0x913: add    rdx,QWORD PTR [rsp+0xb0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 176ULL);
x86_l_91b:
	/* 0x91b: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_91d:
	/* 0x91d: cmp    r13d,r12d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_R12, X86_WIDTH_32);
x86_l_920:
	/* 0x920: seta   sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_A);
x86_l_924:
	/* 0x924: mov    ecx,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_32);
x86_l_927:
	/* 0x927: cmovb  ecx,r13d */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_R13, X86_WIDTH_32, X86_CC_B);
x86_l_92b:
	/* 0x92b: add    esi,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RCX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_92d:
	/* 0x92d: mov    edi,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_32);
x86_l_930:
	/* 0x930: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_932:
	/* 0x932: mov    DWORD PTR [rsp+0xa0],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_939:
	/* 0x939: sub    rax,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_SUB);
x86_l_93c:
	/* 0x93c: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_941:
	/* 0x941: jb     c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JCC(X86_CC_B, 0x941, 0xc24, x86_l_c24);
x86_l_947:
	/* 0x947: cmp    rax,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4095ULL);
x86_l_94d:
	/* 0x94d: ja     c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JCC(X86_CC_A, 0x94d, 0xc24, x86_l_c24);
x86_l_953:
	/* 0x953: cmp    r13d,r12d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_R12, X86_WIDTH_32);
x86_l_956:
	/* 0x956: jbe    95d <generic_rawtp_process_event+0x95d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x956, 0x95d, x86_l_95d);
x86_l_958:
	/* 0x958: mov    BYTE PTR [r15+rax*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_95d:
	/* 0x95d: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_95f:
	/* 0x95f: cmp    r13d,r12d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_R12, X86_WIDTH_32);
x86_l_962:
	/* 0x962: seta   dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_A);
x86_l_966:
	/* 0x966: movzx  esi,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RSI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_969:
	/* 0x969: add    r15,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_96c:
	/* 0x96c: add    rdi,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_96f:
	/* 0x96f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_974:
	/* 0x974: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_977:
	/* 0x977: call   97c <generic_rawtp_process_event+0x97c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_97c:
	/* 0x97c: mov    QWORD PTR [rsp+0x98],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_984:
	/* 0x984: cmp    r13d,r12d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_R12, X86_WIDTH_32);
x86_l_987:
	/* 0x987: jbe    c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x987, 0xc24, x86_l_c24);
x86_l_98d:
	/* 0x98d: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_992:
	/* 0x992: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_99a:
	/* 0x99a: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_9a0:
	/* 0x9a0: dec    ebp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_9a2:
	/* 0x9a2: jne    824 <generic_rawtp_process_event+0x824> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9a2, 0x824, x86_l_824);
x86_l_9a8:
	/* 0x9a8: jmp    c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JMP(0x9a8, 0xc24, x86_l_c24);
x86_l_9ad:
	/* 0x9ad: lea    rdx,[r12+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9b2:
	/* 0x9b2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_9b7:
	/* 0x9b7: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_9bc:
	/* 0x9bc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_9c1:
	/* 0x9c1: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_9c4:
	/* 0x9c4: call   9c9 <generic_rawtp_process_event+0x9c9> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_9c9:
	/* 0x9c9: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_9d1:
	/* 0x9d1: cmp    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 88ULL);
x86_l_9d6:
	/* 0x9d6: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_9dc:
	/* 0x9dc: je     c17 <generic_rawtp_process_event+0xc17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9dc, 0xc17, x86_l_c17);
x86_l_9e2:
	/* 0x9e2: add    r12,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_9e6:
	/* 0x9e6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_9eb:
	/* 0x9eb: lea    rdi,[rsp+0x80] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_9f3:
	/* 0x9f3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_9f8:
	/* 0x9f8: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_9fb:
	/* 0x9fb: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_9fe:
	/* 0x9fe: call   a03 <generic_rawtp_process_event+0xa03> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a03:
	/* 0xa03: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_a08:
	/* 0xa08: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_a10:
	/* 0xa10: add    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_a14:
	/* 0xa14: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_a1c:
	/* 0xa1c: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a21:
	/* 0xa21: dec    ebp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_a23:
	/* 0xa23: jne    824 <generic_rawtp_process_event+0x824> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa23, 0x824, x86_l_824);
x86_l_a29:
	/* 0xa29: jmp    c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JMP(0xa29, 0xc24, x86_l_c24);
x86_l_a2e:
	/* 0xa2e: lea    rsi,[rip+0x2e3b] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x3870ULL);
x86_l_a35:
	/* 0xa35: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a37:
	/* 0xa37: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a3c:
	/* 0xa3c: mov    edi,0x800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 2048ULL);
x86_l_a41:
	/* 0xa41: mov    eax,0xb5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 181ULL);
x86_l_a46:
	/* 0xa46: mov    edi,0x800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 2048ULL);
x86_l_a4b:
	/* 0xa4b: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a4d:
	/* 0xa4d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_a50:
	/* 0xa50: call   a55 <generic_rawtp_process_event+0xa55> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xb5ULL: X86_SIM_BPF_CALL_bpf_loop(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xb5ULL: X86_SIM_BPF_CALL_bpf_loop(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a55:
	/* 0xa55: jmp    c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JMP(0xa55, 0xc24, x86_l_c24);
x86_l_a5a:
	/* 0xa5a: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_a62:
	/* 0xa62: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a67:
	/* 0xa67: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_a6c:
	/* 0xa6c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_a71:
	/* 0xa71: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_a76:
	/* 0xa76: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_a79:
	/* 0xa79: call   a7e <generic_rawtp_process_event+0xa7e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a7e:
	/* 0xa7e: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_a86:
	/* 0xa86: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a8b:
	/* 0xa8b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_a8e:
	/* 0xa8e: jne    5b5 <generic_rawtp_process_event+0x5b5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa8e, 0x5b5, x86_l_5b5);
x86_l_a94:
	/* 0xa94: mov    DWORD PTR [rsp+0xc8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 858993459200ULL);
x86_l_a9f:
	/* 0xa9f: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_aa6:
	/* 0xaa6: lea    rsi,[rsp+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_aae:
	/* 0xaae: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_ab3:
	/* 0xab3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_ab6:
	/* 0xab6: call   abb <generic_rawtp_process_event+0xabb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_abb:
	/* 0xabb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_abe:
	/* 0xabe: je     bfb <generic_rawtp_process_event+0xbfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xabe, 0xbfb, x86_l_bfb);
x86_l_ac4:
	/* 0xac4: mov    QWORD PTR [rsp+0x50],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ac9:
	/* 0xac9: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ace:
	/* 0xace: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_ad1:
	/* 0xad1: cmp    r13d,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 25ULL);
x86_l_ad5:
	/* 0xad5: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ada:
	/* 0xada: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_adf:
	/* 0xadf: jg     10a5 <generic_rawtp_process_event+0x10a5> */
	X86_SIM_X86_JCC(X86_CC_G, 0xadf, 0x10a5, x86_l_10a5);
x86_l_ae5:
	/* 0xae5: cmp    r13d,0x12 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 18ULL);
x86_l_ae9:
	/* 0xae9: jle    1220 <generic_rawtp_process_event+0x1220> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xae9, 0x1220, x86_l_1220);
x86_l_aef:
	/* 0xaef: cmp    r13d,0x14 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 20ULL);
x86_l_af3:
	/* 0xaf3: jle    15ec <generic_rawtp_process_event+0x15ec> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xaf3, 0x15ec, x86_l_15ec);
x86_l_af9:
	/* 0xaf9: cmp    r13d,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 21ULL);
x86_l_afd:
	/* 0xafd: je     1f78 <generic_rawtp_process_event+0x1f78> */
	X86_SIM_X86_JCC(X86_CC_E, 0xafd, 0x1f78, x86_l_1f78);
x86_l_b03:
	/* 0xb03: cmp    r13d,0x16 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 22ULL);
x86_l_b07:
	/* 0xb07: je     1ed6 <generic_rawtp_process_event+0x1ed6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb07, 0x1ed6, x86_l_1ed6);
x86_l_b0d:
	/* 0xb0d: cmp    r13d,0x17 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 23ULL);
x86_l_b11:
	/* 0xb11: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b16:
	/* 0xb16: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b1a:
	/* 0xb1a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b1f:
	/* 0xb1f: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb1f, 0xd3d, x86_l_d3d);
x86_l_b25:
	/* 0xb25: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b2a:
	/* 0xb2a: mov    DWORD PTR [rax+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_b31:
	/* 0xb31: mov    DWORD PTR [rax],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b33:
	/* 0xb33: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_b39:
	/* 0xb39: jmp    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JMP(0xb39, 0xd3d, x86_l_d3d);
x86_l_b3e:
	/* 0xb3e: cmp    r13d,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 44ULL);
x86_l_b42:
	/* 0xb42: ja     a94 <generic_rawtp_process_event+0xa94> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb42, 0xa94, x86_l_a94);
x86_l_b48:
	/* 0xb48: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_b4b:
	/* 0xb4b: movabs rcx,0x11c1f2027cf2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 19524686609650ULL);
x86_l_b55:
	/* 0xb55: bt     rcx,rax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_b59:
	/* 0xb59: jae    a94 <generic_rawtp_process_event+0xa94> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xb59, 0xa94, x86_l_a94);
x86_l_b5f:
	/* 0xb5f: mov    QWORD PTR [rsp+0x48],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_b64:
	/* 0xb64: mov    DWORD PTR [rsp+0xd0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 893353197568ULL);
x86_l_b6f:
	/* 0xb6f: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_b76:
	/* 0xb76: lea    rsi,[rsp+0xd0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_b7e:
	/* 0xb7e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b83:
	/* 0xb83: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_b86:
	/* 0xb86: call   b8b <generic_rawtp_process_event+0xb8b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b8b:
	/* 0xb8b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b8e:
	/* 0xb8e: je     bfb <generic_rawtp_process_event+0xbfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8e, 0xbfb, x86_l_bfb);
x86_l_b90:
	/* 0xb90: mov    QWORD PTR [rsp+0x50],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b95:
	/* 0xb95: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b9a:
	/* 0xb9a: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b9d:
	/* 0xb9d: cmp    r13d,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 16ULL);
x86_l_ba1:
	/* 0xba1: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ba6:
	/* 0xba6: jle    e4c <generic_rawtp_process_event+0xe4c> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xba6, 0xe4c, x86_l_e4c);
x86_l_bac:
	/* 0xbac: cmp    r13d,0x1e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 30ULL);
x86_l_bb0:
	/* 0xbb0: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_bb5:
	/* 0xbb5: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_bba:
	/* 0xbba: jle    fe1 <generic_rawtp_process_event+0xfe1> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xbba, 0xfe1, x86_l_fe1);
x86_l_bc0:
	/* 0xbc0: cmp    r13d,0x26 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 38ULL);
x86_l_bc4:
	/* 0xbc4: jg     10e6 <generic_rawtp_process_event+0x10e6> */
	X86_SIM_X86_JCC(X86_CC_G, 0xbc4, 0x10e6, x86_l_10e6);
x86_l_bca:
	/* 0xbca: lea    eax,[r13-0x1f] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551585ULL);
x86_l_bce:
	/* 0xbce: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_bd1:
	/* 0xbd1: jae    16f8 <generic_rawtp_process_event+0x16f8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xbd1, 0x16f8, x86_l_16f8);
x86_l_bd7:
	/* 0xbd7: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_bdc:
	/* 0xbdc: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_be2:
	/* 0xbe2: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_be7:
	/* 0xbe7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_bec:
	/* 0xbec: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bf1:
	/* 0xbf1: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_bf6:
	/* 0xbf6: jmp    12b9 <generic_rawtp_process_event+0x12b9> */
	X86_SIM_X86_JMP(0xbf6, 0x12b9, x86_l_12b9);
x86_l_bfb:
	/* 0xbfb: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_bfe:
	/* 0xbfe: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c03:
	/* 0xc03: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c08:
	/* 0xc08: jmp    d34 <generic_rawtp_process_event+0xd34> */
	X86_SIM_X86_JMP(0xc08, 0xd34, x86_l_d34);
x86_l_c0d:
	/* 0xc0d: mov    BYTE PTR [rsp+0xa4],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 704374636545ULL);
x86_l_c15:
	/* 0xc15: jmp    c24 <generic_rawtp_process_event+0xc24> */
	X86_SIM_X86_JMP(0xc15, 0xc24, x86_l_c24);
x86_l_c17:
	/* 0xc17: mov    BYTE PTR [rsp+0xa4],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 704374636545ULL);
x86_l_c1f:
	/* 0xc1f: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c24:
	/* 0xc24: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_c2c:
	/* 0xc2c: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c31:
	/* 0xc31: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c33:
	/* 0xc33: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_c36:
	/* 0xc36: je     c71 <generic_rawtp_process_event+0xc71> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc36, 0xc71, x86_l_c71);
x86_l_c38:
	/* 0xc38: cmp    BYTE PTR [rsp+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_c40:
	/* 0xc40: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_c43:
	/* 0xc43: mov    edx,DWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_c4a:
	/* 0xc4a: mov    r15d,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4096ULL);
x86_l_c50:
	/* 0xc50: sub    r15d,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_c53:
	/* 0xc53: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_c55:
	/* 0xc55: cmovle r15d,edx */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RDX, X86_WIDTH_32, X86_CC_LE);
x86_l_c59:
	/* 0xc59: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_c5c:
	/* 0xc5c: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c61:
	/* 0xc61: je     d5f <generic_rawtp_process_event+0xd5f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc61, 0xd5f, x86_l_d5f);
x86_l_c67:
	/* 0xc67: mov    bpl,cl */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RCX, X86_WIDTH_8);
x86_l_c6a:
	/* 0xc6a: add    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_ADD);
x86_l_c6c:
	/* 0xc6c: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_c6f:
	/* 0xc6f: jmp    c79 <generic_rawtp_process_event+0xc79> */
	X86_SIM_X86_JMP(0xc6f, 0xc79, x86_l_c79);
x86_l_c71:
	/* 0xc71: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c74:
	/* 0xc74: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c79:
	/* 0xc79: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c7e:
	/* 0xc7e: lea    rdi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_c82:
	/* 0xc82: and    r15d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_c89:
	/* 0xc89: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_c8e:
	/* 0xc8e: mov    esi,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_32);
x86_l_c91:
	/* 0xc91: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_c94:
	/* 0xc94: call   c99 <generic_rawtp_process_event+0xc99> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c99:
	/* 0xc99: mov    DWORD PTR [r13+0x0],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9d:
	/* 0xc9d: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_ca2:
	/* 0xca2: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_ca7:
	/* 0xca7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_cac:
	/* 0xcac: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_cb1:
	/* 0xcb1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_cb6:
	/* 0xcb6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_cb9:
	/* 0xcb9: call   cbe <generic_rawtp_process_event+0xcbe> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_cbe:
	/* 0xcbe: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_cc3:
	/* 0xcc3: add    rcx,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_cc7:
	/* 0xcc7: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_ccf:
	/* 0xccf: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_cd4:
	/* 0xcd4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_cd9:
	/* 0xcd9: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_cde:
	/* 0xcde: add    rdx,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_ce2:
	/* 0xce2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_ce7:
	/* 0xce7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_cea:
	/* 0xcea: call   cef <generic_rawtp_process_event+0xcef> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_cef:
	/* 0xcef: mov    rcx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_cf7:
	/* 0xcf7: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_cfc:
	/* 0xcfc: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_d01:
	/* 0xd01: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_d06:
	/* 0xd06: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_d0e:
	/* 0xd0e: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_d13:
	/* 0xd13: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_d16:
	/* 0xd16: call   d1b <generic_rawtp_process_event+0xd1b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d1b:
	/* 0xd1b: mov    DWORD PTR [r13+r15*1+0x4],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 4ULL);
x86_l_d20:
	/* 0xd20: movzx  eax,WORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 88ULL);
x86_l_d25:
	/* 0xd25: mov    WORD PTR [r13+r15*1+0x8],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_R15, 0), 8ULL);
x86_l_d2b:
	/* 0xd2b: add    r15d,0xa */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_ADD, 10ULL);
x86_l_d2f:
	/* 0xd2f: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d34:
	/* 0xd34: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d39:
	/* 0xd39: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3d:
	/* 0xd3d: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_d40:
	/* 0xd40: jns    d67 <generic_rawtp_process_event+0xd67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd40, 0xd67, x86_l_d67);
x86_l_d42:
	/* 0xd42: mov    DWORD PTR [rcx+rsi*4+0x5ea0],0xffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 2), 104045582745599ULL);
x86_l_d4d:
	/* 0xd4d: mov    DWORD PTR [rcx+rbp*1+0x90],0xffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 622770257919ULL);
x86_l_d58:
	/* 0xd58: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_d5d:
	/* 0xd5d: jmp    d75 <generic_rawtp_process_event+0xd75> */
	X86_SIM_X86_JMP(0xd5d, 0xd75, x86_l_d75);
x86_l_d5f:
	/* 0xd5f: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d62:
	/* 0xd62: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d67:
	/* 0xd67: and    r15d,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_d6e:
	/* 0xd6e: add    r15d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_d72:
	/* 0xd72: mov    edx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_32);
x86_l_d75:
	/* 0xd75: add    edx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBP, X86_WIDTH_32, X86_ALU_ADD);
x86_l_d77:
	/* 0xd77: mov    ebp,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDX, X86_WIDTH_32);
x86_l_d79:
	/* 0xd79: mov    DWORD PTR [r14+0x4],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_d7d:
	/* 0xd7d: cmp    r12d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 3ULL);
x86_l_d81:
	/* 0xd81: jg     e08 <generic_rawtp_process_event+0xe08> */
	X86_SIM_X86_JCC(X86_CC_G, 0xd81, 0xe08, x86_l_e08);
x86_l_d87:
	/* 0xd87: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_d8f:
	/* 0xd8f: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_call_heap));
x86_l_d96:
	/* 0xd96: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d9b:
	/* 0xd9b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_da0:
	/* 0xda0: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_da3:
	/* 0xda3: call   da8 <generic_rawtp_process_event+0xda8> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_da8:
	/* 0xda8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_dab:
	/* 0xdab: je     e08 <generic_rawtp_process_event+0xe08> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdab, 0xe08, x86_l_e08);
x86_l_dad:
	/* 0xdad: mov    rsi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_db0:
	/* 0xdb0: add    rsi,0x5ef8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_db7:
	/* 0xdb7: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)config_map));
x86_l_dbe:
	/* 0xdbe: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_dc3:
	/* 0xdc3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_dc6:
	/* 0xdc6: call   dcb <generic_rawtp_process_event+0xdcb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_dcb:
	/* 0xdcb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_dce:
	/* 0xdce: je     e08 <generic_rawtp_process_event+0xe08> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdce, 0xe08, x86_l_e08);
x86_l_dd0:
	/* 0xdd0: inc    r12d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_dd3:
	/* 0xdd3: mov    ecx,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_32);
x86_l_dd6:
	/* 0xdd6: and    ecx,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_dd9:
	/* 0xdd9: cmp    DWORD PTR [rax+rcx*4+0x40],0xffffffff */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 279172874239ULL);
x86_l_dde:
	/* 0xdde: je     e08 <generic_rawtp_process_event+0xe08> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdde, 0xe08, x86_l_e08);
x86_l_de0:
	/* 0xde0: mov    DWORD PTR [r14+0x5efc],r12d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24316ULL);
x86_l_de7:
	/* 0xde7: mov    rsi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tp_calls));
x86_l_dee:
	/* 0xdee: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_df3:
	/* 0xdf3: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_df8:
	/* 0xdf8: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_dfb:
	/* 0xdfb: mov    edx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_e00:
	/* 0xe00: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_e03:
	/* 0xe03: call   e08 <generic_rawtp_process_event+0xe08> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e08:
	/* 0xe08: mov    DWORD PTR [r14+0x5efc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104436424769536ULL);
x86_l_e13:
	/* 0xe13: mov    rsi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tp_calls));
x86_l_e1a:
	/* 0xe1a: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_e1f:
	/* 0xe1f: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_e24:
	/* 0xe24: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_e27:
	/* 0xe27: mov    edx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_e2c:
	/* 0xe2c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_e2f:
	/* 0xe2f: call   e34 <generic_rawtp_process_event+0xe34> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e34:
	/* 0xe34: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e36:
	/* 0xe36: add    rsp,0x108 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 264ULL);
x86_l_e3d:
	/* 0xe3d: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e3e:
	/* 0xe3e: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e40:
	/* 0xe40: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_e42:
	/* 0xe42: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_e44:
	/* 0xe44: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_e46:
	/* 0xe46: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e47:
	/* 0xe47: jmp    e4c <generic_rawtp_process_event+0xe4c> */
	X86_SIM_X86_RET();
x86_l_e4c:
	/* 0xe4c: cmp    r13d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 9ULL);
x86_l_e50:
	/* 0xe50: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_e55:
	/* 0xe55: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e5a:
	/* 0xe5a: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e5e:
	/* 0xe5e: jg     1017 <generic_rawtp_process_event+0x1017> */
	X86_SIM_X86_JCC(X86_CC_G, 0xe5e, 0x1017, x86_l_1017);
x86_l_e64:
	/* 0xe64: cmp    r13d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 4ULL);
x86_l_e68:
	/* 0xe68: jle    12c6 <generic_rawtp_process_event+0x12c6> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xe68, 0x12c6, x86_l_12c6);
x86_l_e6e:
	/* 0xe6e: cmp    r13d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 5ULL);
x86_l_e72:
	/* 0xe72: je     191a <generic_rawtp_process_event+0x191a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe72, 0x191a, x86_l_191a);
x86_l_e78:
	/* 0xe78: cmp    r13d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 6ULL);
x86_l_e7c:
	/* 0xe7c: je     1083 <generic_rawtp_process_event+0x1083> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe7c, 0x1083, x86_l_1083);
x86_l_e82:
	/* 0xe82: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e87:
	/* 0xe87: cmp    r13d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 7ULL);
x86_l_e8b:
	/* 0xe8b: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e90:
	/* 0xe90: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e94:
	/* 0xe94: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe94, 0xd3d, x86_l_d3d);
x86_l_e9a:
	/* 0xe9a: mov    r15,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_e9f:
	/* 0xe9f: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ea4:
	/* 0xea4: mov    QWORD PTR [r13+0x28],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_ea8:
	/* 0xea8: lea    rdi,[r13+0x26] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_eac:
	/* 0xeac: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eb0:
	/* 0xeb0: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_eb5:
	/* 0xeb5: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_eba:
	/* 0xeba: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_ebf:
	/* 0xebf: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_ec2:
	/* 0xec2: call   ec7 <generic_rawtp_process_event+0xec7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ec7:
	/* 0xec7: lea    rdi,[r13+0x3a] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 58ULL);
x86_l_ecb:
	/* 0xecb: lea    rdx,[r15+0x12] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18ULL);
x86_l_ecf:
	/* 0xecf: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_ed4:
	/* 0xed4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_ed9:
	/* 0xed9: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_ede:
	/* 0xede: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_ee1:
	/* 0xee1: call   ee6 <generic_rawtp_process_event+0xee6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ee6:
	/* 0xee6: lea    rdi,[r13+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_eea:
	/* 0xeea: lea    rdx,[r15+0x226] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 550ULL);
x86_l_ef1:
	/* 0xef1: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_ef6:
	/* 0xef6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_efb:
	/* 0xefb: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_f00:
	/* 0xf00: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_f03:
	/* 0xf03: call   f08 <generic_rawtp_process_event+0xf08> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f08:
	/* 0xf08: lea    rdi,[r13+0x24] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_f0c:
	/* 0xf0c: lea    rdx,[r15+0x224] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 548ULL);
x86_l_f13:
	/* 0xf13: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_f18:
	/* 0xf18: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_f1d:
	/* 0xf1d: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_f22:
	/* 0xf22: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_f25:
	/* 0xf25: call   f2a <generic_rawtp_process_event+0xf2a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f2a:
	/* 0xf2a: lea    rdi,[r13+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f2e:
	/* 0xf2e: lea    rdx,[r15+0x21c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 540ULL);
x86_l_f35:
	/* 0xf35: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_f3a:
	/* 0xf3a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_f3f:
	/* 0xf3f: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_f44:
	/* 0xf44: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_f47:
	/* 0xf47: call   f4c <generic_rawtp_process_event+0xf4c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f4c:
	/* 0xf4c: lea    rdi,[r13+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_f50:
	/* 0xf50: lea    rdx,[r15+0x218] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_f57:
	/* 0xf57: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_f5c:
	/* 0xf5c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_f61:
	/* 0xf61: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_f66:
	/* 0xf66: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_f69:
	/* 0xf69: call   f6e <generic_rawtp_process_event+0xf6e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f6e:
	/* 0xf6e: lea    r12,[r13+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f72:
	/* 0xf72: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f7a:
	/* 0xf7a: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_f82:
	/* 0xf82: mov    QWORD PTR [r13+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_f8a:
	/* 0xf8a: mov    QWORD PTR [r13+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_f92:
	/* 0xf92: movzx  eax,WORD PTR [r13+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_f97:
	/* 0xf97: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_f9a:
	/* 0xf9a: je     233c <generic_rawtp_process_event+0x233c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf9a, 0x233c, x86_l_233c);
x86_l_fa0:
	/* 0xfa0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_fa3:
	/* 0xfa3: jne    2378 <generic_rawtp_process_event+0x2378> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfa3, 0x2378, x86_l_2378);
x86_l_fa9:
	/* 0xfa9: lea    rdx,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_fad:
	/* 0xfad: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_fb2:
	/* 0xfb2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_fb7:
	/* 0xfb7: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_fba:
	/* 0xfba: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_fbf:
	/* 0xfbf: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_fc2:
	/* 0xfc2: call   fc7 <generic_rawtp_process_event+0xfc7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_fc7:
	/* 0xfc7: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_fcc:
	/* 0xfcc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_fd1:
	/* 0xfd1: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_fd4:
	/* 0xfd4: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_fd9:
	/* 0xfd9: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_fdc:
	/* 0xfdc: jmp    2370 <generic_rawtp_process_event+0x2370> */
	X86_SIM_X86_JMP(0xfdc, 0x2370, x86_l_2370);
x86_l_fe1:
	/* 0xfe1: cmp    r13d,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 28ULL);
x86_l_fe5:
	/* 0xfe5: jg     129a <generic_rawtp_process_event+0x129a> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfe5, 0x129a, x86_l_129a);
x86_l_feb:
	/* 0xfeb: cmp    r13d,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 17ULL);
x86_l_fef:
	/* 0xfef: je     172f <generic_rawtp_process_event+0x172f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfef, 0x172f, x86_l_172f);
x86_l_ff5:
	/* 0xff5: cmp    r13d,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 25ULL);
x86_l_ff9:
	/* 0xff9: je     1817 <generic_rawtp_process_event+0x1817> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff9, 0x1817, x86_l_1817);
x86_l_fff:
	/* 0xfff: cmp    r13d,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 28ULL);
x86_l_1003:
	/* 0x1003: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1008:
	/* 0x1008: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_100c:
	/* 0x100c: je     12d6 <generic_rawtp_process_event+0x12d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x100c, 0x12d6, x86_l_12d6);
x86_l_1012:
	/* 0x1012: jmp    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JMP(0x1012, 0xd3d, x86_l_d3d);
x86_l_1017:
	/* 0x1017: lea    eax,[r13-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_101b:
	/* 0x101b: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_101e:
	/* 0x101e: jb     12d6 <generic_rawtp_process_event+0x12d6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x101e, 0x12d6, x86_l_12d6);
x86_l_1024:
	/* 0x1024: lea    eax,[r13-0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_1028:
	/* 0x1028: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_102b:
	/* 0x102b: jb     12f7 <generic_rawtp_process_event+0x12f7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x102b, 0x12f7, x86_l_12f7);
x86_l_1031:
	/* 0x1031: cmp    r13d,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 14ULL);
x86_l_1035:
	/* 0x1035: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1035, 0xd3d, x86_l_d3d);
x86_l_103b:
	/* 0x103b: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1040:
	/* 0x1040: lea    r15,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1045:
	/* 0x1045: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_104a:
	/* 0x104a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_104f:
	/* 0x104f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1054:
	/* 0x1054: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1057:
	/* 0x1057: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_105a:
	/* 0x105a: call   105f <generic_rawtp_process_event+0x105f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_105f:
	/* 0x105f: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1064:
	/* 0x1064: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1069:
	/* 0x1069: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_106e:
	/* 0x106e: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1073:
	/* 0x1073: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1076:
	/* 0x1076: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_107b:
	/* 0x107b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_107e:
	/* 0x107e: call   1083 <generic_rawtp_process_event+0x1083> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1083:
	/* 0x1083: mov    rdx,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1088:
	/* 0x1088: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_108d:
	/* 0x108d: lea    rdi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1091:
	/* 0x1091: mov    ecx,0x1001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4097ULL);
x86_l_1096:
	/* 0x1096: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_109b:
	/* 0x109b: mov    esi,0x1001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4097ULL);
x86_l_10a0:
	/* 0x10a0: jmp    1b42 <generic_rawtp_process_event+0x1b42> */
	X86_SIM_X86_JMP(0x10a0, 0x1b42, x86_l_1b42);
x86_l_10a5:
	/* 0x10a5: cmp    r13d,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 32ULL);
x86_l_10a9:
	/* 0x10a9: mov    r8,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_10ae:
	/* 0x10ae: jle    14c1 <generic_rawtp_process_event+0x14c1> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x10ae, 0x14c1, x86_l_14c1);
x86_l_10b4:
	/* 0x10b4: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_10b7:
	/* 0x10b7: lea    eax,[r13-0x21] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551583ULL);
x86_l_10bb:
	/* 0x10bb: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_10be:
	/* 0x10be: jae    132c <generic_rawtp_process_event+0x132c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10be, 0x132c, x86_l_132c);
x86_l_10c4:
	/* 0x10c4: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_10ca:
	/* 0x10ca: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_10cf:
	/* 0x10cf: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_10d4:
	/* 0x10d4: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10d9:
	/* 0x10d9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_10de:
	/* 0x10de: mov    rdx,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R8, X86_WIDTH_64);
x86_l_10e1:
	/* 0x10e1: jmp    12b9 <generic_rawtp_process_event+0x12b9> */
	X86_SIM_X86_JMP(0x10e1, 0x12b9, x86_l_12b9);
x86_l_10e6:
	/* 0x10e6: cmp    r13d,0x27 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 39ULL);
x86_l_10ea:
	/* 0x10ea: je     1b20 <generic_rawtp_process_event+0x1b20> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10ea, 0x1b20, x86_l_1b20);
x86_l_10f0:
	/* 0x10f0: cmp    r13d,0x28 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 40ULL);
x86_l_10f4:
	/* 0x10f4: je     1b67 <generic_rawtp_process_event+0x1b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10f4, 0x1b67, x86_l_1b67);
x86_l_10fa:
	/* 0x10fa: cmp    r13d,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 44ULL);
x86_l_10fe:
	/* 0x10fe: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1102:
	/* 0x1102: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1102, 0xd3d, x86_l_d3d);
x86_l_1108:
	/* 0x1108: mov    r15,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_110d:
	/* 0x110d: mov    BYTE PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1112:
	/* 0x1112: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1117:
	/* 0x1117: mov    QWORD PTR [rdi+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_111f:
	/* 0x111f: mov    QWORD PTR [rdi+0x60],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1127:
	/* 0x1127: mov    QWORD PTR [rdi+0x58],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_112f:
	/* 0x112f: mov    QWORD PTR [rdi+0x50],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_1137:
	/* 0x1137: mov    QWORD PTR [rdi+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_113f:
	/* 0x113f: mov    QWORD PTR [rdi+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1147:
	/* 0x1147: mov    QWORD PTR [rdi+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_114f:
	/* 0x114f: mov    QWORD PTR [rdi+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1157:
	/* 0x1157: mov    QWORD PTR [rdi+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_115f:
	/* 0x115f: mov    QWORD PTR [rdi+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1167:
	/* 0x1167: mov    QWORD PTR [rdi+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_116f:
	/* 0x116f: mov    QWORD PTR [rdi+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1177:
	/* 0x1177: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_117f:
	/* 0x117f: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1186:
	/* 0x1186: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_118b:
	/* 0x118b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1190:
	/* 0x1190: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1195:
	/* 0x1195: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1198:
	/* 0x1198: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_119b:
	/* 0x119b: call   11a0 <generic_rawtp_process_event+0x11a0> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11a0:
	/* 0x11a0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_11a3:
	/* 0x11a3: js     26d0 <generic_rawtp_process_event+0x26d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11a3, 0x26d0, x86_l_26d0);
x86_l_11a9:
	/* 0x11a9: lea    r12,[r15+0x2] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_11ad:
	/* 0x11ad: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_11b2:
	/* 0x11b2: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_11b7:
	/* 0x11b7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_11bc:
	/* 0x11bc: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_11c1:
	/* 0x11c1: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_11c4:
	/* 0x11c4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_11c7:
	/* 0x11c7: call   11cc <generic_rawtp_process_event+0x11cc> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11cc:
	/* 0x11cc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_11cf:
	/* 0x11cf: js     26d0 <generic_rawtp_process_event+0x26d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11cf, 0x26d0, x86_l_26d0);
x86_l_11d5:
	/* 0x11d5: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11da:
	/* 0x11da: lea    rdi,[rax+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11de:
	/* 0x11de: cmp    BYTE PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_11e3:
	/* 0x11e3: sete   BYTE PTR [rax+0x2] */
	X86_SIM_L_EXEC_SETCC_MEM(X86_RAX, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_E)), 2ULL);
x86_l_11e7:
	/* 0x11e7: je     2697 <generic_rawtp_process_event+0x2697> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11e7, 0x2697, x86_l_2697);
x86_l_11ed:
	/* 0x11ed: mov    ecx,0x6c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 108ULL);
x86_l_11f2:
	/* 0x11f2: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_11f7:
	/* 0x11f7: mov    esi,0x6c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 108ULL);
x86_l_11fc:
	/* 0x11fc: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_11ff:
	/* 0x11ff: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1202:
	/* 0x1202: call   1207 <generic_rawtp_process_event+0x1207> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1207:
	/* 0x1207: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1209:
	/* 0x1209: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_120e:
	/* 0x120e: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1213:
	/* 0x1213: js     26d0 <generic_rawtp_process_event+0x26d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1213, 0x26d0, x86_l_26d0);
x86_l_1219:
	/* 0x1219: dec    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_DEC, 1);
x86_l_121b:
	/* 0x121b: jmp    26c8 <generic_rawtp_process_event+0x26c8> */
	X86_SIM_X86_JMP(0x121b, 0x26c8, x86_l_26c8);
x86_l_1220:
	/* 0x1220: cmp    r13d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 7ULL);
x86_l_1224:
	/* 0x1224: jg     1597 <generic_rawtp_process_event+0x1597> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1224, 0x1597, x86_l_1597);
x86_l_122a:
	/* 0x122a: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_122d:
	/* 0x122d: cmp    r13d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 2ULL);
x86_l_1231:
	/* 0x1231: je     1c0a <generic_rawtp_process_event+0x1c0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1231, 0x1c0a, x86_l_1c0a);
x86_l_1237:
	/* 0x1237: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_123c:
	/* 0x123c: cmp    r13d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 3ULL);
x86_l_1240:
	/* 0x1240: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1245:
	/* 0x1245: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1249:
	/* 0x1249: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1249, 0xd3d, x86_l_d3d);
x86_l_124f:
	/* 0x124f: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_1252:
	/* 0x1252: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1257:
	/* 0x1257: lea    rbp,[rax+0x90] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_125e:
	/* 0x125e: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1263:
	/* 0x1263: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1266:
	/* 0x1266: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1269:
	/* 0x1269: jle    2510 <generic_rawtp_process_event+0x2510> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1269, 0x2510, x86_l_2510);
x86_l_126f:
	/* 0x126f: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_1272:
	/* 0x1272: je     27e6 <generic_rawtp_process_event+0x27e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1272, 0x27e6, x86_l_27e6);
x86_l_1278:
	/* 0x1278: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_127b:
	/* 0x127b: je     27f3 <generic_rawtp_process_event+0x27f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x127b, 0x27f3, x86_l_27f3);
x86_l_1281:
	/* 0x1281: cmp    eax,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 5ULL);
x86_l_1284:
	/* 0x1284: jne    2c94 <generic_rawtp_process_event+0x2c94> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1284, 0x2c94, x86_l_2c94);
x86_l_128a:
	/* 0x128a: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_128f:
	/* 0x128f: add    rax,0x5e70 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 24176ULL);
x86_l_1295:
	/* 0x1295: jmp    280b <generic_rawtp_process_event+0x280b> */
	X86_SIM_X86_JMP(0x1295, 0x280b, x86_l_280b);
x86_l_129a:
	/* 0x129a: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_129f:
	/* 0x129f: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_12a5:
	/* 0x12a5: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_12aa:
	/* 0x12aa: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_12af:
	/* 0x12af: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12b4:
	/* 0x12b4: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_12b9:
	/* 0x12b9: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_12bc:
	/* 0x12bc: call   12c1 <generic_rawtp_process_event+0x12c1> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_12c1:
	/* 0x12c1: jmp    259e <generic_rawtp_process_event+0x259e> */
	X86_SIM_X86_JMP(0x12c1, 0x259e, x86_l_259e);
x86_l_12c6:
	/* 0x12c6: cmp    r13d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 1ULL);
x86_l_12ca:
	/* 0x12ca: je     12f7 <generic_rawtp_process_event+0x12f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12ca, 0x12f7, x86_l_12f7);
x86_l_12cc:
	/* 0x12cc: cmp    r13d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 4ULL);
x86_l_12d0:
	/* 0x12d0: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12d0, 0xd3d, x86_l_d3d);
x86_l_12d6:
	/* 0x12d6: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_12dc:
	/* 0x12dc: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_12e1:
	/* 0x12e1: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_12e6:
	/* 0x12e6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_12eb:
	/* 0x12eb: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12f0:
	/* 0x12f0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_12f5:
	/* 0x12f5: jmp    1316 <generic_rawtp_process_event+0x1316> */
	X86_SIM_X86_JMP(0x12f5, 0x1316, x86_l_1316);
x86_l_12f7:
	/* 0x12f7: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_12fc:
	/* 0x12fc: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_1302:
	/* 0x1302: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1307:
	/* 0x1307: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_130c:
	/* 0x130c: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1311:
	/* 0x1311: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1316:
	/* 0x1316: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1319:
	/* 0x1319: call   131e <generic_rawtp_process_event+0x131e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_131e:
	/* 0x131e: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1322:
	/* 0x1322: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1327:
	/* 0x1327: jmp    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JMP(0x1327, 0xd3d, x86_l_d3d);
x86_l_132c:
	/* 0x132c: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1331:
	/* 0x1331: cmp    r13d,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 43ULL);
x86_l_1335:
	/* 0x1335: je     2095 <generic_rawtp_process_event+0x2095> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1335, 0x2095, x86_l_2095);
x86_l_133b:
	/* 0x133b: cmp    r13d,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 41ULL);
x86_l_133f:
	/* 0x133f: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1344:
	/* 0x1344: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1348:
	/* 0x1348: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1348, 0xd3d, x86_l_d3d);
x86_l_134e:
	/* 0x134e: mov    r13,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RCX, X86_WIDTH_64);
x86_l_1351:
	/* 0x1351: add    r8,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1355:
	/* 0x1355: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_135a:
	/* 0x135a: mov    r12d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4ULL);
x86_l_1360:
	/* 0x1360: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1365:
	/* 0x1365: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_136a:
	/* 0x136a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_136f:
	/* 0x136f: mov    rdx,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R8, X86_WIDTH_64);
x86_l_1372:
	/* 0x1372: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1375:
	/* 0x1375: call   137a <generic_rawtp_process_event+0x137a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_137a:
	/* 0x137a: mov    r15,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_137f:
	/* 0x137f: test   r15,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64);
x86_l_1382:
	/* 0x1382: je     2794 <generic_rawtp_process_event+0x2794> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1382, 0x2794, x86_l_2794);
x86_l_1388:
	/* 0x1388: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_138d:
	/* 0x138d: mov    QWORD PTR [rbp+0x28],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1391:
	/* 0x1391: lea    rdi,[rbp+0x26] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_1395:
	/* 0x1395: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1399:
	/* 0x1399: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_139e:
	/* 0x139e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_13a3:
	/* 0x13a3: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_13a8:
	/* 0x13a8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_13ab:
	/* 0x13ab: call   13b0 <generic_rawtp_process_event+0x13b0> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13b0:
	/* 0x13b0: lea    rdi,[rbp+0x3a] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 58ULL);
x86_l_13b4:
	/* 0x13b4: lea    rdx,[r15+0x12] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18ULL);
x86_l_13b8:
	/* 0x13b8: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_13bd:
	/* 0x13bd: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_13c2:
	/* 0x13c2: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_13c7:
	/* 0x13c7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_13ca:
	/* 0x13ca: call   13cf <generic_rawtp_process_event+0x13cf> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13cf:
	/* 0x13cf: lea    rdi,[rbp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_13d3:
	/* 0x13d3: lea    rdx,[r15+0x226] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 550ULL);
x86_l_13da:
	/* 0x13da: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_13df:
	/* 0x13df: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_13e4:
	/* 0x13e4: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_13e9:
	/* 0x13e9: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_13ec:
	/* 0x13ec: call   13f1 <generic_rawtp_process_event+0x13f1> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13f1:
	/* 0x13f1: lea    rdi,[rbp+0x24] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_13f5:
	/* 0x13f5: lea    rdx,[r15+0x224] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 548ULL);
x86_l_13fc:
	/* 0x13fc: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1401:
	/* 0x1401: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1406:
	/* 0x1406: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_140b:
	/* 0x140b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_140e:
	/* 0x140e: call   1413 <generic_rawtp_process_event+0x1413> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1413:
	/* 0x1413: lea    rdi,[rbp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1417:
	/* 0x1417: lea    rdx,[r15+0x21c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 540ULL);
x86_l_141e:
	/* 0x141e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1423:
	/* 0x1423: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1428:
	/* 0x1428: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_142b:
	/* 0x142b: call   1430 <generic_rawtp_process_event+0x1430> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1430:
	/* 0x1430: lea    rdi,[rbp+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1434:
	/* 0x1434: lea    rdx,[r15+0x218] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_143b:
	/* 0x143b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1440:
	/* 0x1440: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1445:
	/* 0x1445: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1448:
	/* 0x1448: call   144d <generic_rawtp_process_event+0x144d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_144d:
	/* 0x144d: lea    r12,[rbp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1451:
	/* 0x1451: mov    QWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1459:
	/* 0x1459: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1461:
	/* 0x1461: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1469:
	/* 0x1469: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1471:
	/* 0x1471: movzx  eax,WORD PTR [rbp+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_1475:
	/* 0x1475: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_1478:
	/* 0x1478: je     2703 <generic_rawtp_process_event+0x2703> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1478, 0x2703, x86_l_2703);
x86_l_147e:
	/* 0x147e: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1481:
	/* 0x1481: jne    2741 <generic_rawtp_process_event+0x2741> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1481, 0x2741, x86_l_2741);
x86_l_1487:
	/* 0x1487: lea    rdx,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_148b:
	/* 0x148b: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1490:
	/* 0x1490: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1495:
	/* 0x1495: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_149a:
	/* 0x149a: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_149f:
	/* 0x149f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_14a2:
	/* 0x14a2: call   14a7 <generic_rawtp_process_event+0x14a7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_14a7:
	/* 0x14a7: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_14ac:
	/* 0x14ac: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_14b1:
	/* 0x14b1: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_14b4:
	/* 0x14b4: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_14b9:
	/* 0x14b9: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_14bc:
	/* 0x14bc: jmp    2739 <generic_rawtp_process_event+0x2739> */
	X86_SIM_X86_JMP(0x14bc, 0x2739, x86_l_2739);
x86_l_14c1:
	/* 0x14c1: cmp    r13d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 26ULL);
x86_l_14c5:
	/* 0x14c5: je     2144 <generic_rawtp_process_event+0x2144> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14c5, 0x2144, x86_l_2144);
x86_l_14cb:
	/* 0x14cb: cmp    r13d,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 27ULL);
x86_l_14cf:
	/* 0x14cf: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14d4:
	/* 0x14d4: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14d8:
	/* 0x14d8: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14d8, 0xd3d, x86_l_d3d);
x86_l_14de:
	/* 0x14de: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_14e1:
	/* 0x14e1: mov    r12,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RCX, X86_WIDTH_64);
x86_l_14e4:
	/* 0x14e4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14e9:
	/* 0x14e9: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_14f1:
	/* 0x14f1: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_14f9:
	/* 0x14f9: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1501:
	/* 0x1501: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1509:
	/* 0x1509: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1511:
	/* 0x1511: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1519:
	/* 0x1519: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1521:
	/* 0x1521: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1529:
	/* 0x1529: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1531:
	/* 0x1531: mov    QWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1538:
	/* 0x1538: lea    rdi,[rax+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_153c:
	/* 0x153c: lea    rdx,[r8+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1540:
	/* 0x1540: mov    ecx,0x3f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 63ULL);
x86_l_1545:
	/* 0x1545: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_154a:
	/* 0x154a: mov    esi,0x3f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 63ULL);
x86_l_154f:
	/* 0x154f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1552:
	/* 0x1552: call   1557 <generic_rawtp_process_event+0x1557> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1557:
	/* 0x1557: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_155a:
	/* 0x155a: js     2689 <generic_rawtp_process_event+0x2689> */
	X86_SIM_X86_JCC(X86_CC_S, 0x155a, 0x2689, x86_l_2689);
x86_l_1560:
	/* 0x1560: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1565:
	/* 0x1565: add    rdi,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1569:
	/* 0x1569: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_156e:
	/* 0x156e: add    rdx,0x348 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 840ULL);
x86_l_1575:
	/* 0x1575: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_157a:
	/* 0x157a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_157f:
	/* 0x157f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1584:
	/* 0x1584: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1587:
	/* 0x1587: call   158c <generic_rawtp_process_event+0x158c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_158c:
	/* 0x158c: mov    r15d,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 80ULL);
x86_l_1592:
	/* 0x1592: jmp    268c <generic_rawtp_process_event+0x268c> */
	X86_SIM_X86_JMP(0x1592, 0x268c, x86_l_268c);
x86_l_1597:
	/* 0x1597: cmp    r13d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 8ULL);
x86_l_159b:
	/* 0x159b: je     1c79 <generic_rawtp_process_event+0x1c79> */
	X86_SIM_X86_JCC(X86_CC_E, 0x159b, 0x1c79, x86_l_1c79);
x86_l_15a1:
	/* 0x15a1: cmp    r13d,0x12 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 18ULL);
x86_l_15a5:
	/* 0x15a5: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15aa:
	/* 0x15aa: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ae:
	/* 0x15ae: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15b3:
	/* 0x15b3: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15b3, 0xd3d, x86_l_d3d);
x86_l_15b9:
	/* 0x15b9: mov    r13,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_15be:
	/* 0x15be: and    r13d,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_15c5:
	/* 0x15c5: mov    r15,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RCX, X86_WIDTH_64);
x86_l_15c8:
	/* 0x15c8: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_15cd:
	/* 0x15cd: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15d2:
	/* 0x15d2: mov    esi,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_32);
x86_l_15d5:
	/* 0x15d5: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_15d8:
	/* 0x15d8: call   15dd <generic_rawtp_process_event+0x15dd> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15dd:
	/* 0x15dd: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e1:
	/* 0x15e1: mov    rcx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_64);
x86_l_15e4:
	/* 0x15e4: mov    r15,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_64);
x86_l_15e7:
	/* 0x15e7: jmp    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JMP(0x15e7, 0xd3d, x86_l_d3d);
x86_l_15ec:
	/* 0x15ec: cmp    r13d,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 19ULL);
x86_l_15f0:
	/* 0x15f0: je     202d <generic_rawtp_process_event+0x202d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15f0, 0x202d, x86_l_202d);
x86_l_15f6:
	/* 0x15f6: cmp    r13d,0x14 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 20ULL);
x86_l_15fa:
	/* 0x15fa: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15ff:
	/* 0x15ff: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1603:
	/* 0x1603: mov    r8,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1608:
	/* 0x1608: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1608, 0xd3d, x86_l_d3d);
x86_l_160e:
	/* 0x160e: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1617:
	/* 0x1617: lea    rdx,[r8+0x110] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_161e:
	/* 0x161e: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1623:
	/* 0x1623: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1628:
	/* 0x1628: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_162d:
	/* 0x162d: lea    r15,[r8+0xd8] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1634:
	/* 0x1634: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1639:
	/* 0x1639: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_163c:
	/* 0x163c: mov    r12,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_R8, X86_WIDTH_64);
x86_l_163f:
	/* 0x163f: call   1644 <generic_rawtp_process_event+0x1644> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1644:
	/* 0x1644: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1649:
	/* 0x1649: mov    edx,0x80 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 128ULL);
x86_l_164e:
	/* 0x164e: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_1653:
	/* 0x1653: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1658:
	/* 0x1658: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_165d:
	/* 0x165d: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1660:
	/* 0x1660: mov    esi,0x80 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 128ULL);
x86_l_1665:
	/* 0x1665: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1668:
	/* 0x1668: call   166d <generic_rawtp_process_event+0x166d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_166d:
	/* 0x166d: lea    rdi,[r13+0x90] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1674:
	/* 0x1674: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1679:
	/* 0x1679: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_167e:
	/* 0x167e: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1683:
	/* 0x1683: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1686:
	/* 0x1686: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1689:
	/* 0x1689: call   168e <generic_rawtp_process_event+0x168e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_168e:
	/* 0x168e: lea    rdi,[r13+0x80] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1695:
	/* 0x1695: lea    rdx,[r12+0xe0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_169d:
	/* 0x169d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_16a2:
	/* 0x16a2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_16a7:
	/* 0x16a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_16ac:
	/* 0x16ac: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_16af:
	/* 0x16af: call   16b4 <generic_rawtp_process_event+0x16b4> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16b4:
	/* 0x16b4: add    r13,0x88 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 136ULL);
x86_l_16bb:
	/* 0x16bb: add    r12,0x118 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 280ULL);
x86_l_16c2:
	/* 0x16c2: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_16c7:
	/* 0x16c7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_16cc:
	/* 0x16cc: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_16cf:
	/* 0x16cf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_16d4:
	/* 0x16d4: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_16d7:
	/* 0x16d7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_16da:
	/* 0x16da: call   16df <generic_rawtp_process_event+0x16df> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16df:
	/* 0x16df: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e3:
	/* 0x16e3: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16e8:
	/* 0x16e8: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_16ed:
	/* 0x16ed: mov    r15d,0x98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 152ULL);
x86_l_16f3:
	/* 0x16f3: jmp    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JMP(0x16f3, 0xd3d, x86_l_d3d);
x86_l_16f8:
	/* 0x16f8: cmp    r13d,0x26 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 38ULL);
x86_l_16fc:
	/* 0x16fc: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1700:
	/* 0x1700: jne    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1700, 0xd3d, x86_l_d3d);
x86_l_1706:
	/* 0x1706: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_170b:
	/* 0x170b: movzx  edx,si */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RDX, X86_RSI, X86_WIDTH_32, X86_WIDTH_16);
x86_l_170e:
	/* 0x170e: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1711:
	/* 0x1711: shr    esi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_1714:
	/* 0x1714: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_171a:
	/* 0x171a: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_171f:
	/* 0x171f: lea    rdi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1723:
	/* 0x1723: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1725:
	/* 0x1725: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_172a:
	/* 0x172a: jmp    1b42 <generic_rawtp_process_event+0x1b42> */
	X86_SIM_X86_JMP(0x172a, 0x1b42, x86_l_1b42);
x86_l_172f:
	/* 0x172f: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_1738:
	/* 0x1738: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_173d:
	/* 0x173d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1740:
	/* 0x1740: call   1745 <generic_rawtp_process_event+0x1745> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1745:
	/* 0x1745: shr    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1749:
	/* 0x1749: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_174e:
	/* 0x174e: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1756:
	/* 0x1756: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_175b:
	/* 0x175b: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1760:
	/* 0x1760: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1765:
	/* 0x1765: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_176b:
	/* 0x176b: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1770:
	/* 0x1770: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1773:
	/* 0x1773: call   1778 <generic_rawtp_process_event+0x1778> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1778:
	/* 0x1778: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_177f:
	/* 0x177f: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1783:
	/* 0x1783: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)fdinstall_map));
x86_l_178a:
	/* 0x178a: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_178f:
	/* 0x178f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1794:
	/* 0x1794: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1797:
	/* 0x1797: call   179c <generic_rawtp_process_event+0x179c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_179c:
	/* 0x179c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_179f:
	/* 0x179f: je     21cd <generic_rawtp_process_event+0x21cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x179f, 0x21cd, x86_l_21cd);
x86_l_17a5:
	/* 0x17a5: mov    r15d,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a8:
	/* 0x17a8: lea    rdx,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_17b0:
	/* 0x17b0: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_17b3:
	/* 0x17b3: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_17b8:
	/* 0x17b8: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17bd:
	/* 0x17bd: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_17c0:
	/* 0x17c0: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_17c5:
	/* 0x17c5: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_17c8:
	/* 0x17c8: call   17cd <generic_rawtp_process_event+0x17cd> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17cd:
	/* 0x17cd: and    r15d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_17d4:
	/* 0x17d4: lea    rdi,[rbp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17d8:
	/* 0x17d8: lea    rsi,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17dc:
	/* 0x17dc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_17e1:
	/* 0x17e1: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_17e4:
	/* 0x17e4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_17e7:
	/* 0x17e7: call   17ec <generic_rawtp_process_event+0x17ec> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17ec:
	/* 0x17ec: lea    rdi,[r15+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_17f0:
	/* 0x17f0: add    rdi,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_17f4:
	/* 0x17f4: lea    rdx,[r15+r12*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_17f8:
	/* 0x17f8: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_17fc:
	/* 0x17fc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1801:
	/* 0x1801: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1806:
	/* 0x1806: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1809:
	/* 0x1809: call   180e <generic_rawtp_process_event+0x180e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_180e:
	/* 0x180e: add    r15,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1812:
	/* 0x1812: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x1812, 0x2e92, x86_l_2e92);
x86_l_1817:
	/* 0x1817: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_181a:
	/* 0x181a: mov    r12,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_181f:
	/* 0x181f: lea    rdi,[rsp+0xc0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1827:
	/* 0x1827: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_182c:
	/* 0x182c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1831:
	/* 0x1831: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_1836:
	/* 0x1836: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_1839:
	/* 0x1839: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_183c:
	/* 0x183c: call   1841 <generic_rawtp_process_event+0x1841> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1841:
	/* 0x1841: movzx  eax,BYTE PTR [rsp+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 192ULL);
x86_l_1849:
	/* 0x1849: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_184b:
	/* 0x184b: je     21d9 <generic_rawtp_process_event+0x21d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184b, 0x21d9, x86_l_21d9);
x86_l_1851:
	/* 0x1851: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1854:
	/* 0x1854: jne    2413 <generic_rawtp_process_event+0x2413> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1854, 0x2413, x86_l_2413);
x86_l_185a:
	/* 0x185a: add    r12,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_185e:
	/* 0x185e: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1863:
	/* 0x1863: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_1869:
	/* 0x1869: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_186e:
	/* 0x186e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1873:
	/* 0x1873: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1878:
	/* 0x1878: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_187b:
	/* 0x187b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_187e:
	/* 0x187e: call   1883 <generic_rawtp_process_event+0x1883> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1883:
	/* 0x1883: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1888:
	/* 0x1888: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1890:
	/* 0x1890: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1895:
	/* 0x1895: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_189a:
	/* 0x189a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_189f:
	/* 0x189f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_18a2:
	/* 0x18a2: call   18a7 <generic_rawtp_process_event+0x18a7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18a7:
	/* 0x18a7: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_18ac:
	/* 0x18ac: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_18b0:
	/* 0x18b0: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_18b5:
	/* 0x18b5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_18ba:
	/* 0x18ba: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_18bf:
	/* 0x18bf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_18c4:
	/* 0x18c4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_18c7:
	/* 0x18c7: call   18cc <generic_rawtp_process_event+0x18cc> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18cc:
	/* 0x18cc: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_18d4:
	/* 0x18d4: mov    r13,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_18d9:
	/* 0x18d9: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_18de:
	/* 0x18de: lea    r14,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_18e2:
	/* 0x18e2: add    r14,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_18e9:
	/* 0x18e9: test   BYTE PTR [rsp+0x30],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430240ULL);
x86_l_18ee:
	/* 0x18ee: je     2dd4 <generic_rawtp_process_event+0x2dd4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18ee, 0x2dd4, x86_l_2dd4);
x86_l_18f4:
	/* 0x18f4: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_18fb:
	/* 0x18fb: jb     2dad <generic_rawtp_process_event+0x2dad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x18fb, 0x2dad, x86_l_2dad);
x86_l_1901:
	/* 0x1901: mov    DWORD PTR [r14],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1908:
	/* 0x1908: add    r14,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_190c:
	/* 0x190c: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_190f:
	/* 0x190f: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_1912:
	/* 0x1912: mov    rcx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R13, X86_WIDTH_64);
x86_l_1915:
	/* 0x1915: jmp    2274 <generic_rawtp_process_event+0x2274> */
	X86_SIM_X86_JMP(0x1915, 0x2274, x86_l_2274);
x86_l_191a:
	/* 0x191a: mov    QWORD PTR [rsp+0x40],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_191f:
	/* 0x191f: mov    r12,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1924:
	/* 0x1924: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1929:
	/* 0x1929: lea    rdi,[rbx+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_192d:
	/* 0x192d: lea    rdx,[r12+0x98] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1935:
	/* 0x1935: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_193a:
	/* 0x193a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_193f:
	/* 0x193f: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1944:
	/* 0x1944: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1947:
	/* 0x1947: call   194c <generic_rawtp_process_event+0x194c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_194c:
	/* 0x194c: lea    rdi,[rbx+0x2c] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1950:
	/* 0x1950: lea    rdx,[r12+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1955:
	/* 0x1955: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_195a:
	/* 0x195a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_195f:
	/* 0x195f: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1964:
	/* 0x1964: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1967:
	/* 0x1967: call   196c <generic_rawtp_process_event+0x196c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_196c:
	/* 0x196c: lea    rdi,[rbx+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1970:
	/* 0x1970: lea    rdx,[r12+0x90] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1978:
	/* 0x1978: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_197d:
	/* 0x197d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1982:
	/* 0x1982: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1987:
	/* 0x1987: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_198a:
	/* 0x198a: call   198f <generic_rawtp_process_event+0x198f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_198f:
	/* 0x198f: lea    rdi,[rbx+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1993:
	/* 0x1993: lea    rdx,[r12+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_199b:
	/* 0x199b: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_19a0:
	/* 0x19a0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_19a5:
	/* 0x19a5: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_19aa:
	/* 0x19aa: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_19ad:
	/* 0x19ad: call   19b2 <generic_rawtp_process_event+0x19b2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_19b2:
	/* 0x19b2: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_19bb:
	/* 0x19bb: lea    rdx,[r12+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_19c3:
	/* 0x19c3: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_19c8:
	/* 0x19c8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_19cd:
	/* 0x19cd: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_19d2:
	/* 0x19d2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_19d7:
	/* 0x19d7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_19da:
	/* 0x19da: call   19df <generic_rawtp_process_event+0x19df> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_19df:
	/* 0x19df: lea    rdx,[r12+0xb8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_19e7:
	/* 0x19e7: lea    rdi,[rsp+0xc0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_19ef:
	/* 0x19ef: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_19f4:
	/* 0x19f4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_19f9:
	/* 0x19f9: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_19fe:
	/* 0x19fe: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1a01:
	/* 0x1a01: call   1a06 <generic_rawtp_process_event+0x1a06> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a06:
	/* 0x1a06: movzx  r15d,WORD PTR [rsp+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 192ULL);
x86_l_1a0f:
	/* 0x1a0f: add    r15,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 104ULL);
x86_l_1a14:
	/* 0x1a14: lea    rdi,[rsp+0xbb] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 187ULL);
x86_l_1a1c:
	/* 0x1a1c: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1a21:
	/* 0x1a21: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1a26:
	/* 0x1a26: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_1a2b:
	/* 0x1a2b: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1a2e:
	/* 0x1a2e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1a31:
	/* 0x1a31: call   1a36 <generic_rawtp_process_event+0x1a36> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a36:
	/* 0x1a36: movzx  eax,BYTE PTR [rsp+0xbb] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 187ULL);
x86_l_1a3e:
	/* 0x1a3e: shr    eax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_1a41:
	/* 0x1a41: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_1a44:
	/* 0x1a44: je     2285 <generic_rawtp_process_event+0x2285> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a44, 0x2285, x86_l_2285);
x86_l_1a4a:
	/* 0x1a4a: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1a4d:
	/* 0x1a4d: jne    37a6 <generic_rawtp_process_event+0x37a6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a4d, 0x37a6, x86_l_37a6);
x86_l_1a53:
	/* 0x1a53: lea    rdx,[r15+0x9] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 9ULL);
x86_l_1a57:
	/* 0x1a57: lea    rdi,[rsp+0xbc] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_1a5f:
	/* 0x1a5f: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1a64:
	/* 0x1a64: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1a69:
	/* 0x1a69: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_1a6e:
	/* 0x1a6e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1a71:
	/* 0x1a71: call   1a76 <generic_rawtp_process_event+0x1a76> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a76:
	/* 0x1a76: movzx  eax,BYTE PTR [rsp+0xbc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 188ULL);
x86_l_1a7e:
	/* 0x1a7e: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a83:
	/* 0x1a83: mov    WORD PTR [rdi+0x24],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1a87:
	/* 0x1a87: mov    WORD PTR [rdi+0x26],0x2 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 163208757250ULL);
x86_l_1a8d:
	/* 0x1a8d: lea    rdx,[r15+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1a91:
	/* 0x1a91: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a98:
	/* 0x1a98: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1aa0:
	/* 0x1aa0: mov    QWORD PTR [rdi+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1aa8:
	/* 0x1aa8: mov    QWORD PTR [rdi+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1ab0:
	/* 0x1ab0: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1ab5:
	/* 0x1ab5: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1aba:
	/* 0x1aba: lea    r13,[rdi+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1abe:
	/* 0x1abe: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ac3:
	/* 0x1ac3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1ac6:
	/* 0x1ac6: call   1acb <generic_rawtp_process_event+0x1acb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1acb:
	/* 0x1acb: add    r15,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1acf:
	/* 0x1acf: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1ad4:
	/* 0x1ad4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1ad9:
	/* 0x1ad9: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1adc:
	/* 0x1adc: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ae1:
	/* 0x1ae1: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1ae4:
	/* 0x1ae4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1ae7:
	/* 0x1ae7: call   1aec <generic_rawtp_process_event+0x1aec> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1aec:
	/* 0x1aec: lea    rdx,[r12+0xb6] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_1af4:
	/* 0x1af4: lea    rdi,[rsp+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1afc:
	/* 0x1afc: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1b01:
	/* 0x1b01: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1b06:
	/* 0x1b06: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1b0b:
	/* 0x1b0b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1b0e:
	/* 0x1b0e: call   1b13 <generic_rawtp_process_event+0x1b13> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b13:
	/* 0x1b13: movzx  ebp,BYTE PTR [rsp+0xbc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 188ULL);
x86_l_1b1b:
	/* 0x1b1b: jmp    3610 <generic_rawtp_process_event+0x3610> */
	X86_SIM_X86_JMP(0x1b1b, 0x3610, x86_l_3610);
x86_l_1b20:
	/* 0x1b20: mov    edx,0x120 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 288ULL);
x86_l_1b25:
	/* 0x1b25: add    rdx,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 72ULL);
x86_l_1b2a:
	/* 0x1b2a: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b2f:
	/* 0x1b2f: lea    rdi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b33:
	/* 0x1b33: mov    ecx,0x11 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_1b38:
	/* 0x1b38: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_1b3d:
	/* 0x1b3d: mov    esi,0x11 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_1b42:
	/* 0x1b42: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1b45:
	/* 0x1b45: call   1b4a <generic_rawtp_process_event+0x1b4a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b4a:
	/* 0x1b4a: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1b4d:
	/* 0x1b4d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1b50:
	/* 0x1b50: js     259e <generic_rawtp_process_event+0x259e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b50, 0x259e, x86_l_259e);
x86_l_1b56:
	/* 0x1b56: lea    eax,[r15-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b5a:
	/* 0x1b5a: mov    DWORD PTR [r13+0x0],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b5e:
	/* 0x1b5e: add    r15,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 3ULL);
x86_l_1b62:
	/* 0x1b62: jmp    259e <generic_rawtp_process_event+0x259e> */
	X86_SIM_X86_JMP(0x1b62, 0x259e, x86_l_259e);
x86_l_1b67:
	/* 0x1b67: mov    r15,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1b6c:
	/* 0x1b6c: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b71:
	/* 0x1b71: mov    QWORD PTR [r13+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1b79:
	/* 0x1b79: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1b81:
	/* 0x1b81: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b89:
	/* 0x1b89: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1b8e:
	/* 0x1b8e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1b93:
	/* 0x1b93: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1b96:
	/* 0x1b96: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1b9b:
	/* 0x1b9b: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1b9e:
	/* 0x1b9e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1ba1:
	/* 0x1ba1: call   1ba6 <generic_rawtp_process_event+0x1ba6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ba6:
	/* 0x1ba6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1ba9:
	/* 0x1ba9: js     2598 <generic_rawtp_process_event+0x2598> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ba9, 0x2598, x86_l_2598);
x86_l_1baf:
	/* 0x1baf: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1bb4:
	/* 0x1bb4: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_1bb7:
	/* 0x1bb7: je     2532 <generic_rawtp_process_event+0x2532> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bb7, 0x2532, x86_l_2532);
x86_l_1bbd:
	/* 0x1bbd: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1bc0:
	/* 0x1bc0: jne    257a <generic_rawtp_process_event+0x257a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bc0, 0x257a, x86_l_257a);
x86_l_1bc6:
	/* 0x1bc6: lea    rdx,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bca:
	/* 0x1bca: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1bcf:
	/* 0x1bcf: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1bd4:
	/* 0x1bd4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1bd9:
	/* 0x1bd9: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1bde:
	/* 0x1bde: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1be1:
	/* 0x1be1: call   1be6 <generic_rawtp_process_event+0x1be6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1be6:
	/* 0x1be6: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1bea:
	/* 0x1bea: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bef:
	/* 0x1bef: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bf3:
	/* 0x1bf3: lea    rdi,[rcx+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_1bf7:
	/* 0x1bf7: add    r15,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_1bfb:
	/* 0x1bfb: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1c00:
	/* 0x1c00: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1c05:
	/* 0x1c05: jmp    256a <generic_rawtp_process_event+0x256a> */
	X86_SIM_X86_JMP(0x1c05, 0x256a, x86_l_256a);
x86_l_1c0a:
	/* 0x1c0a: mov    QWORD PTR [rsp+0x40],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c0f:
	/* 0x1c0f: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1c14:
	/* 0x1c14: mov    rbp,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RCX, X86_WIDTH_64);
x86_l_1c17:
	/* 0x1c17: lea    rbx,[rcx+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1c1b:
	/* 0x1c1b: add    rbx,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_1c22:
	/* 0x1c22: mov    QWORD PTR [rsp+0xd0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 893353197568ULL);
x86_l_1c2e:
	/* 0x1c2e: test   BYTE PTR [rsp+0x30],0x10 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430224ULL);
x86_l_1c33:
	/* 0x1c33: jne    242f <generic_rawtp_process_event+0x242f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c33, 0x242f, x86_l_242f);
x86_l_1c39:
	/* 0x1c39: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c3e:
	/* 0x1c3e: mov    r12d,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDX, X86_WIDTH_32);
x86_l_1c41:
	/* 0x1c41: and    edx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1c44:
	/* 0x1c44: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c46:
	/* 0x1c46: mov    rcx,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_1c49:
	/* 0x1c49: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1c4c:
	/* 0x1c4c: jle    26e5 <generic_rawtp_process_event+0x26e5> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1c4c, 0x26e5, x86_l_26e5);
x86_l_1c52:
	/* 0x1c52: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_1c55:
	/* 0x1c55: je     2f5f <generic_rawtp_process_event+0x2f5f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c55, 0x2f5f, x86_l_2f5f);
x86_l_1c5b:
	/* 0x1c5b: cmp    ecx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1c5e:
	/* 0x1c5e: je     2f68 <generic_rawtp_process_event+0x2f68> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c5e, 0x2f68, x86_l_2f68);
x86_l_1c64:
	/* 0x1c64: cmp    ecx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_1c67:
	/* 0x1c67: jne    2f7b <generic_rawtp_process_event+0x2f7b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c67, 0x2f7b, x86_l_2f7b);
x86_l_1c6d:
	/* 0x1c6d: lea    rax,[rbp+0x5e70] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24176ULL);
x86_l_1c74:
	/* 0x1c74: jmp    2f78 <generic_rawtp_process_event+0x2f78> */
	X86_SIM_X86_JMP(0x1c74, 0x2f78, x86_l_2f78);
x86_l_1c79:
	/* 0x1c79: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c7e:
	/* 0x1c7e: lea    rax,[r13+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c82:
	/* 0x1c82: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c87:
	/* 0x1c87: lea    rax,[r13+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c8b:
	/* 0x1c8b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c90:
	/* 0x1c90: mov    r15,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c95:
	/* 0x1c95: lea    rdx,[r15+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c99:
	/* 0x1c99: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1c9e:
	/* 0x1c9e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1ca3:
	/* 0x1ca3: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1ca6:
	/* 0x1ca6: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1cab:
	/* 0x1cab: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1cae:
	/* 0x1cae: call   1cb3 <generic_rawtp_process_event+0x1cb3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cb3:
	/* 0x1cb3: lea    rdi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cb7:
	/* 0x1cb7: lea    rdx,[r15+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1cbb:
	/* 0x1cbb: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1cc0:
	/* 0x1cc0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1cc5:
	/* 0x1cc5: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1cca:
	/* 0x1cca: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1ccd:
	/* 0x1ccd: call   1cd2 <generic_rawtp_process_event+0x1cd2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cd2:
	/* 0x1cd2: lea    rdi,[r13+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cd6:
	/* 0x1cd6: lea    rdx,[r15+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cda:
	/* 0x1cda: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1cdf:
	/* 0x1cdf: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1ce4:
	/* 0x1ce4: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ce9:
	/* 0x1ce9: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1cec:
	/* 0x1cec: call   1cf1 <generic_rawtp_process_event+0x1cf1> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cf1:
	/* 0x1cf1: lea    rdi,[r13+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1cf5:
	/* 0x1cf5: lea    rdx,[r15+0x1c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1cf9:
	/* 0x1cf9: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1cfe:
	/* 0x1cfe: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d03:
	/* 0x1d03: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1d08:
	/* 0x1d08: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1d0b:
	/* 0x1d0b: call   1d10 <generic_rawtp_process_event+0x1d10> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d10:
	/* 0x1d10: lea    rdi,[r13+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d14:
	/* 0x1d14: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d18:
	/* 0x1d18: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1d1d:
	/* 0x1d1d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d22:
	/* 0x1d22: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1d27:
	/* 0x1d27: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1d2a:
	/* 0x1d2a: call   1d2f <generic_rawtp_process_event+0x1d2f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d2f:
	/* 0x1d2f: lea    rdi,[r13+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d33:
	/* 0x1d33: lea    rdx,[r15+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1d37:
	/* 0x1d37: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1d3c:
	/* 0x1d3c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d41:
	/* 0x1d41: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1d46:
	/* 0x1d46: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1d49:
	/* 0x1d49: call   1d4e <generic_rawtp_process_event+0x1d4e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d4e:
	/* 0x1d4e: lea    rdi,[r13+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d52:
	/* 0x1d52: lea    rdx,[r15+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d56:
	/* 0x1d56: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1d5b:
	/* 0x1d5b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d60:
	/* 0x1d60: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1d65:
	/* 0x1d65: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1d68:
	/* 0x1d68: call   1d6d <generic_rawtp_process_event+0x1d6d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d6d:
	/* 0x1d6d: lea    rdi,[r13+0x1c] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1d71:
	/* 0x1d71: lea    rdx,[r15+0x24] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1d75:
	/* 0x1d75: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1d7a:
	/* 0x1d7a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d7f:
	/* 0x1d7f: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1d84:
	/* 0x1d84: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1d87:
	/* 0x1d87: call   1d8c <generic_rawtp_process_event+0x1d8c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d8c:
	/* 0x1d8c: mov    DWORD PTR [r13+0x24],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 154618822656ULL);
x86_l_1d94:
	/* 0x1d94: lea    rdi,[r13+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d98:
	/* 0x1d98: lea    rdx,[r15+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d9c:
	/* 0x1d9c: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1da1:
	/* 0x1da1: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1da6:
	/* 0x1da6: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1dab:
	/* 0x1dab: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1dae:
	/* 0x1dae: call   1db3 <generic_rawtp_process_event+0x1db3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1db3:
	/* 0x1db3: lea    rdi,[r13+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1db7:
	/* 0x1db7: lea    rdx,[r15+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1dbb:
	/* 0x1dbb: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1dc0:
	/* 0x1dc0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1dc5:
	/* 0x1dc5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1dca:
	/* 0x1dca: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1dcd:
	/* 0x1dcd: call   1dd2 <generic_rawtp_process_event+0x1dd2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1dd2:
	/* 0x1dd2: lea    rdi,[r13+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1dd6:
	/* 0x1dd6: lea    rdx,[r15+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1dda:
	/* 0x1dda: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1ddf:
	/* 0x1ddf: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1de4:
	/* 0x1de4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1de9:
	/* 0x1de9: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1dec:
	/* 0x1dec: call   1df1 <generic_rawtp_process_event+0x1df1> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1df1:
	/* 0x1df1: lea    rdx,[r15+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1df5:
	/* 0x1df5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1dfa:
	/* 0x1dfa: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1dff:
	/* 0x1dff: mov    rdi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e04:
	/* 0x1e04: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1e09:
	/* 0x1e09: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1e0c:
	/* 0x1e0c: call   1e11 <generic_rawtp_process_event+0x1e11> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e11:
	/* 0x1e11: add    r15,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_1e18:
	/* 0x1e18: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1e1d:
	/* 0x1e1d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1e22:
	/* 0x1e22: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1e27:
	/* 0x1e27: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1e2c:
	/* 0x1e2c: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1e2f:
	/* 0x1e2f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1e32:
	/* 0x1e32: call   1e37 <generic_rawtp_process_event+0x1e37> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e37:
	/* 0x1e37: mov    r15,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1e3c:
	/* 0x1e3c: lea    rdx,[r15+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1e43:
	/* 0x1e43: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1e48:
	/* 0x1e48: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1e4d:
	/* 0x1e4d: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1e52:
	/* 0x1e52: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1e57:
	/* 0x1e57: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1e5a:
	/* 0x1e5a: call   1e5f <generic_rawtp_process_event+0x1e5f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e5f:
	/* 0x1e5f: lea    rdi,[r13+0x44] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1e63:
	/* 0x1e63: lea    rdx,[r15+0xcc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_1e6a:
	/* 0x1e6a: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1e6f:
	/* 0x1e6f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1e74:
	/* 0x1e74: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1e79:
	/* 0x1e79: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1e7c:
	/* 0x1e7c: call   1e81 <generic_rawtp_process_event+0x1e81> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e81:
	/* 0x1e81: lea    rdi,[r13+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1e85:
	/* 0x1e85: lea    rdx,[r15+0xd0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1e8c:
	/* 0x1e8c: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1e91:
	/* 0x1e91: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1e96:
	/* 0x1e96: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1e9b:
	/* 0x1e9b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1e9e:
	/* 0x1e9e: call   1ea3 <generic_rawtp_process_event+0x1ea3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ea3:
	/* 0x1ea3: add    r13,0x4c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_1ea7:
	/* 0x1ea7: add    r15,0x158 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_1eae:
	/* 0x1eae: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1eb3:
	/* 0x1eb3: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1eb8:
	/* 0x1eb8: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1ebb:
	/* 0x1ebb: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ec0:
	/* 0x1ec0: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1ec3:
	/* 0x1ec3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1ec6:
	/* 0x1ec6: call   1ecb <generic_rawtp_process_event+0x1ecb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ecb:
	/* 0x1ecb: mov    r15d,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 80ULL);
x86_l_1ed1:
	/* 0x1ed1: jmp    259e <generic_rawtp_process_event+0x259e> */
	X86_SIM_X86_JMP(0x1ed1, 0x259e, x86_l_259e);
x86_l_1ed6:
	/* 0x1ed6: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1edb:
	/* 0x1edb: lea    rdx,[r13+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1ee2:
	/* 0x1ee2: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1ee7:
	/* 0x1ee7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1eec:
	/* 0x1eec: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ef1:
	/* 0x1ef1: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1ef4:
	/* 0x1ef4: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ef9:
	/* 0x1ef9: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1efc:
	/* 0x1efc: call   1f01 <generic_rawtp_process_event+0x1f01> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f01:
	/* 0x1f01: lea    rdi,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1f05:
	/* 0x1f05: lea    rdx,[r13+0xcc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_1f0c:
	/* 0x1f0c: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1f11:
	/* 0x1f11: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1f16:
	/* 0x1f16: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1f1b:
	/* 0x1f1b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1f1e:
	/* 0x1f1e: call   1f23 <generic_rawtp_process_event+0x1f23> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f23:
	/* 0x1f23: lea    rdi,[r15+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f27:
	/* 0x1f27: lea    rdx,[r13+0xd0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1f2e:
	/* 0x1f2e: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1f33:
	/* 0x1f33: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1f38:
	/* 0x1f38: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1f3d:
	/* 0x1f3d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1f40:
	/* 0x1f40: call   1f45 <generic_rawtp_process_event+0x1f45> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f45:
	/* 0x1f45: add    r15,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1f49:
	/* 0x1f49: add    r13,0x158 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_1f50:
	/* 0x1f50: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1f55:
	/* 0x1f55: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1f5a:
	/* 0x1f5a: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1f5d:
	/* 0x1f5d: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1f62:
	/* 0x1f62: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1f65:
	/* 0x1f65: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1f68:
	/* 0x1f68: call   1f6d <generic_rawtp_process_event+0x1f6d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f6d:
	/* 0x1f6d: mov    r15d,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 16ULL);
x86_l_1f73:
	/* 0x1f73: jmp    259e <generic_rawtp_process_event+0x259e> */
	X86_SIM_X86_JMP(0x1f73, 0x259e, x86_l_259e);
x86_l_1f78:
	/* 0x1f78: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f7d:
	/* 0x1f7d: lea    rdx,[r13+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1f81:
	/* 0x1f81: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1f86:
	/* 0x1f86: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1f8b:
	/* 0x1f8b: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f90:
	/* 0x1f90: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1f93:
	/* 0x1f93: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1f98:
	/* 0x1f98: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1f9b:
	/* 0x1f9b: call   1fa0 <generic_rawtp_process_event+0x1fa0> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1fa0:
	/* 0x1fa0: lea    rdi,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1fa4:
	/* 0x1fa4: lea    rdx,[r13+0x3c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1fa8:
	/* 0x1fa8: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1fad:
	/* 0x1fad: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1fb2:
	/* 0x1fb2: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1fb7:
	/* 0x1fb7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1fba:
	/* 0x1fba: call   1fbf <generic_rawtp_process_event+0x1fbf> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1fbf:
	/* 0x1fbf: lea    rdi,[r15+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fc3:
	/* 0x1fc3: lea    rdx,[r13+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1fc7:
	/* 0x1fc7: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1fcc:
	/* 0x1fcc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1fd1:
	/* 0x1fd1: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1fd6:
	/* 0x1fd6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1fd9:
	/* 0x1fd9: call   1fde <generic_rawtp_process_event+0x1fde> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1fde:
	/* 0x1fde: lea    rdi,[r15+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1fe2:
	/* 0x1fe2: lea    rdx,[r13+0x44] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1fe6:
	/* 0x1fe6: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1feb:
	/* 0x1feb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1ff0:
	/* 0x1ff0: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ff5:
	/* 0x1ff5: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_1ff8:
	/* 0x1ff8: call   1ffd <generic_rawtp_process_event+0x1ffd> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ffd:
	/* 0x1ffd: add    r15,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2001:
	/* 0x2001: sub    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_2005:
	/* 0x2005: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_200a:
	/* 0x200a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_200f:
	/* 0x200f: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2012:
	/* 0x2012: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2017:
	/* 0x2017: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_201a:
	/* 0x201a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_201d:
	/* 0x201d: call   2022 <generic_rawtp_process_event+0x2022> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2022:
	/* 0x2022: mov    r15d,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 32ULL);
x86_l_2028:
	/* 0x2028: jmp    259e <generic_rawtp_process_event+0x259e> */
	X86_SIM_X86_JMP(0x2028, 0x259e, x86_l_259e);
x86_l_202d:
	/* 0x202d: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_2032:
	/* 0x2032: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2037:
	/* 0x2037: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_203c:
	/* 0x203c: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2041:
	/* 0x2041: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2044:
	/* 0x2044: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_2049:
	/* 0x2049: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_204c:
	/* 0x204c: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_204f:
	/* 0x204f: call   2054 <generic_rawtp_process_event+0x2054> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2054:
	/* 0x2054: lea    rdi,[r15+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2058:
	/* 0x2058: lea    rdx,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_205c:
	/* 0x205c: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_2061:
	/* 0x2061: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2066:
	/* 0x2066: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_206b:
	/* 0x206b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_206e:
	/* 0x206e: call   2073 <generic_rawtp_process_event+0x2073> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2073:
	/* 0x2073: add    r15,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2077:
	/* 0x2077: add    r13,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_207b:
	/* 0x207b: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2080:
	/* 0x2080: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2085:
	/* 0x2085: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2088:
	/* 0x2088: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_208d:
	/* 0x208d: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_2090:
	/* 0x2090: jmp    2137 <generic_rawtp_process_event+0x2137> */
	X86_SIM_X86_JMP(0x2090, 0x2137, x86_l_2137);
x86_l_2095:
	/* 0x2095: lea    rdx,[r8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2099:
	/* 0x2099: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_209e:
	/* 0x209e: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_20a3:
	/* 0x20a3: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_20a8:
	/* 0x20a8: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_20ad:
	/* 0x20ad: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_20b0:
	/* 0x20b0: mov    r13,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R8, X86_WIDTH_64);
x86_l_20b3:
	/* 0x20b3: call   20b8 <generic_rawtp_process_event+0x20b8> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20b8:
	/* 0x20b8: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_20bc:
	/* 0x20bc: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20c1:
	/* 0x20c1: mov    DWORD PTR [r15],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c4:
	/* 0x20c4: lea    rdx,[r13+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20c8:
	/* 0x20c8: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_20cd:
	/* 0x20cd: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_20d2:
	/* 0x20d2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_20d7:
	/* 0x20d7: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_20dc:
	/* 0x20dc: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_20df:
	/* 0x20df: call   20e4 <generic_rawtp_process_event+0x20e4> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20e4:
	/* 0x20e4: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_20e8:
	/* 0x20e8: mov    DWORD PTR [r15+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_20ec:
	/* 0x20ec: add    r13,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_20f0:
	/* 0x20f0: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_20f5:
	/* 0x20f5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_20fa:
	/* 0x20fa: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_20ff:
	/* 0x20ff: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2104:
	/* 0x2104: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_2107:
	/* 0x2107: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_210a:
	/* 0x210a: call   210f <generic_rawtp_process_event+0x210f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_210f:
	/* 0x210f: add    r15,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2113:
	/* 0x2113: mov    edx,0x3e8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1000ULL);
x86_l_2118:
	/* 0x2118: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_211d:
	/* 0x211d: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2120:
	/* 0x2120: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2125:
	/* 0x2125: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_212a:
	/* 0x212a: add    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 104ULL);
x86_l_212f:
	/* 0x212f: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2132:
	/* 0x2132: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2137:
	/* 0x2137: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_213a:
	/* 0x213a: call   213f <generic_rawtp_process_event+0x213f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_213f:
	/* 0x213f: jmp    2598 <generic_rawtp_process_event+0x2598> */
	X86_SIM_X86_JMP(0x213f, 0x2598, x86_l_2598);
x86_l_2144:
	/* 0x2144: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2149:
	/* 0x2149: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_2151:
	/* 0x2151: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2159:
	/* 0x2159: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_2161:
	/* 0x2161: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2169:
	/* 0x2169: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2171:
	/* 0x2171: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2179:
	/* 0x2179: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2181:
	/* 0x2181: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2189:
	/* 0x2189: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2191:
	/* 0x2191: mov    QWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2198:
	/* 0x2198: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_219d:
	/* 0x219d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_21a2:
	/* 0x21a2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_21a7:
	/* 0x21a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21ac:
	/* 0x21ac: mov    rdx,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R8, X86_WIDTH_64);
x86_l_21af:
	/* 0x21af: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_21b2:
	/* 0x21b2: call   21b7 <generic_rawtp_process_event+0x21b7> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_21b7:
	/* 0x21b7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_21ba:
	/* 0x21ba: je     25a8 <generic_rawtp_process_event+0x25a8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ba, 0x25a8, x86_l_25a8);
x86_l_21c0:
	/* 0x21c0: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_21c3:
	/* 0x21c3: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21c8:
	/* 0x21c8: jmp    37bb <generic_rawtp_process_event+0x37bb> */
	X86_SIM_X86_JMP(0x21c8, 0x37bb, x86_l_37bb);
x86_l_21cd:
	/* 0x21cd: mov    r15,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_21d4:
	/* 0x21d4: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x21d4, 0x2e92, x86_l_2e92);
x86_l_21d9:
	/* 0x21d9: lea    rdx,[r12+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21de:
	/* 0x21de: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_21e6:
	/* 0x21e6: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_21eb:
	/* 0x21eb: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21f0:
	/* 0x21f0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_21f5:
	/* 0x21f5: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_21fa:
	/* 0x21fa: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21ff:
	/* 0x21ff: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2202:
	/* 0x2202: call   2207 <generic_rawtp_process_event+0x2207> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2207:
	/* 0x2207: add    r12,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_220b:
	/* 0x220b: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2210:
	/* 0x2210: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2215:
	/* 0x2215: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_221a:
	/* 0x221a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_221f:
	/* 0x221f: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_2222:
	/* 0x2222: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2225:
	/* 0x2225: call   222a <generic_rawtp_process_event+0x222a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_222a:
	/* 0x222a: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2232:
	/* 0x2232: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2237:
	/* 0x2237: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_223c:
	/* 0x223c: lea    r12,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2240:
	/* 0x2240: add    r12,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2247:
	/* 0x2247: test   BYTE PTR [rsp+0x40],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906976ULL);
x86_l_224c:
	/* 0x224c: je     2e47 <generic_rawtp_process_event+0x2e47> */
	X86_SIM_X86_JCC(X86_CC_E, 0x224c, 0x2e47, x86_l_2e47);
x86_l_2252:
	/* 0x2252: cmp    r14,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_64, 4096ULL);
x86_l_2259:
	/* 0x2259: jb     2e1b <generic_rawtp_process_event+0x2e1b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2259, 0x2e1b, x86_l_2e1b);
x86_l_225f:
	/* 0x225f: mov    DWORD PTR [r12],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2267:
	/* 0x2267: add    r12,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_226b:
	/* 0x226b: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_226e:
	/* 0x226e: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_2271:
	/* 0x2271: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
x86_l_2274:
	/* 0x2274: call   0 <generic_rawtp_process_event> */
	X86_SIM_X86_CALL(x86_l_3a51, 0x2279ULL);
x86_l_2279:
	/* 0x2279: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_227c:
	/* 0x227c: add    r15,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2280:
	/* 0x2280: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x2280, 0x2e92, x86_l_2e92);
x86_l_2285:
	/* 0x2285: mov    rbx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_228a:
	/* 0x228a: mov    DWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_2295:
	/* 0x2295: movzx  ebp,WORD PTR [rsp+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 192ULL);
x86_l_229d:
	/* 0x229d: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_ipv6_ext_heap));
x86_l_22a4:
	/* 0x22a4: lea    rsi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_22ac:
	/* 0x22ac: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_22b1:
	/* 0x22b1: lea    r13,[rbx+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_22b5:
	/* 0x22b5: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_22b8:
	/* 0x22b8: call   22bd <generic_rawtp_process_event+0x22bd> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_22bd:
	/* 0x22bd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_22c0:
	/* 0x22c0: je     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c0, 0x35b3, x86_l_35b3);
x86_l_22c6:
	/* 0x22c6: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_22c9:
	/* 0x22c9: mov    WORD PTR [rax],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22cc:
	/* 0x22cc: mov    BYTE PTR [rax+0x5],0xff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 21474836735ULL);
x86_l_22d0:
	/* 0x22d0: mov    BYTE PTR [rax+0x7],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_22d4:
	/* 0x22d4: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_22d7:
	/* 0x22d7: add    rdi,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_22db:
	/* 0x22db: lea    rdx,[r13+0x6] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_22df:
	/* 0x22df: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_22e4:
	/* 0x22e4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_22e9:
	/* 0x22e9: mov    QWORD PTR [rsp+0x20],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22ee:
	/* 0x22ee: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_22f3:
	/* 0x22f3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_22f6:
	/* 0x22f6: call   22fb <generic_rawtp_process_event+0x22fb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_22fb:
	/* 0x22fb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_22fe:
	/* 0x22fe: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22fe, 0x35b3, x86_l_35b3);
x86_l_2304:
	/* 0x2304: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2309:
	/* 0x2309: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_230c:
	/* 0x230c: jg     2e9c <generic_rawtp_process_event+0x2e9c> */
	X86_SIM_X86_JCC(X86_CC_G, 0x230c, 0x2e9c, x86_l_2e9c);
x86_l_2312:
	/* 0x2312: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2314:
	/* 0x2314: je     2f4e <generic_rawtp_process_event+0x2f4e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2314, 0x2f4e, x86_l_2f4e);
x86_l_231a:
	/* 0x231a: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_231d:
	/* 0x231d: je     2f4e <generic_rawtp_process_event+0x2f4e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x231d, 0x2f4e, x86_l_2f4e);
x86_l_2323:
	/* 0x2323: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_2326:
	/* 0x2326: jne    312e <generic_rawtp_process_event+0x312e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2326, 0x312e, x86_l_312e);
x86_l_232c:
	/* 0x232c: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_2333:
	/* 0x2333: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_2337:
	/* 0x2337: jmp    3077 <generic_rawtp_process_event+0x3077> */
	X86_SIM_X86_JMP(0x2337, 0x3077, x86_l_3077);
x86_l_233c:
	/* 0x233c: lea    rdx,[r15+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2340:
	/* 0x2340: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2345:
	/* 0x2345: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_234a:
	/* 0x234a: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_234d:
	/* 0x234d: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2352:
	/* 0x2352: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2355:
	/* 0x2355: call   235a <generic_rawtp_process_event+0x235a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_235a:
	/* 0x235a: lea    rdx,[r15+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_235e:
	/* 0x235e: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2363:
	/* 0x2363: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2368:
	/* 0x2368: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_236b:
	/* 0x236b: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2370:
	/* 0x2370: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2373:
	/* 0x2373: call   2378 <generic_rawtp_process_event+0x2378> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2378:
	/* 0x2378: lea    rdi,[r13+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_237c:
	/* 0x237c: lea    r12,[r15+0xc] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2380:
	/* 0x2380: add    r15,0xe */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 14ULL);
x86_l_2384:
	/* 0x2384: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2389:
	/* 0x2389: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_238e:
	/* 0x238e: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_2393:
	/* 0x2393: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2396:
	/* 0x2396: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2399:
	/* 0x2399: call   239e <generic_rawtp_process_event+0x239e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_239e:
	/* 0x239e: lea    rdi,[r13+0x22] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_23a2:
	/* 0x23a2: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_23a7:
	/* 0x23a7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_23ac:
	/* 0x23ac: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_23b1:
	/* 0x23b1: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_23b4:
	/* 0x23b4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_23b7:
	/* 0x23b7: call   23bc <generic_rawtp_process_event+0x23bc> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23bc:
	/* 0x23bc: movzx  eax,WORD PTR [r13+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_23c1:
	/* 0x23c1: movbe  WORD PTR [r13+0x22],ax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_23c8:
	/* 0x23c8: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_23cd:
	/* 0x23cd: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_23d2:
	/* 0x23d2: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)socktrack_map));
x86_l_23d9:
	/* 0x23d9: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_23de:
	/* 0x23de: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_23e3:
	/* 0x23e3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_23e6:
	/* 0x23e6: call   23eb <generic_rawtp_process_event+0x23eb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23eb:
	/* 0x23eb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_23ee:
	/* 0x23ee: je     2408 <generic_rawtp_process_event+0x2408> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ee, 0x2408, x86_l_2408);
x86_l_23f0:
	/* 0x23f0: mov    ecx,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f2:
	/* 0x23f2: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23f7:
	/* 0x23f7: mov    DWORD PTR [rdx+0x10],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23fa:
	/* 0x23fa: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23fe:
	/* 0x23fe: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2402:
	/* 0x2402: mov    eax,DWORD PTR [rax+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2405:
	/* 0x2405: mov    DWORD PTR [rdx+0x7c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_2408:
	/* 0x2408: mov    r15d,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 64ULL);
x86_l_240e:
	/* 0x240e: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x240e, 0x2e92, x86_l_2e92);
x86_l_2413:
	/* 0x2413: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2418:
	/* 0x2418: mov    QWORD PTR [rbp+rax*1+0x90],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 618475290624ULL);
x86_l_2424:
	/* 0x2424: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_242a:
	/* 0x242a: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x242a, 0x2e92, x86_l_2e92);
x86_l_242f:
	/* 0x242f: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_2434:
	/* 0x2434: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2437:
	/* 0x2437: call   243c <generic_rawtp_process_event+0x243c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_243c:
	/* 0x243c: cmp    rax,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551594ULL);
x86_l_2440:
	/* 0x2440: jne    246c <generic_rawtp_process_event+0x246c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2440, 0x246c, x86_l_246c);
x86_l_2442:
	/* 0x2442: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2447:
	/* 0x2447: lea    rdx,[rax+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_244b:
	/* 0x244b: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2450:
	/* 0x2450: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2455:
	/* 0x2455: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_245a:
	/* 0x245a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_245f:
	/* 0x245f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2462:
	/* 0x2462: call   2467 <generic_rawtp_process_event+0x2467> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2467:
	/* 0x2467: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_246c:
	/* 0x246c: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2470:
	/* 0x2470: mov    rdx,QWORD PTR [rbp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2474:
	/* 0x2474: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2479:
	/* 0x2479: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_247e:
	/* 0x247e: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2483:
	/* 0x2483: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_248c:
	/* 0x248c: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2494:
	/* 0x2494: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_249c:
	/* 0x249c: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)retprobe_map));
x86_l_24a3:
	/* 0x24a3: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24a5:
	/* 0x24a5: lea    rsi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_24ad:
	/* 0x24ad: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_24b2:
	/* 0x24b2: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_24b7:
	/* 0x24b7: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24b9:
	/* 0x24b9: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_24bc:
	/* 0x24bc: call   24c1 <generic_rawtp_process_event+0x24c1> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_24c1:
	/* 0x24c1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_24c4:
	/* 0x24c4: je     2ef9 <generic_rawtp_process_event+0x2ef9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c4, 0x2ef9, x86_l_2ef9);
x86_l_24ca:
	/* 0x24ca: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_24cc:
	/* 0x24cc: mov    WORD PTR [rsp+0x58],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_24d1:
	/* 0x24d1: mov    WORD PTR [rsp+0x5a],0x5 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 386547056645ULL);
x86_l_24d8:
	/* 0x24d8: movabs rax,0x200000046 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8589934662ULL);
x86_l_24e2:
	/* 0x24e2: mov    QWORD PTR [rsp+0x5c],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_24e7:
	/* 0x24e7: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_24ee:
	/* 0x24ee: lea    rsi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_24f3:
	/* 0x24f3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_24f8:
	/* 0x24f8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_24fb:
	/* 0x24fb: call   2500 <generic_rawtp_process_event+0x2500> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2500:
	/* 0x2500: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2503:
	/* 0x2503: je     2ec9 <generic_rawtp_process_event+0x2ec9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2503, 0x2ec9, x86_l_2ec9);
x86_l_2509:
	/* 0x2509: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_250b:
	/* 0x250b: jmp    2ef9 <generic_rawtp_process_event+0x2ef9> */
	X86_SIM_X86_JMP(0x250b, 0x2ef9, x86_l_2ef9);
x86_l_2510:
	/* 0x2510: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2513:
	/* 0x2513: je     2800 <generic_rawtp_process_event+0x2800> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2513, 0x2800, x86_l_2800);
x86_l_2519:
	/* 0x2519: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_251c:
	/* 0x251c: jne    2c94 <generic_rawtp_process_event+0x2c94> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x251c, 0x2c94, x86_l_2c94);
x86_l_2522:
	/* 0x2522: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2527:
	/* 0x2527: add    rax,0x5e58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 24152ULL);
x86_l_252d:
	/* 0x252d: jmp    280b <generic_rawtp_process_event+0x280b> */
	X86_SIM_X86_JMP(0x252d, 0x280b, x86_l_280b);
x86_l_2532:
	/* 0x2532: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2537:
	/* 0x2537: lea    rdi,[r12+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_253c:
	/* 0x253c: lea    rdx,[r15+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2540:
	/* 0x2540: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2545:
	/* 0x2545: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_254a:
	/* 0x254a: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_254f:
	/* 0x254f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2552:
	/* 0x2552: call   2557 <generic_rawtp_process_event+0x2557> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2557:
	/* 0x2557: lea    rdi,[r12+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_255c:
	/* 0x255c: add    r15,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_2560:
	/* 0x2560: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2565:
	/* 0x2565: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_256a:
	/* 0x256a: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_256f:
	/* 0x256f: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2572:
	/* 0x2572: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2575:
	/* 0x2575: call   257a <generic_rawtp_process_event+0x257a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_257a:
	/* 0x257a: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_257f:
	/* 0x257f: movzx  eax,WORD PTR [rcx+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_2583:
	/* 0x2583: movbe  WORD PTR [rcx+0x2],ax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_2589:
	/* 0x2589: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_258e:
	/* 0x258e: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2593:
	/* 0x2593: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2598:
	/* 0x2598: mov    r15d,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 24ULL);
x86_l_259e:
	/* 0x259e: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a3:
	/* 0x25a3: jmp    d39 <generic_rawtp_process_event+0xd39> */
	X86_SIM_X86_JMP(0x25a3, 0xd39, x86_l_d39);
x86_l_25a8:
	/* 0x25a8: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25ad:
	/* 0x25ad: lea    rdi,[rax+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25b1:
	/* 0x25b1: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_25b6:
	/* 0x25b6: mov    edx,0x3f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 63ULL);
x86_l_25bb:
	/* 0x25bb: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_25c0:
	/* 0x25c0: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_25c5:
	/* 0x25c5: mov    esi,0x3f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 63ULL);
x86_l_25ca:
	/* 0x25ca: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_25cd:
	/* 0x25cd: call   25d2 <generic_rawtp_process_event+0x25d2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25d2:
	/* 0x25d2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_25d5:
	/* 0x25d5: js     21c0 <generic_rawtp_process_event+0x21c0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25d5, 0x21c0, x86_l_21c0);
x86_l_25db:
	/* 0x25db: mov    r15,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25e0:
	/* 0x25e0: lea    rdx,[r15+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25e4:
	/* 0x25e4: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_25ec:
	/* 0x25ec: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_25f1:
	/* 0x25f1: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_25f6:
	/* 0x25f6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_25fb:
	/* 0x25fb: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_25fe:
	/* 0x25fe: call   2603 <generic_rawtp_process_event+0x2603> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2603:
	/* 0x2603: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2608:
	/* 0x2608: lea    rdi,[rax+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_260c:
	/* 0x260c: mov    edx,0x348 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 840ULL);
x86_l_2611:
	/* 0x2611: mov    rcx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2619:
	/* 0x2619: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_261c:
	/* 0x261c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2621:
	/* 0x2621: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2626:
	/* 0x2626: add    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 168ULL);
x86_l_262e:
	/* 0x262e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2633:
	/* 0x2633: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2636:
	/* 0x2636: call   263b <generic_rawtp_process_event+0x263b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_263b:
	/* 0x263b: add    r15,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_263f:
	/* 0x263f: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2647:
	/* 0x2647: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_264c:
	/* 0x264c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2651:
	/* 0x2651: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_2656:
	/* 0x2656: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2659:
	/* 0x2659: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_265c:
	/* 0x265c: call   2661 <generic_rawtp_process_event+0x2661> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2661:
	/* 0x2661: mov    r15d,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 80ULL);
x86_l_2667:
	/* 0x2667: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_266a:
	/* 0x266a: jne    21c3 <generic_rawtp_process_event+0x21c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x266a, 0x21c3, x86_l_21c3);
x86_l_2670:
	/* 0x2670: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2672:
	/* 0x2672: cmp    DWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_267a:
	/* 0x267a: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_267d:
	/* 0x267d: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2682:
	/* 0x2682: mov    DWORD PTR [rcx],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2684:
	/* 0x2684: jmp    21c3 <generic_rawtp_process_event+0x21c3> */
	X86_SIM_X86_JMP(0x2684, 0x21c3, x86_l_21c3);
x86_l_2689:
	/* 0x2689: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_268c:
	/* 0x268c: mov    rcx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_64);
x86_l_268f:
	/* 0x268f: mov    r12,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_R13, X86_WIDTH_64);
x86_l_2692:
	/* 0x2692: jmp    37bb <generic_rawtp_process_event+0x37bb> */
	X86_SIM_X86_JMP(0x2692, 0x37bb, x86_l_37bb);
x86_l_2697:
	/* 0x2697: add    r15,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 3ULL);
x86_l_269b:
	/* 0x269b: mov    ecx,0x6b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 107ULL);
x86_l_26a0:
	/* 0x26a0: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_26a5:
	/* 0x26a5: mov    esi,0x6b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 107ULL);
x86_l_26aa:
	/* 0x26aa: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_26ad:
	/* 0x26ad: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_26b0:
	/* 0x26b0: call   26b5 <generic_rawtp_process_event+0x26b5> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26b5:
	/* 0x26b5: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_26b8:
	/* 0x26b8: mov    al,0x6b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_8, 107ULL);
x86_l_26ba:
	/* 0x26ba: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_26bc:
	/* 0x26bc: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26c1:
	/* 0x26c1: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_26c6:
	/* 0x26c6: js     26d0 <generic_rawtp_process_event+0x26d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26c6, 0x26d0, x86_l_26d0);
x86_l_26c8:
	/* 0x26c8: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26cd:
	/* 0x26cd: mov    BYTE PTR [rcx+0x3],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_26d0:
	/* 0x26d0: mov    r15d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 112ULL);
x86_l_26d6:
	/* 0x26d6: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26db:
	/* 0x26db: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_26e0:
	/* 0x26e0: jmp    d39 <generic_rawtp_process_event+0xd39> */
	X86_SIM_X86_JMP(0x26e0, 0xd39, x86_l_d39);
x86_l_26e5:
	/* 0x26e5: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_26e8:
	/* 0x26e8: je     2f71 <generic_rawtp_process_event+0x2f71> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e8, 0x2f71, x86_l_2f71);
x86_l_26ee:
	/* 0x26ee: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_26f1:
	/* 0x26f1: jne    2f7b <generic_rawtp_process_event+0x2f7b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26f1, 0x2f7b, x86_l_2f7b);
x86_l_26f7:
	/* 0x26f7: lea    rax,[rbp+0x5e58] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24152ULL);
x86_l_26fe:
	/* 0x26fe: jmp    2f78 <generic_rawtp_process_event+0x2f78> */
	X86_SIM_X86_JMP(0x26fe, 0x2f78, x86_l_2f78);
x86_l_2703:
	/* 0x2703: lea    rdx,[r15+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2707:
	/* 0x2707: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_270c:
	/* 0x270c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2711:
	/* 0x2711: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2716:
	/* 0x2716: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_271b:
	/* 0x271b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_271e:
	/* 0x271e: call   2723 <generic_rawtp_process_event+0x2723> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2723:
	/* 0x2723: lea    rdx,[r15+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2727:
	/* 0x2727: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_272c:
	/* 0x272c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2731:
	/* 0x2731: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_2734:
	/* 0x2734: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2739:
	/* 0x2739: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_273c:
	/* 0x273c: call   2741 <generic_rawtp_process_event+0x2741> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2741:
	/* 0x2741: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2746:
	/* 0x2746: lea    rdi,[rbp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_274a:
	/* 0x274a: lea    r12,[r15+0xc] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_274e:
	/* 0x274e: add    r15,0xe */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 14ULL);
x86_l_2752:
	/* 0x2752: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2757:
	/* 0x2757: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_275c:
	/* 0x275c: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_2761:
	/* 0x2761: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2764:
	/* 0x2764: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2767:
	/* 0x2767: call   276c <generic_rawtp_process_event+0x276c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_276c:
	/* 0x276c: lea    rdi,[rbp+0x22] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_2770:
	/* 0x2770: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2775:
	/* 0x2775: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_277a:
	/* 0x277a: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_277f:
	/* 0x277f: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_2782:
	/* 0x2782: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2785:
	/* 0x2785: call   278a <generic_rawtp_process_event+0x278a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_278a:
	/* 0x278a: movzx  eax,WORD PTR [rbp+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_278e:
	/* 0x278e: movbe  WORD PTR [rbp+0x22],ax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_2794:
	/* 0x2794: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2799:
	/* 0x2799: mov    rax,QWORD PTR [rax+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_279d:
	/* 0x279d: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_27a2:
	/* 0x27a2: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)socktrack_map));
x86_l_27a9:
	/* 0x27a9: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_27ae:
	/* 0x27ae: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_27b3:
	/* 0x27b3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_27b6:
	/* 0x27b6: call   27bb <generic_rawtp_process_event+0x27bb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_27bb:
	/* 0x27bb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_27be:
	/* 0x27be: je     27d8 <generic_rawtp_process_event+0x27d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27be, 0x27d8, x86_l_27d8);
x86_l_27c0:
	/* 0x27c0: mov    ecx,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c2:
	/* 0x27c2: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_27c7:
	/* 0x27c7: mov    DWORD PTR [rdx+0x10],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27ca:
	/* 0x27ca: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27ce:
	/* 0x27ce: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_27d2:
	/* 0x27d2: mov    eax,DWORD PTR [rax+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_27d5:
	/* 0x27d5: mov    DWORD PTR [rdx+0x7c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_27d8:
	/* 0x27d8: mov    r15d,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 64ULL);
x86_l_27de:
	/* 0x27de: mov    rcx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R13, X86_WIDTH_64);
x86_l_27e1:
	/* 0x27e1: jmp    37b6 <generic_rawtp_process_event+0x37b6> */
	X86_SIM_X86_JMP(0x27e1, 0x37b6, x86_l_37b6);
x86_l_27e6:
	/* 0x27e6: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_27eb:
	/* 0x27eb: add    rax,0x5e60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 24160ULL);
x86_l_27f1:
	/* 0x27f1: jmp    280b <generic_rawtp_process_event+0x280b> */
	X86_SIM_X86_JMP(0x27f1, 0x280b, x86_l_280b);
x86_l_27f3:
	/* 0x27f3: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_27f8:
	/* 0x27f8: add    rax,0x5e68 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 24168ULL);
x86_l_27fe:
	/* 0x27fe: jmp    280b <generic_rawtp_process_event+0x280b> */
	X86_SIM_X86_JMP(0x27fe, 0x280b, x86_l_280b);
x86_l_2800:
	/* 0x2800: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2805:
	/* 0x2805: add    rax,0x5e50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 24144ULL);
x86_l_280b:
	/* 0x280b: mov    r12,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280e:
	/* 0x280e: test   BYTE PTR [rsp+0x40],0x10 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906960ULL);
x86_l_2813:
	/* 0x2813: jne    2cac <generic_rawtp_process_event+0x2cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2813, 0x2cac, x86_l_2cac);
x86_l_2819:
	/* 0x2819: test   r12,r12 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64);
x86_l_281c:
	/* 0x281c: je     2d89 <generic_rawtp_process_event+0x2d89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281c, 0x2d89, x86_l_2d89);
x86_l_2822:
	/* 0x2822: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2827:
	/* 0x2827: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_282d:
	/* 0x282d: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2832:
	/* 0x2832: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2837:
	/* 0x2837: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_283c:
	/* 0x283c: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2841:
	/* 0x2841: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2844:
	/* 0x2844: call   2849 <generic_rawtp_process_event+0x2849> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2849:
	/* 0x2849: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_284e:
	/* 0x284e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2850:
	/* 0x2850: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2850, 0x2c86, x86_l_2c86);
x86_l_2856:
	/* 0x2856: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_285b:
	/* 0x285b: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_2860:
	/* 0x2860: mov    rax,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_2863:
	/* 0x2863: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2868:
	/* 0x2868: cmp    rdx,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 4094ULL);
x86_l_286f:
	/* 0x286f: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x286f, 0x2c86, x86_l_2c86);
x86_l_2875:
	/* 0x2875: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_287a:
	/* 0x287a: lea    rdi,[rax+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_287e:
	/* 0x287e: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_2881:
	/* 0x2881: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2887:
	/* 0x2887: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_288a:
	/* 0x288a: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_288f:
	/* 0x288f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2894:
	/* 0x2894: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2899:
	/* 0x2899: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_289e:
	/* 0x289e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_28a1:
	/* 0x28a1: call   28a6 <generic_rawtp_process_event+0x28a6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28a6:
	/* 0x28a6: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_28ab:
	/* 0x28ab: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_28ad:
	/* 0x28ad: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28ad, 0x2c86, x86_l_2c86);
x86_l_28b3:
	/* 0x28b3: cmp    r12,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 1ULL);
x86_l_28b7:
	/* 0x28b7: je     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28b7, 0x2d90, x86_l_2d90);
x86_l_28bd:
	/* 0x28bd: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28c2:
	/* 0x28c2: lea    rdx,[rax+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c6:
	/* 0x28c6: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_28cb:
	/* 0x28cb: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_28d1:
	/* 0x28d1: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_28d6:
	/* 0x28d6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_28db:
	/* 0x28db: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_28e0:
	/* 0x28e0: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_28e3:
	/* 0x28e3: call   28e8 <generic_rawtp_process_event+0x28e8> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28e8:
	/* 0x28e8: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_28ed:
	/* 0x28ed: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_28ef:
	/* 0x28ef: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28ef, 0x2c86, x86_l_2c86);
x86_l_28f5:
	/* 0x28f5: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_28fa:
	/* 0x28fa: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_28ff:
	/* 0x28ff: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2904:
	/* 0x2904: cmp    rax,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4094ULL);
x86_l_290a:
	/* 0x290a: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x290a, 0x2c86, x86_l_2c86);
x86_l_2910:
	/* 0x2910: add    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2915:
	/* 0x2915: mov    QWORD PTR [rsp+0x40],r14 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_291a:
	/* 0x291a: mov    edi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_32);
x86_l_291d:
	/* 0x291d: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2923:
	/* 0x2923: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2926:
	/* 0x2926: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_292b:
	/* 0x292b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2930:
	/* 0x2930: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2935:
	/* 0x2935: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_293a:
	/* 0x293a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_293d:
	/* 0x293d: call   2942 <generic_rawtp_process_event+0x2942> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2942:
	/* 0x2942: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2947:
	/* 0x2947: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2949:
	/* 0x2949: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2949, 0x2c86, x86_l_2c86);
x86_l_294f:
	/* 0x294f: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2954:
	/* 0x2954: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2959:
	/* 0x2959: cmp    r12,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 3ULL);
x86_l_295d:
	/* 0x295d: jb     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_B, 0x295d, 0x2d90, x86_l_2d90);
x86_l_2963:
	/* 0x2963: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2968:
	/* 0x2968: lea    rdx,[rax+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_296c:
	/* 0x296c: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2971:
	/* 0x2971: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2977:
	/* 0x2977: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_297c:
	/* 0x297c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2981:
	/* 0x2981: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2986:
	/* 0x2986: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2989:
	/* 0x2989: call   298e <generic_rawtp_process_event+0x298e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_298e:
	/* 0x298e: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2993:
	/* 0x2993: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2995:
	/* 0x2995: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2995, 0x2c86, x86_l_2c86);
x86_l_299b:
	/* 0x299b: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_29a0:
	/* 0x29a0: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_29a5:
	/* 0x29a5: mov    QWORD PTR [rsp+0xe0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_29ad:
	/* 0x29ad: cmp    rax,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4094ULL);
x86_l_29b3:
	/* 0x29b3: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x29b3, 0x2c86, x86_l_2c86);
x86_l_29b9:
	/* 0x29b9: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29be:
	/* 0x29be: add    rdi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 64ULL);
x86_l_29c3:
	/* 0x29c3: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_29c6:
	/* 0x29c6: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_29cc:
	/* 0x29cc: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_29cf:
	/* 0x29cf: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_29d4:
	/* 0x29d4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_29d9:
	/* 0x29d9: mov    rsi,QWORD PTR [rsp+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_29e1:
	/* 0x29e1: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_29e6:
	/* 0x29e6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_29e9:
	/* 0x29e9: call   29ee <generic_rawtp_process_event+0x29ee> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29ee:
	/* 0x29ee: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_29f3:
	/* 0x29f3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_29f5:
	/* 0x29f5: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29f5, 0x2c86, x86_l_2c86);
x86_l_29fb:
	/* 0x29fb: mov    rax,QWORD PTR [rsp+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2a03:
	/* 0x2a03: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2a08:
	/* 0x2a08: cmp    r12,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 3ULL);
x86_l_2a0c:
	/* 0x2a0c: je     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a0c, 0x2d90, x86_l_2d90);
x86_l_2a12:
	/* 0x2a12: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a17:
	/* 0x2a17: lea    rdx,[rax+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a1b:
	/* 0x2a1b: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2a20:
	/* 0x2a20: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2a26:
	/* 0x2a26: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2a2b:
	/* 0x2a2b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2a30:
	/* 0x2a30: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2a35:
	/* 0x2a35: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2a38:
	/* 0x2a38: call   2a3d <generic_rawtp_process_event+0x2a3d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a3d:
	/* 0x2a3d: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2a42:
	/* 0x2a42: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2a44:
	/* 0x2a44: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a44, 0x2c86, x86_l_2c86);
x86_l_2a4a:
	/* 0x2a4a: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2a4f:
	/* 0x2a4f: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_2a54:
	/* 0x2a54: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a59:
	/* 0x2a59: cmp    rax,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4094ULL);
x86_l_2a5f:
	/* 0x2a5f: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a5f, 0x2c86, x86_l_2c86);
x86_l_2a65:
	/* 0x2a65: mov    rdi,QWORD PTR [rsp+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2a6d:
	/* 0x2a6d: add    rdi,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2a70:
	/* 0x2a70: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_2a73:
	/* 0x2a73: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a79:
	/* 0x2a79: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2a7c:
	/* 0x2a7c: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2a81:
	/* 0x2a81: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2a86:
	/* 0x2a86: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a8b:
	/* 0x2a8b: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2a90:
	/* 0x2a90: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2a93:
	/* 0x2a93: call   2a98 <generic_rawtp_process_event+0x2a98> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a98:
	/* 0x2a98: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2a9d:
	/* 0x2a9d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2a9f:
	/* 0x2a9f: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a9f, 0x2c86, x86_l_2c86);
x86_l_2aa5:
	/* 0x2aa5: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2aaa:
	/* 0x2aaa: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2aaf:
	/* 0x2aaf: cmp    r12,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 5ULL);
x86_l_2ab3:
	/* 0x2ab3: jb     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2ab3, 0x2d90, x86_l_2d90);
x86_l_2ab9:
	/* 0x2ab9: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2abe:
	/* 0x2abe: lea    rdx,[rax+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2ac2:
	/* 0x2ac2: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2ac7:
	/* 0x2ac7: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2acd:
	/* 0x2acd: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2ad2:
	/* 0x2ad2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2ad7:
	/* 0x2ad7: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2adc:
	/* 0x2adc: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2adf:
	/* 0x2adf: call   2ae4 <generic_rawtp_process_event+0x2ae4> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ae4:
	/* 0x2ae4: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2ae9:
	/* 0x2ae9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2aeb:
	/* 0x2aeb: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2aeb, 0x2c86, x86_l_2c86);
x86_l_2af1:
	/* 0x2af1: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2af6:
	/* 0x2af6: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_2afb:
	/* 0x2afb: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b00:
	/* 0x2b00: cmp    rax,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4094ULL);
x86_l_2b06:
	/* 0x2b06: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b06, 0x2c86, x86_l_2c86);
x86_l_2b0c:
	/* 0x2b0c: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b11:
	/* 0x2b11: add    rdi,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2b14:
	/* 0x2b14: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_2b17:
	/* 0x2b17: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2b1d:
	/* 0x2b1d: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2b20:
	/* 0x2b20: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2b25:
	/* 0x2b25: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2b2a:
	/* 0x2b2a: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b2f:
	/* 0x2b2f: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2b34:
	/* 0x2b34: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2b37:
	/* 0x2b37: call   2b3c <generic_rawtp_process_event+0x2b3c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b3c:
	/* 0x2b3c: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2b41:
	/* 0x2b41: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b43:
	/* 0x2b43: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b43, 0x2c86, x86_l_2c86);
x86_l_2b49:
	/* 0x2b49: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b4e:
	/* 0x2b4e: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2b53:
	/* 0x2b53: cmp    r12,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 5ULL);
x86_l_2b57:
	/* 0x2b57: je     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b57, 0x2d90, x86_l_2d90);
x86_l_2b5d:
	/* 0x2b5d: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b62:
	/* 0x2b62: lea    rdx,[rax+0x50] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b66:
	/* 0x2b66: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2b6b:
	/* 0x2b6b: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2b71:
	/* 0x2b71: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2b76:
	/* 0x2b76: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2b7b:
	/* 0x2b7b: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2b80:
	/* 0x2b80: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2b83:
	/* 0x2b83: call   2b88 <generic_rawtp_process_event+0x2b88> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b88:
	/* 0x2b88: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2b8d:
	/* 0x2b8d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b8f:
	/* 0x2b8f: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b8f, 0x2c86, x86_l_2c86);
x86_l_2b95:
	/* 0x2b95: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2b9a:
	/* 0x2b9a: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_2b9f:
	/* 0x2b9f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ba4:
	/* 0x2ba4: cmp    rax,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4094ULL);
x86_l_2baa:
	/* 0x2baa: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2baa, 0x2c86, x86_l_2c86);
x86_l_2bb0:
	/* 0x2bb0: mov    rdi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2bb5:
	/* 0x2bb5: add    rdi,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2bb8:
	/* 0x2bb8: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_2bbb:
	/* 0x2bbb: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2bc1:
	/* 0x2bc1: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2bc4:
	/* 0x2bc4: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2bc9:
	/* 0x2bc9: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2bce:
	/* 0x2bce: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2bd3:
	/* 0x2bd3: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2bd8:
	/* 0x2bd8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2bdb:
	/* 0x2bdb: call   2be0 <generic_rawtp_process_event+0x2be0> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2be0:
	/* 0x2be0: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2be5:
	/* 0x2be5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2be7:
	/* 0x2be7: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2be7, 0x2c86, x86_l_2c86);
x86_l_2bed:
	/* 0x2bed: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2bf2:
	/* 0x2bf2: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2bf7:
	/* 0x2bf7: cmp    r12,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 7ULL);
x86_l_2bfb:
	/* 0x2bfb: jb     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2bfb, 0x2d90, x86_l_2d90);
x86_l_2c01:
	/* 0x2c01: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c06:
	/* 0x2c06: add    rdx,0x60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_2c0a:
	/* 0x2c0a: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2c0f:
	/* 0x2c0f: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2c15:
	/* 0x2c15: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_2c1a:
	/* 0x2c1a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2c1f:
	/* 0x2c1f: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2c24:
	/* 0x2c24: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2c27:
	/* 0x2c27: call   2c2c <generic_rawtp_process_event+0x2c2c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c2c:
	/* 0x2c2c: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2c31:
	/* 0x2c31: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2c33:
	/* 0x2c33: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c33, 0x2c86, x86_l_2c86);
x86_l_2c35:
	/* 0x2c35: mov    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2c3a:
	/* 0x2c3a: mov    ecx,0xfffffffd */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967293ULL);
x86_l_2c3f:
	/* 0x2c3f: cmp    r12,0xffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_64, 4094ULL);
x86_l_2c46:
	/* 0x2c46: ja     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c46, 0x2c86, x86_l_2c86);
x86_l_2c48:
	/* 0x2c48: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c4d:
	/* 0x2c4d: add    rdi,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2c50:
	/* 0x2c50: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2c56:
	/* 0x2c56: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2c59:
	/* 0x2c59: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2c5e:
	/* 0x2c5e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2c63:
	/* 0x2c63: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2c68:
	/* 0x2c68: mov    esi,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_32);
x86_l_2c6b:
	/* 0x2c6b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2c6e:
	/* 0x2c6e: call   2c73 <generic_rawtp_process_event+0x2c73> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c73:
	/* 0x2c73: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_2c78:
	/* 0x2c78: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2c7a:
	/* 0x2c7a: js     2c86 <generic_rawtp_process_event+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c7a, 0x2c86, x86_l_2c86);
x86_l_2c7c:
	/* 0x2c7c: add    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RSP, X86_R12, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2c81:
	/* 0x2c81: jmp    2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JMP(0x2c81, 0x2d90, x86_l_2d90);
x86_l_2c86:
	/* 0x2c86: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2c8b:
	/* 0x2c8b: mov    DWORD PTR [rbp+rax*1+0x0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2c8f:
	/* 0x2c8f: jmp    2f41 <generic_rawtp_process_event+0x2f41> */
	X86_SIM_X86_JMP(0x2c8f, 0x2f41, x86_l_2f41);
x86_l_2c94:
	/* 0x2c94: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2c97:
	/* 0x2c97: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_2c9c:
	/* 0x2c9c: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ca1:
	/* 0x2ca1: test   BYTE PTR [rsp+0x40],0x10 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906960ULL);
x86_l_2ca6:
	/* 0x2ca6: je     2d90 <generic_rawtp_process_event+0x2d90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ca6, 0x2d90, x86_l_2d90);
x86_l_2cac:
	/* 0x2cac: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_2cb1:
	/* 0x2cb1: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2cb4:
	/* 0x2cb4: call   2cb9 <generic_rawtp_process_event+0x2cb9> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2cb9:
	/* 0x2cb9: cmp    rax,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551594ULL);
x86_l_2cbd:
	/* 0x2cbd: jne    2ce4 <generic_rawtp_process_event+0x2ce4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cbd, 0x2ce4, x86_l_2ce4);
x86_l_2cbf:
	/* 0x2cbf: lea    rdx,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2cc3:
	/* 0x2cc3: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2cc8:
	/* 0x2cc8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2ccd:
	/* 0x2ccd: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2cd2:
	/* 0x2cd2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2cd7:
	/* 0x2cd7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2cda:
	/* 0x2cda: call   2cdf <generic_rawtp_process_event+0x2cdf> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2cdf:
	/* 0x2cdf: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2ce4:
	/* 0x2ce4: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ce9:
	/* 0x2ce9: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ced:
	/* 0x2ced: mov    rdx,QWORD PTR [rdx+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2cf1:
	/* 0x2cf1: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2cf6:
	/* 0x2cf6: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2cfb:
	/* 0x2cfb: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2d00:
	/* 0x2d00: mov    QWORD PTR [rsp+0x78],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2d05:
	/* 0x2d05: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2d0d:
	/* 0x2d0d: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2d15:
	/* 0x2d15: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)retprobe_map));
x86_l_2d1c:
	/* 0x2d1c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d1e:
	/* 0x2d1e: lea    rsi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2d26:
	/* 0x2d26: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2d2b:
	/* 0x2d2b: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2d30:
	/* 0x2d30: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d32:
	/* 0x2d32: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2d35:
	/* 0x2d35: call   2d3a <generic_rawtp_process_event+0x2d3a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d3a:
	/* 0x2d3a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d3d:
	/* 0x2d3d: je     2f2e <generic_rawtp_process_event+0x2f2e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d3d, 0x2f2e, x86_l_2f2e);
x86_l_2d43:
	/* 0x2d43: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_2d45:
	/* 0x2d45: mov    WORD PTR [rsp+0x58],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2d4a:
	/* 0x2d4a: mov    WORD PTR [rsp+0x5a],0x5 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 386547056645ULL);
x86_l_2d51:
	/* 0x2d51: movabs rax,0x200000057 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8589934679ULL);
x86_l_2d5b:
	/* 0x2d5b: mov    QWORD PTR [rsp+0x5c],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_2d60:
	/* 0x2d60: mov    rdi,QWORD PTR [rip+0x21c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_2d67:
	/* 0x2d67: lea    rsi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2d6c:
	/* 0x2d6c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2d71:
	/* 0x2d71: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2d74:
	/* 0x2d74: call   2d79 <generic_rawtp_process_event+0x2d79> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d79:
	/* 0x2d79: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d7c:
	/* 0x2d7c: je     2f04 <generic_rawtp_process_event+0x2f04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d7c, 0x2f04, x86_l_2f04);
x86_l_2d82:
	/* 0x2d82: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2d84:
	/* 0x2d84: jmp    2f2e <generic_rawtp_process_event+0x2f2e> */
	X86_SIM_X86_JMP(0x2d84, 0x2f2e, x86_l_2f2e);
x86_l_2d89:
	/* 0x2d89: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d8b:
	/* 0x2d8b: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d90:
	/* 0x2d90: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2d95:
	/* 0x2d95: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d9a:
	/* 0x2d9a: mov    DWORD PTR [rbp+rax*1+0x0],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2d9f:
	/* 0x2d9f: mov    DWORD PTR [rbp+rax*1+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 4ULL);
x86_l_2da4:
	/* 0x2da4: add    r15,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2da8:
	/* 0x2da8: jmp    2f41 <generic_rawtp_process_event+0x2f41> */
	X86_SIM_X86_JMP(0x2da8, 0x2f41, x86_l_2f41);
x86_l_2dad:
	/* 0x2dad: add    rbp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2db4:
	/* 0x2db4: mov    DWORD PTR [r14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dbb:
	/* 0x2dbb: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2dc0:
	/* 0x2dc0: lea    r14d,[rax+0x8] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2dc4:
	/* 0x2dc4: and    r14d,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2dcb:
	/* 0x2dcb: add    r14,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2dce:
	/* 0x2dce: mov    r15d,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 12ULL);
x86_l_2dd4:
	/* 0x2dd4: cmp    r13,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4095ULL);
x86_l_2ddb:
	/* 0x2ddb: mov    r12d,0xfff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4095ULL);
x86_l_2de1:
	/* 0x2de1: cmovb  r12,r13 */
	X86_SIM_L_EXEC_CMOV(X86_R12, X86_R13, X86_WIDTH_64, X86_CC_B);
x86_l_2de5:
	/* 0x2de5: lea    rdi,[r14+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2de9:
	/* 0x2de9: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2dee:
	/* 0x2dee: mov    esi,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_32);
x86_l_2df1:
	/* 0x2df1: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2df4:
	/* 0x2df4: call   2df9 <generic_rawtp_process_event+0x2df9> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2df9:
	/* 0x2df9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2dfb:
	/* 0x2dfb: js     2e0c <generic_rawtp_process_event+0x2e0c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dfb, 0x2e0c, x86_l_2e0c);
x86_l_2dfd:
	/* 0x2dfd: mov    DWORD PTR [r14],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e00:
	/* 0x2e00: mov    DWORD PTR [r14+0x4],r12d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2e04:
	/* 0x2e04: add    r15,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2e07:
	/* 0x2e07: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x2e07, 0x2e92, x86_l_2e92);
x86_l_2e0c:
	/* 0x2e0c: mov    DWORD PTR [r14],0xfffffffe */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4294967294ULL);
x86_l_2e13:
	/* 0x2e13: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2e19:
	/* 0x2e19: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x2e19, 0x2e92, x86_l_2e92);
x86_l_2e1b:
	/* 0x2e1b: add    rbp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2e22:
	/* 0x2e22: mov    DWORD PTR [r12],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e2a:
	/* 0x2e2a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2e2f:
	/* 0x2e2f: lea    r12d,[rax+0x8] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e33:
	/* 0x2e33: and    r12d,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2e3a:
	/* 0x2e3a: add    r12,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2e3d:
	/* 0x2e3d: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2e42:
	/* 0x2e42: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e47:
	/* 0x2e47: cmp    r14,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_64, 4095ULL);
x86_l_2e4e:
	/* 0x2e4e: mov    r13d,0xfff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4095ULL);
x86_l_2e54:
	/* 0x2e54: cmovb  r13,r14 */
	X86_SIM_L_EXEC_CMOV(X86_R13, X86_R14, X86_WIDTH_64, X86_CC_B);
x86_l_2e58:
	/* 0x2e58: lea    rdi,[r12+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e5d:
	/* 0x2e5d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2e62:
	/* 0x2e62: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2e68:
	/* 0x2e68: mov    esi,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_32);
x86_l_2e6b:
	/* 0x2e6b: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2e6e:
	/* 0x2e6e: call   2e73 <generic_rawtp_process_event+0x2e73> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e73:
	/* 0x2e73: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2e75:
	/* 0x2e75: js     2e8a <generic_rawtp_process_event+0x2e8a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e75, 0x2e8a, x86_l_2e8a);
x86_l_2e77:
	/* 0x2e77: mov    DWORD PTR [r12],r14d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e7b:
	/* 0x2e7b: mov    DWORD PTR [r12+0x4],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2e80:
	/* 0x2e80: mov    r15,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e85:
	/* 0x2e85: add    r15,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2e88:
	/* 0x2e88: jmp    2e92 <generic_rawtp_process_event+0x2e92> */
	X86_SIM_X86_JMP(0x2e88, 0x2e92, x86_l_2e92);
x86_l_2e8a:
	/* 0x2e8a: mov    DWORD PTR [r12],0xfffffffe */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4294967294ULL);
x86_l_2e92:
	/* 0x2e92: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e97:
	/* 0x2e97: jmp    37b6 <generic_rawtp_process_event+0x37b6> */
	X86_SIM_X86_JMP(0x2e97, 0x37b6, x86_l_37b6);
x86_l_2e9c:
	/* 0x2e9c: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_2e9f:
	/* 0x2e9f: je     3066 <generic_rawtp_process_event+0x3066> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e9f, 0x3066, x86_l_3066);
x86_l_2ea5:
	/* 0x2ea5: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_2ea8:
	/* 0x2ea8: je     2f4e <generic_rawtp_process_event+0x2f4e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ea8, 0x2f4e, x86_l_2f4e);
x86_l_2eae:
	/* 0x2eae: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_2eb3:
	/* 0x2eb3: jne    312e <generic_rawtp_process_event+0x312e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2eb3, 0x312e, x86_l_312e);
x86_l_2eb9:
	/* 0x2eb9: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_2ec0:
	/* 0x2ec0: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_2ec4:
	/* 0x2ec4: jmp    3077 <generic_rawtp_process_event+0x3077> */
	X86_SIM_X86_JMP(0x2ec4, 0x3077, x86_l_3077);
x86_l_2ec9:
	/* 0x2ec9: mov    DWORD PTR [rsp+0xc0],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 824633720833ULL);
x86_l_2ed4:
	/* 0x2ed4: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_2edb:
	/* 0x2edb: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2edd:
	/* 0x2edd: lea    rsi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2ee2:
	/* 0x2ee2: lea    rdx,[rsp+0xc0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2eea:
	/* 0x2eea: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2eef:
	/* 0x2eef: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2ef1:
	/* 0x2ef1: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2ef4:
	/* 0x2ef4: call   2ef9 <generic_rawtp_process_event+0x2ef9> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ef9:
	/* 0x2ef9: mov    DWORD PTR [rbx],0xfffffffc */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4294967292ULL);
x86_l_2eff:
	/* 0x2eff: jmp    305b <generic_rawtp_process_event+0x305b> */
	X86_SIM_X86_JMP(0x2eff, 0x305b, x86_l_305b);
x86_l_2f04:
	/* 0x2f04: mov    DWORD PTR [rsp+0x48],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309237645313ULL);
x86_l_2f0c:
	/* 0x2f0c: mov    rdi,QWORD PTR [rip+0x220] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_2f13:
	/* 0x2f13: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2f15:
	/* 0x2f15: lea    rsi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2f1a:
	/* 0x2f1a: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f1f:
	/* 0x2f1f: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2f24:
	/* 0x2f24: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2f26:
	/* 0x2f26: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2f29:
	/* 0x2f29: call   2f2e <generic_rawtp_process_event+0x2f2e> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f2e:
	/* 0x2f2e: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2f33:
	/* 0x2f33: mov    DWORD PTR [rbp+rax*1+0x0],0xfffffffc */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 4294967292ULL);
x86_l_2f3b:
	/* 0x2f3b: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_2f41:
	/* 0x2f41: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f46:
	/* 0x2f46: mov    r12,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_R13, X86_WIDTH_64);
x86_l_2f49:
	/* 0x2f49: jmp    37bb <generic_rawtp_process_event+0x37bb> */
	X86_SIM_X86_JMP(0x2f49, 0x37bb, x86_l_37bb);
x86_l_2f4e:
	/* 0x2f4e: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2f53:
	/* 0x2f53: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_2f5a:
	/* 0x2f5a: jmp    3072 <generic_rawtp_process_event+0x3072> */
	X86_SIM_X86_JMP(0x2f5a, 0x3072, x86_l_3072);
x86_l_2f5f:
	/* 0x2f5f: lea    rax,[rbp+0x5e60] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24160ULL);
x86_l_2f66:
	/* 0x2f66: jmp    2f78 <generic_rawtp_process_event+0x2f78> */
	X86_SIM_X86_JMP(0x2f66, 0x2f78, x86_l_2f78);
x86_l_2f68:
	/* 0x2f68: lea    rax,[rbp+0x5e68] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24168ULL);
x86_l_2f6f:
	/* 0x2f6f: jmp    2f78 <generic_rawtp_process_event+0x2f78> */
	X86_SIM_X86_JMP(0x2f6f, 0x2f78, x86_l_2f78);
x86_l_2f71:
	/* 0x2f71: lea    rax,[rbp+0x5e50] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24144ULL);
x86_l_2f78:
	/* 0x2f78: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f7b:
	/* 0x2f7b: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f80:
	/* 0x2f80: lea    rdi,[rsp+0xd0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2f88:
	/* 0x2f88: lea    rdx,[rsp+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f8d:
	/* 0x2f8d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2f92:
	/* 0x2f92: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2f97:
	/* 0x2f97: mov    r15d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 8ULL);
x86_l_2f9d:
	/* 0x2f9d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2fa2:
	/* 0x2fa2: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2fa5:
	/* 0x2fa5: call   2faa <generic_rawtp_process_event+0x2faa> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2faa:
	/* 0x2faa: mov    r13,QWORD PTR [rsp+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2fb2:
	/* 0x2fb2: test   r12b,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R12, X86_WIDTH_8, 32ULL);
x86_l_2fb6:
	/* 0x2fb6: je     3018 <generic_rawtp_process_event+0x3018> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fb6, 0x3018, x86_l_3018);
x86_l_2fb8:
	/* 0x2fb8: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_2fbf:
	/* 0x2fbf: jb     2ff4 <generic_rawtp_process_event+0x2ff4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2fbf, 0x2ff4, x86_l_2ff4);
x86_l_2fc1:
	/* 0x2fc1: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2fc4:
	/* 0x2fc4: mov    DWORD PTR [rbx],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2fca:
	/* 0x2fca: add    rsi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2fce:
	/* 0x2fce: mov    rbx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2fd3:
	/* 0x2fd3: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_2fd6:
	/* 0x2fd6: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2fdb:
	/* 0x2fdb: mov    rcx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R13, X86_WIDTH_64);
x86_l_2fde:
	/* 0x2fde: call   0 <generic_rawtp_process_event> */
	X86_SIM_X86_CALL(x86_l_3a51, 0x2fe3ULL);
x86_l_2fe3:
	/* 0x2fe3: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_2fe6:
	/* 0x2fe6: add    r15,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2fea:
	/* 0x2fea: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2fef:
	/* 0x2fef: jmp    37b6 <generic_rawtp_process_event+0x37b6> */
	X86_SIM_X86_JMP(0x2fef, 0x37b6, x86_l_37b6);
x86_l_2ff4:
	/* 0x2ff4: add    rbp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2ffb:
	/* 0x2ffb: mov    DWORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3001:
	/* 0x3001: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3006:
	/* 0x3006: lea    ebx,[rax+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3009:
	/* 0x3009: and    ebx,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_300f:
	/* 0x300f: add    rbx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3012:
	/* 0x3012: mov    r15d,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 12ULL);
x86_l_3018:
	/* 0x3018: cmp    r13,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4095ULL);
x86_l_301f:
	/* 0x301f: mov    r14d,0xfff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 4095ULL);
x86_l_3025:
	/* 0x3025: cmovb  r14,r13 */
	X86_SIM_L_EXEC_CMOV(X86_R14, X86_R13, X86_WIDTH_64, X86_CC_B);
x86_l_3029:
	/* 0x3029: lea    rdi,[rbx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_302d:
	/* 0x302d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3032:
	/* 0x3032: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3037:
	/* 0x3037: mov    esi,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_32);
x86_l_303a:
	/* 0x303a: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_303d:
	/* 0x303d: call   3042 <generic_rawtp_process_event+0x3042> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3042:
	/* 0x3042: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3044:
	/* 0x3044: js     3055 <generic_rawtp_process_event+0x3055> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3044, 0x3055, x86_l_3055);
x86_l_3046:
	/* 0x3046: mov    DWORD PTR [rbx],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3049:
	/* 0x3049: mov    DWORD PTR [rbx+0x4],r14d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_304d:
	/* 0x304d: add    r15,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3050:
	/* 0x3050: jmp    37ac <generic_rawtp_process_event+0x37ac> */
	X86_SIM_X86_JMP(0x3050, 0x37ac, x86_l_37ac);
x86_l_3055:
	/* 0x3055: mov    DWORD PTR [rbx],0xfffffffe */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4294967294ULL);
x86_l_305b:
	/* 0x305b: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_3061:
	/* 0x3061: jmp    37ac <generic_rawtp_process_event+0x37ac> */
	X86_SIM_X86_JMP(0x3061, 0x37ac, x86_l_37ac);
x86_l_3066:
	/* 0x3066: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_306b:
	/* 0x306b: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_3072:
	/* 0x3072: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3077:
	/* 0x3077: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_307b:
	/* 0x307b: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_307f:
	/* 0x307f: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3084:
	/* 0x3084: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_3088:
	/* 0x3088: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3088, 0x37ce, x86_l_37ce);
x86_l_308e:
	/* 0x308e: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_3098:
	/* 0x3098: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_309c:
	/* 0x309c: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x309c, 0x37ce, x86_l_37ce);
x86_l_30a2:
	/* 0x30a2: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_30a6:
	/* 0x30a6: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_30a9:
	/* 0x30a9: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_30ac:
	/* 0x30ac: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_30b1:
	/* 0x30b1: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_30b6:
	/* 0x30b6: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30bb:
	/* 0x30bb: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_30bf:
	/* 0x30bf: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_30c2:
	/* 0x30c2: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_30c7:
	/* 0x30c7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_30ca:
	/* 0x30ca: call   30cf <generic_rawtp_process_event+0x30cf> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_30cf:
	/* 0x30cf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_30d2:
	/* 0x30d2: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30d2, 0x35b3, x86_l_35b3);
x86_l_30d8:
	/* 0x30d8: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_30dd:
	/* 0x30dd: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_30e0:
	/* 0x30e0: jg     30fd <generic_rawtp_process_event+0x30fd> */
	X86_SIM_X86_JCC(X86_CC_G, 0x30e0, 0x30fd, x86_l_30fd);
x86_l_30e2:
	/* 0x30e2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_30e4:
	/* 0x30e4: je     311b <generic_rawtp_process_event+0x311b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30e4, 0x311b, x86_l_311b);
x86_l_30e6:
	/* 0x30e6: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_30e9:
	/* 0x30e9: je     311b <generic_rawtp_process_event+0x311b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30e9, 0x311b, x86_l_311b);
x86_l_30eb:
	/* 0x30eb: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_30ee:
	/* 0x30ee: jne    314b <generic_rawtp_process_event+0x314b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30ee, 0x314b, x86_l_314b);
x86_l_30f0:
	/* 0x30f0: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_30f7:
	/* 0x30f7: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_30fb:
	/* 0x30fb: jmp    3150 <generic_rawtp_process_event+0x3150> */
	X86_SIM_X86_JMP(0x30fb, 0x3150, x86_l_3150);
x86_l_30fd:
	/* 0x30fd: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_3100:
	/* 0x3100: je     3138 <generic_rawtp_process_event+0x3138> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3100, 0x3138, x86_l_3138);
x86_l_3102:
	/* 0x3102: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_3105:
	/* 0x3105: je     311b <generic_rawtp_process_event+0x311b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3105, 0x311b, x86_l_311b);
x86_l_3107:
	/* 0x3107: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_310c:
	/* 0x310c: jne    314b <generic_rawtp_process_event+0x314b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x310c, 0x314b, x86_l_314b);
x86_l_310e:
	/* 0x310e: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_3115:
	/* 0x3115: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_3119:
	/* 0x3119: jmp    3150 <generic_rawtp_process_event+0x3150> */
	X86_SIM_X86_JMP(0x3119, 0x3150, x86_l_3150);
x86_l_311b:
	/* 0x311b: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3120:
	/* 0x3120: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_3127:
	/* 0x3127: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_312c:
	/* 0x312c: jmp    3150 <generic_rawtp_process_event+0x3150> */
	X86_SIM_X86_JMP(0x312c, 0x3150, x86_l_3150);
x86_l_312e:
	/* 0x312e: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_3133:
	/* 0x3133: jmp    3077 <generic_rawtp_process_event+0x3077> */
	X86_SIM_X86_JMP(0x3133, 0x3077, x86_l_3077);
x86_l_3138:
	/* 0x3138: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_313d:
	/* 0x313d: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_3144:
	/* 0x3144: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3149:
	/* 0x3149: jmp    3150 <generic_rawtp_process_event+0x3150> */
	X86_SIM_X86_JMP(0x3149, 0x3150, x86_l_3150);
x86_l_314b:
	/* 0x314b: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_3150:
	/* 0x3150: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3154:
	/* 0x3154: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3158:
	/* 0x3158: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_315d:
	/* 0x315d: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_3161:
	/* 0x3161: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3161, 0x37ce, x86_l_37ce);
x86_l_3167:
	/* 0x3167: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_3171:
	/* 0x3171: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_3175:
	/* 0x3175: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3175, 0x37ce, x86_l_37ce);
x86_l_317b:
	/* 0x317b: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_317f:
	/* 0x317f: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_3182:
	/* 0x3182: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3185:
	/* 0x3185: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_318a:
	/* 0x318a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_318f:
	/* 0x318f: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3194:
	/* 0x3194: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3198:
	/* 0x3198: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_319b:
	/* 0x319b: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_31a0:
	/* 0x31a0: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_31a3:
	/* 0x31a3: call   31a8 <generic_rawtp_process_event+0x31a8> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31a8:
	/* 0x31a8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_31ab:
	/* 0x31ab: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x31ab, 0x35b3, x86_l_35b3);
x86_l_31b1:
	/* 0x31b1: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_31b6:
	/* 0x31b6: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_31b9:
	/* 0x31b9: jg     31d6 <generic_rawtp_process_event+0x31d6> */
	X86_SIM_X86_JCC(X86_CC_G, 0x31b9, 0x31d6, x86_l_31d6);
x86_l_31bb:
	/* 0x31bb: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_31bd:
	/* 0x31bd: je     31f4 <generic_rawtp_process_event+0x31f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31bd, 0x31f4, x86_l_31f4);
x86_l_31bf:
	/* 0x31bf: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_31c2:
	/* 0x31c2: je     31f4 <generic_rawtp_process_event+0x31f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c2, 0x31f4, x86_l_31f4);
x86_l_31c4:
	/* 0x31c4: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_31c7:
	/* 0x31c7: jne    321a <generic_rawtp_process_event+0x321a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31c7, 0x321a, x86_l_321a);
x86_l_31c9:
	/* 0x31c9: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_31d0:
	/* 0x31d0: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_31d4:
	/* 0x31d4: jmp    321f <generic_rawtp_process_event+0x321f> */
	X86_SIM_X86_JMP(0x31d4, 0x321f, x86_l_321f);
x86_l_31d6:
	/* 0x31d6: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_31d9:
	/* 0x31d9: je     3207 <generic_rawtp_process_event+0x3207> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31d9, 0x3207, x86_l_3207);
x86_l_31db:
	/* 0x31db: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_31de:
	/* 0x31de: je     31f4 <generic_rawtp_process_event+0x31f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31de, 0x31f4, x86_l_31f4);
x86_l_31e0:
	/* 0x31e0: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_31e5:
	/* 0x31e5: jne    321a <generic_rawtp_process_event+0x321a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31e5, 0x321a, x86_l_321a);
x86_l_31e7:
	/* 0x31e7: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_31ee:
	/* 0x31ee: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_31f2:
	/* 0x31f2: jmp    321f <generic_rawtp_process_event+0x321f> */
	X86_SIM_X86_JMP(0x31f2, 0x321f, x86_l_321f);
x86_l_31f4:
	/* 0x31f4: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_31f9:
	/* 0x31f9: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_3200:
	/* 0x3200: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3205:
	/* 0x3205: jmp    321f <generic_rawtp_process_event+0x321f> */
	X86_SIM_X86_JMP(0x3205, 0x321f, x86_l_321f);
x86_l_3207:
	/* 0x3207: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_320c:
	/* 0x320c: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_3213:
	/* 0x3213: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3218:
	/* 0x3218: jmp    321f <generic_rawtp_process_event+0x321f> */
	X86_SIM_X86_JMP(0x3218, 0x321f, x86_l_321f);
x86_l_321a:
	/* 0x321a: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_321f:
	/* 0x321f: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3223:
	/* 0x3223: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3227:
	/* 0x3227: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_322c:
	/* 0x322c: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_3230:
	/* 0x3230: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3230, 0x37ce, x86_l_37ce);
x86_l_3236:
	/* 0x3236: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_3240:
	/* 0x3240: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_3244:
	/* 0x3244: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3244, 0x37ce, x86_l_37ce);
x86_l_324a:
	/* 0x324a: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_324e:
	/* 0x324e: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_3251:
	/* 0x3251: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3254:
	/* 0x3254: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_3259:
	/* 0x3259: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_325e:
	/* 0x325e: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3263:
	/* 0x3263: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3267:
	/* 0x3267: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_326a:
	/* 0x326a: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_326f:
	/* 0x326f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3272:
	/* 0x3272: call   3277 <generic_rawtp_process_event+0x3277> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3277:
	/* 0x3277: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_327a:
	/* 0x327a: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x327a, 0x35b3, x86_l_35b3);
x86_l_3280:
	/* 0x3280: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_3285:
	/* 0x3285: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_3288:
	/* 0x3288: jg     32a5 <generic_rawtp_process_event+0x32a5> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3288, 0x32a5, x86_l_32a5);
x86_l_328a:
	/* 0x328a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_328c:
	/* 0x328c: je     32c3 <generic_rawtp_process_event+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x328c, 0x32c3, x86_l_32c3);
x86_l_328e:
	/* 0x328e: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_3291:
	/* 0x3291: je     32c3 <generic_rawtp_process_event+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3291, 0x32c3, x86_l_32c3);
x86_l_3293:
	/* 0x3293: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_3296:
	/* 0x3296: jne    32e9 <generic_rawtp_process_event+0x32e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3296, 0x32e9, x86_l_32e9);
x86_l_3298:
	/* 0x3298: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_329f:
	/* 0x329f: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_32a3:
	/* 0x32a3: jmp    32ee <generic_rawtp_process_event+0x32ee> */
	X86_SIM_X86_JMP(0x32a3, 0x32ee, x86_l_32ee);
x86_l_32a5:
	/* 0x32a5: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_32a8:
	/* 0x32a8: je     32d6 <generic_rawtp_process_event+0x32d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32a8, 0x32d6, x86_l_32d6);
x86_l_32aa:
	/* 0x32aa: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_32ad:
	/* 0x32ad: je     32c3 <generic_rawtp_process_event+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32ad, 0x32c3, x86_l_32c3);
x86_l_32af:
	/* 0x32af: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_32b4:
	/* 0x32b4: jne    32e9 <generic_rawtp_process_event+0x32e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32b4, 0x32e9, x86_l_32e9);
x86_l_32b6:
	/* 0x32b6: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_32bd:
	/* 0x32bd: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_32c1:
	/* 0x32c1: jmp    32ee <generic_rawtp_process_event+0x32ee> */
	X86_SIM_X86_JMP(0x32c1, 0x32ee, x86_l_32ee);
x86_l_32c3:
	/* 0x32c3: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_32c8:
	/* 0x32c8: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_32cf:
	/* 0x32cf: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_32d4:
	/* 0x32d4: jmp    32ee <generic_rawtp_process_event+0x32ee> */
	X86_SIM_X86_JMP(0x32d4, 0x32ee, x86_l_32ee);
x86_l_32d6:
	/* 0x32d6: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_32db:
	/* 0x32db: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_32e2:
	/* 0x32e2: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_32e7:
	/* 0x32e7: jmp    32ee <generic_rawtp_process_event+0x32ee> */
	X86_SIM_X86_JMP(0x32e7, 0x32ee, x86_l_32ee);
x86_l_32e9:
	/* 0x32e9: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_32ee:
	/* 0x32ee: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_32f2:
	/* 0x32f2: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32f6:
	/* 0x32f6: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_32fb:
	/* 0x32fb: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_32ff:
	/* 0x32ff: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x32ff, 0x37ce, x86_l_37ce);
x86_l_3305:
	/* 0x3305: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_330f:
	/* 0x330f: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_3313:
	/* 0x3313: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3313, 0x37ce, x86_l_37ce);
x86_l_3319:
	/* 0x3319: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_331d:
	/* 0x331d: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_3320:
	/* 0x3320: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3323:
	/* 0x3323: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_3328:
	/* 0x3328: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_332d:
	/* 0x332d: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3332:
	/* 0x3332: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3336:
	/* 0x3336: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3339:
	/* 0x3339: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_333e:
	/* 0x333e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3341:
	/* 0x3341: call   3346 <generic_rawtp_process_event+0x3346> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3346:
	/* 0x3346: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3349:
	/* 0x3349: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3349, 0x35b3, x86_l_35b3);
x86_l_334f:
	/* 0x334f: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_3354:
	/* 0x3354: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_3357:
	/* 0x3357: jg     3374 <generic_rawtp_process_event+0x3374> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3357, 0x3374, x86_l_3374);
x86_l_3359:
	/* 0x3359: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_335b:
	/* 0x335b: je     3392 <generic_rawtp_process_event+0x3392> */
	X86_SIM_X86_JCC(X86_CC_E, 0x335b, 0x3392, x86_l_3392);
x86_l_335d:
	/* 0x335d: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_3360:
	/* 0x3360: je     3392 <generic_rawtp_process_event+0x3392> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3360, 0x3392, x86_l_3392);
x86_l_3362:
	/* 0x3362: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_3365:
	/* 0x3365: jne    33b8 <generic_rawtp_process_event+0x33b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3365, 0x33b8, x86_l_33b8);
x86_l_3367:
	/* 0x3367: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_336e:
	/* 0x336e: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_3372:
	/* 0x3372: jmp    33bd <generic_rawtp_process_event+0x33bd> */
	X86_SIM_X86_JMP(0x3372, 0x33bd, x86_l_33bd);
x86_l_3374:
	/* 0x3374: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_3377:
	/* 0x3377: je     33a5 <generic_rawtp_process_event+0x33a5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3377, 0x33a5, x86_l_33a5);
x86_l_3379:
	/* 0x3379: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_337c:
	/* 0x337c: je     3392 <generic_rawtp_process_event+0x3392> */
	X86_SIM_X86_JCC(X86_CC_E, 0x337c, 0x3392, x86_l_3392);
x86_l_337e:
	/* 0x337e: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_3383:
	/* 0x3383: jne    33b8 <generic_rawtp_process_event+0x33b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3383, 0x33b8, x86_l_33b8);
x86_l_3385:
	/* 0x3385: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_338c:
	/* 0x338c: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_3390:
	/* 0x3390: jmp    33bd <generic_rawtp_process_event+0x33bd> */
	X86_SIM_X86_JMP(0x3390, 0x33bd, x86_l_33bd);
x86_l_3392:
	/* 0x3392: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3397:
	/* 0x3397: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_339e:
	/* 0x339e: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_33a3:
	/* 0x33a3: jmp    33bd <generic_rawtp_process_event+0x33bd> */
	X86_SIM_X86_JMP(0x33a3, 0x33bd, x86_l_33bd);
x86_l_33a5:
	/* 0x33a5: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_33aa:
	/* 0x33aa: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_33b1:
	/* 0x33b1: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_33b6:
	/* 0x33b6: jmp    33bd <generic_rawtp_process_event+0x33bd> */
	X86_SIM_X86_JMP(0x33b6, 0x33bd, x86_l_33bd);
x86_l_33b8:
	/* 0x33b8: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_33bd:
	/* 0x33bd: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_33c1:
	/* 0x33c1: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33c5:
	/* 0x33c5: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_33ca:
	/* 0x33ca: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_33ce:
	/* 0x33ce: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x33ce, 0x37ce, x86_l_37ce);
x86_l_33d4:
	/* 0x33d4: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_33de:
	/* 0x33de: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_33e2:
	/* 0x33e2: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x33e2, 0x37ce, x86_l_37ce);
x86_l_33e8:
	/* 0x33e8: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_33ec:
	/* 0x33ec: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_33ef:
	/* 0x33ef: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_33f2:
	/* 0x33f2: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_33f7:
	/* 0x33f7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_33fc:
	/* 0x33fc: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3401:
	/* 0x3401: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3405:
	/* 0x3405: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3408:
	/* 0x3408: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_340d:
	/* 0x340d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3410:
	/* 0x3410: call   3415 <generic_rawtp_process_event+0x3415> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3415:
	/* 0x3415: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3418:
	/* 0x3418: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3418, 0x35b3, x86_l_35b3);
x86_l_341e:
	/* 0x341e: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_3423:
	/* 0x3423: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_3426:
	/* 0x3426: jg     3443 <generic_rawtp_process_event+0x3443> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3426, 0x3443, x86_l_3443);
x86_l_3428:
	/* 0x3428: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_342a:
	/* 0x342a: je     3461 <generic_rawtp_process_event+0x3461> */
	X86_SIM_X86_JCC(X86_CC_E, 0x342a, 0x3461, x86_l_3461);
x86_l_342c:
	/* 0x342c: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_342f:
	/* 0x342f: je     3461 <generic_rawtp_process_event+0x3461> */
	X86_SIM_X86_JCC(X86_CC_E, 0x342f, 0x3461, x86_l_3461);
x86_l_3431:
	/* 0x3431: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_3434:
	/* 0x3434: jne    3487 <generic_rawtp_process_event+0x3487> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3434, 0x3487, x86_l_3487);
x86_l_3436:
	/* 0x3436: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_343d:
	/* 0x343d: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_3441:
	/* 0x3441: jmp    348c <generic_rawtp_process_event+0x348c> */
	X86_SIM_X86_JMP(0x3441, 0x348c, x86_l_348c);
x86_l_3443:
	/* 0x3443: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_3446:
	/* 0x3446: je     3474 <generic_rawtp_process_event+0x3474> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3446, 0x3474, x86_l_3474);
x86_l_3448:
	/* 0x3448: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_344b:
	/* 0x344b: je     3461 <generic_rawtp_process_event+0x3461> */
	X86_SIM_X86_JCC(X86_CC_E, 0x344b, 0x3461, x86_l_3461);
x86_l_344d:
	/* 0x344d: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_3452:
	/* 0x3452: jne    3487 <generic_rawtp_process_event+0x3487> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3452, 0x3487, x86_l_3487);
x86_l_3454:
	/* 0x3454: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_345b:
	/* 0x345b: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_345f:
	/* 0x345f: jmp    348c <generic_rawtp_process_event+0x348c> */
	X86_SIM_X86_JMP(0x345f, 0x348c, x86_l_348c);
x86_l_3461:
	/* 0x3461: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3466:
	/* 0x3466: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_346d:
	/* 0x346d: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3472:
	/* 0x3472: jmp    348c <generic_rawtp_process_event+0x348c> */
	X86_SIM_X86_JMP(0x3472, 0x348c, x86_l_348c);
x86_l_3474:
	/* 0x3474: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3479:
	/* 0x3479: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_3480:
	/* 0x3480: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3485:
	/* 0x3485: jmp    348c <generic_rawtp_process_event+0x348c> */
	X86_SIM_X86_JMP(0x3485, 0x348c, x86_l_348c);
x86_l_3487:
	/* 0x3487: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_348c:
	/* 0x348c: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3490:
	/* 0x3490: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3494:
	/* 0x3494: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3499:
	/* 0x3499: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_349d:
	/* 0x349d: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x349d, 0x37ce, x86_l_37ce);
x86_l_34a3:
	/* 0x34a3: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_34ad:
	/* 0x34ad: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_34b1:
	/* 0x34b1: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x34b1, 0x37ce, x86_l_37ce);
x86_l_34b7:
	/* 0x34b7: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_34bb:
	/* 0x34bb: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_34be:
	/* 0x34be: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_34c1:
	/* 0x34c1: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_34c6:
	/* 0x34c6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_34cb:
	/* 0x34cb: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_34d0:
	/* 0x34d0: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_34d4:
	/* 0x34d4: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_34d7:
	/* 0x34d7: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_34dc:
	/* 0x34dc: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_34df:
	/* 0x34df: call   34e4 <generic_rawtp_process_event+0x34e4> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34e4:
	/* 0x34e4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_34e7:
	/* 0x34e7: js     35b3 <generic_rawtp_process_event+0x35b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x34e7, 0x35b3, x86_l_35b3);
x86_l_34ed:
	/* 0x34ed: movzx  eax,BYTE PTR [r15+0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_34f2:
	/* 0x34f2: cmp    eax,0x32 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_34f5:
	/* 0x34f5: jg     3512 <generic_rawtp_process_event+0x3512> */
	X86_SIM_X86_JCC(X86_CC_G, 0x34f5, 0x3512, x86_l_3512);
x86_l_34f7:
	/* 0x34f7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_34f9:
	/* 0x34f9: je     3530 <generic_rawtp_process_event+0x3530> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34f9, 0x3530, x86_l_3530);
x86_l_34fb:
	/* 0x34fb: cmp    eax,0x2b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 43ULL);
x86_l_34fe:
	/* 0x34fe: je     3530 <generic_rawtp_process_event+0x3530> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34fe, 0x3530, x86_l_3530);
x86_l_3500:
	/* 0x3500: cmp    eax,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 44ULL);
x86_l_3503:
	/* 0x3503: jne    3556 <generic_rawtp_process_event+0x3556> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3503, 0x3556, x86_l_3556);
x86_l_3505:
	/* 0x3505: mov    WORD PTR [r15+0x2],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_350c:
	/* 0x350c: mov    ax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 8ULL);
x86_l_3510:
	/* 0x3510: jmp    355b <generic_rawtp_process_event+0x355b> */
	X86_SIM_X86_JMP(0x3510, 0x355b, x86_l_355b);
x86_l_3512:
	/* 0x3512: cmp    eax,0x33 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 51ULL);
x86_l_3515:
	/* 0x3515: je     3543 <generic_rawtp_process_event+0x3543> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3515, 0x3543, x86_l_3543);
x86_l_3517:
	/* 0x3517: cmp    eax,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_351a:
	/* 0x351a: je     3530 <generic_rawtp_process_event+0x3530> */
	X86_SIM_X86_JCC(X86_CC_E, 0x351a, 0x3530, x86_l_3530);
x86_l_351c:
	/* 0x351c: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_3521:
	/* 0x3521: jne    3556 <generic_rawtp_process_event+0x3556> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3521, 0x3556, x86_l_3556);
x86_l_3523:
	/* 0x3523: mov    WORD PTR [r15+0x2],0x28 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_352a:
	/* 0x352a: mov    ax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_16, 40ULL);
x86_l_352e:
	/* 0x352e: jmp    355b <generic_rawtp_process_event+0x355b> */
	X86_SIM_X86_JMP(0x352e, 0x355b, x86_l_355b);
x86_l_3530:
	/* 0x3530: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3535:
	/* 0x3535: lea    eax,[rax*8+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_353c:
	/* 0x353c: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3541:
	/* 0x3541: jmp    355b <generic_rawtp_process_event+0x355b> */
	X86_SIM_X86_JMP(0x3541, 0x355b, x86_l_355b);
x86_l_3543:
	/* 0x3543: movzx  eax,BYTE PTR [r15+0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3548:
	/* 0x3548: lea    eax,[rax*4+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_354f:
	/* 0x354f: mov    WORD PTR [r15+0x2],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3554:
	/* 0x3554: jmp    355b <generic_rawtp_process_event+0x355b> */
	X86_SIM_X86_JMP(0x3554, 0x355b, x86_l_355b);
x86_l_3556:
	/* 0x3556: movzx  eax,WORD PTR [r15+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_355b:
	/* 0x355b: add    ax,WORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R15, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_355f:
	/* 0x355f: mov    WORD PTR [r15],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3563:
	/* 0x3563: movzx  ebp,BYTE PTR [r15+0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3568:
	/* 0x3568: cmp    rbp,0x3c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 60ULL);
x86_l_356c:
	/* 0x356c: ja     37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_A, 0x356c, 0x37ce, x86_l_37ce);
x86_l_3572:
	/* 0x3572: movabs rcx,0x1008180000000001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 1155199692699598849ULL);
x86_l_357c:
	/* 0x357c: bt     rcx,rbp */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_3580:
	/* 0x3580: jae    37ce <generic_rawtp_process_event+0x37ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3580, 0x37ce, x86_l_37ce);
x86_l_3586:
	/* 0x3586: mov    BYTE PTR [r15+0x5],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_358a:
	/* 0x358a: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_358d:
	/* 0x358d: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3590:
	/* 0x3590: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_3595:
	/* 0x3595: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_359a:
	/* 0x359a: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_359f:
	/* 0x359f: movzx  edx,WORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_35a3:
	/* 0x35a3: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_35a6:
	/* 0x35a6: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_35ab:
	/* 0x35ab: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_35ae:
	/* 0x35ae: call   35b3 <generic_rawtp_process_event+0x35b3> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_35b3:
	/* 0x35b3: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_35b5:
	/* 0x35b5: mov    BYTE PTR [rsp+0xbc],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_35bd:
	/* 0x35bd: movzx  eax,bpl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_8);
x86_l_35c1:
	/* 0x35c1: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35c6:
	/* 0x35c6: mov    WORD PTR [rbx+0x24],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_35ca:
	/* 0x35ca: mov    WORD PTR [rbx+0x26],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 163208757258ULL);
x86_l_35d0:
	/* 0x35d0: lea    rdx,[r13+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35d4:
	/* 0x35d4: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_35d9:
	/* 0x35d9: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_35de:
	/* 0x35de: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_35e1:
	/* 0x35e1: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_35e6:
	/* 0x35e6: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_35e9:
	/* 0x35e9: call   35ee <generic_rawtp_process_event+0x35ee> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_35ee:
	/* 0x35ee: lea    rdi,[rbx+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35f2:
	/* 0x35f2: add    r13,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_35f6:
	/* 0x35f6: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_35fb:
	/* 0x35fb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3600:
	/* 0x3600: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_3605:
	/* 0x3605: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3608:
	/* 0x3608: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_360b:
	/* 0x360b: call   3610 <generic_rawtp_process_event+0x3610> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3610:
	/* 0x3610: cmp    bpl,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_8, 17ULL);
x86_l_3614:
	/* 0x3614: je     366d <generic_rawtp_process_event+0x366d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3614, 0x366d, x86_l_366d);
x86_l_3616:
	/* 0x3616: movzx  eax,bpl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_8);
x86_l_361a:
	/* 0x361a: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_361d:
	/* 0x361d: jne    36c4 <generic_rawtp_process_event+0x36c4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x361d, 0x36c4, x86_l_36c4);
x86_l_3623:
	/* 0x3623: mov    rbx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3628:
	/* 0x3628: movzx  r15d,WORD PTR [rsp+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 200ULL);
x86_l_3631:
	/* 0x3631: lea    rdx,[rbx+r15*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_3635:
	/* 0x3635: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_363a:
	/* 0x363a: lea    rdi,[r13+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_363e:
	/* 0x363e: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_3643:
	/* 0x3643: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3648:
	/* 0x3648: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_364d:
	/* 0x364d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3650:
	/* 0x3650: call   3655 <generic_rawtp_process_event+0x3655> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3655:
	/* 0x3655: lea    rdi,[r13+0x22] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_3659:
	/* 0x3659: lea    rdx,[rbx+r15*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_365d:
	/* 0x365d: add    rdx,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_3661:
	/* 0x3661: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_3666:
	/* 0x3666: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_366b:
	/* 0x366b: jmp    36b5 <generic_rawtp_process_event+0x36b5> */
	X86_SIM_X86_JMP(0x366b, 0x36b5, x86_l_36b5);
x86_l_366d:
	/* 0x366d: mov    rbx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3672:
	/* 0x3672: movzx  r15d,WORD PTR [rsp+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 200ULL);
x86_l_367b:
	/* 0x367b: lea    rdx,[rbx+r15*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_367f:
	/* 0x367f: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3684:
	/* 0x3684: lea    rdi,[r13+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3688:
	/* 0x3688: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_368d:
	/* 0x368d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3692:
	/* 0x3692: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_3697:
	/* 0x3697: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_369a:
	/* 0x369a: call   369f <generic_rawtp_process_event+0x369f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_369f:
	/* 0x369f: lea    rdi,[r13+0x22] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_36a3:
	/* 0x36a3: lea    rdx,[rbx+r15*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_36a7:
	/* 0x36a7: add    rdx,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_36ab:
	/* 0x36ab: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_36b0:
	/* 0x36b0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_36b5:
	/* 0x36b5: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_36ba:
	/* 0x36ba: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_36bd:
	/* 0x36bd: call   36c2 <generic_rawtp_process_event+0x36c2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36c2:
	/* 0x36c2: jmp    36d0 <generic_rawtp_process_event+0x36d0> */
	X86_SIM_X86_JMP(0x36c2, 0x36d0, x86_l_36d0);
x86_l_36c4:
	/* 0x36c4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36c9:
	/* 0x36c9: mov    DWORD PTR [rax+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_36d0:
	/* 0x36d0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36d5:
	/* 0x36d5: movzx  eax,WORD PTR [rdx+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_36d9:
	/* 0x36d9: movzx  ecx,WORD PTR [rdx+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_36dd:
	/* 0x36dd: movbe  WORD PTR [rdx+0x20],ax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RDX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_36e3:
	/* 0x36e3: movbe  WORD PTR [rdx+0x22],cx */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RDX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_36e9:
	/* 0x36e9: add    r12,0xe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 224ULL);
x86_l_36f0:
	/* 0x36f0: lea    rdi,[rsp+0xa8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_36f8:
	/* 0x36f8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_36fd:
	/* 0x36fd: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3702:
	/* 0x3702: mov    r15d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4ULL);
x86_l_3708:
	/* 0x3708: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_370d:
	/* 0x370d: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_3710:
	/* 0x3710: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3713:
	/* 0x3713: call   3718 <generic_rawtp_process_event+0x3718> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3718:
	/* 0x3718: mov    rcx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3720:
	/* 0x3720: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3723:
	/* 0x3723: je     37a6 <generic_rawtp_process_event+0x37a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3723, 0x37a6, x86_l_37a6);
x86_l_3729:
	/* 0x3729: add    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 5ULL);
x86_l_372d:
	/* 0x372d: lea    rdi,[rsp+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3732:
	/* 0x3732: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3737:
	/* 0x3737: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_373c:
	/* 0x373c: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3744:
	/* 0x3744: add    rdx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 5ULL);
x86_l_3748:
	/* 0x3748: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_374d:
	/* 0x374d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3750:
	/* 0x3750: call   3755 <generic_rawtp_process_event+0x3755> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3755:
	/* 0x3755: mov    rbx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_375d:
	/* 0x375d: mov    r12,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3762:
	/* 0x3762: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3767:
	/* 0x3767: lea    rdi,[r13+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_376b:
	/* 0x376b: lea    rdx,[rbx+r12*8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 3), 0ULL);
x86_l_376f:
	/* 0x376f: add    rdx,0x44 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_3773:
	/* 0x3773: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3778:
	/* 0x3778: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_377d:
	/* 0x377d: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3780:
	/* 0x3780: call   3785 <generic_rawtp_process_event+0x3785> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3785:
	/* 0x3785: add    r13,0x3c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 60ULL);
x86_l_3789:
	/* 0x3789: lea    rdx,[rbx+r12*8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 3), 0ULL);
x86_l_378d:
	/* 0x378d: add    rdx,0x45 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 69ULL);
x86_l_3791:
	/* 0x3791: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3796:
	/* 0x3796: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_3799:
	/* 0x3799: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_379e:
	/* 0x379e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_37a1:
	/* 0x37a1: call   37a6 <generic_rawtp_process_event+0x37a6> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_37a6:
	/* 0x37a6: mov    r15d,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 64ULL);
x86_l_37ac:
	/* 0x37ac: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_37b1:
	/* 0x37b1: mov    rbx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_37b6:
	/* 0x37b6: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_37bb:
	/* 0x37bb: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_37c0:
	/* 0x37c0: mov    rsi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37c4:
	/* 0x37c4: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_37c9:
	/* 0x37c9: jmp    d3d <generic_rawtp_process_event+0xd3d> */
	X86_SIM_X86_JMP(0x37c9, 0xd3d, x86_l_d3d);
x86_l_37ce:
	/* 0x37ce: mov    WORD PTR [rsp+0xc8],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_37d6:
	/* 0x37d6: jmp    35b5 <generic_rawtp_process_event+0x35b5> */
	X86_SIM_X86_JMP(0x37d6, 0x35b5, x86_l_35b5);
x86_l_3eb0:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_37db */
x86_l_37db:
	/* 0x37db: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_37df:
	/* 0x37df: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_37e4:
	/* 0x37e4: cmp    edi,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 9ULL);
x86_l_37e7:
	/* 0x37e7: ja     386b <extract_arg_depth+0x90> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x37e7, 0x386b, x86_l_386b);
x86_l_37ed:
	/* 0x37ed: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_37ef:
	/* 0x37ef: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_37f0:
	/* 0x37f0: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37f1:
	/* 0x37f1: mov    r8,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37f4:
	/* 0x37f4: mov    r9d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RDI, X86_WIDTH_32);
x86_l_37f7:
	/* 0x37f7: cmp    WORD PTR [r8+r9*8+0x6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_R9, 3), 25769803776ULL);
x86_l_37fe:
	/* 0x37fe: je     3864 <extract_arg_depth+0x89> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x37fe, 0x3864, x86_l_3864);
x86_l_3800:
	/* 0x3800: mov    rcx,QWORD PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3804:
	/* 0x3804: mov    edx,DWORD PTR [r8+r9*8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 3), 0ULL);
x86_l_3808:
	/* 0x3808: add    rdx,QWORD PTR [rcx] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_380b:
	/* 0x380b: mov    QWORD PTR [rcx],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_380e:
	/* 0x380e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3810:
	/* 0x3810: cmp    WORD PTR [r8+r9*8+0x4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_R9, 3), 17179869184ULL);
x86_l_3817:
	/* 0x3817: je     3864 <extract_arg_depth+0x89> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3817, 0x3864, x86_l_3864);
x86_l_3819:
	/* 0x3819: mov    ebx,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_32);
x86_l_381b:
	/* 0x381b: cmp    BYTE PTR [rsi+0x10],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_381f:
	/* 0x381f: je     382d <extract_arg_depth+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x381f, 0x382d, x86_l_382d);
x86_l_3821:
	/* 0x3821: mov    edi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 8ULL);
x86_l_3826:
	/* 0x3826: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_382b:
	/* 0x382b: jmp    3837 <extract_arg_depth+0x5c> */
	X86_SIM_X86_SUB_JMP(0x382b, 0x3837, x86_l_3837);
x86_l_382d:
	/* 0x382d: mov    edi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 8ULL);
x86_l_3832:
	/* 0x3832: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3837:
	/* 0x3837: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_383a:
	/* 0x383a: mov    rdi,QWORD PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_383e:
	/* 0x383e: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3841:
	/* 0x3841: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3846:
	/* 0x3846: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3849:
	/* 0x3849: call   384e <extract_arg_depth+0x73> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_384e:
	/* 0x384e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3850:
	/* 0x3850: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_3855:
	/* 0x3855: jns    3864 <extract_arg_depth+0x89> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x3855, 0x3864, x86_l_3864);
x86_l_3857:
	/* 0x3857: inc    ebx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3859:
	/* 0x3859: mov    rax,QWORD PTR [r14+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_385d:
	/* 0x385d: mov    DWORD PTR [rax],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_385f:
	/* 0x385f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3864:
	/* 0x3864: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3868:
	/* 0x3868: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3869:
	/* 0x3869: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_386b:
	/* 0x386b: jmp    3870 <cwd_read_v61> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_3870 */
x86_l_3870:
	/* 0x3870: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3874:
	/* 0x3874: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3875:
	/* 0x3875: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3877:
	/* 0x3877: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3879:
	/* 0x3879: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_387b:
	/* 0x387b: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_387d:
	/* 0x387d: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_387e:
	/* 0x387e: sub    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_3882:
	/* 0x3882: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_3885:
	/* 0x3885: mov    r12,QWORD PTR [rsi+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3889:
	/* 0x3889: mov    rdx,QWORD PTR [rsi+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_388d:
	/* 0x388d: mov    r15,QWORD PTR [rsi+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3891:
	/* 0x3891: cmp    r12,QWORD PTR [rsi] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_R12, X86_RSI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 0ULL);
x86_l_3894:
	/* 0x3894: jne    38a0 <cwd_read_v61+0x30> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3894, 0x38a0, x86_l_38a0);
x86_l_3896:
	/* 0x3896: cmp    rdx,QWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_389a:
	/* 0x389a: je     3a35 <cwd_read_v61+0x1c5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x389a, 0x3a35, x86_l_3a35);
x86_l_38a0:
	/* 0x38a0: lea    r14,[rbx+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_38a4:
	/* 0x38a4: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_38a9:
	/* 0x38a9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_38ae:
	/* 0x38ae: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_38b3:
	/* 0x38b3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_38b8:
	/* 0x38b8: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_38bb:
	/* 0x38bb: call   38c0 <cwd_read_v61+0x50> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_38c0:
	/* 0x38c0: cmp    r12,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_38c5:
	/* 0x38c5: je     39d4 <cwd_read_v61+0x164> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x38c5, 0x39d4, x86_l_39d4);
x86_l_38cb:
	/* 0x38cb: lea    r13,[r12+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_38d0:
	/* 0x38d0: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38d5:
	/* 0x38d5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_38da:
	/* 0x38da: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_38df:
	/* 0x38df: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_38e4:
	/* 0x38e4: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_38e7:
	/* 0x38e7: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_38ea:
	/* 0x38ea: call   38ef <cwd_read_v61+0x7f> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_38ef:
	/* 0x38ef: cmp    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38f4:
	/* 0x38f4: je     39d4 <cwd_read_v61+0x164> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x38f4, 0x39d4, x86_l_39d4);
x86_l_38fa:
	/* 0x38fa: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_38ff:
	/* 0x38ff: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3904:
	/* 0x3904: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3909:
	/* 0x3909: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_390e:
	/* 0x390e: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3911:
	/* 0x3911: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3914:
	/* 0x3914: call   3919 <cwd_read_v61+0xa9> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3919:
	/* 0x3919: add    r12,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_391d:
	/* 0x391d: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3922:
	/* 0x3922: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_3927:
	/* 0x3927: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_392c:
	/* 0x392c: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_3931:
	/* 0x3931: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_3934:
	/* 0x3934: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3937:
	/* 0x3937: call   393c <cwd_read_v61+0xcc> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_393c:
	/* 0x393c: mov    r15,QWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3940:
	/* 0x3940: mov    rcx,QWORD PTR [rbx+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3944:
	/* 0x3944: mov    ebp,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3948:
	/* 0x3948: sub    rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_394b:
	/* 0x394b: mov    r12d,DWORD PTR [rbx+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_394f:
	/* 0x394f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3951:
	/* 0x3951: mov    edx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_32);
x86_l_3953:
	/* 0x3953: sub    edx,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R12, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3956:
	/* 0x3956: cmovb  edx,eax */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RAX, X86_WIDTH_32, X86_CC_B);
x86_l_3959:
	/* 0x3959: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_395e:
	/* 0x395e: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3960:
	/* 0x3960: cmp    r12d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_3963:
	/* 0x3963: seta   dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_A);
x86_l_3967:
	/* 0x3967: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_3969:
	/* 0x3969: cmovb  esi,r12d */
	X86_SIM_L_EXEC_CMOV(X86_RSI, X86_R12, X86_WIDTH_32, X86_CC_B);
x86_l_396d:
	/* 0x396d: add    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_ADD);
x86_l_396f:
	/* 0x396f: mov    eax,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_32);
x86_l_3972:
	/* 0x3972: sub    eax,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3974:
	/* 0x3974: mov    DWORD PTR [rbx+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3977:
	/* 0x3977: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_397c:
	/* 0x397c: sub    rcx,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDI, X86_WIDTH_64, X86_ALU_SUB);
x86_l_397f:
	/* 0x397f: jb     3a3e <cwd_read_v61+0x1ce> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x397f, 0x3a3e, x86_l_3a3e);
x86_l_3985:
	/* 0x3985: cmp    rcx,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 4095ULL);
x86_l_398c:
	/* 0x398c: ja     3a3e <cwd_read_v61+0x1ce> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x398c, 0x3a3e, x86_l_3a3e);
x86_l_3992:
	/* 0x3992: cmp    r12d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_3995:
	/* 0x3995: jbe    399c <cwd_read_v61+0x12c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x3995, 0x399c, x86_l_399c);
x86_l_3997:
	/* 0x3997: mov    BYTE PTR [r15+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_399c:
	/* 0x399c: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_399e:
	/* 0x399e: cmp    r12d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_39a1:
	/* 0x39a1: seta   dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_A);
x86_l_39a5:
	/* 0x39a5: movzx  esi,sil */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_WIDTH_8);
x86_l_39a9:
	/* 0x39a9: add    r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_39ac:
	/* 0x39ac: add    rdi,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_39af:
	/* 0x39af: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_39b4:
	/* 0x39b4: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_39b7:
	/* 0x39b7: call   39bc <cwd_read_v61+0x14c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_39bc:
	/* 0x39bc: mov    QWORD PTR [rbx+0x30],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_39c0:
	/* 0x39c0: cmp    r12d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_39c3:
	/* 0x39c3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_39c8:
	/* 0x39c8: jbe    3a3e <cwd_read_v61+0x1ce> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x39c8, 0x3a3e, x86_l_3a3e);
x86_l_39ca:
	/* 0x39ca: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_39cf:
	/* 0x39cf: mov    QWORD PTR [r14],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39d2:
	/* 0x39d2: jmp    3a31 <cwd_read_v61+0x1c1> */
	X86_SIM_X86_SUB_JMP(0x39d2, 0x3a31, x86_l_3a31);
x86_l_39d4:
	/* 0x39d4: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39d8:
	/* 0x39d8: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_39dd:
	/* 0x39dd: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_39e2:
	/* 0x39e2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_39e7:
	/* 0x39e7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_39ec:
	/* 0x39ec: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_39ef:
	/* 0x39ef: call   39f4 <cwd_read_v61+0x184> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_39f4:
	/* 0x39f4: mov    rax,QWORD PTR [rbx+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_39f8:
	/* 0x39f8: cmp    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_39fd:
	/* 0x39fd: je     3a35 <cwd_read_v61+0x1c5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x39fd, 0x3a35, x86_l_3a35);
x86_l_39ff:
	/* 0x39ff: add    r15,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_3a03:
	/* 0x3a03: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3a08:
	/* 0x3a08: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3a0d:
	/* 0x3a0d: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_3a10:
	/* 0x3a10: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3a15:
	/* 0x3a15: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_3a18:
	/* 0x3a18: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3a1b:
	/* 0x3a1b: call   3a20 <cwd_read_v61+0x1b0> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3a20:
	/* 0x3a20: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3a25:
	/* 0x3a25: mov    QWORD PTR [rbx+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3a29:
	/* 0x3a29: add    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_3a2d:
	/* 0x3a2d: mov    QWORD PTR [rbx+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3a31:
	/* 0x3a31: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3a33:
	/* 0x3a33: jmp    3a3e <cwd_read_v61+0x1ce> */
	X86_SIM_X86_SUB_JMP(0x3a33, 0x3a3e, x86_l_3a3e);
x86_l_3a35:
	/* 0x3a35: mov    BYTE PTR [rbx+0x3c],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_3a39:
	/* 0x3a39: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3a3e:
	/* 0x3a3e: add    rsp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_3a42:
	/* 0x3a42: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3a43:
	/* 0x3a43: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3a45:
	/* 0x3a45: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3a47:
	/* 0x3a47: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3a49:
	/* 0x3a49: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a4b:
	/* 0x3a4b: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3a4c:
	/* 0x3a4c: jmp    3a51 <data_event_bytes> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_3a51 */
x86_l_3a51:
	/* 0x3a51: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3a52:
	/* 0x3a52: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a54:
	/* 0x3a54: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3a56:
	/* 0x3a56: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3a58:
	/* 0x3a58: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3a5a:
	/* 0x3a5a: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3a5b:
	/* 0x3a5b: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_3a5f:
	/* 0x3a5f: mov    r14,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RCX, X86_WIDTH_64);
x86_l_3a62:
	/* 0x3a62: mov    r15,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDX, X86_WIDTH_64);
x86_l_3a65:
	/* 0x3a65: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_3a68:
	/* 0x3a68: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_3a6b:
	/* 0x3a6b: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_3a73:
	/* 0x3a73: mov    rdi,QWORD PTR [rip+0x290] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data_heap));
x86_l_3a7a:
	/* 0x3a7a: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3a7f:
	/* 0x3a7f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3a84:
	/* 0x3a84: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3a87:
	/* 0x3a87: call   3a8c <data_event_bytes+0x3b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3a8c:
	/* 0x3a8c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3a8f:
	/* 0x3a8f: je     3b33 <data_event_bytes+0xe2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3a8f, 0x3b33, x86_l_3b33);
x86_l_3a95:
	/* 0x3a95: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3a98:
	/* 0x3a98: mov    DWORD PTR [rax],0x18 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3a9e:
	/* 0x3a9e: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_3aa3:
	/* 0x3aa3: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3aa6:
	/* 0x3aa6: call   3aab <data_event_bytes+0x5a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3aab:
	/* 0x3aab: mov    rbp,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_64);
x86_l_3aae:
	/* 0x3aae: add    rbp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3ab2:
	/* 0x3ab2: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ab6:
	/* 0x3ab6: cmp    rax,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551594ULL);
x86_l_3aba:
	/* 0x3aba: jne    3ae6 <data_event_bytes+0x95> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3aba, 0x3ae6, x86_l_3ae6);
x86_l_3abc:
	/* 0x3abc: lea    rdx,[r12+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3ac1:
	/* 0x3ac1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ac6:
	/* 0x3ac6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3acb:
	/* 0x3acb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3ad0:
	/* 0x3ad0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3ad5:
	/* 0x3ad5: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3ad8:
	/* 0x3ad8: call   3add <data_event_bytes+0x8c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3add:
	/* 0x3add: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ae2:
	/* 0x3ae2: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ae6:
	/* 0x3ae6: mov    eax,0x7d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 125ULL);
x86_l_3aeb:
	/* 0x3aeb: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3aee:
	/* 0x3aee: call   3af3 <data_event_bytes+0xa2> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3af3:
	/* 0x3af3: mov    QWORD PTR [r13+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3af7:
	/* 0x3af7: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3afb:
	/* 0x3afb: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3aff:
	/* 0x3aff: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b03:
	/* 0x3b03: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3b07:
	/* 0x3b07: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3b0a:
	/* 0x3b0a: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3b0d:
	/* 0x3b0d: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_3b10:
	/* 0x3b10: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
x86_l_3b13:
	/* 0x3b13: call   3b62 <do_bytes> */
	X86_SIM_X86_CALL(x86_l_3b62, 0x3b18ULL);
x86_l_3b18:
	/* 0x3b18: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3b1a:
	/* 0x3b1a: js     3b37 <data_event_bytes+0xe6> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3b1a, 0x3b37, x86_l_3b37);
x86_l_3b1c:
	/* 0x3b1c: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b23:
	/* 0x3b23: mov    edx,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_32);
x86_l_3b26:
	/* 0x3b26: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3b28:
	/* 0x3b28: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3b2a:
	/* 0x3b2a: cmp    r14,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_3b2e:
	/* 0x3b2e: cmovne ecx,edx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_32, X86_CC_NE);
x86_l_3b31:
	/* 0x3b31: jmp    3b44 <data_event_bytes+0xf3> */
	X86_SIM_X86_SUB_JMP(0x3b31, 0x3b44, x86_l_3b44);
x86_l_3b33:
	/* 0x3b33: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3b35:
	/* 0x3b35: jmp    3b4f <data_event_bytes+0xfe> */
	X86_SIM_X86_SUB_JMP(0x3b35, 0x3b4f, x86_l_3b4f);
x86_l_3b37:
	/* 0x3b37: mov    DWORD PTR [rbx],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b39:
	/* 0x3b39: mov    DWORD PTR [rbx+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_3b40:
	/* 0x3b40: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3b42:
	/* 0x3b42: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3b44:
	/* 0x3b44: mov    DWORD PTR [rbx+0x8],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3b47:
	/* 0x3b47: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3b4a:
	/* 0x3b4a: mov    eax,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_3b4f:
	/* 0x3b4f: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_3b53:
	/* 0x3b53: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3b54:
	/* 0x3b54: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3b56:
	/* 0x3b56: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3b58:
	/* 0x3b58: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3b5a:
	/* 0x3b5a: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3b5c:
	/* 0x3b5c: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3b5d:
	/* 0x3b5d: jmp    3b62 <do_bytes> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_3b62 */
x86_l_3b62:
	/* 0x3b62: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3b63:
	/* 0x3b63: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3b65:
	/* 0x3b65: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3b67:
	/* 0x3b67: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3b69:
	/* 0x3b69: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3b6b:
	/* 0x3b6b: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3b6c:
	/* 0x3b6c: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b6d:
	/* 0x3b6d: mov    rbx,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RCX, X86_WIDTH_64);
x86_l_3b70:
	/* 0x3b70: mov    r14,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDX, X86_WIDTH_64);
x86_l_3b73:
	/* 0x3b73: mov    r15,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RSI, X86_WIDTH_64);
x86_l_3b76:
	/* 0x3b76: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_3b79:
	/* 0x3b79: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3b7eULL);
x86_l_3b7e:
	/* 0x3b7e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3b80:
	/* 0x3b80: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3b80, 0x3d29, x86_l_3d29);
x86_l_3b86:
	/* 0x3b86: mov    r13d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_32);
x86_l_3b89:
	/* 0x3b89: and    r13d,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3b90:
	/* 0x3b90: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3b93:
	/* 0x3b93: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3b96:
	/* 0x3b96: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3b96, 0x3db6, x86_l_3db6);
x86_l_3b9c:
	/* 0x3b9c: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3ba0:
	/* 0x3ba0: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3ba3:
	/* 0x3ba3: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3ba6:
	/* 0x3ba6: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3babULL);
x86_l_3bab:
	/* 0x3bab: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3bad:
	/* 0x3bad: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3bad, 0x3d29, x86_l_3d29);
x86_l_3bb3:
	/* 0x3bb3: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3bb8:
	/* 0x3bb8: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_3bbb:
	/* 0x3bbb: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3bbe:
	/* 0x3bbe: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3bc1:
	/* 0x3bc1: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3bc4:
	/* 0x3bc4: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3bc4, 0x3db6, x86_l_3db6);
x86_l_3bca:
	/* 0x3bca: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3bce:
	/* 0x3bce: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3bd1:
	/* 0x3bd1: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3bd4:
	/* 0x3bd4: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3bd9ULL);
x86_l_3bd9:
	/* 0x3bd9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3bdb:
	/* 0x3bdb: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3bdb, 0x3d29, x86_l_3d29);
x86_l_3be1:
	/* 0x3be1: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3be6:
	/* 0x3be6: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3be9:
	/* 0x3be9: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3bec:
	/* 0x3bec: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3bef:
	/* 0x3bef: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3bf2:
	/* 0x3bf2: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3bf2, 0x3db6, x86_l_3db6);
x86_l_3bf8:
	/* 0x3bf8: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3bfc:
	/* 0x3bfc: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3bff:
	/* 0x3bff: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3c02:
	/* 0x3c02: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3c07ULL);
x86_l_3c07:
	/* 0x3c07: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3c09:
	/* 0x3c09: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3c09, 0x3d29, x86_l_3d29);
x86_l_3c0f:
	/* 0x3c0f: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3c14:
	/* 0x3c14: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_3c17:
	/* 0x3c17: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3c1a:
	/* 0x3c1a: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3c1d:
	/* 0x3c1d: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3c20:
	/* 0x3c20: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3c20, 0x3db6, x86_l_3db6);
x86_l_3c26:
	/* 0x3c26: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3c2a:
	/* 0x3c2a: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3c2d:
	/* 0x3c2d: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3c30:
	/* 0x3c30: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3c35ULL);
x86_l_3c35:
	/* 0x3c35: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3c37:
	/* 0x3c37: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3c37, 0x3d29, x86_l_3d29);
x86_l_3c3d:
	/* 0x3c3d: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3c42:
	/* 0x3c42: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3c45:
	/* 0x3c45: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3c48:
	/* 0x3c48: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3c4b:
	/* 0x3c4b: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3c4e:
	/* 0x3c4e: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3c4e, 0x3db6, x86_l_3db6);
x86_l_3c54:
	/* 0x3c54: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3c58:
	/* 0x3c58: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3c5b:
	/* 0x3c5b: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3c5e:
	/* 0x3c5e: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3c63ULL);
x86_l_3c63:
	/* 0x3c63: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3c65:
	/* 0x3c65: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3c65, 0x3d29, x86_l_3d29);
x86_l_3c6b:
	/* 0x3c6b: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3c70:
	/* 0x3c70: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_3c73:
	/* 0x3c73: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3c76:
	/* 0x3c76: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3c79:
	/* 0x3c79: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3c7c:
	/* 0x3c7c: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3c7c, 0x3db6, x86_l_3db6);
x86_l_3c82:
	/* 0x3c82: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3c86:
	/* 0x3c86: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3c89:
	/* 0x3c89: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3c8c:
	/* 0x3c8c: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3c91ULL);
x86_l_3c91:
	/* 0x3c91: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3c93:
	/* 0x3c93: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3c93, 0x3d29, x86_l_3d29);
x86_l_3c99:
	/* 0x3c99: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3c9e:
	/* 0x3c9e: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3ca1:
	/* 0x3ca1: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3ca4:
	/* 0x3ca4: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3ca7:
	/* 0x3ca7: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3caa:
	/* 0x3caa: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3caa, 0x3db6, x86_l_3db6);
x86_l_3cb0:
	/* 0x3cb0: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3cb4:
	/* 0x3cb4: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3cb7:
	/* 0x3cb7: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3cba:
	/* 0x3cba: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3cbfULL);
x86_l_3cbf:
	/* 0x3cbf: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3cc1:
	/* 0x3cc1: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3cc1, 0x3d29, x86_l_3d29);
x86_l_3cc3:
	/* 0x3cc3: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3cc8:
	/* 0x3cc8: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_3ccb:
	/* 0x3ccb: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3cce:
	/* 0x3cce: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3cd1:
	/* 0x3cd1: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3cd4:
	/* 0x3cd4: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3cd4, 0x3db6, x86_l_3db6);
x86_l_3cda:
	/* 0x3cda: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3cde:
	/* 0x3cde: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3ce1:
	/* 0x3ce1: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3ce4:
	/* 0x3ce4: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3ce9ULL);
x86_l_3ce9:
	/* 0x3ce9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3ceb:
	/* 0x3ceb: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3ceb, 0x3d29, x86_l_3d29);
x86_l_3ced:
	/* 0x3ced: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3cf2:
	/* 0x3cf2: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3cf5:
	/* 0x3cf5: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3cf8:
	/* 0x3cf8: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3cfb:
	/* 0x3cfb: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3cfe:
	/* 0x3cfe: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3cfe, 0x3db6, x86_l_3db6);
x86_l_3d04:
	/* 0x3d04: add    r14,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3d07:
	/* 0x3d07: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3d0a:
	/* 0x3d0a: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_3d0d:
	/* 0x3d0d: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_3d10:
	/* 0x3d10: call   3dcc <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_3dcc, 0x3d15ULL);
x86_l_3d15:
	/* 0x3d15: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3d17:
	/* 0x3d17: js     3d29 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3d17, 0x3d29, x86_l_3d29);
x86_l_3d19:
	/* 0x3d19: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_3d1e:
	/* 0x3d1e: add    rax,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3d21:
	/* 0x3d21: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_3d24:
	/* 0x3d24: jmp    3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JMP(0x3d24, 0x3db6, x86_l_3db6);
x86_l_3d29:
	/* 0x3d29: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_3d2c:
	/* 0x3d2c: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_3d34:
	/* 0x3d34: mov    rdi,QWORD PTR [rip+0x3b0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
x86_l_3d3b:
	/* 0x3d3b: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3d40:
	/* 0x3d40: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3d45:
	/* 0x3d45: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3d48:
	/* 0x3d48: call   3d4d <do_bytes+0x1eb> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3d4d:
	/* 0x3d4d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3d50:
	/* 0x3d50: je     3db6 <do_bytes+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d50, 0x3db6, x86_l_3db6);
x86_l_3d52:
	/* 0x3d52: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
x86_l_3d56:
	/* 0x3d56: jg     3d72 <do_bytes+0x210> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x3d56, 0x3d72, x86_l_3d72);
x86_l_3d58:
	/* 0x3d58: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
x86_l_3d5c:
	/* 0x3d5c: je     3d8c <do_bytes+0x22a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d5c, 0x3d8c, x86_l_3d8c);
x86_l_3d5e:
	/* 0x3d5e: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
x86_l_3d62:
	/* 0x3d62: je     3da4 <do_bytes+0x242> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d62, 0x3da4, x86_l_3da4);
x86_l_3d64:
	/* 0x3d64: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551600ULL);
x86_l_3d68:
	/* 0x3d68: jne    3d9c <do_bytes+0x23a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3d68, 0x3d9c, x86_l_3d9c);
x86_l_3d6a:
	/* 0x3d6a: add    rax,0x558 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_3d70:
	/* 0x3d70: jmp    3db2 <do_bytes+0x250> */
	X86_SIM_X86_SUB_JMP(0x3d70, 0x3db2, x86_l_3db2);
x86_l_3d72:
	/* 0x3d72: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
x86_l_3d76:
	/* 0x3d76: je     3d94 <do_bytes+0x232> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d76, 0x3d94, x86_l_3d94);
x86_l_3d78:
	/* 0x3d78: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
x86_l_3d7c:
	/* 0x3d7c: je     3dac <do_bytes+0x24a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d7c, 0x3dac, x86_l_3dac);
x86_l_3d7e:
	/* 0x3d7e: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
x86_l_3d82:
	/* 0x3d82: jne    3d9c <do_bytes+0x23a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3d82, 0x3d9c, x86_l_3d9c);
x86_l_3d84:
	/* 0x3d84: add    rax,0x548 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_3d8a:
	/* 0x3d8a: jmp    3db2 <do_bytes+0x250> */
	X86_SIM_X86_SUB_JMP(0x3d8a, 0x3db2, x86_l_3db2);
x86_l_3d8c:
	/* 0x3d8c: add    rax,0x568 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_3d92:
	/* 0x3d92: jmp    3db2 <do_bytes+0x250> */
	X86_SIM_X86_SUB_JMP(0x3d92, 0x3db2, x86_l_3db2);
x86_l_3d94:
	/* 0x3d94: add    rax,0x570 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_3d9a:
	/* 0x3d9a: jmp    3db2 <do_bytes+0x250> */
	X86_SIM_X86_SUB_JMP(0x3d9a, 0x3db2, x86_l_3db2);
x86_l_3d9c:
	/* 0x3d9c: add    rax,0x540 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_3da2:
	/* 0x3da2: jmp    3db2 <do_bytes+0x250> */
	X86_SIM_X86_SUB_JMP(0x3da2, 0x3db2, x86_l_3db2);
x86_l_3da4:
	/* 0x3da4: add    rax,0x560 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_3daa:
	/* 0x3daa: jmp    3db2 <do_bytes+0x250> */
	X86_SIM_X86_SUB_JMP(0x3daa, 0x3db2, x86_l_3db2);
x86_l_3dac:
	/* 0x3dac: add    rax,0x550 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_3db2:
	/* 0x3db2: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3db6:
	/* 0x3db6: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_3db9:
	/* 0x3db9: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3dbd:
	/* 0x3dbd: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3dbe:
	/* 0x3dbe: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3dc0:
	/* 0x3dc0: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3dc2:
	/* 0x3dc2: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3dc4:
	/* 0x3dc4: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3dc6:
	/* 0x3dc6: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3dc7:
	/* 0x3dc7: jmp    3dcc <__do_bytes> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_3dcc */
x86_l_3dcc:
	/* 0x3dcc: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3dce:
	/* 0x3dce: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3dd0:
	/* 0x3dd0: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3dd2:
	/* 0x3dd2: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3dd3:
	/* 0x3dd3: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dd4:
	/* 0x3dd4: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3dd7:
	/* 0x3dd7: js     3e6f <__do_bytes+0xa3> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3dd7, 0x3e6f, x86_l_3e6f);
x86_l_3ddd:
	/* 0x3ddd: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_3de0:
	/* 0x3de0: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
x86_l_3de3:
	/* 0x3de3: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
x86_l_3dea:
	/* 0x3dea: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
x86_l_3def:
	/* 0x3def: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
x86_l_3df3:
	/* 0x3df3: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3df7:
	/* 0x3df7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3dfc:
	/* 0x3dfc: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
x86_l_3dfe:
	/* 0x3dfe: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3e01:
	/* 0x3e01: call   3e06 <__do_bytes+0x3a> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3e06:
	/* 0x3e06: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3e08:
	/* 0x3e08: js     3e9a <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3e08, 0x3e9a, x86_l_3e9a);
x86_l_3e0e:
	/* 0x3e0e: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3e12:
	/* 0x3e12: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3e16:
	/* 0x3e16: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_3e1e:
	/* 0x3e1e: mov    rdi,QWORD PTR [rip+0x620] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
x86_l_3e25:
	/* 0x3e25: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3e2a:
	/* 0x3e2a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3e2f:
	/* 0x3e2f: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3e32:
	/* 0x3e32: call   3e37 <__do_bytes+0x6b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3e37:
	/* 0x3e37: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3e3a:
	/* 0x3e3a: je     3e78 <__do_bytes+0xac> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3e3a, 0x3e78, x86_l_3e78);
x86_l_3e3c:
	/* 0x3e3c: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_3e40:
	/* 0x3e40: je     3e78 <__do_bytes+0xac> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3e40, 0x3e78, x86_l_3e78);
x86_l_3e42:
	/* 0x3e42: mov    rsi,QWORD PTR [rip+0x620] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
x86_l_3e49:
	/* 0x3e49: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_3e4e:
	/* 0x3e4e: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_3e53:
	/* 0x3e53: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3e56:
	/* 0x3e56: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
x86_l_3e5b:
	/* 0x3e5b: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
x86_l_3e5e:
	/* 0x3e5e: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_3e61:
	/* 0x3e61: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3e64:
	/* 0x3e64: call   3e69 <__do_bytes+0x9d> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3e69:
	/* 0x3e69: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3e6b:
	/* 0x3e6b: js     3e9a <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3e6b, 0x3e9a, x86_l_3e9a);
x86_l_3e6d:
	/* 0x3e6d: jmp    3e9d <__do_bytes+0xd1> */
	X86_SIM_X86_SUB_JMP(0x3e6d, 0x3e9d, x86_l_3e9d);
x86_l_3e6f:
	/* 0x3e6f: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_3e76:
	/* 0x3e76: jmp    3e9d <__do_bytes+0xd1> */
	X86_SIM_X86_SUB_JMP(0x3e76, 0x3e9d, x86_l_3e9d);
x86_l_3e78:
	/* 0x3e78: mov    rdi,QWORD PTR [rip+0x620] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
x86_l_3e7f:
	/* 0x3e7f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3e81:
	/* 0x3e81: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
x86_l_3e86:
	/* 0x3e86: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_3e89:
	/* 0x3e89: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_3e8c:
	/* 0x3e8c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3e8e:
	/* 0x3e8e: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_3e91:
	/* 0x3e91: call   3e96 <__do_bytes+0xca> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3e96:
	/* 0x3e96: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3e98:
	/* 0x3e98: jns    3e9d <__do_bytes+0xd1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x3e98, 0x3e9d, x86_l_3e9d);
x86_l_3e9a:
	/* 0x3e9a: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_3e9d:
	/* 0x3e9d: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_3ea0:
	/* 0x3ea0: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3ea4:
	/* 0x3ea4: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3ea5:
	/* 0x3ea5: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3ea7:
	/* 0x3ea7: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3ea9:
	/* 0x3ea9: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3eab:
	/* 0x3eab: jmp    3eb0 <__do_bytes+0xe4> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x2279ULL: goto x86_l_2279;
	case 0x2fe3ULL: goto x86_l_2fe3;
	case 0x3b18ULL: goto x86_l_3b18;
	case 0x3b7eULL: goto x86_l_3b7e;
	case 0x3babULL: goto x86_l_3bab;
	case 0x3bd9ULL: goto x86_l_3bd9;
	case 0x3c07ULL: goto x86_l_3c07;
	case 0x3c35ULL: goto x86_l_3c35;
	case 0x3c63ULL: goto x86_l_3c63;
	case 0x3c91ULL: goto x86_l_3c91;
	case 0x3cbfULL: goto x86_l_3cbf;
	case 0x3ce9ULL: goto x86_l_3ce9;
	case 0x3d15ULL: goto x86_l_3d15;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
