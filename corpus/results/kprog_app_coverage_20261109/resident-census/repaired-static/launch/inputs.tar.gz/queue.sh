#!/bin/bash
set -e
export PYTHONDONTWRITEBYTECODE=1
python3 - <<'WAIT'
import os,select
try:
 fd=os.pidfd_open(3891389);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:
 pass
WAIT
python3 /var/tmp/kprog-tmp/A/resident-census-repaired/source/kprog/corpus_resident_verifier.py publish --scratch /var/tmp/kprog-tmp/A/resident-census-linked --output /workspaces/repository/corpus/results/kprog_app_coverage_20261109/resident-census/linked-static --previous-results /var/tmp/kprog-tmp/A/resident-census/stock-results.json
exec taskset -c 16-19 nice -n 10 python3 /var/tmp/kprog-tmp/A/resident-census-repaired/source/kprog/corpus_resident_verifier.py host --scratch /var/tmp/kprog-tmp/A/resident-census-repaired --output /workspaces/repository/corpus/results/kprog_app_coverage_20261109/resident-census/repaired-static --previous-results /workspaces/repository/corpus/results/kprog_app_coverage_20261109/resident-census/linked-static/stock-results.json
