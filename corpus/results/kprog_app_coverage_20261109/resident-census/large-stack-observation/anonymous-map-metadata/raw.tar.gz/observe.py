from pathlib import Path
import json,importlib.util,sys,tempfile,ctypes as c,hashlib,traceback
R=Path('/workspaces/repository');D=Path('/var/tmp/kprog-tmp/A/large-stack-observation/map-metadata')
I=Path('/var/tmp/kprog-tmp/A/large-stack-observation/inputs')
sys.path.insert(0,str(R/'kprog'))
label=sys.argv[1];spec=importlib.util.spec_from_file_location('observed_submit',R/'kprog/selftests/submit.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.tools_for_arch=lambda arch:(I/'stock-runtime',None)
original_mkdtemp=tempfile.mkdtemp
pins=D/'pins';pins.mkdir(exist_ok=True)
def directory(*a,**kw):
 if kw.get('dir')=='/sys/fs/bpf':kw['dir']=str(pins)
 return original_mkdtemp(*a,**kw)
tempfile.mkdtemp=directory
inventory=json.loads((I/'run-inventory.json').read_text());resources={(r['application'],r['source_prog_id']):r for r in json.loads((I/'resource-index.json').read_text())['programs']}
apps={a['application']:a.get('map_inventory',[]) for a in inventory['applications']}
records=[]
for row in inventory['programs']:
 if row['application']!='otelcol-ebpf-profiler/profiling':continue
 base=list(row['map_info']);names={m['name'] for m in base}
 base.extend(m for m in apps[row['application']] if m.get('name') not in names)
 for kind,infos in [('all',base),('named_reference',[m for m in base if m.get('name')])]:
  obj=module.ObjectResources.__new__(module.ObjectResources);record=dict(program=row['name'],source_prog_id=row['source_prog_id'],mode=kind,anonymous_records=sum(not m.get('name') for m in infos))
  work=D/(label+'-'+str(row['source_prog_id'])+'-'+kind);work.mkdir(exist_ok=True)
  try:
   resource=resources[(row['application'],row['source_prog_id'])]
   module.ObjectResources.__init__(obj,'x86',Path(resource['bpf_object']),row['native_candidates'][0]['symbol'],directory=work,map_info=infos)
   obj.bind('bpf_map__type',c.c_int,c.c_void_p);obj.bind('bpf_map__map_flags',c.c_uint32,c.c_void_p)
   maps=[]
   for item in obj.maps:
    name=obj.lib.bpf_map__name(item).decode()
    if obj.lib.bpf_map__is_internal(item):name=name[name.index('.'):] if '.' in name else name
    maps.append(dict(name=name,type=obj.lib.bpf_map__type(item),key=obj.lib.bpf_map__key_size(item),value=obj.lib.bpf_map__value_size(item),max_entries=obj.lib.bpf_map__max_entries(item),flags=obj.lib.bpf_map__map_flags(item)))
   record.update(status='opened_metadata',maps=maps,configured_maps=obj.configured_maps,program_type=obj.lib.bpf_program__type(obj.program),expected_attach=obj.lib.bpf_program__expected_attach_type(obj.program))
  except Exception as e:
   record.update(status='metadata_error',error=repr(e),traceback=traceback.format_exc())
  finally:
   obj.close()
  records.append(record)
report=dict(kind='actual_libbpf_object_metadata',phase=label,source_sha256=hashlib.sha256((R/'kprog/selftests/submit.py').read_bytes()).hexdigest(),maps_created=0,program_loads=0,native_executions=0,programs=13,rows=records)
(D/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(label,[(x['mode'],x['status'],x.get('error')) for x in records],flush=True)
