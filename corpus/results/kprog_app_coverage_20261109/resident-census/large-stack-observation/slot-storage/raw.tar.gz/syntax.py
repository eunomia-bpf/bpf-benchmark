from pathlib import Path
import os,sys,re,shlex,subprocess,json,hashlib,concurrent.futures
D=Path('/var/tmp/kprog-tmp/A/large-stack-observation/slot-storage');R=Path('/workspaces/repository')
namespace={}
generator=(D/'observe.py').read_text().split('def function(',1)[0]
exec(compile(generator,'master-patch-decoder','exec'),namespace)
patched=namespace['patched'];K=namespace['K']
B=Path('/var/tmp/kprog-tmp/S17/x86-build')
capacity=re.search(r'#define MAX_BPF_STACK\s+(\d+)',patched['include/linux/filter.h'])[1]
helper=(R/'kprog/stock-path/include/observation_stack_mask.h').read_text()
header=patched['include/linux/bpf_verifier.h'].replace('#include <linux/kprog_observation_stack_mask.h>',helper)
prefix=('#include <linux/filter.h>\n#undef MAX_BPF_STACK\n#define MAX_BPF_STACK '+capacity+'\n'+header).encode()
fd=os.memfd_create('kprog-observation-headers',0);os.write(fd,prefix)
header_name='/proc/'+str(os.getpid())+'/fd/'+str(fd)
def one(name):
 saved=(B/'kernel/bpf'/('.'+name+'.o.cmd')).read_text().splitlines()[0].split(' := ',1)[1]
 tokens=shlex.split(saved);tokens=tokens[:tokens.index(';')] if ';' in tokens else tokens
 args=[];skip=False
 for arg in tokens:
  if skip:skip=False;continue
  if arg in {'-o','-MF'}:skip=True;continue
  if arg=='-c' or arg.startswith('-Wp,-MMD,') or arg.endswith('/kernel/bpf/'+name+'.c'):continue
  args.append(arg)
 args += ['-iquote',str(K/'kernel/bpf'),'-include',header_name,'-fsyntax-only','-x','c','-']
 source=patched.get('kernel/bpf/'+name+'.c',(K/'kernel/bpf'/(name+'.c')).read_text())
 done=subprocess.run(args,cwd=B,input=source,text=True,capture_output=True)
 row=dict(translation_unit=name,command=args,returncode=done.returncode,stdout=done.stdout,stderr=done.stderr,source_sha256=hashlib.sha256(source.encode()).hexdigest())
 (D/(name+'.syntax.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(one,['verifier','liveness','log']))
os.close(fd)
(D/'syntax-results.json').write_text(json.dumps(dict(kind='kernel_translation_unit_syntax_only',kernel_base='35ea2cde39fc',header_sha256=hashlib.sha256(prefix).hexdigest(),patch_sha256=hashlib.sha256((R/'kprog/stock-path/large-stack-observation.patch').read_bytes()).hexdigest(),canonical_kernel_source_edits=0,rows=rows),indent=2)+'\n')
