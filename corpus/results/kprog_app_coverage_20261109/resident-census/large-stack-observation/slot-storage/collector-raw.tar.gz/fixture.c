
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#define MAX_BPF_STACK 8192
#define MAX_CALL_FRAMES 8
#include "/workspaces/repository/kprog/stock-path/include/observation_stack_mask.h"
typedef uint8_t u8;typedef uint16_t u16;typedef uint32_t u32;typedef unsigned long long u64;
#define BIT(n) (1UL<<(n))
#define static_assert _Static_assert
#define BPF_LOG_LEVEL2 2
#define SCALAR_VALUE 1
#define BPF_ADD_CONST (1U<<31)
struct bpf_reg_state {u32 type,id;};
#define IS_ERR(p) false
#define PTR_ERR(p) (-1)
#define unlikely(x) (x)
#define for_each_set_bit(i,b,n) for((i)=0;(i)<(n);(i)++) if((b)[(i)/64]&(1UL<<((i)%64)))
enum {
	/* instruction references stack slot through PTR_TO_STACK register;
	 * we also store stack's frame number in lower 3 bits (MAX_CALL_FRAMES is 8)
	 * and accessed stack slot's index in next 10 bits (MAX_BPF_STACK is 8192,
	 * 8 bytes per slot, so slot index (spi) is [0, 1023])
	 */
	INSN_F_FRAMENO_MASK = 0x7, /* 3 bits */

	INSN_F_SPI_MASK = 0x3ff, /* 10 bits */
	INSN_F_SPI_SHIFT = 3, /* shifted 3 bits to the left */

	INSN_F_STACK_ACCESS = BIT(13),

	INSN_F_DST_REG_STACK = BIT(14), /* dst_reg is PTR_TO_STACK */
	INSN_F_SRC_REG_STACK = BIT(15), /* src_reg is PTR_TO_STACK */
	/* total 16 bits are used now. */
};
struct bpf_jmp_history_entry {
	u32 idx;
	/* insn idx can't be bigger than 1 million */
	u32 prev_idx : 20;
	/* special INSN_F_xxx flags */
	u32 flags : 16;
	/* additional registers that need precision tracking when this
	 * jump is backtracked, vector of six 14-bit records
	 */
	unsigned __int128 linked_regs;
};
#define LR_FRAMENO_BITS	3
#define LR_SPI_BITS	10
#define LR_ENTRY_BITS	(LR_SPI_BITS + LR_FRAMENO_BITS + 1)
#define LR_SIZE_BITS	4
#define LR_FRAMENO_MASK	((1ull << LR_FRAMENO_BITS) - 1)
#define LR_SPI_MASK	((1ull << LR_SPI_BITS)     - 1)
#define LR_SIZE_MASK	((1ull << LR_SIZE_BITS)    - 1)
#define LR_SPI_OFF	LR_FRAMENO_BITS
#define LR_IS_REG_OFF	(LR_SPI_BITS + LR_FRAMENO_BITS)
#define LINKED_REGS_MAX	6

struct linked_reg {
	u8 frameno;
	union {
		u16 spi;
		u16 regno;
	};
	bool is_reg;
};

struct linked_regs {
	int cnt;
	struct linked_reg entries[LINKED_REGS_MAX];
};

static struct linked_reg *linked_regs_push(struct linked_regs *s)
{
	if (s->cnt < LINKED_REGS_MAX)
		return &s->entries[s->cnt++];

	return NULL;
}

/* Use u128 as a vector of 6 14-bit values, use first 4-bits to track
 * number of elements currently in stack.
 * Pack one history entry for linked registers as 14 bits in the following format:
 * - 3-bits frameno
 * - 10-bits spi_or_reg
 * - 1-bit  is_reg
 */
static unsigned __int128 linked_regs_pack(struct linked_regs *s)
{
	unsigned __int128 val = 0;
	int i;

	for (i = 0; i < s->cnt; ++i) {
		struct linked_reg *e = &s->entries[i];
		unsigned __int128 tmp = 0;

		tmp |= e->frameno;
		tmp |= e->spi << LR_SPI_OFF;
		tmp |= (e->is_reg ? 1 : 0) << LR_IS_REG_OFF;

		val <<= LR_ENTRY_BITS;
		val |= tmp;
	}
	val <<= LR_SIZE_BITS;
	val |= s->cnt;
	return val;
}

static void linked_regs_unpack(unsigned __int128 val, struct linked_regs *s)
{
	int i;

	s->cnt = val & LR_SIZE_MASK;
	val >>= LR_SIZE_BITS;

	for (i = 0; i < s->cnt; ++i) {
		struct linked_reg *e = &s->entries[i];

		e->frameno =  val & LR_FRAMENO_MASK;
		e->spi     = (val >> LR_SPI_OFF) & LR_SPI_MASK;
		e->is_reg  = (val >> LR_IS_REG_OFF) & 0x1;
		val >>= LR_ENTRY_BITS;
	}
}


struct per_frame_masks {
	kprog_obs_stack_mask may_read;		/* stack slots that may be read by this instruction */
	kprog_obs_stack_mask must_write;		/* stack slots written by this instruction */
	kprog_obs_stack_mask must_write_acc;	/* stack slots written by this instruction and its successors */
	kprog_obs_stack_mask live_before;	/* stack slots that may be read by this insn and its successors */
};

struct log { int level; };
struct bpf_insn_aux_data { bool prune_point; };
struct callchain { u32 curframe; };
struct func_instance {
 struct callchain callchain; bool updated,must_write_dropped;
 bool must_write_set[3]; struct per_frame_masks masks[8][3];
};
struct bpf_liveness { kprog_obs_stack_mask write_masks_acc[8]; u32 write_insn_idx; };
struct bpf_verifier_env {
 struct log log;struct bpf_insn_aux_data *insn_aux_data;
 struct bpf_liveness *liveness;
 u32 scratched_regs;kprog_obs_stack_mask scratched_stack_slots;
 char tmp_str_buf[16384];
};
struct backtrack_state {
 struct bpf_verifier_env *env; u32 frame; u32 reg_masks[8];
 kprog_obs_stack_mask stack_masks[8];
};
struct bpf_iarray {u32 cnt;u32 items[2];};
static struct bpf_iarray successors;
static struct bpf_iarray *bpf_insn_successors(struct bpf_verifier_env *env,u32 index)
{(void)env;(void)index;return &successors;}
static struct per_frame_masks *get_frame_masks(struct func_instance *i,u32 f,u32 index)
{return &i->masks[f][index];}
static struct per_frame_masks *alloc_frame_masks(struct bpf_verifier_env *e,struct func_instance *i,u32 f,u32 index)
{(void)e;return get_frame_masks(i,f,index);}
static u32 relative_idx(struct func_instance *i,u32 index){(void)i;return index;}
static u32 callchain_subprog_start(struct callchain *c){(void)c;return 0;}
static char *fmt_callchain(struct bpf_verifier_env *e,struct callchain *c)
{(void)e;(void)c;return "fixture";}
static unsigned log_calls;
static void bpf_log(struct log *l,const char *f,...){(void)l;(void)f;log_calls++;}
#define REQUIRE(x) do { if (!(x)) {fprintf(stderr,"failed line%d: %s\n",__LINE__,#x);return 1;} } while(0)
static void __collect_linked_regs(struct linked_regs *reg_set, struct bpf_reg_state *reg,
				  u32 id, u32 frameno, u32 spi_or_reg, bool is_reg)
{
	struct linked_reg *e;

	if (reg->type != SCALAR_VALUE || (reg->id & ~BPF_ADD_CONST) != id)
		return;

	e = linked_regs_push(reg_set);
	if (e) {
		e->frameno = frameno;
		e->is_reg = is_reg;
		e->regno = spi_or_reg;
	} else {
		reg->id = 0;
	}
}

static int insn_stack_access_flags(int frameno, int spi)
{
	return INSN_F_STACK_ACCESS | (spi << INSN_F_SPI_SHIFT) | frameno;
}

static int insn_stack_access_spi(int insn_flags)
{
	return (insn_flags >> INSN_F_SPI_SHIFT) & INSN_F_SPI_MASK;
}

static int insn_stack_access_frameno(int insn_flags)
{
	return insn_flags & INSN_F_FRAMENO_MASK;
}

static inline u32 bt_empty(struct backtrack_state *bt)
{
	int i;

	for (i = 0; i <= bt->frame; i++)
		if (bt->reg_masks[i] || !kprog_obs_mask_empty(bt->stack_masks[i]))
			return 0;
	return 1;
}

static inline void bt_set_frame_slot(struct backtrack_state *bt, u32 frame, u32 slot)
{
	kprog_obs_mask_set(&bt->stack_masks[frame], slot);
}

static inline void bt_clear_frame_slot(struct backtrack_state *bt, u32 frame, u32 slot)
{
	kprog_obs_mask_clear(&bt->stack_masks[frame], slot);
}

static inline kprog_obs_stack_mask bt_frame_stack_mask(struct backtrack_state *bt, u32 frame)
{
	return bt->stack_masks[frame];
}

static inline kprog_obs_stack_mask bt_stack_mask(struct backtrack_state *bt)
{
	return bt->stack_masks[bt->frame];
}

static inline bool bt_is_frame_slot_set(struct backtrack_state *bt, u32 frame, u32 slot)
{
	return kprog_obs_mask_test(&bt->stack_masks[frame], slot);
}

void bpf_fmt_stack_mask(char *buf, ssize_t buf_sz, kprog_obs_stack_mask stack_mask)
{
	bool first = true;
	int i, n;

	buf[0] = '\0';

	for_each_set_bit(i, stack_mask.bits, KPROG_OBS_STACK_SLOTS) {
		n = snprintf(buf, buf_sz, "%s%d", first ? "" : ",", -(i + 1) * 8);
		first = false;
		buf += n;
		buf_sz -= n;
		if (buf_sz < 0)
			break;
	}
}

static inline void mark_reg_scratched(struct bpf_verifier_env *env, u32 regno)
{
	env->scratched_regs |= 1U << regno;
}

static inline void mark_stack_slot_scratched(struct bpf_verifier_env *env, u32 spi)
{
	kprog_obs_mask_set(&env->scratched_stack_slots, spi);
}

static inline bool reg_scratched(const struct bpf_verifier_env *env, u32 regno)
{
	return (env->scratched_regs >> regno) & 1;
}

static inline bool stack_slot_scratched(const struct bpf_verifier_env *env, u64 regno)
{
	return kprog_obs_mask_test(&env->scratched_stack_slots, regno);
}

static inline bool verifier_state_scratched(const struct bpf_verifier_env *env)
{
	return env->scratched_regs || !kprog_obs_mask_empty(env->scratched_stack_slots);
}

static inline void mark_verifier_state_clean(struct bpf_verifier_env *env)
{
	env->scratched_regs = 0U;
	env->scratched_stack_slots = kprog_obs_mask_zero();
}

static inline void mark_verifier_state_scratched(struct bpf_verifier_env *env)
{
	env->scratched_regs = ~0U;
	env->scratched_stack_slots = kprog_obs_mask_all();
}

static int mark_stack_read(struct bpf_verifier_env *env,
			   struct func_instance *instance, u32 frame, u32 insn_idx, kprog_obs_stack_mask mask)
{
	struct per_frame_masks *masks;
	kprog_obs_stack_mask new_may_read;

	masks = alloc_frame_masks(env, instance, frame, insn_idx);
	if (IS_ERR(masks))
		return PTR_ERR(masks);
	new_may_read = kprog_obs_mask_or(masks->may_read, mask);
	if (!kprog_obs_mask_equal(new_may_read, masks->may_read) &&
	    !kprog_obs_mask_equal(kprog_obs_mask_or(new_may_read, masks->live_before), masks->live_before))
		instance->updated = true;
	masks->may_read = kprog_obs_mask_or(masks->may_read, mask);
	return 0;
}

void bpf_mark_stack_write(struct bpf_verifier_env *env, u32 frame, kprog_obs_stack_mask mask)
{
	env->liveness->write_masks_acc[frame] = kprog_obs_mask_or(env->liveness->write_masks_acc[frame], mask);
}

static int commit_stack_write_marks(struct bpf_verifier_env *env,
				    struct func_instance *instance)
{
	struct bpf_liveness *liveness = env->liveness;
	u32 idx, frame, curframe;
	kprog_obs_stack_mask old_must_write;
	struct per_frame_masks *masks;
	kprog_obs_stack_mask mask;

	if (!instance)
		return 0;

	curframe = instance->callchain.curframe;
	idx = relative_idx(instance, liveness->write_insn_idx);
	for (frame = 0; frame <= curframe; frame++) {
		mask = liveness->write_masks_acc[frame];
		/* avoid allocating frames for zero masks */
		if (kprog_obs_mask_empty(mask) && !instance->must_write_set[idx])
			continue;
		masks = alloc_frame_masks(env, instance, frame, liveness->write_insn_idx);
		if (IS_ERR(masks))
			return PTR_ERR(masks);
		old_must_write = masks->must_write;
		/*
		 * If instruction at this callchain is seen for a first time, set must_write equal
		 * to @mask. Otherwise take intersection with the previous value.
		 */
		if (instance->must_write_set[idx])
			mask = kprog_obs_mask_and(mask, old_must_write);
		if (!kprog_obs_mask_equal(old_must_write, mask)) {
			masks->must_write = mask;
			instance->updated = true;
		}
		if (!kprog_obs_mask_empty(kprog_obs_mask_andnot(old_must_write, mask)))
			instance->must_write_dropped = true;
	}
	instance->must_write_set[idx] = true;
	liveness->write_insn_idx = 0;
	return 0;
}

static void log_mask_change(struct bpf_verifier_env *env, struct callchain *callchain,
			    char *pfx, u32 frame, u32 insn_idx, kprog_obs_stack_mask old, kprog_obs_stack_mask new)
{
	kprog_obs_stack_mask changed_bits = kprog_obs_mask_xor(old, new);
	kprog_obs_stack_mask new_ones = kprog_obs_mask_and(new, changed_bits);
	kprog_obs_stack_mask new_zeros = kprog_obs_mask_andnot(changed_bits, new);

	if (kprog_obs_mask_empty(changed_bits))
		return;
	bpf_log(&env->log, "%s frame %d insn %d ", fmt_callchain(env, callchain), frame, insn_idx);
	if (!kprog_obs_mask_empty(new_ones)) {
		bpf_fmt_stack_mask(env->tmp_str_buf, sizeof(env->tmp_str_buf), new_ones);
		bpf_log(&env->log, "+%s %s ", pfx, env->tmp_str_buf);
	}
	if (!kprog_obs_mask_empty(new_zeros)) {
		bpf_fmt_stack_mask(env->tmp_str_buf, sizeof(env->tmp_str_buf), new_zeros);
		bpf_log(&env->log, "-%s %s", pfx, env->tmp_str_buf);
	}
	bpf_log(&env->log, "\n");
}

static inline bool update_insn(struct bpf_verifier_env *env,
			       struct func_instance *instance, u32 frame, u32 insn_idx)
{
	struct bpf_insn_aux_data *aux = env->insn_aux_data;
	kprog_obs_stack_mask new_before, new_after, must_write_acc;
	struct per_frame_masks *insn, *succ_insn;
	struct bpf_iarray *succ;
	u32 s;
	bool changed;

	succ = bpf_insn_successors(env, insn_idx);
	if (succ->cnt == 0)
		return false;

	changed = false;
	insn = get_frame_masks(instance, frame, insn_idx);
	new_before = kprog_obs_mask_zero();
	new_after = kprog_obs_mask_zero();
	/*
	 * New "must_write_acc" is an intersection of all "must_write_acc"
	 * of successors plus all "must_write" slots of instruction itself.
	 */
	must_write_acc = kprog_obs_mask_all();
	for (s = 0; s < succ->cnt; ++s) {
		succ_insn = get_frame_masks(instance, frame, succ->items[s]);
		new_after = kprog_obs_mask_or(new_after, succ_insn->live_before);
		must_write_acc = kprog_obs_mask_and(must_write_acc, succ_insn->must_write_acc);
	}
	must_write_acc = kprog_obs_mask_or(must_write_acc, insn->must_write);
	/*
	 * New "live_before" is a union of all "live_before" of successors
	 * minus slots written by instruction plus slots read by instruction.
	 */
	new_before = kprog_obs_mask_or(kprog_obs_mask_andnot(new_after, insn->must_write), insn->may_read);
	changed |= !kprog_obs_mask_equal(new_before, insn->live_before);
	changed |= !kprog_obs_mask_equal(must_write_acc, insn->must_write_acc);
	if (unlikely(env->log.level & BPF_LOG_LEVEL2) &&
	    (!kprog_obs_mask_empty(insn->may_read) || !kprog_obs_mask_empty(insn->must_write) ||
	     insn_idx == callchain_subprog_start(&instance->callchain) ||
	     aux[insn_idx].prune_point)) {
		log_mask_change(env, &instance->callchain, "live",
				frame, insn_idx, insn->live_before, new_before);
		log_mask_change(env, &instance->callchain, "written",
				frame, insn_idx, insn->must_write_acc, must_write_acc);
	}
	insn->live_before = new_before;
	insn->must_write_acc = must_write_acc;
	return changed;
}

static bool is_live_before(struct func_instance *instance, u32 insn_idx, u32 frameno, u32 spi)
{
	struct per_frame_masks *masks;

	masks = get_frame_masks(instance, frameno, insn_idx);
	return masks && kprog_obs_mask_test(&masks->live_before, spi);
}

static uint64_t seed=0x9a78309bcc718127ULL;
static unsigned random_bit(void){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return seed&1;}
int main(void){
 unsigned i,j,frame,flags,round;unsigned long long observations=0;
 struct bpf_insn_aux_data aux[3]={};struct bpf_liveness live={};
 struct bpf_verifier_env env={.insn_aux_data=aux,.liveness=&live};
 struct backtrack_state bt={.env=&env,.frame=7};
 kprog_obs_stack_mask zero=kprog_obs_mask_zero(),all=kprog_obs_mask_all();
 REQUIRE(sizeof(kprog_obs_stack_mask)==128);REQUIRE(kprog_obs_mask_empty(zero));
 for(i=0;i<1024;i++){
  kprog_obs_stack_mask bit=kprog_obs_mask_bit(i);
  REQUIRE(!kprog_obs_mask_equal(bit,zero));
  REQUIRE(kprog_obs_mask_equal(kprog_obs_mask_or(bit,bit),bit));
  REQUIRE(kprog_obs_mask_empty(kprog_obs_mask_andnot(bit,bit)));
  for(j=0;j<1024;j++){
   REQUIRE(kprog_obs_mask_test(&bit,j)==(i==j));observations++;
  }
  for(frame=0;frame<8;frame++){
   {
    struct bpf_reg_state reg={.type=SCALAR_VALUE,.id=17};
    struct linked_regs collected={},decoded={};
    __collect_linked_regs(&collected,&reg,17,frame,i,false);
    if(collected.entries[0].spi!=i)
      fprintf(stderr,"collector slot=%u stored=%u frame=%u\n",i,collected.entries[0].spi,frame);
    REQUIRE(collected.cnt==1 && collected.entries[0].spi==i);
    linked_regs_unpack(linked_regs_pack(&collected),&decoded);
    REQUIRE(decoded.entries[0].spi==i && decoded.entries[0].frameno==frame);
    observations++;
   }
   bt_set_frame_slot(&bt,frame,i);REQUIRE(!bt_empty(&bt));
   REQUIRE(bt_is_frame_slot_set(&bt,frame,i));
   REQUIRE(kprog_obs_mask_equal(bt_frame_stack_mask(&bt,frame),bit));
   bt.frame=frame;REQUIRE(kprog_obs_mask_equal(bt_stack_mask(&bt),bit));bt.frame=7;
   bt_clear_frame_slot(&bt,frame,i);REQUIRE(bt_empty(&bt));
   for(flags=0;flags<4;flags++){
    struct bpf_jmp_history_entry hist={};
    hist.flags=insn_stack_access_flags(frame,i)|
        ((flags&1)?INSN_F_DST_REG_STACK:0)|((flags&2)?INSN_F_SRC_REG_STACK:0);
    REQUIRE(insn_stack_access_spi(hist.flags)==(int)i);
    REQUIRE(insn_stack_access_frameno(hist.flags)==(int)frame);observations++;
   }
  }
  mark_verifier_state_clean(&env);mark_stack_slot_scratched(&env,i);
  REQUIRE(verifier_state_scratched(&env));REQUIRE(stack_slot_scratched(&env,i));
  REQUIRE(!stack_slot_scratched(&env,(i+64)%1024));
 }
 for(frame=0;frame<8;frame++)for(i=0;i<=10;i++){
  struct bpf_reg_state reg={.type=SCALAR_VALUE,.id=17};
  struct linked_regs collected={},decoded={};
  __collect_linked_regs(&collected,&reg,17,frame,i,true);
  linked_regs_unpack(linked_regs_pack(&collected),&decoded);
  REQUIRE(decoded.entries[0].regno==i && decoded.entries[0].is_reg);
  observations++;
 }
 mark_verifier_state_scratched(&env);
 for(i=0;i<1024;i++)REQUIRE(stack_slot_scratched(&env,i));
 mark_verifier_state_clean(&env);mark_reg_scratched(&env,10);REQUIRE(reg_scratched(&env,10));
 mark_verifier_state_clean(&env);
 for(i=0;i<1024;i++)REQUIRE(kprog_obs_mask_test(&all,i));
 for(round=0;round<128;round++){
  struct func_instance instance={};unsigned char input[6][1024];
  struct per_frame_masks *cur=&instance.masks[0][0];
  kprog_obs_stack_mask *values[6]={&cur->may_read,&cur->must_write,
      &cur->live_before,&cur->must_write_acc,
      &instance.masks[0][1].live_before,&instance.masks[0][2].live_before};
  for(i=0;i<6;i++)for(j=0;j<1024;j++){
   input[i][j]=random_bit();if(input[i][j])kprog_obs_mask_set(values[i],j);
  }
  instance.masks[0][1].must_write_acc=cur->must_write_acc;
  instance.masks[0][2].must_write_acc=cur->may_read;
  successors.cnt=2;successors.items[0]=1;successors.items[1]=2;
  bool expected_changed=false;
  for(j=0;j<1024;j++){
   unsigned expected_before=((input[4][j]||input[5][j])&&!input[1][j])||input[0][j];
   unsigned expected_written=(input[3][j]&&input[0][j])||input[1][j];
   expected_changed|=(expected_before!=input[2][j])||(expected_written!=input[3][j]);
  }
  REQUIRE(update_insn(&env,&instance,0,0)==expected_changed);
  for(j=0;j<1024;j++){
   REQUIRE(kprog_obs_mask_test(&cur->live_before,j)==(((input[4][j]||input[5][j])&&!input[1][j])||input[0][j]));
   REQUIRE(kprog_obs_mask_test(&cur->must_write_acc,j)==((input[3][j]&&input[0][j])||input[1][j]));
   REQUIRE(is_live_before(&instance,0,0,j)==kprog_obs_mask_test(&cur->live_before,j));observations++;
  }
  REQUIRE(kprog_obs_mask_equal(kprog_obs_mask_xor(all,all),zero));
 }
 {struct func_instance instance={};
  unsigned picks[]={5,63,64,1023};
  for(i=0;i<4;i++)bpf_mark_stack_write(&env,0,kprog_obs_mask_bit(picks[i]));
  REQUIRE(commit_stack_write_marks(&env,&instance)==0);
  for(i=0;i<4;i++)REQUIRE(kprog_obs_mask_test(&instance.masks[0][0].must_write,picks[i]));
  live.write_masks_acc[0]=kprog_obs_mask_or(kprog_obs_mask_bit(5),kprog_obs_mask_bit(64));
  REQUIRE(commit_stack_write_marks(&env,&instance)==0);
  REQUIRE(instance.must_write_dropped);
  for(i=0;i<1024;i++)REQUIRE(kprog_obs_mask_test(&instance.masks[0][0].must_write,i)==(i==5||i==64));
  instance.updated=false;
  REQUIRE(mark_stack_read(&env,&instance,0,0,kprog_obs_mask_bit(1023))==0);
  REQUIRE(instance.updated&&kprog_obs_mask_test(&instance.masks[0][0].may_read,1023));
  log_mask_change(&env,&instance.callchain,"fixture",0,0,zero,all);REQUIRE(log_calls>0);
 }
 for(round=0;round<1024;round++){
  struct linked_regs input={},output={};
  for(i=0;i<6;i++){
   struct linked_reg *e=linked_regs_push(&input);
   e->frameno=(round+i)%8;e->spi=(round+173*i)%1024;e->is_reg=(i+round)&1;
  }
  unsigned __int128 packed=linked_regs_pack(&input);linked_regs_unpack(packed,&output);
  REQUIRE(output.cnt==6);
  for(i=0;i<6;i++){
   REQUIRE(output.entries[i].frameno==input.entries[5-i].frameno);
   REQUIRE(output.entries[i].spi==input.entries[5-i].spi);
   REQUIRE(output.entries[i].is_reg==input.entries[5-i].is_reg);observations++;
  }
 }
 {char output[16384];kprog_obs_stack_mask m=kprog_obs_mask_or(kprog_obs_mask_bit(31),kprog_obs_mask_bit(1023));
  bpf_fmt_stack_mask(output,sizeof(output),m);REQUIRE(strcmp(output,"-256,-8192")==0);}
 printf("slot observations=%llu slots=1024 frames=8 linked_records=6 liveness_rounds=128\n",observations);
 return 0;
}
