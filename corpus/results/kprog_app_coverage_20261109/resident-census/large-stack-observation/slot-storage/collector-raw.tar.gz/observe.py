from pathlib import Path
import re,subprocess,json,hashlib,concurrent.futures
R=Path('/workspaces/repository');K=Path('/var/tmp/kprog-tmp/CK/linux');D=Path('/var/tmp/kprog-tmp/A/large-stack-observation/slot-storage')
patch=(R/'kprog/stock-path/large-stack-observation.patch').read_text()
# Reconstruct compiler-fixture snippets directly from the master-owned diff.
patched={};lines=patch.splitlines(True);at=0
while at<len(lines):
 if not lines[at].startswith('--- a/'):at+=1;continue
 name=lines[at][6:].strip();at+=2;original=(K/name).read_text().splitlines(True);result=[];cursor=0
 while at<len(lines) and not lines[at].startswith('--- a/'):
  if not lines[at].startswith('@@'):at+=1;continue
  m=re.match(r'@@ -(\d+)(?:,\d+)? \+\d+(?:,\d+)? @@',lines[at]);start=int(m[1])-1
  result.extend(original[cursor:start]);cursor=start;at+=1
  while at<len(lines) and lines[at][:1] in {' ','+','-'} and not lines[at].startswith('--- a/'):
   line=lines[at];op=line[0];body=line[1:]
   if op in {' ','-'}:
    if original[cursor]!=body:raise RuntimeError('patch context changed '+name)
    cursor+=1
   if op in {' ','+'}:result.append(body)
   at+=1
 result.extend(original[cursor:]);patched[name]=''.join(result)
def function(text,name):
 m=re.search(r'^[^\n;]*\b'+name+r'\([^;]*?\)\n\{',text,re.M);start=m.start();opening=text.index('{',m.start());depth=0
 quote=None;escape=False
 for i in range(opening,len(text)):
  c=text[i]
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c==quote:quote=None
  elif c in "\"'":quote=c
  elif c=='{':depth+=1
  elif c=='}':
   depth-=1
   if not depth:return text[start:i+1]+'\n'
 raise RuntimeError('function extent '+name)
h=patched['include/linux/bpf_verifier.h'];v=patched['kernel/bpf/verifier.c'];l=patched['kernel/bpf/liveness.c']
enum_start=h.rfind('enum {',0,h.index('INSN_F_FRAMENO_MASK'));enum_end=h.index('};',enum_start)+2
history=h[h.index('struct bpf_jmp_history_entry {'):h.index('};',h.index('struct bpf_jmp_history_entry {'))+2]
linked=v[v.index('#define LR_FRAMENO_BITS'):v.index('/* for any branch, call, exit')]
frame=l[l.index('struct per_frame_masks {'):l.index('};',l.index('struct per_frame_masks {'))+2]
prefix=r"""
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#define MAX_BPF_STACK 8192
#define MAX_CALL_FRAMES 8
#include "/workspaces/repository/kprog/stock-path/include/observation_stack_mask.h"
typedef uint8_t u8;typedef uint16_t u16;typedef uint32_t u32;typedef unsigned long long u64;
#define BIT(n) (1UL<<(n))
#define static_assert _Static_assert
#define BPF_LOG_LEVEL2 2
#define SCALAR_VALUE 1
#define BPF_ADD_CONST (1U<<31)
struct bpf_reg_state {u32 type,id;};
#define IS_ERR(p) false
#define PTR_ERR(p) (-1)
#define unlikely(x) (x)
#define for_each_set_bit(i,b,n) for((i)=0;(i)<(n);(i)++) if((b)[(i)/64]&(1UL<<((i)%64)))
"""
infra=r"""
struct log { int level; };
struct bpf_insn_aux_data { bool prune_point; };
struct callchain { u32 curframe; };
struct func_instance {
 struct callchain callchain; bool updated,must_write_dropped;
 bool must_write_set[3]; struct per_frame_masks masks[8][3];
};
struct bpf_liveness { kprog_obs_stack_mask write_masks_acc[8]; u32 write_insn_idx; };
struct bpf_verifier_env {
 struct log log;struct bpf_insn_aux_data *insn_aux_data;
 struct bpf_liveness *liveness;
 u32 scratched_regs;kprog_obs_stack_mask scratched_stack_slots;
 char tmp_str_buf[16384];
};
struct backtrack_state {
 struct bpf_verifier_env *env; u32 frame; u32 reg_masks[8];
 kprog_obs_stack_mask stack_masks[8];
};
struct bpf_iarray {u32 cnt;u32 items[2];};
static struct bpf_iarray successors;
static struct bpf_iarray *bpf_insn_successors(struct bpf_verifier_env *env,u32 index)
{(void)env;(void)index;return &successors;}
static struct per_frame_masks *get_frame_masks(struct func_instance *i,u32 f,u32 index)
{return &i->masks[f][index];}
static struct per_frame_masks *alloc_frame_masks(struct bpf_verifier_env *e,struct func_instance *i,u32 f,u32 index)
{(void)e;return get_frame_masks(i,f,index);}
static u32 relative_idx(struct func_instance *i,u32 index){(void)i;return index;}
static u32 callchain_subprog_start(struct callchain *c){(void)c;return 0;}
static char *fmt_callchain(struct bpf_verifier_env *e,struct callchain *c)
{(void)e;(void)c;return "fixture";}
static unsigned log_calls;
static void bpf_log(struct log *l,const char *f,...){(void)l;(void)f;log_calls++;}
#define REQUIRE(x) do { if (!(x)) {fprintf(stderr,"failed line%d: %s\n",__LINE__,#x);return 1;} } while(0)
"""
snippets=[function(v,n) for n in ['__collect_linked_regs','insn_stack_access_flags','insn_stack_access_spi','insn_stack_access_frameno','bt_empty','bt_set_frame_slot','bt_clear_frame_slot','bt_frame_stack_mask','bt_stack_mask','bt_is_frame_slot_set','bpf_fmt_stack_mask']]
snippets += [function(h,n) for n in ['mark_reg_scratched','mark_stack_slot_scratched','reg_scratched','stack_slot_scratched','verifier_state_scratched','mark_verifier_state_clean','mark_verifier_state_scratched']]
# Keep exact source order: formatter precedes debug/update functions.
snippets += [function(l,n) for n in ['mark_stack_read','bpf_mark_stack_write','commit_stack_write_marks','log_mask_change','update_insn','is_live_before']]
main=r"""
static uint64_t seed=0x9a78309bcc718127ULL;
static unsigned random_bit(void){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return seed&1;}
int main(void){
 unsigned i,j,frame,flags,round;unsigned long long observations=0;
 struct bpf_insn_aux_data aux[3]={};struct bpf_liveness live={};
 struct bpf_verifier_env env={.insn_aux_data=aux,.liveness=&live};
 struct backtrack_state bt={.env=&env,.frame=7};
 kprog_obs_stack_mask zero=kprog_obs_mask_zero(),all=kprog_obs_mask_all();
 REQUIRE(sizeof(kprog_obs_stack_mask)==128);REQUIRE(kprog_obs_mask_empty(zero));
 for(i=0;i<1024;i++){
  kprog_obs_stack_mask bit=kprog_obs_mask_bit(i);
  REQUIRE(!kprog_obs_mask_equal(bit,zero));
  REQUIRE(kprog_obs_mask_equal(kprog_obs_mask_or(bit,bit),bit));
  REQUIRE(kprog_obs_mask_empty(kprog_obs_mask_andnot(bit,bit)));
  for(j=0;j<1024;j++){
   REQUIRE(kprog_obs_mask_test(&bit,j)==(i==j));observations++;
  }
  for(frame=0;frame<8;frame++){
   {
    struct bpf_reg_state reg={.type=SCALAR_VALUE,.id=17};
    struct linked_regs collected={},decoded={};
    __collect_linked_regs(&collected,&reg,17,frame,i,false);
    if(collected.entries[0].spi!=i)
      fprintf(stderr,"collector slot=%u stored=%u frame=%u\n",i,collected.entries[0].spi,frame);
    REQUIRE(collected.cnt==1 && collected.entries[0].spi==i);
    linked_regs_unpack(linked_regs_pack(&collected),&decoded);
    REQUIRE(decoded.entries[0].spi==i && decoded.entries[0].frameno==frame);
    observations++;
   }
   bt_set_frame_slot(&bt,frame,i);REQUIRE(!bt_empty(&bt));
   REQUIRE(bt_is_frame_slot_set(&bt,frame,i));
   REQUIRE(kprog_obs_mask_equal(bt_frame_stack_mask(&bt,frame),bit));
   bt.frame=frame;REQUIRE(kprog_obs_mask_equal(bt_stack_mask(&bt),bit));bt.frame=7;
   bt_clear_frame_slot(&bt,frame,i);REQUIRE(bt_empty(&bt));
   for(flags=0;flags<4;flags++){
    struct bpf_jmp_history_entry hist={};
    hist.flags=insn_stack_access_flags(frame,i)|
        ((flags&1)?INSN_F_DST_REG_STACK:0)|((flags&2)?INSN_F_SRC_REG_STACK:0);
    REQUIRE(insn_stack_access_spi(hist.flags)==(int)i);
    REQUIRE(insn_stack_access_frameno(hist.flags)==(int)frame);observations++;
   }
  }
  mark_verifier_state_clean(&env);mark_stack_slot_scratched(&env,i);
  REQUIRE(verifier_state_scratched(&env));REQUIRE(stack_slot_scratched(&env,i));
  REQUIRE(!stack_slot_scratched(&env,(i+64)%1024));
 }
 for(frame=0;frame<8;frame++)for(i=0;i<=10;i++){
  struct bpf_reg_state reg={.type=SCALAR_VALUE,.id=17};
  struct linked_regs collected={},decoded={};
  __collect_linked_regs(&collected,&reg,17,frame,i,true);
  linked_regs_unpack(linked_regs_pack(&collected),&decoded);
  REQUIRE(decoded.entries[0].regno==i && decoded.entries[0].is_reg);
  observations++;
 }
 mark_verifier_state_scratched(&env);
 for(i=0;i<1024;i++)REQUIRE(stack_slot_scratched(&env,i));
 mark_verifier_state_clean(&env);mark_reg_scratched(&env,10);REQUIRE(reg_scratched(&env,10));
 mark_verifier_state_clean(&env);
 for(i=0;i<1024;i++)REQUIRE(kprog_obs_mask_test(&all,i));
 for(round=0;round<128;round++){
  struct func_instance instance={};unsigned char input[6][1024];
  struct per_frame_masks *cur=&instance.masks[0][0];
  kprog_obs_stack_mask *values[6]={&cur->may_read,&cur->must_write,
      &cur->live_before,&cur->must_write_acc,
      &instance.masks[0][1].live_before,&instance.masks[0][2].live_before};
  for(i=0;i<6;i++)for(j=0;j<1024;j++){
   input[i][j]=random_bit();if(input[i][j])kprog_obs_mask_set(values[i],j);
  }
  instance.masks[0][1].must_write_acc=cur->must_write_acc;
  instance.masks[0][2].must_write_acc=cur->may_read;
  successors.cnt=2;successors.items[0]=1;successors.items[1]=2;
  bool expected_changed=false;
  for(j=0;j<1024;j++){
   unsigned expected_before=((input[4][j]||input[5][j])&&!input[1][j])||input[0][j];
   unsigned expected_written=(input[3][j]&&input[0][j])||input[1][j];
   expected_changed|=(expected_before!=input[2][j])||(expected_written!=input[3][j]);
  }
  REQUIRE(update_insn(&env,&instance,0,0)==expected_changed);
  for(j=0;j<1024;j++){
   REQUIRE(kprog_obs_mask_test(&cur->live_before,j)==(((input[4][j]||input[5][j])&&!input[1][j])||input[0][j]));
   REQUIRE(kprog_obs_mask_test(&cur->must_write_acc,j)==((input[3][j]&&input[0][j])||input[1][j]));
   REQUIRE(is_live_before(&instance,0,0,j)==kprog_obs_mask_test(&cur->live_before,j));observations++;
  }
  REQUIRE(kprog_obs_mask_equal(kprog_obs_mask_xor(all,all),zero));
 }
 {struct func_instance instance={};
  unsigned picks[]={5,63,64,1023};
  for(i=0;i<4;i++)bpf_mark_stack_write(&env,0,kprog_obs_mask_bit(picks[i]));
  REQUIRE(commit_stack_write_marks(&env,&instance)==0);
  for(i=0;i<4;i++)REQUIRE(kprog_obs_mask_test(&instance.masks[0][0].must_write,picks[i]));
  live.write_masks_acc[0]=kprog_obs_mask_or(kprog_obs_mask_bit(5),kprog_obs_mask_bit(64));
  REQUIRE(commit_stack_write_marks(&env,&instance)==0);
  REQUIRE(instance.must_write_dropped);
  for(i=0;i<1024;i++)REQUIRE(kprog_obs_mask_test(&instance.masks[0][0].must_write,i)==(i==5||i==64));
  instance.updated=false;
  REQUIRE(mark_stack_read(&env,&instance,0,0,kprog_obs_mask_bit(1023))==0);
  REQUIRE(instance.updated&&kprog_obs_mask_test(&instance.masks[0][0].may_read,1023));
  log_mask_change(&env,&instance.callchain,"fixture",0,0,zero,all);REQUIRE(log_calls>0);
 }
 for(round=0;round<1024;round++){
  struct linked_regs input={},output={};
  for(i=0;i<6;i++){
   struct linked_reg *e=linked_regs_push(&input);
   e->frameno=(round+i)%8;e->spi=(round+173*i)%1024;e->is_reg=(i+round)&1;
  }
  unsigned __int128 packed=linked_regs_pack(&input);linked_regs_unpack(packed,&output);
  REQUIRE(output.cnt==6);
  for(i=0;i<6;i++){
   REQUIRE(output.entries[i].frameno==input.entries[5-i].frameno);
   REQUIRE(output.entries[i].spi==input.entries[5-i].spi);
   REQUIRE(output.entries[i].is_reg==input.entries[5-i].is_reg);observations++;
  }
 }
 {char output[16384];kprog_obs_stack_mask m=kprog_obs_mask_or(kprog_obs_mask_bit(31),kprog_obs_mask_bit(1023));
  bpf_fmt_stack_mask(output,sizeof(output),m);REQUIRE(strcmp(output,"-256,-8192")==0);}
 printf("slot observations=%llu slots=1024 frames=8 linked_records=6 liveness_rounds=128\n",observations);
 return 0;
}
"""
source=prefix+h[enum_start:enum_end]+'\n'+history+'\n'+linked+'\n'+frame+'\n'+infra+'\n'.join(snippets)+main
(D/'fixture.c').write_text(source);(D/'header.h').write_bytes((R/'kprog/stock-path/include/observation_stack_mask.h').read_bytes())
def build(compiler):
 out=D/Path(compiler).name
 command=[compiler,'-std=gnu11','-O2','-g','-Wall','-Wextra','-Werror','-Wno-sign-compare','-fsanitize=undefined','-fno-sanitize-recover=all',str(D/'fixture.c'),'-o',str(out)]
 if 'clang' in compiler: command+=['-fno-sanitize-link-runtime','-lubsan']
 result=subprocess.run(command,capture_output=True,text=True)
 row=dict(compiler=compiler,command=command,compile_returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
 if result.returncode==0:
  r=subprocess.run([str(out)],capture_output=True,text=True);row.update(run_returncode=r.returncode,run_stdout=r.stdout,run_stderr=r.stderr)
 (D/(out.name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(build,['/usr/bin/gcc','/usr/bin/clang-18']))
(D/'results.json').write_text(json.dumps(dict(kind='extracted_kernel_capacity_bookkeeping',patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),fixture_sha256=hashlib.sha256(source.encode()).hexdigest(),rows=rows),indent=2)+'\n')
