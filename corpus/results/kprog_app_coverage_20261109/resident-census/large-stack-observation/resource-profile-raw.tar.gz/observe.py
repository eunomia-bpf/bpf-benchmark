from pathlib import Path
import sys,json,ctypes as c,hashlib,traceback
L=Path('/var/tmp/kprog-tmp/A/large-stack-observation');D=L/'resource-profiles'
prefix=(L/'map-metadata/observe.py').read_text().split('records=[]',1)[0]
prefix=prefix.replace("D=Path('/var/tmp/kprog-tmp/A/large-stack-observation/map-metadata')","D=Path('/var/tmp/kprog-tmp/A/large-stack-observation/resource-profiles')")
sys.argv=['metadata-profiles','actual']
ns={};exec(compile(prefix,'actual-resource-constructor','exec'),ns)
module=ns['module'];inventory=ns['inventory'];resources=ns['resources'];apps=ns['apps']
groups=json.loads((L/'groups.json').read_text())['groups'];reports=[]
for group in groups:
 if len(group['members'])==1:continue
 inputs={}
 for row in group['members']:
  infos=list(row.get('map_info',[]));names={m['name'] for m in infos}
  infos.extend(m for m in apps[row['application']] if m.get('name') not in names)
  profile=sorted(json.dumps({k:m.get(k) for k in ['name','key_size','bytes_key','value_size','bytes_value','max_entries']},sort_keys=True) for m in infos)
  key=hashlib.sha256(json.dumps(profile).encode()).hexdigest()
  inputs.setdefault(key,dict(row=row,map_info=infos,members=[]))['members'].append([row['application'],row['source_prog_id']])
 outcomes=[]
 for key,item in inputs.items():
  row=item['row'];work=D/(group['body_sha256'][:12]+'-'+key[:12]);work.mkdir(exist_ok=True)
  obj=module.ObjectResources.__new__(module.ObjectResources)
  record=dict(profile_key=key,members=item['members'])
  try:
   resource=resources[(row['application'],row['source_prog_id'])]
   module.ObjectResources.__init__(obj,'x86',Path(resource['bpf_object']),row['native_candidates'][0]['symbol'],directory=work,map_info=item['map_info'])
   obj.bind('bpf_map__type',c.c_int,c.c_void_p);obj.bind('bpf_map__map_flags',c.c_uint32,c.c_void_p)
   shapes=[]
   for map in obj.maps:
    name=obj.lib.bpf_map__name(map).decode()
    if obj.lib.bpf_map__is_internal(map):name=name[name.index('.'):] if '.' in name else name
    shapes.append(dict(name=name,type=obj.lib.bpf_map__type(map),key=obj.lib.bpf_map__key_size(map),value=obj.lib.bpf_map__value_size(map),max_entries=obj.lib.bpf_map__max_entries(map),flags=obj.lib.bpf_map__map_flags(map)))
   context=dict(type=obj.lib.bpf_program__type(obj.program),expected_attach=obj.lib.bpf_program__expected_attach_type(obj.program),flags=obj.lib.bpf_program__flags(obj.program),section=obj.lib.bpf_program__section_name(obj.program).decode())
   shape=dict(maps=shapes,context=context)
   record.update(status='opened_metadata',shape=shape,shape_key=hashlib.sha256(json.dumps(shape,sort_keys=True).encode()).hexdigest())
  except Exception as e:record.update(status='metadata_error',error=repr(e),traceback=traceback.format_exc())
  finally:obj.close()
  outcomes.append(record)
 report=dict(body_sha256=group['body_sha256'],symbol=group['representative']['native_candidates'][0]['symbol'],member_count=len(group['members']),profiles=len(inputs),actual_shape_variants=len({r['shape_key'] for r in outcomes if 'shape_key' in r}),outcomes=outcomes)
 reports.append(report);(D/'progress.json').write_text(json.dumps(reports,indent=2)+'\n')
 print(report['symbol'],report['member_count'],report['profiles'],report['actual_shape_variants'],flush=True)
result=dict(kind='actual_resource_metadata_preparation',model_head=inventory['source_head'],total_resident_instances=549,native_body_groups=247,repeated_groups=len(reports),repeated_instances=sum(r['member_count'] for r in reports),actual_constructor_profiles=sum(r['profiles'] for r in reports),groups_with_resource_variants=sum(r['actual_shape_variants']>1 for r in reports),metadata_errors=sum(x['status']=='metadata_error' for r in reports for x in r['outcomes']),maps_created=0,program_loads=0,native_executions=0,groups=reports)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('COMPLETE',json.dumps({k:v for k,v in result.items() if k!='groups'}),flush=True)
