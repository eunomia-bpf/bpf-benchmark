int observation(int x) { volatile char bytes[4097]; bytes[4096]=(char)x; asm volatile("" : : "r"(bytes) : "memory"); return bytes[4096]; }
