from pathlib import Path
import sys,importlib.util,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');F=R/'kprog/formal'
sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/x86/micro-prog'))
spec=importlib.util.spec_from_file_location('alu_fault_encoder',G/'source/kprog/x86/micro-prog/generate_micro_sim_proofs.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
registers=[('rax','eax','ax','al'),('rcx','ecx','cx','cl'),('rdx','edx','dx','dl'),('rbx','ebx','bx','bl'),('rsp','esp','sp','spl'),('rbp','ebp','bp','bpl'),('rsi','esi','si','sil'),('rdi','edi','di','dil')]+[(f'r{i}',f'r{i}d',f'r{i}w',f'r{i}b')for i in range(8,16)]
variants=[]
for op in ['add','adc','sub','sbb','and','or','xor']:
 for width,index,qual in [(64,0,'QWORD'),(32,1,'DWORD'),(16,2,'WORD'),(8,3,'BYTE')]:
  mem=f'{qual} PTR [rdi+16]'
  for reg in registers:variants.append((op,(reg[index],mem),reg[0]))
  variants.append((op,(mem,registers[0][index]),None));variants.append((op,(mem,'1'),None))
for op in ['inc','dec','neg','not']:
 for qual in ['QWORD','DWORD','WORD','BYTE']:variants.append((op,(f'{qual} PTR [rdi+16]',),None))
source=['#define X86_SIM_USE_STATE_STRUCT','#define X86_SIM_ENABLE_STACK 1','#include "'+str(G/'source/kprog/x86/x86_sim_local_bpf.h')+'"','#include "'+str(F/'oracles/x86_no_helpers_host.h')+'"','#include <stdio.h>','#include <string.h>','static unsigned calls;','#undef X86_SIM_L_UNSPECIFIED','#define X86_SIM_L_UNSPECIFIED() (calls++,1U)','#undef __x86_sim_is_xdp','#define __x86_sim_is_xdp entry_mode']
for i,(op,args,destination)in enumerate(variants):
 insn=m.NativeInsn(0,op+' '+','.join(args),op,args);e=m.encode(insn,{});body=[];m.append_step(body,insn)
 source+=['static __always_inline void run_'+str(i)+'(struct x86_sim_state *state){','const __u8 entry_mode=state->is_xdp;','X86_SIM_L_BIND_COMMON_STATE(state);',*body,'}']
source+=['int main(void){unsigned cases=0;','for(unsigned flags=0;flags<64;flags++)for(unsigned pattern=0;pattern<66;pattern++){','__u64 value=pattern<64?1ULL<<pattern:pattern==64?0:~0ULL;']
for i,(_,_,dst)in enumerate(variants):
 source+=['{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);']
 for j,reg in enumerate(registers):source+=[f'state.{reg[0]}.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*{j+1}));state.{reg[0]}_tag=0x7f;']
 source+=['state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;','state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;','state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;']
 if dst is not None:
  source+=[f'expected.{dst}.ptr='+(('(void *)(unsigned long)(0ULL-state.native_stack_base);')if dst=='rsp'else'(void *)0;'),f'expected.{dst}_tag=X86_SIM_TAG_SCALAR;']
 source+=[f'calls=0;run_{i}(&state);',f'if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){{fprintf(stderr,"ALU recovery variant={i} flags=%u pattern=%u calls=%u\\n",flags,pattern,calls);return 1;}}','cases++;}']
source+=['}printf("ALU protected-read recovery: %u full-state cases OK\\n",cases);return 0;}']
(G/'fault.c').write_text('\n'.join(source)+'\n');(G/'variants.json').write_text(json.dumps(variants,indent=2)+'\n');print('ALU original encoded variants',len(variants))
