from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,hashlib,tarfile,shutil,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/map-caller-frame/safety-replay';O=R/'corpus/results/kprog_app_coverage_20261108/tracee-clamp-macro/application'
def notice(s):
 msg='\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': '+s+'\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a')as f:f.write(msg)
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('queued_after_map_helper_original38')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 # Keep the existing serial guest budget when a vng parent closes early.
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:cmd=(proc/'cmdline').read_bytes().split(b'\0')
   except (FileNotFoundError,ProcessLookupError):continue
   if cmd and cmd[0].endswith(b'qemu-system-x86_64')and any(('path='+str(Q)+',').encode()in arg for arg in cmd):
    try:
     fd=os.pidfd_open(int(proc.name));select.select([fd],[],[]);os.close(fd)
    except ProcessLookupError:pass
 notice('Packaging paired Tracee image after map helper safety guest: source 20096bb3c preserves size registers through all existing clamps and earlier d6d02957 checked-local offsets; native/BPF/embedded binary compiled0. Current ghost canonical87ab19c5c source captured; sole shared kernel/module caches retain bytes. Runtime admission additions0.')
 with(G/'image.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'image'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'image.exit').write_text(str(p.returncode)+'\n');p.check_returncode();image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip();files=[p for p in(G/'source').rglob('*')if p.is_file()]+[G/'clang',G/'guest.py',G/'Makefile']+[p for p in(G/'image').rglob('*')if p.is_file()];inputs=dict(utc=datetime.now(timezone.utc).isoformat(),app_source_commit='20096bb3cfa32408956e5f9d2cf82ff496e5fabf',canonical_ghost_commit='87ab19c5c9b9bed3562b7da3bd46d42c211f3a8b',image=image,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=tracee/monitor','SAMPLES=1','WORKLOAD_DURATION=2'];(G/'command.json').write_text(json.dumps(command,indent=2)+'\n');save('running',image=image);notice('Whole paired-source Tracee START20-23/12GiB after original38, source20096bb3c size register and checked string offset, actualimage'+image+'. Original workload/BPF/embedded binary/native manifest use paired source artifacts. Every terminal coverage/work record retained.')
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*command],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 with(G/'collect.log').open('w')as f:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=G.parent/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
 for path in I.iterdir():
  if path.is_file():shutil.copy2(path,O/path.name)
 j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']];(O/'work.json').write_text(json.dumps(work,indent=2)+'\n');result=dict(make_exit=p.returncode,native_requests=j['native_requests'],generated=j['generated'],compiled=j['compiled'],installed=j['installed'],failed=j['failed'],work=[dict(application=x['application'],status=x['status'],error=(x['error']or'').splitlines()[0]if x['error']else'')for x in work],inputs=inputs);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Whole paired-source Tracee with existing size clamps\n\nSource 20096bb3c keeps the size value through empty read/write register asm before the every original update_min operation. Original bounds, helper-boundary reload and earlier checked string-offset operation retain their semantics. Both frontends read the same selected C tree and the embedded binary consumes that JIT BPF. Paired native/JIT/binary builds0. Model0818 captures RAW/helper source; original application/workload are retained. Actual G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+'; Makeexit'+str(p.returncode)+'. All native/C/B/compiler/verifier/service and raw work records accompany this cohort. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as tf:
  for name in ['Makefile','guest.py','clang','mount.py','source','image','image.log','image.exit','inputs.json','command.json','controller.py','run.log','run.exit','collect.log','collect.exit','summary.json']:tf.add(G/name,arcname=name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record whole Tracee with shared existing-clamp register lifetime',G/'publication.json');save('finished',commit=commit,result={k:result[k]for k in ['make_exit','native_requests','generated','compiled','installed','failed','work']});notice('PUSHED '+commit+' whole paired-source Tracee G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+' actualwork'+repr(result['work'])+'.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
