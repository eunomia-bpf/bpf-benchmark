from pathlib import Path
import subprocess,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');rows=[]
for compiler in ['gcc','clang-18']:
 for name,src in [('cpu',G/'host.c'),('route',R/'kprog/formal/oracles/test_x86_rep_movs_route_host.c')]:
  exe=G/(compiler+'-'+name);cmd=[compiler,'-O2','-mno-red-zone','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(R/'kprog/formal'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu',str(src),'-o',str(exe)]
  if compiler=='clang-18':cmd+=['-fno-sanitize-link-runtime','-lubsan']
  with(G/(compiler+'-'+name+'.build.log')).open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  row=dict(compiler=compiler,name=name,command=cmd,compile_exit=p.returncode)
  if not p.returncode:
   with(G/(compiler+'-'+name+'.log')).open('w')as f:q=subprocess.run([str(exe)],stdout=f,stderr=subprocess.STDOUT)
   row['run_exit']=q.returncode
  rows.append(row);(G/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
