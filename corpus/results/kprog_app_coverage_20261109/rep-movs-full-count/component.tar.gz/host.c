#define X86_SIM_ENABLE_STACK
#define X86_SIM_STACK_BYTES 64
#define __always_inline inline
typedef unsigned char __u8;typedef unsigned short __u16;typedef unsigned int __u32;typedef unsigned long long __u64;typedef signed char __s8;typedef short __s16;typedef int __s32;typedef signed long long __s64;
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include "/workspaces/repository/kprog/formal/oracles/x86_no_helpers_host.h"
#include <stdio.h>
#include <string.h>
#define FMASK 0x8d5ULL
static __u8 cpu_mem[8192],sim_mem[8192];static unsigned long cases;
static unsigned flags_of(unsigned b){return((b&1)?1:0)|((b&2)?4:0)|((b&4)?16:0)|((b&8)?64:0)|((b&16)?128:0)|((b&32)?2048:0);}
#define CPU_MOVS(SUFFIX) __asm__ volatile("pushfq; popq %%r11; andq $-2262, %%r11; orq %[flags], %%r11; pushq %%r11; popfq; cld; rep movs" SUFFIX "; pushfq; popq %[out]" : "+D"(dst), "+S"(src), "+c"(count),[out]"=r"(out_flags):[flags]"r"((__u64)flags):"r11","cc","memory")
static int check(unsigned width,__u64 n,int gap,unsigned flags){
 for(unsigned i=0;i<sizeof(cpu_mem);i++)cpu_mem[i]=sim_mem[i]=(i*137U+(i>>3)+29U)&255;
 __u8 *src=cpu_mem+256,*dst=src+gap;__u64 count=n,out_flags;
 switch(width){case 1:CPU_MOVS("b");break;case 2:CPU_MOVS("w");break;case 4:CPU_MOVS("l");break;default:CPU_MOVS("q");break;}
 if(count||src!=cpu_mem+256+n*width||dst!=cpu_mem+256+gap+n*width||(out_flags&FMASK)!=flags)return 2;
 X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u64 before[16];__u8 tags[16];
 __x86_rsp.ptr=0;for(unsigned i=0;i<16;i++)if(i!=X86_RSP)X86_SIM_L_WRITE_REG_WIDTH(i,0x1122334455667788ULL+i*0x12345ULL,8);
 X86_SIM_L_WRITE_REG_PTR_TAG(X86_RSI,sim_mem+256,X86_SIM_TAG_MAP_VALUE);X86_SIM_L_WRITE_REG_PTR_TAG(X86_RDI,sim_mem+256+gap,X86_SIM_TAG_MAP_VALUE);X86_SIM_L_WRITE_REG_WIDTH(X86_RCX,n,8);
 for(unsigned i=0;i<16;i++){before[i]=X86_SIM_L_READ_REG(i);tags[i]=X86_SIM_L_REG_TAG(i);}
 __x86_cf=flags&1;__x86_pf=(flags>>2)&1;__x86_af=(flags>>4)&1;__x86_zf=(flags>>6)&1;__x86_sf=(flags>>7)&1;__x86_of=(flags>>11)&1;
 X86_SIM_L_EXEC_REP_MOVS(width,0xdeadbeefcafef00dULL);
 if(memcmp(cpu_mem,sim_mem,sizeof(cpu_mem))||X86_SIM_L_READ_REG(X86_RCX)!=0||X86_SIM_L_READ_REG_PTR(X86_RSI)!=sim_mem+256+n*width||X86_SIM_L_READ_REG_PTR(X86_RDI)!=sim_mem+256+gap+n*width)return 3;
 for(unsigned i=0;i<16;i++)if(i!=X86_RCX&&i!=X86_RSI&&i!=X86_RDI&&(X86_SIM_L_READ_REG(i)!=before[i]||X86_SIM_L_REG_TAG(i)!=tags[i]))return 4;
 unsigned out=__x86_cf|(__x86_pf<<2)|(__x86_af<<4)|(__x86_zf<<6)|(__x86_sf<<7)|(__x86_of<<11);if(out!=flags)return 5;cases++;return 0;
}
int main(void){unsigned ns[]={0,1,2,3,7,8,15,16,31,32,63,64,65,127,128,255,256};int gaps[]={-32,-8,-1,0,1,8,32,2048};for(unsigned w=1;w<=8;w*=2)for(unsigned n=0;n<sizeof(ns)/sizeof(ns[0]);n++)for(unsigned g=0;g<8;g++)for(unsigned f=0;f<64;f++){int e=check(w,ns[n],gaps[g],flags_of(f));if(e){printf("mismatch%u n%u gap%d flags%u error%d\n",w,ns[n],gaps[g],f,e);return e;}}printf("REP MOVS full RCX CPU/full-state PASS %lu cases\n",cases);}
