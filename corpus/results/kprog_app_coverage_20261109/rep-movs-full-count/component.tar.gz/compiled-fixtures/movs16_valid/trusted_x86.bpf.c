#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 144U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 144ULL);
x86_l_7:
	/* 0x7: movabs rax,0x1122334412345678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605615309149816ULL);
x86_l_11:
	/* 0x11: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15:
	/* 0x15: mov    ecx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65ULL);
x86_l_1a:
	/* 0x1a: rep stos WORD PTR es:[rdi],ax */
	X86_SIM_L_EXEC_REP_STOS(X86_WIDTH_16);
x86_l_1d:
	/* 0x1d: lea    rsi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21:
	/* 0x21: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25:
	/* 0x25: mov    ecx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65ULL);
x86_l_2a:
	/* 0x2a: cmp    rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d:
	/* 0x2d: rep movs WORD PTR es:[rdi],WORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_16, 0ULL);
x86_l_30:
	/* 0x30: jne    52 <entry+0x52> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30, 0x52, x86_l_52);
x86_l_32:
	/* 0x32: cmp    WORD PTR [rsp+0x80],ax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3a:
	/* 0x3a: jne    52 <entry+0x52> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a, 0x52, x86_l_52);
x86_l_3c:
	/* 0x3c: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3f:
	/* 0x3f: jne    52 <entry+0x52> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f, 0x52, x86_l_52);
x86_l_41:
	/* 0x41: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_46:
	/* 0x46: add    rsp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_4d:
	/* 0x4d: jmp    63 <entry+0x63> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_52:
	/* 0x52: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_57:
	/* 0x57: add    rsp,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_5e:
	/* 0x5e: jmp    63 <entry+0x63> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_63:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
