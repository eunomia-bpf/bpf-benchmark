#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 272U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30) M(31) M(32) M(33)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x110 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 272ULL);
x86_l_7:
	/* 0x7: movabs rax,0x1122334412345678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605615309149816ULL);
x86_l_11:
	/* 0x11: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15:
	/* 0x15: mov    ecx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65ULL);
x86_l_1a:
	/* 0x1a: rep stos DWORD PTR es:[rdi],eax */
	X86_SIM_L_EXEC_REP_STOS(X86_WIDTH_32);
x86_l_1c:
	/* 0x1c: lea    rsi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20:
	/* 0x20: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24:
	/* 0x24: mov    ecx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65ULL);
x86_l_29:
	/* 0x29: cmp    rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c:
	/* 0x2c: rep movs DWORD PTR es:[rdi],DWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_32, 0ULL);
x86_l_2e:
	/* 0x2e: jne    4f <entry+0x4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e, 0x4f, x86_l_4f);
x86_l_30:
	/* 0x30: cmp    DWORD PTR [rsp+0x100],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_37:
	/* 0x37: jne    4f <entry+0x4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37, 0x4f, x86_l_4f);
x86_l_39:
	/* 0x39: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3c:
	/* 0x3c: jne    4f <entry+0x4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c, 0x4f, x86_l_4f);
x86_l_3e:
	/* 0x3e: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_43:
	/* 0x43: add    rsp,0x110 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 272ULL);
x86_l_4a:
	/* 0x4a: jmp    60 <entry+0x60> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_4f:
	/* 0x4f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_54:
	/* 0x54: add    rsp,0x110 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 272ULL);
x86_l_5b:
	/* 0x5b: jmp    60 <entry+0x60> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_60:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
