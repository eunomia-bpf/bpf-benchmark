#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 80U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 80ULL);
x86_l_4:
	/* 0x4: movabs rax,0x1122334412345678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605615309149816ULL);
x86_l_e:
	/* 0xe: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12:
	/* 0x12: mov    ecx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65ULL);
x86_l_17:
	/* 0x17: rep stos BYTE PTR es:[rdi],al */
	X86_SIM_L_EXEC_REP_STOS(X86_WIDTH_8);
x86_l_19:
	/* 0x19: lea    rsi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d:
	/* 0x1d: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21:
	/* 0x21: mov    ecx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65ULL);
x86_l_26:
	/* 0x26: cmp    rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_29:
	/* 0x29: rep movs BYTE PTR es:[rdi],BYTE PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_8, 0ULL);
x86_l_2b:
	/* 0x2b: jne    46 <entry+0x46> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b, 0x46, x86_l_46);
x86_l_2d:
	/* 0x2d: cmp    BYTE PTR [rsp+0x40],al */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31:
	/* 0x31: jne    46 <entry+0x46> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31, 0x46, x86_l_46);
x86_l_33:
	/* 0x33: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_36:
	/* 0x36: jne    46 <entry+0x46> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x36, 0x46, x86_l_46);
x86_l_38:
	/* 0x38: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3d:
	/* 0x3d: add    rsp,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_41:
	/* 0x41: jmp    54 <entry+0x54> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_46:
	/* 0x46: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4b:
	/* 0x4b: add    rsp,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_4f:
	/* 0x4f: jmp    54 <entry+0x54> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_54:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
