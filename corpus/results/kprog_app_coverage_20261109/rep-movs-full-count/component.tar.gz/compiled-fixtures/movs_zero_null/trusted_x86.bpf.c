#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_4:
	/* 0x4: movabs rax,0x1122334412345678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605615309149816ULL);
x86_l_e:
	/* 0xe: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12:
	/* 0x12: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14:
	/* 0x14: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16:
	/* 0x16: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_18:
	/* 0x18: cmp    rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1b:
	/* 0x1b: rep movs BYTE PTR es:[rdi],BYTE PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_8, 0ULL);
x86_l_1d:
	/* 0x1d: jne    38 <entry+0x38> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d, 0x38, x86_l_38);
x86_l_1f:
	/* 0x1f: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_22:
	/* 0x22: jne    38 <entry+0x38> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22, 0x38, x86_l_38);
x86_l_24:
	/* 0x24: cmp    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28:
	/* 0x28: jne    38 <entry+0x38> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28, 0x38, x86_l_38);
x86_l_2a:
	/* 0x2a: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2f:
	/* 0x2f: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_33:
	/* 0x33: jmp    46 <entry+0x46> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_38:
	/* 0x38: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3d:
	/* 0x3d: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_41:
	/* 0x41: jmp    46 <entry+0x46> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_46:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
