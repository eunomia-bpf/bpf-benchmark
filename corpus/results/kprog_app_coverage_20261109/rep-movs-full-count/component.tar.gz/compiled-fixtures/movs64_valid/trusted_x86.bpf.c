#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 80U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 80ULL);
x86_l_4:
	/* 0x4: movabs rax,0x1122334412345678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605615309149816ULL);
x86_l_e:
	/* 0xe: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12:
	/* 0x12: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_17:
	/* 0x17: rep stos QWORD PTR es:[rdi],rax */
	X86_SIM_L_EXEC_REP_STOS(X86_WIDTH_64);
x86_l_1a:
	/* 0x1a: lea    rsi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e:
	/* 0x1e: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22:
	/* 0x22: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_27:
	/* 0x27: cmp    rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2a:
	/* 0x2a: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 0ULL);
x86_l_2d:
	/* 0x2d: jne    49 <entry+0x49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d, 0x49, x86_l_49);
x86_l_2f:
	/* 0x2f: cmp    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_34:
	/* 0x34: jne    49 <entry+0x49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34, 0x49, x86_l_49);
x86_l_36:
	/* 0x36: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_39:
	/* 0x39: jne    49 <entry+0x49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39, 0x49, x86_l_49);
x86_l_3b:
	/* 0x3b: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_40:
	/* 0x40: add    rsp,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_44:
	/* 0x44: jmp    57 <entry+0x57> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_49:
	/* 0x49: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4e:
	/* 0x4e: add    rsp,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_52:
	/* 0x52: jmp    57 <entry+0x57> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_57:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
