#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_4:
	/* 0x4: movabs rax,0x1122334412345678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605615309149816ULL);
x86_l_e:
	/* 0xe: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12:
	/* 0x12: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14:
	/* 0x14: lea    rdi,[rsp] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18:
	/* 0x18: movabs rcx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_22:
	/* 0x22: cmp    rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_25:
	/* 0x25: rep movs BYTE PTR es:[rdi],BYTE PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_8, 0ULL);
x86_l_27:
	/* 0x27: jne    4c <entry+0x4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27, 0x4c, x86_l_4c);
x86_l_29:
	/* 0x29: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_2c:
	/* 0x2c: jne    4c <entry+0x4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c, 0x4c, x86_l_4c);
x86_l_2e:
	/* 0x2e: cmp    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32:
	/* 0x32: jne    4c <entry+0x4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32, 0x4c, x86_l_4c);
x86_l_34:
	/* 0x34: cmp    rdi,rsp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_37:
	/* 0x37: jne    4c <entry+0x4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37, 0x4c, x86_l_4c);
x86_l_39:
	/* 0x39: test   rsi,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64);
x86_l_3c:
	/* 0x3c: jne    4c <entry+0x4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c, 0x4c, x86_l_4c);
x86_l_3e:
	/* 0x3e: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_43:
	/* 0x43: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_47:
	/* 0x47: jmp    5a <entry+0x5a> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_4c:
	/* 0x4c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_51:
	/* 0x51: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_55:
	/* 0x55: jmp    5a <entry+0x5a> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_5a:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
