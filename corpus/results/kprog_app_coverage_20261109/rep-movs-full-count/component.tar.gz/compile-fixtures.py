from pathlib import Path
import sys,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
rows=[]
for item in json.loads((G/'safety-control/rep-movs/cases.json').read_text()):
 row=dict(item);out=G/'compiled-fixtures'/item['name'];out.parent.mkdir(parents=True,exist_ok=True)
 try:row.update(result=specialize((G/'safety-control/rep-movs'/(item['name']+'.native.o')).read_bytes(),'entry',json.loads((G/'generation.metadata.json').read_text()),out,R/'kprog/x86/native_lab/native_link/target/release/native-link'),status='compiled')
 except BaseException as e:row.update(status='diagnostic',error=str(e))
 rows.append(row);(G/'compiled-fixtures.json').write_text(json.dumps(rows,indent=2)+'\n');print(item['name'],row['status'],row.get('error'),flush=True)
