from pathlib import Path
import importlib.util,sys,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/x86/micro-prog'));spec=importlib.util.spec_from_file_location('rep_count_generator',G/'source/kprog/x86/micro-prog/generate_micro_sim_proofs.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);rows=[]
for line in(G/'forms.disassembly').read_text().splitlines():
 if 'rep movs'not in line:continue
 raw=line.split('\t')[-1].strip();ops=tuple(x.strip()for x in raw[len('rep '):].split(','))
 for count in [None,0,64,65,256,0xffffffffffffffff]:
  ins=m.NativeInsn(0,raw,'rep',ops,sim_imm=count);out=[];m.append_step(out,ins);rows.append(dict(raw=raw,count_fact=count,emitted=out))
(G/'decoder.json').write_text(json.dumps(rows,indent=2)+'\n');print('actual forms/count facts',len(rows));print(rows[0]);print(rows[-1])
