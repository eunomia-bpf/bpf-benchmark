from pathlib import Path
import subprocess,sys,json,os,fcntl,signal,threading,traceback,tarfile,datetime
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');state=G/'requests';state.mkdir(exist_ok=True);rows=[];result=dict(programs=rows,negative_test_run_calls=0);service=None;lines=[]
try:
 service=subprocess.Popen([sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(state),'--native-link',str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'--loader',str(R/'kprog/libnativeloader/build/trusted-native-loader')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 line=service.stdout.readline();lines.append(line);result['service_ready']=json.loads(line)
 for item in json.loads((G/'cases.json').read_text()):
  context=C/'design-only/safety/build/context_array.bpf.o';cmd=[str(G.parent/'canonical-probe'),str(context),str(G/(item['name']+'.native.o'))]
  if item['positive']:cmd+=['0','2']
  p=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,CLANG='/usr/lib/llvm-18/bin/clang',BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1'));(G/(item['name']+'.stdout')).write_text(p.stdout);(G/(item['name']+'.stderr')).write_text(p.stderr)
  line=service.stdout.readline();lines.append(line);record=json.loads(line);row=dict(item,command=cmd,returncode=p.returncode,service=record,stage=('valid_executed'if p.returncode==0 and record['status']==0 else'positive_diagnostic')if item['positive']else('accepted_finding'if record['status']==0 else'verifier_or_generation_rejected'));rows.append(row);(G/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n')
 result['status']='observed'
except BaseException as error:result.update(status='setup_diagnostic',error=str(error),traceback=traceback.format_exc())
finally:
 if service is not None:
  if service.poll()is None:
   lock=state/'request.lock'
   if lock.exists():
    with lock.open('rb')as f:fcntl.flock(f,fcntl.LOCK_EX);os.killpg(service.pid,signal.SIGTERM)
   else:os.killpg(service.pid,signal.SIGTERM)
  lines.append(service.communicate()[0])
 (G/'service.log').write_text(''.join(lines));(G/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print('REP_MOVS_GUEST',json.dumps(result),flush=True)
