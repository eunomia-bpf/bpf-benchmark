from pathlib import Path
import subprocess,os
physical=Path('/var/tmp/kprog-tmp/C/bcc-katran-constant-division');virtual=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/bcc-katran-constant-division');collected=virtual.parent/'collected'/virtual.name
collected.mkdir(parents=True,exist_ok=True);(physical/'collected').mkdir(exist_ok=True)
subprocess.run(['mount','--bind',str(physical),str(virtual)],check=True)
subprocess.run(['mount','--bind',str(physical/'collected'),str(collected)],check=True)
os.execvp('/opt/virtme-ng/bin/python3',['/opt/virtme-ng/bin/python3',str(virtual/'controller.py')])
