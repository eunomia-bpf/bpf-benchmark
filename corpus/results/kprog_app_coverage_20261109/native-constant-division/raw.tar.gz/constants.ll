target triple = "x86_64-pc-linux-gnu"
define i8 @c8_0_0_0(i8 %x) {
 %v = udiv i8 %x, 0
 ret i8 %v
}
define i8 @c8_0_0_1(i8 %x) {
 %v = urem i8 %x, 0
 ret i8 %v
}
define i8 @c8_0_1_0(i8 %x) {
 %v = udiv i8 %x, 1
 ret i8 %v
}
define i8 @c8_0_1_1(i8 %x) {
 %v = urem i8 %x, 1
 ret i8 %v
}
define i8 @c8_0_2_0(i8 %x) {
 %v = udiv i8 %x, 2
 ret i8 %v
}
define i8 @c8_0_2_1(i8 %x) {
 %v = urem i8 %x, 2
 ret i8 %v
}
define i8 @c8_0_3_0(i8 %x) {
 %v = udiv i8 %x, 3
 ret i8 %v
}
define i8 @c8_0_3_1(i8 %x) {
 %v = urem i8 %x, 3
 ret i8 %v
}
define i8 @c8_0_7_0(i8 %x) {
 %v = udiv i8 %x, 7
 ret i8 %v
}
define i8 @c8_0_7_1(i8 %x) {
 %v = urem i8 %x, 7
 ret i8 %v
}
define i8 @c8_0_8_0(i8 %x) {
 %v = udiv i8 %x, 8
 ret i8 %v
}
define i8 @c8_0_8_1(i8 %x) {
 %v = urem i8 %x, 8
 ret i8 %v
}
define i8 @c8_0_16_0(i8 %x) {
 %v = udiv i8 %x, 16
 ret i8 %v
}
define i8 @c8_0_16_1(i8 %x) {
 %v = urem i8 %x, 16
 ret i8 %v
}
define i8 @c8_0_31_0(i8 %x) {
 %v = udiv i8 %x, 31
 ret i8 %v
}
define i8 @c8_0_31_1(i8 %x) {
 %v = urem i8 %x, 31
 ret i8 %v
}
define i8 @c8_0_127_0(i8 %x) {
 %v = udiv i8 %x, 127
 ret i8 %v
}
define i8 @c8_0_127_1(i8 %x) {
 %v = urem i8 %x, 127
 ret i8 %v
}
define i8 @c8_0_128_0(i8 %x) {
 %v = udiv i8 %x, 128
 ret i8 %v
}
define i8 @c8_0_128_1(i8 %x) {
 %v = urem i8 %x, 128
 ret i8 %v
}
define i8 @c8_0_255_0(i8 %x) {
 %v = udiv i8 %x, 255
 ret i8 %v
}
define i8 @c8_0_255_1(i8 %x) {
 %v = urem i8 %x, 255
 ret i8 %v
}
define i8 @c8_1_0_0(i8 %x) {
 %v = sdiv i8 %x, 0
 ret i8 %v
}
define i8 @c8_1_0_1(i8 %x) {
 %v = srem i8 %x, 0
 ret i8 %v
}
define i8 @c8_1_1_0(i8 %x) {
 %v = sdiv i8 %x, 1
 ret i8 %v
}
define i8 @c8_1_1_1(i8 %x) {
 %v = srem i8 %x, 1
 ret i8 %v
}
define i8 @c8_1_2_0(i8 %x) {
 %v = sdiv i8 %x, 2
 ret i8 %v
}
define i8 @c8_1_2_1(i8 %x) {
 %v = srem i8 %x, 2
 ret i8 %v
}
define i8 @c8_1_3_0(i8 %x) {
 %v = sdiv i8 %x, 3
 ret i8 %v
}
define i8 @c8_1_3_1(i8 %x) {
 %v = srem i8 %x, 3
 ret i8 %v
}
define i8 @c8_1_7_0(i8 %x) {
 %v = sdiv i8 %x, 7
 ret i8 %v
}
define i8 @c8_1_7_1(i8 %x) {
 %v = srem i8 %x, 7
 ret i8 %v
}
define i8 @c8_1_8_0(i8 %x) {
 %v = sdiv i8 %x, 8
 ret i8 %v
}
define i8 @c8_1_8_1(i8 %x) {
 %v = srem i8 %x, 8
 ret i8 %v
}
define i8 @c8_1_16_0(i8 %x) {
 %v = sdiv i8 %x, 16
 ret i8 %v
}
define i8 @c8_1_16_1(i8 %x) {
 %v = srem i8 %x, 16
 ret i8 %v
}
define i8 @c8_1_31_0(i8 %x) {
 %v = sdiv i8 %x, 31
 ret i8 %v
}
define i8 @c8_1_31_1(i8 %x) {
 %v = srem i8 %x, 31
 ret i8 %v
}
define i8 @c8_1_127_0(i8 %x) {
 %v = sdiv i8 %x, 127
 ret i8 %v
}
define i8 @c8_1_127_1(i8 %x) {
 %v = srem i8 %x, 127
 ret i8 %v
}
define i8 @c8_1_128_0(i8 %x) {
 %v = sdiv i8 %x, -128
 ret i8 %v
}
define i8 @c8_1_128_1(i8 %x) {
 %v = srem i8 %x, -128
 ret i8 %v
}
define i8 @c8_1_255_0(i8 %x) {
 %v = sdiv i8 %x, -1
 ret i8 %v
}
define i8 @c8_1_255_1(i8 %x) {
 %v = srem i8 %x, -1
 ret i8 %v
}
define i16 @c16_0_0_0(i16 %x) {
 %v = udiv i16 %x, 0
 ret i16 %v
}
define i16 @c16_0_0_1(i16 %x) {
 %v = urem i16 %x, 0
 ret i16 %v
}
define i16 @c16_0_1_0(i16 %x) {
 %v = udiv i16 %x, 1
 ret i16 %v
}
define i16 @c16_0_1_1(i16 %x) {
 %v = urem i16 %x, 1
 ret i16 %v
}
define i16 @c16_0_2_0(i16 %x) {
 %v = udiv i16 %x, 2
 ret i16 %v
}
define i16 @c16_0_2_1(i16 %x) {
 %v = urem i16 %x, 2
 ret i16 %v
}
define i16 @c16_0_3_0(i16 %x) {
 %v = udiv i16 %x, 3
 ret i16 %v
}
define i16 @c16_0_3_1(i16 %x) {
 %v = urem i16 %x, 3
 ret i16 %v
}
define i16 @c16_0_7_0(i16 %x) {
 %v = udiv i16 %x, 7
 ret i16 %v
}
define i16 @c16_0_7_1(i16 %x) {
 %v = urem i16 %x, 7
 ret i16 %v
}
define i16 @c16_0_8_0(i16 %x) {
 %v = udiv i16 %x, 8
 ret i16 %v
}
define i16 @c16_0_8_1(i16 %x) {
 %v = urem i16 %x, 8
 ret i16 %v
}
define i16 @c16_0_16_0(i16 %x) {
 %v = udiv i16 %x, 16
 ret i16 %v
}
define i16 @c16_0_16_1(i16 %x) {
 %v = urem i16 %x, 16
 ret i16 %v
}
define i16 @c16_0_31_0(i16 %x) {
 %v = udiv i16 %x, 31
 ret i16 %v
}
define i16 @c16_0_31_1(i16 %x) {
 %v = urem i16 %x, 31
 ret i16 %v
}
define i16 @c16_0_32767_0(i16 %x) {
 %v = udiv i16 %x, 32767
 ret i16 %v
}
define i16 @c16_0_32767_1(i16 %x) {
 %v = urem i16 %x, 32767
 ret i16 %v
}
define i16 @c16_0_32768_0(i16 %x) {
 %v = udiv i16 %x, 32768
 ret i16 %v
}
define i16 @c16_0_32768_1(i16 %x) {
 %v = urem i16 %x, 32768
 ret i16 %v
}
define i16 @c16_0_65535_0(i16 %x) {
 %v = udiv i16 %x, 65535
 ret i16 %v
}
define i16 @c16_0_65535_1(i16 %x) {
 %v = urem i16 %x, 65535
 ret i16 %v
}
define i16 @c16_1_0_0(i16 %x) {
 %v = sdiv i16 %x, 0
 ret i16 %v
}
define i16 @c16_1_0_1(i16 %x) {
 %v = srem i16 %x, 0
 ret i16 %v
}
define i16 @c16_1_1_0(i16 %x) {
 %v = sdiv i16 %x, 1
 ret i16 %v
}
define i16 @c16_1_1_1(i16 %x) {
 %v = srem i16 %x, 1
 ret i16 %v
}
define i16 @c16_1_2_0(i16 %x) {
 %v = sdiv i16 %x, 2
 ret i16 %v
}
define i16 @c16_1_2_1(i16 %x) {
 %v = srem i16 %x, 2
 ret i16 %v
}
define i16 @c16_1_3_0(i16 %x) {
 %v = sdiv i16 %x, 3
 ret i16 %v
}
define i16 @c16_1_3_1(i16 %x) {
 %v = srem i16 %x, 3
 ret i16 %v
}
define i16 @c16_1_7_0(i16 %x) {
 %v = sdiv i16 %x, 7
 ret i16 %v
}
define i16 @c16_1_7_1(i16 %x) {
 %v = srem i16 %x, 7
 ret i16 %v
}
define i16 @c16_1_8_0(i16 %x) {
 %v = sdiv i16 %x, 8
 ret i16 %v
}
define i16 @c16_1_8_1(i16 %x) {
 %v = srem i16 %x, 8
 ret i16 %v
}
define i16 @c16_1_16_0(i16 %x) {
 %v = sdiv i16 %x, 16
 ret i16 %v
}
define i16 @c16_1_16_1(i16 %x) {
 %v = srem i16 %x, 16
 ret i16 %v
}
define i16 @c16_1_31_0(i16 %x) {
 %v = sdiv i16 %x, 31
 ret i16 %v
}
define i16 @c16_1_31_1(i16 %x) {
 %v = srem i16 %x, 31
 ret i16 %v
}
define i16 @c16_1_32767_0(i16 %x) {
 %v = sdiv i16 %x, 32767
 ret i16 %v
}
define i16 @c16_1_32767_1(i16 %x) {
 %v = srem i16 %x, 32767
 ret i16 %v
}
define i16 @c16_1_32768_0(i16 %x) {
 %v = sdiv i16 %x, -32768
 ret i16 %v
}
define i16 @c16_1_32768_1(i16 %x) {
 %v = srem i16 %x, -32768
 ret i16 %v
}
define i16 @c16_1_65535_0(i16 %x) {
 %v = sdiv i16 %x, -1
 ret i16 %v
}
define i16 @c16_1_65535_1(i16 %x) {
 %v = srem i16 %x, -1
 ret i16 %v
}
define i32 @c32_0_0_0(i32 %x) {
 %v = udiv i32 %x, 0
 ret i32 %v
}
define i32 @c32_0_0_1(i32 %x) {
 %v = urem i32 %x, 0
 ret i32 %v
}
define i32 @c32_0_1_0(i32 %x) {
 %v = udiv i32 %x, 1
 ret i32 %v
}
define i32 @c32_0_1_1(i32 %x) {
 %v = urem i32 %x, 1
 ret i32 %v
}
define i32 @c32_0_2_0(i32 %x) {
 %v = udiv i32 %x, 2
 ret i32 %v
}
define i32 @c32_0_2_1(i32 %x) {
 %v = urem i32 %x, 2
 ret i32 %v
}
define i32 @c32_0_3_0(i32 %x) {
 %v = udiv i32 %x, 3
 ret i32 %v
}
define i32 @c32_0_3_1(i32 %x) {
 %v = urem i32 %x, 3
 ret i32 %v
}
define i32 @c32_0_7_0(i32 %x) {
 %v = udiv i32 %x, 7
 ret i32 %v
}
define i32 @c32_0_7_1(i32 %x) {
 %v = urem i32 %x, 7
 ret i32 %v
}
define i32 @c32_0_8_0(i32 %x) {
 %v = udiv i32 %x, 8
 ret i32 %v
}
define i32 @c32_0_8_1(i32 %x) {
 %v = urem i32 %x, 8
 ret i32 %v
}
define i32 @c32_0_16_0(i32 %x) {
 %v = udiv i32 %x, 16
 ret i32 %v
}
define i32 @c32_0_16_1(i32 %x) {
 %v = urem i32 %x, 16
 ret i32 %v
}
define i32 @c32_0_31_0(i32 %x) {
 %v = udiv i32 %x, 31
 ret i32 %v
}
define i32 @c32_0_31_1(i32 %x) {
 %v = urem i32 %x, 31
 ret i32 %v
}
define i32 @c32_0_65535_0(i32 %x) {
 %v = udiv i32 %x, 65535
 ret i32 %v
}
define i32 @c32_0_65535_1(i32 %x) {
 %v = urem i32 %x, 65535
 ret i32 %v
}
define i32 @c32_0_65537_0(i32 %x) {
 %v = udiv i32 %x, 65537
 ret i32 %v
}
define i32 @c32_0_65537_1(i32 %x) {
 %v = urem i32 %x, 65537
 ret i32 %v
}
define i32 @c32_0_2147483647_0(i32 %x) {
 %v = udiv i32 %x, 2147483647
 ret i32 %v
}
define i32 @c32_0_2147483647_1(i32 %x) {
 %v = urem i32 %x, 2147483647
 ret i32 %v
}
define i32 @c32_0_2147483648_0(i32 %x) {
 %v = udiv i32 %x, 2147483648
 ret i32 %v
}
define i32 @c32_0_2147483648_1(i32 %x) {
 %v = urem i32 %x, 2147483648
 ret i32 %v
}
define i32 @c32_0_4294967295_0(i32 %x) {
 %v = udiv i32 %x, 4294967295
 ret i32 %v
}
define i32 @c32_0_4294967295_1(i32 %x) {
 %v = urem i32 %x, 4294967295
 ret i32 %v
}
define i32 @c32_1_0_0(i32 %x) {
 %v = sdiv i32 %x, 0
 ret i32 %v
}
define i32 @c32_1_0_1(i32 %x) {
 %v = srem i32 %x, 0
 ret i32 %v
}
define i32 @c32_1_1_0(i32 %x) {
 %v = sdiv i32 %x, 1
 ret i32 %v
}
define i32 @c32_1_1_1(i32 %x) {
 %v = srem i32 %x, 1
 ret i32 %v
}
define i32 @c32_1_2_0(i32 %x) {
 %v = sdiv i32 %x, 2
 ret i32 %v
}
define i32 @c32_1_2_1(i32 %x) {
 %v = srem i32 %x, 2
 ret i32 %v
}
define i32 @c32_1_3_0(i32 %x) {
 %v = sdiv i32 %x, 3
 ret i32 %v
}
define i32 @c32_1_3_1(i32 %x) {
 %v = srem i32 %x, 3
 ret i32 %v
}
define i32 @c32_1_7_0(i32 %x) {
 %v = sdiv i32 %x, 7
 ret i32 %v
}
define i32 @c32_1_7_1(i32 %x) {
 %v = srem i32 %x, 7
 ret i32 %v
}
define i32 @c32_1_8_0(i32 %x) {
 %v = sdiv i32 %x, 8
 ret i32 %v
}
define i32 @c32_1_8_1(i32 %x) {
 %v = srem i32 %x, 8
 ret i32 %v
}
define i32 @c32_1_16_0(i32 %x) {
 %v = sdiv i32 %x, 16
 ret i32 %v
}
define i32 @c32_1_16_1(i32 %x) {
 %v = srem i32 %x, 16
 ret i32 %v
}
define i32 @c32_1_31_0(i32 %x) {
 %v = sdiv i32 %x, 31
 ret i32 %v
}
define i32 @c32_1_31_1(i32 %x) {
 %v = srem i32 %x, 31
 ret i32 %v
}
define i32 @c32_1_65535_0(i32 %x) {
 %v = sdiv i32 %x, 65535
 ret i32 %v
}
define i32 @c32_1_65535_1(i32 %x) {
 %v = srem i32 %x, 65535
 ret i32 %v
}
define i32 @c32_1_65537_0(i32 %x) {
 %v = sdiv i32 %x, 65537
 ret i32 %v
}
define i32 @c32_1_65537_1(i32 %x) {
 %v = srem i32 %x, 65537
 ret i32 %v
}
define i32 @c32_1_2147483647_0(i32 %x) {
 %v = sdiv i32 %x, 2147483647
 ret i32 %v
}
define i32 @c32_1_2147483647_1(i32 %x) {
 %v = srem i32 %x, 2147483647
 ret i32 %v
}
define i32 @c32_1_2147483648_0(i32 %x) {
 %v = sdiv i32 %x, -2147483648
 ret i32 %v
}
define i32 @c32_1_2147483648_1(i32 %x) {
 %v = srem i32 %x, -2147483648
 ret i32 %v
}
define i32 @c32_1_4294967295_0(i32 %x) {
 %v = sdiv i32 %x, -1
 ret i32 %v
}
define i32 @c32_1_4294967295_1(i32 %x) {
 %v = srem i32 %x, -1
 ret i32 %v
}
define i64 @c64_0_0_0(i64 %x) {
 %v = udiv i64 %x, 0
 ret i64 %v
}
define i64 @c64_0_0_1(i64 %x) {
 %v = urem i64 %x, 0
 ret i64 %v
}
define i64 @c64_0_1_0(i64 %x) {
 %v = udiv i64 %x, 1
 ret i64 %v
}
define i64 @c64_0_1_1(i64 %x) {
 %v = urem i64 %x, 1
 ret i64 %v
}
define i64 @c64_0_2_0(i64 %x) {
 %v = udiv i64 %x, 2
 ret i64 %v
}
define i64 @c64_0_2_1(i64 %x) {
 %v = urem i64 %x, 2
 ret i64 %v
}
define i64 @c64_0_3_0(i64 %x) {
 %v = udiv i64 %x, 3
 ret i64 %v
}
define i64 @c64_0_3_1(i64 %x) {
 %v = urem i64 %x, 3
 ret i64 %v
}
define i64 @c64_0_7_0(i64 %x) {
 %v = udiv i64 %x, 7
 ret i64 %v
}
define i64 @c64_0_7_1(i64 %x) {
 %v = urem i64 %x, 7
 ret i64 %v
}
define i64 @c64_0_8_0(i64 %x) {
 %v = udiv i64 %x, 8
 ret i64 %v
}
define i64 @c64_0_8_1(i64 %x) {
 %v = urem i64 %x, 8
 ret i64 %v
}
define i64 @c64_0_16_0(i64 %x) {
 %v = udiv i64 %x, 16
 ret i64 %v
}
define i64 @c64_0_16_1(i64 %x) {
 %v = urem i64 %x, 16
 ret i64 %v
}
define i64 @c64_0_31_0(i64 %x) {
 %v = udiv i64 %x, 31
 ret i64 %v
}
define i64 @c64_0_31_1(i64 %x) {
 %v = urem i64 %x, 31
 ret i64 %v
}
define i64 @c64_0_65535_0(i64 %x) {
 %v = udiv i64 %x, 65535
 ret i64 %v
}
define i64 @c64_0_65535_1(i64 %x) {
 %v = urem i64 %x, 65535
 ret i64 %v
}
define i64 @c64_0_65537_0(i64 %x) {
 %v = udiv i64 %x, 65537
 ret i64 %v
}
define i64 @c64_0_65537_1(i64 %x) {
 %v = urem i64 %x, 65537
 ret i64 %v
}
define i64 @c64_0_9223372036854775807_0(i64 %x) {
 %v = udiv i64 %x, 9223372036854775807
 ret i64 %v
}
define i64 @c64_0_9223372036854775807_1(i64 %x) {
 %v = urem i64 %x, 9223372036854775807
 ret i64 %v
}
define i64 @c64_0_9223372036854775808_0(i64 %x) {
 %v = udiv i64 %x, 9223372036854775808
 ret i64 %v
}
define i64 @c64_0_9223372036854775808_1(i64 %x) {
 %v = urem i64 %x, 9223372036854775808
 ret i64 %v
}
define i64 @c64_0_18446744073709551615_0(i64 %x) {
 %v = udiv i64 %x, 18446744073709551615
 ret i64 %v
}
define i64 @c64_0_18446744073709551615_1(i64 %x) {
 %v = urem i64 %x, 18446744073709551615
 ret i64 %v
}
define i64 @c64_1_0_0(i64 %x) {
 %v = sdiv i64 %x, 0
 ret i64 %v
}
define i64 @c64_1_0_1(i64 %x) {
 %v = srem i64 %x, 0
 ret i64 %v
}
define i64 @c64_1_1_0(i64 %x) {
 %v = sdiv i64 %x, 1
 ret i64 %v
}
define i64 @c64_1_1_1(i64 %x) {
 %v = srem i64 %x, 1
 ret i64 %v
}
define i64 @c64_1_2_0(i64 %x) {
 %v = sdiv i64 %x, 2
 ret i64 %v
}
define i64 @c64_1_2_1(i64 %x) {
 %v = srem i64 %x, 2
 ret i64 %v
}
define i64 @c64_1_3_0(i64 %x) {
 %v = sdiv i64 %x, 3
 ret i64 %v
}
define i64 @c64_1_3_1(i64 %x) {
 %v = srem i64 %x, 3
 ret i64 %v
}
define i64 @c64_1_7_0(i64 %x) {
 %v = sdiv i64 %x, 7
 ret i64 %v
}
define i64 @c64_1_7_1(i64 %x) {
 %v = srem i64 %x, 7
 ret i64 %v
}
define i64 @c64_1_8_0(i64 %x) {
 %v = sdiv i64 %x, 8
 ret i64 %v
}
define i64 @c64_1_8_1(i64 %x) {
 %v = srem i64 %x, 8
 ret i64 %v
}
define i64 @c64_1_16_0(i64 %x) {
 %v = sdiv i64 %x, 16
 ret i64 %v
}
define i64 @c64_1_16_1(i64 %x) {
 %v = srem i64 %x, 16
 ret i64 %v
}
define i64 @c64_1_31_0(i64 %x) {
 %v = sdiv i64 %x, 31
 ret i64 %v
}
define i64 @c64_1_31_1(i64 %x) {
 %v = srem i64 %x, 31
 ret i64 %v
}
define i64 @c64_1_65535_0(i64 %x) {
 %v = sdiv i64 %x, 65535
 ret i64 %v
}
define i64 @c64_1_65535_1(i64 %x) {
 %v = srem i64 %x, 65535
 ret i64 %v
}
define i64 @c64_1_65537_0(i64 %x) {
 %v = sdiv i64 %x, 65537
 ret i64 %v
}
define i64 @c64_1_65537_1(i64 %x) {
 %v = srem i64 %x, 65537
 ret i64 %v
}
define i64 @c64_1_9223372036854775807_0(i64 %x) {
 %v = sdiv i64 %x, 9223372036854775807
 ret i64 %v
}
define i64 @c64_1_9223372036854775807_1(i64 %x) {
 %v = srem i64 %x, 9223372036854775807
 ret i64 %v
}
define i64 @c64_1_9223372036854775808_0(i64 %x) {
 %v = sdiv i64 %x, -9223372036854775808
 ret i64 %v
}
define i64 @c64_1_9223372036854775808_1(i64 %x) {
 %v = srem i64 %x, -9223372036854775808
 ret i64 %v
}
define i64 @c64_1_18446744073709551615_0(i64 %x) {
 %v = sdiv i64 %x, -1
 ret i64 %v
}
define i64 @c64_1_18446744073709551615_1(i64 %x) {
 %v = srem i64 %x, -1
 ret i64 %v
}
