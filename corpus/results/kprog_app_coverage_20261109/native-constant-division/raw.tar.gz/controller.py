from pathlib import Path
import subprocess,json,shlex,hashlib,ctypes,random,io,tarfile,sys,traceback,datetime
from elftools.elf.elffile import ELFFile
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/native-constant-division'
commands=[]
def run(args,log,cwd=R):
 commands.append(dict(args=[str(x)for x in args],cwd=str(cwd),log=log));(G/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with(G/log).open('w')as f:p=subprocess.run([str(x)for x in args],cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 (G/(log+'.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('compiling')
 llvm=shlex.split(subprocess.check_output(['llvm-config-18','--cxxflags','--ldflags','--system-libs','--libs','core','passes'],text=True))
 for label,src in [('control','native_division.control.cpp'),('candidate','native_division.cpp')]:
  run(['clang-18','-x','c++','-fPIC','-shared',G/src,*llvm,'-O2','-o',G/(label+'.so')],label+'-plugin.log')
  for subject,oracle in [('division-subject','division-oracle'),('division-vector','division-vector-oracle')]:
   obj=G/(label+'-'+subject+'.o');exe=G/(label+'-'+oracle)
   run(['clang-18','-O3','-fPIC','-fpass-plugin='+str(G/(label+'.so')),'-c',G/(subject+'.c'),'-o',obj],label+'-'+subject+'-compile.log')
   run(['gcc','-O2',G/(oracle+'.c'),obj,'-o',exe],label+'-'+oracle+'-link.log');run([exe],label+'-'+oracle+'.log')
 # Actual LLVM integer widths keep every constant-denominator case through the plugin.
 specs=[];ir=['target triple = "x86_64-pc-linux-gnu"']
 for bits in [8,16,32,64]:
  for sign in [False,True]:
   vals=sorted(set([0,1,2,3,7,8,16,31, (1<<(bits-1))-1, (1<<(bits-1)), (1<<bits)-1]+([65535,65537]if bits>16 else [])))
   for raw in vals:
    d=raw-(1<<bits)if sign and raw>=(1<<(bits-1))else raw
    for rem in [False,True]:
     name=f'c{bits}_{int(sign)}_{raw}_{int(rem)}';op=('s'if sign else'u')+('rem'if rem else'div')
     ir.append(f'define i{bits} @{name}(i{bits} %x) {{\n %v = {op} i{bits} %x, {d}\n ret i{bits} %v\n}}')
     specs.append(dict(name=name,bits=bits,signed=sign,divisor=d,remainder=rem))
 (G/'constants.ll').write_text('\n'.join(ir)+'\n');(G/'constants.json').write_text(json.dumps(specs,indent=2)+'\n')
 for label in ['control','candidate']:
  run(['clang-18','-O3','-fPIC','-shared','-fpass-plugin='+str(G/(label+'.so')),G/'constants.ll','-o',G/(label+'-constants.so')],label+'-constants-build.log')
  lib=ctypes.CDLL(str(G/(label+'-constants.so')));results=0
  for row in specs:
   bits=row['bits'];sign=row['signed'];mask=(1<<bits)-1;fn=getattr(lib,row['name']);typ=getattr(ctypes,('c_int'if sign else'c_uint')+str(bits));fn.argtypes=[typ];fn.restype=typ
   edges=[0,1,2,3,7,8,15,16,31,127,128,255,256,32767,32768,65535,65536,(1<<(bits-1))-1,1<<(bits-1),mask]
   rng=random.Random(0x154c4ead29ac7831)
   nums=list(range(1<<min(bits,16)))if bits<=16 else edges+[rng.getrandbits(bits)for _ in range(10000)]
   for raw in nums:
    raw&=mask;a=raw-(1<<bits)if sign and raw>=(1<<(bits-1))else raw;b=row['divisor']
    q=0 if b==0 else (abs(a)//abs(b))*(-1 if (a<0)^(b<0)else 1)
    expected=(a if b==0 else a-q*b)if row['remainder']else q
    expected&=mask
    if sign and expected>=(1<<(bits-1)):expected-=1<<bits
    got=fn(a)
    if got!=expected:raise RuntimeError(str(dict(case=row,a=a,expected=expected,got=got)))
    results+=1
  (G/(label+'-constants-result.json')).write_text(json.dumps(dict(functions=len(specs),results=results,matched=results),indent=2)+'\n')
 # Use existing corpus object rules and the same current C/headers/flags on both producers.
 rows=[];dependencies={}
 for label in ['control','candidate']:
  d=G/label;d.mkdir(exist_ok=True)
  objects=[d/'native/bcc'/(n+'.native.o')for n in ['biosnoop','capable','opensnoop','runqlat','syscount','tcpconnect','tcplife','vfsstat']]+[d/'native/katran'/(n+'.native.o')for n in ['balancer','healthchecking','healthchecking_ipip','xdp_root']]
  run(['taskset','-c','20-23','make','-C',R/'vendor/bpf',*objects,'ARCH=x86','KERNEL_RELEASE=7.0.0-rc2+','NATIVE_OUT='+str(d/'native'),'NATIVE_DIVISION_PLUGIN='+str(G/(label+'.so'))],label+'-native.log')
  obs=[]
  for obj in objects:
   with obj.open('rb')as f:
    elf=ELFFile(f);sections=[dict(name=s.name,bytes=s['sh_size'],sha256=hashlib.sha256(s.data()).hexdigest())for s in elf.iter_sections()if s['sh_flags']&4 and s['sh_size']]
   name=str(obj.relative_to(d));text=subprocess.check_output(['llvm-objdump-18','-dr','--no-show-raw-insn',str(obj)],text=True);dst=d/(obj.name+'.disassembly.txt');dst.write_text(text)
   import re
   div=[l for l in text.splitlines()if re.search(r'\t(?:i?div)[bwlq]?\s',l)]
   obs.append(dict(object=name,sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),sections=sections,division_instructions=div))
   dep=obj.with_suffix('.d')
   if dep.exists():
    for n in shlex.split(dep.read_text().replace('\\\n',' ').split(':',1)[1]):
     src=Path(n);src=src if src.is_absolute()else R/'vendor/bpf'/src
     if src.is_file():
      src=src.resolve();dependencies[str(src)]=hashlib.sha256(src.read_bytes()).hexdigest()
      try:rel=src.relative_to(R)
      except ValueError:continue
      dst=G/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
  for app in ['bcc','katran']:
   objs=[obj for obj in objects if obj.parent.name==app]
   run(['python3',R/'vendor/bpf/write_native_manifest.py','--app',app,'--llvm-nm','llvm-nm-18','--output',d/'native'/app/'manifest.json',*[v for obj in objs for v in ['--object',obj]]],label+'-'+app+'-manifest.log')
  rows.append(dict(label=label,objects=obs));(G/'objects.json').write_text(json.dumps(rows,indent=2)+'\n')
 (G/'source-dependencies.json').write_text(json.dumps(dependencies,indent=2)+'\n')
 O.mkdir(parents=True,exist_ok=True)
 result=dict(producer_cases=rows,constant_cases={label:json.loads((G/(label+'-constants-result.json')).read_text())for label in ['control','candidate']},native_executions=0,guest_executions=0)
 (O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'candidate.patch').write_bytes((G/'candidate.patch').read_bytes())
 table='| Native object | Control DIV/IDIV sites | Candidate DIV/IDIV sites | Control bytes | Candidate bytes |\n| --- | ---: | ---: | ---: | ---: |\n'
 for old,new in zip(rows[0]['objects'],rows[1]['objects']):table+=f"| {old['object']} | {len(old['division_instructions'])} | {len(new['division_instructions'])} | {sum(s['bytes']for s in old['sections'])} | {sum(s['bytes']for s in new['sections'])} |\n"
 (O/'README.md').write_text('# Constant-division strength reduction in native P production\n\nThe existing native division pass emits guarded hardware division before LLVM optimization. This candidate retains defined constant divisors as LLVM division/remainder operations so the existing optimizer selects shifts and reciprocal multiplication. Constant zero and signed minus-one keep their original guarded eBPF-semantic lowering. Variable divisors and vector lane semantics retain the original pass. The change is four compiler-source lines before P submission.\n\n'+table+'\nThe same current C, helper ABI, compiler flags and existing relocation kinds build both complete12-object producers. Scalar/optnone/flag-frame and vector oracles reuse the existing sources. Constant integer-width fixtures compare actual compiled results with mathematical quotient/remainder over exhaustive8/16-bit numerators and boundary/random32/64-bit numerators; summary.json records exact counts. Raw compiler commands, inputs, native objects and disassemblies accompany raw.tar.gz. Original38, generation-bound application loading, matching work and R-restored05-29 throughput remain subsequent observations. Production compiler source and active canonical/Os application epochs retain their captured definitions. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tar:
  for x in sorted(G.iterdir()):
   if x.name not in ['controller.log','controller.pid','status.json','publication.json']:tar.add(x,arcname=x.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure constant-division native compiler candidate',G/'publication.json');save('finished',commit=commit)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/R/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' pre-submit constant-division compiler candidate at corpus/results/kprog_app_coverage_20261109/native-constant-division. Defined constant divisions remain LLVM operations for strength reduction; zero/signed-minus-one/variable cases retain existing eBPF semantics. Both12-object O3 producers, existing scalar/vector oracles and constant-width actual execution results are retained. Production source and active SMAP/Os cohorts stay captured. Whole application/original38 and R timing follow the existing serial job chain. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
