#!/bin/bash
set -e
install -d /var/tmp/kprog-tmp/C/stock-entry/replays/f05af452eb9fa6ca188bd994e57acd20ee909809/tail
mount --bind /mnt /var/tmp/kprog-tmp/C/stock-entry/replays/f05af452eb9fa6ca188bd994e57acd20ee909809/tail
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
export KPROG_STOCK_MODULE=/mnt/kprog_stock.ko
export KPROG_STOCK_LOADER=/workspaces/repository/kprog/libnativeloader/build
export KPROG_STOCK_BOUND_PROBE=/mnt/bound-probe
export KPROG_STOCK_NATIVE_LINK=/mnt/native-link
OUT=/var/tmp/kprog-tmp/C/stock-entry/replays/f05af452eb9fa6ca188bd994e57acd20ee909809/tail/out
. /workspaces/repository/kprog/stock-path/guest/common.sh
export TMPDIR=/var/tmp/kprog-tmp/C/stock-entry/replays/f05af452eb9fa6ca188bd994e57acd20ee909809/tail CLANG=/var/tmp/kprog-tmp/C/stock-entry/replays/f05af452eb9fa6ca188bd994e57acd20ee909809/tail/stock-compile-proxy
start_service
set +e
/mnt/client /mnt/tail.bpf.o /mnt/tail.native.o /mnt/native-link /var/tmp/kprog-tmp/C/stock-entry/replays/f05af452eb9fa6ca188bd994e57acd20ee909809/tail/out/native.bin /mnt/tail_frame_probe.ko > "$OUT/suite.log" 2>&1
result=$?
stop_service
printf "%s\n" "$result" > "$OUT/suite.exit"
dmesg > "$OUT/dmesg"
exit "$result"
