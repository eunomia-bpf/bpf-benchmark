#!/bin/bash
set -e
install -d /workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/coherent-six-app-runtime
mount --bind /mnt /workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/coherent-six-app-runtime
export CLANG=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/coherent-six-app-runtime/stock-compile-proxy
export PYTHONDONTWRITEBYTECODE=1 BPFREJIT_CORPUS_BPF_STATS=1 BPFREJIT_INSTALL_SKIP_KINSN=1
python3 /mnt/guest.py --samples 1 --duration 2 --apps bcc/set,otelcol-ebpf-profiler/profiling --state /workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/coherent-six-app-runtime
