#!/bin/bash
set -e
install -d /var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315
mount --bind /mnt /var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
export KPROG_STOCK_MODULE=/mnt/kprog_stock.ko
export KPROG_STOCK_LOADER=/workspaces/repository/kprog/libnativeloader/build
export KPROG_STOCK_BOUND_PROBE=/mnt/bound-probe
export KPROG_STOCK_NATIVE_LINK=/mnt/native-link
OUT=/var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315/out
. /workspaces/repository/kprog/stock-path/guest/common.sh
export TMPDIR=/var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315 CLANG=/var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315/stock-compile-proxy
set +e
python3 /workspaces/repository/kprog/selftests/submit.py --arch x86 --table /var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315/table --out /var/tmp/kprog-tmp/C/stock-entry/replays/354fdbee9dca5664cc75bb662d9e5c9af1057a17/selftests315/out > "$OUT/suite.log" 2>&1
result=$?
printf "%s\n" "$result" > "$OUT/suite.exit"
dmesg > "$OUT/dmesg"
exit "$result"
