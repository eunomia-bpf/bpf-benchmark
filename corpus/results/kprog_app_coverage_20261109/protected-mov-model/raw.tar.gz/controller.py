from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,traceback,tarfile,hashlib,sys,shutil
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261109/protected-mov-model'
def save(**j):(G/'status.json').write_text(json.dumps(j,indent=2)+'\n')
try:
 try:
  fd=__import__('os').pidfd_open(int((G/'diagnostic.pid').read_text()));__import__('select').select([fd],[],[]);__import__('os').close(fd)
 except ProcessLookupError:pass
 save(state='component_running')
 with(G/'run.log').open('w')as f:p=subprocess.run(['taskset','-c','8-11','make','-f',str(G/'Makefile'),'component'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n');save(state='component_closed',make_exit=p.returncode)
 O.mkdir(parents=True,exist_ok=True)
 (O/'summary.json').write_text(json.dumps(dict(make_exit=p.returncode,log=(G/'run.log').read_text(),candidate_sha256=hashlib.sha256((G/'source/kprog/x86/x86_sim_local_bpf.h').read_bytes()).hexdigest()),indent=2)+'\n')
 (O/'README.md').write_text('# Generic scalar-address MOV protected-read candidate\n\nThe private candidate exposes both outcomes through the existing unspecified-input mechanism at the single MOV memory access. Success runs the original typed-load body. Recovery clears the full architectural destination register and preserves all flags, raw stack memory, vectors and other GPRs. Narrow MOV and sign/zero extension use the same full saved-GPR recovery, with RSP represented through its existing native coordinate. Full-state host cases cover all16GPR destinations, four high-byte destinations, native widths and extension forms,64flag states,66values and both outcomes. Recovery receives address0x70, so a host access reaches the ordinary process fault path. Both gcc/clang use UBSan. Actual Make exit '+str(p.returncode)+'. Source, generated fixture, every variant and original compiler diagnostics accompany raw.tar.gz.\n\nThe initial fixture forced every encoding through the MOV-load handler; high-byte loads actually encode as MOV-immediate with an embedded memory read. The corrected fixture executes actual append_step output for all244 forms, and a generic emitter recovery arm precedes each high-byte embedded read. Initial compiler/debug output remains retained. Canonical production header and generator retain their current definitions. This component covers scalar-address MOV only. Known-valid context/stack/map/packet/immutable routes keep their existing load body; their validity/lifetime relation remains a universal interface. ALU/RMW/POP/REP/vector access prefixes and the SMAP dispatch case remain the ensuing recovery work. Native guest recovery and full B/physical correspondence retain their separate observations. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for n in ['initial','source','candidate.patch','generate-fixture.py','host.c','variants.json','Makefile','controller.py','run.log','run.exit','status.json']:
   if(G/n).exists():t.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure scalar MOV protected-read success and recovery states',G/'publication.json');save(state='finished',make_exit=p.returncode,commit=commit)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR V/A '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' private generic scalar-address MOV protected-read model component Makeexit'+str(p.returncode)+'. Existing fresh-input selector branches before access; fault clears full native GPR including narrow/MOVSX/MOVZX and preserves flags/memory/vector/fullframe; success retains actual typed load. All16GPR/highbyte/width/extension/64flags/66values both outcomes retained with raw0x70 fault address. Production header retains current bytes. Knownvalid routes/lifetime and ALU/RMW/POP/REP/vector prefixes remain universal interfaces. Existing SMAP case00:38 remains coordinator disposition. Runtime admission additions0.\n')
except BaseException as e:save(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
