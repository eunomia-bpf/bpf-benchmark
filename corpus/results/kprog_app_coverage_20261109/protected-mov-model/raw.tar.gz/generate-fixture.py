from pathlib import Path
import sys,importlib.util,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');F=R/'kprog/formal'
sys.path.insert(0,str(R/'kprog/x86/micro-prog'))
spec=importlib.util.spec_from_file_location('fault_encoder',G/'source/kprog/x86/micro-prog/generate_micro_sim_proofs.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
registers=[('rax','eax','ax','al'),('rcx','ecx','cx','cl'),('rdx','edx','dx','dl'),('rbx','ebx','bx','bl'),('rsp','esp','sp','spl'),('rbp','ebp','bp','bpl'),('rsi','esi','si','sil'),('rdi','edi','di','dil')]+[(f'r{i}',f'r{i}d',f'r{i}w',f'r{i}b')for i in range(8,16)]
variants=[]
for reg in registers:
 for bits,which,ptr in [(64,0,'QWORD'),(32,1,'DWORD'),(16,2,'WORD'),(8,3,'BYTE')]:variants.append(('mov',reg[which],f'{ptr} PTR [rdi+16]',bits,bits,False))
 for bits,which in [(64,0),(32,1),(16,2)]:
  for memory,ptr in [(8,'BYTE'),(16,'WORD')]:
   if memory<bits:
    variants.append(('movzx',reg[which],f'{ptr} PTR [rdi+16]',bits,memory,False));variants.append(('movsx',reg[which],f'{ptr} PTR [rdi+16]',bits,memory,True))
 variants.append(('movsxd',reg[0],'DWORD PTR [rdi+16]',64,32,True))
for byte in ['ah','bh','ch','dh']:variants.append(('mov',byte,'BYTE PTR [rdi+16]',8,8,False))
source=['#define X86_SIM_USE_STATE_STRUCT','#define X86_SIM_ENABLE_STACK 1','#include "'+str(G/'source/kprog/x86/x86_sim_local_bpf.h')+'"','#include "'+str(F/'oracles/x86_no_helpers_host.h')+'"','#include <string.h>','#include <stdio.h>','static unsigned outcome,calls;','static volatile unsigned active_variant,active_flags,active_pattern,active_fault;','#undef X86_SIM_L_UNSPECIFIED','#define X86_SIM_L_UNSPECIFIED() (calls++,outcome)','#undef __x86_sim_is_xdp','#define __x86_sim_is_xdp entry_mode']
for i,(op,dst,mem,*_)in enumerate(variants):
 insn=m.NativeInsn(0,f'{op} {dst},{mem}',op,(dst,mem));e=m.encode(insn,{});emitted=[];m.append_step(emitted,insn)
 source+=['static __always_inline void run_'+str(i)+'(struct x86_sim_state *s){','const __u8 entry_mode=s->is_xdp;','X86_SIM_L_BIND_COMMON_STATE(s);',*emitted,'}']
source+=['int main(void){unsigned cases=0;','for(unsigned flags=0;flags<64;flags++)for(unsigned pattern=0;pattern<66;pattern++)for(unsigned fault=0;fault<2;fault++){','__u64 value=pattern<64?1ULL<<pattern:pattern==64?0:~0ULL;']
for i,(_,dst,_,bits,mem,signed)in enumerate(variants):
 base=m.reg_info(dst)[0][4:].lower();shift=m.reg_info(dst)[2]
 source+=['{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);']
 for j,reg in enumerate(registers):source+=[f'state.{reg[0]}.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*{j+1}+0x123456789abcdefULL);state.{reg[0]}_tag=0x7f;']
 source+=['state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;','state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;','state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;',f'__u64 raw=value & (~0ULL>>(64-{mem}));']
 if signed:source+=[f'if(raw & (1ULL<<({mem}-1)))raw|=~0ULL<<{mem};']
 source+=[f'__u64 old=(unsigned long)state.{base}.ptr;']
 if base=='rsp':source+=['old+=state.native_stack_base;']
 if bits>=32:source+=[f'__u64 want=fault?0:(raw & (~0ULL>>(64-{bits})));']
 else:source+=[f'__u64 mask=(~0ULL>>(64-{bits}))<<{shift};__u64 want=fault?0:((old&~mask)|((raw<<{shift})&mask));']
 if base=='rsp':source+=['want-=state.native_stack_base;']
 source+=[f'expected.{base}.ptr=(void *)(unsigned long)want;expected.{base}_tag=X86_SIM_TAG_SCALAR;',f'outcome=fault;calls=0;active_variant={i};active_flags=flags;active_pattern=pattern;active_fault=fault;run_{i}(&state);',f'if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){{fprintf(stderr,"MOV fault-prefix variant={i} flags=%u pattern=%u fault=%u calls=%u\\n",flags,pattern,fault,calls);return 1;}}','(void)old;cases++;}']
source+=['}printf("MOV protected-read success/recovery: %u full-state cases OK\\n",cases);return 0;}']
(G/'host.c').write_text('\n'.join(source)+'\n');(G/'variants.json').write_text(json.dumps(variants,indent=2)+'\n')
print('variants',len(variants))
