#define X86_SIM_USE_STATE_STRUCT
#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/load-fault-recovery/mov-fault-model/source/kprog/x86/x86_sim_local_bpf.h"
#include "/workspaces/repository/kprog/formal/oracles/x86_no_helpers_host.h"
#include <string.h>
#include <stdio.h>
static unsigned outcome,calls;
static volatile unsigned active_variant,active_flags,active_pattern,active_fault;
#undef X86_SIM_L_UNSPECIFIED
#define X86_SIM_L_UNSPECIFIED() (calls++,outcome)
#undef __x86_sim_is_xdp
#define __x86_sim_is_xdp entry_mode
static __always_inline void run_0(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rax,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_1(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_2(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_3(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov al,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_4(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rax,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_5(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rax,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_6(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_7(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_8(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx eax,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_9(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx eax,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_10(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx eax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_11(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx eax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_12(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ax,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_13(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ax,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_14(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_15(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rcx,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_16(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov ecx,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_17(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov cx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_18(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov cl,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_19(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rcx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_20(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rcx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_21(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rcx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_22(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rcx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_23(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ecx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_24(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ecx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_25(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ecx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_26(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ecx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_27(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx cx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_28(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx cx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_29(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rcx,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_30(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rdx,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_31(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov edx,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_32(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov dx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_33(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov dl,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_34(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rdx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_35(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rdx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_36(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rdx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_37(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rdx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_38(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx edx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_39(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx edx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_40(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx edx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_41(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx edx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_42(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx dx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_43(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx dx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_44(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rdx,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_45(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rbx,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_46(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov ebx,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_47(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov bx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_48(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov bl,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_49(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rbx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_50(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rbx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_51(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rbx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_52(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rbx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_53(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ebx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_54(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ebx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_55(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ebx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_56(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ebx,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_57(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx bx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_58(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx bx,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_59(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rbx,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_60(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rsp,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_61(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_62(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_63(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov spl,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_64(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rsp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_65(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rsp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_66(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rsp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_67(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rsp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_68(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx esp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_69(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx esp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_70(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx esp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_71(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx esp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_72(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx sp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSP, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_73(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx sp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSP, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_74(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rsp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_75(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rbp,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_76(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov ebp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_77(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov bp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_78(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov bpl,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_79(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rbp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_80(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rbp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_81(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rbp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_82(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rbp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_83(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ebp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_84(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ebp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_85(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx ebp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_86(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx ebp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_87(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx bp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_88(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx bp,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBP, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_89(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rbp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_90(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rsi,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_91(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov esi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_92(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov si,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_93(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov sil,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_94(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rsi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_95(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rsi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_96(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rsi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_97(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rsi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_98(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx esi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_99(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx esi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_100(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx esi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_101(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx esi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_102(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx si,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_103(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx si,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_104(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rsi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_105(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov rdi,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_106(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_107(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_108(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov dil,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_109(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rdi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_110(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rdi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_111(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx rdi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_112(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx rdi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_113(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx edi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_114(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx edi,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_115(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx edi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_116(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx edi,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_117(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx di,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_118(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx di,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_119(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd rdi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_120(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r8,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_121(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r8d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_122(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r8w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_123(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r8b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_124(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r8,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_125(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r8,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_126(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r8,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_127(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r8,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_128(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r8d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_129(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r8d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_130(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r8d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_131(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r8d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_132(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r8w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_133(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r8w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R8, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_134(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r8,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_135(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r9,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_136(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r9d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_137(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r9w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_138(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r9b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_139(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r9,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_140(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r9,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_141(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r9,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_142(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r9,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_143(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r9d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_144(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r9d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_145(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r9d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_146(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r9d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_147(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r9w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_148(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r9w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_149(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r9,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_150(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r10,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_151(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r10d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_152(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r10w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_153(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r10b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_154(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r10,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_155(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r10,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_156(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r10,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_157(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r10,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_158(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r10d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_159(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r10d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_160(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r10d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_161(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r10d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_162(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r10w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_163(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r10w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_164(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r10,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_165(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r11,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_166(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r11d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_167(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r11w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_168(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r11b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_169(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r11,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_170(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r11,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_171(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r11,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_172(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r11,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_173(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r11d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_174(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r11d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R11, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_175(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r11d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_176(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r11d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R11, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_177(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r11w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_178(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r11w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R11, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_179(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r11,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_180(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r12,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_181(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r12d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_182(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r12w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_183(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r12b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_184(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r12,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_185(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r12,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_186(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r12,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_187(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r12,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_188(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r12d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_189(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r12d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_190(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r12d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_191(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r12d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_192(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r12w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_193(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r12w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R12, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_194(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r12,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_195(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r13,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_196(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r13d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_197(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r13w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_198(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r13b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_199(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r13,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_200(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r13,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_201(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r13,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_202(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r13,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_203(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r13d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_204(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r13d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_205(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r13d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_206(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r13d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R13, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_207(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r13w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_208(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r13w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R13, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_209(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r13,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_210(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r14,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_211(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r14d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_212(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r14w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_213(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r14b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_214(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r14,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_215(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r14,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_216(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r14,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_217(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r14,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_218(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r14d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_219(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r14d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_220(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r14d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_221(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r14d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_222(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r14w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_223(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r14w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R14, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_224(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r14,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_225(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r15,QWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_226(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r15d,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_227(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r15w,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_228(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov r15b,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_229(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r15,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_230(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r15,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_231(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r15,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_232(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r15,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_233(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r15d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_234(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r15d,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_235(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r15d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_236(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r15d,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
}
static __always_inline void run_237(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movzx r15w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_238(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsx r15w,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R15, X86_RDI, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_239(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: movsxd r15,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
}
static __always_inline void run_240(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov ah,BYTE PTR [rdi+16] */
	if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR && (X86_SIM_L_UNSPECIFIED() & 1U))
		X86_SIM_L_WRITE_REG_WIDTH(X86_RAX, 0, X86_WIDTH_64);
	else {
		X86_SIM_L_EXEC_MOV_IMM_AUX(X86_RAX, X86_WIDTH_8, KPROG_X86_REG_LANE_AUX((0), 8, 0), X86_SIM_L_READ_MEM_VALUE(X86_RDI, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL, X86_WIDTH_8, 0));
	}
}
static __always_inline void run_241(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov bh,BYTE PTR [rdi+16] */
	if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR && (X86_SIM_L_UNSPECIFIED() & 1U))
		X86_SIM_L_WRITE_REG_WIDTH(X86_RBX, 0, X86_WIDTH_64);
	else {
		X86_SIM_L_EXEC_MOV_IMM_AUX(X86_RBX, X86_WIDTH_8, KPROG_X86_REG_LANE_AUX((0), 8, 0), X86_SIM_L_READ_MEM_VALUE(X86_RDI, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL, X86_WIDTH_8, 0));
	}
}
static __always_inline void run_242(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov ch,BYTE PTR [rdi+16] */
	if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR && (X86_SIM_L_UNSPECIFIED() & 1U))
		X86_SIM_L_WRITE_REG_WIDTH(X86_RCX, 0, X86_WIDTH_64);
	else {
		X86_SIM_L_EXEC_MOV_IMM_AUX(X86_RCX, X86_WIDTH_8, KPROG_X86_REG_LANE_AUX((0), 8, 0), X86_SIM_L_READ_MEM_VALUE(X86_RDI, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL, X86_WIDTH_8, 0));
	}
}
static __always_inline void run_243(struct x86_sim_state *s){
const __u8 entry_mode=s->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(s);
	/* 0x0: mov dh,BYTE PTR [rdi+16] */
	if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR && (X86_SIM_L_UNSPECIFIED() & 1U))
		X86_SIM_L_WRITE_REG_WIDTH(X86_RDX, 0, X86_WIDTH_64);
	else {
		X86_SIM_L_EXEC_MOV_IMM_AUX(X86_RDX, X86_WIDTH_8, KPROG_X86_REG_LANE_AUX((0), 8, 0), X86_SIM_L_READ_MEM_VALUE(X86_RDI, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL, X86_WIDTH_8, 0));
	}
}
int main(void){unsigned cases=0;
for(unsigned flags=0;flags<64;flags++)for(unsigned pattern=0;pattern<66;pattern++)for(unsigned fault=0;fault<2;fault++){
__u64 value=pattern<64?1ULL<<pattern:pattern==64?0:~0ULL;
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=0;active_flags=flags;active_pattern=pattern;active_fault=fault;run_0(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=0 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=1;active_flags=flags;active_pattern=pattern;active_fault=fault;run_1(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=1 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rax.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=2;active_flags=flags;active_pattern=pattern;active_fault=fault;run_2(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=2 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rax.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=3;active_flags=flags;active_pattern=pattern;active_fault=fault;run_3(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=3 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=4;active_flags=flags;active_pattern=pattern;active_fault=fault;run_4(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=4 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=5;active_flags=flags;active_pattern=pattern;active_fault=fault;run_5(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=5 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=6;active_flags=flags;active_pattern=pattern;active_fault=fault;run_6(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=6 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=7;active_flags=flags;active_pattern=pattern;active_fault=fault;run_7(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=7 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=8;active_flags=flags;active_pattern=pattern;active_fault=fault;run_8(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=8 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=9;active_flags=flags;active_pattern=pattern;active_fault=fault;run_9(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=9 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=10;active_flags=flags;active_pattern=pattern;active_fault=fault;run_10(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=10 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=11;active_flags=flags;active_pattern=pattern;active_fault=fault;run_11(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=11 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rax.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=12;active_flags=flags;active_pattern=pattern;active_fault=fault;run_12(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=12 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rax.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=13;active_flags=flags;active_pattern=pattern;active_fault=fault;run_13(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=13 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rax.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=14;active_flags=flags;active_pattern=pattern;active_fault=fault;run_14(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=14 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=15;active_flags=flags;active_pattern=pattern;active_fault=fault;run_15(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=15 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=16;active_flags=flags;active_pattern=pattern;active_fault=fault;run_16(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=16 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=17;active_flags=flags;active_pattern=pattern;active_fault=fault;run_17(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=17 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=18;active_flags=flags;active_pattern=pattern;active_fault=fault;run_18(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=18 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=19;active_flags=flags;active_pattern=pattern;active_fault=fault;run_19(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=19 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=20;active_flags=flags;active_pattern=pattern;active_fault=fault;run_20(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=20 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=21;active_flags=flags;active_pattern=pattern;active_fault=fault;run_21(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=21 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=22;active_flags=flags;active_pattern=pattern;active_fault=fault;run_22(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=22 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=23;active_flags=flags;active_pattern=pattern;active_fault=fault;run_23(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=23 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=24;active_flags=flags;active_pattern=pattern;active_fault=fault;run_24(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=24 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=25;active_flags=flags;active_pattern=pattern;active_fault=fault;run_25(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=25 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=26;active_flags=flags;active_pattern=pattern;active_fault=fault;run_26(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=26 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=27;active_flags=flags;active_pattern=pattern;active_fault=fault;run_27(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=27 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rcx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=28;active_flags=flags;active_pattern=pattern;active_fault=fault;run_28(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=28 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rcx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=29;active_flags=flags;active_pattern=pattern;active_fault=fault;run_29(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=29 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=30;active_flags=flags;active_pattern=pattern;active_fault=fault;run_30(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=30 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=31;active_flags=flags;active_pattern=pattern;active_fault=fault;run_31(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=31 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=32;active_flags=flags;active_pattern=pattern;active_fault=fault;run_32(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=32 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=33;active_flags=flags;active_pattern=pattern;active_fault=fault;run_33(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=33 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=34;active_flags=flags;active_pattern=pattern;active_fault=fault;run_34(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=34 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=35;active_flags=flags;active_pattern=pattern;active_fault=fault;run_35(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=35 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=36;active_flags=flags;active_pattern=pattern;active_fault=fault;run_36(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=36 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=37;active_flags=flags;active_pattern=pattern;active_fault=fault;run_37(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=37 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=38;active_flags=flags;active_pattern=pattern;active_fault=fault;run_38(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=38 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=39;active_flags=flags;active_pattern=pattern;active_fault=fault;run_39(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=39 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=40;active_flags=flags;active_pattern=pattern;active_fault=fault;run_40(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=40 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=41;active_flags=flags;active_pattern=pattern;active_fault=fault;run_41(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=41 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=42;active_flags=flags;active_pattern=pattern;active_fault=fault;run_42(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=42 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rdx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=43;active_flags=flags;active_pattern=pattern;active_fault=fault;run_43(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=43 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rdx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=44;active_flags=flags;active_pattern=pattern;active_fault=fault;run_44(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=44 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=45;active_flags=flags;active_pattern=pattern;active_fault=fault;run_45(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=45 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=46;active_flags=flags;active_pattern=pattern;active_fault=fault;run_46(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=46 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=47;active_flags=flags;active_pattern=pattern;active_fault=fault;run_47(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=47 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=48;active_flags=flags;active_pattern=pattern;active_fault=fault;run_48(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=48 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=49;active_flags=flags;active_pattern=pattern;active_fault=fault;run_49(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=49 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=50;active_flags=flags;active_pattern=pattern;active_fault=fault;run_50(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=50 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=51;active_flags=flags;active_pattern=pattern;active_fault=fault;run_51(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=51 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=52;active_flags=flags;active_pattern=pattern;active_fault=fault;run_52(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=52 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=53;active_flags=flags;active_pattern=pattern;active_fault=fault;run_53(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=53 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=54;active_flags=flags;active_pattern=pattern;active_fault=fault;run_54(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=54 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=55;active_flags=flags;active_pattern=pattern;active_fault=fault;run_55(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=55 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=56;active_flags=flags;active_pattern=pattern;active_fault=fault;run_56(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=56 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=57;active_flags=flags;active_pattern=pattern;active_fault=fault;run_57(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=57 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rbx.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=58;active_flags=flags;active_pattern=pattern;active_fault=fault;run_58(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=58 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rbx.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=59;active_flags=flags;active_pattern=pattern;active_fault=fault;run_59(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=59 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=60;active_flags=flags;active_pattern=pattern;active_fault=fault;run_60(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=60 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=61;active_flags=flags;active_pattern=pattern;active_fault=fault;run_61(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=61 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=62;active_flags=flags;active_pattern=pattern;active_fault=fault;run_62(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=62 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=63;active_flags=flags;active_pattern=pattern;active_fault=fault;run_63(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=63 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=64;active_flags=flags;active_pattern=pattern;active_fault=fault;run_64(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=64 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=65;active_flags=flags;active_pattern=pattern;active_fault=fault;run_65(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=65 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=66;active_flags=flags;active_pattern=pattern;active_fault=fault;run_66(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=66 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=67;active_flags=flags;active_pattern=pattern;active_fault=fault;run_67(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=67 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=68;active_flags=flags;active_pattern=pattern;active_fault=fault;run_68(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=68 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=69;active_flags=flags;active_pattern=pattern;active_fault=fault;run_69(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=69 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=70;active_flags=flags;active_pattern=pattern;active_fault=fault;run_70(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=70 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=71;active_flags=flags;active_pattern=pattern;active_fault=fault;run_71(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=71 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=72;active_flags=flags;active_pattern=pattern;active_fault=fault;run_72(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=72 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=73;active_flags=flags;active_pattern=pattern;active_fault=fault;run_73(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=73 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rsp.ptr;
old+=state.native_stack_base;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
want-=state.native_stack_base;
expected.rsp.ptr=(void *)(unsigned long)want;expected.rsp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=74;active_flags=flags;active_pattern=pattern;active_fault=fault;run_74(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=74 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=75;active_flags=flags;active_pattern=pattern;active_fault=fault;run_75(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=75 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=76;active_flags=flags;active_pattern=pattern;active_fault=fault;run_76(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=76 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=77;active_flags=flags;active_pattern=pattern;active_fault=fault;run_77(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=77 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=78;active_flags=flags;active_pattern=pattern;active_fault=fault;run_78(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=78 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=79;active_flags=flags;active_pattern=pattern;active_fault=fault;run_79(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=79 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=80;active_flags=flags;active_pattern=pattern;active_fault=fault;run_80(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=80 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=81;active_flags=flags;active_pattern=pattern;active_fault=fault;run_81(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=81 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=82;active_flags=flags;active_pattern=pattern;active_fault=fault;run_82(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=82 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=83;active_flags=flags;active_pattern=pattern;active_fault=fault;run_83(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=83 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=84;active_flags=flags;active_pattern=pattern;active_fault=fault;run_84(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=84 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=85;active_flags=flags;active_pattern=pattern;active_fault=fault;run_85(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=85 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=86;active_flags=flags;active_pattern=pattern;active_fault=fault;run_86(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=86 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbp.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=87;active_flags=flags;active_pattern=pattern;active_fault=fault;run_87(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=87 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rbp.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=88;active_flags=flags;active_pattern=pattern;active_fault=fault;run_88(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=88 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rbp.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rbp.ptr=(void *)(unsigned long)want;expected.rbp_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=89;active_flags=flags;active_pattern=pattern;active_fault=fault;run_89(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=89 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=90;active_flags=flags;active_pattern=pattern;active_fault=fault;run_90(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=90 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=91;active_flags=flags;active_pattern=pattern;active_fault=fault;run_91(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=91 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=92;active_flags=flags;active_pattern=pattern;active_fault=fault;run_92(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=92 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=93;active_flags=flags;active_pattern=pattern;active_fault=fault;run_93(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=93 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=94;active_flags=flags;active_pattern=pattern;active_fault=fault;run_94(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=94 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=95;active_flags=flags;active_pattern=pattern;active_fault=fault;run_95(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=95 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=96;active_flags=flags;active_pattern=pattern;active_fault=fault;run_96(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=96 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=97;active_flags=flags;active_pattern=pattern;active_fault=fault;run_97(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=97 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=98;active_flags=flags;active_pattern=pattern;active_fault=fault;run_98(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=98 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=99;active_flags=flags;active_pattern=pattern;active_fault=fault;run_99(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=99 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=100;active_flags=flags;active_pattern=pattern;active_fault=fault;run_100(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=100 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=101;active_flags=flags;active_pattern=pattern;active_fault=fault;run_101(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=101 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rsi.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=102;active_flags=flags;active_pattern=pattern;active_fault=fault;run_102(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=102 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rsi.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=103;active_flags=flags;active_pattern=pattern;active_fault=fault;run_103(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=103 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rsi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rsi.ptr=(void *)(unsigned long)want;expected.rsi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=104;active_flags=flags;active_pattern=pattern;active_fault=fault;run_104(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=104 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=105;active_flags=flags;active_pattern=pattern;active_fault=fault;run_105(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=105 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=106;active_flags=flags;active_pattern=pattern;active_fault=fault;run_106(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=106 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=107;active_flags=flags;active_pattern=pattern;active_fault=fault;run_107(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=107 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=108;active_flags=flags;active_pattern=pattern;active_fault=fault;run_108(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=108 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=109;active_flags=flags;active_pattern=pattern;active_fault=fault;run_109(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=109 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=110;active_flags=flags;active_pattern=pattern;active_fault=fault;run_110(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=110 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=111;active_flags=flags;active_pattern=pattern;active_fault=fault;run_111(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=111 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=112;active_flags=flags;active_pattern=pattern;active_fault=fault;run_112(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=112 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=113;active_flags=flags;active_pattern=pattern;active_fault=fault;run_113(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=113 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=114;active_flags=flags;active_pattern=pattern;active_fault=fault;run_114(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=114 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=115;active_flags=flags;active_pattern=pattern;active_fault=fault;run_115(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=115 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=116;active_flags=flags;active_pattern=pattern;active_fault=fault;run_116(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=116 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdi.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=117;active_flags=flags;active_pattern=pattern;active_fault=fault;run_117(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=117 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.rdi.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=118;active_flags=flags;active_pattern=pattern;active_fault=fault;run_118(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=118 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.rdi.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.rdi.ptr=(void *)(unsigned long)want;expected.rdi_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=119;active_flags=flags;active_pattern=pattern;active_fault=fault;run_119(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=119 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=120;active_flags=flags;active_pattern=pattern;active_fault=fault;run_120(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=120 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=121;active_flags=flags;active_pattern=pattern;active_fault=fault;run_121(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=121 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r8.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=122;active_flags=flags;active_pattern=pattern;active_fault=fault;run_122(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=122 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r8.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=123;active_flags=flags;active_pattern=pattern;active_fault=fault;run_123(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=123 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=124;active_flags=flags;active_pattern=pattern;active_fault=fault;run_124(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=124 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=125;active_flags=flags;active_pattern=pattern;active_fault=fault;run_125(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=125 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=126;active_flags=flags;active_pattern=pattern;active_fault=fault;run_126(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=126 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=127;active_flags=flags;active_pattern=pattern;active_fault=fault;run_127(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=127 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=128;active_flags=flags;active_pattern=pattern;active_fault=fault;run_128(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=128 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=129;active_flags=flags;active_pattern=pattern;active_fault=fault;run_129(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=129 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=130;active_flags=flags;active_pattern=pattern;active_fault=fault;run_130(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=130 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=131;active_flags=flags;active_pattern=pattern;active_fault=fault;run_131(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=131 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r8.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=132;active_flags=flags;active_pattern=pattern;active_fault=fault;run_132(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=132 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r8.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=133;active_flags=flags;active_pattern=pattern;active_fault=fault;run_133(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=133 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r8.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r8.ptr=(void *)(unsigned long)want;expected.r8_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=134;active_flags=flags;active_pattern=pattern;active_fault=fault;run_134(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=134 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=135;active_flags=flags;active_pattern=pattern;active_fault=fault;run_135(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=135 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=136;active_flags=flags;active_pattern=pattern;active_fault=fault;run_136(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=136 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r9.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=137;active_flags=flags;active_pattern=pattern;active_fault=fault;run_137(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=137 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r9.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=138;active_flags=flags;active_pattern=pattern;active_fault=fault;run_138(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=138 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=139;active_flags=flags;active_pattern=pattern;active_fault=fault;run_139(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=139 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=140;active_flags=flags;active_pattern=pattern;active_fault=fault;run_140(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=140 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=141;active_flags=flags;active_pattern=pattern;active_fault=fault;run_141(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=141 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=142;active_flags=flags;active_pattern=pattern;active_fault=fault;run_142(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=142 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=143;active_flags=flags;active_pattern=pattern;active_fault=fault;run_143(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=143 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=144;active_flags=flags;active_pattern=pattern;active_fault=fault;run_144(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=144 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=145;active_flags=flags;active_pattern=pattern;active_fault=fault;run_145(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=145 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=146;active_flags=flags;active_pattern=pattern;active_fault=fault;run_146(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=146 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r9.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=147;active_flags=flags;active_pattern=pattern;active_fault=fault;run_147(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=147 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r9.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=148;active_flags=flags;active_pattern=pattern;active_fault=fault;run_148(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=148 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r9.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r9.ptr=(void *)(unsigned long)want;expected.r9_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=149;active_flags=flags;active_pattern=pattern;active_fault=fault;run_149(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=149 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=150;active_flags=flags;active_pattern=pattern;active_fault=fault;run_150(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=150 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=151;active_flags=flags;active_pattern=pattern;active_fault=fault;run_151(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=151 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r10.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=152;active_flags=flags;active_pattern=pattern;active_fault=fault;run_152(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=152 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r10.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=153;active_flags=flags;active_pattern=pattern;active_fault=fault;run_153(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=153 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=154;active_flags=flags;active_pattern=pattern;active_fault=fault;run_154(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=154 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=155;active_flags=flags;active_pattern=pattern;active_fault=fault;run_155(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=155 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=156;active_flags=flags;active_pattern=pattern;active_fault=fault;run_156(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=156 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=157;active_flags=flags;active_pattern=pattern;active_fault=fault;run_157(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=157 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=158;active_flags=flags;active_pattern=pattern;active_fault=fault;run_158(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=158 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=159;active_flags=flags;active_pattern=pattern;active_fault=fault;run_159(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=159 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=160;active_flags=flags;active_pattern=pattern;active_fault=fault;run_160(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=160 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=161;active_flags=flags;active_pattern=pattern;active_fault=fault;run_161(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=161 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r10.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=162;active_flags=flags;active_pattern=pattern;active_fault=fault;run_162(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=162 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r10.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=163;active_flags=flags;active_pattern=pattern;active_fault=fault;run_163(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=163 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r10.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r10.ptr=(void *)(unsigned long)want;expected.r10_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=164;active_flags=flags;active_pattern=pattern;active_fault=fault;run_164(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=164 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=165;active_flags=flags;active_pattern=pattern;active_fault=fault;run_165(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=165 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=166;active_flags=flags;active_pattern=pattern;active_fault=fault;run_166(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=166 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r11.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=167;active_flags=flags;active_pattern=pattern;active_fault=fault;run_167(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=167 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r11.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=168;active_flags=flags;active_pattern=pattern;active_fault=fault;run_168(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=168 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=169;active_flags=flags;active_pattern=pattern;active_fault=fault;run_169(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=169 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=170;active_flags=flags;active_pattern=pattern;active_fault=fault;run_170(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=170 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=171;active_flags=flags;active_pattern=pattern;active_fault=fault;run_171(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=171 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=172;active_flags=flags;active_pattern=pattern;active_fault=fault;run_172(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=172 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=173;active_flags=flags;active_pattern=pattern;active_fault=fault;run_173(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=173 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=174;active_flags=flags;active_pattern=pattern;active_fault=fault;run_174(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=174 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=175;active_flags=flags;active_pattern=pattern;active_fault=fault;run_175(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=175 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=176;active_flags=flags;active_pattern=pattern;active_fault=fault;run_176(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=176 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r11.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=177;active_flags=flags;active_pattern=pattern;active_fault=fault;run_177(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=177 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r11.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=178;active_flags=flags;active_pattern=pattern;active_fault=fault;run_178(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=178 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r11.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r11.ptr=(void *)(unsigned long)want;expected.r11_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=179;active_flags=flags;active_pattern=pattern;active_fault=fault;run_179(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=179 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=180;active_flags=flags;active_pattern=pattern;active_fault=fault;run_180(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=180 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=181;active_flags=flags;active_pattern=pattern;active_fault=fault;run_181(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=181 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r12.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=182;active_flags=flags;active_pattern=pattern;active_fault=fault;run_182(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=182 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r12.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=183;active_flags=flags;active_pattern=pattern;active_fault=fault;run_183(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=183 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=184;active_flags=flags;active_pattern=pattern;active_fault=fault;run_184(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=184 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=185;active_flags=flags;active_pattern=pattern;active_fault=fault;run_185(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=185 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=186;active_flags=flags;active_pattern=pattern;active_fault=fault;run_186(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=186 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=187;active_flags=flags;active_pattern=pattern;active_fault=fault;run_187(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=187 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=188;active_flags=flags;active_pattern=pattern;active_fault=fault;run_188(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=188 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=189;active_flags=flags;active_pattern=pattern;active_fault=fault;run_189(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=189 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=190;active_flags=flags;active_pattern=pattern;active_fault=fault;run_190(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=190 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=191;active_flags=flags;active_pattern=pattern;active_fault=fault;run_191(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=191 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r12.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=192;active_flags=flags;active_pattern=pattern;active_fault=fault;run_192(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=192 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r12.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=193;active_flags=flags;active_pattern=pattern;active_fault=fault;run_193(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=193 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r12.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r12.ptr=(void *)(unsigned long)want;expected.r12_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=194;active_flags=flags;active_pattern=pattern;active_fault=fault;run_194(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=194 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=195;active_flags=flags;active_pattern=pattern;active_fault=fault;run_195(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=195 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=196;active_flags=flags;active_pattern=pattern;active_fault=fault;run_196(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=196 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r13.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=197;active_flags=flags;active_pattern=pattern;active_fault=fault;run_197(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=197 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r13.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=198;active_flags=flags;active_pattern=pattern;active_fault=fault;run_198(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=198 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=199;active_flags=flags;active_pattern=pattern;active_fault=fault;run_199(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=199 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=200;active_flags=flags;active_pattern=pattern;active_fault=fault;run_200(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=200 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=201;active_flags=flags;active_pattern=pattern;active_fault=fault;run_201(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=201 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=202;active_flags=flags;active_pattern=pattern;active_fault=fault;run_202(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=202 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=203;active_flags=flags;active_pattern=pattern;active_fault=fault;run_203(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=203 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=204;active_flags=flags;active_pattern=pattern;active_fault=fault;run_204(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=204 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=205;active_flags=flags;active_pattern=pattern;active_fault=fault;run_205(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=205 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=206;active_flags=flags;active_pattern=pattern;active_fault=fault;run_206(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=206 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r13.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=207;active_flags=flags;active_pattern=pattern;active_fault=fault;run_207(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=207 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r13.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=208;active_flags=flags;active_pattern=pattern;active_fault=fault;run_208(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=208 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r13.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r13.ptr=(void *)(unsigned long)want;expected.r13_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=209;active_flags=flags;active_pattern=pattern;active_fault=fault;run_209(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=209 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=210;active_flags=flags;active_pattern=pattern;active_fault=fault;run_210(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=210 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=211;active_flags=flags;active_pattern=pattern;active_fault=fault;run_211(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=211 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r14.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=212;active_flags=flags;active_pattern=pattern;active_fault=fault;run_212(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=212 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r14.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=213;active_flags=flags;active_pattern=pattern;active_fault=fault;run_213(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=213 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=214;active_flags=flags;active_pattern=pattern;active_fault=fault;run_214(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=214 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=215;active_flags=flags;active_pattern=pattern;active_fault=fault;run_215(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=215 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=216;active_flags=flags;active_pattern=pattern;active_fault=fault;run_216(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=216 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=217;active_flags=flags;active_pattern=pattern;active_fault=fault;run_217(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=217 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=218;active_flags=flags;active_pattern=pattern;active_fault=fault;run_218(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=218 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=219;active_flags=flags;active_pattern=pattern;active_fault=fault;run_219(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=219 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=220;active_flags=flags;active_pattern=pattern;active_fault=fault;run_220(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=220 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=221;active_flags=flags;active_pattern=pattern;active_fault=fault;run_221(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=221 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r14.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=222;active_flags=flags;active_pattern=pattern;active_fault=fault;run_222(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=222 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r14.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=223;active_flags=flags;active_pattern=pattern;active_fault=fault;run_223(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=223 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r14.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r14.ptr=(void *)(unsigned long)want;expected.r14_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=224;active_flags=flags;active_pattern=pattern;active_fault=fault;run_224(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=224 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-64));
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=225;active_flags=flags;active_pattern=pattern;active_fault=fault;run_225(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=225 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=226;active_flags=flags;active_pattern=pattern;active_fault=fault;run_226(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=226 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r15.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=227;active_flags=flags;active_pattern=pattern;active_fault=fault;run_227(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=227 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r15.ptr;
__u64 mask=(~0ULL>>(64-8))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=228;active_flags=flags;active_pattern=pattern;active_fault=fault;run_228(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=228 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=229;active_flags=flags;active_pattern=pattern;active_fault=fault;run_229(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=229 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=230;active_flags=flags;active_pattern=pattern;active_fault=fault;run_230(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=230 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=231;active_flags=flags;active_pattern=pattern;active_fault=fault;run_231(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=231 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=232;active_flags=flags;active_pattern=pattern;active_fault=fault;run_232(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=232 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=233;active_flags=flags;active_pattern=pattern;active_fault=fault;run_233(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=233 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=234;active_flags=flags;active_pattern=pattern;active_fault=fault;run_234(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=234 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=235;active_flags=flags;active_pattern=pattern;active_fault=fault;run_235(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=235 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-16));
if(raw & (1ULL<<(16-1)))raw|=~0ULL<<16;
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-32)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=236;active_flags=flags;active_pattern=pattern;active_fault=fault;run_236(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=236 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.r15.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=237;active_flags=flags;active_pattern=pattern;active_fault=fault;run_237(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=237 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
if(raw & (1ULL<<(8-1)))raw|=~0ULL<<8;
__u64 old=(unsigned long)state.r15.ptr;
__u64 mask=(~0ULL>>(64-16))<<0;__u64 want=fault?0:((old&~mask)|((raw<<0)&mask));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=238;active_flags=flags;active_pattern=pattern;active_fault=fault;run_238(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=238 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-32));
if(raw & (1ULL<<(32-1)))raw|=~0ULL<<32;
__u64 old=(unsigned long)state.r15.ptr;
__u64 want=fault?0:(raw & (~0ULL>>(64-64)));
expected.r15.ptr=(void *)(unsigned long)want;expected.r15_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=239;active_flags=flags;active_pattern=pattern;active_fault=fault;run_239(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=239 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rax.ptr;
__u64 mask=(~0ULL>>(64-8))<<8;__u64 want=fault?0:((old&~mask)|((raw<<8)&mask));
expected.rax.ptr=(void *)(unsigned long)want;expected.rax_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=240;active_flags=flags;active_pattern=pattern;active_fault=fault;run_240(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=240 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rbx.ptr;
__u64 mask=(~0ULL>>(64-8))<<8;__u64 want=fault?0:((old&~mask)|((raw<<8)&mask));
expected.rbx.ptr=(void *)(unsigned long)want;expected.rbx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=241;active_flags=flags;active_pattern=pattern;active_fault=fault;run_241(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=241 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rcx.ptr;
__u64 mask=(~0ULL>>(64-8))<<8;__u64 want=fault?0:((old&~mask)|((raw<<8)&mask));
expected.rcx.ptr=(void *)(unsigned long)want;expected.rcx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=242;active_flags=flags;active_pattern=pattern;active_fault=fault;run_242(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=242 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
{struct x86_sim_state state={0};__u8 datum[32];memset(datum,0xa5,sizeof datum);memcpy(datum+16,&value,8);__u8 before[32];memcpy(before,datum,32);
state.rax.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*1+0x123456789abcdefULL);state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*2+0x123456789abcdefULL);state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*3+0x123456789abcdefULL);state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*4+0x123456789abcdefULL);state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*5+0x123456789abcdefULL);state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*6+0x123456789abcdefULL);state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*7+0x123456789abcdefULL);state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*8+0x123456789abcdefULL);state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*9+0x123456789abcdefULL);state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*10+0x123456789abcdefULL);state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*11+0x123456789abcdefULL);state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*12+0x123456789abcdefULL);state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*13+0x123456789abcdefULL);state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*14+0x123456789abcdefULL);state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*15+0x123456789abcdefULL);state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(0x9e3779b97f4a7c15ULL*16+0x123456789abcdefULL);state.r15_tag=0x7f;
state.native_stack_base=0x100000000000ULL;state.rdi.ptr=fault?(void *)0x60:datum;state.rdi_tag=X86_SIM_TAG_SCALAR;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=0x123456789;state.xmm0_hi=0xfedcba9876543210ULL;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
__u64 raw=value & (~0ULL>>(64-8));
__u64 old=(unsigned long)state.rdx.ptr;
__u64 mask=(~0ULL>>(64-8))<<8;__u64 want=fault?0:((old&~mask)|((raw<<8)&mask));
expected.rdx.ptr=(void *)(unsigned long)want;expected.rdx_tag=X86_SIM_TAG_SCALAR;
outcome=fault;calls=0;active_variant=243;active_flags=flags;active_pattern=pattern;active_fault=fault;run_243(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,datum,32)){fprintf(stderr,"MOV fault-prefix variant=243 flags=%u pattern=%u fault=%u calls=%u\n",flags,pattern,fault,calls);return 1;}
(void)old;cases++;}
}printf("MOV protected-read success/recovery: %u full-state cases OK\n",cases);return 0;}
