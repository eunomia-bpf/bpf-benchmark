#include <stdio.h>
#include <string.h>
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 128
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
static long output(void*d,unsigned n,const void*s){memcpy(d,s,n);return 0;}
static long comm(void*d,unsigned n){memset(d,0x5a,n);return 0;}
#define bpf_probe_read(D,N,S) output(D,N,S)
#define bpf_probe_read_str(D,N,S) output(D,N,S)
#define bpf_probe_read_user(D,N,S) output(D,N,S)
#define bpf_probe_read_kernel(D,N,S) output(D,N,S)
#define bpf_probe_read_user_str(D,N,S) output(D,N,S)
#define bpf_probe_read_kernel_str(D,N,S) output(D,N,S)
#define bpf_get_current_comm(D,N) comm(D,N)
#define bpf_get_current_task_btf() ((void*)0x10000)
unsigned long native_lab_entry_input(unsigned int k){return 0;}
static unsigned cases;
static int run(unsigned which,unsigned lane,unsigned len,unsigned long long seed){
 X86_SIM_ENTRY_RAW((void*)0);__x86_rsp.ptr=(void*)-128;unsigned char expected[128]={},src[32];memset(src,0x5a,sizeof(src));for(unsigned i=0;i<128;i++)__x86_stack_mem.b[i]=0;
 X86_SIM_L_STACK_WRITE(-64,8,seed);memcpy(expected+64,&seed,8);X86_SIM_L_STACK_WRITE(-8,8,seed^0xa5a5a5a5a5a5a5a5ULL);unsigned long long kept=seed^0xa5a5a5a5a5a5a5a5ULL;memcpy(expected+120,&kept,8);
 __x86_rdi.ptr=X86_SIM_L_STACK_PTR(-64+(long)lane);__x86_rdi_tag=X86_SIM_TAG_STACK;__x86_rsi.ptr=(void*)(unsigned long)len;__x86_rdx.ptr=src;__x86_rdx_tag=X86_SIM_TAG_MAP_VALUE;
 switch(which){case 0:X86_SIM_BPF_CALL_bpf_probe_read();break;case 1:X86_SIM_BPF_CALL_bpf_probe_read_str();break;case 2:X86_SIM_BPF_CALL_bpf_probe_read_user();break;case 3:X86_SIM_BPF_CALL_bpf_probe_read_kernel();break;case 4:X86_SIM_BPF_CALL_bpf_probe_read_user_str();break;case 5:X86_SIM_BPF_CALL_bpf_probe_read_kernel_str();break;case 6:X86_SIM_BPF_CALL_bpf_get_current_comm();break;case 7:X86_SIM_BPF_CALL_bpf_get_current_task_btf();break;}
 if(which<7)memset(expected+64+lane,0x5a,len);unsigned long long want;memcpy(&want,expected+64,8);unsigned long long got=X86_SIM_L_STACK_READ(-64,8),preserved=X86_SIM_L_STACK_READ(-8,8);if(got!=want||preserved!=kept||memcmp((const void*)__x86_stack_mem.b,expected,128)){printf("mismatch helper%u lane%u len%u got%llx want%llx kept%llx expected%llx\n",which,lane,len,got,want,preserved,kept);return 1;}cases++;return 0;
}
int main(){unsigned ns[]={0,1,2,3,4,7,8,9,16,17};for(unsigned h=0;h<8;h++)for(unsigned l=0;l<8;l++)for(unsigned n=0;n<10;n++)for(unsigned v=0;v<2;v++)if(run(h,l,ns[n],v?0x1122334455667788ULL:0))return 1;printf("helper output range/caller fullword/partial/raw-memory PASS %u cases\n",cases);}
