ROOT := /workspaces/repository
G := /var/tmp/kprog-tmp/C/helper-output-range
.PHONY: check
check:
	unshare --mount --propagation private python3 $(G)/mount.py python3 $(G)/host.py
