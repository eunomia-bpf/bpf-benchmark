from pathlib import Path
import json,subprocess,tarfile,hashlib,sys,traceback,resource
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/helper-output-range/full-bcc-compile'
def status(**d):(G/'status.json').write_text(json.dumps(d,indent=2)+'\n')
try:
 status(state='compiling_complete_bcc_entry_sets')
 with(G/'compile.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'all'],stdout=f,stderr=subprocess.STDOUT)
 (G/'compile.exit').write_text(str(p.returncode)+'\n');p.check_returncode();rows=json.loads((G/'compiled.json').read_text());totals={label:dict(entries=sum(r['label']==label for r in rows),compiled=sum(r['label']==label and r['status']=='compiled'for r in rows),diagnostic=sum(r['label']==label and r['status']=='diagnostic'for r in rows))for label in ['control','frontend']}
 O.mkdir(parents=True,exist_ok=True);result=dict(totals=totals,rows=rows,model_sha256=hashlib.sha256((G/'source/kprog/x86/x86_sim_local_bpf.h').read_bytes()).hexdigest(),native_execution=0,profile='actual whole-app captured metadata with every original entry; private generic helper candidate');(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 (O/'README.md').write_text('# Full original BCC entry generation with helper output-range representation\n\nThis finite compiler observation includes every25entry of each complete8-object canonicalO3 and existing frozen-config frontend producer. The generation metadata comes from the actual complete BCC runtime archive, preserving original native inputs and entry identities. The private candidate model changes helper-output ghost invalidation/caller-frame representation; native instructions, helper calls and existing lifetime/exit predicates retain their definitions.\n\nActual complete totals '+repr(totals)+'. generated.tar.gz retains every generated C/B/native/link/compiler artifact; component.tar.gz retains exact model source, original service inputs, both complete native producers, commands and diagnostics. Canonical production model retains its published parent. This is generation/compilation evidence; current coherent whole-application verifier/startup/work observations retain their own receipts. Native executions0; runtime admission additions0.\n')
 for name,names in [('generated.tar.gz',['generated']),('component.tar.gz',['source','inputs','actual-inputs.json','control','frontend','Makefile','mount.py','compile.py','controller.py','compile.log','compile.exit','compiled.json'])]:
  with tarfile.open(O/name,'w:gz')as t:
   for n in names:t.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(x.relative_to(R))for x in O.iterdir()if x.is_file()],'Compile every original BCC entry through helper output-range candidate',G/'publication.json')
 with tarfile.open(O/'component.tar.gz')as t:assert hashlib.sha256(t.extractfile('source/kprog/x86/x86_sim_local_bpf.h').read()).hexdigest()==result['model_sha256']
 status(state='finished',commit=commit,totals=totals)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR V/A/R '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' full helper-range BCC actual-metadata compiler cohort '+repr(totals)+'. All25entry metadata/full8native objects per producer retained; original current-control and existing frontend P source. Private candidate model unchanged; actual same-copy corpus/verifier/work remains separate. Canonical source parent retained, new predicates0.\n')
except BaseException as e:status(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
