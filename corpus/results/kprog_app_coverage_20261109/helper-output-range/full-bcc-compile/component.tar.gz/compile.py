from pathlib import Path
import json,sys,subprocess,tarfile,io,hashlib,traceback,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
inputs=json.loads((G/'actual-inputs.json').read_text());rows=[]
# Read original actual runtime metadata from its immutable published archive.
for archive in sorted({item['archive']for item in inputs}):
 with tarfile.open(archive)as t:
  for item in inputs:
   if item['archive']!=archive:continue
   with tarfile.open(fileobj=io.BytesIO(t.extractfile(item['member']).read()))as q:
    p=G/'inputs'/str(item['request_id']);p.mkdir(parents=True,exist_ok=True)
    for n in ['kernel.native.o','kernel.entry','generation.metadata.json','kernel.facts.json','kernel.metadata.json']:(p/n).write_bytes(q.extractfile('request/'+n).read())
for label in ['control','frontend']:
 for item in inputs:
  obj=G/label/item['object'];destination=G/'generated'/label/str(item['request_id']);destination.parent.mkdir(parents=True,exist_ok=True);metadata=json.loads((G/'inputs'/str(item['request_id'])/'generation.metadata.json').read_text());row=dict(label=label,**item,native_sha256=hashlib.sha256(obj.read_bytes()).hexdigest())
  try:row['result']=specialize(obj.read_bytes(),item['entry'],metadata,destination,Path('/var/tmp/kprog-tmp/C/coherent-six-app-runtime/runtime/native-link'));row['status']='compiled'
  except BaseException as e:row.update(status='diagnostic',error=str(e),traceback=traceback.format_exc())
  rows.append(row);(G/'compiled.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({k:row.get(k)for k in ['label','request_id','entry','status','error']}),flush=True)
