import resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
from pathlib import Path
import subprocess,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');rows=[]
for cc in ['gcc','clang-18']:
 cmd=[cc,'-O2','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu',str(G/'host.c'),'-o',str(G/cc)]
 if cc=='clang-18':cmd+=['-fno-sanitize-link-runtime','-lubsan']
 with(G/(cc+'.build.log')).open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(compiler=cc,command=cmd,compile_exit=p.returncode)
 if not p.returncode:
  with(G/(cc+'.log')).open('w')as f:q=subprocess.run([str(G/cc)],stdout=f,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(G/'host-results.json').write_text(json.dumps(rows,indent=2)+'\n')

if any(r["compile_exit"] or r.get("run_exit",1) for r in rows):raise SystemExit(1)
