from pathlib import Path
import json,sys,subprocess,hashlib,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');S=Path('/var/tmp/kprog-tmp/C/helper-output-range-full-bcc');sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
rows=[]
for item in json.loads((G/'actual-inputs.json').read_text()):
 obj=S/'control'/item['object'];destination=G/'generated'/str(item['request_id']);destination.parent.mkdir(parents=True,exist_ok=True);metadata=json.loads((S/'inputs'/str(item['request_id'])/'generation.metadata.json').read_text());row=dict(item,native_sha256=hashlib.sha256(obj.read_bytes()).hexdigest())
 try:row['result']=specialize(obj.read_bytes(),item['entry'],metadata,destination,Path('/var/tmp/kprog-tmp/C/tail-helper-reaching-frame/native-link'));row['status']='compiled'
 except BaseException as e:row.update(status='diagnostic',error=str(e))
 rows.append(row);(G/'compiled.json').write_text(json.dumps(rows,indent=2)+'\n');print(item['entry'],row['status'],row.get('error'),flush=True)
