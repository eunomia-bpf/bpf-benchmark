from pathlib import Path
import subprocess,json,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');rows=[]
for cc in ['gcc','clang-18']:
 for label,src in [('idiv',G/'host.c'),('original-div',R/'kprog/formal/oracles/test_x86_div_route_host.c')]:
  cmd=[cc,'-O2','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-I'+str(R/'kprog/formal'),str(src),'-o',str(G/(cc+'-'+label))]
  if cc=='clang-18':cmd+=['-fno-sanitize-link-runtime','-lubsan']
  with(G/(cc+'-'+label+'.build.log')).open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  row=dict(compiler=cc,label=label,command=cmd,compile_exit=p.returncode)
  if not p.returncode:
   with(G/(cc+'-'+label+'.log')).open('w')as f:q=subprocess.run([str(G/(cc+'-'+label))],stdout=f,stderr=subprocess.STDOUT)
   row['run_exit']=q.returncode
  rows.append(row);(G/'host-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['compiler'],label,row['compile_exit'],row.get('run_exit'),flush=True)
if any(r['compile_exit'] or r.get('run_exit',1)for r in rows):raise SystemExit(1)
