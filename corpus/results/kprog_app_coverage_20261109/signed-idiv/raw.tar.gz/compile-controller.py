from pathlib import Path
import subprocess,json
G=Path(__file__).resolve().parent
with(G/'compile-check.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'compile'],stdout=f,stderr=subprocess.STDOUT)
(G/'compile-check.exit').write_text(str(p.returncode)+'\n')
