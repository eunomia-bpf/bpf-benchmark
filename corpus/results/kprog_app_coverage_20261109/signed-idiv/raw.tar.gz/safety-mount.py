from pathlib import Path
import subprocess,os,sys
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');V=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/signed-idiv')
subprocess.run(['mount','--bind',str(G),str(V)],check=True)
for p in sorted((G/'safety-source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'safety-source'))],check=True)
os.execvp(sys.argv[1],sys.argv[1:])
