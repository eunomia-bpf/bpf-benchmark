from pathlib import Path
import subprocess,sys,json,select,os,tarfile,hashlib,traceback,resource
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/signed-idiv'
def state(**d):(G/'safety-status.json').write_text(json.dumps(d,indent=2)+'\n')
try:
 waits=[int((Path('/var/tmp/kprog-tmp/C/bcc-native-profile-runtime')/'controller.pid').read_text()),int((G/'compile-controller.pid').read_text())]
 state(state='queued_after_application_and_compiler',pids=waits)
 for pid in waits:
  try:fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
  except ProcessLookupError:pass
 state(state='original38')
 command=['unshare','--mount','--propagation','private','python3',str(G/'safety-mount.py'),'make','-f',str(G/'safety-control/Makefile'),'safety'];(G/'safety-command.json').write_text(json.dumps(command,indent=2)+'\n')
 with(G/'original38.log').open('w')as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 (G/'original38.exit').write_text(str(p.returncode)+'\n')
 rows=json.loads((G/'safety-control/safety/outcomes.json').read_text())if(G/'safety-control/safety/outcomes.json').exists()else[]
 safety=dict(make_exit=p.returncode,cases=len(rows),stages={s:sum(x['stage']==s for x in rows)for s in sorted({x['stage']for x in rows})},negative_native_executions=0);(G/'original38.json').write_text(json.dumps(safety,indent=2)+'\n')
 compiled=json.loads((G/'compiled.json').read_text());host=json.loads((G/'host-results.json').read_text());r=dict(inputs=json.loads((G/'inputs.json').read_text()),host=host,host_banners={n:(G/(n+'.log')).read_text().strip()for n in ['gcc-idiv','clang-18-idiv','gcc-original-div','clang-18-original-div']},compiler=dict(entries=len(compiled),compiled=sum(x['status']=='compiled'for x in compiled),diagnostics=[dict(entry=x['entry'],error=x.get('error'))for x in compiled if x['status']!='compiled']),original38=safety,source_sha256={str(p.relative_to(G/'source')):hashlib.sha256(p.read_bytes()).hexdigest()for p in(G/'source').rglob('*')if p.is_file()})
 O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(r,indent=2)+'\n');(O/'candidate.patch').write_bytes((G/'candidate.patch').read_bytes());(O/'README.md').write_text('# Approved signed IDIV generic implementation and replay\n\nThe coordinator approved signed IDIV zero-divisor and quotient-overflow architectural faults on November9. The candidate keeps the existing DIV opcode and uses a signed AUX mode. Unsigned magnitude arithmetic represents the complete high:low signed dividend at8/16/32/64bits, including negative divisors, minimum values and full128bit dividend. Existing division faults occur before register writeback; results retain native partial-register/zero-extension rules, quotient truncation toward zero and dividend-signed remainder. Successful undefined condition flags use the existing fresh input operation. Register/high-byte/memory/RIPdata forms reuse existing decode, protected-read and relocation mechanisms.\n\nGCC and Clang18 UBSan compare the actual simulator body with hardware IDIV for18048inputs per compiler, including9380architectural faults. Every register value/tag and fault-preserved state is compared. Existing unsigned DIV110885cases per compiler retains its original oracle. Complete25canonical BCC entries retain actual service metadata and native P; generated source/B/commands retain every observed compiler outcome. Original38 keeps its published fixture bytes and negative load-only protocol. summary.json records actual host, compiler and guest outcomes. Canonical production source retains its parent through this candidate receipt; source promotion follows source/actual replay review. The kernel after-verification path retains its emitted copy and relocations.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for n in ['inputs.json','parent','source','candidate.patch','host.c','host.py','host-results.json','Makefile','mount.py','controller.py','controller.log','status.json','compile.py','compile-controller.py','compile-check.log','compile-check.exit','actual-inputs.json','generated','compiled.json','safety-source','safety-control','safety-mount.py','safety-controller.py','safety-command.json','original38.log','original38.exit','original38.json','runtime']:
   if(G/n).exists():t.add(G/n,arcname=n)
  for p in G.glob('*.log*'):t.add(p,arcname=p.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 h=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure approved signed IDIV arithmetic and complete original replay',G/'publication.json');state(state='finished',commit=h,compiler=r['compiler'],original38=safety)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR V/A/R '+datetime.now(timezone.utc).isoformat()+': PUSHED '+h+' approved signedIDIV generic candidate host/fullcanonicalBCC/original38 receipt. Hardware '+repr(r['host_banners'])+'; compiler '+repr(r['compiler'])+'; original38 '+repr(safety)+'. New signed AUX mode stays inside existing DIV opcode/fault arm, allwidth/fullhigh:low semantics and fresh undefinedflags. Production parent retained pending exact source/replay review. V owns universal signed-mode extension.\n')
except BaseException as e:state(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
