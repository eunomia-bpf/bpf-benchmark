#include <stdio.h>
#include <signal.h>
#include <setjmp.h>
#include <string.h>
#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
unsigned long native_lab_entry_input(unsigned int key) { return 0; }
static sigjmp_buf hardware_fault;
static jmp_buf model_fault;
static unsigned long long values[16];
static unsigned char tags[16];
static unsigned long cases, faults;
static void fpe(int sig) { siglongjmp(hardware_fault, 1); }
static int hardware(unsigned w,unsigned long long a,unsigned long long d,unsigned long long divisor,unsigned long long *qa,unsigned long long *rd) {
 if(sigsetjmp(hardware_fault,1))return 1;
 switch(w) {
 case 1:__asm__ volatile("idivb %b1":"+a"(a):"q"(divisor):"cc");break;
 case 2:__asm__ volatile("idivw %w2":"+a"(a),"+d"(d):"r"(divisor):"cc");break;
 case 4:__asm__ volatile("idivl %k2":"+a"(a),"+d"(d):"r"(divisor):"cc");break;
 case 8:__asm__ volatile("idivq %2":"+a"(a),"+d"(d):"r"(divisor):"cc");break;
 }
 *qa=a;*rd=d;return 0;
}
#define SNAPSHOT() do {for(unsigned k=0;k<16;k++){values[k]=(__u64)(long)X86_SIM_L_REG_VALUE(k);tags[k]=X86_SIM_L_REG_TAG(k);}}while(0)
#undef X86_SIM_L_DIVIDE_FAULT
#define X86_SIM_L_DIVIDE_FAULT() do {SNAPSHOT();longjmp(model_fault,1);}while(0)
static int model(unsigned w,unsigned long long a,unsigned long long d,unsigned long long divisor) {
 X86_SIM_ENTRY_RAW((void*)0);
 for(unsigned k=0;k<16;k++)X86_SIM_L_WRITE_REG_PTR_TAG(k,(void*)(long)(0x1122334455660000ULL+k),X86_SIM_TAG_MAP_VALUE);
 __x86_rax.ptr=(void*)(long)a;__x86_rdx.ptr=(void*)(long)d;__x86_rbx.ptr=(void*)(long)divisor;
 if(setjmp(model_fault))return 1;
 switch(w) {
 case 1:X86_SIM_RUN_OP(X86_OP_DIV,0,X86_RBX,X86_WIDTH_8,X86_DIV_AUX_SIGNED,0ULL);break;
 case 2:X86_SIM_RUN_OP(X86_OP_DIV,0,X86_RBX,X86_WIDTH_16,X86_DIV_AUX_SIGNED,0ULL);break;
 case 4:X86_SIM_RUN_OP(X86_OP_DIV,0,X86_RBX,X86_WIDTH_32,X86_DIV_AUX_SIGNED,0ULL);break;
 case 8:X86_SIM_RUN_OP(X86_OP_DIV,0,X86_RBX,X86_WIDTH_64,X86_DIV_AUX_SIGNED,0ULL);break;
 }
 SNAPSHOT();return 0;
}
static int check(unsigned w,unsigned long long a,unsigned long long d,unsigned long long divisor) {
 unsigned long long q=0,r=0;int hf=hardware(w,a,d,divisor,&q,&r),mf=model(w,a,d,divisor);
 if(hf!=mf){printf("fault mismatch width%u a%llx d%llx divisor%llx hardware%d model%d\n",w,a,d,divisor,hf,mf);return 1;}
 for(unsigned k=0;k<16;k++) {
  unsigned long long expected=k==X86_RAX?a:k==X86_RDX?d:k==X86_RBX?divisor:0x1122334455660000ULL+k;
  unsigned char tag=X86_SIM_TAG_MAP_VALUE;
  if(!hf&&k==X86_RAX){expected=q;tag=X86_SIM_TAG_SCALAR;}
  if(!hf&&w!=1&&k==X86_RDX){expected=r;tag=X86_SIM_TAG_SCALAR;}
  if(values[k]!=expected||tags[k]!=tag){printf("state mismatch width%u a%llx d%llx divisor%llx reg%u value%llx expected%llx tag%u expected%u\n",w,a,d,divisor,k,values[k],expected,tags[k],tag);return 1;}
 }
 cases++;faults+=hf;return 0;
}
static unsigned long long next(void){static unsigned long long s=0x1223344556677889ULL;s^=s<<13;s^=s>>7;s^=s<<17;return s;}
int main(void){
 struct sigaction sa={};sa.sa_handler=fpe;sigemptyset(&sa.sa_mask);sigaction(SIGFPE,&sa,0);
 unsigned ws[]={1,2,4,8};
 for(unsigned wi=0;wi<4;wi++) {
  unsigned w=ws[wi],bits=w*8;unsigned long long sign=1ULL<<(bits-1),mask=~0ULL>>(64-bits);
  unsigned long long edge[]={0,1,2,sign-1,sign,sign+1,mask-1,mask};
  for(unsigned i=0;i<8;i++)for(unsigned j=0;j<8;j++)for(unsigned k=0;k<8;k++) {
   unsigned long long a=edge[i],d=edge[j];if(w==1)a=(d<<8)|(a&255);
   if(check(w,a,d,edge[k]))return 1;
  }
  for(unsigned i=0;i<4000;i++){
   unsigned long long a=next(),d=next(),v=next();
   if(i%3==0){d=(a&sign)?mask:0;if(w==1)a=((d&255)<<8)|(a&255);}
   if(check(w,a,d,v))return 1;
  }
 }
 printf("signed IDIV hardware/model full-register-state PASS %lu cases, %lu architectural faults\n",cases,faults);return 0;
}
