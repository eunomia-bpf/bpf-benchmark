#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 72U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 cgroup_map[] __ksym;
extern __u8 filter_cg[] __ksym;
extern __u8 hists[] __ksym;
extern __u8 start[] __ksym;
extern __u8 targ_ms[] __ksym;
extern __u8 targ_per_pidns[] __ksym;
extern __u8 targ_per_process[] __ksym;
extern __u8 targ_per_thread[] __ksym;
extern __u8 targ_tgid[] __ksym;
static const __u8 __x86_rodata_0[120] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(19):.bss\",\"size\":120}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 119: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 119, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       __x86_ro_value = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       __x86_ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \
   __x86_ro_value; })

SEC("fentry/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5:
	/* 0x5: mov    rsi,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9:
	/* 0x9: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_c:
	/* 0xc: call   0 <sched_switch> */
	X86_SIM_X86_CALL(x86_l_19, 0x11ULL);
x86_l_11:
	/* 0x11: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13:
	/* 0x13: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: jmp    37e <handle_switch+0x365> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_37e:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_19 */
x86_l_19:
	/* 0x19: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a:
	/* 0x1a: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c:
	/* 0x1c: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1e:
	/* 0x1e: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1f:
	/* 0x1f: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_23:
	/* 0x23: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_26:
	/* 0x26: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_29:
	/* 0x29: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)filter_cg));
x86_l_30:
	/* 0x30: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33:
	/* 0x33: je     4c <handle_switch+0x33> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x33, 0x4c, x86_l_4c);
x86_l_35:
	/* 0x35: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cgroup_map));
x86_l_3c:
	/* 0x3c: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3e:
	/* 0x3e: call   43 <handle_switch+0x2a> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_current_task_under_cgroup);
x86_l_43:
	/* 0x43: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_46:
	/* 0x46: je     2fc <handle_switch+0x2e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x46, 0x2fc, x86_l_2fc);
x86_l_4c:
	/* 0x4c: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_51:
	/* 0x51: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_56:
	/* 0x56: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_59:
	/* 0x59: call   5e <handle_switch+0x45> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_5e:
	/* 0x5e: cmp    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_63:
	/* 0x63: jne    d8 <handle_switch+0xbf> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x63, 0xd8, x86_l_d8);
x86_l_65:
	/* 0x65: lea    rdx,[r14+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_6c:
	/* 0x6c: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_71:
	/* 0x71: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_76:
	/* 0x76: call   7b <handle_switch+0x62> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_7b:
	/* 0x7b: mov    ebp,DWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7f:
	/* 0x7f: add    r14,0xaf0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_ADD, 2800ULL);
x86_l_86:
	/* 0x86: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8b:
	/* 0x8b: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_90:
	/* 0x90: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_93:
	/* 0x93: call   98 <handle_switch+0x7f> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_98:
	/* 0x98: mov    eax,DWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9c:
	/* 0x9c: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a0:
	/* 0xa0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_a2:
	/* 0xa2: je     d8 <handle_switch+0xbf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa2, 0xd8, x86_l_d8);
x86_l_a4:
	/* 0xa4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)targ_tgid));
x86_l_ab:
	/* 0xab: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ae:
	/* 0xae: je     b6 <handle_switch+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xae, 0xb6, x86_l_b6);
x86_l_b0:
	/* 0xb0: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b2:
	/* 0xb2: cmp    eax,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RBP, X86_WIDTH_32);
x86_l_b4:
	/* 0xb4: jne    d8 <handle_switch+0xbf> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb4, 0xd8, x86_l_d8);
x86_l_b6:
	/* 0xb6: call   bb <handle_switch+0xa2> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_bb:
	/* 0xbb: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c0:
	/* 0xc0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_c7:
	/* 0xc7: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_cc:
	/* 0xcc: lea    rdx,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d1:
	/* 0xd1: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d3:
	/* 0xd3: call   d8 <handle_switch+0xbf> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_update_elem);
x86_l_d8:
	/* 0xd8: lea    rdx,[rbx+0xaf0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2800ULL);
x86_l_df:
	/* 0xdf: lea    r14,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e4:
	/* 0xe4: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_e7:
	/* 0xe7: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_ec:
	/* 0xec: call   f1 <handle_switch+0xd8> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_f1:
	/* 0xf1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_f8:
	/* 0xf8: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_fb:
	/* 0xfb: call   100 <handle_switch+0xe7> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_100:
	/* 0x100: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_103:
	/* 0x103: je     2fc <handle_switch+0x2e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x103, 0x2fc, x86_l_2fc);
x86_l_109:
	/* 0x109: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_10c:
	/* 0x10c: call   111 <handle_switch+0xf8> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_111:
	/* 0x111: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_114:
	/* 0x114: sub    r15,QWORD PTR [r14] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R15, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_117:
	/* 0x117: js     2eb <handle_switch+0x2d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x117, 0x2eb, x86_l_2eb);
x86_l_11d:
	/* 0x11d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)targ_per_process));
x86_l_124:
	/* 0x124: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_127:
	/* 0x127: je     13f <handle_switch+0x126> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x127, 0x13f, x86_l_13f);
x86_l_129:
	/* 0x129: lea    rdx,[rbx+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_130:
	/* 0x130: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_133:
	/* 0x133: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_138:
	/* 0x138: call   13d <handle_switch+0x124> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_13d:
	/* 0x13d: jmp    156 <handle_switch+0x13d> */
	X86_SIM_X86_SUB_JMP(0x13d, 0x156, x86_l_156);
x86_l_13f:
	/* 0x13f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)targ_per_thread));
x86_l_146:
	/* 0x146: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_149:
	/* 0x149: je     307 <handle_switch+0x2ee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x149, 0x307, x86_l_307);
x86_l_14f:
	/* 0x14f: mov    eax,DWORD PTR [rsp+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_153:
	/* 0x153: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_156:
	/* 0x156: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)hists));
x86_l_15d:
	/* 0x15d: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_160:
	/* 0x160: call   165 <handle_switch+0x14c> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_165:
	/* 0x165: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_168:
	/* 0x168: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16b:
	/* 0x16b: je     1ff <handle_switch+0x1e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16b, 0x1ff, x86_l_1ff);
x86_l_171:
	/* 0x171: cmp    BYTE PTR [r14+0x68],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_176:
	/* 0x176: je     249 <handle_switch+0x230> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x176, 0x249, x86_l_249);
x86_l_17c:
	/* 0x17c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)targ_ms));
x86_l_183:
	/* 0x183: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_186:
	/* 0x186: je     271 <handle_switch+0x258> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x186, 0x271, x86_l_271);
x86_l_18c:
	/* 0x18c: mov    ecx,0xf4240 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1000000ULL);
x86_l_191:
	/* 0x191: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_194:
	/* 0x194: cqo */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 63) & 1ULL)));
x86_l_196:
	/* 0x196: idiv   rcx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_64, X86_DIV_AUX_SIGNED, 0);
x86_l_199:
	/* 0x199: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_19c:
	/* 0x19c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_19e:
	/* 0x19e: shr    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1a2:
	/* 0x1a2: je     28d <handle_switch+0x274> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a2, 0x28d, x86_l_28d);
x86_l_1a8:
	/* 0x1a8: cmp    edx,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 65536ULL);
x86_l_1ae:
	/* 0x1ae: setae  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_AE);
x86_l_1b1:
	/* 0x1b1: shl    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_1b4:
	/* 0x1b4: shrx   edx,edx,ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RCX, X86_ALU_SHR);
x86_l_1b9:
	/* 0x1b9: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1bb:
	/* 0x1bb: cmp    edx,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 256ULL);
x86_l_1c1:
	/* 0x1c1: setae  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_AE);
x86_l_1c4:
	/* 0x1c4: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1c7:
	/* 0x1c7: shrx   edx,edx,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_1cc:
	/* 0x1cc: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1ce:
	/* 0x1ce: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_1d1:
	/* 0x1d1: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_1d5:
	/* 0x1d5: shl    esi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_1d8:
	/* 0x1d8: shrx   edx,edx,esi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RSI, X86_ALU_SHR);
x86_l_1dd:
	/* 0x1dd: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1df:
	/* 0x1df: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_1e2:
	/* 0x1e2: setae  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_AE);
x86_l_1e6:
	/* 0x1e6: add    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_ADD);
x86_l_1e8:
	/* 0x1e8: shrx   edx,edx,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_1ed:
	/* 0x1ed: shr    edx,1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1ef:
	/* 0x1ef: or     eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_OR);
x86_l_1f1:
	/* 0x1f1: or     eax,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_32, X86_ALU_OR);
x86_l_1f3:
	/* 0x1f3: or     eax,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_OR);
x86_l_1f5:
	/* 0x1f5: or     eax,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_OR);
x86_l_1f7:
	/* 0x1f7: add    eax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 32ULL);
x86_l_1fa:
	/* 0x1fa: jmp    2db <handle_switch+0x2c2> */
	X86_SIM_X86_SUB_JMP(0x1fa, 0x2db, x86_l_2db);
x86_l_1ff:
	/* 0x1ff: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)hists));
x86_l_206:
	/* 0x206: lea    rdx,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_20d:
	/* 0x20d: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_210:
	/* 0x210: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_215:
	/* 0x215: call   21a <handle_switch+0x201> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_update_elem);
x86_l_21a:
	/* 0x21a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_21d:
	/* 0x21d: je     229 <handle_switch+0x210> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x21d, 0x229, x86_l_229);
x86_l_21f:
	/* 0x21f: cmp    rax,0xffffffffffffffef */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551599ULL);
x86_l_223:
	/* 0x223: jne    2eb <handle_switch+0x2d2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x223, 0x2eb, x86_l_2eb);
x86_l_229:
	/* 0x229: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)hists));
x86_l_230:
	/* 0x230: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_233:
	/* 0x233: call   238 <handle_switch+0x21f> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_238:
	/* 0x238: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_23b:
	/* 0x23b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_23e:
	/* 0x23e: jne    171 <handle_switch+0x158> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x23e, 0x171, x86_l_171);
x86_l_244:
	/* 0x244: jmp    2eb <handle_switch+0x2d2> */
	X86_SIM_X86_SUB_JMP(0x244, 0x2eb, x86_l_2eb);
x86_l_249:
	/* 0x249: lea    rdi,[r14+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_24d:
	/* 0x24d: add    rbx,0xd10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 3344ULL);
x86_l_254:
	/* 0x254: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_259:
	/* 0x259: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_25c:
	/* 0x25c: call   261 <handle_switch+0x248> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel_str);
x86_l_261:
	/* 0x261: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)targ_ms));
x86_l_268:
	/* 0x268: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b:
	/* 0x26b: jne    18c <handle_switch+0x173> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x26b, 0x18c, x86_l_18c);
x86_l_271:
	/* 0x271: mov    ecx,0x3e8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1000ULL);
x86_l_276:
	/* 0x276: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_279:
	/* 0x279: cqo */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, (0ULL - ((X86_SIM_L_READ_REG(X86_RAX) >> 63) & 1ULL)));
x86_l_27b:
	/* 0x27b: idiv   rcx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_64, X86_DIV_AUX_SIGNED, 0);
x86_l_27e:
	/* 0x27e: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_281:
	/* 0x281: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_283:
	/* 0x283: shr    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_287:
	/* 0x287: jne    1a8 <handle_switch+0x18f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x287, 0x1a8, x86_l_1a8);
x86_l_28d:
	/* 0x28d: cmp    eax,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 65536ULL);
x86_l_292:
	/* 0x292: setae  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_AE);
x86_l_295:
	/* 0x295: shl    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_298:
	/* 0x298: shrx   edx,eax,ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RAX, X86_WIDTH_32, X86_RCX, X86_ALU_SHR);
x86_l_29d:
	/* 0x29d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_29f:
	/* 0x29f: cmp    edx,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 256ULL);
x86_l_2a5:
	/* 0x2a5: setae  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_AE);
x86_l_2a8:
	/* 0x2a8: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_2ab:
	/* 0x2ab: shrx   edx,edx,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_2b0:
	/* 0x2b0: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2b2:
	/* 0x2b2: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_2b5:
	/* 0x2b5: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_2b9:
	/* 0x2b9: shl    esi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_2bc:
	/* 0x2bc: shrx   edx,edx,esi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RSI, X86_ALU_SHR);
x86_l_2c1:
	/* 0x2c1: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2c3:
	/* 0x2c3: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_2c6:
	/* 0x2c6: setae  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_AE);
x86_l_2ca:
	/* 0x2ca: add    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_ADD);
x86_l_2cc:
	/* 0x2cc: shrx   edx,edx,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RDX, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_2d1:
	/* 0x2d1: shr    edx,1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2d3:
	/* 0x2d3: or     eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_OR);
x86_l_2d5:
	/* 0x2d5: or     eax,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_32, X86_ALU_OR);
x86_l_2d7:
	/* 0x2d7: or     eax,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_OR);
x86_l_2d9:
	/* 0x2d9: or     eax,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_OR);
x86_l_2db:
	/* 0x2db: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2de:
	/* 0x2de: mov    ecx,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_2e3:
	/* 0x2e3: cmovb  ecx,eax */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RAX, X86_WIDTH_32, X86_CC_B);
x86_l_2e6:
	/* 0x2e6: inc DWORD PTR [r14+rcx*4] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_RCX, 2, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2eb:
	/* 0x2eb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_2f2:
	/* 0x2f2: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2f7:
	/* 0x2f7: call   2fc <handle_switch+0x2e3> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_2fc:
	/* 0x2fc: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_300:
	/* 0x300: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_301:
	/* 0x301: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_303:
	/* 0x303: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_305:
	/* 0x305: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_306:
	/* 0x306: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_307:
	/* 0x307: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)targ_per_pidns));
x86_l_30e:
	/* 0x30e: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_311:
	/* 0x311: je     372 <handle_switch+0x359> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x311, 0x372, x86_l_372);
x86_l_313:
	/* 0x313: lea    rdx,[rbx+0xb58] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2904ULL);
x86_l_31a:
	/* 0x31a: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31f:
	/* 0x31f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_324:
	/* 0x324: call   329 <handle_switch+0x310> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_329:
	/* 0x329: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32e:
	/* 0x32e: lea    rdx,[r14+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_332:
	/* 0x332: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_337:
	/* 0x337: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_33c:
	/* 0x33c: call   341 <handle_switch+0x328> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_341:
	/* 0x341: mov    eax,DWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_345:
	/* 0x345: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_349:
	/* 0x349: lea    rdx,[r14+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_34d:
	/* 0x34d: add    rdx,0x80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
x86_l_354:
	/* 0x354: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_359:
	/* 0x359: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_35e:
	/* 0x35e: call   363 <handle_switch+0x34a> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_363:
	/* 0x363: mov    edx,0x158 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 344ULL);
x86_l_368:
	/* 0x368: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_36d:
	/* 0x36d: jmp    130 <handle_switch+0x117> */
	X86_SIM_X86_SUB_JMP(0x36d, 0x130, x86_l_130);
x86_l_372:
	/* 0x372: mov    DWORD PTR [rsp],0xffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4294967295ULL);
x86_l_379:
	/* 0x379: jmp    156 <handle_switch+0x13d> */
	X86_SIM_X86_SUB_JMP(0x379, 0x156, x86_l_156);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x11ULL: goto x86_l_11;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
