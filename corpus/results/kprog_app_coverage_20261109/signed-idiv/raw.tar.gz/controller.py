from pathlib import Path
import subprocess,json,traceback
G=Path(__file__).resolve().parent
try:
 (G/'status.json').write_text(json.dumps(dict(state='hardware_and_original_div_oracles'))+'\n')
 with(G/'host-check.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'host'],stdout=f,stderr=subprocess.STDOUT)
 (G/'host-check.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 (G/'status.json').write_text(json.dumps(dict(state='host_finished',results=json.loads((G/'host-results.json').read_text())),indent=2)+'\n')
except BaseException as e:
 (G/'status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
