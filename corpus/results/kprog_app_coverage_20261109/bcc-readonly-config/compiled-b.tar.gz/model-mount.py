from pathlib import Path
import subprocess,os,sys
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((G/'model-source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'model-source'))],check=True)
os.execvp(sys.argv[1],sys.argv[1:])
