from pathlib import Path
import sys,json
R=Path('/workspaces/repository');G=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
rows=[]
for item in json.loads((G/'actual-inputs.json').read_text()):
 entry=item['entry'];metadata=json.loads((G/'actual-inputs'/entry/'generation.metadata.json').read_text());result=specialize((G/'candidate/bcc/syscount.native.o').read_bytes(),entry,metadata,G/'generated'/entry,R/'kprog/x86/native_lab/native_link/target/release/native-link');rows.append(dict(entry=entry,result=result));(G/'compiled-b.json').write_text(json.dumps(rows,indent=2)+'\n')
