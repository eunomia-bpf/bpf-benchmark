from pathlib import Path
import subprocess,json,tarfile,sys,datetime,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/bcc-readonly-config'
try:
 command=['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'model-mount.py'),'make','-f',str(G/'Makefile'),'compile'];(G/'model-command.json').write_text(json.dumps(command,indent=2)+'\n');(G/'model-status.json').write_text(json.dumps(dict(state='compiling'))+'\n')
 with(G/'model.log').open('w')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'model.exit').write_text(str(p.returncode)+'\n')
 result=dict(make_exit=p.returncode,actual_service_inputs=json.loads((G/'actual-inputs.json').read_text()),compiled_entries=json.loads((G/'compiled-b.json').read_text())if(G/'compiled-b.json').exists()else[],source=json.loads((G/'model-inputs.json').read_text()));(O/'compiled-b.json').write_text(json.dumps(result,indent=2)+'\n')
 with tarfile.open(O/'compiled-b.tar.gz','w:gz')as tar:
  for name in ['model-source','model-inputs.json','model-mount.py','compile-b.py','Makefile','model-command.json','model.log','model.exit','actual-inputs.json','actual-inputs','candidate','generated']:
   if(G/name).exists():tar.add(G/name,arcname=name)
 request='''C for R, BCC frozen-rodata P candidate. Native producer be9dee5a8d61d72f5d5b910dee0ff83a992e59de carries paired complete8-object BCC payloads under /var/tmp/kprog-tmp/C/bcc-readonly-config/{control,candidate}/bcc with full manifests. syscount native control f75d9ddc53bdd5484d1760f9b16b058ae133aa2f8831b07a058be649ae01465d equals the prior O3 ELF. Candidate d43869064ee2a5fe85f2000a01c8f6c4ac4bbf3c5409cba7a066b90905262977 specializes only six stable readonly config fields before P submission: measure_latency1; filter_cg/count_by_process/filter_failed/filter_errno/filter_pid0. Frozen9f3855f6f bcc_set.py selects syscount -L -i1; original syscount.c parser/defaults populate those same fields before libbpf load. P executable bytes540->233, instructions173->78, conditional branches23->6, RIP memory ops17->6; actual dynamic shares and throughput remain R observations. Other seven native objects preserve original bytes and every application program stays in the manifest.

Stage candidate *.native.o and manifest.json at /artifacts/user/native-bpf/x86_64/bcc/ in R's restored05-29 image, retain its existing phase/arm/stats controls, and use the existing target:

```sh
make -C /workspaces/repository __runtime-vm-corpus PLATFORM=kvm ARCH=x86 RUNTIME_CONTAINER_IMAGE="$R_IMAGE_WITH_C_P" SAMPLES=3 WORKLOAD_DURATION=180
```

The paired control payload and immutable raw.tar.gz provide the comparison and reproduction inputs. B uses the actual optimized P and source maps; kernel emission retains its existing same-copy path. R compares actual events/syscall work/BPF run counts and workload throughput against JIT. This payload binds the frozen configuration; a corresponding P compile carries another configuration. Original38 and full application/runtime outcomes retain their separate evidence.
'''
 request+='\nActual sys_enter/sys_exit service inputs from the running canonical cohort supply metadata for compiler replay. Current emitted-B compile exit'+str(p.returncode)+', completed entries'+str([x['entry']for x in result['compiled_entries']])+'. Exact public model source and all generated/compiler output accompany compiled-b.tar.gz.\n';(O/'timing-request.md').write_text(request)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str((O/n).relative_to(R))for n in ['compiled-b.json','compiled-b.tar.gz','timing-request.md']],'Request BCC timing with compiled frozen-config native P',G/'model-publication.json')
 path=C.parent/'COORDINATION.md';text=path.read_text();pos=text.index('\n## ',text.index('## Timing requests')+len('## Timing requests'));text=text[:pos]+'\n- '+datetime.datetime.now(datetime.timezone.utc).isoformat()+' '+request+'\n'+text[pos:];path.write_text(text)
 note='\n- LOCAL C FOR R/V/A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' readonly-config BCC actual native-to-B compilation and Timing request. Exact originalO3 syscount control retained; candidate reduces540->233executable bytes,173->78instructions,23->6conditional branches and17->6RIP memory ops. Actual completed service metadata rows'+str([x['entry']for x in result['actual_service_inputs']])+', B compile exit'+str(p.returncode)+'. Both8-object native payloads retain complete BCC program selection. R owns matching work and restored05-29 throughput. Runtime admission additions0.\n'
 with path.open('a')as f:f.write(note)
 with(C/'last.md').open('a')as f:f.write(note)
 (G/'model-status.json').write_text(json.dumps(dict(state='finished',make_exit=p.returncode,commit=commit))+'\n')
except BaseException as e:(G/'model-status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()))+'\n');raise
