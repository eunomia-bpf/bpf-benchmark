from pathlib import Path
import subprocess,shlex,json,re,tarfile,hashlib,sys,datetime,shutil,traceback
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');G=Path(__file__).resolve().parent;P=Path('/var/tmp/kprog-tmp/C/native-constant-division/control');O=R/'corpus/results/kprog_app_coverage_20261109/bcc-readonly-config';commands=[]
def run(args,log,cwd=R):
 commands.append(dict(args=[str(x)for x in args],cwd=str(cwd),log=log));(G/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with(G/log).open('w')as f:p=subprocess.run([str(x)for x in args],cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 (G/(log+'.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('native_compile')
 log=(P.parent/'control-native.log').read_text().replace('\\\n',' ')
 command=shlex.split(next(l for l in log.splitlines()if l.startswith('"clang-18"')and'syscount.bpf.c'in l))
 emit=command[:];emit[emit.index('-o')+1]=str(G/'syscount.control.ll');emit+=['-S','-emit-llvm'];run(emit,'emit-ir.log',R/'vendor/bpf')
 run(['python3',G/'specialize-ir.py',G/'syscount.control.ll',G/'bindings.json',G/'syscount.candidate.ll',G/'replaced-loads.json'],'specialize.log')
 codegen=['clang-18','-O3','-g','-fPIC','-c','-fomit-frame-pointer','-march=native','-mno-red-zone','-mgeneral-regs-only','-fno-stack-protector','-fno-asynchronous-unwind-tables','-fno-unwind-tables','-fno-jump-tables','-fno-optimize-sibling-calls','-mllvm','-switch-to-lookup=false']
 rows=[]
 for label in ['control','candidate']:
  out=G/label/'bcc';out.mkdir(parents=True,exist_ok=True)
  for obj in(P/'native/bcc').glob('*.native.o'):shutil.copy2(obj,out/obj.name)
  run([*codegen,G/('syscount.'+label+'.ll'),'-o',out/'syscount.native.o'],label+'-codegen.log')
  run(['python3',R/'vendor/bpf/write_native_manifest.py','--app','bcc','--llvm-nm','llvm-nm-18','--output',out/'manifest.json',*[v for obj in sorted(out.glob('*.native.o'))for v in ['--object',obj]]],label+'-manifest.log')
  obj=out/'syscount.native.o'
  with obj.open('rb')as f:
   e=ELFFile(f);sections=[dict(name=s.name,bytes=s['sh_size'],sha256=hashlib.sha256(s.data()).hexdigest())for s in e.iter_sections()if s['sh_flags']&4 and s['sh_size']]
  dis=subprocess.check_output(['llvm-objdump-18','-dr','--no-show-raw-insn',str(obj)],text=True);(G/(label+'.disassembly.txt')).write_text(dis)
  instructions=[l for l in dis.splitlines()if re.match(r'^\s*[0-9a-f]+:\s+\S',l)]
  rows.append(dict(label=label,native_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),sections=sections,instructions=len(instructions),conditional_branches=sum(bool(re.search(r'\tj(?!mp)[a-z]+\s',l))for l in instructions),all_calls=sum('\tcall'in l for l in instructions),rip_memory_ops=sum('(%rip)'in l for l in instructions)))
 (G/'objects.json').write_text(json.dumps(rows,indent=2)+'\n')
 # Capture the exact completed BCC service inputs from the existing canonical cohort.
 K=C/'design-only/remaining-apps/bcc-katran-smap-recovery';actual=[]
 original_hash=hashlib.sha256((P/'native/bcc/syscount.native.o').read_bytes()).hexdigest()
 for archive in K.glob('trusted-*/requests/*.success.tar.gz'):
  with tarfile.open(archive)as tar:
   native=tar.extractfile('request/kernel.native.o').read()
   if hashlib.sha256(native).hexdigest()!=original_hash:continue
   entry=tar.extractfile('request/kernel.entry').read().decode().strip();inp=G/'actual-inputs'/entry;inp.mkdir(parents=True,exist_ok=True)
   for name in ['kernel.native.o','kernel.entry','generation.metadata.json','kernel.facts.json','kernel.metadata.json']:(inp/name).write_bytes(tar.extractfile('request/'+name).read())
   actual.append(dict(entry=entry,archive=str(archive),native_sha256=original_hash))
 (G/'actual-inputs.json').write_text(json.dumps(actual,indent=2)+'\n')
 # Source observations bind this compiler profile to the frozen CLI and loader globals.
 paths=['vendor/bpf/bcc/libbpf-tools/syscount.bpf.c','vendor/repos/bcc/libbpf-tools/syscount.c','vendor/bpf/native_compat.h','vendor/bpf/Makefile']
 source={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in paths}
 for n in paths:
  p=G/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
 frozen=subprocess.check_output(['git','show','9f3855f6f:runner/libs/app_runners/bcc_set.py'],text=True,cwd=R);(G/'frozen-bcc-set.py').write_text(frozen)
 inputs=dict(source=source,frozen_workload='9f3855f6f',syscount_arguments=['-L','-i','1'],configuration_origin='Frozen bcc_set.py tool spec; syscount.c CLI parser/default env/rodata initialization; stable libbpf read-only configuration',bindings=json.loads((G/'bindings.json').read_text()));(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 O.mkdir(parents=True,exist_ok=True);result=dict(objects=rows,replaced_loads=json.loads((G/'replaced-loads.json').read_text()),actual_service_inputs=actual,inputs=inputs,native_executions=0,guest_executions=0);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 table='| Producer | Executable bytes | Instructions | Conditional branches | Calls | RIP memory operations |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
 for row in rows:table+=f"| {row['label']} | {sum(s['bytes']for s in row['sections'])} | {row['instructions']} | {row['conditional_branches']} | {row['all_calls']} | {row['rip_memory_ops']} |\n"
 (O/'README.md').write_text('# BCC native compilation with frozen read-only configuration\n\nThe frozen2026-05-29 recipe runs syscount with -L -i1. The CLI initializes measure_latency1 and filter_cg/count_by_process/filter_failed/filter_errno/filter_pid0 before loading its read-only data map. The private native compiler consumes those fixed input bindings, replaces only their scalar volatile IR loads with captured constants, and runs the existing O3 optimizer/code generator. Original C/JIT, workload and kernel same-copy emission retain their definitions. This is the authorized recompilation of P from stable configuration. The candidate stays tied to these captured bindings; arbitrary configuration changes require the corresponding P compile.\n\n'+table+'\nBoth paired producers carry the same eight BCC native objects and complete manifest, with only syscount recompiled through the paired IR pipeline. summary.json records every replaced load, source hash and actual completed syscount service input. Full IR/commands/native/disassembly payloads accompany raw.tar.gz. These are native compiler observations. Generation-bound loading, original38 and actual matching-work/throughput remain application/R observations. Runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tar:
  for p in sorted(G.iterdir()):
   if p.name not in ['controller.log','controller.pid','status.json','publication.json']:tar.add(p,arcname=p.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Compile BCC native P from frozen read-only configuration',G/'publication.json');save('finished',commit=commit,objects=rows)
 notice='\n- LOCAL C FOR R/A/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' BCC syscount stable-rodata P compile at corpus/results/kprog_app_coverage_20261109/bcc-readonly-config. Frozen9f recipe -L/-i1 binds measure_latency1 and other five filter/aggregation fields0 through original CLI; native IR scalar loads specialize before P submission and O3 codegen. Exact replaced loads/paired8-object payloads/source/actual syscount service inputs retained. Original C/JIT/workload/kernel unchanged; actual matching work/R throughput follows. Runtime admission additions0.\n'
 with(C.parent/'COORDINATION.md').open('a')as f:f.write(notice)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
