from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,hashlib,tarfile,shutil,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');Q=G.parent/'bcc-katran-smap-recovery';O=R/'corpus/results/kprog_app_coverage_20261109/native-size-runtime'
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
def notice(s):
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': '+s+'\n')
try:
 save('queued_after_original38')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:cmd=(proc/'cmdline').read_bytes().split(b'\0')
   except (FileNotFoundError,ProcessLookupError):continue
   if cmd and cmd[0].endswith(b'qemu-system-x86_64')and any(('path='+str(Q)+',').encode()in arg for arg in cmd):
    try:fd=os.pidfd_open(int(proc.name));select.select([fd],[],[]);os.close(fd)
    except ProcessLookupError:pass
 # Refresh the existing Os output cache after the canonical job closes.
 N=C/'design-only/native-size-policy/Os'
 producer=json.loads((N/'command.json').read_text());producer[2]='20-23'
 (G/'native-command.json').write_text(json.dumps(producer,indent=2)+'\n')
 with(G/'native-build.log').open('w')as f:built=subprocess.run(producer,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'native-build.exit').write_text(str(built.returncode)+'\n');built.check_returncode()
 shutil.copy2(N/'native.mk',G/'producer.mk')
 for app in ['bcc','katran']:
  target=G/'image'/app;target.mkdir()
  for obj in(N/'stage'/app).iterdir():
   if obj.name.endswith('.native.o')or obj.name=='manifest.json':shutil.copy2(obj,target/obj.name)
 for src in(Q/'source').rglob('*'):
  if src.is_file()and '__pycache__'not in src.parts:
   rel=src.relative_to(Q/'source');dst=G/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 # Native inputs change before submission; the runtime uses the captured control source.
 objects={str(p.relative_to(G/'image')):hashlib.sha256(p.read_bytes()).hexdigest()for p in(G/'image').rglob('*')if p.is_file()}
 (G/'native-inputs.json').write_text(json.dumps(dict(control=json.loads((Q/'status.json').read_text()),flags='Os in NATIVE_CFLAGS and KATRAN_NATIVE_CFLAGS',objects=objects),indent=2)+'\n')
 notice('Packaging existing native Os producer outputs after canonical SMAP BCC/Katran closure; two compiler flag definitions change P before submission, with the captured kernel/service/model/workload epoch retained. Runtime admission additions0.')
 with(G/'image.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'image'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'image.exit').write_text(str(p.returncode)+'\n');p.check_returncode();image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip();files=[p for p in(G/'source').rglob('*')if p.is_file()]+[G/'clang',G/'guest.py',G/'Makefile']+[p for p in(G/'image').rglob('*')if p.is_file()];inputs=dict(utc=datetime.now(timezone.utc).isoformat(),loader_source='dc120a8ebc2fea2dd274c510fe045a22e29bc52d',image=image,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=bcc/set,katran','SAMPLES=3','WORKLOAD_DURATION=180'];(G/'command.json').write_text(json.dumps(command,indent=2)+'\n');save('running',image=image)
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*command],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 with(G/'collect.log').open('w')as f:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=G.parent/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
 for path in I.iterdir():
  if path.is_file():shutil.copy2(path,O/path.name)
 j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']];(O/'work.json').write_text(json.dumps(work,indent=2)+'\n');result=dict(make_exit=p.returncode,native_requests=j['native_requests'],generated=j['generated'],compiled=j['compiled'],installed=j['installed'],failed=j['failed'],work=work,inputs=inputs);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Whole BCC and Katran native Os producer candidate\n\nThe existing native producer selects Os in its two compiler flag definitions, before P submission. Original C/division lowering/ABI and the captured SMAP kernel/service/model retain their recorded definitions. The canonical O3 cohort supplies the control; R owns restored05-29 timing. Loader resolves public helper calls through the existing generic ABI; native compilation is the optimization boundary. Original application sources, native inputs and workloads retain their definitions. Actual G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+'; Makeexit'+str(p.returncode)+'. Every original native/C/B/compiler/verifier/service record and actual phase work counter accompanies this cohort. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as tf:
  for name in ['Makefile','guest.py','clang','mount.py','source','image','producer-flags.patch','producer.mk','native-command.json','native-build.log','native-build.exit','native-inputs.json','image.log','image.exit','inputs.json','command.json','controller.py','run.log','run.exit','collect.log','collect.exit','summary.json']:tf.add(G/name,arcname=name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure whole BCC and Katran native size producer candidate',G/'publication.json');save('finished',commit=commit,counts={k:result[k]for k in ['make_exit','native_requests','generated','compiled','installed','failed']});notice('PUSHED '+commit+' whole BCC/Katran native Os producer '+repr({k:result[k]for k in ['make_exit','native_requests','generated','compiled','installed','failed']})+'; complete actual work retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
