syscount.bpf.o: bcc/libbpf-tools/syscount.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/x86/vmlinux.h \
  /usr/include/bpf/bpf_helpers.h /usr/include/bpf/bpf_tracing.h \
  /usr/include/bpf/bpf_core_read.h bcc/libbpf-tools/syscount.h \
  bcc/libbpf-tools/maps.bpf.h /usr/include/asm-generic/errno.h \
  /usr/include/asm-generic/errno-base.h
