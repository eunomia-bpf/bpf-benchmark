vfsstat.bpf.o: bcc/libbpf-tools/vfsstat.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/x86/vmlinux.h \
  /usr/include/bpf/bpf_helpers.h /usr/include/bpf/bpf_tracing.h \
  bcc/libbpf-tools/vfsstat.h
