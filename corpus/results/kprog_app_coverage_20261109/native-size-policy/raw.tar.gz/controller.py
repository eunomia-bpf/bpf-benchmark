from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,sys,tarfile,traceback,shutil,shlex
from elftools.elf.elffile import ELFFile
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261109/native-size-policy'
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 results=[]
 for label in ['Os']:
  d=G/label;save('native_compile',label=label);command=['taskset','-c','8-11','make','-C',str(R/'vendor/bpf'),'-f',str(d/'native.mk'),'native-bcc','native-katran','ARCH=x86','KERNEL_RELEASE=7.0.0-rc2+','NATIVE_OUT='+str(d/'native'),'BCC_NATIVE_STAGE_OUT='+str(d/'stage/bcc'),'KATRAN_NATIVE_STAGE_OUT='+str(d/'stage/katran'),'NATIVE_LINK='+str(R/'kprog/x86/native_lab/native_link/target/release/native-link')];(d/'command.json').write_text(json.dumps(command,indent=2)+'\n')
  with(d/'build.log').open('w')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
  (d/'build.exit').write_text(str(p.returncode)+'\n');objects=[]
  for o in sorted((d/'native').rglob('*.native.o')):
   with o.open('rb')as f:
    e=ELFFile(f);sections=[dict(name=s.name,bytes=s['sh_size'],sha256=hashlib.sha256(s.data()).hexdigest())for s in e.iter_sections()if s['sh_flags']&4 and s['sh_size']]
   objects.append(dict(object=str(o.relative_to(d)),sha256=hashlib.sha256(o.read_bytes()).hexdigest(),executable_sections=sections))
  dependencies={}
  for dep in (d/'native').rglob('*.d'):
   txt=dep.read_text().replace('\\\n',' ');items=shlex.split(txt.split(':',1)[1])
   for n in items:
    src=Path(n);src=src if src.is_absolute()else R/'vendor/bpf'/src
    if src.is_file():
     src=src.resolve();dependencies[str(src)]=hashlib.sha256(src.read_bytes()).hexdigest()
     try:rel=src.relative_to(R)
     except ValueError:continue
     dst=G/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  row=dict(label=label,make_exit=p.returncode,objects=objects,dependencies=dependencies);results.append(row);(G/'outcomes.json').write_text(json.dumps(results,indent=2)+'\n')
 O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(dict(native_executions=0,kernel_loads=0,results=results),indent=2)+'\n');(O/'README.md').write_text('# Native size-oriented compilation before submission'+chr(10)+chr(10)+'Whole BCC and Katran native producers compile with Os from their published C and helper ABI, including the existing generic division pass. Canonical production flags keep O3. The prior 973fabf0a O3 control has identical current dependency hashes and supplies the reference executable sections. This compile result records actual object bytes, source dependencies and proof-mode closure. Whole five-step loading, the original38 safety outcome, matching work and R timing remain the next observations.'+chr(10))
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for n in ['producer.before.mk','controller.py','Os','source','outcomes.json']:tf.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure size-oriented native compilation for BCC and Katran',G/'publication.json');save('finished',commit=commit,counts=[dict(label=r['label'],make_exit=r['make_exit'],objects=len(r['objects']),executable_bytes=sum(s['bytes']for o in r['objects']for s in o['executable_sections']))for r in results])
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' generic pre-submit native size compiler measurement: '+repr(json.loads((G/'status.json').read_text()))+'. Same C/ABI/division pass retained; current production flags retained, actual whole work/timing follows selected P. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
