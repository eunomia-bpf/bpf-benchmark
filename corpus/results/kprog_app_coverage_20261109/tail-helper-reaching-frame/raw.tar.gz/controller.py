from pathlib import Path
import json,subprocess,hashlib,sys,tarfile,traceback,resource,shutil
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/tail-helper-reaching-frame'
def state(**d):(G/'status.json').write_text(json.dumps(d,indent=2)+'\n')
def repro(binary,label):
 P=G/'actual-input';proof=next(P.glob('*.proof.o'));plan=next(P.glob('*.link-plan.json'));D=G/label;D.mkdir(exist_ok=True);args=[str(binary),'--input',str(proof),'--symbol','tracepoint__raw_syscalls__sys_enter','--mode','kernel','--output',str(D/'native.blob'),'--output-relocs',str(D/'native.relocs'),'--output-map-patches',str(D/'maps.tsv'),'--output-abi',str(D/'abi.tsv'),'--output-data-layout',str(D/'data.json'),'--link-plan',str(plan)]
 with(D/'stdout').open('w')as f, (D/'stderr').open('w')as e:p=subprocess.run(args,stdout=f,stderr=e)
 d=dict(command=args,returncode=p.returncode,stderr=(D/'stderr').read_text(),outputs={x.name:hashlib.sha256(x.read_bytes()).hexdigest()for x in D.iterdir()if x.name not in ['stdout','stderr']});(D/'result.json').write_text(json.dumps(d,indent=2)+'\n');return d
try:
 state(state='parent_reproduction')
 parent=repro(Path('/var/tmp/kprog-tmp/C/master-x86-runtime/runtime/native-link'),'parent')
 state(state='existing_rust_tests')
 for target in ['test','build']:
  with(G/(target+'.log')).open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),target],stdout=f,stderr=subprocess.STDOUT)
  (G/(target+'.exit')).write_text(str(p.returncode)+'\n');p.check_returncode()
 binary=G/'native-link';shutil.copy2('/var/tmp/kprog-tmp/C/master-x86-runtime/native-target/release/native-link',binary)
 candidate=repro(binary,'candidate');result=dict(source='existing finite reaching-helper flow for entry tail detection',parent=parent,candidate=candidate,rust_test_exit=0,build_exit=0,source_sha256=hashlib.sha256((G/'source/src/x86.rs').read_bytes()).hexdigest(),native_link_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),runtime_predicates_added=0)
 O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'candidate.patch').write_bytes((G/'candidate.patch').read_bytes());(O/'README.md').write_text('# Tail-call frame planning from reaching helper targets\n\nThe actual Tracee raw_syscalls entry in coherent109c86a05 copies helper12 from RAX to R11 after argument setup, then uses the compiler external thunk. Kernel lowering already resolves that call through the generic finite reaching-target analysis. Entry frame planning used a local immediate-register lookahead and missed the copied helper identity, leaving the existing RBP frame location empty.\n\nThe private candidate reuses the existing reaching-target flow for helper-ID detection before frame planning. Existing cleanup/RBP/native ABI calculations, helper lowering, kernel emission and metadata formats retain their implementations. The regression exercises that compiler call shape and an overwritten-helper-ID case. Existing complete Rust tests/build exit0. Exact original Tracee proof object/link plan runs through parent and candidate; summary.json records their actual return values and complete output hashes. Runtime predicate additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for n in ['source','parent-x86.rs','candidate.patch','actual-input','Makefile','controller.py','test.log','test.exit','build.log','build.exit','native-link','parent','candidate']:t.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Reproduce copied helper tail-frame planning with existing reaching definitions',G/'publication.json');state(state='finished',commit=commit,parent_exit=parent['returncode'],candidate_exit=candidate['returncode'])
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR V/A/R/S11/S15 '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' Tracee actual19 copied-helper frame-plan candidate, parent'+str(parent['returncode'])+'/candidate'+str(candidate['returncode'])+', allRust/build0. Existing finite reaching targets now feed entry helper12 detection; prior local lookahead missed RAX->R11 across argument setup although downstream lowering resolved it. Existing frame cleanup/RBP geometry and kernel path retained; runtime predicates0. Production source promotion follows actual reproduction/source review. Raw original P/proof/plan/outputs retained.\n')
except BaseException as e:state(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
