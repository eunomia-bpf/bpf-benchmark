from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,sys,hashlib,tarfile,traceback
G=Path(__file__).resolve().parent;C=Path('/workspaces/.agent-state/kprog-lanes/C');R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261109/smap-recovery/build'
def save(**j):(G/'build-status.json').write_text(json.dumps(j,indent=2)+'\n')
try:
 save(state='incremental_build')
 command=['taskset','-c','20-23','make','-f',str(G/'Makefile'),'build'];(G/'build-command.json').write_text(json.dumps(command,indent=2)+'\n')
 with(G/'build.log').open('w')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'build.exit').write_text(str(p.returncode)+'\n');O.mkdir(parents=True,exist_ok=True)
 files=['vendor/linux-framework/arch/x86/mm/fault.c','kprog/tv/build-kernel-x86/arch/x86/boot/bzImage','kprog/tv/build-kernel-x86/vmlinux','kprog/tv/build-kernel-x86/Module.symvers','kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko','kprog/libnativeloader/build/trusted-native-loader','kprog/libnativeloader/build/libnative_loader.so']
 j=dict(make_exit=p.returncode,source_commit=json.loads((G/'source-publication.json').read_text())['commit'],files={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in files});(O/'summary.json').write_text(json.dumps(j,indent=2)+'\n');(O/'README.md').write_text('# Incremental x86 SMAP recovery producer\n\nApproved casea66 uses the existing kernel/module/loader caches. Actual Make exit'+str(p.returncode)+'. Exact command, original source change and full build output accompany raw.tar.gz. The paired runtime hashes are recorded in summary.json. Live-file/NULL, original38 and whole BCC/Katran supply subsequent runtime observations.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for n in ['Makefile','build-controller.py','build-command.json','build.log','build.exit','fault.before.c','fault.after.c','approved.patch','source-publication.json']:t.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record incremental approved x86 SMAP recovery build',G/'build-publication.json');save(state='finished',commit=commit,make_exit=p.returncode)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/V/R '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' approved SMAP incremental kernel/module/loader build actualMake'+str(p.returncode)+'. Exact paired runtime/source identities retained. Existing authorized live-file/NULL ->38 ->BCC/Katran queue consumes this actual producer. Native P bytes/model and frozen workload source retain their definitions.\n')
except BaseException as e:save(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
