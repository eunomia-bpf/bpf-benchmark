from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,hashlib,tarfile,shutil,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/load-fault-recovery/smap-approved/original38';O=R/'corpus/results/kprog_app_coverage_20261109/smap-recovery/bcc-katran'
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
def notice(s):
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': '+s+'\n')
try:
 save('queued_after_original38')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:cmd=(proc/'cmdline').read_bytes().split(b'\0')
   except (FileNotFoundError,ProcessLookupError):continue
   if cmd and cmd[0].endswith(b'qemu-system-x86_64')and any(('path='+str(Q)+',').encode()in arg for arg in cmd):
    try:fd=os.pidfd_open(int(proc.name));select.select([fd],[],[]);os.close(fd)
    except ProcessLookupError:pass
 for src in (C/'design-only/remaining-apps/bcc-katran-same-copy/source').rglob('*'):
  if src.is_file()and '__pycache__'not in src.parts:
   rel=src.relative_to(C/'design-only/remaining-apps/bcc-katran-same-copy/source');dst=G/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
 rel=Path('kprog/tv/build-kernel-x86/arch/x86/boot/bzImage');dst=G/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
 shutil.copy2(R/'kprog/libnativeloader/build/libnative_loader.so',G/'image/libnative_loader.so')
 (G/'image/paired-kinsn').mkdir()
 for module in(R/'kprog/tv/build-x86/corpus-modules').glob('*.ko'):shutil.copy2(module,G/'image/paired-kinsn'/module.name)
 notice('Packaging own image DSO after original38: dc120a8eb submitted-copy helper binding, existing BCC/Katran application source/native inputs and workloads retained. Runtime admission additions0.')
 with(G/'image.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'image'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'image.exit').write_text(str(p.returncode)+'\n');p.check_returncode();image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip();files=[p for p in(G/'source').rglob('*')if p.is_file()]+[G/'clang',G/'guest.py',G/'Makefile']+[p for p in(G/'image').rglob('*')if p.is_file()];inputs=dict(utc=datetime.now(timezone.utc).isoformat(),loader_source='dc120a8ebc2fea2dd274c510fe045a22e29bc52d',image=image,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=bcc/set,katran','SAMPLES=3','WORKLOAD_DURATION=180'];(G/'command.json').write_text(json.dumps(command,indent=2)+'\n');save('running',image=image)
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*command],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 with(G/'collect.log').open('w')as f:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=G.parent/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
 for path in I.iterdir():
  if path.is_file():shutil.copy2(path,O/path.name)
 j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']];(O/'work.json').write_text(json.dumps(work,indent=2)+'\n');result=dict(make_exit=p.returncode,native_requests=j['native_requests'],generated=j['generated'],compiled=j['compiled'],installed=j['installed'],failed=j['failed'],work=work,inputs=inputs);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Whole BCC and Katran after approved SMAP recovery\n\nApproved SMAPaee6 uses the fresh paired kernel/module/loader. The captured compatibility workload epoch and original native inputs remain recorded; R owns restored05-29 timing. Loader resolves public helper calls through the existing generic ABI; native compilation is the optimization boundary. Original application sources, native inputs and workloads retain their definitions. Actual G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+'; Makeexit'+str(p.returncode)+'. Every original native/C/B/compiler/verifier/service record and actual phase work counter accompanies this cohort. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as tf:
  for name in ['Makefile','guest.py','clang','mount.py','source','image/Dockerfile','image/libnative_loader.so','image/paired-kinsn','image.log','image.exit','inputs.json','command.json','controller.py','run.log','run.exit','collect.log','collect.exit','summary.json']:tf.add(G/name,arcname=name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record whole BCC and Katran after approved SMAP load recovery',G/'publication.json');save('finished',commit=commit,counts={k:result[k]for k in ['make_exit','native_requests','generated','compiled','installed','failed']});notice('PUSHED '+commit+' whole BCC/Katran same-copy binding '+repr({k:result[k]for k in ['make_exit','native_requests','generated','compiled','installed','failed']})+'; complete actual work retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
