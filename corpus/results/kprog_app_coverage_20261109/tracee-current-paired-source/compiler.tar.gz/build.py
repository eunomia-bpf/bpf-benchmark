from pathlib import Path
import subprocess,json,tarfile,shutil,hashlib,sys,traceback,resource
from datetime import datetime,timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');O=R/'corpus/results/kprog_app_coverage_20261109/tracee-current-paired-source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 (G/'status.json').write_text(json.dumps(dict(state='paired_incremental_build'))+'\n')
 for src,dst in [(G/'tree',R/'vendor/bpf/tracee/pkg/ebpf/c'),(G/'tree',R/'vendor/repos/tracee/pkg/ebpf/c'),(G/'embed-dist',R/'vendor/repos/tracee/dist'),(G/'native_compat.h',R/'vendor/bpf/native_compat.h')]:subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
 with(G/'build.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'paired'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'build.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 payload=G/'payload';payload.mkdir()
 for x in(G/'native/tracee').rglob('*.native.o'):shutil.copy2(x,payload/x.name)
 args=['python3',G/'write_native_manifest.py','--app','tracee','--llvm-nm','llvm-nm-18','--dedupe-program','last','--output',payload/'manifest.json']+[v for x in [payload/'tracee.native.o',payload/'kprobe_check.native.o',payload/'lsm_check.native.o']for v in ['--object',x]]
 with(G/'manifest.log').open('w')as f:subprocess.run([str(x)for x in args],stdout=f,stderr=subprocess.STDOUT,check=True)
 result=dict(inputs=json.loads((G/'inputs.json').read_text()),make_exit=0,native_objects={x.name:sha(x)for x in payload.iterdir()if x.is_file()},manifest_entries=len(json.loads((payload/'manifest.json').read_text())['objects']),paired_sources={str(x.relative_to(G/'tree')):sha(x)for x in(G/'tree').rglob('*')if x.is_file()},baseline_bpf_sha256=sha(G/'dist/tracee.bpf.o'),embedded_binary_sha256=sha(G/'dist/tracee'),native_directory=str(payload),baseline_directory=str(G/'dist'))
 O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Tracee paired current published string-offset source\n\nThis incremental producer adopts the published09f40af86 u64 local string-offset/register operands in both native and original JIT BPF frontends. The prior source20096 image in53b44c83b reaches syscall__execveat_enter map32536/off32142/size4096 in its baseline. The captured current complete C/header tree builds native P, JIT BPF and the embedded Tracee executable through the existing make targets. Every original limit, condition, output field and program selection retains the source-ledger definition.\n\nActual paired make0, native3objects/'+str(result['manifest_entries'])+'manifest rows. Native directory `'+str(payload)+'`; actual baseline BPF/embedded binary in `'+str(G/'dist')+'`. summary.json identifies every source/native/BPF/binary hash. compiler.tar.gz retains source, commands, diagnostics and outputs. Actual complete application/verifier/work follows the coherent shim/loader runtime successor. Frozen framework and original38 retain their published bytes.\n')
 with tarfile.open(O/'compiler.tar.gz','w:gz')as t:
  for n in ['inputs.json','Makefile','native-vendor.mk','build.py','tree','native_compat.h','native_division.so','payload','dist/tracee.bpf.o','dist/tracee','dist/lsm_support','build.log','build.exit','manifest.log']:t.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(x.relative_to(R))for x in O.iterdir()if x.is_file()],'Build Tracee native and embedded JIT from current published offset source',G/'publication.json');(G/'status.json').write_text(json.dumps(dict(state='finished',commit=commit,result=result),indent=2)+'\n')
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/R/V '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' Tracee current published09f40af86 same C/header bytes through native3objects/'+str(result['manifest_entries'])+'rows and original JIT/embedded executable, incremental make0. Prior20096 baseline53b mapoff32142 remains raw. Runtime successor pairs new shim with current loader and actual Tetragon selected repo-artifact destination. Full actual startup follows; frozen framework/source38 retained.\n')
except BaseException as e:(G/'status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
