from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,tarfile,sys,shutil,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261109/cilium-map-caller-frame'
def notice(msg):
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/V/R '+datetime.now(timezone.utc).isoformat()+': '+msg+'\n')
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('packaging_paired_kinsn_modules')
 inputs=json.loads((G/'inputs.json').read_text());inputs['runtime_base_image']=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip();(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 save('packaging_paired_modules')
 with(G/'image.log').open('w')as f:p=subprocess.run(['taskset','-c','20-23','make','-f',str(G/'Makefile'),'image'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'image.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip()
 command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=cilium/agent','SAMPLES=3','WORKLOAD_DURATION=180']
 (G/'command.json').write_text(json.dumps(command,indent=2)+'\n');save('running',image=image,command=command)
 notice('Whole original Cilium map-helper caller-frame candidate START20-23/12GiB, SAMPLES3/WORKLOAD_DURATION180, image'+image+'. Existing original38 candidate e4949valid/28verifier/1generation and V368483bd helper-frame laws retained. Current kernel/module/worker/loader source captured together; frozen benchmark files retain bytes. Production helper header retains its current definition. Terminal publication collects every native request, actual app error/work and raw logs. Runtime admission additions0.')
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*command],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 if (G/'summary.json').exists():
  with(G/'collect.log').open('w')as f:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=f,stderr=subprocess.STDOUT)
  (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=G.parent/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
  for path in I.iterdir():
   if path.is_file():shutil.copy2(path,O/path.name)
  j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']]
  result=dict(make_exit=p.returncode,image=image,native_requests=j['native_requests'],generated=j['generated'],compiled=j['compiled'],installed=j['installed'],failed=j['failed'],work=work)
 else:
  O.mkdir(parents=True,exist_ok=True);result=dict(make_exit=p.returncode,image=image,stage='guest_startup',run_log=(G/'run.log').read_text())
 (O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 (O/'README.md').write_text('# Whole Cilium map-helper caller-frame representation\n\nThe generic private candidate retains caller-allocated stack facts across map_update_elem and map_delete_elem, using the existing scalar-result representation. Actual map memory/results and caller clobbers retain their definitions. Every original Cilium startup request runs through the captured five-step source/kernel/module/loader; native input selection, benchmark framework and workload retain their existing definitions. Command: `make -f '+str(G/'Makefile')+' corpus STATE='+str(G)+' CPUS=20-23 VM_CPUS=8 VM_MEM=12G APPS=cilium/agent SAMPLES=3 WORKLOAD_DURATION=180`. Actual Make exit '+str(p.returncode)+'. Coverage, native inputs, verifier classes and work retain their raw records in the accompanying files. Universal platform/helper-footprint obligations retain the V368483bd interface. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as t:
  for n in ['controller.py','Makefile','guest.py','mount.py','clang','source','image/Dockerfile','image/libnative_loader.so','image/skb.h','bootstrap-initial','module-setup','image.log','image.exit','inputs.json','command.json','status.json','run.log','run.exit','collect.log','collect.exit','summary.json']:
   if(G/n).exists():t.add(G/n,arcname=n)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Measure whole Cilium with map helper caller-frame representation',G/'publication.json');save('finished',commit=commit,result=result);notice('PUSHED '+commit+' whole Cilium map-helper candidate actual '+repr({k:v for k,v in result.items()if k!='work'and k!='run_log'})+'. Full original work and terminal errors retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
