#include <stdio.h>
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 128
#include "kprog/x86/x86_sim_local_bpf.h"
#define bpf_ktime_get_ns(...) 7ULL
#define bpf_trace_printk(...) 7ULL
#define bpf_get_prandom_u32(...) 7ULL
#define bpf_get_smp_processor_id(...) 7ULL
#define bpf_get_current_pid_tgid(...) 7ULL
#define bpf_get_current_uid_gid(...) 7ULL
#define bpf_perf_event_output(...) 7ULL
#define bpf_get_stackid(...) 7ULL
#define bpf_get_current_task(...) 7ULL
#define bpf_current_task_under_cgroup(...) 7ULL
#define bpf_get_current_cgroup_id(...) 7ULL
#define bpf_jiffies64(...) 7ULL
#define bpf_ktime_get_boot_ns(...) 7ULL
#define bpf_ringbuf_output(...) 7ULL
#define bpf_ktime_get_coarse_ns(...) 7ULL
#define bpf_get_func_ip(...) 7ULL
#define bpf_get_attach_cookie(...) 7ULL
unsigned long native_lab_entry_input(unsigned int k){return 0;}
static unsigned cases;
static int run(unsigned long long v,unsigned lane,unsigned kind){
 X86_SIM_ENTRY_RAW((void*)0); __x86_rsp.ptr=(void*)-120;
 X86_SIM_L_STACK_WRITE(-64,8,v);
 unsigned long long want=v;
 switch(kind){
 case 0:__x86_rbx.ptr=(void*)(unsigned long)v;X86_SIM_L_EXEC_PUSH(X86_RBX,8);__x86_rbx.ptr=0;X86_SIM_L_EXEC_POP(X86_RBX,8);if((unsigned long)__x86_rbx.ptr!=v)return 2;break;
 case 1:X86_SIM_L_STACK_WRITE(-64+(long)lane,1,0x5a);want=(want&~(255ULL<<(lane*8)))|(0x5aULL<<(lane*8));break;
 case 2:X86_SIM_L_STORE_ADDR_TAGGED((char*)X86_SIM_L_STACK_PTR(-64)+lane,1,0xa5,X86_SIM_TAG_STACK);want=(want&~(255ULL<<(lane*8)))|(0xa5ULL<<(lane*8));break;
 case 3:X86_SIM_L_HELPER_READONLY_SCALAR_RESULT(0);break;
 case 4:X86_SIM_L_HELPER_CLOBBERS();break;
 case 6:X86_SIM_BPF_CALL_bpf_ktime_get_ns();break;
case 7:X86_SIM_BPF_CALL_bpf_trace_printk();break;
case 8:X86_SIM_BPF_CALL_bpf_get_prandom_u32();break;
case 9:X86_SIM_BPF_CALL_bpf_get_smp_processor_id();break;
case 10:X86_SIM_BPF_CALL_bpf_get_current_pid_tgid();break;
case 11:X86_SIM_BPF_CALL_bpf_get_current_uid_gid();break;
case 12:X86_SIM_BPF_CALL_bpf_perf_event_output();break;
case 13:X86_SIM_BPF_CALL_bpf_get_stackid();break;
case 14:X86_SIM_BPF_CALL_bpf_get_current_task();break;
case 15:X86_SIM_BPF_CALL_bpf_current_task_under_cgroup();break;
case 16:X86_SIM_BPF_CALL_bpf_get_current_cgroup_id();break;
case 17:X86_SIM_BPF_CALL_bpf_jiffies64();break;
case 18:X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns();break;
case 19:X86_SIM_BPF_CALL_bpf_ringbuf_output();break;
case 20:X86_SIM_BPF_CALL_bpf_ktime_get_coarse_ns();break;
case 21:X86_SIM_BPF_CALL_bpf_get_func_ip();break;
case 22:X86_SIM_BPF_CALL_bpf_get_attach_cookie();break;
 case 23:__x86_rsp.ptr=(void*)-32;X86_SIM_L_STACK_RELEASE(-120);X86_SIM_L_STACK_WRITE(-64,8,v);__x86_rsp.ptr=(void*)-120;want=0;break;
 case 5:__x86_rsp.ptr=(void*)-32;X86_SIM_L_STACK_RELEASE(-128);__x86_rsp.ptr=(void*)-128;want=0;break;
 }
 unsigned long long raw=__x86_stack_mem.q[X86_SIM_L_STACK_INDEX(-64)/8];
 unsigned long long out=X86_SIM_L_STACK_READ(-64,8);
 unsigned long long alias=X86_SIM_L_LOAD_ADDR_TAGGED(X86_SIM_L_STACK_PTR(-64),8,X86_SIM_TAG_STACK);
 ++cases;if(out!=want||alias!=want||raw!=want){printf("mismatch kind%u lane%u raw%llx got%llx alias%llx want%llx\n",kind,lane,raw,out,alias,want);return 1;}return 0;
}
int main(void){unsigned long long values[]={0,1,0x1122334455667788ULL,~0ULL,1ULL<<63,0x0101010101010101ULL};for(unsigned v=0;v<6;v++)for(unsigned l=0;l<8;l++)for(unsigned k=0;k<24;k++)if(run(values[v],l,k))return 1;printf("scalar stack forwarding PASS %u whole-word/partial/alias/helper/release cases\n",cases);}
