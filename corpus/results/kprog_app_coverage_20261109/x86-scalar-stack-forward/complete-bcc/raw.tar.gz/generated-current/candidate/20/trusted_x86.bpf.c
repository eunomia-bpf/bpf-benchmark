#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 hists[] __ksym;
extern __u8 start[] __ksym;
static const __u8 __x86_rodata_0[120] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(19):.bss\",\"size\":120}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 119: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 119, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       __x86_ro_value = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       __x86_ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \
   __x86_ro_value; })

SEC("fentry/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5:
	/* 0x5: mov    rsi,QWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9:
	/* 0x9: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_c:
	/* 0xc: call   0 <sched_switch> */
	X86_SIM_X86_CALL(x86_l_19, 0x11ULL);
x86_l_11:
	/* 0x11: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13:
	/* 0x13: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: jmp    272 <handle_switch+0x259> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_272:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_19 */
x86_l_19:
	/* 0x19: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1b:
	/* 0x1b: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d:
	/* 0x1d: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e:
	/* 0x1e: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_22:
	/* 0x22: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_25:
	/* 0x25: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_28:
	/* 0x28: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d:
	/* 0x2d: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_32:
	/* 0x32: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_35:
	/* 0x35: call   3a <handle_switch+0x21> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_3a:
	/* 0x3a: cmp    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3f:
	/* 0x3f: jne    9e <handle_switch+0x85> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3f, 0x9e, x86_l_9e);
x86_l_41:
	/* 0x41: lea    rdx,[r14+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_48:
	/* 0x48: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4d:
	/* 0x4d: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_52:
	/* 0x52: call   57 <handle_switch+0x3e> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_57:
	/* 0x57: add    r14,0xaf0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_ADD, 2800ULL);
x86_l_5e:
	/* 0x5e: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_63:
	/* 0x63: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_68:
	/* 0x68: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_6b:
	/* 0x6b: call   70 <handle_switch+0x57> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_70:
	/* 0x70: mov    eax,DWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_74:
	/* 0x74: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_78:
	/* 0x78: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_7a:
	/* 0x7a: je     9e <handle_switch+0x85> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7a, 0x9e, x86_l_9e);
x86_l_7c:
	/* 0x7c: call   81 <handle_switch+0x68> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_81:
	/* 0x81: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_86:
	/* 0x86: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_8d:
	/* 0x8d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_92:
	/* 0x92: lea    rdx,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_97:
	/* 0x97: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_99:
	/* 0x99: call   9e <handle_switch+0x85> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_update_elem);
x86_l_9e:
	/* 0x9e: lea    rdx,[rbx+0xaf0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2800ULL);
x86_l_a5:
	/* 0xa5: lea    r14,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aa:
	/* 0xaa: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_ad:
	/* 0xad: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_b2:
	/* 0xb2: call   b7 <handle_switch+0x9e> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_b7:
	/* 0xb7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_be:
	/* 0xbe: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_c1:
	/* 0xc1: call   c6 <handle_switch+0xad> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c6:
	/* 0xc6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_c9:
	/* 0xc9: je     268 <handle_switch+0x24f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc9, 0x268, x86_l_268);
x86_l_cf:
	/* 0xcf: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_d2:
	/* 0xd2: call   d7 <handle_switch+0xbe> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_d7:
	/* 0xd7: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_da:
	/* 0xda: sub    r14,QWORD PTR [r15] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R14, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_dd:
	/* 0xdd: js     257 <handle_switch+0x23e> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0xdd, 0x257, x86_l_257);
x86_l_e3:
	/* 0xe3: mov    DWORD PTR [rsp+0x4],0xffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 21474836479ULL);
x86_l_eb:
	/* 0xeb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)hists));
x86_l_f2:
	/* 0xf2: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f7:
	/* 0xf7: call   fc <handle_switch+0xe3> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fc:
	/* 0xfc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ff:
	/* 0xff: je     1a8 <handle_switch+0x18f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xff, 0x1a8, x86_l_1a8);
x86_l_105:
	/* 0x105: cmp    BYTE PTR [rax+0x68],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_109:
	/* 0x109: jne    129 <handle_switch+0x110> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x109, 0x129, x86_l_129);
x86_l_10b:
	/* 0x10b: lea    rdi,[rax+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_10f:
	/* 0x10f: add    rbx,0xd10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 3344ULL);
x86_l_116:
	/* 0x116: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_11b:
	/* 0x11b: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_11e:
	/* 0x11e: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_121:
	/* 0x121: call   126 <handle_switch+0x10d> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel_str);
x86_l_126:
	/* 0x126: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_129:
	/* 0x129: shr    r14,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_12d:
	/* 0x12d: movabs rcx,0x20c49ba5e353f7cf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 2361183241434822607ULL);
x86_l_137:
	/* 0x137: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_13a:
	/* 0x13a: mulx   rcx,rcx,rcx */
	X86_SIM_L_EXEC_MULX(X86_RCX, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_13f:
	/* 0x13f: mov    rsi,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RCX, X86_WIDTH_64);
x86_l_142:
	/* 0x142: shr    rsi,0x24 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_SHR, 36ULL);
x86_l_146:
	/* 0x146: je     1f0 <handle_switch+0x1d7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x146, 0x1f0, x86_l_1f0);
x86_l_14c:
	/* 0x14c: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14e:
	/* 0x14e: cmp    esi,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 65536ULL);
x86_l_154:
	/* 0x154: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_157:
	/* 0x157: shl    edx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_15a:
	/* 0x15a: shrx   esi,esi,edx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDX, X86_ALU_SHR);
x86_l_15f:
	/* 0x15f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_161:
	/* 0x161: cmp    esi,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 256ULL);
x86_l_167:
	/* 0x167: setae  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_AE);
x86_l_16a:
	/* 0x16a: shl    ecx,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_16d:
	/* 0x16d: shrx   esi,esi,ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RCX, X86_ALU_SHR);
x86_l_172:
	/* 0x172: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_174:
	/* 0x174: cmp    esi,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_177:
	/* 0x177: setae  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_AE);
x86_l_17b:
	/* 0x17b: shl    edi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_17e:
	/* 0x17e: shrx   esi,esi,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_183:
	/* 0x183: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_186:
	/* 0x186: cmp    esi,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_189:
	/* 0x189: setae  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_AE);
x86_l_18d:
	/* 0x18d: add    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_ADD);
x86_l_190:
	/* 0x190: shrx   esi,esi,r8d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_R8, X86_ALU_SHR);
x86_l_195:
	/* 0x195: shr    esi,1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_197:
	/* 0x197: or     ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_OR);
x86_l_199:
	/* 0x199: or     ecx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDI, X86_WIDTH_32, X86_ALU_OR);
x86_l_19b:
	/* 0x19b: or     ecx,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_OR);
x86_l_19e:
	/* 0x19e: or     ecx,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RSI, X86_WIDTH_32, X86_ALU_OR);
x86_l_1a0:
	/* 0x1a0: add    ecx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 32ULL);
x86_l_1a3:
	/* 0x1a3: jmp    248 <handle_switch+0x22f> */
	X86_SIM_X86_SUB_JMP(0x1a3, 0x248, x86_l_248);
x86_l_1a8:
	/* 0x1a8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)hists));
x86_l_1af:
	/* 0x1af: lea    rdx,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1b6:
	/* 0x1b6: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bb:
	/* 0x1bb: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1c0:
	/* 0x1c0: call   1c5 <handle_switch+0x1ac> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1c5:
	/* 0x1c5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1c8:
	/* 0x1c8: je     1d4 <handle_switch+0x1bb> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c8, 0x1d4, x86_l_1d4);
x86_l_1ca:
	/* 0x1ca: cmp    rax,0xffffffffffffffef */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551599ULL);
x86_l_1ce:
	/* 0x1ce: jne    257 <handle_switch+0x23e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1ce, 0x257, x86_l_257);
x86_l_1d4:
	/* 0x1d4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)hists));
x86_l_1db:
	/* 0x1db: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1e0:
	/* 0x1e0: call   1e5 <handle_switch+0x1cc> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e5:
	/* 0x1e5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1e8:
	/* 0x1e8: jne    105 <handle_switch+0xec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e8, 0x105, x86_l_105);
x86_l_1ee:
	/* 0x1ee: jmp    257 <handle_switch+0x23e> */
	X86_SIM_X86_SUB_JMP(0x1ee, 0x257, x86_l_257);
x86_l_1f0:
	/* 0x1f0: shr    rcx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHR, 4ULL);
x86_l_1f4:
	/* 0x1f4: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f6:
	/* 0x1f6: cmp    ecx,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 65536ULL);
x86_l_1fc:
	/* 0x1fc: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_1ff:
	/* 0x1ff: shl    edx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_202:
	/* 0x202: shrx   esi,ecx,edx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RCX, X86_WIDTH_32, X86_RDX, X86_ALU_SHR);
x86_l_207:
	/* 0x207: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_209:
	/* 0x209: cmp    esi,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 256ULL);
x86_l_20f:
	/* 0x20f: setae  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_AE);
x86_l_212:
	/* 0x212: shl    ecx,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_215:
	/* 0x215: shrx   esi,esi,ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RCX, X86_ALU_SHR);
x86_l_21a:
	/* 0x21a: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_21c:
	/* 0x21c: cmp    esi,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_21f:
	/* 0x21f: setae  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_AE);
x86_l_223:
	/* 0x223: shl    edi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_226:
	/* 0x226: shrx   esi,esi,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_22b:
	/* 0x22b: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_22e:
	/* 0x22e: cmp    esi,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_231:
	/* 0x231: setae  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_AE);
x86_l_235:
	/* 0x235: add    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_ADD);
x86_l_238:
	/* 0x238: shrx   esi,esi,r8d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_R8, X86_ALU_SHR);
x86_l_23d:
	/* 0x23d: shr    esi,1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_23f:
	/* 0x23f: or     ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_OR);
x86_l_241:
	/* 0x241: or     ecx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDI, X86_WIDTH_32, X86_ALU_OR);
x86_l_243:
	/* 0x243: or     ecx,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_OR);
x86_l_246:
	/* 0x246: or     ecx,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RSI, X86_WIDTH_32, X86_ALU_OR);
x86_l_248:
	/* 0x248: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_24b:
	/* 0x24b: mov    edx,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_250:
	/* 0x250: cmovb  edx,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RCX, X86_WIDTH_32, X86_CC_B);
x86_l_253:
	/* 0x253: inc DWORD PTR [rax+rdx*4] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_RDX, 2, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_257:
	/* 0x257: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)start));
x86_l_25e:
	/* 0x25e: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_263:
	/* 0x263: call   268 <handle_switch+0x24f> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_268:
	/* 0x268: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_26c:
	/* 0x26c: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26d:
	/* 0x26d: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_26f:
	/* 0x26f: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_271:
	/* 0x271: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x11ULL: goto x86_l_11;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
