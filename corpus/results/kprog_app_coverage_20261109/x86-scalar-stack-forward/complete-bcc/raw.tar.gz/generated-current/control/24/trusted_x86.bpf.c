#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 136U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

extern __u8 do_count[] __ksym;
extern __u8 events[] __ksym;
extern __u8 filter_ports[] __ksym;
extern __u8 filter_ports_len[] __ksym;
extern __u8 ipv6_count[] __ksym;
extern __u8 sockets[] __ksym;
extern __u8 source_port[] __ksym;
static const __u8 __x86_rodata_0[280] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(11):.rodata\",\"size\":280}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 119: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 119, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 120: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 120, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 121: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 121, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 122: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 122, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 123: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 123, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 124: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 124, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 125: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 125, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 126: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 126, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 127: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 127, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 128: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 128, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 129: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 129, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 130: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 130, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 131: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 131, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 132: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 132, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 133: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 133, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 134: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 134, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 135: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 135, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 136: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 136, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 137: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 137, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 138: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 138, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 139: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 139, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 140: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 140, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 141: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 141, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 142: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 142, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 143: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 143, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 144: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 144, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 145: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 145, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 146: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 146, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 147: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 147, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 148: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 148, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 149: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 149, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 150: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 150, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 151: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 151, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 152: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 152, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 153: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 153, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 154: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 154, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 155: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 155, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 156: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 156, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 157: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 157, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 158: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 158, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 159: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 159, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 160: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 160, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 161: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 161, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 162: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 162, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 163: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 163, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 164: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 164, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 165: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 165, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 166: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 166, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 167: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 167, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 168: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 168, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 169: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 169, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 170: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 170, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 171: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 171, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 172: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 172, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 173: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 173, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 174: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 174, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 175: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 175, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 176: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 176, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 177: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 177, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 178: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 178, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 179: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 179, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 180: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 180, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 181: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 181, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 182: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 182, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 183: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 183, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 184: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 184, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 185: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 185, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 186: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 186, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 187: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 187, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 188: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 188, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 189: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 189, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 190: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 190, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 191: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 191, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 192: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 192, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 193: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 193, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 194: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 194, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 195: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 195, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 196: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 196, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 197: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 197, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 198: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 198, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 199: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 199, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 200: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 200, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 201: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 201, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 202: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 202, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 203: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 203, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 204: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 204, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 205: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 205, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 206: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 206, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 207: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 207, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 208: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 208, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 209: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 209, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 210: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 210, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 211: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 211, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 212: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 212, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 213: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 213, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 214: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 214, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 215: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 215, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 216: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 216, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 217: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 217, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 218: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 218, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 219: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 219, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 220: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 220, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 221: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 221, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 222: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 222, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 223: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 223, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 224: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 224, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 225: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 225, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 226: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 226, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 227: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 227, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 228: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 228, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 229: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 229, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 230: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 230, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 231: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 231, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 232: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 232, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 233: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 233, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 234: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 234, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 235: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 235, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 236: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 236, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 237: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 237, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 238: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 238, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 239: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 239, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 240: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 240, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 241: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 241, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 242: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 242, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 243: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 243, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 244: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 244, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 245: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 245, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 246: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 246, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 247: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 247, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 248: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 248, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 249: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 249, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 250: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 250, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 251: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 251, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 252: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 252, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 253: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 253, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 254: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 254, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 255: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 255, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 256: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 256, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 257: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 257, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 258: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 258, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 259: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 259, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 260: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 260, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 261: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 261, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 262: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 262, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 263: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 263, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 264: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 264, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 265: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 265, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 266: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 266, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 267: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 267, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 268: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 268, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 269: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 269, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 270: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 270, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 271: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 271, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 272: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 272, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 273: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 273, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 274: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 274, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 275: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 275, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 276: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 276, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 277: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 277, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 278: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 278, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 279: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 279, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 119: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 119, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 120: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 120, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 121: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 121, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 122: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 122, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 123: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 123, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 124: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 124, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 125: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 125, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 126: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 126, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 127: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 127, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 128: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 128, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 129: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 129, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 130: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 130, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 131: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 131, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 132: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 132, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 133: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 133, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 134: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 134, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 135: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 135, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 136: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 136, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 137: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 137, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 138: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 138, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 139: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 139, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 140: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 140, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 141: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 141, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 142: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 142, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 143: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 143, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 144: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 144, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 145: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 145, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 146: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 146, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 147: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 147, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 148: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 148, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 149: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 149, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 150: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 150, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 151: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 151, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 152: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 152, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 153: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 153, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 154: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 154, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 155: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 155, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 156: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 156, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 157: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 157, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 158: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 158, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 159: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 159, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 160: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 160, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 161: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 161, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 162: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 162, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 163: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 163, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 164: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 164, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 165: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 165, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 166: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 166, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 167: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 167, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 168: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 168, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 169: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 169, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 170: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 170, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 171: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 171, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 172: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 172, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 173: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 173, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 174: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 174, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 175: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 175, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 176: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 176, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 177: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 177, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 178: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 178, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 179: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 179, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 180: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 180, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 181: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 181, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 182: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 182, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 183: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 183, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 184: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 184, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 185: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 185, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 186: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 186, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 187: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 187, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 188: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 188, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 189: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 189, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 190: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 190, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 191: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 191, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 192: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 192, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 193: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 193, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 194: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 194, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 195: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 195, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 196: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 196, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 197: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 197, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 198: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 198, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 199: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 199, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 200: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 200, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 201: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 201, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 202: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 202, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 203: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 203, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 204: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 204, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 205: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 205, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 206: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 206, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 207: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 207, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 208: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 208, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 209: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 209, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 210: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 210, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 211: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 211, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 212: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 212, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 213: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 213, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 214: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 214, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 215: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 215, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 216: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 216, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 217: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 217, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 218: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 218, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 219: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 219, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 220: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 220, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 221: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 221, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 222: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 222, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 223: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 223, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 224: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 224, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 225: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 225, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 226: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 226, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 227: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 227, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 228: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 228, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 229: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 229, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 230: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 230, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 231: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 231, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 232: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 232, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 233: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 233, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 234: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 234, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 235: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 235, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 236: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 236, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 237: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 237, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 238: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 238, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 239: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 239, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 240: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 240, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 241: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 241, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 242: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 242, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 243: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 243, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 244: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 244, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 245: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 245, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 246: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 246, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 247: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 247, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 248: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 248, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 249: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 249, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 250: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 250, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 251: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 251, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 252: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 252, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 253: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 253, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 254: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 254, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 255: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 255, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 256: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 256, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 257: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 257, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 258: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 258, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 259: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 259, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 260: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 260, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 261: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 261, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 262: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 262, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 263: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 263, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 264: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 264, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 265: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 265, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 266: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 266, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 267: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 267, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 268: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 268, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 269: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 269, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 270: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 270, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 271: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 271, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 272: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 272, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 273: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 273, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 274: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 274, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 275: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 275, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 276: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 276, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 277: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 277, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 278: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 278, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 119: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 119, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 120: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 120, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 121: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 121, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 122: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 122, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 123: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 123, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 124: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 124, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 125: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 125, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 126: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 126, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 127: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 127, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 128: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 128, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 129: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 129, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 130: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 130, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 131: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 131, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 132: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 132, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 133: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 133, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 134: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 134, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 135: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 135, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 136: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 136, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 137: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 137, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 138: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 138, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 139: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 139, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 140: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 140, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 141: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 141, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 142: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 142, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 143: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 143, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 144: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 144, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 145: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 145, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 146: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 146, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 147: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 147, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 148: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 148, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 149: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 149, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 150: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 150, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 151: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 151, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 152: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 152, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 153: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 153, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 154: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 154, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 155: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 155, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 156: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 156, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 157: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 157, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 158: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 158, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 159: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 159, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 160: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 160, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 161: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 161, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 162: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 162, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 163: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 163, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 164: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 164, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 165: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 165, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 166: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 166, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 167: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 167, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 168: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 168, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 169: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 169, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 170: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 170, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 171: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 171, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 172: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 172, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 173: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 173, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 174: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 174, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 175: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 175, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 176: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 176, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 177: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 177, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 178: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 178, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 179: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 179, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 180: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 180, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 181: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 181, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 182: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 182, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 183: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 183, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 184: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 184, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 185: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 185, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 186: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 186, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 187: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 187, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 188: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 188, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 189: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 189, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 190: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 190, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 191: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 191, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 192: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 192, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 193: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 193, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 194: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 194, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 195: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 195, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 196: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 196, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 197: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 197, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 198: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 198, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 199: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 199, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 200: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 200, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 201: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 201, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 202: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 202, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 203: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 203, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 204: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 204, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 205: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 205, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 206: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 206, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 207: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 207, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 208: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 208, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 209: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 209, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 210: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 210, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 211: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 211, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 212: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 212, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 213: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 213, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 214: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 214, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 215: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 215, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 216: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 216, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 217: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 217, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 218: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 218, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 219: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 219, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 220: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 220, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 221: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 221, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 222: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 222, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 223: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 223, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 224: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 224, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 225: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 225, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 226: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 226, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 227: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 227, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 228: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 228, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 229: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 229, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 230: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 230, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 231: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 231, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 232: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 232, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 233: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 233, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 234: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 234, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 235: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 235, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 236: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 236, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 237: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 237, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 238: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 238, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 239: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 239, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 240: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 240, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 241: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 241, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 242: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 242, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 243: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 243, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 244: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 244, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 245: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 245, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 246: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 246, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 247: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 247, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 248: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 248, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 249: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 249, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 250: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 250, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 251: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 251, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 252: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 252, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 253: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 253, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 254: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 254, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 255: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 255, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 256: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 256, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 257: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 257, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 258: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 258, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 259: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 259, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 260: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 260, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 261: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 261, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 262: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 262, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 263: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 263, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 264: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 264, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 265: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 265, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 266: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 266, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 267: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 267, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 268: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 268, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 269: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 269, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 270: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 270, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 271: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 271, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 272: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 272, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 273: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 273, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 274: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 274, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 275: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 275, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 276: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 276, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 15, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 16, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 17, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 18, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 19, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 20, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 21, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 22, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 23, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 24, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 25, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 26, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 27, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 28, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 29, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 30, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 31, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 32, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 33, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 34, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 35, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 36, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 37, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 38, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 39, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 40, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 41, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 42, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 43, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 44, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 45, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 46, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 47, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 48, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 49, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 50, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 51, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 52, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 53, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 54, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 55, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 56, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 57, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 58, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 59, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 60, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 61, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 62, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 63, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 64, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 65, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 66, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 67, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 68, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 69, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 70, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 71, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 72, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 73, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 74, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 75, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 76, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 77, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 78, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 79, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 80: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 80, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 81: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 81, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 82: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 82, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 83: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 83, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 84: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 84, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 85: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 85, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 86: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 86, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 87: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 87, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 88: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 88, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 89: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 89, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 90: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 90, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 91: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 91, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 92: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 92, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 93: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 93, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 94: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 94, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 95: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 95, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 96: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 96, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 97: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 97, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 98: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 98, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 99: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 99, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 100: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 100, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 101: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 101, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 102: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 102, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 103: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 103, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 104: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 104, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 105: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 105, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 106: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 106, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 107: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 107, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 108: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 108, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 109: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 109, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 110: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 110, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 111: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 111, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 112: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 112, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 113: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 113, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 114: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 114, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 115: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 115, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 116: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 116, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 117: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 117, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 118: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 118, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 119: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 119, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 120: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 120, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 121: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 121, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 122: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 122, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 123: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 123, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 124: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 124, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 125: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 125, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 126: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 126, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 127: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 127, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 128: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 128, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 129: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 129, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 130: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 130, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 131: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 131, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 132: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 132, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 133: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 133, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 134: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 134, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 135: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 135, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 136: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 136, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 137: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 137, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 138: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 138, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 139: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 139, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 140: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 140, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 141: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 141, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 142: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 142, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 143: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 143, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 144: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 144, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 145: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 145, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 146: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 146, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 147: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 147, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 148: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 148, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 149: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 149, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 150: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 150, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 151: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 151, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 152: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 152, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 153: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 153, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 154: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 154, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 155: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 155, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 156: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 156, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 157: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 157, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 158: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 158, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 159: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 159, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 160: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 160, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 161: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 161, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 162: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 162, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 163: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 163, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 164: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 164, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 165: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 165, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 166: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 166, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 167: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 167, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 168: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 168, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 169: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 169, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 170: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 170, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 171: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 171, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 172: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 172, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 173: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 173, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 174: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 174, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 175: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 175, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 176: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 176, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 177: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 177, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 178: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 178, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 179: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 179, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 180: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 180, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 181: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 181, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 182: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 182, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 183: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 183, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 184: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 184, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 185: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 185, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 186: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 186, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 187: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 187, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 188: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 188, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 189: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 189, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 190: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 190, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 191: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 191, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 192: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 192, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 193: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 193, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 194: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 194, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 195: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 195, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 196: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 196, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 197: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 197, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 198: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 198, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 199: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 199, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 200: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 200, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 201: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 201, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 202: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 202, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 203: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 203, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 204: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 204, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 205: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 205, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 206: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 206, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 207: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 207, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 208: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 208, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 209: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 209, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 210: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 210, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 211: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 211, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 212: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 212, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 213: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 213, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 214: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 214, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 215: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 215, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 216: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 216, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 217: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 217, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 218: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 218, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 219: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 219, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 220: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 220, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 221: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 221, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 222: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 222, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 223: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 223, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 224: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 224, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 225: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 225, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 226: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 226, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 227: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 227, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 228: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 228, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 229: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 229, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 230: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 230, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 231: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 231, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 232: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 232, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 233: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 233, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 234: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 234, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 235: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 235, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 236: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 236, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 237: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 237, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 238: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 238, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 239: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 239, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 240: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 240, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 241: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 241, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 242: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 242, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 243: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 243, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 244: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 244, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 245: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 245, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 246: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 246, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 247: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 247, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 248: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 248, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 249: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 249, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 250: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 250, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 251: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 251, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 252: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 252, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 253: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 253, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 254: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 254, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 255: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 255, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 256: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 256, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 257: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 257, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 258: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 258, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 259: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 259, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 260: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 260, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 261: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 261, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 262: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 262, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 263: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 263, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 264: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 264, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 265: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 265, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 266: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 266, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 267: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 267, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 268: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 268, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 269: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 269, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 270: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 270, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 271: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 271, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 272: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 272, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       __x86_ro_value = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       __x86_ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \
   __x86_ro_value; })

SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 88ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_11:
	/* 0x11: mov    r14d,DWORD PTR [rdi+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_15:
	/* 0x15: call   1a <tcp_v6_connect_ret+0x1a> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1a:
	/* 0x1a: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1d:
	/* 0x1d: mov    DWORD PTR [rsp+0xc],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_22:
	/* 0x22: mov    WORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_29:
	/* 0x29: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)sockets));
x86_l_30:
	/* 0x30: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_35:
	/* 0x35: call   3a <tcp_v6_connect_ret+0x3a> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a:
	/* 0x3a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3d:
	/* 0x3d: je     55 <tcp_v6_connect_ret+0x55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d, 0x55, x86_l_55);
x86_l_3f:
	/* 0x3f: test   r14,r14 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64);
x86_l_42:
	/* 0x42: je     6a <tcp_v6_connect_ret+0x6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42, 0x6a, x86_l_6a);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)sockets));
x86_l_4b:
	/* 0x4b: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_50:
	/* 0x50: call   55 <tcp_v6_connect_ret+0x55> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_55:
	/* 0x55: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_57:
	/* 0x57: add    rsp,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_5b:
	/* 0x5b: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5c:
	/* 0x5c: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5e:
	/* 0x5e: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_60:
	/* 0x60: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_64:
	/* 0x64: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_65:
	/* 0x65: jmp    2c4 <tcp_v6_connect_ret+0x2c4> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_6a:
	/* 0x6a: mov    r14,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d:
	/* 0x6d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)source_port));
x86_l_74:
	/* 0x74: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_77:
	/* 0x77: je     8c <tcp_v6_connect_ret+0x8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x77, 0x8c, x86_l_8c);
x86_l_79:
	/* 0x79: lea    rdx,[r14+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_7d:
	/* 0x7d: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_82:
	/* 0x82: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_87:
	/* 0x87: call   8c <tcp_v6_connect_ret+0x8c> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_8c:
	/* 0x8c: lea    rdx,[r14+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_90:
	/* 0x90: lea    rdi,[rsp+0xa] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 10ULL);
x86_l_95:
	/* 0x95: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_9a:
	/* 0x9a: call   9f <tcp_v6_connect_ret+0x9f> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_9f:
	/* 0x9f: movzx  ebp,WORD PTR [rsp+0xa] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 10ULL);
x86_l_a4:
	/* 0xa4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)filter_ports_len));
x86_l_ab:
	/* 0xab: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ae:
	/* 0xae: je     e2 <tcp_v6_connect_ret+0xe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae, 0xe2, x86_l_e2);
x86_l_b0:
	/* 0xb0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b3:
	/* 0xb3: jle    44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xb3, 0x44, x86_l_44);
x86_l_b5:
	/* 0xb5: movzx  ecx,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_b8:
	/* 0xb8: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_ba:
	/* 0xba: mov    rsi,QWORD PTR [rip+0xfffffffffffffffc] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)filter_ports));
x86_l_c1:
	/* 0xc1: mov    edi,DWORD PTR [rsi+rdx*4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 2), 0ULL);
x86_l_c4:
	/* 0xc4: cmp    edi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_32);
x86_l_c6:
	/* 0xc6: je     e2 <tcp_v6_connect_ret+0xe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6, 0xe2, x86_l_e2);
x86_l_c8:
	/* 0xc8: movsxd rdi,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_cb:
	/* 0xcb: cmp    rdx,0x3e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 62ULL);
x86_l_cf:
	/* 0xcf: ja     44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JCC(X86_CC_A, 0xcf, 0x44, x86_l_44);
x86_l_d5:
	/* 0xd5: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_d8:
	/* 0xd8: cmp    rdx,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_db:
	/* 0xdb: jl     c1 <tcp_v6_connect_ret+0xc1> */
	X86_SIM_X86_JCC(X86_CC_L, 0xdb, 0xc1, x86_l_c1);
x86_l_dd:
	/* 0xdd: jmp    44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JMP(0xdd, 0x44, x86_l_44);
x86_l_e2:
	/* 0xe2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)do_count));
x86_l_e9:
	/* 0xe9: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ec:
	/* 0xec: movzx  r12d,WORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_f2:
	/* 0xf2: je     17f <tcp_v6_connect_ret+0x17f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf2, 0x17f, x86_l_17f);
x86_l_f8:
	/* 0xf8: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_100:
	/* 0x100: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_109:
	/* 0x109: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_112:
	/* 0x112: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_11b:
	/* 0x11b: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_124:
	/* 0x124: lea    rbx,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_129:
	/* 0x129: lea    rdx,[r14+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_12d:
	/* 0x12d: lea    r15,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_132:
	/* 0x132: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_135:
	/* 0x135: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_13a:
	/* 0x13a: call   13f <tcp_v6_connect_ret+0x13f> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_13f:
	/* 0x13f: add    r14,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_143:
	/* 0x143: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_146:
	/* 0x146: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_14b:
	/* 0x14b: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_14e:
	/* 0x14e: call   153 <tcp_v6_connect_ret+0x153> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_153:
	/* 0x153: mov    WORD PTR [rsp+0x30],r12w */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_159:
	/* 0x159: mov    WORD PTR [rsp+0x32],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 50ULL);
x86_l_15e:
	/* 0x15e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)ipv6_count));
x86_l_165:
	/* 0x165: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_168:
	/* 0x168: call   16d <tcp_v6_connect_ret+0x16d> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16d:
	/* 0x16d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_170:
	/* 0x170: je     279 <tcp_v6_connect_ret+0x279> */
	X86_SIM_X86_JCC(X86_CC_E, 0x170, 0x279, x86_l_279);
x86_l_176:
	/* 0x176: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_17a:
	/* 0x17a: jmp    44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JMP(0x17a, 0x44, x86_l_44);
x86_l_17f:
	/* 0x17f: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_183:
	/* 0x183: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_18c:
	/* 0x18c: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_195:
	/* 0x195: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_19e:
	/* 0x19e: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1a7:
	/* 0x1a7: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1b0:
	/* 0x1b0: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1b9:
	/* 0x1b9: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1c2:
	/* 0x1c2: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1cb:
	/* 0x1cb: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1d4:
	/* 0x1d4: lea    r13,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d9:
	/* 0x1d9: mov    DWORD PTR [rsp+0x48],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309237645322ULL);
x86_l_1e1:
	/* 0x1e1: mov    DWORD PTR [rsp+0x4c],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_1e6:
	/* 0x1e6: call   1eb <tcp_v6_connect_ret+0x1eb> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1eb:
	/* 0x1eb: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ef:
	/* 0x1ef: call   1f4 <tcp_v6_connect_ret+0x1f4> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_1f4:
	/* 0x1f4: shr    rax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_1f8:
	/* 0x1f8: movabs rcx,0x20c49ba5e353f7cf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 2361183241434822607ULL);
x86_l_202:
	/* 0x202: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_205:
	/* 0x205: mulx   rax,rax,rcx */
	X86_SIM_L_EXEC_MULX(X86_RAX, X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_20a:
	/* 0x20a: shr    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 4ULL);
x86_l_20e:
	/* 0x20e: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_213:
	/* 0x213: lea    rdx,[r14+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_217:
	/* 0x217: lea    r15,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21c:
	/* 0x21c: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_21f:
	/* 0x21f: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_224:
	/* 0x224: call   229 <tcp_v6_connect_ret+0x229> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_229:
	/* 0x229: add    r14,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_22d:
	/* 0x22d: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_230:
	/* 0x230: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_235:
	/* 0x235: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_238:
	/* 0x238: call   23d <tcp_v6_connect_ret+0x23d> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_23d:
	/* 0x23d: mov    WORD PTR [rsp+0x54],r12w */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_243:
	/* 0x243: mov    WORD PTR [rsp+0x56],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_248:
	/* 0x248: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_24d:
	/* 0x24d: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_252:
	/* 0x252: call   257 <tcp_v6_connect_ret+0x257> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_get_current_comm);
x86_l_257:
	/* 0x257: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)events));
x86_l_25e:
	/* 0x25e: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
x86_l_263:
	/* 0x263: mov    r8d,0x48 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 72ULL);
x86_l_269:
	/* 0x269: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_26c:
	/* 0x26c: mov    rcx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_64);
x86_l_26f:
	/* 0x26f: call   274 <tcp_v6_connect_ret+0x274> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_perf_event_output);
x86_l_274:
	/* 0x274: jmp    44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JMP(0x274, 0x44, x86_l_44);
x86_l_279:
	/* 0x279: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)ipv6_count));
x86_l_280:
	/* 0x280: lea    rdx,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (272))));
x86_l_287:
	/* 0x287: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c:
	/* 0x28c: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_291:
	/* 0x291: call   296 <tcp_v6_connect_ret+0x296> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_update_elem);
x86_l_296:
	/* 0x296: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_299:
	/* 0x299: je     2a5 <tcp_v6_connect_ret+0x2a5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x299, 0x2a5, x86_l_2a5);
x86_l_29b:
	/* 0x29b: cmp    rax,0xffffffffffffffef */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551599ULL);
x86_l_29f:
	/* 0x29f: jne    44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29f, 0x44, x86_l_44);
x86_l_2a5:
	/* 0x2a5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)ipv6_count));
x86_l_2ac:
	/* 0x2ac: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b1:
	/* 0x2b1: call   2b6 <tcp_v6_connect_ret+0x2b6> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b6:
	/* 0x2b6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2b9:
	/* 0x2b9: jne    176 <tcp_v6_connect_ret+0x176> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b9, 0x176, x86_l_176);
x86_l_2bf:
	/* 0x2bf: jmp    44 <tcp_v6_connect_ret+0x44> */
	X86_SIM_X86_JMP(0x2bf, 0x44, x86_l_44);
x86_l_2c4:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
