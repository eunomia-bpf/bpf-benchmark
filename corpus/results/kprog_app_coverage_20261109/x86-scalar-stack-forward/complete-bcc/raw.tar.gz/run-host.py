from pathlib import Path
import subprocess,json,os,hashlib
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');rows=[]
for compiler in ['gcc','clang-18']:
 for name,src in [('cache',G/'cache-host.c'),('exit',R/'kprog/formal/oracles/test_invocation_exit_host.c'),('output',R/'kprog/formal/oracles/test_stack_output_lifetime_host.c')]:
  exe=G/(compiler+'-'+name);cmd=[compiler,'-O2','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(G/'source'),'-I'+str(R),'-I/usr/include/x86_64-linux-gnu','-I'+str(R/'vendor/libbpf/src'),str(src),'-o',str(exe)]
  if compiler=='clang-18':cmd+=['-fno-sanitize-link-runtime','-lubsan']
  with(G/(compiler+'-'+name+'.compile.log')).open('w')as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  row=dict(compiler=compiler,name=name,command=cmd,compile_exit=p.returncode)
  if not p.returncode:
   with(G/(compiler+'-'+name+'.log')).open('w')as log:q=subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT)
   row['run_exit']=q.returncode
  rows.append(row);(G/'host-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows),flush=True)

for compiler in ['gcc','clang-18']:
 src=R/'kprog/formal/oracles/test_stack_output_lifetime_host.c';exe=G/(compiler+'-parent-output');cmd=[compiler,'-O2','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(G.parent/'parent-source'),'-I'+str(R),'-I/usr/include/x86_64-linux-gnu','-I'+str(R/'vendor/libbpf/src'),str(src),'-o',str(exe)]
 if compiler=='clang-18':cmd+=['-fno-sanitize-link-runtime','-lubsan']
 with(G/(compiler+'-parent-output.compile.log')).open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(compiler=compiler,name='parent-output',command=cmd,compile_exit=p.returncode)
 if not p.returncode:
  with(G/(compiler+'-parent-output.log')).open('w')as f:q=subprocess.run([str(exe)],stdout=f,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(G/'host-results.json').write_text(json.dumps(rows,indent=2)+'\n')
