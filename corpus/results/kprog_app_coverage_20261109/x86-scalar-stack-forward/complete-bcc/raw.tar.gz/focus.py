from pathlib import Path
import sys,json,subprocess,hashlib
G=Path(__file__).resolve().parent;A=G.parent;R=Path('/workspaces/repository');D=Path('/var/tmp/kprog-tmp/C/bcc-frozen-config-set-application');sys.path.insert(0,str(R/'kprog/x86'));from trusted_specializer import specialize
rows=[]
inputs=json.loads((A/'actual-inputs.json').read_text())
for label in ['control','candidate']:
 for item in inputs:
  if item['entry'] not in ['kprobe__cap_capable_entry','tracepoint__syscalls__sys_enter_open']:continue
  metadata=json.loads((A/'actual-inputs'/str(item['request_id'])/'generation.metadata.json').read_text());obj=D/(label+'-runtime')/'image/bcc'/item['object'];out=G/'focused'/label/str(item['request_id']);out.parent.mkdir(parents=True,exist_ok=True);row=dict(label=label,entry=item['entry'],native_sha256=hashlib.sha256(obj.read_bytes()).hexdigest())
  try:
   row['result']=specialize(obj.read_bytes(),item['entry'],metadata,out,R/'kprog/x86/native_lab/native_link/target/release/native-link');row['status']='compiled'
   commands=[json.loads(x)for x in(out/'commands.jsonl').read_text().splitlines()];cmd=next(x['command'] for x in commands if '-target' in x.get('command',[])and'-c'in x['command'])
   cmd[cmd.index('-c')]='-S';cmd.insert(cmd.index('-S')+1,'-emit-llvm');cmd[cmd.index('-o')+1]=str(out/'trusted_x86.ll');p=subprocess.run(cmd,capture_output=True,text=True);row['ir_exit']=p.returncode;(out/'ir.stderr').write_text(p.stderr)
  except BaseException as e:row.update(status='diagnostic',error=str(e))
  rows.append(row);(G/'focused.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['label'],row['entry'],row['status'],row.get('error'),flush=True)
