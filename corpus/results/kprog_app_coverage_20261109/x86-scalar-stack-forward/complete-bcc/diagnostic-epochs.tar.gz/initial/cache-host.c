#include <stdio.h>
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 128
#include "kprog/x86/x86_sim_local_bpf.h"
unsigned long native_lab_entry_input(unsigned int k){return 0;}
static unsigned cases;
static int run(unsigned long long v,unsigned lane,unsigned kind){
 X86_SIM_ENTRY_RAW((void*)0); __x86_rsp.ptr=(void*)-128;
 X86_SIM_L_STACK_WRITE(-64,8,v);
 unsigned long long want=v;
 switch(kind){
 case 0:break;
 case 1:X86_SIM_L_STACK_WRITE(-64+(long)lane,1,0x5a);want=(want&~(255ULL<<(lane*8)))|(0x5aULL<<(lane*8));break;
 case 2:X86_SIM_L_STORE_ADDR_TAGGED((char*)X86_SIM_L_STACK_PTR(-64)+lane,1,0xa5,X86_SIM_TAG_STACK);want=(want&~(255ULL<<(lane*8)))|(0xa5ULL<<(lane*8));break;
 case 3:X86_SIM_L_HELPER_READONLY_SCALAR_RESULT(0);break;
 case 4:X86_SIM_L_HELPER_CLOBBERS();break;
 case 5:__x86_rsp.ptr=(void*)-32;X86_SIM_L_STACK_RELEASE(-128);__x86_rsp.ptr=(void*)-128;want=0;break;
 }
 unsigned long long raw=__x86_stack_mem.q[X86_SIM_L_STACK_INDEX(-64)/8];
 unsigned long long out=X86_SIM_L_STACK_READ(-64,8);
 unsigned long long alias=X86_SIM_L_LOAD_ADDR_TAGGED(X86_SIM_L_STACK_PTR(-64),8,X86_SIM_TAG_STACK);
 ++cases;if(out!=want||alias!=want||raw!=want){printf("mismatch kind%u lane%u raw%llx got%llx alias%llx want%llx\n",kind,lane,raw,out,alias,want);return 1;}return 0;
}
int main(void){unsigned long long values[]={0,1,0x1122334455667788ULL,~0ULL,1ULL<<63,0x0101010101010101ULL};for(unsigned v=0;v<6;v++)for(unsigned l=0;l<8;l++)for(unsigned k=0;k<6;k++)if(run(values[v],l,k))return 1;printf("scalar stack forwarding PASS %u whole-word/partial/alias/helper/release cases\n",cases);}
