from pathlib import Path
from collections import OrderedDict,Counter
import importlib.util,json,sys,hashlib
B=Path(__file__).resolve().parent;version=sys.argv[1];root=B/version
sys.path[:0]=[str(root/'kprog/arm64/micro-prog'),str(root/'kprog')]
spec=importlib.util.spec_from_file_location('arm_join_generator',root/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py')
g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
def instructions(opaque=False,offset=8,helper='bpf_probe_read_kernel',reverse=False):
 rows=[];labels={};relocs={}
 def emit(op,*args,reloc=None):
  if reloc:relocs[len(rows)]=reloc
  rows.append((op,args))
 def label(name):labels[name]=len(rows)*4
 emit('sub','sp','sp','#96')
 emit('str','x30','[sp, #88]')
 emit('mov','x20','x0')
 if not opaque:emit('mov','x3','#42')
 emit('str','x19' if opaque else 'x3',f'[sp, #{offset}]')
 emit('cbz','x20','external' if not reverse else 'stack')
 def stack():
  emit('add','x2','sp',f'#{offset}')
  emit('str','x2','[sp, #40]')
 def external():
  emit('mov','x2','x20');emit('add','x0','sp','#40');emit('mov','w1','#8');emit('bl','0',reloc=helper)
 (stack if not reverse else external)();emit('b','join')
 label('external' if not reverse else 'stack')
 (external if not reverse else stack)()
 label('join')
 emit('ldr','x2','[sp, #40]')
 emit('add','x0','sp','#64');emit('mov','w1','#8');emit('bl','0',reloc=helper)
 emit('ldr','w0','[sp, #64]');emit('ldr','x30','[sp, #88]');emit('add','sp','sp','#96');emit('ret')
 insns=[]
 for i,(op,args) in enumerate(rows):
  args=tuple(f'{labels[a]:x}' if a in labels else a for a in args)
  insns.append(g.NativeInsn(i*4,op,args,op+' '+', '.join(args),relocs.get(i)))
 return insns
rows=[]
for helper in ['bpf_probe_read','bpf_probe_read_user','bpf_probe_read_kernel','bpf_copy_from_user']:
 for offset in [0,8,16,24]:
  for reverse in [False,True]:
   for opaque in [False,True]:
    insns=instructions(opaque,offset,helper,reverse)
    try:
     result=g.check_definedness(insns,g.indirect_targets(insns),False,g)
    except ValueError as exc:
     actual='undefined' if 'undefined native ABI register w0' in str(exc) else 'unresolved' if 'native helper source stack relation unresolved' in str(exc) else 'other'
     error=str(exc);result=None
    else:actual='accepted';error=''
    expected='undefined' if opaque else 'accepted'
    rows.append(dict(helper=helper,offset=offset,reverse=reverse,opaque=opaque,expected=expected,actual=actual,error=error,layout=result))
counts=Counter(r['actual'] for r in rows);mismatch=[r for r in rows if r['actual']!=r['expected']]
report={'source_version':version,'cases':len(rows),'outcomes':dict(counts),'mismatches':len(mismatch),'rows':rows}
(B/(version+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
if version=='before':
 assert all(r['actual']=='unresolved' for r in rows),rows
else:assert not mismatch,mismatch[:2]
