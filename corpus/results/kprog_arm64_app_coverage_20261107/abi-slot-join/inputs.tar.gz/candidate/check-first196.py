from pathlib import Path
from collections import OrderedDict,Counter
import importlib.util,json,sys,hashlib
B=Path(__file__).resolve().parent;version=sys.argv[1];root=B/version
sys.path[:0]=[str(root/'kprog/arm64/micro-prog'),str(root/'kprog')]
spec=importlib.util.spec_from_file_location('arm_join_generator',root/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py')
g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
def instructions(opaque=False,offset=8,helper='bpf_probe_read_kernel',reverse=False,mode='mixed'):
 rows=[];labels={};relocs={}
 def emit(op,*args,reloc=None):
  if reloc:relocs[len(rows)]=reloc
  rows.append((op,args))
 def label(name):labels[name]=len(rows)*4
 emit('sub','sp','sp','#96')
 emit('str','x30','[sp, #88]')
 emit('mov','x20','x0')
 if not opaque:emit('mov','x3','#42')
 emit('str','x19' if opaque else 'x3',f'[sp, #{offset}]')
 emit('cbz','x20','external' if not reverse else 'stack')
 def stack():
  emit('add','x2','sp',f'#{offset}')
  emit('str','x2','[sp, #40]')
 def external():
  emit('mov','x2','x20');emit('add','x0','sp','#40');emit('mov','w1','#8');emit('bl','0',reloc=helper)
 left,right=(stack,external) if mode=='mixed' else (stack,stack) if mode=='stack' else (external,external)
 (left if not reverse else right)();emit('b','join')
 label('external' if not reverse else 'stack')
 (right if not reverse else left)()
 label('join')
 emit('ldr','x2','[sp, #40]')
 emit('add','x0','sp','#64');emit('mov','w1','#8');emit('bl','0',reloc=helper)
 emit('ldr','w0','[sp, #64]');emit('ldr','x30','[sp, #88]');emit('add','sp','sp','#96');emit('ret')
 insns=[]
 for i,(op,args) in enumerate(rows):
  args=tuple(f'{labels[a]:x}' if a in labels else a for a in args)
  insns.append(g.NativeInsn(i*4,op,args,op+' '+', '.join(args),relocs.get(i)))
 return insns
rows=[]
def exercise(insns,expected,fields):
 try:
  result=g.check_definedness(insns,g.indirect_targets(insns),False,g)
  rendered=g.render_program("abi_join","entry",OrderedDict(entry=insns),"raw",linked_exit=False,program_section="kprobe/trusted")
 except ValueError as exc:
  actual='undefined' if 'undefined native ABI register w0' in str(exc) else 'unresolved' if 'native helper source stack relation unresolved' in str(exc) else 'other'
  error=str(exc);result=None;digest=None
 else:actual='accepted';error='';digest=hashlib.sha256(rendered.encode()).hexdigest()
 rows.append(dict(fields,expected=expected,actual=actual,error=error,layout=result,rendered_source_sha256=digest))
for helper in ['bpf_probe_read','bpf_probe_read_user','bpf_probe_read_kernel','bpf_copy_from_user']:
 for offset in [0,8,16,24]:
  for reverse in [False,True]:
   for opaque in [False,True]:
    for mode in ['mixed','stack','external']:
     expected='undefined' if opaque and mode!='external' else 'accepted'
     exercise(instructions(opaque,offset,helper,reverse,mode),expected,dict(helper=helper,offset=offset,reverse=reverse,opaque=opaque,mode=mode))
# Explicit unknown origins survive the same load/join path and retain rejection.
for helper in ['bpf_probe_read','bpf_probe_read_user','bpf_probe_read_kernel','bpf_copy_from_user']:
 insns=instructions(False,8,helper,False,'stack')
 at=next(i for i,x in enumerate(insns) if x.mnemonic=='ldr' and x.operands[0]=='x2')
 extra=[('cmp',('x20','#0')),('csel',('x2','x20','sp','eq')),('add',('x2','x2','#8')),('str',('x2','[sp, #40]'))]
 # Insert immediately before the joined-slot load and relocate actual branch targets.
 shift=len(extra)*4;old_pc=insns[at].addr
 moved=[]
 for x in insns:
  args=tuple(f'{int(a,16)+shift:x}' if x.mnemonic in {'b','cbz'} and j==len(x.operands)-1 and int(a,16)>=old_pc else a for j,a in enumerate(x.operands))
  moved.append(g.NativeInsn(x.addr+shift if x.addr>=old_pc else x.addr,x.mnemonic,args,x.raw,x.reloc_symbol))
 added=[g.NativeInsn(old_pc+i*4,op,args,op+' '+', '.join(args)) for i,(op,args) in enumerate(extra)]
 # The branch join enters the inserted operation block.
 moved=[g.NativeInsn(x.addr,x.mnemonic,tuple(f'{old_pc:x}' if x.mnemonic=='b' and a==f'{old_pc+shift:x}' else a for a in x.operands),x.raw,x.reloc_symbol) for x in moved]
 exercise(moved[:at]+added+moved[at:],'unresolved',dict(helper=helper,mode='explicit_unknown'))
counts=Counter(r['actual'] for r in rows);mismatch=[r for r in rows if r['actual']!=r['expected']]
report={'source_version':version,'cases':len(rows),'outcomes':dict(counts),'mismatches':len(mismatch),'rows':rows}
(B/(version+'.json')).write_text(json.dumps(report,indent=2)+chr(10))
print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
if version=='before':
 assert len(mismatch)==64 and all(r['mode']=='mixed' and r['actual']=='unresolved' for r in mismatch),mismatch[:2]
else:assert not mismatch,mismatch[:2]
