; ModuleID = '/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261107/tetragon-mixed-probe/native.ll'
source_filename = "bpf-source"

@__native_source_map_3 = external global [0 x i8]

define noundef i64 @bpf_main(ptr %0) local_unnamed_addr {
setupBlock:
  %1 = ptrtoint ptr %0 to i64
  %2 = tail call i64 @bpf_tail_call(i64 %1, i64 ptrtoint (ptr @__native_source_map_3 to i64), i64 0)
  ret i64 0
}

declare i64 @bpf_tail_call(i64, i64, i64) local_unnamed_addr

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @__llvmbpf_pseudo_call_pc_00000009(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4) local_unnamed_addr #0 {
setupBlock:
  ret i64 0
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
