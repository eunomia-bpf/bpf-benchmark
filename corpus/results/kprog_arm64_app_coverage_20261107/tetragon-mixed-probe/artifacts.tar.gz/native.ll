; ModuleID = 'bpf-source'
source_filename = "bpf-source"


define i64 @bpf_main(ptr %0) {
setupBlock:
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 0, ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  store i64 0, ptr %r4, align 4
  store i64 0, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, i32 8, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 8
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %0, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  %1 = load i64, ptr %r1, align 4
  store i64 %1, ptr %r6, align 4
  %2 = load i64, ptr %r1, align 4
  %3 = load i64, ptr %r2, align 4
  %4 = load i64, ptr %r3, align 4
  %5 = load i64, ptr %r4, align 4
  %6 = load i64, ptr %r5, align 4
  %7 = call i64 @__llvmbpf_pseudo_call_pc_00000009(i64 %2, i64 %3, i64 %4, i64 %5, i64 %6)
  store i64 %7, ptr %r0, align 4
  br label %bb_inst_2

bb_inst_2:                                        ; preds = %bb_inst_0
  %8 = load i64, ptr %r6, align 4
  store i64 %8, ptr %r1, align 4
  store i64 ptrtoint (ptr @__native_source_map_3 to i64), ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  %9 = load i64, ptr %r1, align 4
  %10 = load i64, ptr %r2, align 4
  %11 = load i64, ptr %r3, align 4
  %12 = call i64 @bpf_tail_call(i64 %9, i64 %10, i64 %11)
  br label %bb_inst_7

bb_inst_7:                                        ; preds = %bb_inst_2
  store i64 0, ptr %r0, align 4
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_7
  %13 = load i64, ptr %r0, align 4
  ret i64 %13
}

declare i64 @bpf_tail_call(i64, i64, i64)

define i64 @__llvmbpf_pseudo_call_pc_00000009(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4) {
setupBlock:
  %5 = inttoptr i64 %0 to ptr
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 %1, ptr %r2, align 4
  store i64 %2, ptr %r3, align 4
  store i64 %3, ptr %r4, align 4
  store i64 %4, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, i32 8, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 8
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %5, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  store i64 0, ptr %r0, align 4
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_0
  %6 = load i64, ptr %r0, align 4
  ret i64 %6
}

@__native_source_map_3 = external global [0 x i8]
