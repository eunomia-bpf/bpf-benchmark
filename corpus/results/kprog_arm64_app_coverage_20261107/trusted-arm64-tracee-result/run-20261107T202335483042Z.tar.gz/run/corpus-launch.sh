#!/bin/sh
set -eu
export BPFREJIT_INSIDE_RUNTIME_CONTAINER=1 HOME=/root TARGET='arm64-qemu' RUN_TARGET_NAME='arm64-qemu' RUN_TARGET_ARCH='arm64' RUN_EXECUTOR='kvm' RUNTIME_CONTAINER_IMAGE='bpf-benchmark/runner-runtime:arm64-a-context-v35' RUNTIME_IMAGE_TAR='/workspaces/repository/kprog/arm64/build/app-runtime-v35/image.tar' RUN_REMOTE_PYTHON_BIN='python3' RUN_RUNTIME_PYTHON_BIN='python3' RUN_BPFTOOL_BIN='bpftool' RUN_NATIVE_REPOS_CSV='bcc,katran,tracee,tetragon' RUN_TOKEN='86ddf06c' SAMPLES='1'      FUZZ_ROUNDS='1000'  WORKLOAD_DURATION='2' KEEP_WORKDIRS='1'  BPFREJIT_CORPUS_APPS='bcc/set'           MERLIN_COMPILETIME_MODE='none' BPFREJIT_CORPUS_APP_TIMEOUT='7200'   BPFREJIT_CORPUS_BPF_STATS='1'  BPFREJIT_SHIM_NATIVE_LOADER='post'      BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1'         CILIUM_PROFILE_ARM='all'   
export BPFREJIT_CORPUS_APPS=tracee/monitor
exec python3 -m corpus.driver
