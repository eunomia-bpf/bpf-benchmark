#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <linux/bpf.h>
struct prog_entry { char name[16]; uint32_t insn_cnt,prog_type,expected_attach_type,attach_btf_id; uint64_t hash,policy_hash; };
static uint64_t fnv1a64_update_state(uint64_t h, const void *data, size_t len) {
    const uint8_t *p = (const uint8_t *)data;
    for (size_t i = 0; i < len; i++) {
        h ^= p[i];
        h *= 0x100000001b3ULL;
    }
    return h;
}

static uint64_t fnv1a64(const void *data, size_t len) {
    return fnv1a64_update_state(0xcbf29ce484222325ULL, data, len);
}

static uint64_t normalized_load_hash(const struct bpf_insn *insns,
                                     uint32_t insn_cnt) {
    uint64_t h = 0xcbf29ce484222325ULL;
    for (uint32_t pc = 0; pc < insn_cnt; pc++) {
        struct bpf_insn copy = insns[pc];
        if (copy.code == (BPF_LD | BPF_DW | BPF_IMM) &&
            (copy.src_reg == BPF_PSEUDO_MAP_FD ||
             copy.src_reg == BPF_PSEUDO_MAP_VALUE ||
             copy.src_reg == BPF_PSEUDO_MAP_IDX ||
             copy.src_reg == BPF_PSEUDO_MAP_IDX_VALUE)) {
            copy.imm = 0;
            h = fnv1a64_update_state(h, &copy, sizeof(copy));
            if (pc + 1 < insn_cnt) {
                struct bpf_insn next = insns[++pc];
                next.imm = 0;
                h = fnv1a64_update_state(h, &next, sizeof(next));
            }
            continue;
        }
        h = fnv1a64_update_state(h, &copy, sizeof(copy));
    }
    return h;
}

static int shim_native_loader_is_libbpf_probe(const struct prog_entry *prog) {
    const char *name = prog ? prog->name : "";
    uint32_t insn_cnt = prog ? prog->insn_cnt : 0;

    if ((!name || !name[0]) && insn_cnt <= 2)
        return 1;
    if (prog && (!name || !name[0]) && insn_cnt <= 4 &&
        (prog->prog_type == BPF_PROG_TYPE_CGROUP_SOCK ||
         prog->prog_type == BPF_PROG_TYPE_CGROUP_SOCK_ADDR ||
         prog->prog_type == BPF_PROG_TYPE_CGROUP_SOCKOPT ||
         prog->prog_type == BPF_PROG_TYPE_XDP ||
         prog->prog_type == BPF_PROG_TYPE_SCHED_CLS ||
         prog->prog_type == BPF_PROG_TYPE_SCHED_ACT)) {
        return 1;
    }
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_SOCKET_FILTER &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt <= 5)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_TRACEPOINT &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt <= 6)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 11 && prog->policy_hash == 0x7f60b6fbd3faebcfULL)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_TRACING &&
        prog->expected_attach_type != 0 && prog->attach_btf_id != 0 &&
        insn_cnt == 3 && prog->hash == 0x145b4e38542e17e8ULL)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_KPROBE &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt <= 6)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_LSM &&
        prog->expected_attach_type == BPF_LSM_MAC &&
        prog->attach_btf_id != 0 && insn_cnt == 3 &&
        prog->hash == 0x145b4e38542e17e8ULL)
        return 1;
    if (name && strcmp(name, "libbpf_nametest") == 0 && insn_cnt <= 2)
        return 1;
    if (name && strcmp(name, "det_arg_ctx") == 0 && insn_cnt <= 4)
        return 1;
    if (prog && name && strcmp(name, "test") == 0 &&
        prog->prog_type == BPF_PROG_TYPE_XDP && prog->expected_attach_type == 0 &&
        prog->attach_btf_id == 0 && insn_cnt == 6 &&
        prog->hash == 0xf2c52b5b17d11f48ULL)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_SOCKET_FILTER &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 4097 && prog->hash == 0xdad2efe83d9579b0ULL)
        return 1;
    if (prog && name && strcmp(name, "probe_fib_looku") == 0 &&
        prog->prog_type == BPF_PROG_TYPE_SCHED_CLS &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 23 && (prog->hash == 0xf436d54fbd8c7ea7ULL ||
                           prog->hash == 0xca5c856e97173b3bULL ||
                           prog->hash == 0xb81a739a980c3e63ULL))
        return 1;
    if (prog && name && strcmp(name, "adjust_mac_room") == 0 &&
        prog->prog_type == BPF_PROG_TYPE_SCHED_CLS &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 5 && prog->hash == 0x708e759c87fe3b92ULL)
        return 1;
    if (prog && name &&
        (strcmp(name, "probe_bpf_kprob") == 0 ||
         strcmp(name, "probe_bpf_perf_") == 0 ||
         strcmp(name, "probe_kpm_link") == 0 ||
         strcmp(name, "probe_upm_link") == 0 ||
         strcmp(name, "probe_fmod_ret") == 0 ||
         strcmp(name, "probe_sys_fmod_") == 0 ||
         strcmp(name, "probe_lsm_file_") == 0 ||
         strcmp(name, "probe_get_func_") == 0 ||
         strcmp(name, "uprobe_regs") == 0) &&
        insn_cnt <= 6)
        return 1;
    return 0;
}


int main(void) {
 unsigned identity_errors=0,boundary_errors=0,normalized_errors=0,checks=0;
 struct prog_entry p={.insn_cnt=11,.prog_type=BPF_PROG_TYPE_RAW_TRACEPOINT,.policy_hash=0x7f60b6fbd3faebcfULL};
 for(unsigned i=0;i<258;i++){p.hash=i==257?0x71725f032fe1d5e4ULL:(0x9e3779b97f4a7c15ULL*i);identity_errors+=!shim_native_loader_is_libbpf_probe(&p);checks++;}
 p.hash=0x71725f032fe1d5e4ULL;
 for(unsigned i=0;i<64;i++){p.policy_hash=0x7f60b6fbd3faebcfULL^(1ULL<<i);boundary_errors+=shim_native_loader_is_libbpf_probe(&p);checks++;}
 p.policy_hash=0x7f60b6fbd3faebcfULL;
 p.name[0]='x';boundary_errors+=shim_native_loader_is_libbpf_probe(&p);checks++;p.name[0]=0;
 p.expected_attach_type=1;boundary_errors+=shim_native_loader_is_libbpf_probe(&p);checks++;p.expected_attach_type=0;
 p.attach_btf_id=1;boundary_errors+=shim_native_loader_is_libbpf_probe(&p);checks++;p.attach_btf_id=0;
 p.insn_cnt=12;boundary_errors+=shim_native_loader_is_libbpf_probe(&p);checks++;
 const unsigned kinds[]={BPF_PSEUDO_MAP_FD,BPF_PSEUDO_MAP_VALUE,BPF_PSEUDO_MAP_IDX,BPF_PSEUDO_MAP_IDX_VALUE};
 for(unsigned k=0;k<4;k++)for(unsigned fd=0;fd<4096;fd++){
 struct bpf_insn v[3]={{.code=BPF_LD|BPF_DW|BPF_IMM,.dst_reg=2,.src_reg=kinds[k],.imm=(int)fd},{0},{.code=BPF_JMP|BPF_EXIT}};
 uint64_t raw=fnv1a64(v,sizeof(v));uint64_t x=normalized_load_hash(v,3);v[0].imm=0;uint64_t y=normalized_load_hash(v,3);normalized_errors+=x!=y;normalized_errors+=(fd && raw==fnv1a64(v,sizeof(v)));checks++;
 v[0].off=1;normalized_errors+=normalized_load_hash(v,3)==y;checks++;
 }
 printf("{\"checks\":%u,\"descriptor_identity_errors\":%u,\"metadata_boundary_errors\":%u,\"normalized_hash_errors\":%u}\n",checks,identity_errors,boundary_errors,normalized_errors);
 return identity_errors||boundary_errors||normalized_errors;
}
