#!/bin/sh
cd /workspaces/.agent-state/kprog-lanes/A/probe-map-fd
make -f Makefile > regression-build.log 2>&1
r=$?
if [ "$r" = 0 ]; then
 ./before > before.json
 echo $? > before.exit
 ./after > after.json
 r=$?
fi
echo "$r" > regression.exit
if [ "$r" = 0 ]; then
 make -C /workspaces/repository/bpfopt/shim SHIM_SO="$PWD/shim-x86.so" "$PWD/shim-x86.so" > x86-build.log 2>&1
 r=$?
fi
if [ "$r" = 0 ]; then
 make -C /workspaces/repository/bpfopt/shim CC=aarch64-linux-gnu-gcc SHIM_SO="$PWD/shim-arm64.so" "$PWD/shim-arm64.so" > arm64-build.log 2>&1
 r=$?
fi
echo "$r" > build.exit
exit "$r"
