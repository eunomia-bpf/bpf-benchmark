set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/tracee-core-refresh/source/tracee-c /workspaces/repository/vendor/bpf/tracee/pkg/ebpf/c
mount --bind /workspaces/.agent-state/kprog-lanes/A/tracee-core-refresh/source/Makefile /workspaces/repository/vendor/bpf/Makefile
mount --bind /workspaces/.agent-state/kprog-lanes/A/tracee-core-refresh/source/native_compat.h /workspaces/repository/vendor/bpf/native_compat.h
exec taskset -c 16-19 make -C vendor/bpf ARCH=arm64 NATIVE_OUT=/workspaces/repository/kprog/arm64/build/tracee-core-native /workspaces/repository/kprog/arm64/build/tracee-core-native/tracee/tracee.native.o /workspaces/repository/kprog/arm64/build/tracee-core-native/tracee/lsm_support/kprobe_check.native.o /workspaces/repository/kprog/arm64/build/tracee-core-native/tracee/lsm_support/lsm_check.native.o
