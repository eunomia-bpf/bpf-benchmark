set +e
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/tracee-core-refresh/inside.sh >/workspaces/.agent-state/kprog-lanes/A/tracee-core-refresh/build.log 2>&1
rc=$?
echo "$rc" >/workspaces/.agent-state/kprog-lanes/A/tracee-core-refresh/exit
exit "$rc"
