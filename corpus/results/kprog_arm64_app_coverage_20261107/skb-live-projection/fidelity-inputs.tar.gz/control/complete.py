from pathlib import Path
import csv,gzip,hashlib,importlib.util,json,os,select,shlex,subprocess,tarfile,datetime,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/skb-live-projection'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(N/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def fd_for(pid):
 try:return os.pidfd_open(pid)
 except ProcessLookupError:return None
def wait(fd):
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
spec=importlib.util.spec_from_file_location('skb_pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
full_fd=fd_for(int((N/'fidelity.pid').read_text()));app_fd=fd_for(4075266)
try:
 save('waiting_fidelity',fidelity_pid=int((N/'fidelity.pid').read_text()),application_predecessor=4075266)
 wait(full_fd);rc=int((N/'fidelity.exit').read_text());F=N/'fidelity';s=json.loads((D/'summary.json').read_text())
 rows=list(csv.DictReader((F/'forms.tsv').open(),delimiter='\t'));ref=list(csv.DictReader((F/'reference-forms.tsv').open(),delimiter='\t')) if (F/'reference-forms.tsv').exists() else []
 full=dict(returncode=rc,forms=len(rows),cpu_cases=sum(int(x['cases']) for x in rows),cpu_mismatches=sum(int(x['mismatches']) for x in rows),reference_cases=sum(int(x['reference_cases']) for x in ref),cpu_reference_mismatches=sum(int(x['cpu_mismatches']) for x in ref),simulator_reference_mismatches=sum(int(x['simulator_mismatches']) for x in ref),awaiting_reference=sum(x['status']!='checked' for x in ref),trace_bytes=(F/'cpu-states.bin').stat().st_size,trace_sha256=sha(F/'cpu-states.bin'),binary_sha256=sha(R/'kprog/fidelity/build-arm64/cpu-differential'))
 if rc==0:
  assert full['forms']==807 and full['cpu_cases']==full['reference_cases']==826368 and full['cpu_mismatches']==full['cpu_reference_mismatches']==full['simulator_reference_mismatches']==full['awaiting_reference']==0
  assert all((F/n).stat().st_size==0 for n in ['mismatches.jsonl','reference-mismatches.jsonl','reference-unavailable.jsonl'])
 raw=subprocess.check_output(['aarch64-linux-gnu-gcc','-MM','-I../../vendor/libbpf/src','-I../../vendor/libbpf/include/uapi','build-arm64/generated.c'],cwd=R/'kprog/fidelity',text=True)
 deps=[(R/'kprog/fidelity'/x).resolve() for x in shlex.split(raw.replace(chr(92)+chr(10),' ').split(':',1)[1])]
 deps += [R/'kprog/fidelity'/x for x in ['driver.c','driver.h','build-arm64/native.S','build-arm64/cpu-differential']]
 inputs={};payload={}
 for p in sorted(set(deps)):
  if not p.is_relative_to(R):continue
  key=str(p.relative_to(R));b=(N/'after.h').read_bytes() if key=='kprog/arm64/arm64_sim_local_bpf.h' else p.read_bytes();payload[key]=b;inputs[key]=dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
 header_keys=[k for k in inputs if k.endswith('/snapshot/kprog/arm64/arm64_sim_local_bpf.h')]
 assert len(header_keys)==1 and inputs[header_keys[0]]['sha256']==s['source_after_sha256']
 baseline=json.loads((N/'input-pins.json').read_text())
 for key,pin in inputs.items():
  if '/snapshot/' in key:
   original=key.split('/snapshot/',1)[1]
   if original in baseline:assert pin['sha256']==(s['source_after_sha256'] if original=='kprog/arm64/arm64_sim_local_bpf.h' else baseline[original]),original
 full['frozen_header_path']=header_keys[0]
 (N/'compiled-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 with tarfile.open(D/'fidelity-inputs.tar.gz','w:gz') as t:
  import io
  for key,b in payload.items():info=tarfile.TarInfo('source/'+key);info.size=len(b);t.addfile(info,io.BytesIO(b))
  for n in ['complete.py','compiled-inputs.json','fidelity-launch.json','fidelity.sh']:t.add(N/n,arcname='control/'+n)
 with tarfile.open(D/'fidelity-raw.tar.gz','w:gz') as t:
  for n in ['forms.tsv','host.txt','mismatches.jsonl','native-code.json','reference-forms.tsv','reference-mismatches.jsonl','reference-unavailable.jsonl']:
   if (F/n).exists():t.add(F/n,arcname=n)
  t.add(N/'fidelity.log',arcname='driver.log');t.add(N/'fidelity.exit',arcname='driver.exit');t.add(N/'collector-setup.tar.gz',arcname='collector-setup.tar.gz')
 full['compiled_source_files']=len(inputs);s['fidelity']['canonical_phase']='closed';s['fidelity']['completed']=full
 (D/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
 with (D/'README.md').open('a') as f:f.write('\nCompleted differential collection: Make exit'+str(rc)+', '+str(full['forms'])+' forms/'+str(full['reference_cases'])+' canonical cases. Exact compiled sources/static ELF, every result row, diagnostics and trace identity accompany the fidelity archives. The current source epoch remains captured through adoption.\n')
 rec=pub.publish([str((D/n).relative_to(R)) for n in ['fidelity-inputs.tar.gz','fidelity-raw.tar.gz','summary.json','README.md']],'Retain ARM skb projection differential source and results','arm-skb-live-fidelity');notice('PUSHED '+rec['commit']+' ARM skb live projection differential '+json.dumps(full)+'. Existing application epoch retained.');save('waiting_application_epoch',result_commit=rec['commit'],application_predecessor=4075266)
 if rc:raise RuntimeError('Differential collection records exit '+str(rc))
 wait(app_fd)
 p=R/'kprog/arm64/arm64_sim_local_bpf.h';before=(N/'before.h').read_bytes();assert p.read_bytes()==before==subprocess.check_output(['git','show','HEAD:kprog/arm64/arm64_sim_local_bpf.h'])
 pins=json.loads((N/'input-pins.json').read_text());assert all(sha(R/k)==v for k,v in pins.items())
 p.write_bytes((N/'after.h').read_bytes());s['production_status']='Adopted after the captured application epoch and full differential closure.';(D/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
 with (D/'README.md').open('a') as f:f.write('\nThe production ARM simulator now adopts this live skb projection after the captured application sequence closes. The generic component uses the actual kernel-context address and live packet/cb access paths. Complete application successors consume this production source in their captured epochs.\n')
 rec=pub.publish(['kprog/arm64/arm64_sim_local_bpf.h',str((D/'summary.json').relative_to(R)),str((D/'README.md').relative_to(R))],'Use live kernel skb context in the ARM simulator','arm-skb-live-production');save('adopted',result_commit=rec['commit']);notice('PUSHED '+rec['commit']+' ARM live skb production adoption after original OTel8GiB4075266 closes;142080host, actualTC QEMU0/guest0 retval31,807forms/826368threeway cases joined. C/V universal ABI/source interface available; future A whole-app epochs consume production header.')
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
