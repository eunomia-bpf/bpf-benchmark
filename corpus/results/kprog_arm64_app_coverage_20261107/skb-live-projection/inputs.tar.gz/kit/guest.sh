set -eu
mount -t bpf bpffs /sys/fs/bpf
bpftool version > /run/lane/bpftool-version.txt
bpftool -d prog load /run/lane/check.bpf.o /sys/fs/bpf/skb_projection type classifier > /run/lane/load.stdout 2> /run/lane/load.stderr
bpftool -j prog run pinned /sys/fs/bpf/skb_projection data_in /run/lane/packet.bin data_out /run/lane/packet-out.bin ctx_in /run/lane/ctx.bin ctx_out /run/lane/ctx-out.bin repeat 1 > /run/lane/run.json 2> /run/lane/run.stderr
