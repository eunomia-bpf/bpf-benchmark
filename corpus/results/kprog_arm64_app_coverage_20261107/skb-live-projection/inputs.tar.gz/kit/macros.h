#if defined(__bpf__) || defined(__BPF__)
extern void *bpf_cast_to_kern_ctx(void *) __ksym;
#define ARM64_SIM_L_SKB_STORE_ACCESS(BITS, CTX, OFF, VALUE) \
 do { if (__builtin_constant_p(OFF)) \
  asm volatile("*(u" #BITS " *)(%0 + %1) = %2" : : "r"(CTX), "i"(OFF), "r"(VALUE) : "memory"); \
 else KPROG_ARM64_STORE_ACCESS(BITS, (__u8 *)(CTX) + (OFF), VALUE); } while (0)
#else
static inline void *bpf_cast_to_kern_ctx(void *ctx) { return ctx; }
#define ARM64_SIM_L_SKB_STORE_ACCESS(BITS, CTX, OFF, VALUE) \
 KPROG_ARM64_STORE_ACCESS(BITS, (__u8 *)(CTX) + (OFF), VALUE)
#endif
/* Kernel-context addresses retain native identity. Packet and qdisc cb fields
 * select the corresponding live verifier context access at the native width. */
#define ARM64_SIM_L_SKB_OFFSET(BASE, OFF) \
 ((__s64)((__u64)(long)ARM64_SIM_L_READ_REG_PTR(BASE) - (__u64)(long)__a64_sim_helper_abi_base + (__u64)(OFF)))
#define ARM64_SIM_L_SKB_FIELD(CTX, FIELD) \
 ({ __u64 __a64_sf_value; KPROG_ARM64_LOAD_ACCESS_OFFSET(32, (CTX), (__s64)__builtin_offsetof(struct __sk_buff, FIELD), __a64_sf_value); __a64_sf_value; })
#define ARM64_SIM_L_SKB_READ(BASE, OFF, WIDTH) \
 ({ __s64 __a64_sr_off = ARM64_SIM_L_SKB_OFFSET((BASE), (OFF)); \
    struct __sk_buff *__a64_sr_ctx = __a64_sim_helper_ctx; \
    __u64 __a64_sr_value; \
    if (((__a64_sr_off >= ARM64_SKB_DATA_OFF && __a64_sr_off <= ARM64_SKB_DATA_OFF + 8 - (WIDTH)) || \
         (__a64_sr_off >= ARM64_SKB_DATA_END_OFF && __a64_sr_off <= ARM64_SKB_DATA_END_OFF + 8 - (WIDTH)))) { \
      __s64 __a64_sr_lane; \
      if (__a64_sr_off >= ARM64_SKB_DATA_OFF) { __a64_sr_value=ARM64_SIM_L_SKB_FIELD(__a64_sr_ctx,data); __a64_sr_lane=__a64_sr_off-ARM64_SKB_DATA_OFF; } \
      else { __a64_sr_value=ARM64_SIM_L_SKB_FIELD(__a64_sr_ctx,data_end); __a64_sr_lane=__a64_sr_off-ARM64_SKB_DATA_END_OFF; } \
      if ((WIDTH) != ARM64_WIDTH_64) __a64_sr_value=KPROG_ARM64_APPLY_WIDTH(ARM64_SIM_L_XDP_NUMERIC(__a64_sr_value) >> (__a64_sr_lane*8), (WIDTH)); \
    } else if (__a64_sr_off >= ARM64_SKB_CB_OFF && __a64_sr_off <= ARM64_SKB_CB_OFF + 20 - (WIDTH)) \
      __a64_sr_value=KPROG_ARM64_LOAD_BYTES_OFFSET(__a64_sr_ctx, __a64_sr_off-ARM64_SKB_CB_OFF+(__s64)__builtin_offsetof(struct __sk_buff,cb), (WIDTH)); \
    else __a64_sr_value=KPROG_ARM64_LOAD_BYTES_OFFSET(ARM64_SIM_L_READ_REG_PTR(BASE),(OFF),(WIDTH)); \
    __a64_sr_value; })
#define ARM64_SIM_L_SKB_WRITE(BASE, OFF, WIDTH, VALUE) \
 do { __s64 __a64_sw_off=ARM64_SIM_L_SKB_OFFSET((BASE),(OFF)); \
      __u64 __a64_sw_value=KPROG_ARM64_APPLY_WIDTH((VALUE),(WIDTH)); \
      if (__a64_sw_off >= ARM64_SKB_CB_OFF && __a64_sw_off <= ARM64_SKB_CB_OFF + 20 - (WIDTH)) { \
       __s64 __a64_sw_ctx_off=__a64_sw_off-ARM64_SKB_CB_OFF+__builtin_offsetof(struct __sk_buff,cb); \
       if ((WIDTH)==ARM64_WIDTH_64) ARM64_SIM_L_SKB_STORE_ACCESS(64,__a64_sim_helper_ctx,__a64_sw_ctx_off,__a64_sw_value); \
       else if ((WIDTH)==ARM64_WIDTH_32) ARM64_SIM_L_SKB_STORE_ACCESS(32,__a64_sim_helper_ctx,__a64_sw_ctx_off,__a64_sw_value); \
       else if ((WIDTH)==ARM64_WIDTH_16) ARM64_SIM_L_SKB_STORE_ACCESS(16,__a64_sim_helper_ctx,__a64_sw_ctx_off,__a64_sw_value); \
       else ARM64_SIM_L_SKB_STORE_ACCESS(8,__a64_sim_helper_ctx,__a64_sw_ctx_off,__a64_sw_value); \
      } else ARM64_SIM_L_STORE_ADDR((__u8 *)ARM64_SIM_L_READ_REG_PTR(BASE)+(OFF),(WIDTH),__a64_sw_value); \
 } while (0)
