set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/skb-live-projection/after.h /workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h
cd /workspaces/repository
taskset -c 16-19 make -C kprog/fidelity ARCH=arm64 build
taskset -c 16-19 make -f kprog/results/kprog_fidelity_20261107/differential/arm64-current-logical/Makefile reference OUT=/workspaces/.agent-state/kprog-lanes/A/skb-live-projection/fidelity
