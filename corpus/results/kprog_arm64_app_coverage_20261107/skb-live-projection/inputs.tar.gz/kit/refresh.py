from pathlib import Path
import re,difflib,hashlib,json
R=Path('/workspaces/repository');N=Path(__file__).resolve().parent;p=R/'kprog/arm64/arm64_sim_local_bpf.h'
s=(N/'candidate-template.h').read_text().replace('@@NEW_MACROS@@',(N/'macros.h').read_text()).replace('- (__u8 *)__a64_sim_helper_abi_base) : 0) + __a64_mrt_off','- (__u8 *)(__a64_sim_is_xdp ? __a64_sim_helper_ctx : __a64_sim_helper_abi_base)) : 0) + __a64_mrt_off');(N/'after.h').write_text(s)
(N/'production.patch').write_text(''.join(difflib.unified_diff((N/'before.h').read_text().splitlines(True),s.splitlines(True),fromfile='a/kprog/arm64/arm64_sim_local_bpf.h',tofile='b/kprog/arm64/arm64_sim_local_bpf.h')))
inputs={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()}
def inc(m):
 target=(p.parent/m[1]).resolve();inputs[str(target.relative_to(R))]=hashlib.sha256(target.read_bytes()).hexdigest();return '#include "'+str(target)+'"'
s=re.sub(r'^#include "([^"]+)"',inc,s,flags=re.M);(N/'candidate.h').write_text(s);(N/'input-pins.json').write_text(json.dumps(inputs,indent=2)+'\n')
