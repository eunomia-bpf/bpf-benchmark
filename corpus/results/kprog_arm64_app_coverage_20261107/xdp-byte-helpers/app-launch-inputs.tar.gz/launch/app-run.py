from pathlib import Path
import ast,datetime,fcntl,gzip,hashlib,importlib.util,json,os,select,signal,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/xdp-byte-helpers';state={};plan=json.loads((N/'app-plan.json').read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(utc=now(),phase=phase,**kw);(N/'app-status.json').write_text(json.dumps(state,indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def wait(pid):
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:return
 try:select.select([fd],[],[])
 finally:os.close(fd)
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
lock=(N/'app.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 save('waiting_helper_controls');wait(int((N/'qemu-run.pid').read_text()));control=json.loads((N/'status.json').read_text());assert control['phase']=='component_published';assert all(r['host_ok'] for r in control['results'].values());plan['component_commit']=control['publication']['commit'];plan['utc']=now()
 save('waiting_matched_module_bundle');B=A/'kfunc-kernel/module-bundle';wait(int((B/'finish.pid').read_text()));bundle=json.loads((B/'status.json').read_text());assert bundle['phase']=='finished';plan['module_bundle_commit']=bundle['publication']['commit'];plan['binary_and_manifest_pins'].update(bundle['build']['file_pins'])
 for p in ['kprog/arm64/build/kernel-kfunc/Module.symvers','kprog/arm64/build/kernel-kfunc/kernel.release']:plan['binary_and_manifest_pins'][p]=sha(R/p)
 for p,h in plan['binary_and_manifest_pins'].items():assert sha(R/p)==h,p
 for p,h in plan['source_pins'].items():assert sha(N/'app-source'/p)==h,p
 candidates=[('tracee-core-runtime',26065,'corpus/results/kprog_arm64_app_coverage_20261107/tracee-core-refresh/runtime/launch-inputs.tar.gz'),('cilium-registered-kernel',20644,'corpus/results/kprog_arm64_app_coverage_20261107/cilium-registered-kernel/launch-inputs.tar.gz')];retired=plan.get('retired_waiting_controllers',[])
 ready=all(json.loads((A/folder/'status.json').read_text())['phase']=='waiting_application_epoch' for folder,pid,archive in candidates)
 if ready:
  for folder,pid,archive in candidates:
   Q=A/folder;command=Path('/proc/'+str(pid)+'/cmdline').read_bytes();assert str(Q/'run.py').encode() in command;assert Path('/proc/'+str(pid)+'/task/'+str(pid)+'/children').read_text().strip()==''
   with tarfile.open(R/archive) as t:assert t.extractfile('launch/run.py').read()==(Q/'run.py').read_bytes()
   retired.append(dict(folder=folder,pid=pid,status=json.loads((Q/'status.json').read_text()),command=command.decode().replace(chr(0),' '),source_sha256=sha(Q/'run.py'),archive=archive));os.kill(pid,signal.SIGTERM);wait(pid);(Q/'status.json').write_text(json.dumps(dict(phase='retired_waiting_successor',replacement=str(N/'app-run.py'),utc=now()),indent=2)+'\n')
 elif not retired:plan['predecessor_pid']=26065
 plan['retired_waiting_controllers']=retired;plan['source_overlay_pins']={n:sha(N/n) for n in ['app-cilium-transport.py','app-tracee-transport.py','app-cilium.sh','app-tracee.sh','app-run.py','tracee-manifest.json','safety-transport.py','safety.sh']};(N/'app-plan.json').write_text(json.dumps(plan,indent=2)+'\n');(D/'app-launch.json').write_text(json.dumps(plan,indent=2)+'\n')
 with tarfile.open(D/'app-launch-inputs.tar.gz','w:gz') as t:
  for name in ['app-plan.json','app-run.py','app-cilium-transport.py','app-tracee-transport.py','app-cilium.sh','app-tracee.sh','tracee-manifest.json','app-source','safety-fixtures','safety-transport.py','safety.sh']:t.add(N/name,arcname='launch/'+name)
 q=D/'README.md';q.write_text(q.read_text()+'\nThe coherent successor combines the matched complete kernel module bundle, C21e8040 generic map-helper target binding and the complete34-case native-only regression suite. Exact78 source snapshots, kernel/module/caller/native/workload identities and prior waiting-controller retirement records accompany the captured launch. Safety controls precede whole Cilium and Tracee after the original application/skb epoch.\n');pub=load('xdp_app_pub',A/'six-app-publish.py');receipt=pub.publish([str((D/n).relative_to(R)) for n in ['app-launch.json','app-launch-inputs.tar.gz','README.md']],'Queue whole ARM applications with generic XDP byte helpers','arm-xdp-helper-app-launch');save('waiting_original_epoch',launch_commit=receipt['commit'],waiting_pid=plan['predecessor_pid']);notice('PUSHED '+receipt['commit']+' soleARM XDPhelper app successor'+str(os.getpid())+' waits'+str(plan['predecessor_pid'])+'; retiredwaitingcontrollers'+json.dumps([r['pid'] for r in retired])+', originalpubliclaunchbytesjoined. CompleteCilium thenTracee8GiB/eightvCPU16-19/76frozensusources, matchedkernel/map-helper-module/caller/newCORETracee; currentoriginalKatran/OTel/skb epochsretained.')
 for row in retired:(A/row['folder']/'run.py').unlink(missing_ok=True)
 wait(plan['predecessor_pid'])
 for name,h in plan['safety_fixture_pins'].items():assert sha(N/'safety-fixtures'/name)==h,name
 for p,h in plan['binary_and_manifest_pins'].items():assert sha(R/p)==h,p
 save('actual_map_helper_safety')
 with (N/'safety.log').open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/'safety.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 F=R/'corpus/results/kprog_arm64_app_coverage_20261108/map-helper-binding/safety/trusted-arm64-service-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive']
 with tarfile.open(archive) as t:rows=json.load(t.extractfile('run/outcomes.json'))
 expected={x['name']:x['native_sha256'] for x in json.loads((N/'safety-fixtures/cases.json').read_text())}
 assert all(expected[r['name']]==r['native_sha256'] for r in rows)
 stages={x:sum(r['stage']==x for r in rows) for x in sorted({r['stage'] for r in rows})}
 report=dict(make_exit=done.returncode,host_ok=summary['ok'],guest_exit=summary['guest_exit'],cases=len(rows),stages=stages,unsafe_accepted=sum(r['negative'] and r['stage']=='accepted_finding' for r in rows),unsafe_executed=sum(r['negative'] and r['unsafe_native_executed'] for r in rows),native_identities={r['name']:r['native_sha256'] for r in rows},archive_sha256=sha(archive),module_build_commit=plan['map_helper_build_commit'])
 (F/'outcomes.json').write_text(json.dumps(report,indent=2)+chr(10));(F/'driver.log.gz').write_bytes(gzip.compress((N/'safety.log').read_bytes(),mtime=0));(F/'README.md').write_text('Generic ARM native-only regression through the matched map-helper callback/module epoch. Actual stages '+json.dumps(stages)+', cases '+str(len(rows))+', unsafe accepted '+str(report['unsafe_accepted'])+', unsafe executed '+str(report['unsafe_executed'])+', guest exit '+str(report['guest_exit'])+'. Complete native identities and raw service/kernel/loader outcomes accompany the captured source launch.'+chr(10))
 receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'outcomes.json',F/'driver.log.gz',F/'README.md']],'Retain ARM generic map helper safety runtime','arm-map-helper-safety');save('closed_map_helper_safety',safety_commit=receipt['commit']);notice('PUSHED '+receipt['commit']+' matchedARM native-only safety stages='+json.dumps(stages)+' cases='+str(len(rows))+' accepted/executed='+str(report['unsafe_accepted'])+'/'+str(report['unsafe_executed'])+'. Exactnative identities and complete raw outcomes retained.')
 assert summary['ok'] and done.returncode==0 and len(rows)==34 and report['unsafe_accepted']==0 and report['unsafe_executed']==0
 source_plan=json.loads((N/'plan.json').read_text());paths=source_plan['source_paths']
 for p,h in source_plan['source_before_sha256'].items():assert sha(R/p)==h and (R/p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p]),p
 for p in paths:(R/p).write_bytes((N/'source'/p).read_bytes())
 summary=json.loads((D/'summary.json').read_text());summary['production_status']='Adopted after the captured original application and live skb epochs.';(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');q.write_text(q.read_text()+'\nProduction adopts the complete80-helper family after the recorded original application/skb sequence. The compiler/helper identity/source ABI domains and complete generic regressions accompany this epoch.\n');receipt=pub.publish(paths+[str((D/n).relative_to(R)) for n in ['summary.json','README.md']],'Bind XDP buffer helpers through the ARM simulator','arm-xdp-helper-production');save('production_adopted',production_commit=receipt['commit']);notice('PUSHED '+receipt['commit']+' ARM generic188/189/190 helperbindings+80identityconstructorcoverage productionadopted afteroriginalapp/skbepoch; actualQEMUvalid/bounds+164864UBSan/82identity/4universalLeancontracts retained. C/V helperABI/sourceinterfaceavailable; completeCilium/Tracee next.')
 for app in ['cilium','tracee']:
  for p,h in plan['binary_and_manifest_pins'].items():assert sha(R/p)==h,p
  for p,h in plan['source_pins'].items():assert sha(N/'app-source'/p)==h,p
  for p,h in plan['source_overlay_pins'].items():assert sha(N/p)==h,p
  save('actual_'+app);notice('START completeARM '+app+' XDPhelper/nativeCORE whole-app replay8GiB/eightvCPU16-19; exactsource/kernel/native/workload epochs retained.')
  with (N/('app-'+app+'.log')).open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/('app-'+app+'.sh'))],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  F=D/'applications'/app/('trusted-arm64-'+app+'-result');s=json.loads((F/'summary.json').read_text());archive=F/s['archive'];audit=load('xdp_app_identity',A/'context-native-collector.py').inspect(s,archive,app);tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
  for node in tree.body:
   if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
   nodes.append(node)
  scope={'__name__':'xdp_app_coverage'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'xdp_app_coverage','exec'),scope);coverage=scope['coverage'](s,archive);(F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/('app-'+app+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Complete ARM '+app+' two-start through the generic80-helper/kfunc/nativeCORE epoch. Actual guest exit'+str(s['guest_exit'])+', Make exit'+str(done.returncode)+', host status'+str(s['ok'])+', stages'+json.dumps(coverage['stages'])+'. Complete raw source/native/service/verifier/work identities accompany this whole-app result. Universal simulator/binding composition continues with V/C.\n');receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain whole ARM '+app+' XDP helper runtime coverage','arm-xdp-helper-'+app+'-result');state[app+'_result_commit']=receipt['commit'];save('closed_'+app,stages=coverage['stages'],host_ok=s['ok']);notice('PUSHED '+receipt['commit']+' wholeARM '+app+' guest='+str(s['guest_exit'])+' stages='+json.dumps(coverage['stages'])+' freshnative/service/fullworklogs joined. Continuegenericfailureclassclosure acrosssixapplications.')
 save('finished')
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
