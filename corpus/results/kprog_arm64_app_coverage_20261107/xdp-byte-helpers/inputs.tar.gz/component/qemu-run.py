from pathlib import Path
import ast,datetime,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/xdp-byte-helpers';results={}
def save(phase,**kw):(N/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def wait(pid):
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:return
 try:select.select([fd],[],[])
 finally:os.close(fd)
try:
 save('waiting_host_contract',pid=int((N/'run.pid').read_text()));wait(int((N/'run.pid').read_text()));assert (N/'check.exit').read_text().strip()=='0';subprocess.run(['make','-f',str(N/'Makefile'),'fixtures'],cwd=R,check=True);D.mkdir(exist_ok=True)
 for case in ['valid','bounds']:
  save('actual_'+case,results=results)
  with (N/(case+'.log')).open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/(case+'.sh'))],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  F=D/case/'trusted-arm64-service-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];audit=load('xdp_identity',A/'context-native-collector.py').inspect(summary,archive,'control');tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
  for node in tree.body:
   if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
   nodes.append(node)
  scope={'__name__':'xdp_byte_review'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'xdp_byte_review','exec'),scope);coverage=scope['coverage'](summary,archive);assert done.returncode==0 and summary['ok'] and not audit['identity_errors'];assert coverage['stages']=={'bound_accepted':1}
  (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/(case+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Generic XDP byte-helper '+case+' control through the matched kernel-owned ARM service. Fresh generation/compile/verifier/binding/native execution returns2. Native fixtures call actual188/189/190 Linux helpers. Complete request/source/byte/verifier/runtime records accompany this control.\n');pub=load('xdp_pub',A/'six-app-publish.py');receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Exercise ARM XDP byte helper '+case+' through the native service','arm-xdp-helpers-'+case);results[case]=dict(commit=receipt['commit'],host_ok=summary['ok'],stages=coverage['stages']);save('closed_'+case,results=results)
 plan=json.loads((N/'plan.json').read_text());checks=json.loads((N/'checks.json').read_text());checks['qemu_controls']=results;checks['production_status']='Candidate source with adoption after the captured original application and skb epochs.';(D/'summary.json').write_text(json.dumps(checks,indent=2)+'\n')
 with tarfile.open(D/'inputs.tar.gz','w:gz') as t:
  for name in ['source','before','plan.json','check.c','check.py','helper-macros.h','Makefile','inside.sh','run.sh','check.log','check.exit','check-setup.log','check-setup.exit','audit.lean','checks.json','valid.S','bounds.S','valid.sh','bounds.sh','transport.py','qemu-run.py']:t.add(N/name,arcname='component/'+name)
  t.add(R/'kprog/arm64/build/xdp-byte-helpers',arcname='native-fixtures')
 (D/'README.md').write_text('Generic ARM XDP byte-helper bindings\n\nHelpers188/189/190 retain exact Linux helper identities, real XDP context pointers, u32 offset/length narrowing and full scalar returns. Successful packet loads clear overwritten destination provenance; failed loads preserve destination bytes and tags, matching net/core/filter.c. Existing full-write helper contracts retain their domain. The80-row generated identity table, independent enumeration and constructor completeness theorem agree with the vendored Linux helper declarations. Host UBSan164864call/byte/tag controls,82identity checks,80finite helper dispatches,4scalar refusals and4Lean theorem/axiom checks pass. Actual matched-kernel QEMU valid and bounds controls each complete fresh generation/compile/verification/binding/native execution with retval2. Inputs/source/native/request/diagnostics remain in the archives. Production adoption follows the captured original application/skb sequence; the complete Cilium and Tracee successors consume this epoch.\n');receipt=pub.publish([str((D/n).relative_to(R)) for n in ['summary.json','inputs.tar.gz','README.md']],'Preserve XDP byte helper identity and conditional output effects on ARM','arm-xdp-helpers-component');save('component_published',publication=receipt,results=results)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+receipt['commit']+' genericARM XDP188/189/190 candidate;164864UBSan+82identity+80finitedispatch/4scalarrefusals/2targetjoin and4Lean universalidentity/completenesstheorems+audits0. ActualQEMUvalid/bounds eachfreshgen/compile/bound/native2 onnewkernel, exactsource/native/request joins. Success-onlydestinationtag updates preservekernelerrorbytes. Whole-app/production successor adoption follows original4075266/skb4109581; currentguestsource retained.\n')
except BaseException as e:save('needs_continuation',results=results,error=str(e),traceback=traceback.format_exc());raise
