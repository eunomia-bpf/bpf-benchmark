set +e
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/inside.sh >/workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/check.log 2>&1
rc=$?
echo "$rc" > /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/check.exit
exit "$rc"
