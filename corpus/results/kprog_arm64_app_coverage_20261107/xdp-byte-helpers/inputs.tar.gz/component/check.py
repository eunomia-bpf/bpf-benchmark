from pathlib import Path
import os,sys,json,subprocess,importlib.util,hashlib
R=Path('/workspaces/repository');N=Path(__file__).resolve().parent;S=R/'kprog/arm64/arm64_sim_local_bpf.h';text=S.read_text();selected=[]
for name in ['bpf_xdp_get_buff_len','bpf_xdp_load_bytes','bpf_xdp_store_bytes']:
 lines=text.splitlines(True);i=next(i for i,l in enumerate(lines) if l.startswith('#define ARM64_SIM_BPF_CALL_'+name+'()'));block=[lines[i]]
 while block[-1].rstrip(chr(10)).endswith(chr(92)):i+=1;block.append(lines[i])
 selected.extend(block)
(N/'helper-macros.h').write_text(''.join(selected));subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror','-fsanitize=undefined','-fno-sanitize-recover=all',str(N/'check.c'),'-o',str(N/'check')],check=True);subprocess.run([str(N/'check')],check=True)
sys.path.insert(0,str(R/'kprog/arm64/micro-prog'));import generate_micro_sim_proofs as g
current=dict(g.HELPER_IDENTS);before={x['id']:x['name'] for x in json.loads((N/'before/kprog/formal/contracts/arm64_helper_idents_spec.json').read_text())['rows']}
def seq(number):return [g.NativeInsn(0,'mov',('w8','#'+str(number)),'mov w8,#'+str(number)),g.NativeInsn(4,'blr',('x8',),'blr x8'),g.NativeInsn(8,'mov',('w0','#2'),'mov w0,#2'),g.NativeInsn(12,'ret',(),'ret')]
g.HELPER_IDENTS=before
for number in [188,189,190]:
 try:g.indirect_targets(seq(number))
 except ValueError as e:assert 'invalid indirect target scalar:' in str(e)
 else:raise AssertionError('baseline XDP target classification')
g.HELPER_IDENTS=current
for number,name in current.items():
 result=g.indirect_targets(seq(number));assert result[4]==frozenset({('scalar',number)});out=[];g.append_indirect(out,seq(number)[1],result[4],8);assert 'ARM64_SIM_BPF_CALL_'+name+'()' in '\n'.join(out)
for number in [0,187,196,65535]:
 try:g.indirect_targets(seq(number))
 except ValueError:pass
 else:raise AssertionError('scalar target classification '+str(number))
I=g.NativeInsn;joined=[I(0,'mov',('w8','#188'),'mov w8,#188'),I(4,'mov',('w9','#189'),'mov w9,#189'),I(8,'cmp',('x0','#0'),'cmp x0,#0'),I(12,'csel',('x8','x8','x9','eq'),'csel x8,x8,x9,eq'),I(16,'blr',('x8',),'blr x8'),I(20,'mov',('w0','#2'),'mov w0,#2'),I(24,'ret',(),'ret')];targets=g.indirect_targets(joined)[16];assert targets==frozenset({('scalar',188),('scalar',189)});out=[];g.append_indirect(out,joined[4],targets,20);assert sum('case ' in x for x in out)==2;print('finite helper identity/dispatch checks:80 accepted,4 scalar refusals,3 baseline regressions,1 two-target join',flush=True)
F=R/'kprog/formal';env=os.environ.copy();env['LEAN_PATH']=str(N/'lean')+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=F,text=True).strip();lean=subprocess.check_output(['lake','env','which','lean'],cwd=F,text=True).strip();generated=Path('KProgFormal/Generated/GeneratedArm64HelperIdents.lean');target=N/'lean'/generated.with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True);subprocess.run([lean,'-o',str(target),str(generated)],cwd=F,env=env,check=True);hand=Path('KProgFormal/Arm64HelperIdents.lean');target=N/'lean'/hand.with_suffix('.olean');subprocess.run([lean,'-o',str(target),str(hand)],cwd=F,env=env,check=True);audit=N/'audit.lean';audit.write_text('import KProgFormal.Arm64HelperIdents\n'+''.join('#print axioms KProgFormal.'+n+'\n' for n in ['helper_idents_refines','helper_idents_names_nodup','helper_idents_ids_strictly_increasing','helper_idents_complete']));subprocess.run([lean,str(audit)],cwd=F,env=env,check=True)
report=dict(host_cases=164864,helper_identities=len(current),finite_scalar_refusals=4,baseline_regressions=3,joined_dispatches=1,lean_theorems=4,lean_audits=4,source_pins={str(p.relative_to(N/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (N/'source').rglob('*') if p.is_file()});(N/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
