#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
typedef uint64_t __u64; typedef int64_t __s64; typedef uint32_t __u32; typedef uint8_t __u8;
#define ARM64_X0 0
#define ARM64_X1 1
#define ARM64_X2 2
#define ARM64_X3 3
#define ARM64_SIM_TAG_SCALAR 0
#define ARM64_SIM_TAG_STACK 1
struct xdp_md { unsigned char bytes[64]; __u64 len; } context;
static __u64 regs[4]; static unsigned char tags[4], buffer[24];
static unsigned calls, transfers; static __u32 observed_offset, observed_len;
static void *observed_buffer; static __s64 destination; static __u8 destination_tag;
#define ARM64_SIM_L_READ_REG(R) regs[R]
#define ARM64_SIM_L_READ_REG_PTR(R) ((void *)(uintptr_t)regs[R])
#define ARM64_SIM_L_REG_TAG(R) tags[R]
#define ARM64_SIM_L_HELPER_CTX_PTR(R) ((void)((R)==0 || (assert(0),0)), &context)
#define ARM64_SIM_L_HELPER_ARG_PTR(R) ((void *)(uintptr_t)regs[R])
#define ARM64_SIM_L_HELPER_SCALAR_RESULT(E) do { __u64 v=(__u64)(E); regs[0]=v; tags[0]=0; } while(0)
static void transfer(__s64 dst,__u8 tag,__u32 len) { transfers++; destination=dst; destination_tag=tag; assert(len==observed_len); }
#define ARM64_SIM_L_MEMORY_TAG_TRANSFER(D,T,S,U,L,C) transfer(D,T,L)
static __u64 bpf_xdp_get_buff_len(struct xdp_md *ctx) { assert(ctx==&context); calls++; return ctx->len; }
static long access_bytes(struct xdp_md *ctx,__u32 offset,void *buf,__u32 len,int store) {
 assert(ctx==&context); calls++; observed_offset=offset; observed_len=len; observed_buffer=buf;
 if ((__u64)offset+len>64) return -14;
 if(store) memcpy(ctx->bytes+offset,buf,len); else memcpy(buf,ctx->bytes+offset,len);
 return 0;
}
static long bpf_xdp_load_bytes(struct xdp_md *ctx,__u32 offset,void *buf,__u32 len) { return access_bytes(ctx,offset,buf,len,0); }
static long bpf_xdp_store_bytes(struct xdp_md *ctx,__u32 offset,void *buf,__u32 len) { return access_bytes(ctx,offset,buf,len,1); }
#include "helper-macros.h"
int main(void) {
 unsigned long count=0;
 for(unsigned seed=0;seed<1024;seed++) {
  regs[0]=0x999; context.len=((__u64)seed<<32)|64; calls=0; tags[0]=3;
  ARM64_SIM_BPF_CALL_bpf_xdp_get_buff_len(); assert(regs[0]==context.len && tags[0]==0 && calls==1); count++;
  for(unsigned width=1;width<=8;width*=2) for(unsigned at=0;at<5;at++) for(unsigned tag=0;tag<4;tag++) for(unsigned store=0;store<2;store++) {
   unsigned offsets[]={0,4,63,64,65535},offset=offsets[at]; unsigned char expected_packet[64],expected_buffer[24];
   for(unsigned i=0;i<64;i++) context.bytes[i]=(unsigned char)(seed+i*17);
   for(unsigned i=0;i<24;i++) buffer[i]=(unsigned char)(seed-i*13);
   memcpy(expected_packet,context.bytes,64); memcpy(expected_buffer,buffer,24);
   int success=offset+width<=64;
   if(success) { if(store) memcpy(expected_packet+offset,buffer+8,width); else memcpy(expected_buffer+8,context.bytes+offset,width); }
   regs[0]=0x999; regs[1]=((__u64)seed<<32)|offset; regs[2]=(uintptr_t)(buffer+8); regs[3]=((__u64)(seed^511)<<32)|width; tags[0]=2; tags[2]=tag; calls=transfers=0;
   __u64 arg1=regs[1],arg2=regs[2],arg3=regs[3];
   if(store) ARM64_SIM_BPF_CALL_bpf_xdp_store_bytes(); else ARM64_SIM_BPF_CALL_bpf_xdp_load_bytes();
   assert(calls==1 && observed_offset==offset && observed_len==width && observed_buffer==buffer+8);
   assert(regs[0]==(__u64)(success?0:-14) && tags[0]==0 && regs[1]==arg1 && regs[2]==arg2 && regs[3]==arg3);
   assert(memcmp(context.bytes,expected_packet,64)==0 && memcmp(buffer,expected_buffer,24)==0);
   assert(transfers==(unsigned)(success && !store));
   if(transfers) assert(destination==(__s64)(uintptr_t)(buffer+8) && destination_tag==tag);
   count++;
  }
 }
 printf("ARM XDP helper call/width/context/byte/tag checks: %lu\n",count);
}
