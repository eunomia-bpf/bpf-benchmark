set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/arm64/arm64_sim_local_bpf.h /workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/formal/contracts/arm64_helper_idents_spec.json /workspaces/repository/kprog/formal/contracts/arm64_helper_idents_spec.json
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/formal/tools/generate_arm64_helper_idents_spec.py /workspaces/repository/kprog/formal/tools/generate_arm64_helper_idents_spec.py
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/formal/KProgFormal/Arm64HelperIdents.lean /workspaces/repository/kprog/formal/KProgFormal/Arm64HelperIdents.lean
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/formal/oracles/test_arm64_helper_idents_host.c /workspaces/repository/kprog/formal/oracles/test_arm64_helper_idents_host.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/formal/generated/arm64_helper_idents.h /workspaces/repository/kprog/formal/generated/arm64_helper_idents.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/formal/KProgFormal/Generated/GeneratedArm64HelperIdents.lean /workspaces/repository/kprog/formal/KProgFormal/Generated/GeneratedArm64HelperIdents.lean
mount --bind /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/source/kprog/arm64/micro-prog/generated_arm64_helper_idents.py /workspaces/repository/kprog/arm64/micro-prog/generated_arm64_helper_idents.py
exec make -f /workspaces/.agent-state/kprog-lanes/A/xdp-byte-helpers/Makefile check
