from pathlib import Path
import ast,datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/kfunc-arm-runtime';plan=json.loads((N/'plan.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(N/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=load('kfunc_pub',A/'six-app-publish.py')
try:
 rec={'commit':plan['build_publication']};completed={}
 for group in ['retained_input_pins','new_binary_pins']:
  for p,h in plan[group].items():assert sha(R/p)==h,p
 (D/'runtime-plan.json').write_text(json.dumps(plan,indent=2)+chr(10))
 with tarfile.open(D/'runtime-inputs.tar.gz','w:gz') as t:
  for n in ['plan.json','run.py','transport.py','xdp-control.sh','tc-control.sh','runtime-setup.tar.gz']:t.add(N/n,arcname=n)
 launch=pub.publish([str((D/n).relative_to(R)) for n in ['runtime-plan.json','runtime-inputs.tar.gz']],'Prepare typed ARM service control runtime inputs','arm-kfunc-runtime-inputs');save('runtime_prepared',runtime_commit=launch['commit'],build_commit=rec['commit'])
 for case in ['xdp-control','tc-control']:
  for p,h in plan['control_source_pins'].items():assert sha(N/p)==h,p
  save('actual_'+case,build_commit=rec['commit'])
  with (N/(case+'.log')).open('w') as output:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/(case+'.sh'))],cwd=R,env=__import__('os').environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT)
  F=D/case/'trusted-arm64-service-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];audit=load('kf_identity',A/'context-native-collector.py').inspect(summary,archive,'control')
  tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
  for node in tree.body:
   if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
   nodes.append(node)
  scope={'__name__':'kf_control'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'kf_control','exec'),scope);coverage=scope['coverage'](summary,archive)
  (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/(case+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Generic '+case+' native-only registered-service control. Guest exit'+str(summary.get('guest_exit'))+', host status'+str(summary['ok'])+', Make exit'+str(done.returncode)+', stages'+json.dumps(coverage['stages'])+'. Exact raw request/generated ELF/kfunc metadata and native execution identities accompany this coherent caller/worker epoch. Universal ABI/link and whole-application composition continue.\n')
  result=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain ARM '+case+' fresh kfunc service result','arm-kfunc-'+case);save('closed_'+case,result_commit=result['commit'],host_ok=summary['ok'],stages=coverage['stages'])
  completed[case]=result; (N/'runtime-publications.json').write_text(json.dumps(completed,indent=2)+chr(10))
  with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED '+result['commit']+' genericARM '+case+' actualkfunc pairedruntime, guest='+str(summary.get('guest_exit'))+' host='+str(summary['ok'])+' stages='+json.dumps(coverage['stages'])+'; fullraw/nativeidentity/source epochs retained.\n')
 save('finished',publications=completed,build_commit=rec['commit'])
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
