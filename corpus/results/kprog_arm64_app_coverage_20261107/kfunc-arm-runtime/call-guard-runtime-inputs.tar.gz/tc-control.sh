set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/kfunc-arm-build/transport.py /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py
mount --bind /workspaces/.agent-state/kprog-lanes/A/skb-live-projection/after.h /workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h
exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=tc-control TRUSTED_RESULTS=/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261107/kfunc-arm-runtime/call-guard/tc-control
