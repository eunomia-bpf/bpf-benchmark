#!/bin/sh
set -eu
cd /workspaces/repository
B=/workspaces/.agent-state/kprog-lanes/A/readonly-byte-candidate
mount --bind "$B/readonly.after.py" corpus/results/kprog_arm64_app_coverage_20261106/readonly_metadata.py
if test "$1" = after; then mount --bind "$B/generator.after.py" kprog/arm64/micro-prog/generate_micro_sim_proofs.py; fi
PYTHONDONTWRITEBYTECODE=1 exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile readonly-metadata-check PHASE=../kprog_arm64_app_coverage_20261107/readonly-byte-exact/"$1"
