#!/bin/sh
B=/workspaces/.agent-state/kprog-lanes/A/readonly-byte-candidate
unshare --mount --propagation private sh "$B/inside-actual.sh"
rc=$?
printf '%s\n' "$rc" > "$B/actual.exit"
exit "$rc"
