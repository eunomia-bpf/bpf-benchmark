from pathlib import Path
from datetime import datetime,timezone
from elftools.elf.elffile import ELFFile
import hashlib,importlib.util,io,json,shutil,sys,tarfile
R=Path('/workspaces/repository');B=Path('/workspaces/.agent-state/kprog-lanes/A/readonly-byte-candidate');sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/arm64/micro-prog'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def sha(data):return hashlib.sha256(data).hexdigest()
D=R/'corpus/results/kprog_arm64_app_coverage_20261107/trusted-arm64-otelcol-ebpf-profiler-result';summary=json.loads((D/'summary.json').read_text());archive=D/summary['archive'];assert sha(archive.read_bytes())==summary['archive_sha256']
with tarfile.open(archive) as outer:
 receipt=json.loads(outer.extractfile('run/requests/requests.jsonl').read().decode().splitlines()[0]);blob=outer.extractfile('run/requests/'+Path(receipt['failure_archive']).name).read()
 with tarfile.open(fileobj=io.BytesIO(blob)) as request:
  names=['request/kernel.native.o','request/kernel.entry','request/generation.metadata.json','request/generated/trusted_arm64.proof.o','request/generated/trusted_arm64.bpf.o','request/generated/trusted_arm64.bpf.c']
  frozen=B/'frozen';frozen.mkdir(exist_ok=True)
  for name in names:(frozen/Path(name).name).write_bytes(request.extractfile(name).read())
old=load('old_rodata_reader',B/'generator.before.py');old.REPO_ROOT=R;worker=load('actual_arm_worker',R/'kprog/arm64/trusted_specializer.py');new=worker.gen
native=(frozen/'kernel.native.o').read_bytes();assert sha(native)==receipt['native_sha256'];entry=(frozen/'kernel.entry').read_text().strip();metadata=json.loads((frozen/'generation.metadata.json').read_text())
original=new.load_rodata_blobs(frozen/'trusted_arm64.proof.o');corrupt=old.load_rodata_blobs(frozen/'trusted_arm64.proof.o')
old_compiled=ELFFile(io.BytesIO((frozen/'trusted_arm64.bpf.o').read_bytes()));old_metadata=json.loads(old_compiled.get_section_by_name('.native_lab.rodata').data().removesuffix(b'\0'))
checks=[]
for row in old_metadata['objects']:
 expected=original[row['native_symbol']];bad=old_compiled.get_section_by_name(row['proof_section']).data();assert bad==corrupt[row['native_symbol']];assert bad!=expected
 checks.append({'native_symbol':row['native_symbol'],'size':len(expected),'expected_sha256':sha(expected),'old_sha256':sha(bad),'first_mismatch':next(i for i,(x,y) in enumerate(zip(expected,bad)) if x!=y)})
link=R/'kprog/arm64/build/app-native-link/release/native-link';result=worker.specialize(native,entry,metadata,B/'actual',link)
new_compiled=ELFFile(io.BytesIO(Path(result['simulator_object']).read_bytes()));new_metadata=json.loads(new_compiled.get_section_by_name('.native_lab.rodata').data().removesuffix(b'\0'))
for row in new_metadata['objects']:
 actual=new_compiled.get_section_by_name(row['proof_section']).data();assert actual==original[row['native_symbol']]
 for item in checks:
  if item['native_symbol']==row['native_symbol']:item['new_sha256']=sha(actual);item['new_matches_captured_proof_native_data']=True
assert len(checks)==len(new_metadata['objects'])
micros=B/'micros';micros.mkdir(exist_ok=True);micro_checks=[]
for bench in new.load_benches(R/'micro/config/micro_pure_jit.yaml'):
 source=R/'kprog/arm64/micro-prog/build/native-link'/(bench.name+'.proof.o');shutil.copy2(source,micros/source.name)
 outputs=[]
 for gen in [old,new]:
  funcs,data=gen.parse_native_linked_program(bench,micros);outputs.append(gen.render_program(bench.name,bench.symbol,funcs,bench.kind,rodata16=data,linked_exit=True))
 if outputs[0]!=outputs[1]:raise RuntimeError('micro emitted source changed '+bench.name)
 micro_checks.append({'name':bench.name,'native_proof_sha256':sha(source.read_bytes()),'generated_c_sha256':sha(outputs[1].encode()),'old_new_identical':True})
record={'utc':datetime.now(timezone.utc).isoformat(),'scope':'Actual captured OTel request regenerated and compiled with private reader; no guest/binder/verifier/app success claim','raw_archive':str(archive.relative_to(R)),'raw_archive_sha256':summary['archive_sha256'],'native_sha256':sha(native),'entry':entry,'original_request_id':receipt['request_id'],'host_native_link_sha256':sha(link.read_bytes()),'readonly_objects':checks,'micros':micro_checks,'micro_sources_byte_identical':len(micro_checks),'artifact_hashes':{p.name:sha(p.read_bytes()) for p in (B/'actual').iterdir() if p.is_file()}}
(B/'actual-check.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'readonly':checks,'micro_sources_byte_identical':len(micro_checks)},indent=2))
