from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,os,select,fcntl,tarfile,gzip,ast,traceback,importlib.util
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');B=A/'cilium-writable-candidate';N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/cilium-writable-root';plan=json.loads((N/'home-plan.json').read_text());state={}
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(phase=phase,utc=now(),**kw);raw=json.dumps(state,indent=2)+chr(10);(N/'status.json').write_text(raw);(B/'status.json').write_text(raw)
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write(chr(10)+'- LOCAL A '+now()+': '+s+chr(10))
def wait(pid,label):
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:return
 try:save('waiting_'+label,waiting_pid=pid);select.select([fd],[],[])
 finally:os.close(fd)
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
wait(plan['previous_waiting_pid'],'prior_waiting_observer')
lock=(B/'continue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 resources=json.loads((A/'native-resources/status.json').read_text());assert resources['phase']=='finished'
 for name,h in resources['plan']['loader_binaries'].items():assert sha(R/resources['plan']['loader_prefix']/name)==h,name
 assert sha(R/resources['plan']['module_output']/'bpf_arm64_native_lab.ko')==resources['plan']['module_sha256'];assert sha(R/plan['canonical_transport'])==plan['canonical_transport_before_sha256'];assert sha(N/'transport-home.py')==plan['private_transport_sha256']
 D.mkdir(exist_ok=True);(D/'home-launch.json').write_text(json.dumps(plan,indent=2)+chr(10))
 with tarfile.open(D/'home-inputs.tar.gz','w:gz') as ar:
  for n in ['home-plan.json','transport-home.py','runtime-home.sh','run-home.py','previous-home-error.tar.gz']:ar.add(N/n,arcname='launch/'+n)
 p=D/'README.md';text=p.read_text();marker='Canonical transport not yet applied;';start=text.find(marker)
 if start>=0:text=text[:start]+'The complete Cilium baseline/native recipe starts in a private source mount on16-19 with4GiB while the existing OTel8GiB guest continues. Total A guest allocation is12GiB. Workload, samples, native inputs and generation-bound requirements retain their recipe. Kernel-owned map capability and readonly-label builds are pinned at340a4ea5e. Canonical transport publication follows actual OTel closure; Tetragon and Tracee retain their successor order. Runtime outcomes and launch resource settings remain in the complete archives.'+chr(10)
 else:text+='\nThe private parallel replay uses4GiB on16-19 alongside the original8GiB OTel guest. Whole-application results and canonical source adoption follow their actual closures.\n'
 p.write_text(text);pub=load('parallel_pub',A/'six-app-publish.py');receipt=pub.publish([str((D/n).relative_to(R)) for n in ['home-launch.json','home-inputs.tar.gz','README.md']],'Prepare Cilium replay with an ephemeral writable guest home','arm-cilium-home-launch');save('actual_cilium_replay',launch_commit=receipt['commit'],diagnosis_commit='bdd3a3a95b631008b352b4689b7932e4a7ecbe9c');notice('PUSHED '+receipt['commit']+' whole Cilium private parallel launch inputs:4GiB16-19 plus original OTel8GiB8-11=12GiB. Existing Make recipe/workload/native/proof requirements retained; canonical transport and active OTel source views retained.')
 with (N/'runtime.log').open('w') as output:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/'runtime-home.sh')],cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=output,stderr=subprocess.STDOUT)
 F=D/'home-replay/trusted-arm64-cilium-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];audit=load('parallel_identity',A/'context-native-collector.py').inspect(summary,archive,'cilium');tree=ast.parse((A/'six-app-queue.py').read_text());body=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
  body.append(node)
 scope={'__name__':'parallel_closed_review'};exec(compile(ast.Module(body=body,type_ignores=[]),'parallel_closed_review','exec'),scope);coverage=scope['coverage'](summary,archive)
 (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+chr(10));(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+chr(10));(F/'driver.log.gz').write_bytes(gzip.compress((N/'runtime.log').read_bytes(),mtime=0));(F/'README.md').write_text('Complete Cilium two-start functional replay with4GiB on16-19. Host status '+str(summary['ok'])+'; guest exit '+str(summary.get('guest_exit'))+'; Make exit '+str(done.returncode)+'; stages '+json.dumps(coverage['stages'])+'. Source/binary/resource settings and every application/request/work counter retain their actual archives. QEMU observations describe functional work. Whole-application and universal safety completion continues.'+chr(10));receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain Cilium functional replay with an ephemeral guest home','arm-cilium-home-result');state.update(replay_commit=receipt['commit'],host_ok=summary['ok'],stages=coverage['stages']);save('runtime_closed');notice('PUSHED '+receipt['commit']+' whole Cilium private replay:guest='+str(summary.get('guest_exit'))+',stages='+json.dumps(coverage['stages'])+'. Original OTel guest continues; canonical source adoption follows its closure.')
 wait(plan['prior_otel_pid'],'otel_closure_for_canonical_source')
 source=R/plan['canonical_transport'];assert sha(source)==plan['canonical_transport_before_sha256'];assert sha(B/'transport.after.py')==plan['canonical_transport_after_sha256'];source.write_bytes((B/'transport.after.py').read_bytes());receipt=pub.publish([plan['canonical_transport']],'Adopt Cilium writable libraries and ARM resource service inputs','arm-cilium-source-adoption');save('finished',source_commit=receipt['commit']);notice('PUSHED '+receipt['commit']+' canonical ARM transport after actual OTel closure; complete Cilium parallel result already published. Tetra/Tracee successor chain proceeds through its existing collectors.')
except BaseException as e:save('failed',error=str(e),traceback=traceback.format_exc());raise
