#!/bin/sh
cd /workspaces/repository || exit
B=/workspaces/.agent-state/kprog-lanes/A/readonly-layout-extent
rc=0
make -f "$B/Makefile" before > "$B/before.log" 2>&1 || rc=$?
echo "$rc" > "$B/before.exit"
rc=0
make -f "$B/Makefile" after > "$B/after.log" 2>&1 || rc=$?
echo "$rc" > "$B/after.exit"
if test "$rc" -ne 0; then exit "$rc"; fi
rc=0
make -f "$B/Makefile" adjacent > "$B/adjacent.log" 2>&1 || rc=$?
echo "$rc" > "$B/adjacent.exit"
exit "$rc"
