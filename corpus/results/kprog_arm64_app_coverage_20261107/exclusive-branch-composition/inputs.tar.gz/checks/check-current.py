from pathlib import Path
import hashlib,json,os,subprocess
A=Path('/workspaces/.agent-state/kprog-lanes/A');N=A/'exclusive-branch-composition';plan=json.loads((N/'current-plan.json').read_text());env=dict(os.environ,LEAN_PATH=str(N/'current-olean')+':'+str(A/'numeric-contract-sync/lean')+':'+os.environ.get('LEAN_PATH',''));rows=[];previous={r['module']:r for r in json.loads((N/'current-results.json').read_text())}
for name in plan['affected']:
 src=N/'current'/(name.replace('.','/')+'.lean');out=N/'current-olean'/(name.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);print('CHECK',name,flush=True)
 if name in previous and previous[name]['exit']==0 and hashlib.sha256(src.read_bytes()).hexdigest()==previous[name]['source_sha256'] and out.exists() and hashlib.sha256(out.read_bytes()).hexdigest()==previous[name]['olean_sha256']:
  rows.append(previous[name]);continue
 done=subprocess.run(['lean','--root='+str(N/'current'),'-o',str(out),str(src)],env=env);rows.append(dict(module=name,exit=done.returncode,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),olean_sha256=hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None));(N/'current-results.json').write_text(json.dumps(rows,indent=2)+'\n');done.check_returncode()
