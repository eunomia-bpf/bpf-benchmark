from pathlib import Path
import os,subprocess,sys
N=Path('/workspaces/.agent-state/kprog-lanes/A/exclusive-branch-composition')
env=dict(os.environ,LEAN_PATH=str(N/sys.argv[1])+':/workspaces/.agent-state/kprog-lanes/A/numeric-contract-sync/lean:'+os.environ.get('LEAN_PATH',''))
r=subprocess.run(['lean','--root='+str(N/'current'),str(N/'current/Audit.lean')],env=env,text=True,capture_output=True)
print(r.stdout,end='');print(r.stderr,end='');r.check_returncode()
assert 'sorryAx' not in r.stdout
