import KProgFormal.Refinement.Arm64Memory
import KProgFormal.Generated.GeneratedArm64Stlxr

namespace KProgFormal.Refinement.Arm64Exclusive
open Reference
open Reference.AArch64

/-- No monitor can never be turned into a successful store by an external
choice. A platform witness cannot manufacture a local reservation. -/
theorem empty_monitor_fails (s : State) (bytes : Nat)
    (h : s.exclusiveMonitor = none) : exclusiveStorePass s bytes = false := by
  simp [exclusiveStorePass, exclusiveMonitorPass, h]

theorem interference_fails (s : State) (bytes : Nat)
    (h : s.exclusiveInputs.retainLocal = false) : exclusiveStorePass s bytes = false := by
  simp [exclusiveStorePass, exclusiveMonitorPass, h]

/-- A matching load is insufficient when the global monitor or atomic commit
fails; the failure branch remains architectural, not an omitted path. -/
theorem global_failure (s : State) (bytes : Nat)
    (h : s.exclusiveInputs.globalPass = false) : exclusiveStorePass s bytes = false := by
  simp [exclusiveStorePass, exclusiveMonitorPass, h]

theorem commit_failure (s : State) (bytes : Nat)
    (h : s.exclusiveInputs.commitPass = false) : exclusiveStorePass s bytes = false := by
  simp [exclusiveStorePass, h]

theorem clear_step (s : State) :
    step (.exclusive .clear) s =
      ⟨{ s with exclusiveMonitor := none, pc := s.pc + 4 },
        [.exclusive .clear 0 0 false false true], none⟩ := rfl

/-- An unsuccessful monitor check with fault-before-check disabled cannot
write any byte or change NZCV, vector, SP, or any register except status. -/
theorem failed_store (s : State) (width : Width) (release : Bool) (status src base : Register)
    (hm : exclusiveMonitorPass s width.bytes = false)
    (ha : s.exclusiveInputs.abortOnFailure = false)
    (hsp : spAlignmentFault s base = none) :
    exclusiveStep (.store width release status src base) s =
      ⟨{ writeReg (if !s.exclusiveInputs.retainLocal || s.exclusiveInputs.virtualPass then
              { s with exclusiveMonitor := none } else s) status 1 with pc := s.pc + 4 },
        [.exclusive .attempt (memoryBase s base) width.bytes false release false], none⟩ := by
  simp [exclusiveStep, exclusiveStorePass, hm, ha, hsp]

/-- Different virtual addresses can share a physical reservation; the
monitor is checked in physical coordinates supplied by address translation. -/
theorem physical_alias_pass (s : State) (bytes : Nat) (monitor : ExclusiveMonitor)
    (hm : s.exclusiveMonitor = some monitor)
    (hr : s.exclusiveInputs.retainLocal = true)
    (hv : s.exclusiveInputs.virtualPass = true)
    (hg : s.exclusiveInputs.globalPass = true)
    (hc : s.exclusiveInputs.commitPass = true)
    (covers : exclusiveCovers monitor s.exclusiveInputs.physicalAddress bytes = true) :
    exclusiveStorePass s bytes = true := by
  simp [exclusiveStorePass, exclusiveMonitorPass, hm, hr, hv, hg, hc, covers]

/-- The exclusive C arms use native W/X memory widths, never a byte ladder. -/
def accessWidth : Width → MemoryWidth
  | .w32 => .word | .w64 => .double

theorem access_width_refines (width : Width) : (accessWidth width).bytes = width.bytes := by
  cases width <;> rfl

/-- A monitor annotation belongs to the environment relation. The C simulator
has no local monitor cell; a certificate must justify this ghost state and the
acquire/release event, including atomicity and order on the target platform. -/
def checkedState (s : State) : State :=
  if !s.exclusiveInputs.retainLocal || s.exclusiveInputs.virtualPass then
    { s with exclusiveMonitor := none } else s

/-- LDAXR's generated load and GPR write, with the reservation annotation
supplied by the same explicit environment as the canonical step. -/
def loadCore (width : Width) (acquire : Bool) (dst base : Register) (s : State) :
    Transition State :=
  let address := Arm64Memory.baseValue s base
  match Arm64Memory.read (accessWidth width) s.memory address with
  | .error fault => ⟨s, [.fault fault], some fault⟩
  | .ok (value, event) =>
      ⟨{ Arm64Register.writeReg s dst value width with
          exclusiveMonitor := some s.exclusiveInputs.reservation, pc := s.pc + 4 },
       [event, .exclusive .reserve address width.bytes acquire false true], none⟩

theorem load_core_refines (width : Width) (acquire : Bool) (dst base : Register)
    (s : State) (spAligned : spAlignmentFault s base = none)
    (aligned : exclusiveNaturalFault (memoryBase s base) width.bytes = none) :
    loadCore width acquire dst base s = step (.exclusive (.load width acquire dst base)) s := by
  simp only [loadCore, step, exclusiveStep, Arm64Memory.base_refines,
    Arm64Memory.read_refines, access_width_refines, spAligned, aligned]
  cases readMemory s.memory (memoryBase s base) width.bytes with
  | error fault => rfl
  | ok pair =>
      rcases pair with ⟨value, event⟩
      simp only [Arm64Register.write_refines]

theorem status_value_refines (failure : Bool) :
    narrow (GeneratedArm64Stlxr.value .stlxr .w32 failure) .w32 =
      (if failure then 1 else 0) := by
  cases failure <;> decide

/-- STLXR tests the explicit outcome before accessing memory, then writes a
W status. The source is captured before the status write, including aliases.
Monitor and exclusive-event fields are ghost annotations, not extra C guards. -/
def storeCore (width : Width) (release failure : Bool) (status src base : Register)
    (s : State) : Transition State :=
  let address := Arm64Memory.baseValue s base
  let checked := checkedState s
  let stored := if failure then checked else
    { checked with memory := Arm64Memory.store (accessWidth width) s.memory address (Arm64Register.readReg s src) }
  let result := Arm64Register.writeReg stored status
    (GeneratedArm64Stlxr.value .stlxr .w32 failure) .w32
  ⟨{ result with pc := s.pc + 4 },
   [.exclusive .attempt address width.bytes false release (!failure)] ++
     (if failure then [] else
       [.memory .write address (valueBytes (Arm64Register.readReg s src) width.bytes) true]), none⟩

/-- The environment outcome must match the canonical monitor AND commit
result. Failure is included, not replaced with a chosen successful execution.
If the architecture checks memory on failure, that preflight must also pass;
when it does not check, inaccessible memory remains a permitted failure input. -/
theorem store_core_refines (width : Width) (release failure : Bool)
    (status src base : Register) (s : State)
    (outcome : failure = !exclusiveStorePass s width.bytes)
    (spAligned : spAlignmentFault s base = none)
    (aligned : exclusiveNaturalFault (memoryBase s base) width.bytes = none)
    (preflight : (exclusiveMonitorPass s width.bytes || s.exclusiveInputs.abortOnFailure) = true →
      permitted s.memory.writable (memoryBase s base) width.bytes = true) :
    storeCore width release failure status src base s =
      step (.exclusive (.store width release status src base)) s := by
  subst failure
  simp only [storeCore, step, exclusiveStep, Arm64Memory.base_refines,
    Arm64Memory.store_refines, access_width_refines, Arm64Register.read_refines,
    Arm64Register.write_refines, status_value_refines, checkedState, spAligned]
  by_cases monitor : exclusiveMonitorPass s width.bytes = true
  · have writable := preflight (by simp [monitor])
    simp only [monitor, Bool.true_or, ↓reduceIte, aligned, Option.isSome_none,
      Bool.false_eq_true, writable, Bool.not_true, Bool.true_and]
    cases commit : s.exclusiveInputs.commitPass <;>
      simp [exclusiveStorePass, monitor, commit]
  · have monitorFalse : exclusiveMonitorPass s width.bytes = false := by
      cases h : exclusiveMonitorPass s width.bytes <;> simp_all
    have failed : exclusiveStorePass s width.bytes = false := by
      simp [exclusiveStorePass, monitorFalse]
    by_cases abort : s.exclusiveInputs.abortOnFailure = true
    · have writable := preflight (by simp [abort])
      simp [monitorFalse, failed, abort, aligned, writable]
    · have abortFalse : s.exclusiveInputs.abortOnFailure = false := by
        cases h : s.exclusiveInputs.abortOnFailure <;> simp_all
      simp [monitorFalse, failed, abortFalse]

/-- A real W status receives the exact outcome of the existing exclusive store
body for every incoming state and native data width. -/
theorem retry_status_refines (width : Width) (release failure : Bool)
    (status : Gpr) (src base : Register) (s : State) :
    readReg (storeCore width release failure status.castSucc src base s).state
      status.castSucc = (if failure then 1 else 0) := by
  cases failure <;>
    simp [storeCore, Arm64Register.write_refines, readReg, writeReg,
      status_value_refines, status.isLt]

/-- The canonical store and its actual W-status branch retain ordered effects
and any store fault. Displacement is a native branch operand. -/
def retrySuffix (width : Width) (release : Bool) (status : Gpr)
    (src base : Register) (displacement : Word) (s : State) : Transition State :=
  let attempt := step (.exclusive (.store width release status.castSucc src base)) s
  match attempt.fault with
  | some _ => attempt
  | none =>
      let branch := step (.branchZero .w32 true status.castSucc displacement) attempt.state
      ⟨branch.state, attempt.events ++ branch.events, branch.fault⟩

/-- The branch takes the supplied retry displacement exactly on the fresh
failure outcome. Success takes the architectural fallthrough; all other state
and exclusive/store events come from the existing canonical refinement. -/
theorem retry_suffix_refines (width : Width) (release failure : Bool)
    (status : Gpr) (src base : Register) (displacement : Word) (s : State)
    (outcome : failure = !exclusiveStorePass s width.bytes)
    (spAligned : spAlignmentFault s base = none)
    (aligned : exclusiveNaturalFault (memoryBase s base) width.bytes = none)
    (preflight : (exclusiveMonitorPass s width.bytes || s.exclusiveInputs.abortOnFailure) = true →
      permitted s.memory.writable (memoryBase s base) width.bytes = true) :
    retrySuffix width release status src base displacement s =
      ⟨{ (storeCore width release failure status.castSucc src base s).state with
          pc := s.pc + 4 + (if failure then displacement else 4) },
        (storeCore width release failure status.castSucc src base s).events, none⟩ := by
  have refined := store_core_refines width release failure status.castSucc src base s
    outcome spAligned aligned preflight
  have statusValue := retry_status_refines width release failure status src base s
  unfold retrySuffix
  rw [← refined]
  have faultNone : (storeCore width release failure status.castSucc src base s).fault = none := rfl
  simp only [faultNone]
  simp only [step, branchStep, statusValue, zeroBranch, List.append_nil]
  cases failure <;> simp [storeCore, narrow, Width.bits]

/-- Any canonical store fault ends the suffix with the complete original fault
transition, retaining its state and events. -/
theorem retry_suffix_fault (width : Width) (release : Bool) (status : Gpr)
    (src base : Register) (displacement : Word) (s : State) (fault : Fault)
    (failed : (step (.exclusive (.store width release status.castSucc src base)) s).fault = some fault) :
    retrySuffix width release status src base displacement s =
      step (.exclusive (.store width release status.castSucc src base)) s := by
  simp [retrySuffix, failed]

end KProgFormal.Refinement.Arm64Exclusive
