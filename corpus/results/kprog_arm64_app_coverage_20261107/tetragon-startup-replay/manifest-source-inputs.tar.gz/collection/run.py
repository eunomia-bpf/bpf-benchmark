from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,hashlib,tarfile,traceback,importlib.util
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');B=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/tetragon-startup-replay';D.mkdir(exist_ok=True);p=json.loads((B/'inputs.json').read_text());state={}
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(phase=phase,utc=datetime.now(timezone.utc).isoformat(),**kw);(B/'status.json').write_text(json.dumps(state,indent=2)+chr(10))
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write(chr(10)+'- LOCAL A '+datetime.now(timezone.utc).isoformat()+': '+s+chr(10))
def inputs_match():
 assert sha(R/p['scanner_path'])==p['scanner_sha256']
 for r in p['inputs']:
  assert sha(R/r['source'])==r['source_sha256'];assert sha(R/r['native'])==r['native_sha256']
def waiting():
 s=json.loads((A/'tetra-mixed-probe/continuation.status.json').read_text());assert s['phase'] in ['waiting_readonly_fix_replay','waiting_cilium_fix_replay'],s
try:
 waiting();inputs_match();save('shared_manifest_generator')
 with (B/'make.log').open('w') as output:r=subprocess.run(['make','-f',str(B/'Makefile'),'prepare'],cwd=R,stdout=output,stderr=subprocess.STDOUT)
 (B/'make.exit').write_text(str(r.returncode)+chr(10));r.check_returncode();inputs_match()
 before=json.loads((B/'manifest.before.json').read_text());after=json.loads((B/'manifest.generated.json').read_text());assert before['map_rules']==after['map_rules'];stage=(R/p['manifest_path']).parent;native_set={r['native'] for r in p['inputs']};extras=[x for x in before['objects'] if str((stage/x['native_object']).resolve().relative_to(R)) not in native_set]
 for row in after['objects']:
  path=Path(row['native_object']);assert path.is_absolute() and str(path.relative_to(R)) in native_set;row['native_object']=str(path.relative_to(stage))
 after['objects']+=extras
 (B/'manifest.after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+chr(10))
 def indexed(m):return {(x['native_object'],x.get('symbol'),x['program']):x for x in m['objects']}
 old,new=indexed(before),indexed(after);changes=[{'identity':list(k),'before':old.get(k),'after':new.get(k)} for k in sorted(old.keys()|new.keys(),key=repr) if old.get(k)!=new.get(k)];assert changes
 report={'utc':datetime.now(timezone.utc).isoformat(),'scope':'Shared linked-source manifest generator consumption for the whole ARM Tetragon application cohort. Runtime application coverage follows the existing serialized queue.','scanner_commit':p['scanner_commit'],'scanner_sha256':p['scanner_sha256'],'native_source_pairs':len(p['inputs']),'before_rows':len(before['objects']),'after_rows':len(after['objects']),'existing_extra_rows_retained':len(extras),'changed_rows':len(changes),'changes':changes,'input_pins':p,'manifest_after_sha256':sha(B/'manifest.after.json'),'make_exit':r.returncode}
 with tarfile.open(D/'manifest-source-inputs.tar.gz','w:gz') as ar:
  for name in ['inputs.json','Makefile','run.py','make.log','make.exit','manifest.before.json','manifest.generated.json','manifest.after.json']:ar.add(B/name,arcname='collection/'+name)
  ar.add(R/p['scanner_path'],arcname='collection/write_native_manifest.py')
  for row in p['inputs']:ar.add(R/row['source'],arcname='inputs/'+row['source'])
 report['raw_archive_sha256']=sha(D/'manifest-source-inputs.tar.gz');(D/'manifest-source-closure.json').write_text(json.dumps(report,indent=2)+chr(10));(D/'README.md').write_text('ARM Tetragon application replay inputs. The shared linked-source scanner from db0228718 includes direct-call and function-address callback closures in source bytecode extents and helper discriminators. The retained62ARM native/source pairs produce '+str(len(after['objects']))+' selectors from '+str(len(before['objects']))+' prior selectors, with '+str(len(changes))+' changed rows. Existing extra startup rows retain their exact fields, and all native object bytes retain their captured hashes. The input archive contains every source ELF, both manifests, commands and generator bytes. The existing serialized application continuation consumes the refreshed staging manifest after source publication. Whole-application execution and universal safety theorem work continue.'+chr(10))
 spec=importlib.util.spec_from_file_location('closure_pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);result=pub.publish([str((D/n).relative_to(R)) for n in ['manifest-source-closure.json','manifest-source-inputs.tar.gz','README.md']],'Refresh ARM Tetragon selectors from linked BPF source closure','arm-tetragon-source-closure');save('published',publication=result)
 waiting();inputs_match();manifest=R/p['manifest_path'];assert sha(manifest)==p['manifest_before_sha256'];manifest.write_bytes((B/'manifest.after.json').read_bytes());save('finished',publication=result,manifest_sha256=sha(manifest),changed_rows=len(changes),before_rows=len(before['objects']),after_rows=len(after['objects']));notice('PUSHED '+result['commit']+' ARM Tetragon shared manifest-source closure result/rawsourceELFs. Existing62native objects retain exact bytes; selectors '+str(len(before['objects']))+'->'+str(len(after['objects']))+',changed'+str(len(changes))+',extra startup rows retained'+str(len(extras))+'. Staging manifest updated while its application observer waits; current OTel guest and Cilium/Tetra/Tracee queue ownership retained. Generic scanner db0228718 is shared with C; application runtime outcomes follow their existing collectors.')
except BaseException as e:save('failed',error=str(e),traceback=traceback.format_exc());raise
