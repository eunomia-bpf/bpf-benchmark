from pathlib import Path
from datetime import datetime,timezone
import ast,fcntl,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;plan=json.loads((N/'plan.json').read_text());D=R/plan['result_directory'];state={}
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(phase=phase,utc=now(),**kw);(N/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
lock=(N/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 for p,h in plan['binary_and_manifest_pins'].items():assert sha(R/p)==h,p
 assert sha(N/'transport.py')==plan['transport_sha256'];D.mkdir(exist_ok=True)
 (D/'launch.json').write_text(json.dumps(plan,indent=2)+'\n')
 with tarfile.open(D/'launch-inputs.tar.gz','w:gz') as ar:
  for n in ['plan.json','transport.py','runtime.sh','run.py']:ar.add(N/n,arcname='launch/'+n)
 (D/'README.md').write_text('Complete OTel two-start replay with8GiB16-19 after scoped Tracee/Cilium and guarded-module Katran sequence. Previous bfaeaf240 guest QEMU log records Clang OOM at3679392KiB resident in4GiB; first request bound and second generated C before SIGKILL. This replay retains the original application native ELF, samples, workload and bound-service requirement, and uses paired entry-resource caller/linker bca4d587e plus guarded module8a57874a. Runtime/source/binary identities and actual terminal counters accompany the launch and result archives. Functional QEMU and universal safety work continue.\n')
 pub=load('otel_memory_pub',A/'six-app-publish.py');receipt=pub.publish([str((D/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Queue full ARM OTel replay with guest compile memory','arm-otel-memory-launch');save('waiting_guarded_sequence',launch_commit=receipt['commit'],waiting_pid=plan['predecessor_pid']);notice('PUSHED '+receipt['commit']+' wholeOTel8GiB16-19 waits guarded sequence4001034. Prior bfaeaf240 actual4GiB guest OOM killed Clang at3679392KiB resident;1bound/second generated C retained. Paired bca4caller/linker and8aguarded module pins captured; original native application/workload retained. A guest cap12GiB retained.')
 try:fd=os.pidfd_open(plan['predecessor_pid'])
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 for p,h in plan['binary_and_manifest_pins'].items():assert sha(R/p)==h,p
 assert sha(N/'transport.py')==plan['transport_sha256']
 save('actual_otel_replay')
 with (N/'runtime.log').open('w') as output:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/'runtime.sh')],cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=output,stderr=subprocess.STDOUT)
 F=D/'replay/trusted-arm64-otelcol-ebpf-profiler-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];audit=load('otel_resource_identity',A/'context-native-collector.py').inspect(summary,archive,'otelcol-ebpf-profiler');tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
  nodes.append(node)
 scope={'__name__':'otel_resource_review'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'otel_resource_review','exec'),scope);coverage=scope['coverage'](summary,archive)
 (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/'runtime.log').read_bytes(),mtime=0));(F/'README.md').write_text('Complete OTel functional replay through the generic resource/caller epoch. Guest exit '+str(summary.get('guest_exit'))+'; host status '+str(summary['ok'])+'; Make exit '+str(done.returncode)+'; stages '+json.dumps(coverage['stages'])+'. Complete raw application/workload/service diagnostics and identity joins accompany this result. Universal theorem and six-application closure work continues.\n');receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain full ARM OTel replay with compile memory','arm-otel-memory-result');save('finished',replay_commit=receipt['commit'],host_ok=summary['ok'],stages=coverage['stages']);notice('PUSHED '+receipt['commit']+' wholeOTel8GiB replay guest='+str(summary.get('guest_exit'))+' stages='+json.dumps(coverage['stages'])+'. Complete raw requests/app work and binary/source epochs retained; universal/six-app closure continues.')
except BaseException as e:save('failed',error=str(e),traceback=traceback.format_exc());raise
