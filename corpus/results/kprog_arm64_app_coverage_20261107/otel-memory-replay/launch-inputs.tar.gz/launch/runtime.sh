set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/otel-memory-replay/transport.py /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py
exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=otelcol-ebpf-profiler TRUSTED_RESULTS=/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261107/otel-memory-replay/replay
