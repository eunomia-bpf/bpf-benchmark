"""Serialize real corpus runs after the retained BCC host closes; keep all failures."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import fcntl,gzip,hashlib,importlib.util,io,json,os,re,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A')
D=R/'corpus/results/kprog_arm64_app_coverage_20261107';S=A/'six-app-queue.status.json'
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=module('a_private_publish',A/'six-app-publish.py')
audit=module('a_native_identity',A/'context-native-collector.py')
state={'phase':'starting','closed_results':[]}
def now():return datetime.now(timezone.utc).isoformat()
def save():state['utc']=now();S.write_text(json.dumps(state,indent=2)+'\n')
def notice(text):
 with Path('/workspaces/.agent-state/kprog-lanes/COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+text+'\n')
def wait_existing(job):
 try:fd=os.pidfd_open(job['pid'])
 except ProcessLookupError:return
 try:
  p=Path('/proc/'+str(job['pid'])+'/stat')
  if p.exists() and p.read_text().rsplit(')',1)[1].split()[19]!=job['starttime']:raise RuntimeError('existing BCC PID identity changed')
  select.select([fd],[],[])
 finally:os.close(fd)
def get(ar,name):
 try:m=ar.getmember(name)
 except KeyError:return None
 if not m.isfile():raise RuntimeError('nonregular archive member '+name)
 return ar.extractfile(m).read()
def coverage(summary,archive):
 rows=[];apps=[]
 with tarfile.open(archive) as ar:
  raw=get(ar,'run/requests/requests.jsonl');receipts=[json.loads(x) for x in raw.decode().splitlines()] if raw else []
  for receipt in receipts:
   name='run/requests/'+Path(receipt.get('artifact_archive') or receipt['failure_archive']).name
   blob=get(ar,name)
   if blob is None:raise RuntimeError('closed receipt lacks archive '+name)
   with tarfile.open(fileobj=io.BytesIO(blob)) as request:
    bpf=get(request,'request/generated/trusted_arm64.bpf.o');source=get(request,'request/generated/trusted_arm64.bpf.c')
    message=(get(request,'request/load.stderr') or b'').decode(errors='replace')
    commands=get(request,'request/generated/commands.jsonl')
    commands=[json.loads(x) for x in commands.decode().splitlines()] if commands else []
    failed=[x for x in commands if x['returncode']]
    if receipt['status']==0:stage,cause='bound_accepted',None
    elif 'infinite loop detected' in message:stage,cause='verifier_rejected','infinite_loop'
    elif 'BPF_PROG_LOAD' in message and any(x in message for x in ['BPF program is too large','too many states','processed 1000001 insns','The sequence of 8193 jumps']):stage,cause='verifier_rejected','complexity_or_size'
    elif 'verifier log:' in message and any(x in message for x in ['invalid mem access','invalid access to','!read_ok','invalid func','unbounded memory access','out of bounds','misaligned','math between','R0 leaks','stack depth','negative min value']):stage,cause='verifier_rejected','verifier_diagnostic'
    elif 'native-link kernel failed' in message and 'link-plan tail_call_maps entry' in message:stage,cause='loader_rejected','native_link_tail_map_plan'
    elif bpf is not None:stage,cause='loader_rejected','see_exact_load_stderr'
    elif source is not None:stage,cause='specialization_failed','compiler'
    else:stage,cause='specialization_failed','generation_or_metadata'
    entry=get(request,'request/kernel.entry')
    rows.append(dict(request_id=receipt['request_id'],source_prog_id=receipt['source_prog_id'],native_sha256=receipt['native_sha256'],entry=entry.decode().strip() if entry else None,status=receipt['status'],stage=stage,cause=cause,proof_generated=bpf is not None,source_generated=source is not None,prog_id=receipt.get('prog_id'),request_archive=name,request_archive_sha256=hashlib.sha256(blob).hexdigest(),failed_commands=failed,error=receipt.get('error'),load_stderr=message))
  for m in ar:
   if m.isfile() and '/details/apps/' in m.name and m.name.endswith('.json'):
    app=json.loads(ar.extractfile(m).read());phases={}
    for phase in ['baseline','post_rejit']:
     measurement=app.get(phase) or {};phases[phase]={'programs':list(measurement.get('bpf',{}).values()),'workload':measurement.get('workload'), 'raw_measurement':measurement}
    apps.append(dict(archive_member=m.name,app=app['app'],status=app['status'],error=app.get('error'),phases=phases))
 counts=Counter(x['stage'] for x in rows)
 return dict(utc=now(),host_ok=summary['ok'],guest_exit=summary.get('guest_exit'),hashes_unchanged=summary.get('hashes_unchanged'),service_request_attempts=len(rows),distinct_source_prog_ids=len({x['source_prog_id'] for x in rows}),proof_generated=sum(x['proof_generated'] for x in rows),stages=dict(counts),failure_causes=dict(Counter(x['cause'] for x in rows if x['cause'])),requests=rows,applications=apps,denominators='Service requests retain retries. Distinct source IDs are recorded separately. Baseline resident programs and every raw phase measurement are retained without using manifest entries as loaded-program counts.')
lock=(A/'six-app-queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 job=json.loads((A/'bcc-full-start-job.json').read_text());state.update(phase='waiting_for_existing_bcc_host',existing_bcc=job);save();wait_existing(job)
 if not (A/'bcc-full-start.exit').exists():raise RuntimeError('BCC host closed without exit receipt')
 state['existing_bcc_exit']=int((A/'bcc-full-start.exit').read_text());save()
 for app in ['otelcol-ebpf-profiler','cilium','tetragon','katran','tracee']:
  folder=D/('trusted-arm64-'+app+'-result');folder.mkdir(exist_ok=True)
  command=['make','-f','corpus/results/kprog_arm64_app_coverage_20261106/Makefile','trusted-service-arm64-run','TRUSTED_APP='+app,'TRUSTED_RESULTS='+str(D)]
  start=now();state.update(phase='running',application=app,command=command,started=start);save();notice('serial current-native-only QEMU app='+app+' START, existing BCC HOST closed exit='+str(state['existing_bcc_exit'])+'. Same canonical kernel/module/root/native worker; 8GiB, CPUs8-11. No rebuild, private candidate not adopted.')
  with (folder/'driver.log').open('w') as output:done=subprocess.run(command,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=output,stderr=subprocess.STDOUT)
  (folder/'driver.log.gz').write_bytes(gzip.compress((folder/'driver.log').read_bytes(),mtime=0))
  launch=dict(started=start,finished=now(),command=command,returncode=done.returncode)
  (folder/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
  summary_path=folder/'summary.json'
  if not summary_path.exists():
   (folder/'README.md').write_text('# ARM '+app+' launch failure\n\nThe Make invocation exited '+str(done.returncode)+' before a closed host summary was produced. Complete launch output is in driver.log.gz; launch.json retains the command. No verifier/application success is inferred. The queue continues independent application attempts.\n')
   paths=[str(p.relative_to(R)) for p in [folder/'launch.json',folder/'driver.log.gz',folder/'README.md']]
   result=pub.publish(paths,'Retain ARM '+app+' native-only launch failure','six-app-'+app)
  else:
   summary=json.loads(summary_path.read_text());archive=folder/summary['archive']
   if summary['started']<start:raise RuntimeError('stale host summary for '+app)
   identity=audit.inspect(summary,archive,app);report=coverage(summary,archive)
   (folder/'native-identity-audit.json').write_text(json.dumps(identity,indent=2)+'\n');(folder/'coverage.json').write_text(json.dumps(report,indent=2)+'\n')
   stages=report['stages'];text='# Native-only ARM '+app+' two-start replay\n\n'
   text+='Host status `'+str(summary['ok'])+'`; guest exit `'+str(summary.get('guest_exit'))+'`; driver exit `'+str(done.returncode)+'`. Request stages: `'+json.dumps(stages,sort_keys=True)+'`. Exact request/native identities, all failure causes/messages, baseline and native per-program work counters and complete phase measurements are in coverage.json and native-identity-audit.json.\n\n'
   text+='All requests retain retries and errors. A generated proof or a bound load alone is not full application acceptance. See applications[].status/error and phases for the actual workload outcome. Manifest counts are not loaded-program denominators. This transport adds no program filters or workload checks and reuses the application source and kernel. Applications submit native ELF; the private kernel candidate is not adopted. QEMU timing is functional only.\n\n'
   text+='Raw '+archive.name+' SHA256 `'+summary['archive_sha256']+'`; identity errors `'+json.dumps(identity['identity_errors'])+'`. All six apps and remaining formal/hardware obligations are still open.\n';(folder/'README.md').write_text(text)
   paths=[str(p.relative_to(R)) for p in [summary_path,archive,folder/'native-identity-audit.json',folder/'coverage.json',folder/'README.md',folder/'launch.json',folder/'driver.log.gz']]
   result=pub.publish(paths,'Retain ARM '+app+' native-only coverage and workload result','six-app-'+app)
   result.update(host_ok=summary['ok'],stages=stages,application_status=[{'app':x['app'],'status':x['status'],'error':x['error']} for x in report['applications']],identity_errors=identity['identity_errors'])
  result['app']=app;state['closed_results'].append(result);save();notice('PUSHED '+result['commit']+' closed '+app+' raw result/coverage via PRIVATEindex/exactpaths/remoteancestor+physicalblobs. '+json.dumps({k:v for k,v in result.items() if k in ['host_ok','stages','application_status','identity_errors']},separators=(',',':'))+' Independent next app continues; no all-six-app claim.')
 state['phase']='finished';save()
except BaseException as error:
 state.update(phase='failed',error=str(error),traceback=traceback.format_exc());save();notice('serial current-native-only queue stopped with explicit error: '+str(error)+'; inspect A/six-app-queue.status.json. Existing/foreign guests and caches preserved.');raise
