from pathlib import Path
from datetime import datetime,timezone
import ast,fcntl,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;plan=json.loads((N/'plan.json').read_text());D=R/plan['result_directory'];state={}
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(phase=phase,utc=now(),**kw);(N/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
lock=(N/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 assert sha(N/'transport.py')==plan['transport_sha256'];D.mkdir(exist_ok=True)
 (D/'launch.json').write_text(json.dumps(plan,indent=2)+'\n');(D/'previous-diagnosis.json').write_bytes((N/'previous-diagnosis.json').read_bytes())
 with tarfile.open(D/'launch-inputs.tar.gz','w:gz') as ar:
  for n in ['plan.json','transport.py','runtime.sh','run.py','qemu-clock-help.txt','previous-diagnosis.json']:ar.add(N/n,arcname='launch/'+n)
 (D/'README.md').write_text('Complete Cilium functional replay with the common QEMU instruction-count virtual clock. Previous full recipe ed5f63c65 reaches initial endpoint generation after XDP/host attachments and3m41.424607504s host-template compilation; Cilium retains its330s context deadline. QEMU8.2.2 supplies shift=0,align=off,sleep=off: virtual clock ticks follow executed instructions. This runtime mechanism addresses application startup under software simulation while application code, deadline, native bytes, workload and samples retain their original recipe. Exact QEMU help, sources and binary pins accompany the launch.\n\nThe existing Tetragon/Tracee sequence closes first. One2GiB common-service control then checks native result2 through the same transport; the complete Cilium baseline/native recipe follows with8GiB on8-15. Concurrent OTel uses4GiB16-19; A total12GiB. Functional QEMU counters and clock settings remain attached to each raw result. Hardware timing follows the operator priority order.\n')
 pub=load('clock_pub',A/'six-app-publish.py');receipt=pub.publish([str((D/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','previous-diagnosis.json','README.md']],'Prepare complete Cilium replay on the QEMU instruction clock','arm-cilium-clock-launch');save('waiting_existing_tracee_sequence',launch_commit=receipt['commit'],waiting_pid=plan['waiting_tracee_pid']);notice('PUSHED '+receipt['commit']+' generic QEMU instructionclock candidate and complete Cilium deadline diagnosis. Existing Tetra/Tracee sequence retained; new observer waits3774961, then commoncontrol2GiB and wholeCilium8GiB8-15. Original application deadline330s/native/workload/sample bytes retained; OTel4GiB16-19 continues and totalA12GiB.')
 try:fd=os.pidfd_open(plan['waiting_tracee_pid'])
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 previous=json.loads((A/plan['waiting_tracee_state']).read_text());assert previous['phase']=='finished',previous
 audit=load('clock_identity',A/'context-native-collector.py');tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
  nodes.append(node)
 scope={'__name__':'clock_review'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'clock_review','exec'),scope)
 for case,folder,label in [('control','control','service'),('cilium','replay','cilium')]:
  for p,h in plan['binary_and_manifest_pins'].items():assert sha(R/p)==h,p
  assert sha(N/'transport.py')==plan['transport_sha256'];save('actual_'+label+'_replay')
  with (N/(label+'.log')).open('w') as output:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/'runtime.sh'),'TRUSTED_APP='+case,'TRUSTED_RESULTS='+str(D/folder)],cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=output,stderr=subprocess.STDOUT)
  F=D/folder/('trusted-arm64-cilium-result' if case=='cilium' else 'trusted-arm64-service-result');summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];identities=audit.inspect(summary,archive,case);coverage=scope['coverage'](summary,archive)
  (F/'native-identity-audit.json').write_text(json.dumps(identities,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/(label+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Functional '+case+' replay under the QEMU instruction-count virtual clock. Guest exit '+str(summary.get('guest_exit'))+'; host status '+str(summary['ok'])+'; Make exit '+str(done.returncode)+'; stages '+json.dumps(coverage['stages'])+'. Exact clock/resource settings, raw app work and all service/native identities accompany this result. Universal theorem and six-application work continues.\n');receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain ARM '+case+' functional replay on the instruction clock','arm-clock-'+label+'-result');state[label+'_result_commit']=receipt['commit'];save(label+'_closed',host_ok=summary['ok'],stages=coverage['stages']);notice('PUSHED '+receipt['commit']+' complete '+case+' instructionclock replay guest='+str(summary.get('guest_exit'))+' stages='+json.dumps(coverage['stages'])+'. Exact raw clock/work/identity records retained.')
  if case=='control':assert summary['ok'] and summary['guest']['retval']==2,summary.get('guest')
 save('finished')
except BaseException as e:save('failed',error=str(e),traceback=traceback.format_exc());raise
