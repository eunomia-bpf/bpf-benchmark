from pathlib import Path
from datetime import datetime,timezone
import ast,fcntl,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/entry-resource-scope';C=R/'corpus/results/kprog_arm64_app_coverage_20261107/cilium-clock-replay';plan=json.loads((N/'adoption.json').read_text());state={};clock_state={}
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(phase=phase,utc=now(),**kw);(N/'status.json').write_text(json.dumps(state,indent=2)+'\n')
 (A/'cilium-clock/status.json').write_text(json.dumps(dict(state,queue_pid=os.getpid()),indent=2)+chr(10))
 view=dict(state,queue_pid=os.getpid()) if 'tracee_result_commit' not in state else dict(phase='finished',utc=now(),replay_commit=state['tracee_result_commit'],queue_pid=os.getpid())
 (A/'arm-abi-join-candidate/continuation.status.json').write_text(json.dumps(view,indent=2)+chr(10))
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
lock=(N/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 build=json.loads((A/'entry-resource-build/status.json').read_text());assert build['phase']=='finished';pins=build['plan']['binary_pins'];pub=load('scope_app_pub',A/'six-app-publish.py')
 for p,h in pins.items():assert sha(R/p)==h,p
 (D/'app-successors.json').write_text(json.dumps(plan,indent=2)+'\n')
 with tarfile.open(D/'app-successors.tar.gz','w:gz') as ar:
  for n in ['adoption.json','transport.py','clock-transport.py','runtime.sh','clock-runtime.sh','run.py','previous-observers.tar.gz']:ar.add(N/n,arcname='launch/'+n)
  for n in ['six-app-queue.py','context-native-collector.py']:ar.add(A/n,arcname='collectors/'+n)
 p=D/'README.md';p.write_text(p.read_text()+'\nThe paired application queue archives its exact snapshots in app-successors.tar.gz. It waits for the existing active predecessor, runs the common service control and complete Tracee recipe, then the instruction-clock control and complete Cilium recipe. Existing OTel4GiB16-19 continues; each app guest uses8GiB and each control2GiB. Native-only application submissions use BPFREJIT_NATIVE_LINK_BINARY to select the paired entry-resource linker in the native phase through the existing corpus environment mechanism.\n');receipt=pub.publish([str((D/n).relative_to(R)) for n in ['app-successors.json','app-successors.tar.gz','README.md']],'Pair ARM application successors with scoped native resources','arm-scoped-app-launch');save('waiting_predecessor',launch_commit=receipt['commit'],waiting_pid=plan['predecessor_pid']);notice('PUSHED '+receipt['commit']+' paired ARM successors after entryresource build '+build['publication']['commit']+'. Waiting-only observer snapshots retained and replaced by solequeue'+str(os.getpid())+'; active OTel/Tetra runtime epochs retain executable bytes. Tracee/commoncontrol then Cilium instructionclock/commoncontrol; A memory12GiB maximum.')
 try:fd=os.pidfd_open(plan['predecessor_pid'])
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 previous=json.loads((A/plan['predecessor_state']).read_text());assert previous['phase']=='finished',previous
 audit=load('scoped_app_identity',A/'context-native-collector.py');tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
  nodes.append(node)
 scope={'__name__':'scoped_app_review'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'scoped_app_review','exec'),scope)
 jobs=[('control',D/'control','runtime.sh','resource-control'),('tracee',D/'tracee-replay','runtime.sh','tracee'),('control',C/'control','clock-runtime.sh','clock-control'),('cilium',C/'replay','clock-runtime.sh','cilium')]
 for case,out,script,label in jobs:
  for p,h in pins.items():assert sha(R/p)==h,p
  for p,h in plan['source_pins'].items():assert sha(N/p)==h,p
  save('actual_'+label+'_replay');notice('START '+label+' complete existing Make recipe with scoped ARM caller/linker; exact transport snapshot/pins retained.')
  with (N/(label+'.log')).open('w') as output:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/script),'TRUSTED_APP='+case,'TRUSTED_RESULTS='+str(out)],cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=output,stderr=subprocess.STDOUT)
  F=out/('trusted-arm64-service-result' if case=='control' else 'trusted-arm64-'+case+'-result');summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];identities=audit.inspect(summary,archive,case);coverage=scope['coverage'](summary,archive)
  (F/'native-identity-audit.json').write_text(json.dumps(identities,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/(label+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Complete '+label+' functional replay with paired scoped-resource caller/linker. Guest exit '+str(summary.get('guest_exit'))+'; host status '+str(summary['ok'])+'; Make exit '+str(done.returncode)+'; stages '+json.dumps(coverage['stages'])+'. Raw app/request/work/clock records retain exact input epochs. Universal theorem and complete six-application work continues.\n');receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain ARM '+label+' scoped resource runtime coverage','arm-scoped-'+label);state[label+'_result_commit']=receipt['commit'];save(label+'_closed',host_ok=summary['ok'],stages=coverage['stages']);notice('PUSHED '+receipt['commit']+' complete '+label+' guest='+str(summary.get('guest_exit'))+' stages='+json.dumps(coverage['stages'])+'. All raw identities/errors/work counters retained.')
  if case=='control':assert summary['ok'] and summary['guest']['retval']==2,summary.get('guest')
 save('finished')
except BaseException as e:save('failed',error=str(e),traceback=traceback.format_exc());raise
