from pathlib import Path
import json,subprocess,shutil,hashlib,datetime,traceback,os
B=Path(__file__).resolve().parent;R=Path('/workspaces/repository');i=json.loads((B/'inputs.json').read_text());status={'phase':'configure','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():status['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(B/'status.json').write_text(json.dumps(status,indent=2)+chr(10))
try:
 save()
 with (B/'configure.log').open('w') as output:subprocess.run(i['configure_command'],env=dict(os.environ,**i['configure_environment']),cwd=R,stdout=output,stderr=subprocess.STDOUT,check=True)
 status['phase']='incremental_component_build';save()
 command=['cmake','--build',str(R/i['new_build_directory']),'--parallel','4','--target','native_loader_shared','trusted-native-loader','trusted-service-client']
 with (B/'build.log').open('w') as output:subprocess.run(['taskset','-c','12-15',*command],cwd=R,stdout=output,stderr=subprocess.STDOUT,check=True)
 for p,h in i['source_pins'].items():
  if hashlib.sha256((R/p).read_bytes()).hexdigest()!=h:raise RuntimeError('Loader source changed during build: '+p)
 old=R/i['old_build_directory'];new=R/i['new_build_directory'];shutil.copy2(old/'trusted-native.o',new/'trusted-native.o')
 for n,h in i['old_binary_pins'].items():
  if hashlib.sha256((old/n).read_bytes()).hexdigest()!=h:raise RuntimeError('Existing runtime binary changed: '+n)
 status.update(phase='finished',command=command,binaries={n:hashlib.sha256((new/n).read_bytes()).hexdigest() for n in ['trusted-native-loader','libnative_loader.so','trusted-service-client','trusted-native.o']});save()
except BaseException as e:status.update(phase='failed',error=str(e),traceback=traceback.format_exc());save();raise
