#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"root"
#define LINUX_COMPILE_HOST	"coder-22123351-d4a5-40fc-bc3b-1b853af74a7e-c7ccfb766-mpvhz"
#define LINUX_COMPILER		"aarch64-linux-gnu-gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, GNU ld (GNU Binutils for Ubuntu) 2.42"
