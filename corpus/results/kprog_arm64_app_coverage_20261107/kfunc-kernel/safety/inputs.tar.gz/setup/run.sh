set +e
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/kfunc-safety/inside.sh >/workspaces/.agent-state/kprog-lanes/A/kfunc-safety/driver.log 2>&1
rc=$?
echo "$rc" >/workspaces/.agent-state/kprog-lanes/A/kfunc-safety/exit
exit "$rc"
