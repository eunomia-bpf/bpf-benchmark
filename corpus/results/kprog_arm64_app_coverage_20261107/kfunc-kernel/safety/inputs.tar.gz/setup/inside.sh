set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/kfunc-safety/fixtures /workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp
mount --bind /workspaces/.agent-state/kprog-lanes/A/kfunc-safety/transport.py /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py
mount --bind /workspaces/.agent-state/kprog-lanes/A/skb-live-projection/after.h /workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h
make -f /workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp/Makefile build
exec make -f /workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp/Makefile qemu RUN_OUT=/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261107/kfunc-kernel/safety
