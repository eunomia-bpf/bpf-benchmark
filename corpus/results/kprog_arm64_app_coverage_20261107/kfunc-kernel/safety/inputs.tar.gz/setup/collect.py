from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,json,os,select,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/kfunc-kernel/safety';pid=int((N/'run.pid').read_text())
def save(phase,**kw):(N/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
try:
 save('waiting_existing_suite',pid=pid)
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 F=D/'trusted-arm64-service-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive']
 with tarfile.open(archive) as ar:rows=json.load(ar.extractfile('run/outcomes.json'))
 counts=dict(collections.Counter(r['stage'] for r in rows));report=dict(make_exit=int((N/'exit').read_text()),host_ok=summary['ok'],guest_exit=summary['guest_exit'],cases=len(rows),stages=counts,unsafe_accepted=sum(r['negative'] and r['stage']=='accepted_finding' for r in rows),unsafe_executed=sum(r['negative'] and r['unsafe_native_executed'] for r in rows),native_identities={r['name']:r['native_sha256'] for r in rows},archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
 (D/'outcomes.json').write_text(json.dumps(report,indent=2)+'\n');(D/'driver.log.gz').write_bytes(gzip.compress((N/'driver.log').read_bytes(),mtime=0))
 with tarfile.open(D/'inputs.tar.gz','w:gz') as ar:
  for n in ['plan.json','fixtures','inside.sh','run.sh','collect.py','transport.py']:ar.add(N/n,arcname='setup/'+n)
  ar.add(R/'kprog/formal/build/fidelity-trusted-arm64-kfunc',arcname='native-fixtures-and-producer')
 (D/'README.md').write_text('Existing ARM native safety suite on the matched kfunc kernel\n\nThe complete34-fixture suite uses the common kernel-owned service, paired caller, e183 linker and30b8c570 ARM kernel/module profile. Named positive controls execute through TEST_RUN; unsafe fixtures use load-only submission. Actual stages '+json.dumps(counts)+', unsafe accepted '+str(report['unsafe_accepted'])+', unsafe executed '+str(report['unsafe_executed'])+', guest exit '+str(report['guest_exit'])+'. The combined outcome table, complete guest/service archives, compiler commands and exact native fixture hashes retain the epoch. The suite exercises generic mechanisms; universal simulator and binding composition continues with V/C.\n')
 spec=importlib.util.spec_from_file_location('safety_publish',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);paths=[D/'outcomes.json',D/'driver.log.gz',D/'inputs.tar.gz',D/'README.md',F/'summary.json',archive];receipt=pub.publish([str(p.relative_to(R)) for p in paths],'Retain matched ARM native safety regression outcomes','arm-kfunc-safety');save('finished',publication=receipt,outcome=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+receipt['commit']+' matchedARM complete34safety '+json.dumps(counts)+'; unsafeaccepted='+str(report['unsafe_accepted'])+'/executed='+str(report['unsafe_executed'])+' guest='+str(report['guest_exit'])+'. Generic fixtures/common service/exact native hashes/fullraw archived. Universal O1/O2/O4 andapplicationcomposition continue.\n')
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
