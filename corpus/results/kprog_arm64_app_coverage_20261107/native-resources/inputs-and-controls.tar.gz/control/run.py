from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,tarfile,gzip,importlib.util,traceback,shutil
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');B=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261107/native-resources';D.mkdir(exist_ok=True);p=json.loads((B/'inputs.json').read_text());state={}
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(phase=phase,utc=datetime.now(timezone.utc).isoformat(),**kw);(B/'status.json').write_text(json.dumps(state,indent=2)+chr(10))
def load(n,path):
 s=importlib.util.spec_from_file_location(n,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run(name,cmd):
 save(name)
 with (B/(name+'.log')).open('w') as output:r=subprocess.run(cmd,cwd=R,stdout=output,stderr=subprocess.STDOUT)
 (B/(name+'.exit')).write_text(str(r.returncode)+chr(10));r.check_returncode()
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write(chr(10)+'- LOCAL A '+datetime.now(timezone.utc).isoformat()+': '+s+chr(10))
try:
 save('frozen_source_build')
 for target in ['module','loader','transport-build']:run(target,['make','-f',str(B/'Makefile'),target])
 for path,h in p['source_pins'].items():assert sha(R/path)==h,path
 old=R/'kinsn/module/arm64/build';new=R/p['module_output'];out=R/'kprog/arm64/build/trusted-transport';private=B/'transport-output';shutil.copy2(out/'test-trusted-transport',private/'test-trusted-transport')
 script=['set -eu','mount --bind '+str(new)+' '+str(old),'mount --bind '+str(private)+' '+str(out),'mount --bind '+str(B/'transport-replay.py')+' '+str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted-arm64-transport-result/replay.py'),'exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-transport-arm64-run TRANSPORT_ROOTFS='+str(R/p['rootfs'])];(B/'transport.sh').write_text(chr(10).join(script)+chr(10));run('transport',['unshare','--mount','--propagation','private','sh',str(B/'transport.sh')]);transport=json.loads((private/'result.json').read_text());assert transport['guest_status']==0 and transport['qemu_exit']==0;console=(private/'console.log').read_text(errors='replace');markers=[x.strip() for x in console.splitlines() if 'REJECTED (' in x or ': PASS' in x];assert len(markers)==34,len(markers)
 oldloader=R/'kprog/libnativeloader/build-arm64-a-map-order-v3';loader=R/p['loader_prefix'];script=['set -eu','mount --bind '+str(new)+' '+str(old)]
 for n in ['trusted-native-loader','libnative_loader.so','trusted-service-client']:script.append('mount --bind '+str(loader/n)+' '+str(oldloader/n))
 link=R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link-arm64-rodata-extents';retainedlink=link.with_name('native-link');p['retained_runtime'][str(retainedlink.relative_to(R))]=sha(retainedlink)
 script+=['mount --bind '+str(link)+' '+str(retainedlink),'mount --bind '+str(A/'readonly-layout-extent/control.o')+' '+str(oldloader/'trusted-native.o'),'exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=control TRUSTED_RESULTS='+str(D/'replay')];(B/'service.sh').write_text(chr(10).join(script)+chr(10));run('service',['unshare','--mount','--propagation','private','sh',str(B/'service.sh')]);F=D/'replay/trusted-arm64-service-result';s=json.loads((F/'summary.json').read_text());audit=load('resource_identity',A/'context-native-collector.py').inspect(s,F/s['archive'],'arm-native-resources');assert s['guest_exit']==0 and s['qemu_returncode']==0 and s['guest']['retval']==2 and not audit['identity_errors']
 for path,h in p['retained_runtime'].items():assert sha(R/path)==h,path
 p.update(transport_result=transport,transport_markers=markers,transport_rejection_count=sum('REJECTED (' in v for v in markers),service_host_ok=s['ok'],service_guest_exit=s['guest_exit'],service_retval=s['guest']['retval'],module_sha256=sha(new/'bpf_arm64_native_lab.ko'),loader_binaries={n:sha(loader/n) for n in ['trusted-native-loader','libnative_loader.so','trusted-service-client','trusted-native.o']},linker_sha256=sha(link),identity_errors=audit['identity_errors'])
 (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+chr(10));(F/'driver.log.gz').write_bytes(gzip.compress((B/'service.log').read_bytes(),mtime=0));(F/'README.md').write_text('ARM native-resource capability build and common-service compatibility control. QEMU/guest exit0; native retval2 and request identity agreement. Original host status and source drift fields remain in summary.json. Universal safety and complete-application execution continue.'+chr(10))
 (D/'summary.json').write_text(json.dumps(p,indent=2)+chr(10))
 with tarfile.open(D/'inputs-and-controls.tar.gz','w:gz') as ar:
  for n in ['inputs.json','Makefile','run.py','freeze.sh','initial-source-epoch-diagnostic.tar.gz','module-build.sh','transport-replay.py','module.log','module.exit','loader.log','loader.exit','transport-build.log','transport-build.exit','transport.sh','transport.log','transport.exit','transport-output','service.sh']:ar.add(B/n,arcname='control/'+n)
  for path in p['source_pins']:
   q=R/path
   if sha(q)!=p['source_pins'][path]:raise RuntimeError('Captured resource source changed: '+path)
   ar.add(q,arcname='source/'+path)
  ar.add(new/'bpf_arm64_native_lab.ko',arcname='bin/bpf_arm64_native_lab.ko')
  for n in p['loader_binaries']:ar.add(loader/n,arcname='bin/'+n)
 (D/'README.md').write_text('AArch64 adoption of published native-map capabilities c94fbff01 and caller/service5ed0c5831. Kernel module and caller reuse the existing kernel, ARM dependencies and warm component caches. The existing portable transport suite records30expected refusals plus4PASS markers; its resource vector cases exercise pinned object identity and lifecycle. The common registered-service control generates/binds fresh verifier code and executes native retval2. Captured sources, module/caller binaries and raw controls accompany the result. Canonical host Image/module/old caller bytes remain pinned in summary.json while the active OTel application retains its epoch. Subsequent whole-application startups select the new module/caller paths; universal simulator, specialization and link-preservation theorem work continues.'+chr(10))
 pub=load('resource_pub',A/'six-app-publish.py');paths=[str((D/n).relative_to(R)) for n in ['summary.json','inputs-and-controls.tar.gz','README.md']]+[str(q.relative_to(R)) for q in [F/'summary.json',F/s['archive'],F/'native-identity-audit.json',F/'driver.log.gz',F/'README.md']];result=pub.publish(paths,'Adopt native map capabilities in the ARM trusted service path','arm-native-resources');save('finished',publication=result,plan=p);notice('PUSHED '+result['commit']+' actual ARM resource capability controls and coherent module/caller build. Portable transport34markers/30refusals and common-service guest0/native2; canonical Image/module/active old caller retained. Future Cilium/Tetra/Tracee paths consume the new module and current typed-tail caller prefix after the existing OTel application closes.')
except BaseException as e:save('failed',error=str(e),traceback=traceback.format_exc());raise
