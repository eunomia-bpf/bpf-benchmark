set -eu
mount --bind /workspaces/repository/kinsn/module/arm64/build-native-resources /workspaces/repository/kinsn/module/arm64/build
mount --bind /workspaces/repository/kprog/libnativeloader/build-arm64-typed-tail-v1/trusted-native-loader /workspaces/repository/kprog/libnativeloader/build-arm64-a-map-order-v3/trusted-native-loader
mount --bind /workspaces/repository/kprog/libnativeloader/build-arm64-typed-tail-v1/libnative_loader.so /workspaces/repository/kprog/libnativeloader/build-arm64-a-map-order-v3/libnative_loader.so
mount --bind /workspaces/repository/kprog/libnativeloader/build-arm64-typed-tail-v1/trusted-service-client /workspaces/repository/kprog/libnativeloader/build-arm64-a-map-order-v3/trusted-service-client
mount --bind /workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link-arm64-rodata-extents /workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link
mount --bind /workspaces/.agent-state/kprog-lanes/A/readonly-layout-extent/control.o /workspaces/repository/kprog/libnativeloader/build-arm64-a-map-order-v3/trusted-native.o
exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=control TRUSTED_RESULTS=/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261107/native-resources/replay
