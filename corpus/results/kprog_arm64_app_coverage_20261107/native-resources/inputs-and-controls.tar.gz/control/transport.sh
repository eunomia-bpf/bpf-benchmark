set -eu
mount --bind /workspaces/repository/kinsn/module/arm64/build-native-resources /workspaces/repository/kinsn/module/arm64/build
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-resources/transport-output /workspaces/repository/kprog/arm64/build/trusted-transport
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-resources/transport-replay.py /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/trusted-arm64-transport-result/replay.py
exec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-transport-arm64-run TRANSPORT_ROOTFS=/workspaces/repository/kprog/arm64/build/app-runtime-v35/root
