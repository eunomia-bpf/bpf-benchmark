set -eu
cd /workspaces/repository
mount --bind /workspaces/repository/kinsn/module/arm64/build-native-resources /workspaces/repository/kinsn/module/arm64/build
exec make -C vendor/build/arm64/linux ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- M=/workspaces/repository/kinsn/module/arm64 MO=/workspaces/repository/kinsn/module/arm64/build modules -j4
