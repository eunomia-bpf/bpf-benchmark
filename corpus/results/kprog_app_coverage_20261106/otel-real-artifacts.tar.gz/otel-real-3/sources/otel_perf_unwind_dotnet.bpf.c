#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 200U
#define LICENSE __x86_original_license
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/otel-real-3/original/declarations.h"
#undef LICENSE
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/otel-real-3/simulator/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

static const __u8 __x86_rodata_0[66] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x64, 0x6f, 0x74, 0x6e, 0x65, 0x74, 0x3a, 0x20, 0x20, 0x2d, 0x2d, 0x3e, 0x20, 0x66, 0x69, 0x6e, 0x64, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x20, 0x73, 0x74, 0x61, 0x72, 0x74, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x25, 0x6c, 0x78, 0x3a, 0x20, 0x70, 0x63, 0x5f, 0x62, 0x61, 0x73, 0x65, 0x20, 0x25, 0x6c, 0x78, 0x2c, 0x20, 0x6d, 0x61, 0x70, 0x5f, 0x73, 0x74, 0x61, 0x72, 0x74, 0x20, 0x25, 0x6c, 0x78, 0x0a, 0x00};
static const __u8 __x86_rodata_1[67] SEC(".rodata.native.1") __attribute__((aligned(16))) = {0x64, 0x6f, 0x74, 0x6e, 0x65, 0x74, 0x3a, 0x20, 0x20, 0x2d, 0x2d, 0x3e, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x5f, 0x73, 0x74, 0x61, 0x72, 0x74, 0x20, 0x3d, 0x20, 0x25, 0x6c, 0x78, 0x2c, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x5f, 0x68, 0x65, 0x61, 0x64, 0x65, 0x72, 0x20, 0x3d, 0x20, 0x25, 0x6c, 0x78, 0x2c, 0x20, 0x70, 0x63, 0x5f, 0x6f, 0x66, 0x66, 0x73, 0x65, 0x74, 0x20, 0x3d, 0x20, 0x25, 0x6c, 0x78, 0x0a, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L__const.dotnet_find_code_start.____fmt\",\"size\":66},{\"proof_section\":\".rodata.native.1\",\"proof_symbol\":\"__x86_rodata_1\",\"native_symbol\":\".L__const.unwind_one_dotnet_frame.____fmt.9\",\"size\":67}]}";

SEC("perf_event/unwind_dotnet")
int otel_perf_unwind_dotnet_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x98 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 152ULL);
x86_l_11:
	/* 0x11: mov    r15,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDI, X86_WIDTH_64);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1c:
	/* 0x1c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&per_cpu_records));
x86_l_23:
	/* 0x23: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28:
	/* 0x28: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2d:
	/* 0x2d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f:
	/* 0x2f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_32:
	/* 0x32: je     77cb <perf_unwind_dotnet+0x77cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32, 0x77cb, x86_l_77cb);
x86_l_38:
	/* 0x38: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_3b:
	/* 0x3b: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d:
	/* 0x3d: mov    DWORD PTR [rsp+0x94],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_44:
	/* 0x44: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_4b:
	/* 0x4b: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f:
	/* 0x4f: jne    71d <perf_unwind_dotnet+0x71d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f, 0x71d, x86_l_71d);
x86_l_55:
	/* 0x55: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&dotnet_procs));
x86_l_5c:
	/* 0x5c: lea    rsi,[rsp+0x94] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_64:
	/* 0x64: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_69:
	/* 0x69: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6b:
	/* 0x6b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e:
	/* 0x6e: je     9d <perf_unwind_dotnet+0x9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e, 0x9d, x86_l_9d);
x86_l_70:
	/* 0x70: mov    BYTE PTR [r14+0x1385],0x2 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 21461951578114ULL);
x86_l_78:
	/* 0x78: mov    DWORD PTR [rsp+0x70],0x5a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337242ULL);
x86_l_80:
	/* 0x80: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_87:
	/* 0x87: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8c:
	/* 0x8c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_91:
	/* 0x91: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_93:
	/* 0x93: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_96:
	/* 0x96: je     d3 <perf_unwind_dotnet+0xd3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x96, 0xd3, x86_l_d3);
x86_l_98:
	/* 0x98: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_9b:
	/* 0x9b: jmp    dd <perf_unwind_dotnet+0xdd> */
	X86_SIM_X86_JMP(0x9b, 0xdd, x86_l_dd);
x86_l_9d:
	/* 0x9d: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a1:
	/* 0xa1: jne    807 <perf_unwind_dotnet+0x807> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa1, 0x807, x86_l_807);
x86_l_a7:
	/* 0xa7: mov    DWORD PTR [rsp+0x70],0x5c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337244ULL);
x86_l_af:
	/* 0xaf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_b6:
	/* 0xb6: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_bb:
	/* 0xbb: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_c0:
	/* 0xc0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c2:
	/* 0xc2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_c5:
	/* 0xc5: je     2ae <perf_unwind_dotnet+0x2ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc5, 0x2ae, x86_l_2ae);
x86_l_cb:
	/* 0xcb: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_ce:
	/* 0xce: jmp    2b8 <perf_unwind_dotnet+0x2b8> */
	X86_SIM_X86_JMP(0xce, 0x2b8, x86_l_2b8);
x86_l_d3:
	/* 0xd3: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d7:
	/* 0xd7: jne    887 <perf_unwind_dotnet+0x887> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd7, 0x887, x86_l_887);
x86_l_dd:
	/* 0xdd: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_e4:
	/* 0xe4: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_eb:
	/* 0xeb: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_f2:
	/* 0xf2: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_fa:
	/* 0xfa: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fe:
	/* 0xfe: jne    78e <perf_unwind_dotnet+0x78e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfe, 0x78e, x86_l_78e);
x86_l_104:
	/* 0x104: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_107:
	/* 0x107: jb     76c0 <perf_unwind_dotnet+0x76c0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x107, 0x76c0, x86_l_76c0);
x86_l_10d:
	/* 0x10d: lea    rax,[rbx+0x2000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_114:
	/* 0x114: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_117:
	/* 0x117: jae    76c0 <perf_unwind_dotnet+0x76c0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x117, 0x76c0, x86_l_76c0);
x86_l_11d:
	/* 0x11d: mov    BYTE PTR [rsp+0x88],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_124:
	/* 0x124: mov    QWORD PTR [rsp+0x60],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_129:
	/* 0x129: lea    rbx,[r14+0xed0] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_130:
	/* 0x130: mov    rax,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R14, X86_WIDTH_64);
x86_l_133:
	/* 0x133: add    rax,0xf80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 3968ULL);
x86_l_139:
	/* 0x139: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_141:
	/* 0x141: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_148:
	/* 0x148: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_14f:
	/* 0x14f: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_154:
	/* 0x154: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_15c:
	/* 0x15c: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_15f:
	/* 0x15f: and    rax,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_163:
	/* 0x163: cmp    rax,0x80 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_169:
	/* 0x169: jne    24e <perf_unwind_dotnet+0x24e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x169, 0x24e, x86_l_24e);
x86_l_16f:
	/* 0x16f: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_176:
	/* 0x176: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_17b:
	/* 0x17b: mov    r8d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 112ULL);
x86_l_181:
	/* 0x181: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_188:
	/* 0x188: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_18b:
	/* 0x18b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_190:
	/* 0x190: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_193:
	/* 0x193: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_196:
	/* 0x196: je     2c2 <perf_unwind_dotnet+0x2c2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x196, 0x2c2, x86_l_2c2);
x86_l_19c:
	/* 0x19c: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_1a3:
	/* 0x1a3: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a7:
	/* 0x1a7: jne    998 <perf_unwind_dotnet+0x998> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a7, 0x998, x86_l_998);
x86_l_1ad:
	/* 0x1ad: mov    DWORD PTR [rsp+0xc],0x5d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607645ULL);
x86_l_1b5:
	/* 0x1b5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_1bc:
	/* 0x1bc: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c1:
	/* 0x1c1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1c6:
	/* 0x1c6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c8:
	/* 0x1c8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1cb:
	/* 0x1cb: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1d0:
	/* 0x1d0: jne    2a6 <perf_unwind_dotnet+0x2a6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d0, 0x2a6, x86_l_2a6);
x86_l_1d6:
	/* 0x1d6: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1da:
	/* 0x1da: je     770d <perf_unwind_dotnet+0x770d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1da, 0x770d, x86_l_770d);
x86_l_1e0:
	/* 0x1e0: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_1ea:
	/* 0x1ea: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1ef:
	/* 0x1ef: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_1f9:
	/* 0x1f9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1fe:
	/* 0x1fe: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_208:
	/* 0x208: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20d:
	/* 0x20d: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_217:
	/* 0x217: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21c:
	/* 0x21c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_226:
	/* 0x226: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22b:
	/* 0x22b: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_235:
	/* 0x235: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23a:
	/* 0x23a: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23f:
	/* 0x23f: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_244:
	/* 0x244: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_249:
	/* 0x249: jmp    451 <perf_unwind_dotnet+0x451> */
	X86_SIM_X86_JMP(0x249, 0x451, x86_l_451);
x86_l_24e:
	/* 0x24e: lea    rdi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_253:
	/* 0x253: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_258:
	/* 0x258: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_25d:
	/* 0x25d: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_262:
	/* 0x262: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_265:
	/* 0x265: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_267:
	/* 0x267: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_26a:
	/* 0x26a: je     2d2 <perf_unwind_dotnet+0x2d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a, 0x2d2, x86_l_2d2);
x86_l_26c:
	/* 0x26c: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_273:
	/* 0x273: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277:
	/* 0x277: jne    9f1 <perf_unwind_dotnet+0x9f1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x277, 0x9f1, x86_l_9f1);
x86_l_27d:
	/* 0x27d: mov    DWORD PTR [rsp+0xc],0x5d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607645ULL);
x86_l_285:
	/* 0x285: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_28c:
	/* 0x28c: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_291:
	/* 0x291: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_296:
	/* 0x296: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_298:
	/* 0x298: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_29b:
	/* 0x29b: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2a0:
	/* 0x2a0: je     3de <perf_unwind_dotnet+0x3de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a0, 0x3de, x86_l_3de);
x86_l_2a6:
	/* 0x2a6: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2a9:
	/* 0x2a9: jmp    770d <perf_unwind_dotnet+0x770d> */
	X86_SIM_X86_JMP(0x2a9, 0x770d, x86_l_770d);
x86_l_2ae:
	/* 0x2ae: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b2:
	/* 0x2b2: jne    902 <perf_unwind_dotnet+0x902> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b2, 0x902, x86_l_902);
x86_l_2b8:
	/* 0x2b8: mov    eax,0x1770 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6000ULL);
x86_l_2bd:
	/* 0x2bd: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0x2bd, 0x7712, x86_l_7712);
x86_l_2c2:
	/* 0x2c2: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_2ca:
	/* 0x2ca: and    ebp,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_2cd:
	/* 0x2cd: jmp    bac <perf_unwind_dotnet+0xbac> */
	X86_SIM_X86_JMP(0x2cd, 0xbac, x86_l_bac);
x86_l_2d2:
	/* 0x2d2: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2d6:
	/* 0x2d6: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2dd:
	/* 0x2dd: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2e2:
	/* 0x2e2: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2e9:
	/* 0x2e9: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2ee:
	/* 0x2ee: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2f5:
	/* 0x2f5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_2fc:
	/* 0x2fc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff:
	/* 0x2ff: jne    a4a <perf_unwind_dotnet+0xa4a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ff, 0xa4a, x86_l_a4a);
x86_l_305:
	/* 0x305: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_30c:
	/* 0x30c: jb     bac <perf_unwind_dotnet+0xbac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x30c, 0xbac, x86_l_bac);
x86_l_312:
	/* 0x312: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_319:
	/* 0x319: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_320:
	/* 0x320: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_323:
	/* 0x323: sub    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_326:
	/* 0x326: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_32d:
	/* 0x32d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_330:
	/* 0x330: jne    ae3 <perf_unwind_dotnet+0xae3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x330, 0xae3, x86_l_ae3);
x86_l_336:
	/* 0x336: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_339:
	/* 0x339: shr    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_33d:
	/* 0x33d: mov    ecx,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 127ULL);
x86_l_342:
	/* 0x342: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_344:
	/* 0x344: and    ecx,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_347:
	/* 0x347: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_349:
	/* 0x349: cmp    r13,0x8000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 32768ULL);
x86_l_350:
	/* 0x350: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_358:
	/* 0x358: cmovb  rdx,rsi */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B);
x86_l_35c:
	/* 0x35c: cmovae ecx,esi */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE);
x86_l_35f:
	/* 0x35f: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_362:
	/* 0x362: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_36a:
	/* 0x36a: lea    rdi,[rax+rcx*4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_36e:
	/* 0x36e: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
x86_l_373:
	/* 0x373: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_378:
	/* 0x378: mov    esi,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 512ULL);
x86_l_37d:
	/* 0x37d: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_37f:
	/* 0x37f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_382:
	/* 0x382: je     463 <perf_unwind_dotnet+0x463> */
	X86_SIM_X86_JCC(X86_CC_E, 0x382, 0x463, x86_l_463);
x86_l_388:
	/* 0x388: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_38f:
	/* 0x38f: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_393:
	/* 0x393: jne    6c6 <perf_unwind_dotnet+0x6c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x393, 0x6c6, x86_l_6c6);
x86_l_399:
	/* 0x399: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_3a1:
	/* 0x3a1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_3a8:
	/* 0x3a8: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3ad:
	/* 0x3ad: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3b2:
	/* 0x3b2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3b4:
	/* 0x3b4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3b7:
	/* 0x3b7: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3bc:
	/* 0x3bc: mov    r12,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBX, X86_WIDTH_64);
x86_l_3bf:
	/* 0x3bf: je     4ba <perf_unwind_dotnet+0x4ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3bf, 0x4ba, x86_l_4ba);
x86_l_3c5:
	/* 0x3c5: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3c8:
	/* 0x3c8: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_3cd:
	/* 0x3cd: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3cf:
	/* 0x3cf: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d3:
	/* 0x3d3: je     4d5 <perf_unwind_dotnet+0x4d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d3, 0x4d5, x86_l_4d5);
x86_l_3d9:
	/* 0x3d9: jmp    1aab <perf_unwind_dotnet+0x1aab> */
	X86_SIM_X86_JMP(0x3d9, 0x1aab, x86_l_1aab);
x86_l_3de:
	/* 0x3de: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e2:
	/* 0x3e2: je     770d <perf_unwind_dotnet+0x770d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e2, 0x770d, x86_l_770d);
x86_l_3e8:
	/* 0x3e8: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_3f2:
	/* 0x3f2: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3f7:
	/* 0x3f7: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_401:
	/* 0x401: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_406:
	/* 0x406: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_410:
	/* 0x410: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_415:
	/* 0x415: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_41f:
	/* 0x41f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_424:
	/* 0x424: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_42e:
	/* 0x42e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_433:
	/* 0x433: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_43d:
	/* 0x43d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_442:
	/* 0x442: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_447:
	/* 0x447: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_44c:
	/* 0x44c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_451:
	/* 0x451: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_455:
	/* 0x455: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_45a:
	/* 0x45a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_45c:
	/* 0x45c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_45e:
	/* 0x45e: jmp    770d <perf_unwind_dotnet+0x770d> */
	X86_SIM_X86_JMP(0x45e, 0x770d, x86_l_770d);
x86_l_463:
	/* 0x463: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_46a:
	/* 0x46a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_471:
	/* 0x471: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_474:
	/* 0x474: jne    10f5 <perf_unwind_dotnet+0x10f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x474, 0x10f5, x86_l_10f5);
x86_l_47a:
	/* 0x47a: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_47d:
	/* 0x47d: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_47f:
	/* 0x47f: shr    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_482:
	/* 0x482: and    al,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_484:
	/* 0x484: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_489:
	/* 0x489: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_48c:
	/* 0x48c: je     5f7 <perf_unwind_dotnet+0x5f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48c, 0x5f7, x86_l_5f7);
x86_l_492:
	/* 0x492: and    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_496:
	/* 0x496: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_499:
	/* 0x499: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_49c:
	/* 0x49c: jne    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49c, 0xb35, x86_l_b35);
x86_l_4a2:
	/* 0x4a2: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4a5:
	/* 0x4a5: shr    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_4a8:
	/* 0x4a8: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4ab:
	/* 0x4ab: je     709 <perf_unwind_dotnet+0x709> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ab, 0x709, x86_l_709);
x86_l_4b1:
	/* 0x4b1: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_4b5:
	/* 0x4b5: jmp    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JMP(0x4b5, 0xb35, x86_l_b35);
x86_l_4ba:
	/* 0x4ba: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4be:
	/* 0x4be: jne    1206 <perf_unwind_dotnet+0x1206> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4be, 0x1206, x86_l_1206);
x86_l_4c4:
	/* 0x4c4: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_4c9:
	/* 0x4c9: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4cb:
	/* 0x4cb: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4cf:
	/* 0x4cf: jne    1aab <perf_unwind_dotnet+0x1aab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4cf, 0x1aab, x86_l_1aab);
x86_l_4d5:
	/* 0x4d5: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_4da:
	/* 0x4da: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_4dc:
	/* 0x4dc: je     7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dc, 0x7712, x86_l_7712);
x86_l_4e2:
	/* 0x4e2: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4e9:
	/* 0x4e9: cmp    rax,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 127ULL);
x86_l_4ed:
	/* 0x4ed: jb     599 <perf_unwind_dotnet+0x599> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4ed, 0x599, x86_l_599);
x86_l_4f3:
	/* 0x4f3: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f7:
	/* 0x4f7: jne    1292 <perf_unwind_dotnet+0x1292> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f7, 0x1292, x86_l_1292);
x86_l_4fd:
	/* 0x4fd: mov    DWORD PTR [rsp+0xc],0x2 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607554ULL);
x86_l_505:
	/* 0x505: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_50c:
	/* 0x50c: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_511:
	/* 0x511: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_516:
	/* 0x516: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_518:
	/* 0x518: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_51b:
	/* 0x51b: jne    bff <perf_unwind_dotnet+0xbff> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51b, 0xbff, x86_l_bff);
x86_l_521:
	/* 0x521: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_525:
	/* 0x525: je     c0e <perf_unwind_dotnet+0xc0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x525, 0xc0e, x86_l_c0e);
x86_l_52b:
	/* 0x52b: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_535:
	/* 0x535: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_53a:
	/* 0x53a: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_544:
	/* 0x544: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_549:
	/* 0x549: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_553:
	/* 0x553: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_558:
	/* 0x558: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_562:
	/* 0x562: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_567:
	/* 0x567: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_571:
	/* 0x571: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_576:
	/* 0x576: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_580:
	/* 0x580: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_585:
	/* 0x585: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58a:
	/* 0x58a: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_58f:
	/* 0x58f: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_594:
	/* 0x594: jmp    1059 <perf_unwind_dotnet+0x1059> */
	X86_SIM_X86_JMP(0x594, 0x1059, x86_l_1059);
x86_l_599:
	/* 0x599: lea    ecx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_59c:
	/* 0x59c: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5a3:
	/* 0x5a3: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_5a7:
	/* 0x5a7: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_5b3:
	/* 0x5b3: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_5bf:
	/* 0x5bf: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_5c8:
	/* 0x5c8: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_5d4:
	/* 0x5d4: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_5e0:
	/* 0x5e0: mov    rbx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R12, X86_WIDTH_64);
x86_l_5e3:
	/* 0x5e3: mov    r13,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e6:
	/* 0x5e6: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e9:
	/* 0x5e9: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_5ec:
	/* 0x5ec: jne    d47 <perf_unwind_dotnet+0xd47> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5ec, 0xd47, x86_l_d47);
x86_l_5f2:
	/* 0x5f2: jmp    2531 <perf_unwind_dotnet+0x2531> */
	X86_SIM_X86_JMP(0x5f2, 0x2531, x86_l_2531);
x86_l_5f7:
	/* 0x5f7: and    r13,0xffffffffffffff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_5fe:
	/* 0x5fe: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_602:
	/* 0x602: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_609:
	/* 0x609: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_610:
	/* 0x610: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_613:
	/* 0x613: jne    1462 <perf_unwind_dotnet+0x1462> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x613, 0x1462, x86_l_1462);
x86_l_619:
	/* 0x619: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_61b:
	/* 0x61b: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_61e:
	/* 0x61e: je     14f6 <perf_unwind_dotnet+0x14f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61e, 0x14f6, x86_l_14f6);
x86_l_624:
	/* 0x624: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_626:
	/* 0x626: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_629:
	/* 0x629: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_62c:
	/* 0x62c: jae    1a20 <perf_unwind_dotnet+0x1a20> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x62c, 0x1a20, x86_l_1a20);
x86_l_632:
	/* 0x632: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_639:
	/* 0x639: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_63d:
	/* 0x63d: je     399 <perf_unwind_dotnet+0x399> */
	X86_SIM_X86_JCC(X86_CC_E, 0x63d, 0x399, x86_l_399);
x86_l_643:
	/* 0x643: movabs rax,0xa657361625f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2926295996587875ULL);
x86_l_64d:
	/* 0x64d: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_652:
	/* 0x652: movabs rax,0x5f637020776f6c65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460741042564197ULL);
x86_l_65c:
	/* 0x65c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_661:
	/* 0x661: movabs rax,0x6220746e65772068 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7070779432469209192ULL);
x86_l_66b:
	/* 0x66b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_670:
	/* 0x670: movabs rax,0x6372616573207061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165897045450977377ULL);
x86_l_67a:
	/* 0x67a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_67f:
	/* 0x67f: movabs rax,0x6d20656c6262696e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7863396465570376046ULL);
x86_l_689:
	/* 0x689: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_68e:
	/* 0x68e: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_698:
	/* 0x698: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_69d:
	/* 0x69d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6a2:
	/* 0x6a2: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_6a7:
	/* 0x6a7: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_6ac:
	/* 0x6ac: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_6b1:
	/* 0x6b1: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6b3:
	/* 0x6b3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6b5:
	/* 0x6b5: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_6bc:
	/* 0x6bc: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c0:
	/* 0x6c0: je     399 <perf_unwind_dotnet+0x399> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c0, 0x399, x86_l_399);
x86_l_6c6:
	/* 0x6c6: movabs rax,0x6e756f6620746f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959390400869068654ULL);
x86_l_6d0:
	/* 0x6d0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6d5:
	/* 0x6d5: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_6df:
	/* 0x6df: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6e4:
	/* 0x6e4: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_6ec:
	/* 0x6ec: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6f1:
	/* 0x6f1: mov    eax,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_6f6:
	/* 0x6f6: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_6fb:
	/* 0x6fb: mov    esi,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 19ULL);
x86_l_700:
	/* 0x700: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_702:
	/* 0x702: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_704:
	/* 0x704: jmp    399 <perf_unwind_dotnet+0x399> */
	X86_SIM_X86_JMP(0x704, 0x399, x86_l_399);
x86_l_709:
	/* 0x709: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_70c:
	/* 0x70c: shr    ecx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_70f:
	/* 0x70f: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_712:
	/* 0x712: je     776 <perf_unwind_dotnet+0x776> */
	X86_SIM_X86_JCC(X86_CC_E, 0x712, 0x776, x86_l_776);
x86_l_714:
	/* 0x714: add    r13,0xffffffffffffffc0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_718:
	/* 0x718: jmp    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JMP(0x718, 0xb35, x86_l_b35);
x86_l_71d:
	/* 0x71d: movabs rax,0x3d3d206425207465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 4412718824384656485ULL);
x86_l_727:
	/* 0x727: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_72c:
	/* 0x72c: movabs rax,0x6e746f645f646e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959108918358339177ULL);
x86_l_736:
	/* 0x736: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_73b:
	/* 0x73b: movabs rax,0x776e75203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8605944719278423357ULL);
x86_l_745:
	/* 0x745: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_74a:
	/* 0x74a: mov    DWORD PTR [rsp+0x28],0xa3d3d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171799362877ULL);
x86_l_752:
	/* 0x752: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_757:
	/* 0x757: mov    eax,0x1c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 28ULL);
x86_l_75c:
	/* 0x75c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_761:
	/* 0x761: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_768:
	/* 0x768: mov    esi,0x1c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 28ULL);
x86_l_76d:
	/* 0x76d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_76f:
	/* 0x76f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_771:
	/* 0x771: jmp    55 <perf_unwind_dotnet+0x55> */
	X86_SIM_X86_JMP(0x771, 0x55, x86_l_55);
x86_l_776:
	/* 0x776: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_779:
	/* 0x779: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_77c:
	/* 0x77c: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_77f:
	/* 0x77f: je     86f <perf_unwind_dotnet+0x86f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x77f, 0x86f, x86_l_86f);
x86_l_785:
	/* 0x785: add    r13,0xffffffffffffffa0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_789:
	/* 0x789: jmp    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JMP(0x789, 0xb35, x86_l_b35);
x86_l_78e:
	/* 0x78e: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_798:
	/* 0x798: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_79d:
	/* 0x79d: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_7a7:
	/* 0x7a7: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7ac:
	/* 0x7ac: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_7b6:
	/* 0x7b6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7bb:
	/* 0x7bb: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_7c5:
	/* 0x7c5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7ca:
	/* 0x7ca: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_7d2:
	/* 0x7d2: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d7:
	/* 0x7d7: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_7dc:
	/* 0x7dc: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_7e2:
	/* 0x7e2: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_7e7:
	/* 0x7e7: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_7ea:
	/* 0x7ea: mov    ebp,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RCX, X86_WIDTH_32);
x86_l_7ec:
	/* 0x7ec: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_7ef:
	/* 0x7ef: mov    r8,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R13, X86_WIDTH_64);
x86_l_7f2:
	/* 0x7f2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7f4:
	/* 0x7f4: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7f7:
	/* 0x7f7: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_7f9:
	/* 0x7f9: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_7fc:
	/* 0x7fc: jae    10d <perf_unwind_dotnet+0x10d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x7fc, 0x10d, x86_l_10d);
x86_l_802:
	/* 0x802: jmp    76c0 <perf_unwind_dotnet+0x76c0> */
	X86_SIM_X86_JMP(0x802, 0x76c0, x86_l_76c0);
x86_l_807:
	/* 0x807: movabs rax,0xa646970207369 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2925153782625129ULL);
x86_l_811:
	/* 0x811: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_816:
	/* 0x816: movabs rax,0x687420726f66206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7526676553110265967ULL);
x86_l_820:
	/* 0x820: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_825:
	/* 0x825: movabs rax,0x666e49636f725074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7380917530727174260ULL);
x86_l_82f:
	/* 0x82f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_834:
	/* 0x834: movabs rax,0x656e746f44206f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7308907266502061934ULL);
x86_l_83e:
	/* 0x83e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_843:
	/* 0x843: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_84d:
	/* 0x84d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_852:
	/* 0x852: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_857:
	/* 0x857: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_85c:
	/* 0x85c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_861:
	/* 0x861: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_866:
	/* 0x866: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_868:
	/* 0x868: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_86a:
	/* 0x86a: jmp    a7 <perf_unwind_dotnet+0xa7> */
	X86_SIM_X86_JMP(0x86a, 0xa7, x86_l_a7);
x86_l_86f:
	/* 0x86f: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_872:
	/* 0x872: shr    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_875:
	/* 0x875: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_878:
	/* 0x878: je     97d <perf_unwind_dotnet+0x97d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x878, 0x97d, x86_l_97d);
x86_l_87e:
	/* 0x87e: add    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_882:
	/* 0x882: jmp    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JMP(0x882, 0xb35, x86_l_b35);
x86_l_887:
	/* 0x887: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_891:
	/* 0x891: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_896:
	/* 0x896: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_8a0:
	/* 0x8a0: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8a5:
	/* 0x8a5: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_8af:
	/* 0x8af: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8b4:
	/* 0x8b4: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_8be:
	/* 0x8be: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8c3:
	/* 0x8c3: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_8cd:
	/* 0x8cd: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8d2:
	/* 0x8d2: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_8dc:
	/* 0x8dc: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8e1:
	/* 0x8e1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8e6:
	/* 0x8e6: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_8eb:
	/* 0x8eb: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8f0:
	/* 0x8f0: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8f4:
	/* 0x8f4: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_8f9:
	/* 0x8f9: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8fb:
	/* 0x8fb: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8fd:
	/* 0x8fd: jmp    dd <perf_unwind_dotnet+0xdd> */
	X86_SIM_X86_JMP(0x8fd, 0xdd, x86_l_dd);
x86_l_902:
	/* 0x902: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_90c:
	/* 0x90c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_911:
	/* 0x911: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_91b:
	/* 0x91b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_920:
	/* 0x920: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_92a:
	/* 0x92a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_92f:
	/* 0x92f: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_939:
	/* 0x939: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_93e:
	/* 0x93e: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_948:
	/* 0x948: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_94d:
	/* 0x94d: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_957:
	/* 0x957: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_95c:
	/* 0x95c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_961:
	/* 0x961: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_966:
	/* 0x966: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_96b:
	/* 0x96b: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_96f:
	/* 0x96f: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_974:
	/* 0x974: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_976:
	/* 0x976: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_978:
	/* 0x978: jmp    2b8 <perf_unwind_dotnet+0x2b8> */
	X86_SIM_X86_JMP(0x978, 0x2b8, x86_l_2b8);
x86_l_97d:
	/* 0x97d: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_980:
	/* 0x980: shr    ecx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_983:
	/* 0x983: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_986:
	/* 0x986: je     acf <perf_unwind_dotnet+0xacf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x986, 0xacf, x86_l_acf);
x86_l_98c:
	/* 0x98c: add    r13,0xffffffffffffff60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_993:
	/* 0x993: jmp    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JMP(0x993, 0xb35, x86_l_b35);
x86_l_998:
	/* 0x998: movabs rax,0xa7265746e696f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2940529837762927ULL);
x86_l_9a2:
	/* 0x9a2: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9a7:
	/* 0x9a7: movabs rax,0x70206b6361747320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8079575806083625760ULL);
x86_l_9b1:
	/* 0x9b1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9b6:
	/* 0x9b6: movabs rax,0x646162203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7233170367155350816ULL);
x86_l_9c0:
	/* 0x9c0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_9c5:
	/* 0x9c5: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_9cf:
	/* 0x9cf: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9d4:
	/* 0x9d4: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9d9:
	/* 0x9d9: mov    eax,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_9de:
	/* 0x9de: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_9e3:
	/* 0x9e3: mov    esi,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 32ULL);
x86_l_9e8:
	/* 0x9e8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_9ea:
	/* 0x9ea: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_9ec:
	/* 0x9ec: jmp    1ad <perf_unwind_dotnet+0x1ad> */
	X86_SIM_X86_JMP(0x9ec, 0x1ad, x86_l_1ad);
x86_l_9f1:
	/* 0x9f1: movabs rax,0xa7265746e696f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2940529837762927ULL);
x86_l_9fb:
	/* 0x9fb: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a00:
	/* 0xa00: movabs rax,0x7020656d61726620 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8079569251963397664ULL);
x86_l_a0a:
	/* 0xa0a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a0f:
	/* 0xa0f: movabs rax,0x646162203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7233170367155350816ULL);
x86_l_a19:
	/* 0xa19: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a1e:
	/* 0xa1e: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_a28:
	/* 0xa28: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a2d:
	/* 0xa2d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a32:
	/* 0xa32: mov    eax,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_a37:
	/* 0xa37: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_a3c:
	/* 0xa3c: mov    esi,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 32ULL);
x86_l_a41:
	/* 0xa41: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a43:
	/* 0xa43: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a45:
	/* 0xa45: jmp    27d <perf_unwind_dotnet+0x27d> */
	X86_SIM_X86_JMP(0xa45, 0x27d, x86_l_27d);
x86_l_a4a:
	/* 0xa4a: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_a54:
	/* 0xa54: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a59:
	/* 0xa59: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_a63:
	/* 0xa63: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a68:
	/* 0xa68: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_a72:
	/* 0xa72: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a77:
	/* 0xa77: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_a81:
	/* 0xa81: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a86:
	/* 0xa86: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_a8e:
	/* 0xa8e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a93:
	/* 0xa93: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_a98:
	/* 0xa98: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_a9e:
	/* 0xa9e: mov    rdx,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_aa5:
	/* 0xaa5: mov    rcx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_aac:
	/* 0xaac: mov    r8,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_ab3:
	/* 0xab3: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_ab8:
	/* 0xab8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_aba:
	/* 0xaba: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_abd:
	/* 0xabd: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_ac4:
	/* 0xac4: jae    312 <perf_unwind_dotnet+0x312> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xac4, 0x312, x86_l_312);
x86_l_aca:
	/* 0xaca: jmp    bac <perf_unwind_dotnet+0xbac> */
	X86_SIM_X86_JMP(0xaca, 0xbac, x86_l_bac);
x86_l_acf:
	/* 0xacf: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_ad2:
	/* 0xad2: shr    ecx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_ad5:
	/* 0xad5: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_ad8:
	/* 0xad8: je     b27 <perf_unwind_dotnet+0xb27> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad8, 0xb27, x86_l_b27);
x86_l_ada:
	/* 0xada: add    r13,0xffffffffffffff40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_ae1:
	/* 0xae1: jmp    b35 <perf_unwind_dotnet+0xb35> */
	X86_SIM_X86_JMP(0xae1, 0xb35, x86_l_b35);
x86_l_ae3:
	/* 0xae3: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_aea:
	/* 0xaea: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_aef:
	/* 0xaef: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_af4:
	/* 0xaf4: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_af7:
	/* 0xaf7: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_afa:
	/* 0xafa: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_b01:
	/* 0xb01: mov    ecx,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 66ULL);
x86_l_b06:
	/* 0xb06: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_b0c:
	/* 0xb0c: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_b0f:
	/* 0xb0f: mov    esi,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 66ULL);
x86_l_b14:
	/* 0xb14: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_b17:
	/* 0xb17: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_b1a:
	/* 0xb1a: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_b1d:
	/* 0xb1d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b1f:
	/* 0xb1f: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b22:
	/* 0xb22: jmp    336 <perf_unwind_dotnet+0x336> */
	X86_SIM_X86_JMP(0xb22, 0x336, x86_l_336);
x86_l_b27:
	/* 0xb27: shr    r15d,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_b2b:
	/* 0xb2b: add    r13,0xffffffffffffff20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_b32:
	/* 0xb32: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_b35:
	/* 0xb35: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_b38:
	/* 0xb38: lea    r15d,[rcx*4-0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 18446744073709551612ULL);
x86_l_b40:
	/* 0xb40: add    r15,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_b43:
	/* 0xb43: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_b4a:
	/* 0xb4a: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b4e:
	/* 0xb4e: jne    1187 <perf_unwind_dotnet+0x1187> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb4e, 0x1187, x86_l_1187);
x86_l_b54:
	/* 0xb54: lea    rdx,[r15-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_b58:
	/* 0xb58: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_b5d:
	/* 0xb5d: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_b62:
	/* 0xb62: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_b67:
	/* 0xb67: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_b6c:
	/* 0xb6c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b6e:
	/* 0xb6e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b71:
	/* 0xb71: je     ba7 <perf_unwind_dotnet+0xba7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb71, 0xba7, x86_l_ba7);
x86_l_b73:
	/* 0xb73: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b77:
	/* 0xb77: jne    12fa <perf_unwind_dotnet+0x12fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb77, 0x12fa, x86_l_12fa);
x86_l_b7d:
	/* 0xb7d: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_b85:
	/* 0xb85: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_b8c:
	/* 0xb8c: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_b91:
	/* 0xb91: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b96:
	/* 0xb96: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b98:
	/* 0xb98: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b9b:
	/* 0xb9b: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_ba0:
	/* 0xba0: je     c18 <perf_unwind_dotnet+0xc18> */
	X86_SIM_X86_JCC(X86_CC_E, 0xba0, 0xc18, x86_l_c18);
x86_l_ba2:
	/* 0xba2: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_ba5:
	/* 0xba5: jmp    c22 <perf_unwind_dotnet+0xc22> */
	X86_SIM_X86_JMP(0xba5, 0xc22, x86_l_c22);
x86_l_ba7:
	/* 0xba7: mov    ebp,0x1f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 31ULL);
x86_l_bac:
	/* 0xbac: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_bb3:
	/* 0xbb3: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bb6:
	/* 0xbb6: jne    c2c <perf_unwind_dotnet+0xc2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbb6, 0xc2c, x86_l_c2c);
x86_l_bb8:
	/* 0xbb8: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_bbf:
	/* 0xbbf: cmp    rax,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 127ULL);
x86_l_bc3:
	/* 0xbc3: jb     c86 <perf_unwind_dotnet+0xc86> */
	X86_SIM_X86_JCC(X86_CC_B, 0xbc3, 0xc86, x86_l_c86);
x86_l_bc9:
	/* 0xbc9: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_bd0:
	/* 0xbd0: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd4:
	/* 0xbd4: jne    d7b <perf_unwind_dotnet+0xd7b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbd4, 0xd7b, x86_l_d7b);
x86_l_bda:
	/* 0xbda: mov    DWORD PTR [rsp+0xc],0x2 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607554ULL);
x86_l_be2:
	/* 0xbe2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_be9:
	/* 0xbe9: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_bee:
	/* 0xbee: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_bf3:
	/* 0xbf3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_bf5:
	/* 0xbf5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_bf8:
	/* 0xbf8: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_bfd:
	/* 0xbfd: je     c04 <perf_unwind_dotnet+0xc04> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbfd, 0xc04, x86_l_c04);
x86_l_bff:
	/* 0xbff: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_c02:
	/* 0xc02: jmp    c0e <perf_unwind_dotnet+0xc0e> */
	X86_SIM_X86_JMP(0xc02, 0xc0e, x86_l_c0e);
x86_l_c04:
	/* 0xc04: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c08:
	/* 0xc08: jne    ff0 <perf_unwind_dotnet+0xff0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc08, 0xff0, x86_l_ff0);
x86_l_c0e:
	/* 0xc0e: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_c13:
	/* 0xc13: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0xc13, 0x7712, x86_l_7712);
x86_l_c18:
	/* 0xc18: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c1c:
	/* 0xc1c: jne    1bbf <perf_unwind_dotnet+0x1bbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc1c, 0x1bbf, x86_l_1bbf);
x86_l_c22:
	/* 0xc22: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_c27:
	/* 0xc27: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0xc27, 0x7712, x86_l_7712);
x86_l_c2c:
	/* 0xc2c: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_c33:
	/* 0xc33: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c38:
	/* 0xc38: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_c3d:
	/* 0xc3d: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_c40:
	/* 0xc40: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_c43:
	/* 0xc43: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_c48:
	/* 0xc48: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_c4f:
	/* 0xc4f: mov    ecx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 67ULL);
x86_l_c54:
	/* 0xc54: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_c5a:
	/* 0xc5a: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_c5f:
	/* 0xc5f: mov    r8,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_64);
x86_l_c62:
	/* 0xc62: sub    r8,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_c65:
	/* 0xc65: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_c68:
	/* 0xc68: mov    esi,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 67ULL);
x86_l_c6d:
	/* 0xc6d: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_c70:
	/* 0xc70: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c72:
	/* 0xc72: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c75:
	/* 0xc75: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_c7c:
	/* 0xc7c: cmp    rax,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 127ULL);
x86_l_c80:
	/* 0xc80: jae    bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xc80, 0xbc9, x86_l_bc9);
x86_l_c86:
	/* 0xc86: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_c8b:
	/* 0xc8b: sub    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_c8e:
	/* 0xc8e: shl    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_c92:
	/* 0xc92: add    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_c95:
	/* 0xc95: lea    edx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_c98:
	/* 0xc98: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_c9f:
	/* 0xc9f: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_ca3:
	/* 0xca3: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_cab:
	/* 0xcab: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_cb3:
	/* 0xcb3: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_cbc:
	/* 0xcbc: movzx  ecx,BYTE PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 136ULL);
x86_l_cc4:
	/* 0xcc4: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_ccc:
	/* 0xccc: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_cd8:
	/* 0xcd8: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_ce3:
	/* 0xce3: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_ceb:
	/* 0xceb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_cf2:
	/* 0xcf2: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_cf7:
	/* 0xcf7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_cfc:
	/* 0xcfc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_cfe:
	/* 0xcfe: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_d01:
	/* 0xd01: je     d22 <perf_unwind_dotnet+0xd22> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd01, 0xd22, x86_l_d22);
x86_l_d03:
	/* 0xd03: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_d06:
	/* 0xd06: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d0b:
	/* 0xd0b: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_d12:
	/* 0xd12: mov    r13,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d15:
	/* 0xd15: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d18:
	/* 0xd18: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_d1b:
	/* 0xd1b: jne    d47 <perf_unwind_dotnet+0xd47> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd1b, 0xd47, x86_l_d47);
x86_l_d1d:
	/* 0xd1d: jmp    2531 <perf_unwind_dotnet+0x2531> */
	X86_SIM_X86_JMP(0xd1d, 0x2531, x86_l_2531);
x86_l_d22:
	/* 0xd22: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_d29:
	/* 0xd29: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d2d:
	/* 0xd2d: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d32:
	/* 0xd32: jne    106b <perf_unwind_dotnet+0x106b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd32, 0x106b, x86_l_106b);
x86_l_d38:
	/* 0xd38: mov    r13,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3b:
	/* 0xd3b: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3e:
	/* 0xd3e: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_d41:
	/* 0xd41: je     2531 <perf_unwind_dotnet+0x2531> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd41, 0x2531, x86_l_2531);
x86_l_d47:
	/* 0xd47: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_d49:
	/* 0xd49: jne    de3 <perf_unwind_dotnet+0xde3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd49, 0xde3, x86_l_de3);
x86_l_d4f:
	/* 0xd4f: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_d52:
	/* 0xd52: shr    rax,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_d56:
	/* 0xd56: je     e75 <perf_unwind_dotnet+0xe75> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd56, 0xe75, x86_l_e75);
x86_l_d5c:
	/* 0xd5c: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d60:
	/* 0xd60: jne    24c9 <perf_unwind_dotnet+0x24c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd60, 0x24c9, x86_l_24c9);
x86_l_d66:
	/* 0xd66: mov    DWORD PTR [r14+0xf28],0xb */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108491ULL);
x86_l_d71:
	/* 0xd71: mov    eax,0xfab */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4011ULL);
x86_l_d76:
	/* 0xd76: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0xd76, 0x7712, x86_l_7712);
x86_l_d7b:
	/* 0xd7b: movabs rax,0xa6c6c75662073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2933962849001587ULL);
x86_l_d85:
	/* 0xd85: mov    QWORD PTR [rsp+0x2d],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 45ULL);
x86_l_d8a:
	/* 0xd8a: movabs rax,0x66207369206b6361 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7359008686476059489ULL);
x86_l_d94:
	/* 0xd94: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d99:
	/* 0xd99: movabs rax,0x7473203a656d6172 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8391085965903225202ULL);
x86_l_da3:
	/* 0xda3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_da8:
	/* 0xda8: movabs rax,0x662068737570206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7358996636224200815ULL);
x86_l_db2:
	/* 0xdb2: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_db7:
	/* 0xdb7: movabs rax,0x7420656c62616e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367799623835807349ULL);
x86_l_dc1:
	/* 0xdc1: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dc6:
	/* 0xdc6: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dcb:
	/* 0xdcb: mov    eax,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_dd0:
	/* 0xdd0: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_dd5:
	/* 0xdd5: mov    esi,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 37ULL);
x86_l_dda:
	/* 0xdda: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_ddc:
	/* 0xddc: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_dde:
	/* 0xdde: jmp    bda <perf_unwind_dotnet+0xbda> */
	X86_SIM_X86_JMP(0xdde, 0xbda, x86_l_bda);
x86_l_de3:
	/* 0xde3: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 737813247186461733ULL);
x86_l_ded:
	/* 0xded: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_df2:
	/* 0xdf2: movabs rax,0x20656d617266203a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021050ULL);
x86_l_dfc:
	/* 0xdfc: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e01:
	/* 0xe01: movabs rax,0x7265646e69776e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243105118350175861ULL);
x86_l_e0b:
	/* 0xe0b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e10:
	/* 0xe10: movabs rax,0x20656d6172662074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021108ULL);
x86_l_e1a:
	/* 0xe1a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e1f:
	/* 0xe1f: movabs rax,0x78656e2065766c6f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8675461342619397231ULL);
x86_l_e29:
	/* 0xe29: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e2e:
	/* 0xe2e: movabs rax,0x736552203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315142585429343549ULL);
x86_l_e38:
	/* 0xe38: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e3d:
	/* 0xe3d: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_e42:
	/* 0xe42: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e47:
	/* 0xe47: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_e4c:
	/* 0xe4c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_e51:
	/* 0xe51: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_e58:
	/* 0xe58: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_e5d:
	/* 0xe5d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e5f:
	/* 0xe5f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e61:
	/* 0xe61: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_e68:
	/* 0xe68: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_e6b:
	/* 0xe6b: shr    rax,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_e6f:
	/* 0xe6f: jne    d5c <perf_unwind_dotnet+0xd5c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe6f, 0xd5c, x86_l_d5c);
x86_l_e75:
	/* 0xe75: cmp    r13,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4095ULL);
x86_l_e7c:
	/* 0xe7c: ja     e9d <perf_unwind_dotnet+0xe9d> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe7c, 0xe9d, x86_l_e9d);
x86_l_e7e:
	/* 0xe7e: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e82:
	/* 0xe82: jne    2664 <perf_unwind_dotnet+0x2664> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe82, 0x2664, x86_l_2664);
x86_l_e88:
	/* 0xe88: mov    DWORD PTR [r14+0xf28],0x31 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108529ULL);
x86_l_e93:
	/* 0xe93: mov    eax,0xfae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4014ULL);
x86_l_e98:
	/* 0xe98: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0xe98, 0x7712, x86_l_7712);
x86_l_e9d:
	/* 0xe9d: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ea0:
	/* 0xea0: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_ea8:
	/* 0xea8: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_eae:
	/* 0xeae: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_eb5:
	/* 0xeb5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&pid_page_to_mapping_info));
x86_l_ebc:
	/* 0xebc: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_ec1:
	/* 0xec1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_ec6:
	/* 0xec6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ec8:
	/* 0xec8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ecb:
	/* 0xecb: je     874c <perf_unwind_dotnet+0x874c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xecb, 0x874c, x86_l_874c);
x86_l_ed1:
	/* 0xed1: mov    QWORD PTR [rsp+0x88],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_ed9:
	/* 0xed9: movabs rdx,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_ee3:
	/* 0xee3: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee7:
	/* 0xee7: mov    rcx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_64);
x86_l_eea:
	/* 0xeea: and    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND);
x86_l_eed:
	/* 0xeed: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_ef4:
	/* 0xef4: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ef7:
	/* 0xef7: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_efe:
	/* 0xefe: shr    r12,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_f02:
	/* 0xf02: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_f05:
	/* 0xf05: sub    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_f08:
	/* 0xf08: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_f0f:
	/* 0xf0f: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f13:
	/* 0xf13: jne    1353 <perf_unwind_dotnet+0x1353> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf13, 0x1353, x86_l_1353);
x86_l_f19:
	/* 0xf19: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_f1d:
	/* 0xf1d: jne    1cea <perf_unwind_dotnet+0x1cea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf1d, 0x1cea, x86_l_1cea);
x86_l_f23:
	/* 0xf23: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_f2a:
	/* 0xf2a: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_f2f:
	/* 0xf2f: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_f36:
	/* 0xf36: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&interpreter_offsets));
x86_l_f3d:
	/* 0xf3d: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_f42:
	/* 0xf42: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_f47:
	/* 0xf47: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f49:
	/* 0xf49: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_f4f:
	/* 0xf4f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_f52:
	/* 0xf52: je     1cea <perf_unwind_dotnet+0x1cea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf52, 0x1cea, x86_l_1cea);
x86_l_f58:
	/* 0xf58: cmp    QWORD PTR [rax],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f5b:
	/* 0xf5b: ja     f63 <perf_unwind_dotnet+0xf63> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf5b, 0xf63, x86_l_f63);
x86_l_f5d:
	/* 0xf5d: cmp    QWORD PTR [rax+0x8],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f61:
	/* 0xf61: jae    f77 <perf_unwind_dotnet+0xf77> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf61, 0xf77, x86_l_f77);
x86_l_f63:
	/* 0xf63: cmp    QWORD PTR [rax+0x10],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f67:
	/* 0xf67: ja     1cea <perf_unwind_dotnet+0x1cea> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf67, 0x1cea, x86_l_1cea);
x86_l_f6d:
	/* 0xf6d: cmp    QWORD PTR [rax+0x18],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f71:
	/* 0xf71: jb     1cea <perf_unwind_dotnet+0x1cea> */
	X86_SIM_X86_JCC(X86_CC_B, 0xf71, 0x1cea, x86_l_1cea);
x86_l_f77:
	/* 0xf77: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f7b:
	/* 0xf7b: jne    1c3a <perf_unwind_dotnet+0x1c3a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf7b, 0x1c3a, x86_l_1c3a);
x86_l_f81:
	/* 0xf81: mov    ecx,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_f88:
	/* 0xf88: mov    edx,DWORD PTR [rax+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f8b:
	/* 0xf8b: bt     ecx,edx */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_f8e:
	/* 0xf8e: jae    1cad <perf_unwind_dotnet+0x1cad> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf8e, 0x1cad, x86_l_1cad);
x86_l_f94:
	/* 0xf94: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f98:
	/* 0xf98: je     1cea <perf_unwind_dotnet+0x1cea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf98, 0x1cea, x86_l_1cea);
x86_l_f9e:
	/* 0xf9e: movabs rax,0x6e6f64207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7957689157107934318ULL);
x86_l_fa8:
	/* 0xfa8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_fad:
	/* 0xfad: movabs rax,0x69776e7520726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345545598324ULL);
x86_l_fb7:
	/* 0xfb7: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_fbc:
	/* 0xfbc: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_fc6:
	/* 0xfc6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fcb:
	/* 0xfcb: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_fd3:
	/* 0xfd3: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fd8:
	/* 0xfd8: mov    eax,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_fdd:
	/* 0xfdd: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_fe2:
	/* 0xfe2: mov    esi,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 27ULL);
x86_l_fe7:
	/* 0xfe7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_fe9:
	/* 0xfe9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_feb:
	/* 0xfeb: jmp    1cea <perf_unwind_dotnet+0x1cea> */
	X86_SIM_X86_JMP(0xfeb, 0x1cea, x86_l_1cea);
x86_l_ff0:
	/* 0xff0: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_ffa:
	/* 0xffa: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_fff:
	/* 0xfff: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_1009:
	/* 0x1009: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_100e:
	/* 0x100e: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_1018:
	/* 0x1018: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_101d:
	/* 0x101d: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_1027:
	/* 0x1027: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_102c:
	/* 0x102c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_1036:
	/* 0x1036: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_103b:
	/* 0x103b: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_1045:
	/* 0x1045: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_104a:
	/* 0x104a: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_104f:
	/* 0x104f: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_1054:
	/* 0x1054: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_1059:
	/* 0x1059: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_105d:
	/* 0x105d: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_1062:
	/* 0x1062: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1064:
	/* 0x1064: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1066:
	/* 0x1066: jmp    c0e <perf_unwind_dotnet+0xc0e> */
	X86_SIM_X86_JMP(0x1066, 0xc0e, x86_l_c0e);
x86_l_106b:
	/* 0x106b: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_1075:
	/* 0x1075: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_107a:
	/* 0x107a: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_1084:
	/* 0x1084: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1089:
	/* 0x1089: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_1093:
	/* 0x1093: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1098:
	/* 0x1098: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_10a2:
	/* 0x10a2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_10a7:
	/* 0x10a7: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_10b1:
	/* 0x10b1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_10b6:
	/* 0x10b6: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_10c0:
	/* 0x10c0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10c5:
	/* 0x10c5: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10ca:
	/* 0x10ca: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_10cf:
	/* 0x10cf: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_10d4:
	/* 0x10d4: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_10d8:
	/* 0x10d8: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_10dd:
	/* 0x10dd: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10df:
	/* 0x10df: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10e1:
	/* 0x10e1: mov    r13,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e4:
	/* 0x10e4: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e7:
	/* 0x10e7: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_10ea:
	/* 0x10ea: jne    d47 <perf_unwind_dotnet+0xd47> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10ea, 0xd47, x86_l_d47);
x86_l_10f0:
	/* 0x10f0: jmp    2531 <perf_unwind_dotnet+0x2531> */
	X86_SIM_X86_JMP(0x10f0, 0x2531, x86_l_2531);
x86_l_10f5:
	/* 0x10f5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_10f8:
	/* 0x10f8: and    rdx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_10fc:
	/* 0x10fc: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_1106:
	/* 0x1106: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_110b:
	/* 0x110b: movabs rax,0x72746e6520747372 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8247338198237475698ULL);
x86_l_1115:
	/* 0x1115: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_111a:
	/* 0x111a: movabs rax,0x6966203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7594793257107465504ULL);
x86_l_1124:
	/* 0x1124: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1129:
	/* 0x1129: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_1133:
	/* 0x1133: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1138:
	/* 0x1138: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_1142:
	/* 0x1142: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1147:
	/* 0x1147: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_1151:
	/* 0x1151: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1156:
	/* 0x1156: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_1160:
	/* 0x1160: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1165:
	/* 0x1165: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_116a:
	/* 0x116a: mov    eax,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 54ULL);
x86_l_116f:
	/* 0x116f: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_1175:
	/* 0x1175: mov    esi,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 54ULL);
x86_l_117a:
	/* 0x117a: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_117d:
	/* 0x117d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_117f:
	/* 0x117f: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1182:
	/* 0x1182: jmp    47a <perf_unwind_dotnet+0x47a> */
	X86_SIM_X86_JMP(0x1182, 0x47a, x86_l_47a);
x86_l_1187:
	/* 0x1187: movabs rax,0xa786c253d7465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155643692133ULL);
x86_l_1191:
	/* 0x1191: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1196:
	/* 0x1196: movabs rax,0x746572202c78253d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8387235363558008125ULL);
x86_l_11a0:
	/* 0x11a0: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_11a5:
	/* 0x11a5: movabs rax,0x6c6176202c786c25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809653109394271269ULL);
x86_l_11af:
	/* 0x11af: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11b4:
	/* 0x11b4: movabs rax,0x203d2061746c6564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2323048585730221412ULL);
x86_l_11be:
	/* 0x11be: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11c3:
	/* 0x11c3: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460740081921312ULL);
x86_l_11cd:
	/* 0x11cd: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11d2:
	/* 0x11d2: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_11dc:
	/* 0x11dc: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11e1:
	/* 0x11e1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11e6:
	/* 0x11e6: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_11eb:
	/* 0x11eb: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_11f1:
	/* 0x11f1: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_11f6:
	/* 0x11f6: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_11f9:
	/* 0x11f9: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_11fc:
	/* 0x11fc: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11fe:
	/* 0x11fe: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1201:
	/* 0x1201: jmp    b54 <perf_unwind_dotnet+0xb54> */
	X86_SIM_X86_JMP(0x1201, 0xb54, x86_l_b54);
x86_l_1206:
	/* 0x1206: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_1210:
	/* 0x1210: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1215:
	/* 0x1215: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_121f:
	/* 0x121f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1224:
	/* 0x1224: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_122e:
	/* 0x122e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1233:
	/* 0x1233: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_123d:
	/* 0x123d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1242:
	/* 0x1242: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_124c:
	/* 0x124c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1251:
	/* 0x1251: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_125b:
	/* 0x125b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1260:
	/* 0x1260: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1265:
	/* 0x1265: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_126a:
	/* 0x126a: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_126f:
	/* 0x126f: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1273:
	/* 0x1273: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_1278:
	/* 0x1278: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_127a:
	/* 0x127a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_127c:
	/* 0x127c: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_1281:
	/* 0x1281: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1283:
	/* 0x1283: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1287:
	/* 0x1287: je     4d5 <perf_unwind_dotnet+0x4d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1287, 0x4d5, x86_l_4d5);
x86_l_128d:
	/* 0x128d: jmp    1aab <perf_unwind_dotnet+0x1aab> */
	X86_SIM_X86_JMP(0x128d, 0x1aab, x86_l_1aab);
x86_l_1292:
	/* 0x1292: movabs rax,0xa6c6c75662073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2933962849001587ULL);
x86_l_129c:
	/* 0x129c: mov    QWORD PTR [rsp+0x2d],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 45ULL);
x86_l_12a1:
	/* 0x12a1: movabs rax,0x66207369206b6361 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7359008686476059489ULL);
x86_l_12ab:
	/* 0x12ab: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12b0:
	/* 0x12b0: movabs rax,0x7473203a656d6172 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8391085965903225202ULL);
x86_l_12ba:
	/* 0x12ba: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12bf:
	/* 0x12bf: movabs rax,0x662068737570206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7358996636224200815ULL);
x86_l_12c9:
	/* 0x12c9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12ce:
	/* 0x12ce: movabs rax,0x7420656c62616e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367799623835807349ULL);
x86_l_12d8:
	/* 0x12d8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12dd:
	/* 0x12dd: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12e2:
	/* 0x12e2: mov    eax,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_12e7:
	/* 0x12e7: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_12ec:
	/* 0x12ec: mov    esi,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 37ULL);
x86_l_12f1:
	/* 0x12f1: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_12f3:
	/* 0x12f3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_12f5:
	/* 0x12f5: jmp    4fd <perf_unwind_dotnet+0x4fd> */
	X86_SIM_X86_JMP(0x12f5, 0x4fd, x86_l_4fd);
x86_l_12fa:
	/* 0x12fa: movabs rax,0xa726564616568 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2940529568474472ULL);
x86_l_1304:
	/* 0x1304: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_1309:
	/* 0x1309: movabs rax,0x65682065646f6320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7307126015257436960ULL);
x86_l_1313:
	/* 0x1313: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1318:
	/* 0x1318: movabs rax,0x646162203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7233170367155350816ULL);
x86_l_1322:
	/* 0x1322: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1327:
	/* 0x1327: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_1331:
	/* 0x1331: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1336:
	/* 0x1336: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_133b:
	/* 0x133b: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_1340:
	/* 0x1340: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_1345:
	/* 0x1345: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_134a:
	/* 0x134a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_134c:
	/* 0x134c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_134e:
	/* 0x134e: jmp    b7d <perf_unwind_dotnet+0xb7d> */
	X86_SIM_X86_JMP(0x134e, 0xb7d, x86_l_b7d);
x86_l_1353:
	/* 0x1353: movabs rax,0x296425207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2982549674514539630ULL);
x86_l_135d:
	/* 0x135d: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1362:
	/* 0x1362: movabs rax,0x69776e752820786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345674446956ULL);
x86_l_136c:
	/* 0x136c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1371:
	/* 0x1371: movabs rax,0x6c2520736920786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670410291574892ULL);
x86_l_137b:
	/* 0x137b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1380:
	/* 0x1380: movabs rax,0x2520435020726f66 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675212190078889830ULL);
x86_l_138a:
	/* 0x138a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_138f:
	/* 0x138f: movabs rax,0x206469206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334106094897424756ULL);
x86_l_1399:
	/* 0x1399: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_139e:
	/* 0x139e: movabs rbx,0x6365732074786554 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 7162257365632836948ULL);
x86_l_13a8:
	/* 0x13a8: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13ad:
	/* 0x13ad: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_13b4:
	/* 0x13b4: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13b9:
	/* 0x13b9: mov    eax,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_13be:
	/* 0x13be: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_13c4:
	/* 0x13c4: mov    rcx,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_13cb:
	/* 0x13cb: mov    esi,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 50ULL);
x86_l_13d0:
	/* 0x13d0: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_13d3:
	/* 0x13d3: mov    r8d,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_32);
x86_l_13d6:
	/* 0x13d6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13d8:
	/* 0x13d8: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13db:
	/* 0x13db: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13df:
	/* 0x13df: je     f19 <perf_unwind_dotnet+0xf19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13df, 0xf19, x86_l_f19);
x86_l_13e5:
	/* 0x13e5: movabs rax,0xa786c6c252073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947156833280115ULL);
x86_l_13ef:
	/* 0x13ef: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_13f4:
	/* 0x13f4: movabs rax,0x7369207465736666 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8316213871206688358ULL);
x86_l_13fe:
	/* 0x13fe: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1403:
	/* 0x1403: movabs rax,0x6f20646e61202c78 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8007510562703420536ULL);
x86_l_140d:
	/* 0x140d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1412:
	/* 0x1412: movabs rax,0x6c6c252073692073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7812660274886418547ULL);
x86_l_141c:
	/* 0x141c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1421:
	/* 0x1421: movabs rax,0x616962206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7019249385664899444ULL);
x86_l_142b:
	/* 0x142b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1430:
	/* 0x1430: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1435:
	/* 0x1435: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_143a:
	/* 0x143a: mov    eax,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 47ULL);
x86_l_143f:
	/* 0x143f: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_1445:
	/* 0x1445: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_144c:
	/* 0x144c: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1453:
	/* 0x1453: mov    esi,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 47ULL);
x86_l_1458:
	/* 0x1458: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_145a:
	/* 0x145a: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_145d:
	/* 0x145d: jmp    f19 <perf_unwind_dotnet+0xf19> */
	X86_SIM_X86_JMP(0x145d, 0xf19, x86_l_f19);
x86_l_1462:
	/* 0x1462: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_146c:
	/* 0x146c: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_1471:
	/* 0x1471: movabs rax,0x746e6520646e6f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8389754345636130659ULL);
x86_l_147b:
	/* 0x147b: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1480:
	/* 0x1480: movabs rax,0x6573203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310222055652992288ULL);
x86_l_148a:
	/* 0x148a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_148f:
	/* 0x148f: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_1499:
	/* 0x1499: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_149e:
	/* 0x149e: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_14a8:
	/* 0x14a8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14ad:
	/* 0x14ad: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_14b7:
	/* 0x14b7: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_14bc:
	/* 0x14bc: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_14c6:
	/* 0x14c6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14cb:
	/* 0x14cb: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14d0:
	/* 0x14d0: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_14d5:
	/* 0x14d5: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_14db:
	/* 0x14db: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_14e0:
	/* 0x14e0: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_14e3:
	/* 0x14e3: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_14e6:
	/* 0x14e6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14e8:
	/* 0x14e8: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_14eb:
	/* 0x14eb: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14ed:
	/* 0x14ed: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_14f0:
	/* 0x14f0: jne    624 <perf_unwind_dotnet+0x624> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14f0, 0x624, x86_l_624);
x86_l_14f6:
	/* 0x14f6: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_14fd:
	/* 0x14fd: mov    ecx,0xffffff84 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967172ULL);
x86_l_1502:
	/* 0x1502: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1505:
	/* 0x1505: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1505, 0x19fd, x86_l_19fd);
x86_l_150b:
	/* 0x150b: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_1512:
	/* 0x1512: mov    ecx,0xffffff86 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967174ULL);
x86_l_1517:
	/* 0x1517: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_151a:
	/* 0x151a: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x151a, 0x19fd, x86_l_19fd);
x86_l_1520:
	/* 0x1520: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_1527:
	/* 0x1527: mov    ecx,0xffffff88 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967176ULL);
x86_l_152c:
	/* 0x152c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_152f:
	/* 0x152f: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x152f, 0x19fd, x86_l_19fd);
x86_l_1535:
	/* 0x1535: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_153c:
	/* 0x153c: mov    ecx,0xffffff8a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967178ULL);
x86_l_1541:
	/* 0x1541: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1544:
	/* 0x1544: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1544, 0x19fd, x86_l_19fd);
x86_l_154a:
	/* 0x154a: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_1551:
	/* 0x1551: mov    ecx,0xffffff8c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967180ULL);
x86_l_1556:
	/* 0x1556: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1559:
	/* 0x1559: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1559, 0x19fd, x86_l_19fd);
x86_l_155f:
	/* 0x155f: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_1566:
	/* 0x1566: mov    ecx,0xffffff8e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967182ULL);
x86_l_156b:
	/* 0x156b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_156e:
	/* 0x156e: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x156e, 0x19fd, x86_l_19fd);
x86_l_1574:
	/* 0x1574: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_157b:
	/* 0x157b: mov    ecx,0xffffff90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967184ULL);
x86_l_1580:
	/* 0x1580: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1583:
	/* 0x1583: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1583, 0x19fd, x86_l_19fd);
x86_l_1589:
	/* 0x1589: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_1590:
	/* 0x1590: mov    ecx,0xffffff92 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967186ULL);
x86_l_1595:
	/* 0x1595: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1598:
	/* 0x1598: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1598, 0x19fd, x86_l_19fd);
x86_l_159e:
	/* 0x159e: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_15a5:
	/* 0x15a5: mov    ecx,0xffffff94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967188ULL);
x86_l_15aa:
	/* 0x15aa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_15ad:
	/* 0x15ad: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15ad, 0x19fd, x86_l_19fd);
x86_l_15b3:
	/* 0x15b3: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_15ba:
	/* 0x15ba: mov    ecx,0xffffff96 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967190ULL);
x86_l_15bf:
	/* 0x15bf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_15c2:
	/* 0x15c2: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15c2, 0x19fd, x86_l_19fd);
x86_l_15c8:
	/* 0x15c8: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_15cf:
	/* 0x15cf: mov    ecx,0xffffff98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967192ULL);
x86_l_15d4:
	/* 0x15d4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_15d7:
	/* 0x15d7: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15d7, 0x19fd, x86_l_19fd);
x86_l_15dd:
	/* 0x15dd: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_15e4:
	/* 0x15e4: mov    ecx,0xffffff9a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967194ULL);
x86_l_15e9:
	/* 0x15e9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_15ec:
	/* 0x15ec: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15ec, 0x19fd, x86_l_19fd);
x86_l_15f2:
	/* 0x15f2: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_15f9:
	/* 0x15f9: mov    ecx,0xffffff9c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967196ULL);
x86_l_15fe:
	/* 0x15fe: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1601:
	/* 0x1601: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1601, 0x19fd, x86_l_19fd);
x86_l_1607:
	/* 0x1607: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_160e:
	/* 0x160e: mov    ecx,0xffffff9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967198ULL);
x86_l_1613:
	/* 0x1613: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1616:
	/* 0x1616: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1616, 0x19fd, x86_l_19fd);
x86_l_161c:
	/* 0x161c: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_1623:
	/* 0x1623: mov    ecx,0xffffffa0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967200ULL);
x86_l_1628:
	/* 0x1628: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_162b:
	/* 0x162b: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x162b, 0x19fd, x86_l_19fd);
x86_l_1631:
	/* 0x1631: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_1638:
	/* 0x1638: mov    ecx,0xffffffa2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967202ULL);
x86_l_163d:
	/* 0x163d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1640:
	/* 0x1640: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1640, 0x19fd, x86_l_19fd);
x86_l_1646:
	/* 0x1646: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_164d:
	/* 0x164d: mov    ecx,0xffffffa4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967204ULL);
x86_l_1652:
	/* 0x1652: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1655:
	/* 0x1655: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1655, 0x19fd, x86_l_19fd);
x86_l_165b:
	/* 0x165b: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_1662:
	/* 0x1662: mov    ecx,0xffffffa6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967206ULL);
x86_l_1667:
	/* 0x1667: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_166a:
	/* 0x166a: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x166a, 0x19fd, x86_l_19fd);
x86_l_1670:
	/* 0x1670: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_1677:
	/* 0x1677: mov    ecx,0xffffffa8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967208ULL);
x86_l_167c:
	/* 0x167c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_167f:
	/* 0x167f: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x167f, 0x19fd, x86_l_19fd);
x86_l_1685:
	/* 0x1685: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_168c:
	/* 0x168c: mov    ecx,0xffffffaa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967210ULL);
x86_l_1691:
	/* 0x1691: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1694:
	/* 0x1694: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1694, 0x19fd, x86_l_19fd);
x86_l_169a:
	/* 0x169a: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_16a1:
	/* 0x16a1: mov    ecx,0xffffffac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967212ULL);
x86_l_16a6:
	/* 0x16a6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16a9:
	/* 0x16a9: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16a9, 0x19fd, x86_l_19fd);
x86_l_16af:
	/* 0x16af: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_16b6:
	/* 0x16b6: mov    ecx,0xffffffae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967214ULL);
x86_l_16bb:
	/* 0x16bb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16be:
	/* 0x16be: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16be, 0x19fd, x86_l_19fd);
x86_l_16c4:
	/* 0x16c4: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_16cb:
	/* 0x16cb: mov    ecx,0xffffffb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967216ULL);
x86_l_16d0:
	/* 0x16d0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16d3:
	/* 0x16d3: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16d3, 0x19fd, x86_l_19fd);
x86_l_16d9:
	/* 0x16d9: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_16e0:
	/* 0x16e0: mov    ecx,0xffffffb2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967218ULL);
x86_l_16e5:
	/* 0x16e5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16e8:
	/* 0x16e8: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16e8, 0x19fd, x86_l_19fd);
x86_l_16ee:
	/* 0x16ee: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_16f5:
	/* 0x16f5: mov    ecx,0xffffffb4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967220ULL);
x86_l_16fa:
	/* 0x16fa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_16fd:
	/* 0x16fd: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16fd, 0x19fd, x86_l_19fd);
x86_l_1703:
	/* 0x1703: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_170a:
	/* 0x170a: mov    ecx,0xffffffb6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967222ULL);
x86_l_170f:
	/* 0x170f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1712:
	/* 0x1712: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1712, 0x19fd, x86_l_19fd);
x86_l_1718:
	/* 0x1718: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_171f:
	/* 0x171f: mov    ecx,0xffffffb8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967224ULL);
x86_l_1724:
	/* 0x1724: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1727:
	/* 0x1727: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1727, 0x19fd, x86_l_19fd);
x86_l_172d:
	/* 0x172d: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_1734:
	/* 0x1734: mov    ecx,0xffffffba */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967226ULL);
x86_l_1739:
	/* 0x1739: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_173c:
	/* 0x173c: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x173c, 0x19fd, x86_l_19fd);
x86_l_1742:
	/* 0x1742: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_1749:
	/* 0x1749: mov    ecx,0xffffffbc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967228ULL);
x86_l_174e:
	/* 0x174e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1751:
	/* 0x1751: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1751, 0x19fd, x86_l_19fd);
x86_l_1757:
	/* 0x1757: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_175e:
	/* 0x175e: mov    ecx,0xffffffbe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967230ULL);
x86_l_1763:
	/* 0x1763: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1766:
	/* 0x1766: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1766, 0x19fd, x86_l_19fd);
x86_l_176c:
	/* 0x176c: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_1773:
	/* 0x1773: mov    ecx,0xffffffc0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967232ULL);
x86_l_1778:
	/* 0x1778: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_177b:
	/* 0x177b: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x177b, 0x19fd, x86_l_19fd);
x86_l_1781:
	/* 0x1781: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_1788:
	/* 0x1788: mov    ecx,0xffffffc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967234ULL);
x86_l_178d:
	/* 0x178d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1790:
	/* 0x1790: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1790, 0x19fd, x86_l_19fd);
x86_l_1796:
	/* 0x1796: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_179d:
	/* 0x179d: mov    ecx,0xffffffc4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967236ULL);
x86_l_17a2:
	/* 0x17a2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17a5:
	/* 0x17a5: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17a5, 0x19fd, x86_l_19fd);
x86_l_17ab:
	/* 0x17ab: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_17b2:
	/* 0x17b2: mov    ecx,0xffffffc6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967238ULL);
x86_l_17b7:
	/* 0x17b7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17ba:
	/* 0x17ba: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17ba, 0x19fd, x86_l_19fd);
x86_l_17c0:
	/* 0x17c0: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_17c7:
	/* 0x17c7: mov    ecx,0xffffffc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967240ULL);
x86_l_17cc:
	/* 0x17cc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17cf:
	/* 0x17cf: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17cf, 0x19fd, x86_l_19fd);
x86_l_17d5:
	/* 0x17d5: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_17dc:
	/* 0x17dc: mov    ecx,0xffffffca */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967242ULL);
x86_l_17e1:
	/* 0x17e1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17e4:
	/* 0x17e4: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17e4, 0x19fd, x86_l_19fd);
x86_l_17ea:
	/* 0x17ea: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_17f1:
	/* 0x17f1: mov    ecx,0xffffffcc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967244ULL);
x86_l_17f6:
	/* 0x17f6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17f9:
	/* 0x17f9: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17f9, 0x19fd, x86_l_19fd);
x86_l_17ff:
	/* 0x17ff: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_1806:
	/* 0x1806: mov    ecx,0xffffffce */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967246ULL);
x86_l_180b:
	/* 0x180b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_180e:
	/* 0x180e: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x180e, 0x19fd, x86_l_19fd);
x86_l_1814:
	/* 0x1814: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_181b:
	/* 0x181b: mov    ecx,0xffffffd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967248ULL);
x86_l_1820:
	/* 0x1820: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1823:
	/* 0x1823: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1823, 0x19fd, x86_l_19fd);
x86_l_1829:
	/* 0x1829: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_1830:
	/* 0x1830: mov    ecx,0xffffffd2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967250ULL);
x86_l_1835:
	/* 0x1835: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1838:
	/* 0x1838: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1838, 0x19fd, x86_l_19fd);
x86_l_183e:
	/* 0x183e: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_1845:
	/* 0x1845: mov    ecx,0xffffffd4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967252ULL);
x86_l_184a:
	/* 0x184a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_184d:
	/* 0x184d: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x184d, 0x19fd, x86_l_19fd);
x86_l_1853:
	/* 0x1853: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_185a:
	/* 0x185a: mov    ecx,0xffffffd6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967254ULL);
x86_l_185f:
	/* 0x185f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1862:
	/* 0x1862: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1862, 0x19fd, x86_l_19fd);
x86_l_1868:
	/* 0x1868: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_186f:
	/* 0x186f: mov    ecx,0xffffffd8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967256ULL);
x86_l_1874:
	/* 0x1874: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1877:
	/* 0x1877: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1877, 0x19fd, x86_l_19fd);
x86_l_187d:
	/* 0x187d: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_1884:
	/* 0x1884: mov    ecx,0xffffffda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967258ULL);
x86_l_1889:
	/* 0x1889: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_188c:
	/* 0x188c: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x188c, 0x19fd, x86_l_19fd);
x86_l_1892:
	/* 0x1892: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_1899:
	/* 0x1899: mov    ecx,0xffffffdc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967260ULL);
x86_l_189e:
	/* 0x189e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_18a1:
	/* 0x18a1: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18a1, 0x19fd, x86_l_19fd);
x86_l_18a7:
	/* 0x18a7: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_18ae:
	/* 0x18ae: mov    ecx,0xffffffde */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967262ULL);
x86_l_18b3:
	/* 0x18b3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_18b6:
	/* 0x18b6: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18b6, 0x19fd, x86_l_19fd);
x86_l_18bc:
	/* 0x18bc: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_18c3:
	/* 0x18c3: mov    ecx,0xffffffe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967264ULL);
x86_l_18c8:
	/* 0x18c8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_18cb:
	/* 0x18cb: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18cb, 0x19fd, x86_l_19fd);
x86_l_18d1:
	/* 0x18d1: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_18d8:
	/* 0x18d8: mov    ecx,0xffffffe2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967266ULL);
x86_l_18dd:
	/* 0x18dd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_18e0:
	/* 0x18e0: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18e0, 0x19fd, x86_l_19fd);
x86_l_18e6:
	/* 0x18e6: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_18ed:
	/* 0x18ed: mov    ecx,0xffffffe4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967268ULL);
x86_l_18f2:
	/* 0x18f2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_18f5:
	/* 0x18f5: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18f5, 0x19fd, x86_l_19fd);
x86_l_18fb:
	/* 0x18fb: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_1902:
	/* 0x1902: mov    ecx,0xffffffe6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967270ULL);
x86_l_1907:
	/* 0x1907: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_190a:
	/* 0x190a: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x190a, 0x19fd, x86_l_19fd);
x86_l_1910:
	/* 0x1910: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_1917:
	/* 0x1917: mov    ecx,0xffffffe8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967272ULL);
x86_l_191c:
	/* 0x191c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_191f:
	/* 0x191f: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x191f, 0x19fd, x86_l_19fd);
x86_l_1925:
	/* 0x1925: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_192c:
	/* 0x192c: mov    ecx,0xffffffea */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967274ULL);
x86_l_1931:
	/* 0x1931: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1934:
	/* 0x1934: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1934, 0x19fd, x86_l_19fd);
x86_l_193a:
	/* 0x193a: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_1941:
	/* 0x1941: mov    ecx,0xffffffec */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967276ULL);
x86_l_1946:
	/* 0x1946: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1949:
	/* 0x1949: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1949, 0x19fd, x86_l_19fd);
x86_l_194f:
	/* 0x194f: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_1956:
	/* 0x1956: mov    ecx,0xffffffee */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967278ULL);
x86_l_195b:
	/* 0x195b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_195e:
	/* 0x195e: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x195e, 0x19fd, x86_l_19fd);
x86_l_1964:
	/* 0x1964: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_196b:
	/* 0x196b: mov    ecx,0xfffffff0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967280ULL);
x86_l_1970:
	/* 0x1970: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1973:
	/* 0x1973: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1973, 0x19fd, x86_l_19fd);
x86_l_1979:
	/* 0x1979: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_1980:
	/* 0x1980: mov    ecx,0xfffffff2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967282ULL);
x86_l_1985:
	/* 0x1985: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1988:
	/* 0x1988: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1988, 0x19fd, x86_l_19fd);
x86_l_198a:
	/* 0x198a: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_1991:
	/* 0x1991: mov    ecx,0xfffffff4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967284ULL);
x86_l_1996:
	/* 0x1996: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1999:
	/* 0x1999: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1999, 0x19fd, x86_l_19fd);
x86_l_199b:
	/* 0x199b: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_19a2:
	/* 0x19a2: mov    ecx,0xfffffff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967286ULL);
x86_l_19a7:
	/* 0x19a7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19aa:
	/* 0x19aa: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19aa, 0x19fd, x86_l_19fd);
x86_l_19ac:
	/* 0x19ac: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_19b3:
	/* 0x19b3: mov    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967288ULL);
x86_l_19b8:
	/* 0x19b8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19bb:
	/* 0x19bb: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19bb, 0x19fd, x86_l_19fd);
x86_l_19bd:
	/* 0x19bd: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_19c4:
	/* 0x19c4: mov    ecx,0xfffffffa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967290ULL);
x86_l_19c9:
	/* 0x19c9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19cc:
	/* 0x19cc: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19cc, 0x19fd, x86_l_19fd);
x86_l_19ce:
	/* 0x19ce: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_19d5:
	/* 0x19d5: mov    ecx,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967292ULL);
x86_l_19da:
	/* 0x19da: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19dd:
	/* 0x19dd: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19dd, 0x19fd, x86_l_19fd);
x86_l_19df:
	/* 0x19df: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_19e6:
	/* 0x19e6: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_19eb:
	/* 0x19eb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19ee:
	/* 0x19ee: jne    19fd <perf_unwind_dotnet+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19ee, 0x19fd, x86_l_19fd);
x86_l_19f0:
	/* 0x19f0: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_19f8:
	/* 0x19f8: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19fb:
	/* 0x19fb: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_19fd:
	/* 0x19fd: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_19ff:
	/* 0x19ff: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1a02:
	/* 0x1a02: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1a06:
	/* 0x1a06: setne  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_NE);
x86_l_1a09:
	/* 0x1a09: cmove  r15d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_1a0d:
	/* 0x1a0d: sub    ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1a0f:
	/* 0x1a0f: add    ecx,0x7e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_1a12:
	/* 0x1a12: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_1a14:
	/* 0x1a14: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_1a17:
	/* 0x1a17: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_1a1a:
	/* 0x1a1a: jb     632 <perf_unwind_dotnet+0x632> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a1a, 0x632, x86_l_632);
x86_l_1a20:
	/* 0x1a20: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1a27:
	/* 0x1a27: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a2a:
	/* 0x1a2a: jne    1b20 <perf_unwind_dotnet+0x1b20> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a2a, 0x1b20, x86_l_1b20);
x86_l_1a30:
	/* 0x1a30: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_1a33:
	/* 0x1a33: jne    496 <perf_unwind_dotnet+0x496> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a33, 0x496, x86_l_496);
x86_l_1a39:
	/* 0x1a39: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_1a41:
	/* 0x1a41: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_1a48:
	/* 0x1a48: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1a4d:
	/* 0x1a4d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1a52:
	/* 0x1a52: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a54:
	/* 0x1a54: mov    r12,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBX, X86_WIDTH_64);
x86_l_1a57:
	/* 0x1a57: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1a5a:
	/* 0x1a5a: je     1a81 <perf_unwind_dotnet+0x1a81> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a5a, 0x1a81, x86_l_1a81);
x86_l_1a5c:
	/* 0x1a5c: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1a5f:
	/* 0x1a5f: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a64:
	/* 0x1a64: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_1a6b:
	/* 0x1a6b: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_1a70:
	/* 0x1a70: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_1a75:
	/* 0x1a75: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a79:
	/* 0x1a79: je     4d5 <perf_unwind_dotnet+0x4d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a79, 0x4d5, x86_l_4d5);
x86_l_1a7f:
	/* 0x1a7f: jmp    1aab <perf_unwind_dotnet+0x1aab> */
	X86_SIM_X86_JMP(0x1a7f, 0x1aab, x86_l_1aab);
x86_l_1a81:
	/* 0x1a81: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_1a88:
	/* 0x1a88: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a8c:
	/* 0x1a8c: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a91:
	/* 0x1a91: jne    2185 <perf_unwind_dotnet+0x2185> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a91, 0x2185, x86_l_2185);
x86_l_1a97:
	/* 0x1a97: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_1a9c:
	/* 0x1a9c: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_1aa1:
	/* 0x1aa1: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aa5:
	/* 0x1aa5: je     4d5 <perf_unwind_dotnet+0x4d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1aa5, 0x4d5, x86_l_4d5);
x86_l_1aab:
	/* 0x1aab: movabs rax,0xa642520687469 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387390569ULL);
x86_l_1ab5:
	/* 0x1ab5: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1aba:
	/* 0x1aba: movabs rax,0x772064656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8583971276541485414ULL);
x86_l_1ac4:
	/* 0x1ac4: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ac9:
	/* 0x1ac9: movabs rax,0x2074726174735f65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338619869403242341ULL);
x86_l_1ad3:
	/* 0x1ad3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ad8:
	/* 0x1ad8: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7237112116340927776ULL);
x86_l_1ae2:
	/* 0x1ae2: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ae7:
	/* 0x1ae7: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_1af1:
	/* 0x1af1: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1af6:
	/* 0x1af6: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1afb:
	/* 0x1afb: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_1b00:
	/* 0x1b00: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_1b05:
	/* 0x1b05: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_1b0a:
	/* 0x1b0a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1b0c:
	/* 0x1b0c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b0e:
	/* 0x1b0e: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_1b13:
	/* 0x1b13: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_1b15:
	/* 0x1b15: jne    4e2 <perf_unwind_dotnet+0x4e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b15, 0x4e2, x86_l_4e2);
x86_l_1b1b:
	/* 0x1b1b: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0x1b1b, 0x7712, x86_l_7712);
x86_l_1b20:
	/* 0x1b20: movabs rax,0x207972746e65202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2340027325789577260ULL);
x86_l_1b2a:
	/* 0x1b2a: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1b2f:
	/* 0x1b2f: movabs rax,0x6425206465707069 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7216209593501773929ULL);
x86_l_1b39:
	/* 0x1b39: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1b3e:
	/* 0x1b3e: movabs rax,0x6b73203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7742567619880559904ULL);
x86_l_1b48:
	/* 0x1b48: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b4d:
	/* 0x1b4d: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_1b57:
	/* 0x1b57: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b5c:
	/* 0x1b5c: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_1b66:
	/* 0x1b66: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b6b:
	/* 0x1b6b: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_1b75:
	/* 0x1b75: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b7a:
	/* 0x1b7a: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_1b84:
	/* 0x1b84: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b89:
	/* 0x1b89: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_1b91:
	/* 0x1b91: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b96:
	/* 0x1b96: mov    eax,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_1b9b:
	/* 0x1b9b: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_1ba1:
	/* 0x1ba1: mov    esi,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 60ULL);
x86_l_1ba6:
	/* 0x1ba6: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1ba9:
	/* 0x1ba9: mov    r8d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_32);
x86_l_1bac:
	/* 0x1bac: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1bae:
	/* 0x1bae: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1bb1:
	/* 0x1bb1: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_1bb4:
	/* 0x1bb4: jne    496 <perf_unwind_dotnet+0x496> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bb4, 0x496, x86_l_496);
x86_l_1bba:
	/* 0x1bba: jmp    1a39 <perf_unwind_dotnet+0x1a39> */
	X86_SIM_X86_JMP(0x1bba, 0x1a39, x86_l_1a39);
x86_l_1bbf:
	/* 0x1bbf: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_1bc9:
	/* 0x1bc9: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1bce:
	/* 0x1bce: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_1bd8:
	/* 0x1bd8: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1bdd:
	/* 0x1bdd: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_1be7:
	/* 0x1be7: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1bec:
	/* 0x1bec: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_1bf6:
	/* 0x1bf6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bfb:
	/* 0x1bfb: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_1c05:
	/* 0x1c05: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c0a:
	/* 0x1c0a: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_1c14:
	/* 0x1c14: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c19:
	/* 0x1c19: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c1e:
	/* 0x1c1e: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_1c23:
	/* 0x1c23: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_1c28:
	/* 0x1c28: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c2c:
	/* 0x1c2c: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_1c31:
	/* 0x1c31: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c33:
	/* 0x1c33: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c35:
	/* 0x1c35: jmp    c22 <perf_unwind_dotnet+0xc22> */
	X86_SIM_X86_JMP(0x1c35, 0xc22, x86_l_c22);
x86_l_1c3a:
	/* 0x1c3a: movabs rcx,0xa642520686374 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 2924860387386228ULL);
x86_l_1c44:
	/* 0x1c44: mov    QWORD PTR [rsp+0x26],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_1c49:
	/* 0x1c49: movabs rcx,0x6374616d20737465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 7166460028377068645ULL);
x86_l_1c53:
	/* 0x1c53: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c58:
	/* 0x1c58: movabs rcx,0x7366666f5f726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 8315446390514935156ULL);
x86_l_1c62:
	/* 0x1c62: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c67:
	/* 0x1c67: movabs rcx,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_1c71:
	/* 0x1c71: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c76:
	/* 0x1c76: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c7b:
	/* 0x1c7b: mov    ecx,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 30ULL);
x86_l_1c80:
	/* 0x1c80: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_1c86:
	/* 0x1c86: movzx  edx,WORD PTR [rax+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1c8a:
	/* 0x1c8a: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_1c8f:
	/* 0x1c8f: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_1c92:
	/* 0x1c92: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c94:
	/* 0x1c94: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c97:
	/* 0x1c97: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_1c9a:
	/* 0x1c9a: mov    ecx,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_1ca1:
	/* 0x1ca1: mov    edx,DWORD PTR [rax+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ca4:
	/* 0x1ca4: bt     ecx,edx */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_1ca7:
	/* 0x1ca7: jb     f94 <perf_unwind_dotnet+0xf94> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ca7, 0xf94, x86_l_f94);
x86_l_1cad:
	/* 0x1cad: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_1cb0:
	/* 0x1cb0: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1cb8:
	/* 0x1cb8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_1cbf:
	/* 0x1cbf: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1cc4:
	/* 0x1cc4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1cc9:
	/* 0x1cc9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ccb:
	/* 0x1ccb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1cce:
	/* 0x1cce: je     1cd8 <perf_unwind_dotnet+0x1cd8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cce, 0x1cd8, x86_l_1cd8);
x86_l_1cd0:
	/* 0x1cd0: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1cd3:
	/* 0x1cd3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_1cd6:
	/* 0x1cd6: jmp    1ce5 <perf_unwind_dotnet+0x1ce5> */
	X86_SIM_X86_JMP(0x1cd6, 0x1ce5, x86_l_1ce5);
x86_l_1cd8:
	/* 0x1cd8: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cdc:
	/* 0x1cdc: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_1cdf:
	/* 0x1cdf: jne    22f8 <perf_unwind_dotnet+0x22f8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cdf, 0x22f8, x86_l_22f8);
x86_l_1ce5:
	/* 0x1ce5: movzx  r12d,WORD PTR [rax+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1cea:
	/* 0x1cea: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1cec:
	/* 0x1cec: cmp    r12d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 8ULL);
x86_l_1cf0:
	/* 0x1cf0: jne    7715 <perf_unwind_dotnet+0x7715> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cf0, 0x7715, x86_l_7715);
x86_l_1cf6:
	/* 0x1cf6: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1cfd:
	/* 0x1cfd: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1d04:
	/* 0x1d04: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1d0b:
	/* 0x1d0b: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_1d13:
	/* 0x1d13: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d17:
	/* 0x1d17: jne    20dd <perf_unwind_dotnet+0x20dd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d17, 0x20dd, x86_l_20dd);
x86_l_1d1d:
	/* 0x1d1d: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_1d20:
	/* 0x1d20: jb     76c0 <perf_unwind_dotnet+0x76c0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d20, 0x76c0, x86_l_76c0);
x86_l_1d26:
	/* 0x1d26: lea    rax,[rbx+0x2000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_1d2d:
	/* 0x1d2d: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_1d30:
	/* 0x1d30: jae    76c0 <perf_unwind_dotnet+0x76c0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1d30, 0x76c0, x86_l_76c0);
x86_l_1d36:
	/* 0x1d36: mov    ebx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RCX, X86_WIDTH_32);
x86_l_1d38:
	/* 0x1d38: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1d3f:
	/* 0x1d3f: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1d46:
	/* 0x1d46: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1d4b:
	/* 0x1d4b: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_1d53:
	/* 0x1d53: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_1d56:
	/* 0x1d56: and    rax,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_1d5a:
	/* 0x1d5a: cmp    rax,0x80 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_1d60:
	/* 0x1d60: jne    1da4 <perf_unwind_dotnet+0x1da4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d60, 0x1da4, x86_l_1da4);
x86_l_1d62:
	/* 0x1d62: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1d69:
	/* 0x1d69: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1d6e:
	/* 0x1d6e: mov    r8d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 112ULL);
x86_l_1d74:
	/* 0x1d74: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1d7c:
	/* 0x1d7c: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1d83:
	/* 0x1d83: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1d88:
	/* 0x1d88: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d8b:
	/* 0x1d8b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1d8e:
	/* 0x1d8e: jne    19c <perf_unwind_dotnet+0x19c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d8e, 0x19c, x86_l_19c);
x86_l_1d94:
	/* 0x1d94: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_1d9c:
	/* 0x1d9c: and    ebp,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1d9f:
	/* 0x1d9f: jmp    23ce <perf_unwind_dotnet+0x23ce> */
	X86_SIM_X86_JMP(0x1d9f, 0x23ce, x86_l_23ce);
x86_l_1da4:
	/* 0x1da4: lea    rdi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1da9:
	/* 0x1da9: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_1dae:
	/* 0x1dae: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_1db3:
	/* 0x1db3: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_1db8:
	/* 0x1db8: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1dbb:
	/* 0x1dbb: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1dbd:
	/* 0x1dbd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1dc0:
	/* 0x1dc0: jne    26c <perf_unwind_dotnet+0x26c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dc0, 0x26c, x86_l_26c);
x86_l_1dc6:
	/* 0x1dc6: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1dca:
	/* 0x1dca: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1dd1:
	/* 0x1dd1: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1dd6:
	/* 0x1dd6: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1ddd:
	/* 0x1ddd: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1de2:
	/* 0x1de2: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1de9:
	/* 0x1de9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1df0:
	/* 0x1df0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1df3:
	/* 0x1df3: jne    2214 <perf_unwind_dotnet+0x2214> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1df3, 0x2214, x86_l_2214);
x86_l_1df9:
	/* 0x1df9: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_1e00:
	/* 0x1e00: jb     23ce <perf_unwind_dotnet+0x23ce> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e00, 0x23ce, x86_l_23ce);
x86_l_1e06:
	/* 0x1e06: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1e0d:
	/* 0x1e0d: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1e14:
	/* 0x1e14: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_1e17:
	/* 0x1e17: sub    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_1e1a:
	/* 0x1e1a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1e21:
	/* 0x1e21: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e24:
	/* 0x1e24: jne    22b4 <perf_unwind_dotnet+0x22b4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e24, 0x22b4, x86_l_22b4);
x86_l_1e2a:
	/* 0x1e2a: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_1e2d:
	/* 0x1e2d: shr    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_1e31:
	/* 0x1e31: mov    ecx,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 127ULL);
x86_l_1e36:
	/* 0x1e36: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1e38:
	/* 0x1e38: and    ecx,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1e3b:
	/* 0x1e3b: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1e3d:
	/* 0x1e3d: cmp    r13,0x8000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 32768ULL);
x86_l_1e44:
	/* 0x1e44: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_1e4c:
	/* 0x1e4c: cmovb  rdx,rsi */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B);
x86_l_1e50:
	/* 0x1e50: cmovae ecx,esi */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE);
x86_l_1e53:
	/* 0x1e53: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1e56:
	/* 0x1e56: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1e5e:
	/* 0x1e5e: lea    rdi,[rax+rcx*4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_1e62:
	/* 0x1e62: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
x86_l_1e67:
	/* 0x1e67: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_1e6c:
	/* 0x1e6c: mov    esi,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 512ULL);
x86_l_1e71:
	/* 0x1e71: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e73:
	/* 0x1e73: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1e76:
	/* 0x1e76: je     1ead <perf_unwind_dotnet+0x1ead> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e76, 0x1ead, x86_l_1ead);
x86_l_1e78:
	/* 0x1e78: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1e7f:
	/* 0x1e7f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e82:
	/* 0x1e82: jne    206e <perf_unwind_dotnet+0x206e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e82, 0x206e, x86_l_206e);
x86_l_1e88:
	/* 0x1e88: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_1e90:
	/* 0x1e90: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_1e97:
	/* 0x1e97: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1e9c:
	/* 0x1e9c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ea1:
	/* 0x1ea1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ea3:
	/* 0x1ea3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1ea6:
	/* 0x1ea6: je     1f04 <perf_unwind_dotnet+0x1f04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea6, 0x1f04, x86_l_1f04);
x86_l_1ea8:
	/* 0x1ea8: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1eab:
	/* 0x1eab: jmp    1f14 <perf_unwind_dotnet+0x1f14> */
	X86_SIM_X86_JMP(0x1eab, 0x1f14, x86_l_1f14);
x86_l_1ead:
	/* 0x1ead: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_1eb4:
	/* 0x1eb4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1ebb:
	/* 0x1ebb: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ebe:
	/* 0x1ebe: jne    289c <perf_unwind_dotnet+0x289c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ebe, 0x289c, x86_l_289c);
x86_l_1ec4:
	/* 0x1ec4: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_1ec7:
	/* 0x1ec7: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_1ec9:
	/* 0x1ec9: shr    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_1ecc:
	/* 0x1ecc: and    al,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_1ece:
	/* 0x1ece: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_1ed3:
	/* 0x1ed3: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_1ed6:
	/* 0x1ed6: je     1fa1 <perf_unwind_dotnet+0x1fa1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed6, 0x1fa1, x86_l_1fa1);
x86_l_1edc:
	/* 0x1edc: and    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_1ee0:
	/* 0x1ee0: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_1ee3:
	/* 0x1ee3: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1ee6:
	/* 0x1ee6: jne    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee6, 0x2381, x86_l_2381);
x86_l_1eec:
	/* 0x1eec: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_1eef:
	/* 0x1eef: shr    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_1ef2:
	/* 0x1ef2: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1ef5:
	/* 0x1ef5: je     20b1 <perf_unwind_dotnet+0x20b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef5, 0x20b1, x86_l_20b1);
x86_l_1efb:
	/* 0x1efb: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_1eff:
	/* 0x1eff: jmp    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JMP(0x1eff, 0x2381, x86_l_2381);
x86_l_1f04:
	/* 0x1f04: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1f0b:
	/* 0x1f0b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f0e:
	/* 0x1f0e: jne    29ad <perf_unwind_dotnet+0x29ad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f0e, 0x29ad, x86_l_29ad);
x86_l_1f14:
	/* 0x1f14: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_1f19:
	/* 0x1f19: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f1b:
	/* 0x1f1b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1f22:
	/* 0x1f22: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f25:
	/* 0x1f25: jne    3163 <perf_unwind_dotnet+0x3163> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f25, 0x3163, x86_l_3163);
x86_l_1f2b:
	/* 0x1f2b: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_1f30:
	/* 0x1f30: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_1f32:
	/* 0x1f32: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1f37:
	/* 0x1f37: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_1f3e:
	/* 0x1f3e: je     7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f3e, 0x7712, x86_l_7712);
x86_l_1f44:
	/* 0x1f44: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1f4b:
	/* 0x1f4b: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_1f4f:
	/* 0x1f4f: ja     4f3 <perf_unwind_dotnet+0x4f3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1f4f, 0x4f3, x86_l_4f3);
x86_l_1f55:
	/* 0x1f55: lea    ecx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f58:
	/* 0x1f58: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1f5f:
	/* 0x1f5f: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_1f63:
	/* 0x1f63: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_1f6f:
	/* 0x1f6f: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_1f7b:
	/* 0x1f7b: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_1f84:
	/* 0x1f84: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_1f90:
	/* 0x1f90: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_1f9c:
	/* 0x1f9c: jmp    2481 <perf_unwind_dotnet+0x2481> */
	X86_SIM_X86_JMP(0x1f9c, 0x2481, x86_l_2481);
x86_l_1fa1:
	/* 0x1fa1: and    r13,0xffffffffffffff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_1fa8:
	/* 0x1fa8: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_1fac:
	/* 0x1fac: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_1fb3:
	/* 0x1fb3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1fba:
	/* 0x1fba: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fbd:
	/* 0x1fbd: jne    2b3d <perf_unwind_dotnet+0x2b3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fbd, 0x2b3d, x86_l_2b3d);
x86_l_1fc3:
	/* 0x1fc3: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fc5:
	/* 0x1fc5: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_1fc8:
	/* 0x1fc8: je     2bd1 <perf_unwind_dotnet+0x2bd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fc8, 0x2bd1, x86_l_2bd1);
x86_l_1fce:
	/* 0x1fce: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_1fd0:
	/* 0x1fd0: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_1fd3:
	/* 0x1fd3: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_1fd6:
	/* 0x1fd6: jae    30fb <perf_unwind_dotnet+0x30fb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1fd6, 0x30fb, x86_l_30fb);
x86_l_1fdc:
	/* 0x1fdc: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_1fe3:
	/* 0x1fe3: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe6:
	/* 0x1fe6: je     1e88 <perf_unwind_dotnet+0x1e88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe6, 0x1e88, x86_l_1e88);
x86_l_1fec:
	/* 0x1fec: movabs rax,0xa657361625f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2926295996587875ULL);
x86_l_1ff6:
	/* 0x1ff6: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1ffb:
	/* 0x1ffb: movabs rax,0x5f637020776f6c65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460741042564197ULL);
x86_l_2005:
	/* 0x2005: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_200a:
	/* 0x200a: movabs rax,0x6220746e65772068 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7070779432469209192ULL);
x86_l_2014:
	/* 0x2014: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2019:
	/* 0x2019: movabs rax,0x6372616573207061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165897045450977377ULL);
x86_l_2023:
	/* 0x2023: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2028:
	/* 0x2028: movabs rax,0x6d20656c6262696e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7863396465570376046ULL);
x86_l_2032:
	/* 0x2032: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2037:
	/* 0x2037: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_2041:
	/* 0x2041: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2046:
	/* 0x2046: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_204b:
	/* 0x204b: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_2050:
	/* 0x2050: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_2055:
	/* 0x2055: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_205a:
	/* 0x205a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_205c:
	/* 0x205c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_205e:
	/* 0x205e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_2065:
	/* 0x2065: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2068:
	/* 0x2068: je     1e88 <perf_unwind_dotnet+0x1e88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2068, 0x1e88, x86_l_1e88);
x86_l_206e:
	/* 0x206e: movabs rax,0x6e756f6620746f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959390400869068654ULL);
x86_l_2078:
	/* 0x2078: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_207d:
	/* 0x207d: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_2087:
	/* 0x2087: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_208c:
	/* 0x208c: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_2094:
	/* 0x2094: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2099:
	/* 0x2099: mov    eax,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_209e:
	/* 0x209e: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_20a3:
	/* 0x20a3: mov    esi,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 19ULL);
x86_l_20a8:
	/* 0x20a8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20aa:
	/* 0x20aa: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20ac:
	/* 0x20ac: jmp    1e88 <perf_unwind_dotnet+0x1e88> */
	X86_SIM_X86_JMP(0x20ac, 0x1e88, x86_l_1e88);
x86_l_20b1:
	/* 0x20b1: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_20b4:
	/* 0x20b4: shr    ecx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_20b7:
	/* 0x20b7: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_20ba:
	/* 0x20ba: je     20c5 <perf_unwind_dotnet+0x20c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ba, 0x20c5, x86_l_20c5);
x86_l_20bc:
	/* 0x20bc: add    r13,0xffffffffffffffc0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_20c0:
	/* 0x20c0: jmp    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JMP(0x20c0, 0x2381, x86_l_2381);
x86_l_20c5:
	/* 0x20c5: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_20c8:
	/* 0x20c8: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_20cb:
	/* 0x20cb: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_20ce:
	/* 0x20ce: je     2156 <perf_unwind_dotnet+0x2156> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ce, 0x2156, x86_l_2156);
x86_l_20d4:
	/* 0x20d4: add    r13,0xffffffffffffffa0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_20d8:
	/* 0x20d8: jmp    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JMP(0x20d8, 0x2381, x86_l_2381);
x86_l_20dd:
	/* 0x20dd: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_20e7:
	/* 0x20e7: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20ec:
	/* 0x20ec: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_20f6:
	/* 0x20f6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20fb:
	/* 0x20fb: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_2105:
	/* 0x2105: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_210a:
	/* 0x210a: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_2114:
	/* 0x2114: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2119:
	/* 0x2119: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_2121:
	/* 0x2121: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2126:
	/* 0x2126: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_212b:
	/* 0x212b: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_2131:
	/* 0x2131: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_2136:
	/* 0x2136: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_2139:
	/* 0x2139: mov    ebp,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RCX, X86_WIDTH_32);
x86_l_213b:
	/* 0x213b: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_213e:
	/* 0x213e: mov    r8,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R13, X86_WIDTH_64);
x86_l_2141:
	/* 0x2141: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2143:
	/* 0x2143: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2146:
	/* 0x2146: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_2148:
	/* 0x2148: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_214b:
	/* 0x214b: jae    1d26 <perf_unwind_dotnet+0x1d26> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x214b, 0x1d26, x86_l_1d26);
x86_l_2151:
	/* 0x2151: jmp    76c0 <perf_unwind_dotnet+0x76c0> */
	X86_SIM_X86_JMP(0x2151, 0x76c0, x86_l_76c0);
x86_l_2156:
	/* 0x2156: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_2159:
	/* 0x2159: shr    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_215c:
	/* 0x215c: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_215f:
	/* 0x215f: je     216a <perf_unwind_dotnet+0x216a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215f, 0x216a, x86_l_216a);
x86_l_2161:
	/* 0x2161: add    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_2165:
	/* 0x2165: jmp    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JMP(0x2165, 0x2381, x86_l_2381);
x86_l_216a:
	/* 0x216a: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_216d:
	/* 0x216d: shr    ecx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_2170:
	/* 0x2170: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2173:
	/* 0x2173: je     2299 <perf_unwind_dotnet+0x2299> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2173, 0x2299, x86_l_2299);
x86_l_2179:
	/* 0x2179: add    r13,0xffffffffffffff60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_2180:
	/* 0x2180: jmp    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JMP(0x2180, 0x2381, x86_l_2381);
x86_l_2185:
	/* 0x2185: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_218f:
	/* 0x218f: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2194:
	/* 0x2194: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_219e:
	/* 0x219e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21a3:
	/* 0x21a3: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_21ad:
	/* 0x21ad: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21b2:
	/* 0x21b2: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_21bc:
	/* 0x21bc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21c1:
	/* 0x21c1: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_21cb:
	/* 0x21cb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21d0:
	/* 0x21d0: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_21da:
	/* 0x21da: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21df:
	/* 0x21df: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21e4:
	/* 0x21e4: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_21e9:
	/* 0x21e9: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_21ee:
	/* 0x21ee: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_21f2:
	/* 0x21f2: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_21f7:
	/* 0x21f7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_21f9:
	/* 0x21f9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_21fb:
	/* 0x21fb: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_2200:
	/* 0x2200: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2205:
	/* 0x2205: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2209:
	/* 0x2209: je     4d5 <perf_unwind_dotnet+0x4d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2209, 0x4d5, x86_l_4d5);
x86_l_220f:
	/* 0x220f: jmp    1aab <perf_unwind_dotnet+0x1aab> */
	X86_SIM_X86_JMP(0x220f, 0x1aab, x86_l_1aab);
x86_l_2214:
	/* 0x2214: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_221e:
	/* 0x221e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2223:
	/* 0x2223: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_222d:
	/* 0x222d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2232:
	/* 0x2232: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_223c:
	/* 0x223c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2241:
	/* 0x2241: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_224b:
	/* 0x224b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2250:
	/* 0x2250: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_2258:
	/* 0x2258: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_225d:
	/* 0x225d: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_2262:
	/* 0x2262: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_2268:
	/* 0x2268: mov    rdx,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_226f:
	/* 0x226f: mov    rcx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2276:
	/* 0x2276: mov    r8,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_227d:
	/* 0x227d: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_2282:
	/* 0x2282: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2284:
	/* 0x2284: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2287:
	/* 0x2287: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_228e:
	/* 0x228e: jae    1e06 <perf_unwind_dotnet+0x1e06> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x228e, 0x1e06, x86_l_1e06);
x86_l_2294:
	/* 0x2294: jmp    23ce <perf_unwind_dotnet+0x23ce> */
	X86_SIM_X86_JMP(0x2294, 0x23ce, x86_l_23ce);
x86_l_2299:
	/* 0x2299: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_229c:
	/* 0x229c: shr    ecx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_229f:
	/* 0x229f: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_22a2:
	/* 0x22a2: je     2373 <perf_unwind_dotnet+0x2373> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22a2, 0x2373, x86_l_2373);
x86_l_22a8:
	/* 0x22a8: add    r13,0xffffffffffffff40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_22af:
	/* 0x22af: jmp    2381 <perf_unwind_dotnet+0x2381> */
	X86_SIM_X86_JMP(0x22af, 0x2381, x86_l_2381);
x86_l_22b4:
	/* 0x22b4: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_22bb:
	/* 0x22bb: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22c0:
	/* 0x22c0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_22c5:
	/* 0x22c5: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_22c8:
	/* 0x22c8: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_22cb:
	/* 0x22cb: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_22d2:
	/* 0x22d2: mov    ecx,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 66ULL);
x86_l_22d7:
	/* 0x22d7: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_22dd:
	/* 0x22dd: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_22e0:
	/* 0x22e0: mov    esi,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 66ULL);
x86_l_22e5:
	/* 0x22e5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_22e8:
	/* 0x22e8: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_22eb:
	/* 0x22eb: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_22ee:
	/* 0x22ee: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_22f0:
	/* 0x22f0: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_22f3:
	/* 0x22f3: jmp    1e2a <perf_unwind_dotnet+0x1e2a> */
	X86_SIM_X86_JMP(0x22f3, 0x1e2a, x86_l_1e2a);
x86_l_22f8:
	/* 0x22f8: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_2302:
	/* 0x2302: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2307:
	/* 0x2307: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_2311:
	/* 0x2311: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2316:
	/* 0x2316: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_2320:
	/* 0x2320: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2325:
	/* 0x2325: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_232f:
	/* 0x232f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2334:
	/* 0x2334: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_233e:
	/* 0x233e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2343:
	/* 0x2343: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_234d:
	/* 0x234d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2352:
	/* 0x2352: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2357:
	/* 0x2357: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_235c:
	/* 0x235c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_2361:
	/* 0x2361: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2365:
	/* 0x2365: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_236a:
	/* 0x236a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_236c:
	/* 0x236c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_236e:
	/* 0x236e: jmp    1cd3 <perf_unwind_dotnet+0x1cd3> */
	X86_SIM_X86_JMP(0x236e, 0x1cd3, x86_l_1cd3);
x86_l_2373:
	/* 0x2373: shr    r15d,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_2377:
	/* 0x2377: add    r13,0xffffffffffffff20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_237e:
	/* 0x237e: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_2381:
	/* 0x2381: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2384:
	/* 0x2384: lea    r15d,[rcx*4-0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 18446744073709551612ULL);
x86_l_238c:
	/* 0x238c: add    r15,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_238f:
	/* 0x238f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_2396:
	/* 0x2396: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2399:
	/* 0x2399: jne    292e <perf_unwind_dotnet+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2399, 0x292e, x86_l_292e);
x86_l_239f:
	/* 0x239f: lea    rdx,[r15-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_23a3:
	/* 0x23a3: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_23a8:
	/* 0x23a8: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_23ad:
	/* 0x23ad: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_23b2:
	/* 0x23b2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_23b7:
	/* 0x23b7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23b9:
	/* 0x23b9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_23bc:
	/* 0x23bc: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_23c3:
	/* 0x23c3: jne    b73 <perf_unwind_dotnet+0xb73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23c3, 0xb73, x86_l_b73);
x86_l_23c9:
	/* 0x23c9: mov    ebp,0x1f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 31ULL);
x86_l_23ce:
	/* 0x23ce: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_23d5:
	/* 0x23d5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23d8:
	/* 0x23d8: jne    254e <perf_unwind_dotnet+0x254e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23d8, 0x254e, x86_l_254e);
x86_l_23de:
	/* 0x23de: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_23e5:
	/* 0x23e5: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_23e9:
	/* 0x23e9: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x23e9, 0xbc9, x86_l_bc9);
x86_l_23ef:
	/* 0x23ef: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_23f4:
	/* 0x23f4: sub    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_23f7:
	/* 0x23f7: shl    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_23fb:
	/* 0x23fb: add    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_23fe:
	/* 0x23fe: lea    edx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2401:
	/* 0x2401: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_2408:
	/* 0x2408: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_240c:
	/* 0x240c: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_2414:
	/* 0x2414: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_241c:
	/* 0x241c: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_2425:
	/* 0x2425: mov    BYTE PTR [r14+rax*8+0x2e1],bl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_242d:
	/* 0x242d: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_2439:
	/* 0x2439: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_2444:
	/* 0x2444: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_244c:
	/* 0x244c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_2453:
	/* 0x2453: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2458:
	/* 0x2458: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_245d:
	/* 0x245d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_245f:
	/* 0x245f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2462:
	/* 0x2462: je     2470 <perf_unwind_dotnet+0x2470> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2462, 0x2470, x86_l_2470);
x86_l_2464:
	/* 0x2464: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2467:
	/* 0x2467: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_246e:
	/* 0x246e: jmp    2481 <perf_unwind_dotnet+0x2481> */
	X86_SIM_X86_JMP(0x246e, 0x2481, x86_l_2481);
x86_l_2470:
	/* 0x2470: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_2477:
	/* 0x2477: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_247b:
	/* 0x247b: jne    2821 <perf_unwind_dotnet+0x2821> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x247b, 0x2821, x86_l_2821);
x86_l_2481:
	/* 0x2481: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2489:
	/* 0x2489: mov    r13,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248c:
	/* 0x248c: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248f:
	/* 0x248f: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_2492:
	/* 0x2492: je     252c <perf_unwind_dotnet+0x252c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2492, 0x252c, x86_l_252c);
x86_l_2498:
	/* 0x2498: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_249a:
	/* 0x249a: jne    25ad <perf_unwind_dotnet+0x25ad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x249a, 0x25ad, x86_l_25ad);
x86_l_24a0:
	/* 0x24a0: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_24aa:
	/* 0x24aa: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_24ad:
	/* 0x24ad: jbe    2645 <perf_unwind_dotnet+0x2645> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x24ad, 0x2645, x86_l_2645);
x86_l_24b3:
	/* 0x24b3: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_24b8:
	/* 0x24b8: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_24bf:
	/* 0x24bf: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24c3:
	/* 0x24c3: je     d66 <perf_unwind_dotnet+0xd66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c3, 0xd66, x86_l_d66);
x86_l_24c9:
	/* 0x24c9: movabs rax,0x7373657264646120 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8319104478668415264ULL);
x86_l_24d3:
	/* 0x24d3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24d8:
	/* 0x24d8: movabs rax,0x6c656e72656b2061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7810770566350839905ULL);
x86_l_24e2:
	/* 0x24e2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24e7:
	/* 0x24e7: movabs rax,0x20736920786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338328219715642656ULL);
x86_l_24f1:
	/* 0x24f1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24f6:
	/* 0x24f6: movabs rax,0x65756c6176204350 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310868735955321680ULL);
x86_l_2500:
	/* 0x2500: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2505:
	/* 0x2505: mov    WORD PTR [rsp+0x30],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430218ULL);
x86_l_250c:
	/* 0x250c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2511:
	/* 0x2511: mov    eax,0x22 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 34ULL);
x86_l_2516:
	/* 0x2516: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_251b:
	/* 0x251b: mov    esi,0x22 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 34ULL);
x86_l_2520:
	/* 0x2520: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_2523:
	/* 0x2523: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2525:
	/* 0x2525: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2527:
	/* 0x2527: jmp    d66 <perf_unwind_dotnet+0xd66> */
	X86_SIM_X86_JMP(0x2527, 0xd66, x86_l_d66);
x86_l_252c:
	/* 0x252c: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2531:
	/* 0x2531: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2533:
	/* 0x2533: jne    8809 <perf_unwind_dotnet+0x8809> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2533, 0x8809, x86_l_8809);
x86_l_2539:
	/* 0x2539: mov    DWORD PTR [r14+0xf28],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108481ULL);
x86_l_2544:
	/* 0x2544: mov    eax,0xfad */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4013ULL);
x86_l_2549:
	/* 0x2549: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0x2549, 0x7712, x86_l_7712);
x86_l_254e:
	/* 0x254e: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_2555:
	/* 0x2555: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_255a:
	/* 0x255a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_255f:
	/* 0x255f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2562:
	/* 0x2562: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_2565:
	/* 0x2565: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_256a:
	/* 0x256a: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_2571:
	/* 0x2571: mov    ecx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 67ULL);
x86_l_2576:
	/* 0x2576: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_257c:
	/* 0x257c: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2581:
	/* 0x2581: mov    r8,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_64);
x86_l_2584:
	/* 0x2584: sub    r8,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_2587:
	/* 0x2587: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_258a:
	/* 0x258a: mov    esi,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 67ULL);
x86_l_258f:
	/* 0x258f: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2592:
	/* 0x2592: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2594:
	/* 0x2594: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2597:
	/* 0x2597: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_259e:
	/* 0x259e: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_25a2:
	/* 0x25a2: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x25a2, 0xbc9, x86_l_bc9);
x86_l_25a8:
	/* 0x25a8: jmp    23ef <perf_unwind_dotnet+0x23ef> */
	X86_SIM_X86_JMP(0x25a8, 0x23ef, x86_l_23ef);
x86_l_25ad:
	/* 0x25ad: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 737813247186461733ULL);
x86_l_25b7:
	/* 0x25b7: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_25bc:
	/* 0x25bc: movabs rax,0x20656d617266203a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021050ULL);
x86_l_25c6:
	/* 0x25c6: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25cb:
	/* 0x25cb: movabs rax,0x7265646e69776e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243105118350175861ULL);
x86_l_25d5:
	/* 0x25d5: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_25da:
	/* 0x25da: movabs rax,0x20656d6172662074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021108ULL);
x86_l_25e4:
	/* 0x25e4: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25e9:
	/* 0x25e9: movabs rax,0x78656e2065766c6f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8675461342619397231ULL);
x86_l_25f3:
	/* 0x25f3: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25f8:
	/* 0x25f8: movabs rax,0x736552203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315142585429343549ULL);
x86_l_2602:
	/* 0x2602: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2607:
	/* 0x2607: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_260c:
	/* 0x260c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2611:
	/* 0x2611: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_2616:
	/* 0x2616: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_261b:
	/* 0x261b: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_2622:
	/* 0x2622: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_2627:
	/* 0x2627: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2629:
	/* 0x2629: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_262b:
	/* 0x262b: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2632:
	/* 0x2632: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_263c:
	/* 0x263c: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_263f:
	/* 0x263f: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x263f, 0x24b3, x86_l_24b3);
x86_l_2645:
	/* 0x2645: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_264c:
	/* 0x264c: jae    26c0 <perf_unwind_dotnet+0x26c0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x264c, 0x26c0, x86_l_26c0);
x86_l_264e:
	/* 0x264e: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2653:
	/* 0x2653: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_265a:
	/* 0x265a: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_265e:
	/* 0x265e: je     e88 <perf_unwind_dotnet+0xe88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x265e, 0xe88, x86_l_e88);
x86_l_2664:
	/* 0x2664: movabs rax,0xa676e69726f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2928473680277358ULL);
x86_l_266e:
	/* 0x266e: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_2673:
	/* 0x2673: movabs rax,0x6f6e6769202c786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8029468886857185388ULL);
x86_l_267d:
	/* 0x267d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2682:
	/* 0x2682: movabs rax,0x252065756c617620 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675249733661980192ULL);
x86_l_268c:
	/* 0x268c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2691:
	/* 0x2691: movabs rax,0x6370206c6c616d73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165262657193340275ULL);
x86_l_269b:
	/* 0x269b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26a0:
	/* 0x26a0: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26a5:
	/* 0x26a5: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_26aa:
	/* 0x26aa: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_26af:
	/* 0x26af: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_26b4:
	/* 0x26b4: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_26b7:
	/* 0x26b7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_26b9:
	/* 0x26b9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26bb:
	/* 0x26bb: jmp    e88 <perf_unwind_dotnet+0xe88> */
	X86_SIM_X86_JMP(0x26bb, 0xe88, x86_l_e88);
x86_l_26c0:
	/* 0x26c0: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c3:
	/* 0x26c3: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_26cb:
	/* 0x26cb: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_26d1:
	/* 0x26d1: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_26d8:
	/* 0x26d8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&pid_page_to_mapping_info));
x86_l_26df:
	/* 0x26df: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_26e4:
	/* 0x26e4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_26e9:
	/* 0x26e9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26eb:
	/* 0x26eb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_26ee:
	/* 0x26ee: je     8740 <perf_unwind_dotnet+0x8740> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26ee, 0x8740, x86_l_8740);
x86_l_26f4:
	/* 0x26f4: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26f8:
	/* 0x26f8: mov    rcx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_64);
x86_l_26fb:
	/* 0x26fb: movabs rdx,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_2705:
	/* 0x2705: and    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND);
x86_l_2708:
	/* 0x2708: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_270f:
	/* 0x270f: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2712:
	/* 0x2712: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_2719:
	/* 0x2719: shr    r12,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_271d:
	/* 0x271d: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_2720:
	/* 0x2720: sub    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_2723:
	/* 0x2723: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_272a:
	/* 0x272a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_2731:
	/* 0x2731: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2734:
	/* 0x2734: jne    2a28 <perf_unwind_dotnet+0x2a28> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2734, 0x2a28, x86_l_2a28);
x86_l_273a:
	/* 0x273a: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_273e:
	/* 0x273e: jne    3311 <perf_unwind_dotnet+0x3311> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x273e, 0x3311, x86_l_3311);
x86_l_2744:
	/* 0x2744: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_274b:
	/* 0x274b: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2750:
	/* 0x2750: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_2757:
	/* 0x2757: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&interpreter_offsets));
x86_l_275e:
	/* 0x275e: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2763:
	/* 0x2763: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2768:
	/* 0x2768: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_276a:
	/* 0x276a: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_2770:
	/* 0x2770: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2773:
	/* 0x2773: je     3311 <perf_unwind_dotnet+0x3311> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2773, 0x3311, x86_l_3311);
x86_l_2779:
	/* 0x2779: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_277c:
	/* 0x277c: cmp    QWORD PTR [rax],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277f:
	/* 0x277f: ja     2787 <perf_unwind_dotnet+0x2787> */
	X86_SIM_X86_JCC(X86_CC_A, 0x277f, 0x2787, x86_l_2787);
x86_l_2781:
	/* 0x2781: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2785:
	/* 0x2785: jae    279b <perf_unwind_dotnet+0x279b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2785, 0x279b, x86_l_279b);
x86_l_2787:
	/* 0x2787: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_278b:
	/* 0x278b: ja     3311 <perf_unwind_dotnet+0x3311> */
	X86_SIM_X86_JCC(X86_CC_A, 0x278b, 0x3311, x86_l_3311);
x86_l_2791:
	/* 0x2791: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2795:
	/* 0x2795: jb     3311 <perf_unwind_dotnet+0x3311> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2795, 0x3311, x86_l_3311);
x86_l_279b:
	/* 0x279b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_27a2:
	/* 0x27a2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27a5:
	/* 0x27a5: jne    326a <perf_unwind_dotnet+0x326a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27a5, 0x326a, x86_l_326a);
x86_l_27ab:
	/* 0x27ab: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_27b2:
	/* 0x27b2: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_27b6:
	/* 0x27b6: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_27b9:
	/* 0x27b9: jae    32d7 <perf_unwind_dotnet+0x32d7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x27b9, 0x32d7, x86_l_32d7);
x86_l_27bf:
	/* 0x27bf: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_27c6:
	/* 0x27c6: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c9:
	/* 0x27c9: je     3311 <perf_unwind_dotnet+0x3311> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c9, 0x3311, x86_l_3311);
x86_l_27cf:
	/* 0x27cf: movabs rax,0x6e6f64207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7957689157107934318ULL);
x86_l_27d9:
	/* 0x27d9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_27de:
	/* 0x27de: movabs rax,0x69776e7520726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345545598324ULL);
x86_l_27e8:
	/* 0x27e8: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_27ed:
	/* 0x27ed: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_27f7:
	/* 0x27f7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27fc:
	/* 0x27fc: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_2804:
	/* 0x2804: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2809:
	/* 0x2809: mov    eax,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_280e:
	/* 0x280e: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_2813:
	/* 0x2813: mov    esi,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 27ULL);
x86_l_2818:
	/* 0x2818: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_281a:
	/* 0x281a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_281c:
	/* 0x281c: jmp    3311 <perf_unwind_dotnet+0x3311> */
	X86_SIM_X86_JMP(0x281c, 0x3311, x86_l_3311);
x86_l_2821:
	/* 0x2821: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_282b:
	/* 0x282b: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2830:
	/* 0x2830: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_283a:
	/* 0x283a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_283f:
	/* 0x283f: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_2849:
	/* 0x2849: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_284e:
	/* 0x284e: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_2858:
	/* 0x2858: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_285d:
	/* 0x285d: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_2867:
	/* 0x2867: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_286c:
	/* 0x286c: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_2876:
	/* 0x2876: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_287b:
	/* 0x287b: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2880:
	/* 0x2880: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_2885:
	/* 0x2885: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_288a:
	/* 0x288a: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_288e:
	/* 0x288e: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_2893:
	/* 0x2893: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2895:
	/* 0x2895: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2897:
	/* 0x2897: jmp    2481 <perf_unwind_dotnet+0x2481> */
	X86_SIM_X86_JMP(0x2897, 0x2481, x86_l_2481);
x86_l_289c:
	/* 0x289c: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_289f:
	/* 0x289f: and    rdx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_28a3:
	/* 0x28a3: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_28ad:
	/* 0x28ad: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_28b2:
	/* 0x28b2: movabs rax,0x72746e6520747372 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8247338198237475698ULL);
x86_l_28bc:
	/* 0x28bc: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_28c1:
	/* 0x28c1: movabs rax,0x6966203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7594793257107465504ULL);
x86_l_28cb:
	/* 0x28cb: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_28d0:
	/* 0x28d0: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_28da:
	/* 0x28da: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_28df:
	/* 0x28df: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_28e9:
	/* 0x28e9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28ee:
	/* 0x28ee: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_28f8:
	/* 0x28f8: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28fd:
	/* 0x28fd: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_2907:
	/* 0x2907: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_290c:
	/* 0x290c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2911:
	/* 0x2911: mov    eax,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 54ULL);
x86_l_2916:
	/* 0x2916: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_291c:
	/* 0x291c: mov    esi,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 54ULL);
x86_l_2921:
	/* 0x2921: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_2924:
	/* 0x2924: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2926:
	/* 0x2926: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2929:
	/* 0x2929: jmp    1ec4 <perf_unwind_dotnet+0x1ec4> */
	X86_SIM_X86_JMP(0x2929, 0x1ec4, x86_l_1ec4);
x86_l_292e:
	/* 0x292e: movabs rax,0xa786c253d7465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155643692133ULL);
x86_l_2938:
	/* 0x2938: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_293d:
	/* 0x293d: movabs rax,0x746572202c78253d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8387235363558008125ULL);
x86_l_2947:
	/* 0x2947: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_294c:
	/* 0x294c: movabs rax,0x6c6176202c786c25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809653109394271269ULL);
x86_l_2956:
	/* 0x2956: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_295b:
	/* 0x295b: movabs rax,0x203d2061746c6564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2323048585730221412ULL);
x86_l_2965:
	/* 0x2965: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_296a:
	/* 0x296a: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460740081921312ULL);
x86_l_2974:
	/* 0x2974: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2979:
	/* 0x2979: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_2983:
	/* 0x2983: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2988:
	/* 0x2988: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_298d:
	/* 0x298d: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_2992:
	/* 0x2992: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_2998:
	/* 0x2998: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_299d:
	/* 0x299d: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_29a0:
	/* 0x29a0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_29a3:
	/* 0x29a3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_29a5:
	/* 0x29a5: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29a8:
	/* 0x29a8: jmp    239f <perf_unwind_dotnet+0x239f> */
	X86_SIM_X86_JMP(0x29a8, 0x239f, x86_l_239f);
x86_l_29ad:
	/* 0x29ad: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_29b7:
	/* 0x29b7: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_29bc:
	/* 0x29bc: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_29c6:
	/* 0x29c6: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29cb:
	/* 0x29cb: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_29d5:
	/* 0x29d5: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_29da:
	/* 0x29da: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_29e4:
	/* 0x29e4: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29e9:
	/* 0x29e9: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_29f3:
	/* 0x29f3: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_29f8:
	/* 0x29f8: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_2a02:
	/* 0x2a02: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a07:
	/* 0x2a07: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a0c:
	/* 0x2a0c: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_2a11:
	/* 0x2a11: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_2a16:
	/* 0x2a16: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2a1a:
	/* 0x2a1a: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_2a1f:
	/* 0x2a1f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2a21:
	/* 0x2a21: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a23:
	/* 0x2a23: jmp    1f14 <perf_unwind_dotnet+0x1f14> */
	X86_SIM_X86_JMP(0x2a23, 0x1f14, x86_l_1f14);
x86_l_2a28:
	/* 0x2a28: movabs rax,0x296425207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2982549674514539630ULL);
x86_l_2a32:
	/* 0x2a32: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a37:
	/* 0x2a37: movabs rax,0x69776e752820786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345674446956ULL);
x86_l_2a41:
	/* 0x2a41: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a46:
	/* 0x2a46: movabs rax,0x6c2520736920786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670410291574892ULL);
x86_l_2a50:
	/* 0x2a50: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2a55:
	/* 0x2a55: movabs rax,0x2520435020726f66 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675212190078889830ULL);
x86_l_2a5f:
	/* 0x2a5f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a64:
	/* 0x2a64: movabs rax,0x206469206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334106094897424756ULL);
x86_l_2a6e:
	/* 0x2a6e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2a73:
	/* 0x2a73: movabs rbx,0x6365732074786554 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 7162257365632836948ULL);
x86_l_2a7d:
	/* 0x2a7d: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a82:
	/* 0x2a82: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_2a89:
	/* 0x2a89: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a8e:
	/* 0x2a8e: mov    eax,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_2a93:
	/* 0x2a93: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_2a99:
	/* 0x2a99: mov    rcx,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_2aa0:
	/* 0x2aa0: mov    esi,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 50ULL);
x86_l_2aa5:
	/* 0x2aa5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_2aa8:
	/* 0x2aa8: mov    r8d,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_32);
x86_l_2aab:
	/* 0x2aab: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2aad:
	/* 0x2aad: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ab0:
	/* 0x2ab0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_2ab7:
	/* 0x2ab7: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aba:
	/* 0x2aba: je     273a <perf_unwind_dotnet+0x273a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aba, 0x273a, x86_l_273a);
x86_l_2ac0:
	/* 0x2ac0: movabs rax,0xa786c6c252073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947156833280115ULL);
x86_l_2aca:
	/* 0x2aca: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_2acf:
	/* 0x2acf: movabs rax,0x7369207465736666 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8316213871206688358ULL);
x86_l_2ad9:
	/* 0x2ad9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ade:
	/* 0x2ade: movabs rax,0x6f20646e61202c78 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8007510562703420536ULL);
x86_l_2ae8:
	/* 0x2ae8: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2aed:
	/* 0x2aed: movabs rax,0x6c6c252073692073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7812660274886418547ULL);
x86_l_2af7:
	/* 0x2af7: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2afc:
	/* 0x2afc: movabs rax,0x616962206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7019249385664899444ULL);
x86_l_2b06:
	/* 0x2b06: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b0b:
	/* 0x2b0b: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b10:
	/* 0x2b10: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b15:
	/* 0x2b15: mov    eax,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 47ULL);
x86_l_2b1a:
	/* 0x2b1a: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_2b20:
	/* 0x2b20: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_2b27:
	/* 0x2b27: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_2b2e:
	/* 0x2b2e: mov    esi,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 47ULL);
x86_l_2b33:
	/* 0x2b33: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2b35:
	/* 0x2b35: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b38:
	/* 0x2b38: jmp    273a <perf_unwind_dotnet+0x273a> */
	X86_SIM_X86_JMP(0x2b38, 0x273a, x86_l_273a);
x86_l_2b3d:
	/* 0x2b3d: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_2b47:
	/* 0x2b47: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_2b4c:
	/* 0x2b4c: movabs rax,0x746e6520646e6f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8389754345636130659ULL);
x86_l_2b56:
	/* 0x2b56: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b5b:
	/* 0x2b5b: movabs rax,0x6573203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310222055652992288ULL);
x86_l_2b65:
	/* 0x2b65: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b6a:
	/* 0x2b6a: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_2b74:
	/* 0x2b74: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b79:
	/* 0x2b79: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_2b83:
	/* 0x2b83: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b88:
	/* 0x2b88: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_2b92:
	/* 0x2b92: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b97:
	/* 0x2b97: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_2ba1:
	/* 0x2ba1: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ba6:
	/* 0x2ba6: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bab:
	/* 0x2bab: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_2bb0:
	/* 0x2bb0: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_2bb6:
	/* 0x2bb6: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_2bbb:
	/* 0x2bbb: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_2bbe:
	/* 0x2bbe: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_2bc1:
	/* 0x2bc1: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2bc3:
	/* 0x2bc3: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2bc6:
	/* 0x2bc6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2bc8:
	/* 0x2bc8: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_2bcb:
	/* 0x2bcb: jne    1fce <perf_unwind_dotnet+0x1fce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bcb, 0x1fce, x86_l_1fce);
x86_l_2bd1:
	/* 0x2bd1: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_2bd8:
	/* 0x2bd8: mov    ecx,0xffffff84 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967172ULL);
x86_l_2bdd:
	/* 0x2bdd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2be0:
	/* 0x2be0: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2be0, 0x30d8, x86_l_30d8);
x86_l_2be6:
	/* 0x2be6: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_2bed:
	/* 0x2bed: mov    ecx,0xffffff86 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967174ULL);
x86_l_2bf2:
	/* 0x2bf2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2bf5:
	/* 0x2bf5: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bf5, 0x30d8, x86_l_30d8);
x86_l_2bfb:
	/* 0x2bfb: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_2c02:
	/* 0x2c02: mov    ecx,0xffffff88 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967176ULL);
x86_l_2c07:
	/* 0x2c07: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c0a:
	/* 0x2c0a: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c0a, 0x30d8, x86_l_30d8);
x86_l_2c10:
	/* 0x2c10: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_2c17:
	/* 0x2c17: mov    ecx,0xffffff8a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967178ULL);
x86_l_2c1c:
	/* 0x2c1c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c1f:
	/* 0x2c1f: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c1f, 0x30d8, x86_l_30d8);
x86_l_2c25:
	/* 0x2c25: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_2c2c:
	/* 0x2c2c: mov    ecx,0xffffff8c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967180ULL);
x86_l_2c31:
	/* 0x2c31: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c34:
	/* 0x2c34: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c34, 0x30d8, x86_l_30d8);
x86_l_2c3a:
	/* 0x2c3a: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_2c41:
	/* 0x2c41: mov    ecx,0xffffff8e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967182ULL);
x86_l_2c46:
	/* 0x2c46: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c49:
	/* 0x2c49: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c49, 0x30d8, x86_l_30d8);
x86_l_2c4f:
	/* 0x2c4f: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_2c56:
	/* 0x2c56: mov    ecx,0xffffff90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967184ULL);
x86_l_2c5b:
	/* 0x2c5b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c5e:
	/* 0x2c5e: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c5e, 0x30d8, x86_l_30d8);
x86_l_2c64:
	/* 0x2c64: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_2c6b:
	/* 0x2c6b: mov    ecx,0xffffff92 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967186ULL);
x86_l_2c70:
	/* 0x2c70: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c73:
	/* 0x2c73: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c73, 0x30d8, x86_l_30d8);
x86_l_2c79:
	/* 0x2c79: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_2c80:
	/* 0x2c80: mov    ecx,0xffffff94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967188ULL);
x86_l_2c85:
	/* 0x2c85: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c88:
	/* 0x2c88: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c88, 0x30d8, x86_l_30d8);
x86_l_2c8e:
	/* 0x2c8e: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_2c95:
	/* 0x2c95: mov    ecx,0xffffff96 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967190ULL);
x86_l_2c9a:
	/* 0x2c9a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2c9d:
	/* 0x2c9d: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c9d, 0x30d8, x86_l_30d8);
x86_l_2ca3:
	/* 0x2ca3: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_2caa:
	/* 0x2caa: mov    ecx,0xffffff98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967192ULL);
x86_l_2caf:
	/* 0x2caf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2cb2:
	/* 0x2cb2: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cb2, 0x30d8, x86_l_30d8);
x86_l_2cb8:
	/* 0x2cb8: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_2cbf:
	/* 0x2cbf: mov    ecx,0xffffff9a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967194ULL);
x86_l_2cc4:
	/* 0x2cc4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2cc7:
	/* 0x2cc7: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cc7, 0x30d8, x86_l_30d8);
x86_l_2ccd:
	/* 0x2ccd: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_2cd4:
	/* 0x2cd4: mov    ecx,0xffffff9c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967196ULL);
x86_l_2cd9:
	/* 0x2cd9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2cdc:
	/* 0x2cdc: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cdc, 0x30d8, x86_l_30d8);
x86_l_2ce2:
	/* 0x2ce2: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_2ce9:
	/* 0x2ce9: mov    ecx,0xffffff9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967198ULL);
x86_l_2cee:
	/* 0x2cee: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2cf1:
	/* 0x2cf1: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cf1, 0x30d8, x86_l_30d8);
x86_l_2cf7:
	/* 0x2cf7: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_2cfe:
	/* 0x2cfe: mov    ecx,0xffffffa0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967200ULL);
x86_l_2d03:
	/* 0x2d03: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d06:
	/* 0x2d06: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d06, 0x30d8, x86_l_30d8);
x86_l_2d0c:
	/* 0x2d0c: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_2d13:
	/* 0x2d13: mov    ecx,0xffffffa2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967202ULL);
x86_l_2d18:
	/* 0x2d18: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d1b:
	/* 0x2d1b: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d1b, 0x30d8, x86_l_30d8);
x86_l_2d21:
	/* 0x2d21: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_2d28:
	/* 0x2d28: mov    ecx,0xffffffa4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967204ULL);
x86_l_2d2d:
	/* 0x2d2d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d30:
	/* 0x2d30: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d30, 0x30d8, x86_l_30d8);
x86_l_2d36:
	/* 0x2d36: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_2d3d:
	/* 0x2d3d: mov    ecx,0xffffffa6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967206ULL);
x86_l_2d42:
	/* 0x2d42: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d45:
	/* 0x2d45: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d45, 0x30d8, x86_l_30d8);
x86_l_2d4b:
	/* 0x2d4b: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_2d52:
	/* 0x2d52: mov    ecx,0xffffffa8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967208ULL);
x86_l_2d57:
	/* 0x2d57: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d5a:
	/* 0x2d5a: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d5a, 0x30d8, x86_l_30d8);
x86_l_2d60:
	/* 0x2d60: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_2d67:
	/* 0x2d67: mov    ecx,0xffffffaa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967210ULL);
x86_l_2d6c:
	/* 0x2d6c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d6f:
	/* 0x2d6f: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d6f, 0x30d8, x86_l_30d8);
x86_l_2d75:
	/* 0x2d75: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_2d7c:
	/* 0x2d7c: mov    ecx,0xffffffac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967212ULL);
x86_l_2d81:
	/* 0x2d81: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d84:
	/* 0x2d84: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d84, 0x30d8, x86_l_30d8);
x86_l_2d8a:
	/* 0x2d8a: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_2d91:
	/* 0x2d91: mov    ecx,0xffffffae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967214ULL);
x86_l_2d96:
	/* 0x2d96: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d99:
	/* 0x2d99: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d99, 0x30d8, x86_l_30d8);
x86_l_2d9f:
	/* 0x2d9f: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_2da6:
	/* 0x2da6: mov    ecx,0xffffffb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967216ULL);
x86_l_2dab:
	/* 0x2dab: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2dae:
	/* 0x2dae: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dae, 0x30d8, x86_l_30d8);
x86_l_2db4:
	/* 0x2db4: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_2dbb:
	/* 0x2dbb: mov    ecx,0xffffffb2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967218ULL);
x86_l_2dc0:
	/* 0x2dc0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2dc3:
	/* 0x2dc3: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dc3, 0x30d8, x86_l_30d8);
x86_l_2dc9:
	/* 0x2dc9: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_2dd0:
	/* 0x2dd0: mov    ecx,0xffffffb4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967220ULL);
x86_l_2dd5:
	/* 0x2dd5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2dd8:
	/* 0x2dd8: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dd8, 0x30d8, x86_l_30d8);
x86_l_2dde:
	/* 0x2dde: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_2de5:
	/* 0x2de5: mov    ecx,0xffffffb6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967222ULL);
x86_l_2dea:
	/* 0x2dea: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2ded:
	/* 0x2ded: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ded, 0x30d8, x86_l_30d8);
x86_l_2df3:
	/* 0x2df3: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_2dfa:
	/* 0x2dfa: mov    ecx,0xffffffb8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967224ULL);
x86_l_2dff:
	/* 0x2dff: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e02:
	/* 0x2e02: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e02, 0x30d8, x86_l_30d8);
x86_l_2e08:
	/* 0x2e08: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_2e0f:
	/* 0x2e0f: mov    ecx,0xffffffba */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967226ULL);
x86_l_2e14:
	/* 0x2e14: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e17:
	/* 0x2e17: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e17, 0x30d8, x86_l_30d8);
x86_l_2e1d:
	/* 0x2e1d: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_2e24:
	/* 0x2e24: mov    ecx,0xffffffbc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967228ULL);
x86_l_2e29:
	/* 0x2e29: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e2c:
	/* 0x2e2c: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e2c, 0x30d8, x86_l_30d8);
x86_l_2e32:
	/* 0x2e32: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_2e39:
	/* 0x2e39: mov    ecx,0xffffffbe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967230ULL);
x86_l_2e3e:
	/* 0x2e3e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e41:
	/* 0x2e41: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e41, 0x30d8, x86_l_30d8);
x86_l_2e47:
	/* 0x2e47: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_2e4e:
	/* 0x2e4e: mov    ecx,0xffffffc0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967232ULL);
x86_l_2e53:
	/* 0x2e53: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e56:
	/* 0x2e56: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e56, 0x30d8, x86_l_30d8);
x86_l_2e5c:
	/* 0x2e5c: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_2e63:
	/* 0x2e63: mov    ecx,0xffffffc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967234ULL);
x86_l_2e68:
	/* 0x2e68: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e6b:
	/* 0x2e6b: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e6b, 0x30d8, x86_l_30d8);
x86_l_2e71:
	/* 0x2e71: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_2e78:
	/* 0x2e78: mov    ecx,0xffffffc4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967236ULL);
x86_l_2e7d:
	/* 0x2e7d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e80:
	/* 0x2e80: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e80, 0x30d8, x86_l_30d8);
x86_l_2e86:
	/* 0x2e86: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_2e8d:
	/* 0x2e8d: mov    ecx,0xffffffc6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967238ULL);
x86_l_2e92:
	/* 0x2e92: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2e95:
	/* 0x2e95: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e95, 0x30d8, x86_l_30d8);
x86_l_2e9b:
	/* 0x2e9b: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_2ea2:
	/* 0x2ea2: mov    ecx,0xffffffc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967240ULL);
x86_l_2ea7:
	/* 0x2ea7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2eaa:
	/* 0x2eaa: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2eaa, 0x30d8, x86_l_30d8);
x86_l_2eb0:
	/* 0x2eb0: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_2eb7:
	/* 0x2eb7: mov    ecx,0xffffffca */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967242ULL);
x86_l_2ebc:
	/* 0x2ebc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2ebf:
	/* 0x2ebf: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ebf, 0x30d8, x86_l_30d8);
x86_l_2ec5:
	/* 0x2ec5: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_2ecc:
	/* 0x2ecc: mov    ecx,0xffffffcc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967244ULL);
x86_l_2ed1:
	/* 0x2ed1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2ed4:
	/* 0x2ed4: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ed4, 0x30d8, x86_l_30d8);
x86_l_2eda:
	/* 0x2eda: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_2ee1:
	/* 0x2ee1: mov    ecx,0xffffffce */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967246ULL);
x86_l_2ee6:
	/* 0x2ee6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2ee9:
	/* 0x2ee9: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ee9, 0x30d8, x86_l_30d8);
x86_l_2eef:
	/* 0x2eef: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_2ef6:
	/* 0x2ef6: mov    ecx,0xffffffd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967248ULL);
x86_l_2efb:
	/* 0x2efb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2efe:
	/* 0x2efe: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2efe, 0x30d8, x86_l_30d8);
x86_l_2f04:
	/* 0x2f04: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_2f0b:
	/* 0x2f0b: mov    ecx,0xffffffd2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967250ULL);
x86_l_2f10:
	/* 0x2f10: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f13:
	/* 0x2f13: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f13, 0x30d8, x86_l_30d8);
x86_l_2f19:
	/* 0x2f19: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_2f20:
	/* 0x2f20: mov    ecx,0xffffffd4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967252ULL);
x86_l_2f25:
	/* 0x2f25: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f28:
	/* 0x2f28: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f28, 0x30d8, x86_l_30d8);
x86_l_2f2e:
	/* 0x2f2e: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_2f35:
	/* 0x2f35: mov    ecx,0xffffffd6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967254ULL);
x86_l_2f3a:
	/* 0x2f3a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f3d:
	/* 0x2f3d: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f3d, 0x30d8, x86_l_30d8);
x86_l_2f43:
	/* 0x2f43: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_2f4a:
	/* 0x2f4a: mov    ecx,0xffffffd8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967256ULL);
x86_l_2f4f:
	/* 0x2f4f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f52:
	/* 0x2f52: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f52, 0x30d8, x86_l_30d8);
x86_l_2f58:
	/* 0x2f58: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_2f5f:
	/* 0x2f5f: mov    ecx,0xffffffda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967258ULL);
x86_l_2f64:
	/* 0x2f64: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f67:
	/* 0x2f67: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f67, 0x30d8, x86_l_30d8);
x86_l_2f6d:
	/* 0x2f6d: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_2f74:
	/* 0x2f74: mov    ecx,0xffffffdc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967260ULL);
x86_l_2f79:
	/* 0x2f79: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f7c:
	/* 0x2f7c: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f7c, 0x30d8, x86_l_30d8);
x86_l_2f82:
	/* 0x2f82: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_2f89:
	/* 0x2f89: mov    ecx,0xffffffde */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967262ULL);
x86_l_2f8e:
	/* 0x2f8e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f91:
	/* 0x2f91: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f91, 0x30d8, x86_l_30d8);
x86_l_2f97:
	/* 0x2f97: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_2f9e:
	/* 0x2f9e: mov    ecx,0xffffffe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967264ULL);
x86_l_2fa3:
	/* 0x2fa3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2fa6:
	/* 0x2fa6: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fa6, 0x30d8, x86_l_30d8);
x86_l_2fac:
	/* 0x2fac: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_2fb3:
	/* 0x2fb3: mov    ecx,0xffffffe2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967266ULL);
x86_l_2fb8:
	/* 0x2fb8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2fbb:
	/* 0x2fbb: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fbb, 0x30d8, x86_l_30d8);
x86_l_2fc1:
	/* 0x2fc1: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_2fc8:
	/* 0x2fc8: mov    ecx,0xffffffe4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967268ULL);
x86_l_2fcd:
	/* 0x2fcd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2fd0:
	/* 0x2fd0: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fd0, 0x30d8, x86_l_30d8);
x86_l_2fd6:
	/* 0x2fd6: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_2fdd:
	/* 0x2fdd: mov    ecx,0xffffffe6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967270ULL);
x86_l_2fe2:
	/* 0x2fe2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2fe5:
	/* 0x2fe5: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fe5, 0x30d8, x86_l_30d8);
x86_l_2feb:
	/* 0x2feb: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_2ff2:
	/* 0x2ff2: mov    ecx,0xffffffe8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967272ULL);
x86_l_2ff7:
	/* 0x2ff7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2ffa:
	/* 0x2ffa: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ffa, 0x30d8, x86_l_30d8);
x86_l_3000:
	/* 0x3000: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_3007:
	/* 0x3007: mov    ecx,0xffffffea */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967274ULL);
x86_l_300c:
	/* 0x300c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_300f:
	/* 0x300f: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x300f, 0x30d8, x86_l_30d8);
x86_l_3015:
	/* 0x3015: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_301c:
	/* 0x301c: mov    ecx,0xffffffec */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967276ULL);
x86_l_3021:
	/* 0x3021: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3024:
	/* 0x3024: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3024, 0x30d8, x86_l_30d8);
x86_l_302a:
	/* 0x302a: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_3031:
	/* 0x3031: mov    ecx,0xffffffee */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967278ULL);
x86_l_3036:
	/* 0x3036: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3039:
	/* 0x3039: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3039, 0x30d8, x86_l_30d8);
x86_l_303f:
	/* 0x303f: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_3046:
	/* 0x3046: mov    ecx,0xfffffff0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967280ULL);
x86_l_304b:
	/* 0x304b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_304e:
	/* 0x304e: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x304e, 0x30d8, x86_l_30d8);
x86_l_3054:
	/* 0x3054: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_305b:
	/* 0x305b: mov    ecx,0xfffffff2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967282ULL);
x86_l_3060:
	/* 0x3060: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3063:
	/* 0x3063: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3063, 0x30d8, x86_l_30d8);
x86_l_3065:
	/* 0x3065: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_306c:
	/* 0x306c: mov    ecx,0xfffffff4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967284ULL);
x86_l_3071:
	/* 0x3071: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3074:
	/* 0x3074: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3074, 0x30d8, x86_l_30d8);
x86_l_3076:
	/* 0x3076: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_307d:
	/* 0x307d: mov    ecx,0xfffffff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967286ULL);
x86_l_3082:
	/* 0x3082: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3085:
	/* 0x3085: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3085, 0x30d8, x86_l_30d8);
x86_l_3087:
	/* 0x3087: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_308e:
	/* 0x308e: mov    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967288ULL);
x86_l_3093:
	/* 0x3093: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3096:
	/* 0x3096: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3096, 0x30d8, x86_l_30d8);
x86_l_3098:
	/* 0x3098: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_309f:
	/* 0x309f: mov    ecx,0xfffffffa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967290ULL);
x86_l_30a4:
	/* 0x30a4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_30a7:
	/* 0x30a7: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30a7, 0x30d8, x86_l_30d8);
x86_l_30a9:
	/* 0x30a9: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_30b0:
	/* 0x30b0: mov    ecx,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967292ULL);
x86_l_30b5:
	/* 0x30b5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_30b8:
	/* 0x30b8: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30b8, 0x30d8, x86_l_30d8);
x86_l_30ba:
	/* 0x30ba: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_30c1:
	/* 0x30c1: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_30c6:
	/* 0x30c6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_30c9:
	/* 0x30c9: jne    30d8 <perf_unwind_dotnet+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30c9, 0x30d8, x86_l_30d8);
x86_l_30cb:
	/* 0x30cb: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_30d3:
	/* 0x30d3: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30d6:
	/* 0x30d6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_30d8:
	/* 0x30d8: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_30da:
	/* 0x30da: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_30dd:
	/* 0x30dd: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_30e1:
	/* 0x30e1: setne  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_NE);
x86_l_30e4:
	/* 0x30e4: cmove  r15d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_30e8:
	/* 0x30e8: sub    ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_30ea:
	/* 0x30ea: add    ecx,0x7e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_30ed:
	/* 0x30ed: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_30ef:
	/* 0x30ef: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_30f2:
	/* 0x30f2: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_30f5:
	/* 0x30f5: jb     1fdc <perf_unwind_dotnet+0x1fdc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x30f5, 0x1fdc, x86_l_1fdc);
x86_l_30fb:
	/* 0x30fb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3102:
	/* 0x3102: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3105:
	/* 0x3105: jne    31cb <perf_unwind_dotnet+0x31cb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3105, 0x31cb, x86_l_31cb);
x86_l_310b:
	/* 0x310b: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_310e:
	/* 0x310e: jne    1ee0 <perf_unwind_dotnet+0x1ee0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x310e, 0x1ee0, x86_l_1ee0);
x86_l_3114:
	/* 0x3114: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_311c:
	/* 0x311c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_3123:
	/* 0x3123: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3128:
	/* 0x3128: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_312d:
	/* 0x312d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_312f:
	/* 0x312f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3132:
	/* 0x3132: je     3139 <perf_unwind_dotnet+0x3139> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3132, 0x3139, x86_l_3139);
x86_l_3134:
	/* 0x3134: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3137:
	/* 0x3137: jmp    3149 <perf_unwind_dotnet+0x3149> */
	X86_SIM_X86_JMP(0x3137, 0x3149, x86_l_3149);
x86_l_3139:
	/* 0x3139: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3140:
	/* 0x3140: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3143:
	/* 0x3143: jne    37ae <perf_unwind_dotnet+0x37ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3143, 0x37ae, x86_l_37ae);
x86_l_3149:
	/* 0x3149: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_314e:
	/* 0x314e: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_3153:
	/* 0x3153: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_315a:
	/* 0x315a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_315d:
	/* 0x315d: je     1f2b <perf_unwind_dotnet+0x1f2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x315d, 0x1f2b, x86_l_1f2b);
x86_l_3163:
	/* 0x3163: movabs rax,0xa642520687469 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387390569ULL);
x86_l_316d:
	/* 0x316d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3172:
	/* 0x3172: movabs rax,0x772064656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8583971276541485414ULL);
x86_l_317c:
	/* 0x317c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3181:
	/* 0x3181: movabs rax,0x2074726174735f65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338619869403242341ULL);
x86_l_318b:
	/* 0x318b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3190:
	/* 0x3190: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7237112116340927776ULL);
x86_l_319a:
	/* 0x319a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_319f:
	/* 0x319f: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_31a9:
	/* 0x31a9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31ae:
	/* 0x31ae: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31b3:
	/* 0x31b3: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_31b8:
	/* 0x31b8: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_31bd:
	/* 0x31bd: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_31c2:
	/* 0x31c2: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31c4:
	/* 0x31c4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31c6:
	/* 0x31c6: jmp    1f2b <perf_unwind_dotnet+0x1f2b> */
	X86_SIM_X86_JMP(0x31c6, 0x1f2b, x86_l_1f2b);
x86_l_31cb:
	/* 0x31cb: movabs rax,0x207972746e65202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2340027325789577260ULL);
x86_l_31d5:
	/* 0x31d5: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31da:
	/* 0x31da: movabs rax,0x6425206465707069 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7216209593501773929ULL);
x86_l_31e4:
	/* 0x31e4: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31e9:
	/* 0x31e9: movabs rax,0x6b73203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7742567619880559904ULL);
x86_l_31f3:
	/* 0x31f3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_31f8:
	/* 0x31f8: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_3202:
	/* 0x3202: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3207:
	/* 0x3207: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_3211:
	/* 0x3211: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3216:
	/* 0x3216: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_3220:
	/* 0x3220: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3225:
	/* 0x3225: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_322f:
	/* 0x322f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3234:
	/* 0x3234: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_323c:
	/* 0x323c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3241:
	/* 0x3241: mov    eax,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_3246:
	/* 0x3246: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_324c:
	/* 0x324c: mov    esi,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 60ULL);
x86_l_3251:
	/* 0x3251: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3254:
	/* 0x3254: mov    r8d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_32);
x86_l_3257:
	/* 0x3257: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3259:
	/* 0x3259: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_325c:
	/* 0x325c: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_325f:
	/* 0x325f: jne    1ee0 <perf_unwind_dotnet+0x1ee0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x325f, 0x1ee0, x86_l_1ee0);
x86_l_3265:
	/* 0x3265: jmp    3114 <perf_unwind_dotnet+0x3114> */
	X86_SIM_X86_JMP(0x3265, 0x3114, x86_l_3114);
x86_l_326a:
	/* 0x326a: movabs rax,0xa642520686374 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387386228ULL);
x86_l_3274:
	/* 0x3274: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_3279:
	/* 0x3279: movabs rax,0x6374616d20737465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7166460028377068645ULL);
x86_l_3283:
	/* 0x3283: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3288:
	/* 0x3288: movabs rax,0x7366666f5f726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315446390514935156ULL);
x86_l_3292:
	/* 0x3292: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3297:
	/* 0x3297: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_32a1:
	/* 0x32a1: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32a6:
	/* 0x32a6: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32ab:
	/* 0x32ab: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_32b0:
	/* 0x32b0: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_32b5:
	/* 0x32b5: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_32ba:
	/* 0x32ba: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_32bf:
	/* 0x32bf: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_32c1:
	/* 0x32c1: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_32c3:
	/* 0x32c3: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_32ca:
	/* 0x32ca: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_32ce:
	/* 0x32ce: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_32d1:
	/* 0x32d1: jb     27bf <perf_unwind_dotnet+0x27bf> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32d1, 0x27bf, x86_l_27bf);
x86_l_32d7:
	/* 0x32d7: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_32df:
	/* 0x32df: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_32e6:
	/* 0x32e6: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_32eb:
	/* 0x32eb: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_32f0:
	/* 0x32f0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_32f2:
	/* 0x32f2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_32f5:
	/* 0x32f5: je     32fc <perf_unwind_dotnet+0x32fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f5, 0x32fc, x86_l_32fc);
x86_l_32f7:
	/* 0x32f7: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_32fa:
	/* 0x32fa: jmp    330c <perf_unwind_dotnet+0x330c> */
	X86_SIM_X86_JMP(0x32fa, 0x330c, x86_l_330c);
x86_l_32fc:
	/* 0x32fc: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3303:
	/* 0x3303: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3306:
	/* 0x3306: jne    390d <perf_unwind_dotnet+0x390d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3306, 0x390d, x86_l_390d);
x86_l_330c:
	/* 0x330c: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_3311:
	/* 0x3311: cmp    r12d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 8ULL);
x86_l_3315:
	/* 0x3315: jne    8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3315, 0x8cac, x86_l_8cac);
x86_l_331b:
	/* 0x331b: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_3322:
	/* 0x3322: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_3329:
	/* 0x3329: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_3330:
	/* 0x3330: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_3338:
	/* 0x3338: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_333c:
	/* 0x333c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3343:
	/* 0x3343: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3346:
	/* 0x3346: jne    370a <perf_unwind_dotnet+0x370a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3346, 0x370a, x86_l_370a);
x86_l_334c:
	/* 0x334c: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_334f:
	/* 0x334f: jb     76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x334f, 0x76bb, x86_l_76bb);
x86_l_3355:
	/* 0x3355: lea    rax,[rbx+0x2000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_335c:
	/* 0x335c: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_335f:
	/* 0x335f: jae    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x335f, 0x76bb, x86_l_76bb);
x86_l_3365:
	/* 0x3365: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_336c:
	/* 0x336c: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_3373:
	/* 0x3373: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3378:
	/* 0x3378: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_3380:
	/* 0x3380: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_3383:
	/* 0x3383: and    rax,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_3387:
	/* 0x3387: cmp    rax,0x80 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_338d:
	/* 0x338d: jne    33d1 <perf_unwind_dotnet+0x33d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x338d, 0x33d1, x86_l_33d1);
x86_l_338f:
	/* 0x338f: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_3396:
	/* 0x3396: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_339b:
	/* 0x339b: mov    r8d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 112ULL);
x86_l_33a1:
	/* 0x33a1: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_33a9:
	/* 0x33a9: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_33b0:
	/* 0x33b0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_33b5:
	/* 0x33b5: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33b8:
	/* 0x33b8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_33bb:
	/* 0x33bb: jne    19c <perf_unwind_dotnet+0x19c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33bb, 0x19c, x86_l_19c);
x86_l_33c1:
	/* 0x33c1: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_33c9:
	/* 0x33c9: and    ebp,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_33cc:
	/* 0x33cc: jmp    39e3 <perf_unwind_dotnet+0x39e3> */
	X86_SIM_X86_JMP(0x33cc, 0x39e3, x86_l_39e3);
x86_l_33d1:
	/* 0x33d1: lea    rdi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_33d6:
	/* 0x33d6: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_33db:
	/* 0x33db: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_33e0:
	/* 0x33e0: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_33e5:
	/* 0x33e5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_33e8:
	/* 0x33e8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33ea:
	/* 0x33ea: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_33ed:
	/* 0x33ed: jne    26c <perf_unwind_dotnet+0x26c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33ed, 0x26c, x86_l_26c);
x86_l_33f3:
	/* 0x33f3: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_33f7:
	/* 0x33f7: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_33fe:
	/* 0x33fe: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3403:
	/* 0x3403: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_340a:
	/* 0x340a: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_340f:
	/* 0x340f: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_3416:
	/* 0x3416: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_341d:
	/* 0x341d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3420:
	/* 0x3420: jne    3829 <perf_unwind_dotnet+0x3829> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3420, 0x3829, x86_l_3829);
x86_l_3426:
	/* 0x3426: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_342d:
	/* 0x342d: jb     39e3 <perf_unwind_dotnet+0x39e3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x342d, 0x39e3, x86_l_39e3);
x86_l_3433:
	/* 0x3433: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_343a:
	/* 0x343a: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_3441:
	/* 0x3441: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_3444:
	/* 0x3444: sub    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3447:
	/* 0x3447: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_344e:
	/* 0x344e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3451:
	/* 0x3451: jne    38c9 <perf_unwind_dotnet+0x38c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3451, 0x38c9, x86_l_38c9);
x86_l_3457:
	/* 0x3457: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_345a:
	/* 0x345a: shr    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_345e:
	/* 0x345e: mov    ecx,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 127ULL);
x86_l_3463:
	/* 0x3463: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3465:
	/* 0x3465: and    ecx,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_3468:
	/* 0x3468: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_346a:
	/* 0x346a: cmp    r13,0x8000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 32768ULL);
x86_l_3471:
	/* 0x3471: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_3479:
	/* 0x3479: cmovb  rdx,rsi */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B);
x86_l_347d:
	/* 0x347d: cmovae ecx,esi */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE);
x86_l_3480:
	/* 0x3480: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3483:
	/* 0x3483: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_348b:
	/* 0x348b: lea    rdi,[rax+rcx*4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_348f:
	/* 0x348f: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
x86_l_3494:
	/* 0x3494: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_3499:
	/* 0x3499: mov    esi,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 512ULL);
x86_l_349e:
	/* 0x349e: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34a0:
	/* 0x34a0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_34a3:
	/* 0x34a3: je     34da <perf_unwind_dotnet+0x34da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34a3, 0x34da, x86_l_34da);
x86_l_34a5:
	/* 0x34a5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_34ac:
	/* 0x34ac: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34af:
	/* 0x34af: jne    369b <perf_unwind_dotnet+0x369b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34af, 0x369b, x86_l_369b);
x86_l_34b5:
	/* 0x34b5: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_34bd:
	/* 0x34bd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_34c4:
	/* 0x34c4: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_34c9:
	/* 0x34c9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_34ce:
	/* 0x34ce: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34d0:
	/* 0x34d0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_34d3:
	/* 0x34d3: je     3531 <perf_unwind_dotnet+0x3531> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34d3, 0x3531, x86_l_3531);
x86_l_34d5:
	/* 0x34d5: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_34d8:
	/* 0x34d8: jmp    3541 <perf_unwind_dotnet+0x3541> */
	X86_SIM_X86_JMP(0x34d8, 0x3541, x86_l_3541);
x86_l_34da:
	/* 0x34da: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_34e1:
	/* 0x34e1: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_34e8:
	/* 0x34e8: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34eb:
	/* 0x34eb: jne    3db0 <perf_unwind_dotnet+0x3db0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34eb, 0x3db0, x86_l_3db0);
x86_l_34f1:
	/* 0x34f1: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_34f4:
	/* 0x34f4: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_34f6:
	/* 0x34f6: shr    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_34f9:
	/* 0x34f9: and    al,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_34fb:
	/* 0x34fb: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_3500:
	/* 0x3500: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_3503:
	/* 0x3503: je     35ce <perf_unwind_dotnet+0x35ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3503, 0x35ce, x86_l_35ce);
x86_l_3509:
	/* 0x3509: and    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_350d:
	/* 0x350d: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_3510:
	/* 0x3510: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3513:
	/* 0x3513: jne    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3513, 0x3996, x86_l_3996);
x86_l_3519:
	/* 0x3519: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_351c:
	/* 0x351c: shr    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_351f:
	/* 0x351f: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3522:
	/* 0x3522: je     36de <perf_unwind_dotnet+0x36de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3522, 0x36de, x86_l_36de);
x86_l_3528:
	/* 0x3528: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_352c:
	/* 0x352c: jmp    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JMP(0x352c, 0x3996, x86_l_3996);
x86_l_3531:
	/* 0x3531: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3538:
	/* 0x3538: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_353b:
	/* 0x353b: jne    3ec1 <perf_unwind_dotnet+0x3ec1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x353b, 0x3ec1, x86_l_3ec1);
x86_l_3541:
	/* 0x3541: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_3546:
	/* 0x3546: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3548:
	/* 0x3548: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_354f:
	/* 0x354f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3552:
	/* 0x3552: jne    4677 <perf_unwind_dotnet+0x4677> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3552, 0x4677, x86_l_4677);
x86_l_3558:
	/* 0x3558: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_355d:
	/* 0x355d: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_355f:
	/* 0x355f: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3564:
	/* 0x3564: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_356b:
	/* 0x356b: je     7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x356b, 0x7712, x86_l_7712);
x86_l_3571:
	/* 0x3571: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3578:
	/* 0x3578: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_357c:
	/* 0x357c: ja     4f3 <perf_unwind_dotnet+0x4f3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x357c, 0x4f3, x86_l_4f3);
x86_l_3582:
	/* 0x3582: lea    ecx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3585:
	/* 0x3585: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_358c:
	/* 0x358c: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_3590:
	/* 0x3590: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_359c:
	/* 0x359c: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_35a8:
	/* 0x35a8: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_35b1:
	/* 0x35b1: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_35bd:
	/* 0x35bd: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_35c9:
	/* 0x35c9: jmp    3a93 <perf_unwind_dotnet+0x3a93> */
	X86_SIM_X86_JMP(0x35c9, 0x3a93, x86_l_3a93);
x86_l_35ce:
	/* 0x35ce: and    r13,0xffffffffffffff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_35d5:
	/* 0x35d5: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_35d9:
	/* 0x35d9: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_35e0:
	/* 0x35e0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_35e7:
	/* 0x35e7: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35ea:
	/* 0x35ea: jne    4051 <perf_unwind_dotnet+0x4051> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35ea, 0x4051, x86_l_4051);
x86_l_35f0:
	/* 0x35f0: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_35f2:
	/* 0x35f2: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_35f5:
	/* 0x35f5: je     40e5 <perf_unwind_dotnet+0x40e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35f5, 0x40e5, x86_l_40e5);
x86_l_35fb:
	/* 0x35fb: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_35fd:
	/* 0x35fd: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_3600:
	/* 0x3600: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3603:
	/* 0x3603: jae    460f <perf_unwind_dotnet+0x460f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3603, 0x460f, x86_l_460f);
x86_l_3609:
	/* 0x3609: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3610:
	/* 0x3610: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3613:
	/* 0x3613: je     34b5 <perf_unwind_dotnet+0x34b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3613, 0x34b5, x86_l_34b5);
x86_l_3619:
	/* 0x3619: movabs rax,0xa657361625f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2926295996587875ULL);
x86_l_3623:
	/* 0x3623: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3628:
	/* 0x3628: movabs rax,0x5f637020776f6c65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460741042564197ULL);
x86_l_3632:
	/* 0x3632: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3637:
	/* 0x3637: movabs rax,0x6220746e65772068 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7070779432469209192ULL);
x86_l_3641:
	/* 0x3641: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3646:
	/* 0x3646: movabs rax,0x6372616573207061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165897045450977377ULL);
x86_l_3650:
	/* 0x3650: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3655:
	/* 0x3655: movabs rax,0x6d20656c6262696e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7863396465570376046ULL);
x86_l_365f:
	/* 0x365f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3664:
	/* 0x3664: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_366e:
	/* 0x366e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3673:
	/* 0x3673: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3678:
	/* 0x3678: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_367d:
	/* 0x367d: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3682:
	/* 0x3682: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_3687:
	/* 0x3687: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3689:
	/* 0x3689: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_368b:
	/* 0x368b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3692:
	/* 0x3692: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3695:
	/* 0x3695: je     34b5 <perf_unwind_dotnet+0x34b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3695, 0x34b5, x86_l_34b5);
x86_l_369b:
	/* 0x369b: movabs rax,0x6e756f6620746f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959390400869068654ULL);
x86_l_36a5:
	/* 0x36a5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_36aa:
	/* 0x36aa: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_36b4:
	/* 0x36b4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_36b9:
	/* 0x36b9: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_36c1:
	/* 0x36c1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_36c6:
	/* 0x36c6: mov    eax,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_36cb:
	/* 0x36cb: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_36d0:
	/* 0x36d0: mov    esi,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 19ULL);
x86_l_36d5:
	/* 0x36d5: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_36d7:
	/* 0x36d7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36d9:
	/* 0x36d9: jmp    34b5 <perf_unwind_dotnet+0x34b5> */
	X86_SIM_X86_JMP(0x36d9, 0x34b5, x86_l_34b5);
x86_l_36de:
	/* 0x36de: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_36e1:
	/* 0x36e1: shr    ecx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_36e4:
	/* 0x36e4: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_36e7:
	/* 0x36e7: je     36f2 <perf_unwind_dotnet+0x36f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36e7, 0x36f2, x86_l_36f2);
x86_l_36e9:
	/* 0x36e9: add    r13,0xffffffffffffffc0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_36ed:
	/* 0x36ed: jmp    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JMP(0x36ed, 0x3996, x86_l_3996);
x86_l_36f2:
	/* 0x36f2: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_36f5:
	/* 0x36f5: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_36f8:
	/* 0x36f8: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_36fb:
	/* 0x36fb: je     377f <perf_unwind_dotnet+0x377f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36fb, 0x377f, x86_l_377f);
x86_l_3701:
	/* 0x3701: add    r13,0xffffffffffffffa0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_3705:
	/* 0x3705: jmp    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JMP(0x3705, 0x3996, x86_l_3996);
x86_l_370a:
	/* 0x370a: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_3714:
	/* 0x3714: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3719:
	/* 0x3719: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_3723:
	/* 0x3723: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3728:
	/* 0x3728: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_3732:
	/* 0x3732: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3737:
	/* 0x3737: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_3741:
	/* 0x3741: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3746:
	/* 0x3746: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_374e:
	/* 0x374e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3753:
	/* 0x3753: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_3758:
	/* 0x3758: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_375e:
	/* 0x375e: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_3763:
	/* 0x3763: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_3766:
	/* 0x3766: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_3769:
	/* 0x3769: mov    r8,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R13, X86_WIDTH_64);
x86_l_376c:
	/* 0x376c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_376e:
	/* 0x376e: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3771:
	/* 0x3771: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_3774:
	/* 0x3774: jae    3355 <perf_unwind_dotnet+0x3355> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3774, 0x3355, x86_l_3355);
x86_l_377a:
	/* 0x377a: jmp    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JMP(0x377a, 0x76bb, x86_l_76bb);
x86_l_377f:
	/* 0x377f: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_3782:
	/* 0x3782: shr    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_3785:
	/* 0x3785: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3788:
	/* 0x3788: je     3793 <perf_unwind_dotnet+0x3793> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3788, 0x3793, x86_l_3793);
x86_l_378a:
	/* 0x378a: add    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_378e:
	/* 0x378e: jmp    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JMP(0x378e, 0x3996, x86_l_3996);
x86_l_3793:
	/* 0x3793: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_3796:
	/* 0x3796: shr    ecx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_3799:
	/* 0x3799: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_379c:
	/* 0x379c: je     38ae <perf_unwind_dotnet+0x38ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x379c, 0x38ae, x86_l_38ae);
x86_l_37a2:
	/* 0x37a2: add    r13,0xffffffffffffff60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_37a9:
	/* 0x37a9: jmp    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JMP(0x37a9, 0x3996, x86_l_3996);
x86_l_37ae:
	/* 0x37ae: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_37b8:
	/* 0x37b8: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_37bd:
	/* 0x37bd: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_37c7:
	/* 0x37c7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_37cc:
	/* 0x37cc: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_37d6:
	/* 0x37d6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_37db:
	/* 0x37db: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_37e5:
	/* 0x37e5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_37ea:
	/* 0x37ea: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_37f4:
	/* 0x37f4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_37f9:
	/* 0x37f9: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_3803:
	/* 0x3803: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3808:
	/* 0x3808: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_380d:
	/* 0x380d: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_3812:
	/* 0x3812: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3817:
	/* 0x3817: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_381b:
	/* 0x381b: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_3820:
	/* 0x3820: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3822:
	/* 0x3822: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3824:
	/* 0x3824: jmp    3149 <perf_unwind_dotnet+0x3149> */
	X86_SIM_X86_JMP(0x3824, 0x3149, x86_l_3149);
x86_l_3829:
	/* 0x3829: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_3833:
	/* 0x3833: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3838:
	/* 0x3838: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_3842:
	/* 0x3842: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3847:
	/* 0x3847: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_3851:
	/* 0x3851: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3856:
	/* 0x3856: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_3860:
	/* 0x3860: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3865:
	/* 0x3865: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_386d:
	/* 0x386d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3872:
	/* 0x3872: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_3877:
	/* 0x3877: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_387d:
	/* 0x387d: mov    rdx,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_3884:
	/* 0x3884: mov    rcx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_388b:
	/* 0x388b: mov    r8,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_3892:
	/* 0x3892: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_3897:
	/* 0x3897: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3899:
	/* 0x3899: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_389c:
	/* 0x389c: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_38a3:
	/* 0x38a3: jae    3433 <perf_unwind_dotnet+0x3433> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x38a3, 0x3433, x86_l_3433);
x86_l_38a9:
	/* 0x38a9: jmp    39e3 <perf_unwind_dotnet+0x39e3> */
	X86_SIM_X86_JMP(0x38a9, 0x39e3, x86_l_39e3);
x86_l_38ae:
	/* 0x38ae: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_38b1:
	/* 0x38b1: shr    ecx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_38b4:
	/* 0x38b4: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_38b7:
	/* 0x38b7: je     3988 <perf_unwind_dotnet+0x3988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38b7, 0x3988, x86_l_3988);
x86_l_38bd:
	/* 0x38bd: add    r13,0xffffffffffffff40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_38c4:
	/* 0x38c4: jmp    3996 <perf_unwind_dotnet+0x3996> */
	X86_SIM_X86_JMP(0x38c4, 0x3996, x86_l_3996);
x86_l_38c9:
	/* 0x38c9: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_38d0:
	/* 0x38d0: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_38d5:
	/* 0x38d5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_38da:
	/* 0x38da: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_38dd:
	/* 0x38dd: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_38e0:
	/* 0x38e0: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_38e7:
	/* 0x38e7: mov    ecx,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 66ULL);
x86_l_38ec:
	/* 0x38ec: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_38f2:
	/* 0x38f2: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_38f5:
	/* 0x38f5: mov    esi,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 66ULL);
x86_l_38fa:
	/* 0x38fa: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_38fd:
	/* 0x38fd: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_3900:
	/* 0x3900: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_3903:
	/* 0x3903: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3905:
	/* 0x3905: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3908:
	/* 0x3908: jmp    3457 <perf_unwind_dotnet+0x3457> */
	X86_SIM_X86_JMP(0x3908, 0x3457, x86_l_3457);
x86_l_390d:
	/* 0x390d: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_3917:
	/* 0x3917: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_391c:
	/* 0x391c: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_3926:
	/* 0x3926: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_392b:
	/* 0x392b: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_3935:
	/* 0x3935: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_393a:
	/* 0x393a: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_3944:
	/* 0x3944: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3949:
	/* 0x3949: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_3953:
	/* 0x3953: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3958:
	/* 0x3958: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_3962:
	/* 0x3962: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3967:
	/* 0x3967: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_396c:
	/* 0x396c: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_3971:
	/* 0x3971: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3976:
	/* 0x3976: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_397a:
	/* 0x397a: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_397f:
	/* 0x397f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3981:
	/* 0x3981: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3983:
	/* 0x3983: jmp    330c <perf_unwind_dotnet+0x330c> */
	X86_SIM_X86_JMP(0x3983, 0x330c, x86_l_330c);
x86_l_3988:
	/* 0x3988: shr    r15d,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_398c:
	/* 0x398c: add    r13,0xffffffffffffff20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_3993:
	/* 0x3993: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_3996:
	/* 0x3996: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3999:
	/* 0x3999: lea    r15d,[rcx*4-0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 18446744073709551612ULL);
x86_l_39a1:
	/* 0x39a1: add    r15,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_39a4:
	/* 0x39a4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_39ab:
	/* 0x39ab: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39ae:
	/* 0x39ae: jne    3e42 <perf_unwind_dotnet+0x3e42> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39ae, 0x3e42, x86_l_3e42);
x86_l_39b4:
	/* 0x39b4: lea    rdx,[r15-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_39b8:
	/* 0x39b8: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_39bd:
	/* 0x39bd: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_39c2:
	/* 0x39c2: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_39c7:
	/* 0x39c7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_39cc:
	/* 0x39cc: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_39ce:
	/* 0x39ce: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_39d1:
	/* 0x39d1: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_39d8:
	/* 0x39d8: jne    b73 <perf_unwind_dotnet+0xb73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39d8, 0xb73, x86_l_b73);
x86_l_39de:
	/* 0x39de: mov    ebp,0x1f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 31ULL);
x86_l_39e3:
	/* 0x39e3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_39ea:
	/* 0x39ea: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39ed:
	/* 0x39ed: jne    3c39 <perf_unwind_dotnet+0x3c39> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39ed, 0x3c39, x86_l_3c39);
x86_l_39f3:
	/* 0x39f3: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_39fa:
	/* 0x39fa: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_39fe:
	/* 0x39fe: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x39fe, 0xbc9, x86_l_bc9);
x86_l_3a04:
	/* 0x3a04: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3a09:
	/* 0x3a09: sub    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3a0c:
	/* 0x3a0c: shl    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_3a10:
	/* 0x3a10: add    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3a13:
	/* 0x3a13: lea    edx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3a16:
	/* 0x3a16: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3a1d:
	/* 0x3a1d: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_3a21:
	/* 0x3a21: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_3a29:
	/* 0x3a29: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_3a31:
	/* 0x3a31: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_3a3a:
	/* 0x3a3a: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_3a3f:
	/* 0x3a3f: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_3a47:
	/* 0x3a47: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_3a53:
	/* 0x3a53: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_3a5e:
	/* 0x3a5e: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_3a66:
	/* 0x3a66: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_3a6d:
	/* 0x3a6d: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3a72:
	/* 0x3a72: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3a77:
	/* 0x3a77: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3a79:
	/* 0x3a79: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3a7c:
	/* 0x3a7c: je     3a83 <perf_unwind_dotnet+0x3a83> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a7c, 0x3a83, x86_l_3a83);
x86_l_3a7e:
	/* 0x3a7e: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3a81:
	/* 0x3a81: jmp    3a93 <perf_unwind_dotnet+0x3a93> */
	X86_SIM_X86_JMP(0x3a81, 0x3a93, x86_l_3a93);
x86_l_3a83:
	/* 0x3a83: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3a8a:
	/* 0x3a8a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a8d:
	/* 0x3a8d: jne    3d35 <perf_unwind_dotnet+0x3d35> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a8d, 0x3d35, x86_l_3d35);
x86_l_3a93:
	/* 0x3a93: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_3a9b:
	/* 0x3a9b: mov    r13,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a9e:
	/* 0x3a9e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3aa5:
	/* 0x3aa5: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3aa7:
	/* 0x3aa7: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_3aaa:
	/* 0x3aaa: je     87f5 <perf_unwind_dotnet+0x87f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3aaa, 0x87f5, x86_l_87f5);
x86_l_3ab0:
	/* 0x3ab0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3ab2:
	/* 0x3ab2: jne    3c98 <perf_unwind_dotnet+0x3c98> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ab2, 0x3c98, x86_l_3c98);
x86_l_3ab8:
	/* 0x3ab8: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_3ac2:
	/* 0x3ac2: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3ac5:
	/* 0x3ac5: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3ac5, 0x24b3, x86_l_24b3);
x86_l_3acb:
	/* 0x3acb: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_3ad2:
	/* 0x3ad2: jb     264e <perf_unwind_dotnet+0x264e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3ad2, 0x264e, x86_l_264e);
x86_l_3ad8:
	/* 0x3ad8: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3adb:
	/* 0x3adb: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_3ae3:
	/* 0x3ae3: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_3ae9:
	/* 0x3ae9: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_3af0:
	/* 0x3af0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&pid_page_to_mapping_info));
x86_l_3af7:
	/* 0x3af7: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3afc:
	/* 0x3afc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3b01:
	/* 0x3b01: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3b03:
	/* 0x3b03: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3b06:
	/* 0x3b06: je     8740 <perf_unwind_dotnet+0x8740> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b06, 0x8740, x86_l_8740);
x86_l_3b0c:
	/* 0x3b0c: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3b10:
	/* 0x3b10: mov    rcx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_64);
x86_l_3b13:
	/* 0x3b13: movabs rdx,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_3b1d:
	/* 0x3b1d: and    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND);
x86_l_3b20:
	/* 0x3b20: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_3b27:
	/* 0x3b27: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b2a:
	/* 0x3b2a: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3b31:
	/* 0x3b31: shr    r12,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_3b35:
	/* 0x3b35: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_3b38:
	/* 0x3b38: sub    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3b3b:
	/* 0x3b3b: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3b42:
	/* 0x3b42: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3b49:
	/* 0x3b49: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b4c:
	/* 0x3b4c: jne    3f3c <perf_unwind_dotnet+0x3f3c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b4c, 0x3f3c, x86_l_3f3c);
x86_l_3b52:
	/* 0x3b52: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_3b56:
	/* 0x3b56: jne    4825 <perf_unwind_dotnet+0x4825> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b56, 0x4825, x86_l_4825);
x86_l_3b5c:
	/* 0x3b5c: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3b63:
	/* 0x3b63: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3b68:
	/* 0x3b68: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3b6f:
	/* 0x3b6f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&interpreter_offsets));
x86_l_3b76:
	/* 0x3b76: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3b7b:
	/* 0x3b7b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3b80:
	/* 0x3b80: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3b82:
	/* 0x3b82: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_3b88:
	/* 0x3b88: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3b8b:
	/* 0x3b8b: je     4825 <perf_unwind_dotnet+0x4825> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b8b, 0x4825, x86_l_4825);
x86_l_3b91:
	/* 0x3b91: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_3b94:
	/* 0x3b94: cmp    QWORD PTR [rax],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b97:
	/* 0x3b97: ja     3b9f <perf_unwind_dotnet+0x3b9f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3b97, 0x3b9f, x86_l_3b9f);
x86_l_3b99:
	/* 0x3b99: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3b9d:
	/* 0x3b9d: jae    3bb3 <perf_unwind_dotnet+0x3bb3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3b9d, 0x3bb3, x86_l_3bb3);
x86_l_3b9f:
	/* 0x3b9f: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ba3:
	/* 0x3ba3: ja     4825 <perf_unwind_dotnet+0x4825> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3ba3, 0x4825, x86_l_4825);
x86_l_3ba9:
	/* 0x3ba9: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3bad:
	/* 0x3bad: jb     4825 <perf_unwind_dotnet+0x4825> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3bad, 0x4825, x86_l_4825);
x86_l_3bb3:
	/* 0x3bb3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3bba:
	/* 0x3bba: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bbd:
	/* 0x3bbd: jne    477e <perf_unwind_dotnet+0x477e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3bbd, 0x477e, x86_l_477e);
x86_l_3bc3:
	/* 0x3bc3: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_3bca:
	/* 0x3bca: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3bce:
	/* 0x3bce: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_3bd1:
	/* 0x3bd1: jae    47eb <perf_unwind_dotnet+0x47eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3bd1, 0x47eb, x86_l_47eb);
x86_l_3bd7:
	/* 0x3bd7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3bde:
	/* 0x3bde: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3be1:
	/* 0x3be1: je     4825 <perf_unwind_dotnet+0x4825> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3be1, 0x4825, x86_l_4825);
x86_l_3be7:
	/* 0x3be7: movabs rax,0x6e6f64207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7957689157107934318ULL);
x86_l_3bf1:
	/* 0x3bf1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3bf6:
	/* 0x3bf6: movabs rax,0x69776e7520726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345545598324ULL);
x86_l_3c00:
	/* 0x3c00: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3c05:
	/* 0x3c05: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_3c0f:
	/* 0x3c0f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c14:
	/* 0x3c14: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_3c1c:
	/* 0x3c1c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c21:
	/* 0x3c21: mov    eax,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_3c26:
	/* 0x3c26: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3c2b:
	/* 0x3c2b: mov    esi,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 27ULL);
x86_l_3c30:
	/* 0x3c30: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3c32:
	/* 0x3c32: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3c34:
	/* 0x3c34: jmp    4825 <perf_unwind_dotnet+0x4825> */
	X86_SIM_X86_JMP(0x3c34, 0x4825, x86_l_4825);
x86_l_3c39:
	/* 0x3c39: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_3c40:
	/* 0x3c40: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c45:
	/* 0x3c45: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3c4a:
	/* 0x3c4a: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3c4d:
	/* 0x3c4d: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_3c50:
	/* 0x3c50: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_3c55:
	/* 0x3c55: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_3c5c:
	/* 0x3c5c: mov    ecx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 67ULL);
x86_l_3c61:
	/* 0x3c61: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_3c67:
	/* 0x3c67: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3c6c:
	/* 0x3c6c: mov    r8,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_64);
x86_l_3c6f:
	/* 0x3c6f: sub    r8,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_3c72:
	/* 0x3c72: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3c75:
	/* 0x3c75: mov    esi,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 67ULL);
x86_l_3c7a:
	/* 0x3c7a: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_3c7d:
	/* 0x3c7d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3c7f:
	/* 0x3c7f: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3c82:
	/* 0x3c82: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3c89:
	/* 0x3c89: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_3c8d:
	/* 0x3c8d: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3c8d, 0xbc9, x86_l_bc9);
x86_l_3c93:
	/* 0x3c93: jmp    3a04 <perf_unwind_dotnet+0x3a04> */
	X86_SIM_X86_JMP(0x3c93, 0x3a04, x86_l_3a04);
x86_l_3c98:
	/* 0x3c98: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 737813247186461733ULL);
x86_l_3ca2:
	/* 0x3ca2: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3ca7:
	/* 0x3ca7: movabs rax,0x20656d617266203a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021050ULL);
x86_l_3cb1:
	/* 0x3cb1: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3cb6:
	/* 0x3cb6: movabs rax,0x7265646e69776e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243105118350175861ULL);
x86_l_3cc0:
	/* 0x3cc0: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3cc5:
	/* 0x3cc5: movabs rax,0x20656d6172662074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021108ULL);
x86_l_3ccf:
	/* 0x3ccf: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3cd4:
	/* 0x3cd4: movabs rax,0x78656e2065766c6f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8675461342619397231ULL);
x86_l_3cde:
	/* 0x3cde: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3ce3:
	/* 0x3ce3: movabs rax,0x736552203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315142585429343549ULL);
x86_l_3ced:
	/* 0x3ced: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3cf2:
	/* 0x3cf2: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3cf7:
	/* 0x3cf7: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3cfc:
	/* 0x3cfc: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_3d01:
	/* 0x3d01: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3d06:
	/* 0x3d06: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3d0d:
	/* 0x3d0d: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_3d12:
	/* 0x3d12: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3d14:
	/* 0x3d14: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3d16:
	/* 0x3d16: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_3d1d:
	/* 0x3d1d: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_3d27:
	/* 0x3d27: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3d2a:
	/* 0x3d2a: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3d2a, 0x24b3, x86_l_24b3);
x86_l_3d30:
	/* 0x3d30: jmp    3acb <perf_unwind_dotnet+0x3acb> */
	X86_SIM_X86_JMP(0x3d30, 0x3acb, x86_l_3acb);
x86_l_3d35:
	/* 0x3d35: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_3d3f:
	/* 0x3d3f: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3d44:
	/* 0x3d44: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_3d4e:
	/* 0x3d4e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3d53:
	/* 0x3d53: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_3d5d:
	/* 0x3d5d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3d62:
	/* 0x3d62: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_3d6c:
	/* 0x3d6c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3d71:
	/* 0x3d71: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_3d7b:
	/* 0x3d7b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d80:
	/* 0x3d80: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_3d8a:
	/* 0x3d8a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d8f:
	/* 0x3d8f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d94:
	/* 0x3d94: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_3d99:
	/* 0x3d99: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3d9e:
	/* 0x3d9e: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3da2:
	/* 0x3da2: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_3da7:
	/* 0x3da7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3da9:
	/* 0x3da9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3dab:
	/* 0x3dab: jmp    3a93 <perf_unwind_dotnet+0x3a93> */
	X86_SIM_X86_JMP(0x3dab, 0x3a93, x86_l_3a93);
x86_l_3db0:
	/* 0x3db0: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3db3:
	/* 0x3db3: and    rdx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_3db7:
	/* 0x3db7: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_3dc1:
	/* 0x3dc1: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_3dc6:
	/* 0x3dc6: movabs rax,0x72746e6520747372 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8247338198237475698ULL);
x86_l_3dd0:
	/* 0x3dd0: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3dd5:
	/* 0x3dd5: movabs rax,0x6966203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7594793257107465504ULL);
x86_l_3ddf:
	/* 0x3ddf: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3de4:
	/* 0x3de4: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_3dee:
	/* 0x3dee: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3df3:
	/* 0x3df3: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_3dfd:
	/* 0x3dfd: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3e02:
	/* 0x3e02: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_3e0c:
	/* 0x3e0c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3e11:
	/* 0x3e11: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_3e1b:
	/* 0x3e1b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e20:
	/* 0x3e20: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e25:
	/* 0x3e25: mov    eax,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 54ULL);
x86_l_3e2a:
	/* 0x3e2a: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_3e30:
	/* 0x3e30: mov    esi,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 54ULL);
x86_l_3e35:
	/* 0x3e35: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_3e38:
	/* 0x3e38: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3e3a:
	/* 0x3e3a: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3e3d:
	/* 0x3e3d: jmp    34f1 <perf_unwind_dotnet+0x34f1> */
	X86_SIM_X86_JMP(0x3e3d, 0x34f1, x86_l_34f1);
x86_l_3e42:
	/* 0x3e42: movabs rax,0xa786c253d7465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155643692133ULL);
x86_l_3e4c:
	/* 0x3e4c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3e51:
	/* 0x3e51: movabs rax,0x746572202c78253d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8387235363558008125ULL);
x86_l_3e5b:
	/* 0x3e5b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3e60:
	/* 0x3e60: movabs rax,0x6c6176202c786c25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809653109394271269ULL);
x86_l_3e6a:
	/* 0x3e6a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3e6f:
	/* 0x3e6f: movabs rax,0x203d2061746c6564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2323048585730221412ULL);
x86_l_3e79:
	/* 0x3e79: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3e7e:
	/* 0x3e7e: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460740081921312ULL);
x86_l_3e88:
	/* 0x3e88: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3e8d:
	/* 0x3e8d: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_3e97:
	/* 0x3e97: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e9c:
	/* 0x3e9c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ea1:
	/* 0x3ea1: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_3ea6:
	/* 0x3ea6: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_3eac:
	/* 0x3eac: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_3eb1:
	/* 0x3eb1: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3eb4:
	/* 0x3eb4: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_3eb7:
	/* 0x3eb7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3eb9:
	/* 0x3eb9: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3ebc:
	/* 0x3ebc: jmp    39b4 <perf_unwind_dotnet+0x39b4> */
	X86_SIM_X86_JMP(0x3ebc, 0x39b4, x86_l_39b4);
x86_l_3ec1:
	/* 0x3ec1: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_3ecb:
	/* 0x3ecb: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3ed0:
	/* 0x3ed0: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_3eda:
	/* 0x3eda: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3edf:
	/* 0x3edf: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_3ee9:
	/* 0x3ee9: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3eee:
	/* 0x3eee: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_3ef8:
	/* 0x3ef8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3efd:
	/* 0x3efd: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_3f07:
	/* 0x3f07: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3f0c:
	/* 0x3f0c: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_3f16:
	/* 0x3f16: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f1b:
	/* 0x3f1b: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f20:
	/* 0x3f20: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_3f25:
	/* 0x3f25: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_3f2a:
	/* 0x3f2a: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3f2e:
	/* 0x3f2e: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_3f33:
	/* 0x3f33: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3f35:
	/* 0x3f35: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3f37:
	/* 0x3f37: jmp    3541 <perf_unwind_dotnet+0x3541> */
	X86_SIM_X86_JMP(0x3f37, 0x3541, x86_l_3541);
x86_l_3f3c:
	/* 0x3f3c: movabs rax,0x296425207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2982549674514539630ULL);
x86_l_3f46:
	/* 0x3f46: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3f4b:
	/* 0x3f4b: movabs rax,0x69776e752820786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345674446956ULL);
x86_l_3f55:
	/* 0x3f55: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3f5a:
	/* 0x3f5a: movabs rax,0x6c2520736920786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670410291574892ULL);
x86_l_3f64:
	/* 0x3f64: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3f69:
	/* 0x3f69: movabs rax,0x2520435020726f66 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675212190078889830ULL);
x86_l_3f73:
	/* 0x3f73: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f78:
	/* 0x3f78: movabs rax,0x206469206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334106094897424756ULL);
x86_l_3f82:
	/* 0x3f82: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3f87:
	/* 0x3f87: movabs rbx,0x6365732074786554 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 7162257365632836948ULL);
x86_l_3f91:
	/* 0x3f91: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f96:
	/* 0x3f96: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_3f9d:
	/* 0x3f9d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3fa2:
	/* 0x3fa2: mov    eax,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_3fa7:
	/* 0x3fa7: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_3fad:
	/* 0x3fad: mov    rcx,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3fb4:
	/* 0x3fb4: mov    esi,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 50ULL);
x86_l_3fb9:
	/* 0x3fb9: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3fbc:
	/* 0x3fbc: mov    r8d,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_32);
x86_l_3fbf:
	/* 0x3fbf: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3fc1:
	/* 0x3fc1: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3fc4:
	/* 0x3fc4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_3fcb:
	/* 0x3fcb: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fce:
	/* 0x3fce: je     3b52 <perf_unwind_dotnet+0x3b52> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fce, 0x3b52, x86_l_3b52);
x86_l_3fd4:
	/* 0x3fd4: movabs rax,0xa786c6c252073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947156833280115ULL);
x86_l_3fde:
	/* 0x3fde: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_3fe3:
	/* 0x3fe3: movabs rax,0x7369207465736666 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8316213871206688358ULL);
x86_l_3fed:
	/* 0x3fed: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3ff2:
	/* 0x3ff2: movabs rax,0x6f20646e61202c78 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8007510562703420536ULL);
x86_l_3ffc:
	/* 0x3ffc: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4001:
	/* 0x4001: movabs rax,0x6c6c252073692073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7812660274886418547ULL);
x86_l_400b:
	/* 0x400b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4010:
	/* 0x4010: movabs rax,0x616962206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7019249385664899444ULL);
x86_l_401a:
	/* 0x401a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_401f:
	/* 0x401f: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4024:
	/* 0x4024: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4029:
	/* 0x4029: mov    eax,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 47ULL);
x86_l_402e:
	/* 0x402e: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_4034:
	/* 0x4034: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_403b:
	/* 0x403b: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4042:
	/* 0x4042: mov    esi,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 47ULL);
x86_l_4047:
	/* 0x4047: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4049:
	/* 0x4049: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_404c:
	/* 0x404c: jmp    3b52 <perf_unwind_dotnet+0x3b52> */
	X86_SIM_X86_JMP(0x404c, 0x3b52, x86_l_3b52);
x86_l_4051:
	/* 0x4051: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_405b:
	/* 0x405b: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_4060:
	/* 0x4060: movabs rax,0x746e6520646e6f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8389754345636130659ULL);
x86_l_406a:
	/* 0x406a: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_406f:
	/* 0x406f: movabs rax,0x6573203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310222055652992288ULL);
x86_l_4079:
	/* 0x4079: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_407e:
	/* 0x407e: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_4088:
	/* 0x4088: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_408d:
	/* 0x408d: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_4097:
	/* 0x4097: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_409c:
	/* 0x409c: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_40a6:
	/* 0x40a6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_40ab:
	/* 0x40ab: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_40b5:
	/* 0x40b5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_40ba:
	/* 0x40ba: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_40bf:
	/* 0x40bf: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_40c4:
	/* 0x40c4: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_40ca:
	/* 0x40ca: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_40cf:
	/* 0x40cf: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_40d2:
	/* 0x40d2: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_40d5:
	/* 0x40d5: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_40d7:
	/* 0x40d7: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_40da:
	/* 0x40da: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_40dc:
	/* 0x40dc: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_40df:
	/* 0x40df: jne    35fb <perf_unwind_dotnet+0x35fb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40df, 0x35fb, x86_l_35fb);
x86_l_40e5:
	/* 0x40e5: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_40ec:
	/* 0x40ec: mov    ecx,0xffffff84 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967172ULL);
x86_l_40f1:
	/* 0x40f1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_40f4:
	/* 0x40f4: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40f4, 0x45ec, x86_l_45ec);
x86_l_40fa:
	/* 0x40fa: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_4101:
	/* 0x4101: mov    ecx,0xffffff86 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967174ULL);
x86_l_4106:
	/* 0x4106: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4109:
	/* 0x4109: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4109, 0x45ec, x86_l_45ec);
x86_l_410f:
	/* 0x410f: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_4116:
	/* 0x4116: mov    ecx,0xffffff88 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967176ULL);
x86_l_411b:
	/* 0x411b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_411e:
	/* 0x411e: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x411e, 0x45ec, x86_l_45ec);
x86_l_4124:
	/* 0x4124: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_412b:
	/* 0x412b: mov    ecx,0xffffff8a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967178ULL);
x86_l_4130:
	/* 0x4130: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4133:
	/* 0x4133: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4133, 0x45ec, x86_l_45ec);
x86_l_4139:
	/* 0x4139: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_4140:
	/* 0x4140: mov    ecx,0xffffff8c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967180ULL);
x86_l_4145:
	/* 0x4145: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4148:
	/* 0x4148: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4148, 0x45ec, x86_l_45ec);
x86_l_414e:
	/* 0x414e: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_4155:
	/* 0x4155: mov    ecx,0xffffff8e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967182ULL);
x86_l_415a:
	/* 0x415a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_415d:
	/* 0x415d: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x415d, 0x45ec, x86_l_45ec);
x86_l_4163:
	/* 0x4163: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_416a:
	/* 0x416a: mov    ecx,0xffffff90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967184ULL);
x86_l_416f:
	/* 0x416f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4172:
	/* 0x4172: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4172, 0x45ec, x86_l_45ec);
x86_l_4178:
	/* 0x4178: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_417f:
	/* 0x417f: mov    ecx,0xffffff92 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967186ULL);
x86_l_4184:
	/* 0x4184: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4187:
	/* 0x4187: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4187, 0x45ec, x86_l_45ec);
x86_l_418d:
	/* 0x418d: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_4194:
	/* 0x4194: mov    ecx,0xffffff94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967188ULL);
x86_l_4199:
	/* 0x4199: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_419c:
	/* 0x419c: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x419c, 0x45ec, x86_l_45ec);
x86_l_41a2:
	/* 0x41a2: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_41a9:
	/* 0x41a9: mov    ecx,0xffffff96 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967190ULL);
x86_l_41ae:
	/* 0x41ae: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_41b1:
	/* 0x41b1: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41b1, 0x45ec, x86_l_45ec);
x86_l_41b7:
	/* 0x41b7: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_41be:
	/* 0x41be: mov    ecx,0xffffff98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967192ULL);
x86_l_41c3:
	/* 0x41c3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_41c6:
	/* 0x41c6: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41c6, 0x45ec, x86_l_45ec);
x86_l_41cc:
	/* 0x41cc: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_41d3:
	/* 0x41d3: mov    ecx,0xffffff9a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967194ULL);
x86_l_41d8:
	/* 0x41d8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_41db:
	/* 0x41db: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41db, 0x45ec, x86_l_45ec);
x86_l_41e1:
	/* 0x41e1: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_41e8:
	/* 0x41e8: mov    ecx,0xffffff9c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967196ULL);
x86_l_41ed:
	/* 0x41ed: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_41f0:
	/* 0x41f0: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41f0, 0x45ec, x86_l_45ec);
x86_l_41f6:
	/* 0x41f6: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_41fd:
	/* 0x41fd: mov    ecx,0xffffff9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967198ULL);
x86_l_4202:
	/* 0x4202: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4205:
	/* 0x4205: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4205, 0x45ec, x86_l_45ec);
x86_l_420b:
	/* 0x420b: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_4212:
	/* 0x4212: mov    ecx,0xffffffa0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967200ULL);
x86_l_4217:
	/* 0x4217: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_421a:
	/* 0x421a: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x421a, 0x45ec, x86_l_45ec);
x86_l_4220:
	/* 0x4220: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_4227:
	/* 0x4227: mov    ecx,0xffffffa2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967202ULL);
x86_l_422c:
	/* 0x422c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_422f:
	/* 0x422f: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x422f, 0x45ec, x86_l_45ec);
x86_l_4235:
	/* 0x4235: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_423c:
	/* 0x423c: mov    ecx,0xffffffa4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967204ULL);
x86_l_4241:
	/* 0x4241: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4244:
	/* 0x4244: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4244, 0x45ec, x86_l_45ec);
x86_l_424a:
	/* 0x424a: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_4251:
	/* 0x4251: mov    ecx,0xffffffa6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967206ULL);
x86_l_4256:
	/* 0x4256: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4259:
	/* 0x4259: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4259, 0x45ec, x86_l_45ec);
x86_l_425f:
	/* 0x425f: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_4266:
	/* 0x4266: mov    ecx,0xffffffa8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967208ULL);
x86_l_426b:
	/* 0x426b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_426e:
	/* 0x426e: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x426e, 0x45ec, x86_l_45ec);
x86_l_4274:
	/* 0x4274: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_427b:
	/* 0x427b: mov    ecx,0xffffffaa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967210ULL);
x86_l_4280:
	/* 0x4280: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4283:
	/* 0x4283: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4283, 0x45ec, x86_l_45ec);
x86_l_4289:
	/* 0x4289: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_4290:
	/* 0x4290: mov    ecx,0xffffffac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967212ULL);
x86_l_4295:
	/* 0x4295: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4298:
	/* 0x4298: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4298, 0x45ec, x86_l_45ec);
x86_l_429e:
	/* 0x429e: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_42a5:
	/* 0x42a5: mov    ecx,0xffffffae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967214ULL);
x86_l_42aa:
	/* 0x42aa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_42ad:
	/* 0x42ad: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42ad, 0x45ec, x86_l_45ec);
x86_l_42b3:
	/* 0x42b3: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_42ba:
	/* 0x42ba: mov    ecx,0xffffffb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967216ULL);
x86_l_42bf:
	/* 0x42bf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_42c2:
	/* 0x42c2: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42c2, 0x45ec, x86_l_45ec);
x86_l_42c8:
	/* 0x42c8: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_42cf:
	/* 0x42cf: mov    ecx,0xffffffb2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967218ULL);
x86_l_42d4:
	/* 0x42d4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_42d7:
	/* 0x42d7: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42d7, 0x45ec, x86_l_45ec);
x86_l_42dd:
	/* 0x42dd: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_42e4:
	/* 0x42e4: mov    ecx,0xffffffb4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967220ULL);
x86_l_42e9:
	/* 0x42e9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_42ec:
	/* 0x42ec: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42ec, 0x45ec, x86_l_45ec);
x86_l_42f2:
	/* 0x42f2: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_42f9:
	/* 0x42f9: mov    ecx,0xffffffb6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967222ULL);
x86_l_42fe:
	/* 0x42fe: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4301:
	/* 0x4301: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4301, 0x45ec, x86_l_45ec);
x86_l_4307:
	/* 0x4307: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_430e:
	/* 0x430e: mov    ecx,0xffffffb8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967224ULL);
x86_l_4313:
	/* 0x4313: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4316:
	/* 0x4316: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4316, 0x45ec, x86_l_45ec);
x86_l_431c:
	/* 0x431c: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_4323:
	/* 0x4323: mov    ecx,0xffffffba */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967226ULL);
x86_l_4328:
	/* 0x4328: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_432b:
	/* 0x432b: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x432b, 0x45ec, x86_l_45ec);
x86_l_4331:
	/* 0x4331: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_4338:
	/* 0x4338: mov    ecx,0xffffffbc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967228ULL);
x86_l_433d:
	/* 0x433d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4340:
	/* 0x4340: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4340, 0x45ec, x86_l_45ec);
x86_l_4346:
	/* 0x4346: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_434d:
	/* 0x434d: mov    ecx,0xffffffbe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967230ULL);
x86_l_4352:
	/* 0x4352: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4355:
	/* 0x4355: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4355, 0x45ec, x86_l_45ec);
x86_l_435b:
	/* 0x435b: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_4362:
	/* 0x4362: mov    ecx,0xffffffc0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967232ULL);
x86_l_4367:
	/* 0x4367: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_436a:
	/* 0x436a: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x436a, 0x45ec, x86_l_45ec);
x86_l_4370:
	/* 0x4370: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_4377:
	/* 0x4377: mov    ecx,0xffffffc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967234ULL);
x86_l_437c:
	/* 0x437c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_437f:
	/* 0x437f: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x437f, 0x45ec, x86_l_45ec);
x86_l_4385:
	/* 0x4385: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_438c:
	/* 0x438c: mov    ecx,0xffffffc4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967236ULL);
x86_l_4391:
	/* 0x4391: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4394:
	/* 0x4394: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4394, 0x45ec, x86_l_45ec);
x86_l_439a:
	/* 0x439a: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_43a1:
	/* 0x43a1: mov    ecx,0xffffffc6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967238ULL);
x86_l_43a6:
	/* 0x43a6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_43a9:
	/* 0x43a9: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43a9, 0x45ec, x86_l_45ec);
x86_l_43af:
	/* 0x43af: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_43b6:
	/* 0x43b6: mov    ecx,0xffffffc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967240ULL);
x86_l_43bb:
	/* 0x43bb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_43be:
	/* 0x43be: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43be, 0x45ec, x86_l_45ec);
x86_l_43c4:
	/* 0x43c4: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_43cb:
	/* 0x43cb: mov    ecx,0xffffffca */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967242ULL);
x86_l_43d0:
	/* 0x43d0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_43d3:
	/* 0x43d3: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43d3, 0x45ec, x86_l_45ec);
x86_l_43d9:
	/* 0x43d9: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_43e0:
	/* 0x43e0: mov    ecx,0xffffffcc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967244ULL);
x86_l_43e5:
	/* 0x43e5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_43e8:
	/* 0x43e8: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43e8, 0x45ec, x86_l_45ec);
x86_l_43ee:
	/* 0x43ee: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_43f5:
	/* 0x43f5: mov    ecx,0xffffffce */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967246ULL);
x86_l_43fa:
	/* 0x43fa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_43fd:
	/* 0x43fd: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43fd, 0x45ec, x86_l_45ec);
x86_l_4403:
	/* 0x4403: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_440a:
	/* 0x440a: mov    ecx,0xffffffd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967248ULL);
x86_l_440f:
	/* 0x440f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4412:
	/* 0x4412: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4412, 0x45ec, x86_l_45ec);
x86_l_4418:
	/* 0x4418: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_441f:
	/* 0x441f: mov    ecx,0xffffffd2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967250ULL);
x86_l_4424:
	/* 0x4424: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4427:
	/* 0x4427: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4427, 0x45ec, x86_l_45ec);
x86_l_442d:
	/* 0x442d: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_4434:
	/* 0x4434: mov    ecx,0xffffffd4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967252ULL);
x86_l_4439:
	/* 0x4439: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_443c:
	/* 0x443c: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x443c, 0x45ec, x86_l_45ec);
x86_l_4442:
	/* 0x4442: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_4449:
	/* 0x4449: mov    ecx,0xffffffd6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967254ULL);
x86_l_444e:
	/* 0x444e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4451:
	/* 0x4451: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4451, 0x45ec, x86_l_45ec);
x86_l_4457:
	/* 0x4457: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_445e:
	/* 0x445e: mov    ecx,0xffffffd8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967256ULL);
x86_l_4463:
	/* 0x4463: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4466:
	/* 0x4466: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4466, 0x45ec, x86_l_45ec);
x86_l_446c:
	/* 0x446c: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_4473:
	/* 0x4473: mov    ecx,0xffffffda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967258ULL);
x86_l_4478:
	/* 0x4478: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_447b:
	/* 0x447b: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x447b, 0x45ec, x86_l_45ec);
x86_l_4481:
	/* 0x4481: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_4488:
	/* 0x4488: mov    ecx,0xffffffdc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967260ULL);
x86_l_448d:
	/* 0x448d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4490:
	/* 0x4490: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4490, 0x45ec, x86_l_45ec);
x86_l_4496:
	/* 0x4496: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_449d:
	/* 0x449d: mov    ecx,0xffffffde */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967262ULL);
x86_l_44a2:
	/* 0x44a2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_44a5:
	/* 0x44a5: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44a5, 0x45ec, x86_l_45ec);
x86_l_44ab:
	/* 0x44ab: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_44b2:
	/* 0x44b2: mov    ecx,0xffffffe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967264ULL);
x86_l_44b7:
	/* 0x44b7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_44ba:
	/* 0x44ba: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44ba, 0x45ec, x86_l_45ec);
x86_l_44c0:
	/* 0x44c0: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_44c7:
	/* 0x44c7: mov    ecx,0xffffffe2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967266ULL);
x86_l_44cc:
	/* 0x44cc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_44cf:
	/* 0x44cf: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44cf, 0x45ec, x86_l_45ec);
x86_l_44d5:
	/* 0x44d5: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_44dc:
	/* 0x44dc: mov    ecx,0xffffffe4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967268ULL);
x86_l_44e1:
	/* 0x44e1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_44e4:
	/* 0x44e4: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44e4, 0x45ec, x86_l_45ec);
x86_l_44ea:
	/* 0x44ea: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_44f1:
	/* 0x44f1: mov    ecx,0xffffffe6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967270ULL);
x86_l_44f6:
	/* 0x44f6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_44f9:
	/* 0x44f9: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44f9, 0x45ec, x86_l_45ec);
x86_l_44ff:
	/* 0x44ff: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_4506:
	/* 0x4506: mov    ecx,0xffffffe8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967272ULL);
x86_l_450b:
	/* 0x450b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_450e:
	/* 0x450e: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x450e, 0x45ec, x86_l_45ec);
x86_l_4514:
	/* 0x4514: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_451b:
	/* 0x451b: mov    ecx,0xffffffea */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967274ULL);
x86_l_4520:
	/* 0x4520: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4523:
	/* 0x4523: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4523, 0x45ec, x86_l_45ec);
x86_l_4529:
	/* 0x4529: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_4530:
	/* 0x4530: mov    ecx,0xffffffec */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967276ULL);
x86_l_4535:
	/* 0x4535: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4538:
	/* 0x4538: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4538, 0x45ec, x86_l_45ec);
x86_l_453e:
	/* 0x453e: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_4545:
	/* 0x4545: mov    ecx,0xffffffee */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967278ULL);
x86_l_454a:
	/* 0x454a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_454d:
	/* 0x454d: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x454d, 0x45ec, x86_l_45ec);
x86_l_4553:
	/* 0x4553: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_455a:
	/* 0x455a: mov    ecx,0xfffffff0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967280ULL);
x86_l_455f:
	/* 0x455f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4562:
	/* 0x4562: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4562, 0x45ec, x86_l_45ec);
x86_l_4568:
	/* 0x4568: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_456f:
	/* 0x456f: mov    ecx,0xfffffff2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967282ULL);
x86_l_4574:
	/* 0x4574: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4577:
	/* 0x4577: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4577, 0x45ec, x86_l_45ec);
x86_l_4579:
	/* 0x4579: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_4580:
	/* 0x4580: mov    ecx,0xfffffff4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967284ULL);
x86_l_4585:
	/* 0x4585: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4588:
	/* 0x4588: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4588, 0x45ec, x86_l_45ec);
x86_l_458a:
	/* 0x458a: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_4591:
	/* 0x4591: mov    ecx,0xfffffff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967286ULL);
x86_l_4596:
	/* 0x4596: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4599:
	/* 0x4599: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4599, 0x45ec, x86_l_45ec);
x86_l_459b:
	/* 0x459b: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_45a2:
	/* 0x45a2: mov    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967288ULL);
x86_l_45a7:
	/* 0x45a7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_45aa:
	/* 0x45aa: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45aa, 0x45ec, x86_l_45ec);
x86_l_45ac:
	/* 0x45ac: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_45b3:
	/* 0x45b3: mov    ecx,0xfffffffa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967290ULL);
x86_l_45b8:
	/* 0x45b8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_45bb:
	/* 0x45bb: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45bb, 0x45ec, x86_l_45ec);
x86_l_45bd:
	/* 0x45bd: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_45c4:
	/* 0x45c4: mov    ecx,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967292ULL);
x86_l_45c9:
	/* 0x45c9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_45cc:
	/* 0x45cc: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45cc, 0x45ec, x86_l_45ec);
x86_l_45ce:
	/* 0x45ce: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_45d5:
	/* 0x45d5: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_45da:
	/* 0x45da: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_45dd:
	/* 0x45dd: jne    45ec <perf_unwind_dotnet+0x45ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45dd, 0x45ec, x86_l_45ec);
x86_l_45df:
	/* 0x45df: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_45e7:
	/* 0x45e7: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45ea:
	/* 0x45ea: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_45ec:
	/* 0x45ec: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_45ee:
	/* 0x45ee: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_45f1:
	/* 0x45f1: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_45f5:
	/* 0x45f5: setne  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_NE);
x86_l_45f8:
	/* 0x45f8: cmove  r15d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_45fc:
	/* 0x45fc: sub    ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_45fe:
	/* 0x45fe: add    ecx,0x7e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_4601:
	/* 0x4601: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_4603:
	/* 0x4603: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_4606:
	/* 0x4606: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_4609:
	/* 0x4609: jb     3609 <perf_unwind_dotnet+0x3609> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4609, 0x3609, x86_l_3609);
x86_l_460f:
	/* 0x460f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4616:
	/* 0x4616: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4619:
	/* 0x4619: jne    46df <perf_unwind_dotnet+0x46df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4619, 0x46df, x86_l_46df);
x86_l_461f:
	/* 0x461f: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_4622:
	/* 0x4622: jne    350d <perf_unwind_dotnet+0x350d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4622, 0x350d, x86_l_350d);
x86_l_4628:
	/* 0x4628: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_4630:
	/* 0x4630: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_4637:
	/* 0x4637: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_463c:
	/* 0x463c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4641:
	/* 0x4641: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4643:
	/* 0x4643: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4646:
	/* 0x4646: je     464d <perf_unwind_dotnet+0x464d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4646, 0x464d, x86_l_464d);
x86_l_4648:
	/* 0x4648: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_464b:
	/* 0x464b: jmp    465d <perf_unwind_dotnet+0x465d> */
	X86_SIM_X86_JMP(0x464b, 0x465d, x86_l_465d);
x86_l_464d:
	/* 0x464d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4654:
	/* 0x4654: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4657:
	/* 0x4657: jne    4cc2 <perf_unwind_dotnet+0x4cc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4657, 0x4cc2, x86_l_4cc2);
x86_l_465d:
	/* 0x465d: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_4662:
	/* 0x4662: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_4667:
	/* 0x4667: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_466e:
	/* 0x466e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4671:
	/* 0x4671: je     3558 <perf_unwind_dotnet+0x3558> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4671, 0x3558, x86_l_3558);
x86_l_4677:
	/* 0x4677: movabs rax,0xa642520687469 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387390569ULL);
x86_l_4681:
	/* 0x4681: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4686:
	/* 0x4686: movabs rax,0x772064656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8583971276541485414ULL);
x86_l_4690:
	/* 0x4690: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4695:
	/* 0x4695: movabs rax,0x2074726174735f65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338619869403242341ULL);
x86_l_469f:
	/* 0x469f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_46a4:
	/* 0x46a4: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7237112116340927776ULL);
x86_l_46ae:
	/* 0x46ae: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_46b3:
	/* 0x46b3: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_46bd:
	/* 0x46bd: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_46c2:
	/* 0x46c2: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_46c7:
	/* 0x46c7: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_46cc:
	/* 0x46cc: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_46d1:
	/* 0x46d1: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_46d6:
	/* 0x46d6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_46d8:
	/* 0x46d8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_46da:
	/* 0x46da: jmp    3558 <perf_unwind_dotnet+0x3558> */
	X86_SIM_X86_JMP(0x46da, 0x3558, x86_l_3558);
x86_l_46df:
	/* 0x46df: movabs rax,0x207972746e65202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2340027325789577260ULL);
x86_l_46e9:
	/* 0x46e9: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_46ee:
	/* 0x46ee: movabs rax,0x6425206465707069 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7216209593501773929ULL);
x86_l_46f8:
	/* 0x46f8: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_46fd:
	/* 0x46fd: movabs rax,0x6b73203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7742567619880559904ULL);
x86_l_4707:
	/* 0x4707: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_470c:
	/* 0x470c: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_4716:
	/* 0x4716: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_471b:
	/* 0x471b: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_4725:
	/* 0x4725: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_472a:
	/* 0x472a: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_4734:
	/* 0x4734: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4739:
	/* 0x4739: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_4743:
	/* 0x4743: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4748:
	/* 0x4748: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_4750:
	/* 0x4750: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4755:
	/* 0x4755: mov    eax,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_475a:
	/* 0x475a: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_4760:
	/* 0x4760: mov    esi,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 60ULL);
x86_l_4765:
	/* 0x4765: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_4768:
	/* 0x4768: mov    r8d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_32);
x86_l_476b:
	/* 0x476b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_476d:
	/* 0x476d: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4770:
	/* 0x4770: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_4773:
	/* 0x4773: jne    350d <perf_unwind_dotnet+0x350d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4773, 0x350d, x86_l_350d);
x86_l_4779:
	/* 0x4779: jmp    4628 <perf_unwind_dotnet+0x4628> */
	X86_SIM_X86_JMP(0x4779, 0x4628, x86_l_4628);
x86_l_477e:
	/* 0x477e: movabs rax,0xa642520686374 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387386228ULL);
x86_l_4788:
	/* 0x4788: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_478d:
	/* 0x478d: movabs rax,0x6374616d20737465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7166460028377068645ULL);
x86_l_4797:
	/* 0x4797: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_479c:
	/* 0x479c: movabs rax,0x7366666f5f726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315446390514935156ULL);
x86_l_47a6:
	/* 0x47a6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_47ab:
	/* 0x47ab: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_47b5:
	/* 0x47b5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_47ba:
	/* 0x47ba: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_47bf:
	/* 0x47bf: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_47c4:
	/* 0x47c4: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_47c9:
	/* 0x47c9: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_47ce:
	/* 0x47ce: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_47d3:
	/* 0x47d3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_47d5:
	/* 0x47d5: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_47d7:
	/* 0x47d7: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_47de:
	/* 0x47de: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_47e2:
	/* 0x47e2: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_47e5:
	/* 0x47e5: jb     3bd7 <perf_unwind_dotnet+0x3bd7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x47e5, 0x3bd7, x86_l_3bd7);
x86_l_47eb:
	/* 0x47eb: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_47f3:
	/* 0x47f3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_47fa:
	/* 0x47fa: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_47ff:
	/* 0x47ff: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4804:
	/* 0x4804: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4806:
	/* 0x4806: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4809:
	/* 0x4809: je     4810 <perf_unwind_dotnet+0x4810> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4809, 0x4810, x86_l_4810);
x86_l_480b:
	/* 0x480b: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_480e:
	/* 0x480e: jmp    4820 <perf_unwind_dotnet+0x4820> */
	X86_SIM_X86_JMP(0x480e, 0x4820, x86_l_4820);
x86_l_4810:
	/* 0x4810: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4817:
	/* 0x4817: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_481a:
	/* 0x481a: jne    4e21 <perf_unwind_dotnet+0x4e21> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x481a, 0x4e21, x86_l_4e21);
x86_l_4820:
	/* 0x4820: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_4825:
	/* 0x4825: cmp    r12d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 8ULL);
x86_l_4829:
	/* 0x4829: jne    8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4829, 0x8cac, x86_l_8cac);
x86_l_482f:
	/* 0x482f: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_4836:
	/* 0x4836: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_483d:
	/* 0x483d: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_4844:
	/* 0x4844: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_484c:
	/* 0x484c: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_4850:
	/* 0x4850: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4857:
	/* 0x4857: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_485a:
	/* 0x485a: jne    4c1e <perf_unwind_dotnet+0x4c1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x485a, 0x4c1e, x86_l_4c1e);
x86_l_4860:
	/* 0x4860: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_4863:
	/* 0x4863: jb     76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4863, 0x76bb, x86_l_76bb);
x86_l_4869:
	/* 0x4869: lea    rax,[rbx+0x2000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_4870:
	/* 0x4870: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_4873:
	/* 0x4873: jae    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4873, 0x76bb, x86_l_76bb);
x86_l_4879:
	/* 0x4879: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4880:
	/* 0x4880: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4887:
	/* 0x4887: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_488c:
	/* 0x488c: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_4894:
	/* 0x4894: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_4897:
	/* 0x4897: and    rax,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_489b:
	/* 0x489b: cmp    rax,0x80 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_48a1:
	/* 0x48a1: jne    48e5 <perf_unwind_dotnet+0x48e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x48a1, 0x48e5, x86_l_48e5);
x86_l_48a3:
	/* 0x48a3: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_48aa:
	/* 0x48aa: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_48af:
	/* 0x48af: mov    r8d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 112ULL);
x86_l_48b5:
	/* 0x48b5: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_48bd:
	/* 0x48bd: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_48c4:
	/* 0x48c4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_48c9:
	/* 0x48c9: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_48cc:
	/* 0x48cc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_48cf:
	/* 0x48cf: jne    19c <perf_unwind_dotnet+0x19c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x48cf, 0x19c, x86_l_19c);
x86_l_48d5:
	/* 0x48d5: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_48dd:
	/* 0x48dd: and    ebp,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_48e0:
	/* 0x48e0: jmp    4ef7 <perf_unwind_dotnet+0x4ef7> */
	X86_SIM_X86_JMP(0x48e0, 0x4ef7, x86_l_4ef7);
x86_l_48e5:
	/* 0x48e5: lea    rdi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_48ea:
	/* 0x48ea: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_48ef:
	/* 0x48ef: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_48f4:
	/* 0x48f4: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_48f9:
	/* 0x48f9: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_48fc:
	/* 0x48fc: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_48fe:
	/* 0x48fe: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4901:
	/* 0x4901: jne    26c <perf_unwind_dotnet+0x26c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4901, 0x26c, x86_l_26c);
x86_l_4907:
	/* 0x4907: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_490b:
	/* 0x490b: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_4912:
	/* 0x4912: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4917:
	/* 0x4917: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_491e:
	/* 0x491e: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_4923:
	/* 0x4923: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_492a:
	/* 0x492a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4931:
	/* 0x4931: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4934:
	/* 0x4934: jne    4d3d <perf_unwind_dotnet+0x4d3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4934, 0x4d3d, x86_l_4d3d);
x86_l_493a:
	/* 0x493a: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_4941:
	/* 0x4941: jb     4ef7 <perf_unwind_dotnet+0x4ef7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4941, 0x4ef7, x86_l_4ef7);
x86_l_4947:
	/* 0x4947: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_494e:
	/* 0x494e: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4955:
	/* 0x4955: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_4958:
	/* 0x4958: sub    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_495b:
	/* 0x495b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4962:
	/* 0x4962: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4965:
	/* 0x4965: jne    4ddd <perf_unwind_dotnet+0x4ddd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4965, 0x4ddd, x86_l_4ddd);
x86_l_496b:
	/* 0x496b: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_496e:
	/* 0x496e: shr    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_4972:
	/* 0x4972: mov    ecx,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 127ULL);
x86_l_4977:
	/* 0x4977: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_4979:
	/* 0x4979: and    ecx,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_497c:
	/* 0x497c: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_497e:
	/* 0x497e: cmp    r13,0x8000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 32768ULL);
x86_l_4985:
	/* 0x4985: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_498d:
	/* 0x498d: cmovb  rdx,rsi */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B);
x86_l_4991:
	/* 0x4991: cmovae ecx,esi */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE);
x86_l_4994:
	/* 0x4994: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4997:
	/* 0x4997: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_499f:
	/* 0x499f: lea    rdi,[rax+rcx*4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_49a3:
	/* 0x49a3: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
x86_l_49a8:
	/* 0x49a8: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_49ad:
	/* 0x49ad: mov    esi,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 512ULL);
x86_l_49b2:
	/* 0x49b2: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_49b4:
	/* 0x49b4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_49b7:
	/* 0x49b7: je     49ee <perf_unwind_dotnet+0x49ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49b7, 0x49ee, x86_l_49ee);
x86_l_49b9:
	/* 0x49b9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_49c0:
	/* 0x49c0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49c3:
	/* 0x49c3: jne    4baf <perf_unwind_dotnet+0x4baf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49c3, 0x4baf, x86_l_4baf);
x86_l_49c9:
	/* 0x49c9: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_49d1:
	/* 0x49d1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_49d8:
	/* 0x49d8: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_49dd:
	/* 0x49dd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_49e2:
	/* 0x49e2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_49e4:
	/* 0x49e4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_49e7:
	/* 0x49e7: je     4a45 <perf_unwind_dotnet+0x4a45> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49e7, 0x4a45, x86_l_4a45);
x86_l_49e9:
	/* 0x49e9: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_49ec:
	/* 0x49ec: jmp    4a55 <perf_unwind_dotnet+0x4a55> */
	X86_SIM_X86_JMP(0x49ec, 0x4a55, x86_l_4a55);
x86_l_49ee:
	/* 0x49ee: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_49f5:
	/* 0x49f5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_49fc:
	/* 0x49fc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49ff:
	/* 0x49ff: jne    52c4 <perf_unwind_dotnet+0x52c4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49ff, 0x52c4, x86_l_52c4);
x86_l_4a05:
	/* 0x4a05: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_4a08:
	/* 0x4a08: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_4a0a:
	/* 0x4a0a: shr    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_4a0d:
	/* 0x4a0d: and    al,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_4a0f:
	/* 0x4a0f: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_4a14:
	/* 0x4a14: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_4a17:
	/* 0x4a17: je     4ae2 <perf_unwind_dotnet+0x4ae2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a17, 0x4ae2, x86_l_4ae2);
x86_l_4a1d:
	/* 0x4a1d: and    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_4a21:
	/* 0x4a21: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4a24:
	/* 0x4a24: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4a27:
	/* 0x4a27: jne    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a27, 0x4eaa, x86_l_4eaa);
x86_l_4a2d:
	/* 0x4a2d: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4a30:
	/* 0x4a30: shr    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_4a33:
	/* 0x4a33: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4a36:
	/* 0x4a36: je     4bf2 <perf_unwind_dotnet+0x4bf2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a36, 0x4bf2, x86_l_4bf2);
x86_l_4a3c:
	/* 0x4a3c: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_4a40:
	/* 0x4a40: jmp    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JMP(0x4a40, 0x4eaa, x86_l_4eaa);
x86_l_4a45:
	/* 0x4a45: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4a4c:
	/* 0x4a4c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a4f:
	/* 0x4a4f: jne    53d5 <perf_unwind_dotnet+0x53d5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a4f, 0x53d5, x86_l_53d5);
x86_l_4a55:
	/* 0x4a55: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_4a5a:
	/* 0x4a5a: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4a5c:
	/* 0x4a5c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4a63:
	/* 0x4a63: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a66:
	/* 0x4a66: jne    5779 <perf_unwind_dotnet+0x5779> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a66, 0x5779, x86_l_5779);
x86_l_4a6c:
	/* 0x4a6c: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_4a71:
	/* 0x4a71: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_4a73:
	/* 0x4a73: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4a78:
	/* 0x4a78: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_4a7f:
	/* 0x4a7f: je     7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a7f, 0x7712, x86_l_7712);
x86_l_4a85:
	/* 0x4a85: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4a8c:
	/* 0x4a8c: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_4a90:
	/* 0x4a90: ja     4f3 <perf_unwind_dotnet+0x4f3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4a90, 0x4f3, x86_l_4f3);
x86_l_4a96:
	/* 0x4a96: lea    ecx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4a99:
	/* 0x4a99: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4aa0:
	/* 0x4aa0: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_4aa4:
	/* 0x4aa4: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_4ab0:
	/* 0x4ab0: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_4abc:
	/* 0x4abc: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_4ac5:
	/* 0x4ac5: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_4ad1:
	/* 0x4ad1: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_4add:
	/* 0x4add: jmp    4fa7 <perf_unwind_dotnet+0x4fa7> */
	X86_SIM_X86_JMP(0x4add, 0x4fa7, x86_l_4fa7);
x86_l_4ae2:
	/* 0x4ae2: and    r13,0xffffffffffffff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_4ae9:
	/* 0x4ae9: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_4aed:
	/* 0x4aed: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_4af4:
	/* 0x4af4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4afb:
	/* 0x4afb: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4afe:
	/* 0x4afe: jne    5565 <perf_unwind_dotnet+0x5565> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4afe, 0x5565, x86_l_5565);
x86_l_4b04:
	/* 0x4b04: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4b06:
	/* 0x4b06: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_4b09:
	/* 0x4b09: je     55f9 <perf_unwind_dotnet+0x55f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b09, 0x55f9, x86_l_55f9);
x86_l_4b0f:
	/* 0x4b0f: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_4b11:
	/* 0x4b11: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_4b14:
	/* 0x4b14: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_4b17:
	/* 0x4b17: jae    5711 <perf_unwind_dotnet+0x5711> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4b17, 0x5711, x86_l_5711);
x86_l_4b1d:
	/* 0x4b1d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4b24:
	/* 0x4b24: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b27:
	/* 0x4b27: je     49c9 <perf_unwind_dotnet+0x49c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b27, 0x49c9, x86_l_49c9);
x86_l_4b2d:
	/* 0x4b2d: movabs rax,0xa657361625f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2926295996587875ULL);
x86_l_4b37:
	/* 0x4b37: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4b3c:
	/* 0x4b3c: movabs rax,0x5f637020776f6c65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460741042564197ULL);
x86_l_4b46:
	/* 0x4b46: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4b4b:
	/* 0x4b4b: movabs rax,0x6220746e65772068 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7070779432469209192ULL);
x86_l_4b55:
	/* 0x4b55: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4b5a:
	/* 0x4b5a: movabs rax,0x6372616573207061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165897045450977377ULL);
x86_l_4b64:
	/* 0x4b64: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4b69:
	/* 0x4b69: movabs rax,0x6d20656c6262696e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7863396465570376046ULL);
x86_l_4b73:
	/* 0x4b73: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4b78:
	/* 0x4b78: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_4b82:
	/* 0x4b82: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4b87:
	/* 0x4b87: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4b8c:
	/* 0x4b8c: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_4b91:
	/* 0x4b91: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_4b96:
	/* 0x4b96: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_4b9b:
	/* 0x4b9b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4b9d:
	/* 0x4b9d: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4b9f:
	/* 0x4b9f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4ba6:
	/* 0x4ba6: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ba9:
	/* 0x4ba9: je     49c9 <perf_unwind_dotnet+0x49c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ba9, 0x49c9, x86_l_49c9);
x86_l_4baf:
	/* 0x4baf: movabs rax,0x6e756f6620746f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959390400869068654ULL);
x86_l_4bb9:
	/* 0x4bb9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4bbe:
	/* 0x4bbe: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_4bc8:
	/* 0x4bc8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4bcd:
	/* 0x4bcd: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_4bd5:
	/* 0x4bd5: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4bda:
	/* 0x4bda: mov    eax,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_4bdf:
	/* 0x4bdf: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_4be4:
	/* 0x4be4: mov    esi,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 19ULL);
x86_l_4be9:
	/* 0x4be9: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4beb:
	/* 0x4beb: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4bed:
	/* 0x4bed: jmp    49c9 <perf_unwind_dotnet+0x49c9> */
	X86_SIM_X86_JMP(0x4bed, 0x49c9, x86_l_49c9);
x86_l_4bf2:
	/* 0x4bf2: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4bf5:
	/* 0x4bf5: shr    ecx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_4bf8:
	/* 0x4bf8: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4bfb:
	/* 0x4bfb: je     4c06 <perf_unwind_dotnet+0x4c06> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4bfb, 0x4c06, x86_l_4c06);
x86_l_4bfd:
	/* 0x4bfd: add    r13,0xffffffffffffffc0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_4c01:
	/* 0x4c01: jmp    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JMP(0x4c01, 0x4eaa, x86_l_4eaa);
x86_l_4c06:
	/* 0x4c06: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4c09:
	/* 0x4c09: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_4c0c:
	/* 0x4c0c: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4c0f:
	/* 0x4c0f: je     4c93 <perf_unwind_dotnet+0x4c93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c0f, 0x4c93, x86_l_4c93);
x86_l_4c15:
	/* 0x4c15: add    r13,0xffffffffffffffa0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_4c19:
	/* 0x4c19: jmp    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JMP(0x4c19, 0x4eaa, x86_l_4eaa);
x86_l_4c1e:
	/* 0x4c1e: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_4c28:
	/* 0x4c28: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4c2d:
	/* 0x4c2d: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_4c37:
	/* 0x4c37: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4c3c:
	/* 0x4c3c: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_4c46:
	/* 0x4c46: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c4b:
	/* 0x4c4b: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_4c55:
	/* 0x4c55: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c5a:
	/* 0x4c5a: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_4c62:
	/* 0x4c62: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c67:
	/* 0x4c67: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_4c6c:
	/* 0x4c6c: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_4c72:
	/* 0x4c72: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_4c77:
	/* 0x4c77: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_4c7a:
	/* 0x4c7a: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_4c7d:
	/* 0x4c7d: mov    r8,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R13, X86_WIDTH_64);
x86_l_4c80:
	/* 0x4c80: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4c82:
	/* 0x4c82: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4c85:
	/* 0x4c85: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_4c88:
	/* 0x4c88: jae    4869 <perf_unwind_dotnet+0x4869> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4c88, 0x4869, x86_l_4869);
x86_l_4c8e:
	/* 0x4c8e: jmp    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JMP(0x4c8e, 0x76bb, x86_l_76bb);
x86_l_4c93:
	/* 0x4c93: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4c96:
	/* 0x4c96: shr    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_4c99:
	/* 0x4c99: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4c9c:
	/* 0x4c9c: je     4ca7 <perf_unwind_dotnet+0x4ca7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c9c, 0x4ca7, x86_l_4ca7);
x86_l_4c9e:
	/* 0x4c9e: add    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_4ca2:
	/* 0x4ca2: jmp    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JMP(0x4ca2, 0x4eaa, x86_l_4eaa);
x86_l_4ca7:
	/* 0x4ca7: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4caa:
	/* 0x4caa: shr    ecx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_4cad:
	/* 0x4cad: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4cb0:
	/* 0x4cb0: je     4dc2 <perf_unwind_dotnet+0x4dc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4cb0, 0x4dc2, x86_l_4dc2);
x86_l_4cb6:
	/* 0x4cb6: add    r13,0xffffffffffffff60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_4cbd:
	/* 0x4cbd: jmp    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JMP(0x4cbd, 0x4eaa, x86_l_4eaa);
x86_l_4cc2:
	/* 0x4cc2: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_4ccc:
	/* 0x4ccc: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4cd1:
	/* 0x4cd1: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_4cdb:
	/* 0x4cdb: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4ce0:
	/* 0x4ce0: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_4cea:
	/* 0x4cea: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4cef:
	/* 0x4cef: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_4cf9:
	/* 0x4cf9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4cfe:
	/* 0x4cfe: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_4d08:
	/* 0x4d08: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d0d:
	/* 0x4d0d: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_4d17:
	/* 0x4d17: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d1c:
	/* 0x4d1c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d21:
	/* 0x4d21: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_4d26:
	/* 0x4d26: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_4d2b:
	/* 0x4d2b: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4d2f:
	/* 0x4d2f: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_4d34:
	/* 0x4d34: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4d36:
	/* 0x4d36: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4d38:
	/* 0x4d38: jmp    465d <perf_unwind_dotnet+0x465d> */
	X86_SIM_X86_JMP(0x4d38, 0x465d, x86_l_465d);
x86_l_4d3d:
	/* 0x4d3d: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_4d47:
	/* 0x4d47: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4d4c:
	/* 0x4d4c: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_4d56:
	/* 0x4d56: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4d5b:
	/* 0x4d5b: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_4d65:
	/* 0x4d65: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d6a:
	/* 0x4d6a: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_4d74:
	/* 0x4d74: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d79:
	/* 0x4d79: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_4d81:
	/* 0x4d81: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d86:
	/* 0x4d86: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_4d8b:
	/* 0x4d8b: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_4d91:
	/* 0x4d91: mov    rdx,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_4d98:
	/* 0x4d98: mov    rcx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_4d9f:
	/* 0x4d9f: mov    r8,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_4da6:
	/* 0x4da6: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_4dab:
	/* 0x4dab: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4dad:
	/* 0x4dad: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4db0:
	/* 0x4db0: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_4db7:
	/* 0x4db7: jae    4947 <perf_unwind_dotnet+0x4947> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4db7, 0x4947, x86_l_4947);
x86_l_4dbd:
	/* 0x4dbd: jmp    4ef7 <perf_unwind_dotnet+0x4ef7> */
	X86_SIM_X86_JMP(0x4dbd, 0x4ef7, x86_l_4ef7);
x86_l_4dc2:
	/* 0x4dc2: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4dc5:
	/* 0x4dc5: shr    ecx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_4dc8:
	/* 0x4dc8: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4dcb:
	/* 0x4dcb: je     4e9c <perf_unwind_dotnet+0x4e9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dcb, 0x4e9c, x86_l_4e9c);
x86_l_4dd1:
	/* 0x4dd1: add    r13,0xffffffffffffff40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_4dd8:
	/* 0x4dd8: jmp    4eaa <perf_unwind_dotnet+0x4eaa> */
	X86_SIM_X86_JMP(0x4dd8, 0x4eaa, x86_l_4eaa);
x86_l_4ddd:
	/* 0x4ddd: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_4de4:
	/* 0x4de4: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4de9:
	/* 0x4de9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_4dee:
	/* 0x4dee: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4df1:
	/* 0x4df1: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_4df4:
	/* 0x4df4: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_4dfb:
	/* 0x4dfb: mov    ecx,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 66ULL);
x86_l_4e00:
	/* 0x4e00: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_4e06:
	/* 0x4e06: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4e09:
	/* 0x4e09: mov    esi,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 66ULL);
x86_l_4e0e:
	/* 0x4e0e: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_4e11:
	/* 0x4e11: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_4e14:
	/* 0x4e14: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_4e17:
	/* 0x4e17: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4e19:
	/* 0x4e19: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4e1c:
	/* 0x4e1c: jmp    496b <perf_unwind_dotnet+0x496b> */
	X86_SIM_X86_JMP(0x4e1c, 0x496b, x86_l_496b);
x86_l_4e21:
	/* 0x4e21: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_4e2b:
	/* 0x4e2b: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4e30:
	/* 0x4e30: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_4e3a:
	/* 0x4e3a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4e3f:
	/* 0x4e3f: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_4e49:
	/* 0x4e49: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4e4e:
	/* 0x4e4e: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_4e58:
	/* 0x4e58: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4e5d:
	/* 0x4e5d: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_4e67:
	/* 0x4e67: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4e6c:
	/* 0x4e6c: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_4e76:
	/* 0x4e76: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e7b:
	/* 0x4e7b: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e80:
	/* 0x4e80: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_4e85:
	/* 0x4e85: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_4e8a:
	/* 0x4e8a: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4e8e:
	/* 0x4e8e: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_4e93:
	/* 0x4e93: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4e95:
	/* 0x4e95: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4e97:
	/* 0x4e97: jmp    4820 <perf_unwind_dotnet+0x4820> */
	X86_SIM_X86_JMP(0x4e97, 0x4820, x86_l_4820);
x86_l_4e9c:
	/* 0x4e9c: shr    r15d,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_4ea0:
	/* 0x4ea0: add    r13,0xffffffffffffff20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_4ea7:
	/* 0x4ea7: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_4eaa:
	/* 0x4eaa: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4ead:
	/* 0x4ead: lea    r15d,[rcx*4-0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 18446744073709551612ULL);
x86_l_4eb5:
	/* 0x4eb5: add    r15,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4eb8:
	/* 0x4eb8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4ebf:
	/* 0x4ebf: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ec2:
	/* 0x4ec2: jne    5356 <perf_unwind_dotnet+0x5356> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4ec2, 0x5356, x86_l_5356);
x86_l_4ec8:
	/* 0x4ec8: lea    rdx,[r15-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_4ecc:
	/* 0x4ecc: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4ed1:
	/* 0x4ed1: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_4ed6:
	/* 0x4ed6: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_4edb:
	/* 0x4edb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4ee0:
	/* 0x4ee0: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4ee2:
	/* 0x4ee2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4ee5:
	/* 0x4ee5: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_4eec:
	/* 0x4eec: jne    b73 <perf_unwind_dotnet+0xb73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4eec, 0xb73, x86_l_b73);
x86_l_4ef2:
	/* 0x4ef2: mov    ebp,0x1f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 31ULL);
x86_l_4ef7:
	/* 0x4ef7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4efe:
	/* 0x4efe: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f01:
	/* 0x4f01: jne    514d <perf_unwind_dotnet+0x514d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f01, 0x514d, x86_l_514d);
x86_l_4f07:
	/* 0x4f07: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4f0e:
	/* 0x4f0e: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_4f12:
	/* 0x4f12: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4f12, 0xbc9, x86_l_bc9);
x86_l_4f18:
	/* 0x4f18: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4f1d:
	/* 0x4f1d: sub    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_4f20:
	/* 0x4f20: shl    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_4f24:
	/* 0x4f24: add    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4f27:
	/* 0x4f27: lea    edx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4f2a:
	/* 0x4f2a: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4f31:
	/* 0x4f31: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_4f35:
	/* 0x4f35: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_4f3d:
	/* 0x4f3d: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_4f45:
	/* 0x4f45: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_4f4e:
	/* 0x4f4e: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_4f53:
	/* 0x4f53: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_4f5b:
	/* 0x4f5b: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_4f67:
	/* 0x4f67: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_4f72:
	/* 0x4f72: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_4f7a:
	/* 0x4f7a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_4f81:
	/* 0x4f81: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4f86:
	/* 0x4f86: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4f8b:
	/* 0x4f8b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4f8d:
	/* 0x4f8d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4f90:
	/* 0x4f90: je     4f97 <perf_unwind_dotnet+0x4f97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f90, 0x4f97, x86_l_4f97);
x86_l_4f92:
	/* 0x4f92: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_4f95:
	/* 0x4f95: jmp    4fa7 <perf_unwind_dotnet+0x4fa7> */
	X86_SIM_X86_JMP(0x4f95, 0x4fa7, x86_l_4fa7);
x86_l_4f97:
	/* 0x4f97: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4f9e:
	/* 0x4f9e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fa1:
	/* 0x4fa1: jne    5249 <perf_unwind_dotnet+0x5249> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4fa1, 0x5249, x86_l_5249);
x86_l_4fa7:
	/* 0x4fa7: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4faf:
	/* 0x4faf: mov    r13,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fb2:
	/* 0x4fb2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_4fb9:
	/* 0x4fb9: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fbb:
	/* 0x4fbb: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_4fbe:
	/* 0x4fbe: je     87f5 <perf_unwind_dotnet+0x87f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4fbe, 0x87f5, x86_l_87f5);
x86_l_4fc4:
	/* 0x4fc4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4fc6:
	/* 0x4fc6: jne    51ac <perf_unwind_dotnet+0x51ac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4fc6, 0x51ac, x86_l_51ac);
x86_l_4fcc:
	/* 0x4fcc: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_4fd6:
	/* 0x4fd6: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_4fd9:
	/* 0x4fd9: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4fd9, 0x24b3, x86_l_24b3);
x86_l_4fdf:
	/* 0x4fdf: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_4fe6:
	/* 0x4fe6: jb     264e <perf_unwind_dotnet+0x264e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4fe6, 0x264e, x86_l_264e);
x86_l_4fec:
	/* 0x4fec: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fef:
	/* 0x4fef: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_4ff7:
	/* 0x4ff7: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_4ffd:
	/* 0x4ffd: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_5004:
	/* 0x5004: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&pid_page_to_mapping_info));
x86_l_500b:
	/* 0x500b: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5010:
	/* 0x5010: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5015:
	/* 0x5015: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5017:
	/* 0x5017: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_501a:
	/* 0x501a: je     8740 <perf_unwind_dotnet+0x8740> */
	X86_SIM_X86_JCC(X86_CC_E, 0x501a, 0x8740, x86_l_8740);
x86_l_5020:
	/* 0x5020: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5024:
	/* 0x5024: mov    rcx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_64);
x86_l_5027:
	/* 0x5027: movabs rdx,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_5031:
	/* 0x5031: and    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND);
x86_l_5034:
	/* 0x5034: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_503b:
	/* 0x503b: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_503e:
	/* 0x503e: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5045:
	/* 0x5045: shr    r12,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_5049:
	/* 0x5049: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_504c:
	/* 0x504c: sub    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_504f:
	/* 0x504f: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_5056:
	/* 0x5056: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_505d:
	/* 0x505d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5060:
	/* 0x5060: jne    5450 <perf_unwind_dotnet+0x5450> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5060, 0x5450, x86_l_5450);
x86_l_5066:
	/* 0x5066: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_506a:
	/* 0x506a: jne    5927 <perf_unwind_dotnet+0x5927> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x506a, 0x5927, x86_l_5927);
x86_l_5070:
	/* 0x5070: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5077:
	/* 0x5077: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_507c:
	/* 0x507c: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_5083:
	/* 0x5083: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&interpreter_offsets));
x86_l_508a:
	/* 0x508a: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_508f:
	/* 0x508f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5094:
	/* 0x5094: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5096:
	/* 0x5096: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_509c:
	/* 0x509c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_509f:
	/* 0x509f: je     5927 <perf_unwind_dotnet+0x5927> */
	X86_SIM_X86_JCC(X86_CC_E, 0x509f, 0x5927, x86_l_5927);
x86_l_50a5:
	/* 0x50a5: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_50a8:
	/* 0x50a8: cmp    QWORD PTR [rax],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50ab:
	/* 0x50ab: ja     50b3 <perf_unwind_dotnet+0x50b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x50ab, 0x50b3, x86_l_50b3);
x86_l_50ad:
	/* 0x50ad: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_50b1:
	/* 0x50b1: jae    50c7 <perf_unwind_dotnet+0x50c7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x50b1, 0x50c7, x86_l_50c7);
x86_l_50b3:
	/* 0x50b3: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_50b7:
	/* 0x50b7: ja     5927 <perf_unwind_dotnet+0x5927> */
	X86_SIM_X86_JCC(X86_CC_A, 0x50b7, 0x5927, x86_l_5927);
x86_l_50bd:
	/* 0x50bd: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_50c1:
	/* 0x50c1: jb     5927 <perf_unwind_dotnet+0x5927> */
	X86_SIM_X86_JCC(X86_CC_B, 0x50c1, 0x5927, x86_l_5927);
x86_l_50c7:
	/* 0x50c7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_50ce:
	/* 0x50ce: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50d1:
	/* 0x50d1: jne    5880 <perf_unwind_dotnet+0x5880> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x50d1, 0x5880, x86_l_5880);
x86_l_50d7:
	/* 0x50d7: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_50de:
	/* 0x50de: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_50e2:
	/* 0x50e2: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_50e5:
	/* 0x50e5: jae    58ed <perf_unwind_dotnet+0x58ed> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x50e5, 0x58ed, x86_l_58ed);
x86_l_50eb:
	/* 0x50eb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_50f2:
	/* 0x50f2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50f5:
	/* 0x50f5: je     5927 <perf_unwind_dotnet+0x5927> */
	X86_SIM_X86_JCC(X86_CC_E, 0x50f5, 0x5927, x86_l_5927);
x86_l_50fb:
	/* 0x50fb: movabs rax,0x6e6f64207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7957689157107934318ULL);
x86_l_5105:
	/* 0x5105: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_510a:
	/* 0x510a: movabs rax,0x69776e7520726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345545598324ULL);
x86_l_5114:
	/* 0x5114: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5119:
	/* 0x5119: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_5123:
	/* 0x5123: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5128:
	/* 0x5128: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_5130:
	/* 0x5130: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5135:
	/* 0x5135: mov    eax,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_513a:
	/* 0x513a: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_513f:
	/* 0x513f: mov    esi,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 27ULL);
x86_l_5144:
	/* 0x5144: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5146:
	/* 0x5146: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5148:
	/* 0x5148: jmp    5927 <perf_unwind_dotnet+0x5927> */
	X86_SIM_X86_JMP(0x5148, 0x5927, x86_l_5927);
x86_l_514d:
	/* 0x514d: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_5154:
	/* 0x5154: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5159:
	/* 0x5159: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_515e:
	/* 0x515e: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_5161:
	/* 0x5161: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_5164:
	/* 0x5164: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_5169:
	/* 0x5169: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_5170:
	/* 0x5170: mov    ecx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 67ULL);
x86_l_5175:
	/* 0x5175: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_517b:
	/* 0x517b: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5180:
	/* 0x5180: mov    r8,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_64);
x86_l_5183:
	/* 0x5183: sub    r8,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_5186:
	/* 0x5186: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_5189:
	/* 0x5189: mov    esi,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 67ULL);
x86_l_518e:
	/* 0x518e: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_5191:
	/* 0x5191: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5193:
	/* 0x5193: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5196:
	/* 0x5196: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_519d:
	/* 0x519d: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_51a1:
	/* 0x51a1: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x51a1, 0xbc9, x86_l_bc9);
x86_l_51a7:
	/* 0x51a7: jmp    4f18 <perf_unwind_dotnet+0x4f18> */
	X86_SIM_X86_JMP(0x51a7, 0x4f18, x86_l_4f18);
x86_l_51ac:
	/* 0x51ac: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 737813247186461733ULL);
x86_l_51b6:
	/* 0x51b6: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_51bb:
	/* 0x51bb: movabs rax,0x20656d617266203a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021050ULL);
x86_l_51c5:
	/* 0x51c5: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_51ca:
	/* 0x51ca: movabs rax,0x7265646e69776e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243105118350175861ULL);
x86_l_51d4:
	/* 0x51d4: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_51d9:
	/* 0x51d9: movabs rax,0x20656d6172662074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021108ULL);
x86_l_51e3:
	/* 0x51e3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_51e8:
	/* 0x51e8: movabs rax,0x78656e2065766c6f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8675461342619397231ULL);
x86_l_51f2:
	/* 0x51f2: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_51f7:
	/* 0x51f7: movabs rax,0x736552203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315142585429343549ULL);
x86_l_5201:
	/* 0x5201: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5206:
	/* 0x5206: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_520b:
	/* 0x520b: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5210:
	/* 0x5210: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_5215:
	/* 0x5215: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_521a:
	/* 0x521a: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5221:
	/* 0x5221: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_5226:
	/* 0x5226: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5228:
	/* 0x5228: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_522a:
	/* 0x522a: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_5231:
	/* 0x5231: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_523b:
	/* 0x523b: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_523e:
	/* 0x523e: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x523e, 0x24b3, x86_l_24b3);
x86_l_5244:
	/* 0x5244: jmp    4fdf <perf_unwind_dotnet+0x4fdf> */
	X86_SIM_X86_JMP(0x5244, 0x4fdf, x86_l_4fdf);
x86_l_5249:
	/* 0x5249: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_5253:
	/* 0x5253: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5258:
	/* 0x5258: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_5262:
	/* 0x5262: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5267:
	/* 0x5267: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_5271:
	/* 0x5271: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5276:
	/* 0x5276: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_5280:
	/* 0x5280: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5285:
	/* 0x5285: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_528f:
	/* 0x528f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5294:
	/* 0x5294: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_529e:
	/* 0x529e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_52a3:
	/* 0x52a3: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_52a8:
	/* 0x52a8: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_52ad:
	/* 0x52ad: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_52b2:
	/* 0x52b2: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_52b6:
	/* 0x52b6: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_52bb:
	/* 0x52bb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_52bd:
	/* 0x52bd: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_52bf:
	/* 0x52bf: jmp    4fa7 <perf_unwind_dotnet+0x4fa7> */
	X86_SIM_X86_JMP(0x52bf, 0x4fa7, x86_l_4fa7);
x86_l_52c4:
	/* 0x52c4: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_52c7:
	/* 0x52c7: and    rdx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_52cb:
	/* 0x52cb: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_52d5:
	/* 0x52d5: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_52da:
	/* 0x52da: movabs rax,0x72746e6520747372 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8247338198237475698ULL);
x86_l_52e4:
	/* 0x52e4: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_52e9:
	/* 0x52e9: movabs rax,0x6966203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7594793257107465504ULL);
x86_l_52f3:
	/* 0x52f3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_52f8:
	/* 0x52f8: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_5302:
	/* 0x5302: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5307:
	/* 0x5307: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_5311:
	/* 0x5311: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5316:
	/* 0x5316: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_5320:
	/* 0x5320: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5325:
	/* 0x5325: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_532f:
	/* 0x532f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5334:
	/* 0x5334: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5339:
	/* 0x5339: mov    eax,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 54ULL);
x86_l_533e:
	/* 0x533e: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_5344:
	/* 0x5344: mov    esi,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 54ULL);
x86_l_5349:
	/* 0x5349: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_534c:
	/* 0x534c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_534e:
	/* 0x534e: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5351:
	/* 0x5351: jmp    4a05 <perf_unwind_dotnet+0x4a05> */
	X86_SIM_X86_JMP(0x5351, 0x4a05, x86_l_4a05);
x86_l_5356:
	/* 0x5356: movabs rax,0xa786c253d7465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155643692133ULL);
x86_l_5360:
	/* 0x5360: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5365:
	/* 0x5365: movabs rax,0x746572202c78253d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8387235363558008125ULL);
x86_l_536f:
	/* 0x536f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5374:
	/* 0x5374: movabs rax,0x6c6176202c786c25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809653109394271269ULL);
x86_l_537e:
	/* 0x537e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5383:
	/* 0x5383: movabs rax,0x203d2061746c6564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2323048585730221412ULL);
x86_l_538d:
	/* 0x538d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5392:
	/* 0x5392: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460740081921312ULL);
x86_l_539c:
	/* 0x539c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_53a1:
	/* 0x53a1: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_53ab:
	/* 0x53ab: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53b0:
	/* 0x53b0: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53b5:
	/* 0x53b5: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_53ba:
	/* 0x53ba: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_53c0:
	/* 0x53c0: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_53c5:
	/* 0x53c5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_53c8:
	/* 0x53c8: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_53cb:
	/* 0x53cb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_53cd:
	/* 0x53cd: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_53d0:
	/* 0x53d0: jmp    4ec8 <perf_unwind_dotnet+0x4ec8> */
	X86_SIM_X86_JMP(0x53d0, 0x4ec8, x86_l_4ec8);
x86_l_53d5:
	/* 0x53d5: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_53df:
	/* 0x53df: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_53e4:
	/* 0x53e4: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_53ee:
	/* 0x53ee: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_53f3:
	/* 0x53f3: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_53fd:
	/* 0x53fd: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5402:
	/* 0x5402: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_540c:
	/* 0x540c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5411:
	/* 0x5411: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_541b:
	/* 0x541b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5420:
	/* 0x5420: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_542a:
	/* 0x542a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_542f:
	/* 0x542f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5434:
	/* 0x5434: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_5439:
	/* 0x5439: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_543e:
	/* 0x543e: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5442:
	/* 0x5442: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_5447:
	/* 0x5447: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5449:
	/* 0x5449: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_544b:
	/* 0x544b: jmp    4a55 <perf_unwind_dotnet+0x4a55> */
	X86_SIM_X86_JMP(0x544b, 0x4a55, x86_l_4a55);
x86_l_5450:
	/* 0x5450: movabs rax,0x296425207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2982549674514539630ULL);
x86_l_545a:
	/* 0x545a: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_545f:
	/* 0x545f: movabs rax,0x69776e752820786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345674446956ULL);
x86_l_5469:
	/* 0x5469: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_546e:
	/* 0x546e: movabs rax,0x6c2520736920786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670410291574892ULL);
x86_l_5478:
	/* 0x5478: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_547d:
	/* 0x547d: movabs rax,0x2520435020726f66 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675212190078889830ULL);
x86_l_5487:
	/* 0x5487: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_548c:
	/* 0x548c: movabs rax,0x206469206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334106094897424756ULL);
x86_l_5496:
	/* 0x5496: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_549b:
	/* 0x549b: movabs rbx,0x6365732074786554 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 7162257365632836948ULL);
x86_l_54a5:
	/* 0x54a5: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_54aa:
	/* 0x54aa: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_54b1:
	/* 0x54b1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_54b6:
	/* 0x54b6: mov    eax,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_54bb:
	/* 0x54bb: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_54c1:
	/* 0x54c1: mov    rcx,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_54c8:
	/* 0x54c8: mov    esi,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 50ULL);
x86_l_54cd:
	/* 0x54cd: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_54d0:
	/* 0x54d0: mov    r8d,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_32);
x86_l_54d3:
	/* 0x54d3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_54d5:
	/* 0x54d5: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_54d8:
	/* 0x54d8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_54df:
	/* 0x54df: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54e2:
	/* 0x54e2: je     5066 <perf_unwind_dotnet+0x5066> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54e2, 0x5066, x86_l_5066);
x86_l_54e8:
	/* 0x54e8: movabs rax,0xa786c6c252073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947156833280115ULL);
x86_l_54f2:
	/* 0x54f2: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_54f7:
	/* 0x54f7: movabs rax,0x7369207465736666 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8316213871206688358ULL);
x86_l_5501:
	/* 0x5501: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5506:
	/* 0x5506: movabs rax,0x6f20646e61202c78 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8007510562703420536ULL);
x86_l_5510:
	/* 0x5510: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5515:
	/* 0x5515: movabs rax,0x6c6c252073692073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7812660274886418547ULL);
x86_l_551f:
	/* 0x551f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5524:
	/* 0x5524: movabs rax,0x616962206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7019249385664899444ULL);
x86_l_552e:
	/* 0x552e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5533:
	/* 0x5533: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5538:
	/* 0x5538: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_553d:
	/* 0x553d: mov    eax,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 47ULL);
x86_l_5542:
	/* 0x5542: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_5548:
	/* 0x5548: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_554f:
	/* 0x554f: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_5556:
	/* 0x5556: mov    esi,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 47ULL);
x86_l_555b:
	/* 0x555b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_555d:
	/* 0x555d: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5560:
	/* 0x5560: jmp    5066 <perf_unwind_dotnet+0x5066> */
	X86_SIM_X86_JMP(0x5560, 0x5066, x86_l_5066);
x86_l_5565:
	/* 0x5565: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_556f:
	/* 0x556f: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_5574:
	/* 0x5574: movabs rax,0x746e6520646e6f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8389754345636130659ULL);
x86_l_557e:
	/* 0x557e: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5583:
	/* 0x5583: movabs rax,0x6573203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310222055652992288ULL);
x86_l_558d:
	/* 0x558d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5592:
	/* 0x5592: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_559c:
	/* 0x559c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_55a1:
	/* 0x55a1: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_55ab:
	/* 0x55ab: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_55b0:
	/* 0x55b0: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_55ba:
	/* 0x55ba: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_55bf:
	/* 0x55bf: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_55c9:
	/* 0x55c9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_55ce:
	/* 0x55ce: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_55d3:
	/* 0x55d3: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_55d8:
	/* 0x55d8: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_55de:
	/* 0x55de: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_55e3:
	/* 0x55e3: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_55e6:
	/* 0x55e6: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_55e9:
	/* 0x55e9: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_55eb:
	/* 0x55eb: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_55ee:
	/* 0x55ee: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_55f0:
	/* 0x55f0: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_55f3:
	/* 0x55f3: jne    4b0f <perf_unwind_dotnet+0x4b0f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x55f3, 0x4b0f, x86_l_4b0f);
x86_l_55f9:
	/* 0x55f9: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_5600:
	/* 0x5600: mov    ecx,0xffffff84 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967172ULL);
x86_l_5605:
	/* 0x5605: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5608:
	/* 0x5608: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5608, 0x56ee, x86_l_56ee);
x86_l_560e:
	/* 0x560e: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_5615:
	/* 0x5615: mov    ecx,0xffffff86 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967174ULL);
x86_l_561a:
	/* 0x561a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_561d:
	/* 0x561d: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x561d, 0x56ee, x86_l_56ee);
x86_l_5623:
	/* 0x5623: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_562a:
	/* 0x562a: mov    ecx,0xffffff88 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967176ULL);
x86_l_562f:
	/* 0x562f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5632:
	/* 0x5632: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5632, 0x56ee, x86_l_56ee);
x86_l_5638:
	/* 0x5638: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_563f:
	/* 0x563f: mov    ecx,0xffffff8a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967178ULL);
x86_l_5644:
	/* 0x5644: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5647:
	/* 0x5647: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5647, 0x56ee, x86_l_56ee);
x86_l_564d:
	/* 0x564d: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_5654:
	/* 0x5654: mov    ecx,0xffffff8c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967180ULL);
x86_l_5659:
	/* 0x5659: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_565c:
	/* 0x565c: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x565c, 0x56ee, x86_l_56ee);
x86_l_5662:
	/* 0x5662: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_5669:
	/* 0x5669: mov    ecx,0xffffff8e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967182ULL);
x86_l_566e:
	/* 0x566e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5671:
	/* 0x5671: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5671, 0x56ee, x86_l_56ee);
x86_l_5673:
	/* 0x5673: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_567a:
	/* 0x567a: mov    ecx,0xffffff90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967184ULL);
x86_l_567f:
	/* 0x567f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5682:
	/* 0x5682: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5682, 0x56ee, x86_l_56ee);
x86_l_5684:
	/* 0x5684: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_568b:
	/* 0x568b: mov    ecx,0xffffff92 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967186ULL);
x86_l_5690:
	/* 0x5690: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5693:
	/* 0x5693: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5693, 0x56ee, x86_l_56ee);
x86_l_5695:
	/* 0x5695: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_569c:
	/* 0x569c: mov    ecx,0xffffff94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967188ULL);
x86_l_56a1:
	/* 0x56a1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56a4:
	/* 0x56a4: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x56a4, 0x56ee, x86_l_56ee);
x86_l_56a6:
	/* 0x56a6: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_56ad:
	/* 0x56ad: mov    ecx,0xffffff96 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967190ULL);
x86_l_56b2:
	/* 0x56b2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56b5:
	/* 0x56b5: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x56b5, 0x56ee, x86_l_56ee);
x86_l_56b7:
	/* 0x56b7: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_56be:
	/* 0x56be: mov    ecx,0xffffff98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967192ULL);
x86_l_56c3:
	/* 0x56c3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56c6:
	/* 0x56c6: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x56c6, 0x56ee, x86_l_56ee);
x86_l_56c8:
	/* 0x56c8: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_56cf:
	/* 0x56cf: mov    ecx,0xffffff9a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967194ULL);
x86_l_56d4:
	/* 0x56d4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56d7:
	/* 0x56d7: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x56d7, 0x56ee, x86_l_56ee);
x86_l_56d9:
	/* 0x56d9: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_56e0:
	/* 0x56e0: mov    ecx,0xffffff9c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967196ULL);
x86_l_56e5:
	/* 0x56e5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56e8:
	/* 0x56e8: je     6cf5 <perf_unwind_dotnet+0x6cf5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56e8, 0x6cf5, x86_l_6cf5);
x86_l_56ee:
	/* 0x56ee: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_56f0:
	/* 0x56f0: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_56f3:
	/* 0x56f3: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_56f7:
	/* 0x56f7: setne  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_NE);
x86_l_56fa:
	/* 0x56fa: cmove  r15d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_56fe:
	/* 0x56fe: sub    ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5700:
	/* 0x5700: add    ecx,0x7e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_5703:
	/* 0x5703: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_5705:
	/* 0x5705: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_5708:
	/* 0x5708: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_570b:
	/* 0x570b: jb     4b1d <perf_unwind_dotnet+0x4b1d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x570b, 0x4b1d, x86_l_4b1d);
x86_l_5711:
	/* 0x5711: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5718:
	/* 0x5718: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_571b:
	/* 0x571b: jne    57e1 <perf_unwind_dotnet+0x57e1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x571b, 0x57e1, x86_l_57e1);
x86_l_5721:
	/* 0x5721: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_5724:
	/* 0x5724: jne    4a21 <perf_unwind_dotnet+0x4a21> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5724, 0x4a21, x86_l_4a21);
x86_l_572a:
	/* 0x572a: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_5732:
	/* 0x5732: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_5739:
	/* 0x5739: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_573e:
	/* 0x573e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5743:
	/* 0x5743: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5745:
	/* 0x5745: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5748:
	/* 0x5748: je     574f <perf_unwind_dotnet+0x574f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5748, 0x574f, x86_l_574f);
x86_l_574a:
	/* 0x574a: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_574d:
	/* 0x574d: jmp    575f <perf_unwind_dotnet+0x575f> */
	X86_SIM_X86_JMP(0x574d, 0x575f, x86_l_575f);
x86_l_574f:
	/* 0x574f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5756:
	/* 0x5756: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5759:
	/* 0x5759: jne    5dc4 <perf_unwind_dotnet+0x5dc4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5759, 0x5dc4, x86_l_5dc4);
x86_l_575f:
	/* 0x575f: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_5764:
	/* 0x5764: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_5769:
	/* 0x5769: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5770:
	/* 0x5770: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5773:
	/* 0x5773: je     4a6c <perf_unwind_dotnet+0x4a6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5773, 0x4a6c, x86_l_4a6c);
x86_l_5779:
	/* 0x5779: movabs rax,0xa642520687469 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387390569ULL);
x86_l_5783:
	/* 0x5783: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5788:
	/* 0x5788: movabs rax,0x772064656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8583971276541485414ULL);
x86_l_5792:
	/* 0x5792: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5797:
	/* 0x5797: movabs rax,0x2074726174735f65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338619869403242341ULL);
x86_l_57a1:
	/* 0x57a1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_57a6:
	/* 0x57a6: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7237112116340927776ULL);
x86_l_57b0:
	/* 0x57b0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_57b5:
	/* 0x57b5: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_57bf:
	/* 0x57bf: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_57c4:
	/* 0x57c4: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_57c9:
	/* 0x57c9: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_57ce:
	/* 0x57ce: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_57d3:
	/* 0x57d3: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_57d8:
	/* 0x57d8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_57da:
	/* 0x57da: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_57dc:
	/* 0x57dc: jmp    4a6c <perf_unwind_dotnet+0x4a6c> */
	X86_SIM_X86_JMP(0x57dc, 0x4a6c, x86_l_4a6c);
x86_l_57e1:
	/* 0x57e1: movabs rax,0x207972746e65202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2340027325789577260ULL);
x86_l_57eb:
	/* 0x57eb: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_57f0:
	/* 0x57f0: movabs rax,0x6425206465707069 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7216209593501773929ULL);
x86_l_57fa:
	/* 0x57fa: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_57ff:
	/* 0x57ff: movabs rax,0x6b73203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7742567619880559904ULL);
x86_l_5809:
	/* 0x5809: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_580e:
	/* 0x580e: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_5818:
	/* 0x5818: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_581d:
	/* 0x581d: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_5827:
	/* 0x5827: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_582c:
	/* 0x582c: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_5836:
	/* 0x5836: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_583b:
	/* 0x583b: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_5845:
	/* 0x5845: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_584a:
	/* 0x584a: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_5852:
	/* 0x5852: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5857:
	/* 0x5857: mov    eax,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_585c:
	/* 0x585c: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_5862:
	/* 0x5862: mov    esi,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 60ULL);
x86_l_5867:
	/* 0x5867: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_586a:
	/* 0x586a: mov    r8d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_32);
x86_l_586d:
	/* 0x586d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_586f:
	/* 0x586f: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5872:
	/* 0x5872: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_5875:
	/* 0x5875: jne    4a21 <perf_unwind_dotnet+0x4a21> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5875, 0x4a21, x86_l_4a21);
x86_l_587b:
	/* 0x587b: jmp    572a <perf_unwind_dotnet+0x572a> */
	X86_SIM_X86_JMP(0x587b, 0x572a, x86_l_572a);
x86_l_5880:
	/* 0x5880: movabs rax,0xa642520686374 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387386228ULL);
x86_l_588a:
	/* 0x588a: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_588f:
	/* 0x588f: movabs rax,0x6374616d20737465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7166460028377068645ULL);
x86_l_5899:
	/* 0x5899: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_589e:
	/* 0x589e: movabs rax,0x7366666f5f726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315446390514935156ULL);
x86_l_58a8:
	/* 0x58a8: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_58ad:
	/* 0x58ad: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_58b7:
	/* 0x58b7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58bc:
	/* 0x58bc: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58c1:
	/* 0x58c1: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_58c6:
	/* 0x58c6: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_58cb:
	/* 0x58cb: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_58d0:
	/* 0x58d0: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_58d5:
	/* 0x58d5: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_58d7:
	/* 0x58d7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_58d9:
	/* 0x58d9: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_58e0:
	/* 0x58e0: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_58e4:
	/* 0x58e4: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_58e7:
	/* 0x58e7: jb     50eb <perf_unwind_dotnet+0x50eb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x58e7, 0x50eb, x86_l_50eb);
x86_l_58ed:
	/* 0x58ed: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_58f5:
	/* 0x58f5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_58fc:
	/* 0x58fc: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5901:
	/* 0x5901: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5906:
	/* 0x5906: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5908:
	/* 0x5908: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_590b:
	/* 0x590b: je     5912 <perf_unwind_dotnet+0x5912> */
	X86_SIM_X86_JCC(X86_CC_E, 0x590b, 0x5912, x86_l_5912);
x86_l_590d:
	/* 0x590d: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5910:
	/* 0x5910: jmp    5922 <perf_unwind_dotnet+0x5922> */
	X86_SIM_X86_JMP(0x5910, 0x5922, x86_l_5922);
x86_l_5912:
	/* 0x5912: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5919:
	/* 0x5919: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_591c:
	/* 0x591c: jne    5f23 <perf_unwind_dotnet+0x5f23> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x591c, 0x5f23, x86_l_5f23);
x86_l_5922:
	/* 0x5922: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_5927:
	/* 0x5927: cmp    r12d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 8ULL);
x86_l_592b:
	/* 0x592b: jne    8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x592b, 0x8cac, x86_l_8cac);
x86_l_5931:
	/* 0x5931: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_5938:
	/* 0x5938: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_593f:
	/* 0x593f: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_5946:
	/* 0x5946: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_594e:
	/* 0x594e: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_5952:
	/* 0x5952: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5959:
	/* 0x5959: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_595c:
	/* 0x595c: jne    5d20 <perf_unwind_dotnet+0x5d20> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x595c, 0x5d20, x86_l_5d20);
x86_l_5962:
	/* 0x5962: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_5965:
	/* 0x5965: jb     76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5965, 0x76bb, x86_l_76bb);
x86_l_596b:
	/* 0x596b: lea    rax,[rbx+0x2000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_5972:
	/* 0x5972: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_5975:
	/* 0x5975: jae    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5975, 0x76bb, x86_l_76bb);
x86_l_597b:
	/* 0x597b: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5982:
	/* 0x5982: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_5989:
	/* 0x5989: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_598e:
	/* 0x598e: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_5996:
	/* 0x5996: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_5999:
	/* 0x5999: and    rax,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_599d:
	/* 0x599d: cmp    rax,0x80 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_59a3:
	/* 0x59a3: jne    59e7 <perf_unwind_dotnet+0x59e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x59a3, 0x59e7, x86_l_59e7);
x86_l_59a5:
	/* 0x59a5: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_59ac:
	/* 0x59ac: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_59b1:
	/* 0x59b1: mov    r8d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 112ULL);
x86_l_59b7:
	/* 0x59b7: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_59bf:
	/* 0x59bf: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_59c6:
	/* 0x59c6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_59cb:
	/* 0x59cb: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_59ce:
	/* 0x59ce: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_59d1:
	/* 0x59d1: jne    19c <perf_unwind_dotnet+0x19c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x59d1, 0x19c, x86_l_19c);
x86_l_59d7:
	/* 0x59d7: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_59df:
	/* 0x59df: and    ebp,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_59e2:
	/* 0x59e2: jmp    5ff9 <perf_unwind_dotnet+0x5ff9> */
	X86_SIM_X86_JMP(0x59e2, 0x5ff9, x86_l_5ff9);
x86_l_59e7:
	/* 0x59e7: lea    rdi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_59ec:
	/* 0x59ec: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_59f1:
	/* 0x59f1: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_59f6:
	/* 0x59f6: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_59fb:
	/* 0x59fb: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_59fe:
	/* 0x59fe: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5a00:
	/* 0x5a00: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5a03:
	/* 0x5a03: jne    26c <perf_unwind_dotnet+0x26c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5a03, 0x26c, x86_l_26c);
x86_l_5a09:
	/* 0x5a09: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_5a0d:
	/* 0x5a0d: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_5a14:
	/* 0x5a14: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5a19:
	/* 0x5a19: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_5a20:
	/* 0x5a20: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_5a25:
	/* 0x5a25: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_5a2c:
	/* 0x5a2c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5a33:
	/* 0x5a33: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a36:
	/* 0x5a36: jne    5e3f <perf_unwind_dotnet+0x5e3f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5a36, 0x5e3f, x86_l_5e3f);
x86_l_5a3c:
	/* 0x5a3c: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_5a43:
	/* 0x5a43: jb     5ff9 <perf_unwind_dotnet+0x5ff9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5a43, 0x5ff9, x86_l_5ff9);
x86_l_5a49:
	/* 0x5a49: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5a50:
	/* 0x5a50: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_5a57:
	/* 0x5a57: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_5a5a:
	/* 0x5a5a: sub    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_5a5d:
	/* 0x5a5d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5a64:
	/* 0x5a64: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a67:
	/* 0x5a67: jne    5edf <perf_unwind_dotnet+0x5edf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5a67, 0x5edf, x86_l_5edf);
x86_l_5a6d:
	/* 0x5a6d: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_5a70:
	/* 0x5a70: shr    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_5a74:
	/* 0x5a74: mov    ecx,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 127ULL);
x86_l_5a79:
	/* 0x5a79: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5a7b:
	/* 0x5a7b: and    ecx,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_5a7e:
	/* 0x5a7e: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5a80:
	/* 0x5a80: cmp    r13,0x8000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 32768ULL);
x86_l_5a87:
	/* 0x5a87: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_5a8f:
	/* 0x5a8f: cmovb  rdx,rsi */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B);
x86_l_5a93:
	/* 0x5a93: cmovae ecx,esi */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE);
x86_l_5a96:
	/* 0x5a96: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5a99:
	/* 0x5a99: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_5aa1:
	/* 0x5aa1: lea    rdi,[rax+rcx*4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_5aa5:
	/* 0x5aa5: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
x86_l_5aaa:
	/* 0x5aaa: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_5aaf:
	/* 0x5aaf: mov    esi,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 512ULL);
x86_l_5ab4:
	/* 0x5ab4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5ab6:
	/* 0x5ab6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5ab9:
	/* 0x5ab9: je     5af0 <perf_unwind_dotnet+0x5af0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ab9, 0x5af0, x86_l_5af0);
x86_l_5abb:
	/* 0x5abb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5ac2:
	/* 0x5ac2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ac5:
	/* 0x5ac5: jne    5cb1 <perf_unwind_dotnet+0x5cb1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5ac5, 0x5cb1, x86_l_5cb1);
x86_l_5acb:
	/* 0x5acb: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_5ad3:
	/* 0x5ad3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_5ada:
	/* 0x5ada: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5adf:
	/* 0x5adf: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5ae4:
	/* 0x5ae4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5ae6:
	/* 0x5ae6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5ae9:
	/* 0x5ae9: je     5b47 <perf_unwind_dotnet+0x5b47> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ae9, 0x5b47, x86_l_5b47);
x86_l_5aeb:
	/* 0x5aeb: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5aee:
	/* 0x5aee: jmp    5b57 <perf_unwind_dotnet+0x5b57> */
	X86_SIM_X86_JMP(0x5aee, 0x5b57, x86_l_5b57);
x86_l_5af0:
	/* 0x5af0: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_5af7:
	/* 0x5af7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5afe:
	/* 0x5afe: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b01:
	/* 0x5b01: jne    63c6 <perf_unwind_dotnet+0x63c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b01, 0x63c6, x86_l_63c6);
x86_l_5b07:
	/* 0x5b07: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_5b0a:
	/* 0x5b0a: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_5b0c:
	/* 0x5b0c: shr    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_5b0f:
	/* 0x5b0f: and    al,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_5b11:
	/* 0x5b11: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_5b16:
	/* 0x5b16: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_5b19:
	/* 0x5b19: je     5be4 <perf_unwind_dotnet+0x5be4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b19, 0x5be4, x86_l_5be4);
x86_l_5b1f:
	/* 0x5b1f: and    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_5b23:
	/* 0x5b23: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5b26:
	/* 0x5b26: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5b29:
	/* 0x5b29: jne    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b29, 0x5fac, x86_l_5fac);
x86_l_5b2f:
	/* 0x5b2f: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5b32:
	/* 0x5b32: shr    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_5b35:
	/* 0x5b35: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5b38:
	/* 0x5b38: je     5cf4 <perf_unwind_dotnet+0x5cf4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b38, 0x5cf4, x86_l_5cf4);
x86_l_5b3e:
	/* 0x5b3e: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_5b42:
	/* 0x5b42: jmp    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JMP(0x5b42, 0x5fac, x86_l_5fac);
x86_l_5b47:
	/* 0x5b47: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5b4e:
	/* 0x5b4e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b51:
	/* 0x5b51: jne    64d7 <perf_unwind_dotnet+0x64d7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b51, 0x64d7, x86_l_64d7);
x86_l_5b57:
	/* 0x5b57: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_5b5c:
	/* 0x5b5c: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5b5e:
	/* 0x5b5e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5b65:
	/* 0x5b65: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b68:
	/* 0x5b68: jne    6c8d <perf_unwind_dotnet+0x6c8d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b68, 0x6c8d, x86_l_6c8d);
x86_l_5b6e:
	/* 0x5b6e: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_5b73:
	/* 0x5b73: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_5b75:
	/* 0x5b75: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_5b7a:
	/* 0x5b7a: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_5b81:
	/* 0x5b81: je     7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b81, 0x7712, x86_l_7712);
x86_l_5b87:
	/* 0x5b87: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5b8e:
	/* 0x5b8e: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_5b92:
	/* 0x5b92: ja     4f3 <perf_unwind_dotnet+0x4f3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5b92, 0x4f3, x86_l_4f3);
x86_l_5b98:
	/* 0x5b98: lea    ecx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_5b9b:
	/* 0x5b9b: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5ba2:
	/* 0x5ba2: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_5ba6:
	/* 0x5ba6: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_5bb2:
	/* 0x5bb2: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_5bbe:
	/* 0x5bbe: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_5bc7:
	/* 0x5bc7: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_5bd3:
	/* 0x5bd3: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_5bdf:
	/* 0x5bdf: jmp    60a9 <perf_unwind_dotnet+0x60a9> */
	X86_SIM_X86_JMP(0x5bdf, 0x60a9, x86_l_60a9);
x86_l_5be4:
	/* 0x5be4: and    r13,0xffffffffffffff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_5beb:
	/* 0x5beb: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_5bef:
	/* 0x5bef: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_5bf6:
	/* 0x5bf6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5bfd:
	/* 0x5bfd: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c00:
	/* 0x5c00: jne    6667 <perf_unwind_dotnet+0x6667> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c00, 0x6667, x86_l_6667);
x86_l_5c06:
	/* 0x5c06: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c08:
	/* 0x5c08: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_5c0b:
	/* 0x5c0b: je     66fb <perf_unwind_dotnet+0x66fb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c0b, 0x66fb, x86_l_66fb);
x86_l_5c11:
	/* 0x5c11: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_5c13:
	/* 0x5c13: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_5c16:
	/* 0x5c16: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_5c19:
	/* 0x5c19: jae    6c25 <perf_unwind_dotnet+0x6c25> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5c19, 0x6c25, x86_l_6c25);
x86_l_5c1f:
	/* 0x5c1f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5c26:
	/* 0x5c26: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c29:
	/* 0x5c29: je     5acb <perf_unwind_dotnet+0x5acb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c29, 0x5acb, x86_l_5acb);
x86_l_5c2f:
	/* 0x5c2f: movabs rax,0xa657361625f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2926295996587875ULL);
x86_l_5c39:
	/* 0x5c39: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5c3e:
	/* 0x5c3e: movabs rax,0x5f637020776f6c65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460741042564197ULL);
x86_l_5c48:
	/* 0x5c48: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5c4d:
	/* 0x5c4d: movabs rax,0x6220746e65772068 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7070779432469209192ULL);
x86_l_5c57:
	/* 0x5c57: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5c5c:
	/* 0x5c5c: movabs rax,0x6372616573207061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165897045450977377ULL);
x86_l_5c66:
	/* 0x5c66: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5c6b:
	/* 0x5c6b: movabs rax,0x6d20656c6262696e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7863396465570376046ULL);
x86_l_5c75:
	/* 0x5c75: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5c7a:
	/* 0x5c7a: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_5c84:
	/* 0x5c84: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c89:
	/* 0x5c89: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c8e:
	/* 0x5c8e: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_5c93:
	/* 0x5c93: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_5c98:
	/* 0x5c98: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_5c9d:
	/* 0x5c9d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c9f:
	/* 0x5c9f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5ca1:
	/* 0x5ca1: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5ca8:
	/* 0x5ca8: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5cab:
	/* 0x5cab: je     5acb <perf_unwind_dotnet+0x5acb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5cab, 0x5acb, x86_l_5acb);
x86_l_5cb1:
	/* 0x5cb1: movabs rax,0x6e756f6620746f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959390400869068654ULL);
x86_l_5cbb:
	/* 0x5cbb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5cc0:
	/* 0x5cc0: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_5cca:
	/* 0x5cca: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5ccf:
	/* 0x5ccf: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_5cd7:
	/* 0x5cd7: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5cdc:
	/* 0x5cdc: mov    eax,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_5ce1:
	/* 0x5ce1: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_5ce6:
	/* 0x5ce6: mov    esi,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 19ULL);
x86_l_5ceb:
	/* 0x5ceb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5ced:
	/* 0x5ced: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5cef:
	/* 0x5cef: jmp    5acb <perf_unwind_dotnet+0x5acb> */
	X86_SIM_X86_JMP(0x5cef, 0x5acb, x86_l_5acb);
x86_l_5cf4:
	/* 0x5cf4: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5cf7:
	/* 0x5cf7: shr    ecx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_5cfa:
	/* 0x5cfa: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5cfd:
	/* 0x5cfd: je     5d08 <perf_unwind_dotnet+0x5d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5cfd, 0x5d08, x86_l_5d08);
x86_l_5cff:
	/* 0x5cff: add    r13,0xffffffffffffffc0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_5d03:
	/* 0x5d03: jmp    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JMP(0x5d03, 0x5fac, x86_l_5fac);
x86_l_5d08:
	/* 0x5d08: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5d0b:
	/* 0x5d0b: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_5d0e:
	/* 0x5d0e: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5d11:
	/* 0x5d11: je     5d95 <perf_unwind_dotnet+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d11, 0x5d95, x86_l_5d95);
x86_l_5d17:
	/* 0x5d17: add    r13,0xffffffffffffffa0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_5d1b:
	/* 0x5d1b: jmp    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JMP(0x5d1b, 0x5fac, x86_l_5fac);
x86_l_5d20:
	/* 0x5d20: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_5d2a:
	/* 0x5d2a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5d2f:
	/* 0x5d2f: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_5d39:
	/* 0x5d39: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5d3e:
	/* 0x5d3e: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_5d48:
	/* 0x5d48: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5d4d:
	/* 0x5d4d: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_5d57:
	/* 0x5d57: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5d5c:
	/* 0x5d5c: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_5d64:
	/* 0x5d64: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5d69:
	/* 0x5d69: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_5d6e:
	/* 0x5d6e: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_5d74:
	/* 0x5d74: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_5d79:
	/* 0x5d79: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_5d7c:
	/* 0x5d7c: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_5d7f:
	/* 0x5d7f: mov    r8,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R13, X86_WIDTH_64);
x86_l_5d82:
	/* 0x5d82: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d84:
	/* 0x5d84: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5d87:
	/* 0x5d87: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_5d8a:
	/* 0x5d8a: jae    596b <perf_unwind_dotnet+0x596b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5d8a, 0x596b, x86_l_596b);
x86_l_5d90:
	/* 0x5d90: jmp    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JMP(0x5d90, 0x76bb, x86_l_76bb);
x86_l_5d95:
	/* 0x5d95: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5d98:
	/* 0x5d98: shr    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_5d9b:
	/* 0x5d9b: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5d9e:
	/* 0x5d9e: je     5da9 <perf_unwind_dotnet+0x5da9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d9e, 0x5da9, x86_l_5da9);
x86_l_5da0:
	/* 0x5da0: add    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_5da4:
	/* 0x5da4: jmp    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JMP(0x5da4, 0x5fac, x86_l_5fac);
x86_l_5da9:
	/* 0x5da9: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5dac:
	/* 0x5dac: shr    ecx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_5daf:
	/* 0x5daf: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5db2:
	/* 0x5db2: je     5ec4 <perf_unwind_dotnet+0x5ec4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5db2, 0x5ec4, x86_l_5ec4);
x86_l_5db8:
	/* 0x5db8: add    r13,0xffffffffffffff60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_5dbf:
	/* 0x5dbf: jmp    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JMP(0x5dbf, 0x5fac, x86_l_5fac);
x86_l_5dc4:
	/* 0x5dc4: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_5dce:
	/* 0x5dce: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5dd3:
	/* 0x5dd3: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_5ddd:
	/* 0x5ddd: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5de2:
	/* 0x5de2: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_5dec:
	/* 0x5dec: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5df1:
	/* 0x5df1: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_5dfb:
	/* 0x5dfb: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5e00:
	/* 0x5e00: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_5e0a:
	/* 0x5e0a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5e0f:
	/* 0x5e0f: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_5e19:
	/* 0x5e19: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e1e:
	/* 0x5e1e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e23:
	/* 0x5e23: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_5e28:
	/* 0x5e28: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_5e2d:
	/* 0x5e2d: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5e31:
	/* 0x5e31: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_5e36:
	/* 0x5e36: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e38:
	/* 0x5e38: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5e3a:
	/* 0x5e3a: jmp    575f <perf_unwind_dotnet+0x575f> */
	X86_SIM_X86_JMP(0x5e3a, 0x575f, x86_l_575f);
x86_l_5e3f:
	/* 0x5e3f: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_5e49:
	/* 0x5e49: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5e4e:
	/* 0x5e4e: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_5e58:
	/* 0x5e58: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5e5d:
	/* 0x5e5d: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_5e67:
	/* 0x5e67: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5e6c:
	/* 0x5e6c: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_5e76:
	/* 0x5e76: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e7b:
	/* 0x5e7b: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_5e83:
	/* 0x5e83: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e88:
	/* 0x5e88: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_5e8d:
	/* 0x5e8d: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_5e93:
	/* 0x5e93: mov    rdx,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_5e9a:
	/* 0x5e9a: mov    rcx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_5ea1:
	/* 0x5ea1: mov    r8,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_5ea8:
	/* 0x5ea8: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_5ead:
	/* 0x5ead: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5eaf:
	/* 0x5eaf: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5eb2:
	/* 0x5eb2: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_5eb9:
	/* 0x5eb9: jae    5a49 <perf_unwind_dotnet+0x5a49> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5eb9, 0x5a49, x86_l_5a49);
x86_l_5ebf:
	/* 0x5ebf: jmp    5ff9 <perf_unwind_dotnet+0x5ff9> */
	X86_SIM_X86_JMP(0x5ebf, 0x5ff9, x86_l_5ff9);
x86_l_5ec4:
	/* 0x5ec4: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5ec7:
	/* 0x5ec7: shr    ecx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_5eca:
	/* 0x5eca: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5ecd:
	/* 0x5ecd: je     5f9e <perf_unwind_dotnet+0x5f9e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ecd, 0x5f9e, x86_l_5f9e);
x86_l_5ed3:
	/* 0x5ed3: add    r13,0xffffffffffffff40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_5eda:
	/* 0x5eda: jmp    5fac <perf_unwind_dotnet+0x5fac> */
	X86_SIM_X86_JMP(0x5eda, 0x5fac, x86_l_5fac);
x86_l_5edf:
	/* 0x5edf: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_5ee6:
	/* 0x5ee6: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5eeb:
	/* 0x5eeb: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_5ef0:
	/* 0x5ef0: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_5ef3:
	/* 0x5ef3: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_5ef6:
	/* 0x5ef6: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_5efd:
	/* 0x5efd: mov    ecx,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 66ULL);
x86_l_5f02:
	/* 0x5f02: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_5f08:
	/* 0x5f08: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_5f0b:
	/* 0x5f0b: mov    esi,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 66ULL);
x86_l_5f10:
	/* 0x5f10: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_5f13:
	/* 0x5f13: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_5f16:
	/* 0x5f16: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_5f19:
	/* 0x5f19: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5f1b:
	/* 0x5f1b: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5f1e:
	/* 0x5f1e: jmp    5a6d <perf_unwind_dotnet+0x5a6d> */
	X86_SIM_X86_JMP(0x5f1e, 0x5a6d, x86_l_5a6d);
x86_l_5f23:
	/* 0x5f23: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_5f2d:
	/* 0x5f2d: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5f32:
	/* 0x5f32: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_5f3c:
	/* 0x5f3c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5f41:
	/* 0x5f41: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_5f4b:
	/* 0x5f4b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5f50:
	/* 0x5f50: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_5f5a:
	/* 0x5f5a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f5f:
	/* 0x5f5f: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_5f69:
	/* 0x5f69: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5f6e:
	/* 0x5f6e: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_5f78:
	/* 0x5f78: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f7d:
	/* 0x5f7d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f82:
	/* 0x5f82: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_5f87:
	/* 0x5f87: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_5f8c:
	/* 0x5f8c: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5f90:
	/* 0x5f90: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_5f95:
	/* 0x5f95: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5f97:
	/* 0x5f97: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5f99:
	/* 0x5f99: jmp    5922 <perf_unwind_dotnet+0x5922> */
	X86_SIM_X86_JMP(0x5f99, 0x5922, x86_l_5922);
x86_l_5f9e:
	/* 0x5f9e: shr    r15d,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_5fa2:
	/* 0x5fa2: add    r13,0xffffffffffffff20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_5fa9:
	/* 0x5fa9: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_5fac:
	/* 0x5fac: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5faf:
	/* 0x5faf: lea    r15d,[rcx*4-0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 18446744073709551612ULL);
x86_l_5fb7:
	/* 0x5fb7: add    r15,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5fba:
	/* 0x5fba: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_5fc1:
	/* 0x5fc1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5fc4:
	/* 0x5fc4: jne    6458 <perf_unwind_dotnet+0x6458> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5fc4, 0x6458, x86_l_6458);
x86_l_5fca:
	/* 0x5fca: lea    rdx,[r15-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_5fce:
	/* 0x5fce: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5fd3:
	/* 0x5fd3: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_5fd8:
	/* 0x5fd8: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_5fdd:
	/* 0x5fdd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5fe2:
	/* 0x5fe2: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5fe4:
	/* 0x5fe4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5fe7:
	/* 0x5fe7: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_5fee:
	/* 0x5fee: jne    b73 <perf_unwind_dotnet+0xb73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5fee, 0xb73, x86_l_b73);
x86_l_5ff4:
	/* 0x5ff4: mov    ebp,0x1f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 31ULL);
x86_l_5ff9:
	/* 0x5ff9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_6000:
	/* 0x6000: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6003:
	/* 0x6003: jne    624f <perf_unwind_dotnet+0x624f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6003, 0x624f, x86_l_624f);
x86_l_6009:
	/* 0x6009: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6010:
	/* 0x6010: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_6014:
	/* 0x6014: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6014, 0xbc9, x86_l_bc9);
x86_l_601a:
	/* 0x601a: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_601f:
	/* 0x601f: sub    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_6022:
	/* 0x6022: shl    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_6026:
	/* 0x6026: add    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_6029:
	/* 0x6029: lea    edx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_602c:
	/* 0x602c: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6033:
	/* 0x6033: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_6037:
	/* 0x6037: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_603f:
	/* 0x603f: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_6047:
	/* 0x6047: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_6050:
	/* 0x6050: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_6055:
	/* 0x6055: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_605d:
	/* 0x605d: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_6069:
	/* 0x6069: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_6074:
	/* 0x6074: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_607c:
	/* 0x607c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_6083:
	/* 0x6083: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6088:
	/* 0x6088: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_608d:
	/* 0x608d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_608f:
	/* 0x608f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6092:
	/* 0x6092: je     6099 <perf_unwind_dotnet+0x6099> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6092, 0x6099, x86_l_6099);
x86_l_6094:
	/* 0x6094: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6097:
	/* 0x6097: jmp    60a9 <perf_unwind_dotnet+0x60a9> */
	X86_SIM_X86_JMP(0x6097, 0x60a9, x86_l_60a9);
x86_l_6099:
	/* 0x6099: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_60a0:
	/* 0x60a0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60a3:
	/* 0x60a3: jne    634b <perf_unwind_dotnet+0x634b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x60a3, 0x634b, x86_l_634b);
x86_l_60a9:
	/* 0x60a9: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_60b1:
	/* 0x60b1: mov    r13,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60b4:
	/* 0x60b4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_60bb:
	/* 0x60bb: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60bd:
	/* 0x60bd: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_60c0:
	/* 0x60c0: je     87f5 <perf_unwind_dotnet+0x87f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60c0, 0x87f5, x86_l_87f5);
x86_l_60c6:
	/* 0x60c6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_60c8:
	/* 0x60c8: jne    62ae <perf_unwind_dotnet+0x62ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x60c8, 0x62ae, x86_l_62ae);
x86_l_60ce:
	/* 0x60ce: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_60d8:
	/* 0x60d8: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_60db:
	/* 0x60db: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x60db, 0x24b3, x86_l_24b3);
x86_l_60e1:
	/* 0x60e1: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_60e8:
	/* 0x60e8: jb     264e <perf_unwind_dotnet+0x264e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x60e8, 0x264e, x86_l_264e);
x86_l_60ee:
	/* 0x60ee: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60f1:
	/* 0x60f1: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_60f9:
	/* 0x60f9: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_60ff:
	/* 0x60ff: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_6106:
	/* 0x6106: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&pid_page_to_mapping_info));
x86_l_610d:
	/* 0x610d: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6112:
	/* 0x6112: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_6117:
	/* 0x6117: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6119:
	/* 0x6119: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_611c:
	/* 0x611c: je     8740 <perf_unwind_dotnet+0x8740> */
	X86_SIM_X86_JCC(X86_CC_E, 0x611c, 0x8740, x86_l_8740);
x86_l_6122:
	/* 0x6122: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6126:
	/* 0x6126: mov    rcx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R12, X86_WIDTH_64);
x86_l_6129:
	/* 0x6129: movabs rdx,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_6133:
	/* 0x6133: and    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND);
x86_l_6136:
	/* 0x6136: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_613d:
	/* 0x613d: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6140:
	/* 0x6140: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_6147:
	/* 0x6147: shr    r12,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_614b:
	/* 0x614b: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_614e:
	/* 0x614e: sub    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_6151:
	/* 0x6151: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_6158:
	/* 0x6158: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_615f:
	/* 0x615f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6162:
	/* 0x6162: jne    6552 <perf_unwind_dotnet+0x6552> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6162, 0x6552, x86_l_6552);
x86_l_6168:
	/* 0x6168: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_616c:
	/* 0x616c: jne    7252 <perf_unwind_dotnet+0x7252> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x616c, 0x7252, x86_l_7252);
x86_l_6172:
	/* 0x6172: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_6179:
	/* 0x6179: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_617e:
	/* 0x617e: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_6185:
	/* 0x6185: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&interpreter_offsets));
x86_l_618c:
	/* 0x618c: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6191:
	/* 0x6191: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_6196:
	/* 0x6196: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6198:
	/* 0x6198: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_619e:
	/* 0x619e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_61a1:
	/* 0x61a1: je     7252 <perf_unwind_dotnet+0x7252> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61a1, 0x7252, x86_l_7252);
x86_l_61a7:
	/* 0x61a7: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_61aa:
	/* 0x61aa: cmp    QWORD PTR [rax],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61ad:
	/* 0x61ad: ja     61b5 <perf_unwind_dotnet+0x61b5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x61ad, 0x61b5, x86_l_61b5);
x86_l_61af:
	/* 0x61af: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_61b3:
	/* 0x61b3: jae    61c9 <perf_unwind_dotnet+0x61c9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x61b3, 0x61c9, x86_l_61c9);
x86_l_61b5:
	/* 0x61b5: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_61b9:
	/* 0x61b9: ja     7252 <perf_unwind_dotnet+0x7252> */
	X86_SIM_X86_JCC(X86_CC_A, 0x61b9, 0x7252, x86_l_7252);
x86_l_61bf:
	/* 0x61bf: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_61c3:
	/* 0x61c3: jb     7252 <perf_unwind_dotnet+0x7252> */
	X86_SIM_X86_JCC(X86_CC_B, 0x61c3, 0x7252, x86_l_7252);
x86_l_61c9:
	/* 0x61c9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_61d0:
	/* 0x61d0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61d3:
	/* 0x61d3: jne    71ab <perf_unwind_dotnet+0x71ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x61d3, 0x71ab, x86_l_71ab);
x86_l_61d9:
	/* 0x61d9: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_61e0:
	/* 0x61e0: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_61e4:
	/* 0x61e4: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_61e7:
	/* 0x61e7: jae    7218 <perf_unwind_dotnet+0x7218> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x61e7, 0x7218, x86_l_7218);
x86_l_61ed:
	/* 0x61ed: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_61f4:
	/* 0x61f4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61f7:
	/* 0x61f7: je     7252 <perf_unwind_dotnet+0x7252> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61f7, 0x7252, x86_l_7252);
x86_l_61fd:
	/* 0x61fd: movabs rax,0x6e6f64207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7957689157107934318ULL);
x86_l_6207:
	/* 0x6207: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_620c:
	/* 0x620c: movabs rax,0x69776e7520726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345545598324ULL);
x86_l_6216:
	/* 0x6216: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_621b:
	/* 0x621b: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_6225:
	/* 0x6225: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_622a:
	/* 0x622a: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_6232:
	/* 0x6232: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6237:
	/* 0x6237: mov    eax,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_623c:
	/* 0x623c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_6241:
	/* 0x6241: mov    esi,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 27ULL);
x86_l_6246:
	/* 0x6246: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6248:
	/* 0x6248: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_624a:
	/* 0x624a: jmp    7252 <perf_unwind_dotnet+0x7252> */
	X86_SIM_X86_JMP(0x624a, 0x7252, x86_l_7252);
x86_l_624f:
	/* 0x624f: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_6256:
	/* 0x6256: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_625b:
	/* 0x625b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_6260:
	/* 0x6260: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_6263:
	/* 0x6263: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_6266:
	/* 0x6266: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_626b:
	/* 0x626b: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_6272:
	/* 0x6272: mov    ecx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 67ULL);
x86_l_6277:
	/* 0x6277: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_627d:
	/* 0x627d: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_6282:
	/* 0x6282: mov    r8,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_64);
x86_l_6285:
	/* 0x6285: sub    r8,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_6288:
	/* 0x6288: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_628b:
	/* 0x628b: mov    esi,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 67ULL);
x86_l_6290:
	/* 0x6290: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_6293:
	/* 0x6293: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6295:
	/* 0x6295: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6298:
	/* 0x6298: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_629f:
	/* 0x629f: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_62a3:
	/* 0x62a3: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x62a3, 0xbc9, x86_l_bc9);
x86_l_62a9:
	/* 0x62a9: jmp    601a <perf_unwind_dotnet+0x601a> */
	X86_SIM_X86_JMP(0x62a9, 0x601a, x86_l_601a);
x86_l_62ae:
	/* 0x62ae: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 737813247186461733ULL);
x86_l_62b8:
	/* 0x62b8: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_62bd:
	/* 0x62bd: movabs rax,0x20656d617266203a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021050ULL);
x86_l_62c7:
	/* 0x62c7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_62cc:
	/* 0x62cc: movabs rax,0x7265646e69776e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243105118350175861ULL);
x86_l_62d6:
	/* 0x62d6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_62db:
	/* 0x62db: movabs rax,0x20656d6172662074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021108ULL);
x86_l_62e5:
	/* 0x62e5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_62ea:
	/* 0x62ea: movabs rax,0x78656e2065766c6f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8675461342619397231ULL);
x86_l_62f4:
	/* 0x62f4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_62f9:
	/* 0x62f9: movabs rax,0x736552203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315142585429343549ULL);
x86_l_6303:
	/* 0x6303: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6308:
	/* 0x6308: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_630d:
	/* 0x630d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6312:
	/* 0x6312: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_6317:
	/* 0x6317: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_631c:
	/* 0x631c: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6323:
	/* 0x6323: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_6328:
	/* 0x6328: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_632a:
	/* 0x632a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_632c:
	/* 0x632c: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_6333:
	/* 0x6333: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_633d:
	/* 0x633d: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_6340:
	/* 0x6340: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6340, 0x24b3, x86_l_24b3);
x86_l_6346:
	/* 0x6346: jmp    60e1 <perf_unwind_dotnet+0x60e1> */
	X86_SIM_X86_JMP(0x6346, 0x60e1, x86_l_60e1);
x86_l_634b:
	/* 0x634b: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_6355:
	/* 0x6355: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_635a:
	/* 0x635a: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_6364:
	/* 0x6364: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6369:
	/* 0x6369: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_6373:
	/* 0x6373: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6378:
	/* 0x6378: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_6382:
	/* 0x6382: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6387:
	/* 0x6387: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_6391:
	/* 0x6391: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6396:
	/* 0x6396: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_63a0:
	/* 0x63a0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_63a5:
	/* 0x63a5: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_63aa:
	/* 0x63aa: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_63af:
	/* 0x63af: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_63b4:
	/* 0x63b4: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_63b8:
	/* 0x63b8: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_63bd:
	/* 0x63bd: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_63bf:
	/* 0x63bf: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_63c1:
	/* 0x63c1: jmp    60a9 <perf_unwind_dotnet+0x60a9> */
	X86_SIM_X86_JMP(0x63c1, 0x60a9, x86_l_60a9);
x86_l_63c6:
	/* 0x63c6: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_63c9:
	/* 0x63c9: and    rdx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_63cd:
	/* 0x63cd: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_63d7:
	/* 0x63d7: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_63dc:
	/* 0x63dc: movabs rax,0x72746e6520747372 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8247338198237475698ULL);
x86_l_63e6:
	/* 0x63e6: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_63eb:
	/* 0x63eb: movabs rax,0x6966203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7594793257107465504ULL);
x86_l_63f5:
	/* 0x63f5: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_63fa:
	/* 0x63fa: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_6404:
	/* 0x6404: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6409:
	/* 0x6409: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_6413:
	/* 0x6413: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6418:
	/* 0x6418: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_6422:
	/* 0x6422: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6427:
	/* 0x6427: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_6431:
	/* 0x6431: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6436:
	/* 0x6436: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_643b:
	/* 0x643b: mov    eax,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 54ULL);
x86_l_6440:
	/* 0x6440: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_6446:
	/* 0x6446: mov    esi,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 54ULL);
x86_l_644b:
	/* 0x644b: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_644e:
	/* 0x644e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6450:
	/* 0x6450: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6453:
	/* 0x6453: jmp    5b07 <perf_unwind_dotnet+0x5b07> */
	X86_SIM_X86_JMP(0x6453, 0x5b07, x86_l_5b07);
x86_l_6458:
	/* 0x6458: movabs rax,0xa786c253d7465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155643692133ULL);
x86_l_6462:
	/* 0x6462: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_6467:
	/* 0x6467: movabs rax,0x746572202c78253d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8387235363558008125ULL);
x86_l_6471:
	/* 0x6471: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6476:
	/* 0x6476: movabs rax,0x6c6176202c786c25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809653109394271269ULL);
x86_l_6480:
	/* 0x6480: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6485:
	/* 0x6485: movabs rax,0x203d2061746c6564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2323048585730221412ULL);
x86_l_648f:
	/* 0x648f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6494:
	/* 0x6494: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460740081921312ULL);
x86_l_649e:
	/* 0x649e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_64a3:
	/* 0x64a3: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_64ad:
	/* 0x64ad: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_64b2:
	/* 0x64b2: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_64b7:
	/* 0x64b7: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_64bc:
	/* 0x64bc: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_64c2:
	/* 0x64c2: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_64c7:
	/* 0x64c7: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_64ca:
	/* 0x64ca: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_64cd:
	/* 0x64cd: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_64cf:
	/* 0x64cf: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_64d2:
	/* 0x64d2: jmp    5fca <perf_unwind_dotnet+0x5fca> */
	X86_SIM_X86_JMP(0x64d2, 0x5fca, x86_l_5fca);
x86_l_64d7:
	/* 0x64d7: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_64e1:
	/* 0x64e1: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_64e6:
	/* 0x64e6: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_64f0:
	/* 0x64f0: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_64f5:
	/* 0x64f5: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_64ff:
	/* 0x64ff: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6504:
	/* 0x6504: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_650e:
	/* 0x650e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6513:
	/* 0x6513: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_651d:
	/* 0x651d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6522:
	/* 0x6522: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_652c:
	/* 0x652c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6531:
	/* 0x6531: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6536:
	/* 0x6536: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_653b:
	/* 0x653b: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_6540:
	/* 0x6540: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6544:
	/* 0x6544: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_6549:
	/* 0x6549: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_654b:
	/* 0x654b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_654d:
	/* 0x654d: jmp    5b57 <perf_unwind_dotnet+0x5b57> */
	X86_SIM_X86_JMP(0x654d, 0x5b57, x86_l_5b57);
x86_l_6552:
	/* 0x6552: movabs rax,0x296425207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2982549674514539630ULL);
x86_l_655c:
	/* 0x655c: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_6561:
	/* 0x6561: movabs rax,0x69776e752820786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345674446956ULL);
x86_l_656b:
	/* 0x656b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6570:
	/* 0x6570: movabs rax,0x6c2520736920786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670410291574892ULL);
x86_l_657a:
	/* 0x657a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_657f:
	/* 0x657f: movabs rax,0x2520435020726f66 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675212190078889830ULL);
x86_l_6589:
	/* 0x6589: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_658e:
	/* 0x658e: movabs rax,0x206469206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334106094897424756ULL);
x86_l_6598:
	/* 0x6598: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_659d:
	/* 0x659d: movabs rbx,0x6365732074786554 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 7162257365632836948ULL);
x86_l_65a7:
	/* 0x65a7: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_65ac:
	/* 0x65ac: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_65b3:
	/* 0x65b3: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_65b8:
	/* 0x65b8: mov    eax,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_65bd:
	/* 0x65bd: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_65c3:
	/* 0x65c3: mov    rcx,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_65ca:
	/* 0x65ca: mov    esi,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 50ULL);
x86_l_65cf:
	/* 0x65cf: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_65d2:
	/* 0x65d2: mov    r8d,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_32);
x86_l_65d5:
	/* 0x65d5: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_65d7:
	/* 0x65d7: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_65da:
	/* 0x65da: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_65e1:
	/* 0x65e1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_65e4:
	/* 0x65e4: je     6168 <perf_unwind_dotnet+0x6168> */
	X86_SIM_X86_JCC(X86_CC_E, 0x65e4, 0x6168, x86_l_6168);
x86_l_65ea:
	/* 0x65ea: movabs rax,0xa786c6c252073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947156833280115ULL);
x86_l_65f4:
	/* 0x65f4: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_65f9:
	/* 0x65f9: movabs rax,0x7369207465736666 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8316213871206688358ULL);
x86_l_6603:
	/* 0x6603: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6608:
	/* 0x6608: movabs rax,0x6f20646e61202c78 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8007510562703420536ULL);
x86_l_6612:
	/* 0x6612: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6617:
	/* 0x6617: movabs rax,0x6c6c252073692073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7812660274886418547ULL);
x86_l_6621:
	/* 0x6621: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6626:
	/* 0x6626: movabs rax,0x616962206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7019249385664899444ULL);
x86_l_6630:
	/* 0x6630: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6635:
	/* 0x6635: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_663a:
	/* 0x663a: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_663f:
	/* 0x663f: mov    eax,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 47ULL);
x86_l_6644:
	/* 0x6644: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_664a:
	/* 0x664a: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_6651:
	/* 0x6651: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_6658:
	/* 0x6658: mov    esi,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 47ULL);
x86_l_665d:
	/* 0x665d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_665f:
	/* 0x665f: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6662:
	/* 0x6662: jmp    6168 <perf_unwind_dotnet+0x6168> */
	X86_SIM_X86_JMP(0x6662, 0x6168, x86_l_6168);
x86_l_6667:
	/* 0x6667: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_6671:
	/* 0x6671: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_6676:
	/* 0x6676: movabs rax,0x746e6520646e6f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8389754345636130659ULL);
x86_l_6680:
	/* 0x6680: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_6685:
	/* 0x6685: movabs rax,0x6573203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310222055652992288ULL);
x86_l_668f:
	/* 0x668f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6694:
	/* 0x6694: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_669e:
	/* 0x669e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_66a3:
	/* 0x66a3: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_66ad:
	/* 0x66ad: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_66b2:
	/* 0x66b2: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_66bc:
	/* 0x66bc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_66c1:
	/* 0x66c1: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_66cb:
	/* 0x66cb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_66d0:
	/* 0x66d0: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_66d5:
	/* 0x66d5: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_66da:
	/* 0x66da: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_66e0:
	/* 0x66e0: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_66e5:
	/* 0x66e5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_66e8:
	/* 0x66e8: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_66eb:
	/* 0x66eb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_66ed:
	/* 0x66ed: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_66f0:
	/* 0x66f0: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_66f2:
	/* 0x66f2: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_66f5:
	/* 0x66f5: jne    5c11 <perf_unwind_dotnet+0x5c11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x66f5, 0x5c11, x86_l_5c11);
x86_l_66fb:
	/* 0x66fb: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_6702:
	/* 0x6702: mov    ecx,0xffffff84 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967172ULL);
x86_l_6707:
	/* 0x6707: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_670a:
	/* 0x670a: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x670a, 0x6c02, x86_l_6c02);
x86_l_6710:
	/* 0x6710: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_6717:
	/* 0x6717: mov    ecx,0xffffff86 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967174ULL);
x86_l_671c:
	/* 0x671c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_671f:
	/* 0x671f: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x671f, 0x6c02, x86_l_6c02);
x86_l_6725:
	/* 0x6725: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_672c:
	/* 0x672c: mov    ecx,0xffffff88 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967176ULL);
x86_l_6731:
	/* 0x6731: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6734:
	/* 0x6734: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6734, 0x6c02, x86_l_6c02);
x86_l_673a:
	/* 0x673a: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_6741:
	/* 0x6741: mov    ecx,0xffffff8a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967178ULL);
x86_l_6746:
	/* 0x6746: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6749:
	/* 0x6749: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6749, 0x6c02, x86_l_6c02);
x86_l_674f:
	/* 0x674f: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_6756:
	/* 0x6756: mov    ecx,0xffffff8c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967180ULL);
x86_l_675b:
	/* 0x675b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_675e:
	/* 0x675e: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x675e, 0x6c02, x86_l_6c02);
x86_l_6764:
	/* 0x6764: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_676b:
	/* 0x676b: mov    ecx,0xffffff8e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967182ULL);
x86_l_6770:
	/* 0x6770: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6773:
	/* 0x6773: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6773, 0x6c02, x86_l_6c02);
x86_l_6779:
	/* 0x6779: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_6780:
	/* 0x6780: mov    ecx,0xffffff90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967184ULL);
x86_l_6785:
	/* 0x6785: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6788:
	/* 0x6788: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6788, 0x6c02, x86_l_6c02);
x86_l_678e:
	/* 0x678e: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_6795:
	/* 0x6795: mov    ecx,0xffffff92 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967186ULL);
x86_l_679a:
	/* 0x679a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_679d:
	/* 0x679d: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x679d, 0x6c02, x86_l_6c02);
x86_l_67a3:
	/* 0x67a3: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_67aa:
	/* 0x67aa: mov    ecx,0xffffff94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967188ULL);
x86_l_67af:
	/* 0x67af: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_67b2:
	/* 0x67b2: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67b2, 0x6c02, x86_l_6c02);
x86_l_67b8:
	/* 0x67b8: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_67bf:
	/* 0x67bf: mov    ecx,0xffffff96 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967190ULL);
x86_l_67c4:
	/* 0x67c4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_67c7:
	/* 0x67c7: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67c7, 0x6c02, x86_l_6c02);
x86_l_67cd:
	/* 0x67cd: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_67d4:
	/* 0x67d4: mov    ecx,0xffffff98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967192ULL);
x86_l_67d9:
	/* 0x67d9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_67dc:
	/* 0x67dc: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67dc, 0x6c02, x86_l_6c02);
x86_l_67e2:
	/* 0x67e2: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_67e9:
	/* 0x67e9: mov    ecx,0xffffff9a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967194ULL);
x86_l_67ee:
	/* 0x67ee: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_67f1:
	/* 0x67f1: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67f1, 0x6c02, x86_l_6c02);
x86_l_67f7:
	/* 0x67f7: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_67fe:
	/* 0x67fe: mov    ecx,0xffffff9c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967196ULL);
x86_l_6803:
	/* 0x6803: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6806:
	/* 0x6806: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6806, 0x6c02, x86_l_6c02);
x86_l_680c:
	/* 0x680c: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_6813:
	/* 0x6813: mov    ecx,0xffffff9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967198ULL);
x86_l_6818:
	/* 0x6818: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_681b:
	/* 0x681b: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x681b, 0x6c02, x86_l_6c02);
x86_l_6821:
	/* 0x6821: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_6828:
	/* 0x6828: mov    ecx,0xffffffa0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967200ULL);
x86_l_682d:
	/* 0x682d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6830:
	/* 0x6830: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6830, 0x6c02, x86_l_6c02);
x86_l_6836:
	/* 0x6836: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_683d:
	/* 0x683d: mov    ecx,0xffffffa2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967202ULL);
x86_l_6842:
	/* 0x6842: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6845:
	/* 0x6845: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6845, 0x6c02, x86_l_6c02);
x86_l_684b:
	/* 0x684b: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_6852:
	/* 0x6852: mov    ecx,0xffffffa4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967204ULL);
x86_l_6857:
	/* 0x6857: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_685a:
	/* 0x685a: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x685a, 0x6c02, x86_l_6c02);
x86_l_6860:
	/* 0x6860: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_6867:
	/* 0x6867: mov    ecx,0xffffffa6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967206ULL);
x86_l_686c:
	/* 0x686c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_686f:
	/* 0x686f: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x686f, 0x6c02, x86_l_6c02);
x86_l_6875:
	/* 0x6875: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_687c:
	/* 0x687c: mov    ecx,0xffffffa8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967208ULL);
x86_l_6881:
	/* 0x6881: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6884:
	/* 0x6884: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6884, 0x6c02, x86_l_6c02);
x86_l_688a:
	/* 0x688a: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_6891:
	/* 0x6891: mov    ecx,0xffffffaa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967210ULL);
x86_l_6896:
	/* 0x6896: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6899:
	/* 0x6899: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6899, 0x6c02, x86_l_6c02);
x86_l_689f:
	/* 0x689f: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_68a6:
	/* 0x68a6: mov    ecx,0xffffffac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967212ULL);
x86_l_68ab:
	/* 0x68ab: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_68ae:
	/* 0x68ae: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68ae, 0x6c02, x86_l_6c02);
x86_l_68b4:
	/* 0x68b4: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_68bb:
	/* 0x68bb: mov    ecx,0xffffffae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967214ULL);
x86_l_68c0:
	/* 0x68c0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_68c3:
	/* 0x68c3: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68c3, 0x6c02, x86_l_6c02);
x86_l_68c9:
	/* 0x68c9: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_68d0:
	/* 0x68d0: mov    ecx,0xffffffb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967216ULL);
x86_l_68d5:
	/* 0x68d5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_68d8:
	/* 0x68d8: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68d8, 0x6c02, x86_l_6c02);
x86_l_68de:
	/* 0x68de: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_68e5:
	/* 0x68e5: mov    ecx,0xffffffb2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967218ULL);
x86_l_68ea:
	/* 0x68ea: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_68ed:
	/* 0x68ed: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68ed, 0x6c02, x86_l_6c02);
x86_l_68f3:
	/* 0x68f3: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_68fa:
	/* 0x68fa: mov    ecx,0xffffffb4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967220ULL);
x86_l_68ff:
	/* 0x68ff: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6902:
	/* 0x6902: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6902, 0x6c02, x86_l_6c02);
x86_l_6908:
	/* 0x6908: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_690f:
	/* 0x690f: mov    ecx,0xffffffb6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967222ULL);
x86_l_6914:
	/* 0x6914: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6917:
	/* 0x6917: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6917, 0x6c02, x86_l_6c02);
x86_l_691d:
	/* 0x691d: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_6924:
	/* 0x6924: mov    ecx,0xffffffb8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967224ULL);
x86_l_6929:
	/* 0x6929: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_692c:
	/* 0x692c: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x692c, 0x6c02, x86_l_6c02);
x86_l_6932:
	/* 0x6932: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_6939:
	/* 0x6939: mov    ecx,0xffffffba */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967226ULL);
x86_l_693e:
	/* 0x693e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6941:
	/* 0x6941: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6941, 0x6c02, x86_l_6c02);
x86_l_6947:
	/* 0x6947: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_694e:
	/* 0x694e: mov    ecx,0xffffffbc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967228ULL);
x86_l_6953:
	/* 0x6953: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6956:
	/* 0x6956: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6956, 0x6c02, x86_l_6c02);
x86_l_695c:
	/* 0x695c: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_6963:
	/* 0x6963: mov    ecx,0xffffffbe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967230ULL);
x86_l_6968:
	/* 0x6968: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_696b:
	/* 0x696b: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x696b, 0x6c02, x86_l_6c02);
x86_l_6971:
	/* 0x6971: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_6978:
	/* 0x6978: mov    ecx,0xffffffc0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967232ULL);
x86_l_697d:
	/* 0x697d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6980:
	/* 0x6980: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6980, 0x6c02, x86_l_6c02);
x86_l_6986:
	/* 0x6986: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_698d:
	/* 0x698d: mov    ecx,0xffffffc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967234ULL);
x86_l_6992:
	/* 0x6992: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6995:
	/* 0x6995: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6995, 0x6c02, x86_l_6c02);
x86_l_699b:
	/* 0x699b: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_69a2:
	/* 0x69a2: mov    ecx,0xffffffc4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967236ULL);
x86_l_69a7:
	/* 0x69a7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_69aa:
	/* 0x69aa: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69aa, 0x6c02, x86_l_6c02);
x86_l_69b0:
	/* 0x69b0: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_69b7:
	/* 0x69b7: mov    ecx,0xffffffc6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967238ULL);
x86_l_69bc:
	/* 0x69bc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_69bf:
	/* 0x69bf: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69bf, 0x6c02, x86_l_6c02);
x86_l_69c5:
	/* 0x69c5: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_69cc:
	/* 0x69cc: mov    ecx,0xffffffc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967240ULL);
x86_l_69d1:
	/* 0x69d1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_69d4:
	/* 0x69d4: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69d4, 0x6c02, x86_l_6c02);
x86_l_69da:
	/* 0x69da: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_69e1:
	/* 0x69e1: mov    ecx,0xffffffca */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967242ULL);
x86_l_69e6:
	/* 0x69e6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_69e9:
	/* 0x69e9: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69e9, 0x6c02, x86_l_6c02);
x86_l_69ef:
	/* 0x69ef: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_69f6:
	/* 0x69f6: mov    ecx,0xffffffcc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967244ULL);
x86_l_69fb:
	/* 0x69fb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_69fe:
	/* 0x69fe: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69fe, 0x6c02, x86_l_6c02);
x86_l_6a04:
	/* 0x6a04: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_6a0b:
	/* 0x6a0b: mov    ecx,0xffffffce */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967246ULL);
x86_l_6a10:
	/* 0x6a10: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a13:
	/* 0x6a13: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a13, 0x6c02, x86_l_6c02);
x86_l_6a19:
	/* 0x6a19: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_6a20:
	/* 0x6a20: mov    ecx,0xffffffd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967248ULL);
x86_l_6a25:
	/* 0x6a25: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a28:
	/* 0x6a28: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a28, 0x6c02, x86_l_6c02);
x86_l_6a2e:
	/* 0x6a2e: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_6a35:
	/* 0x6a35: mov    ecx,0xffffffd2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967250ULL);
x86_l_6a3a:
	/* 0x6a3a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a3d:
	/* 0x6a3d: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a3d, 0x6c02, x86_l_6c02);
x86_l_6a43:
	/* 0x6a43: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_6a4a:
	/* 0x6a4a: mov    ecx,0xffffffd4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967252ULL);
x86_l_6a4f:
	/* 0x6a4f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a52:
	/* 0x6a52: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a52, 0x6c02, x86_l_6c02);
x86_l_6a58:
	/* 0x6a58: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_6a5f:
	/* 0x6a5f: mov    ecx,0xffffffd6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967254ULL);
x86_l_6a64:
	/* 0x6a64: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a67:
	/* 0x6a67: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a67, 0x6c02, x86_l_6c02);
x86_l_6a6d:
	/* 0x6a6d: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_6a74:
	/* 0x6a74: mov    ecx,0xffffffd8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967256ULL);
x86_l_6a79:
	/* 0x6a79: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a7c:
	/* 0x6a7c: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a7c, 0x6c02, x86_l_6c02);
x86_l_6a82:
	/* 0x6a82: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_6a89:
	/* 0x6a89: mov    ecx,0xffffffda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967258ULL);
x86_l_6a8e:
	/* 0x6a8e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6a91:
	/* 0x6a91: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a91, 0x6c02, x86_l_6c02);
x86_l_6a97:
	/* 0x6a97: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_6a9e:
	/* 0x6a9e: mov    ecx,0xffffffdc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967260ULL);
x86_l_6aa3:
	/* 0x6aa3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6aa6:
	/* 0x6aa6: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6aa6, 0x6c02, x86_l_6c02);
x86_l_6aac:
	/* 0x6aac: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_6ab3:
	/* 0x6ab3: mov    ecx,0xffffffde */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967262ULL);
x86_l_6ab8:
	/* 0x6ab8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6abb:
	/* 0x6abb: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6abb, 0x6c02, x86_l_6c02);
x86_l_6ac1:
	/* 0x6ac1: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_6ac8:
	/* 0x6ac8: mov    ecx,0xffffffe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967264ULL);
x86_l_6acd:
	/* 0x6acd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ad0:
	/* 0x6ad0: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ad0, 0x6c02, x86_l_6c02);
x86_l_6ad6:
	/* 0x6ad6: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_6add:
	/* 0x6add: mov    ecx,0xffffffe2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967266ULL);
x86_l_6ae2:
	/* 0x6ae2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ae5:
	/* 0x6ae5: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ae5, 0x6c02, x86_l_6c02);
x86_l_6aeb:
	/* 0x6aeb: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_6af2:
	/* 0x6af2: mov    ecx,0xffffffe4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967268ULL);
x86_l_6af7:
	/* 0x6af7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6afa:
	/* 0x6afa: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6afa, 0x6c02, x86_l_6c02);
x86_l_6b00:
	/* 0x6b00: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_6b07:
	/* 0x6b07: mov    ecx,0xffffffe6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967270ULL);
x86_l_6b0c:
	/* 0x6b0c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b0f:
	/* 0x6b0f: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b0f, 0x6c02, x86_l_6c02);
x86_l_6b15:
	/* 0x6b15: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_6b1c:
	/* 0x6b1c: mov    ecx,0xffffffe8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967272ULL);
x86_l_6b21:
	/* 0x6b21: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b24:
	/* 0x6b24: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b24, 0x6c02, x86_l_6c02);
x86_l_6b2a:
	/* 0x6b2a: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_6b31:
	/* 0x6b31: mov    ecx,0xffffffea */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967274ULL);
x86_l_6b36:
	/* 0x6b36: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b39:
	/* 0x6b39: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b39, 0x6c02, x86_l_6c02);
x86_l_6b3f:
	/* 0x6b3f: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_6b46:
	/* 0x6b46: mov    ecx,0xffffffec */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967276ULL);
x86_l_6b4b:
	/* 0x6b4b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b4e:
	/* 0x6b4e: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b4e, 0x6c02, x86_l_6c02);
x86_l_6b54:
	/* 0x6b54: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_6b5b:
	/* 0x6b5b: mov    ecx,0xffffffee */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967278ULL);
x86_l_6b60:
	/* 0x6b60: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b63:
	/* 0x6b63: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b63, 0x6c02, x86_l_6c02);
x86_l_6b69:
	/* 0x6b69: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_6b70:
	/* 0x6b70: mov    ecx,0xfffffff0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967280ULL);
x86_l_6b75:
	/* 0x6b75: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b78:
	/* 0x6b78: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b78, 0x6c02, x86_l_6c02);
x86_l_6b7e:
	/* 0x6b7e: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_6b85:
	/* 0x6b85: mov    ecx,0xfffffff2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967282ULL);
x86_l_6b8a:
	/* 0x6b8a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b8d:
	/* 0x6b8d: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b8d, 0x6c02, x86_l_6c02);
x86_l_6b8f:
	/* 0x6b8f: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_6b96:
	/* 0x6b96: mov    ecx,0xfffffff4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967284ULL);
x86_l_6b9b:
	/* 0x6b9b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6b9e:
	/* 0x6b9e: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b9e, 0x6c02, x86_l_6c02);
x86_l_6ba0:
	/* 0x6ba0: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_6ba7:
	/* 0x6ba7: mov    ecx,0xfffffff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967286ULL);
x86_l_6bac:
	/* 0x6bac: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6baf:
	/* 0x6baf: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6baf, 0x6c02, x86_l_6c02);
x86_l_6bb1:
	/* 0x6bb1: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_6bb8:
	/* 0x6bb8: mov    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967288ULL);
x86_l_6bbd:
	/* 0x6bbd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6bc0:
	/* 0x6bc0: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6bc0, 0x6c02, x86_l_6c02);
x86_l_6bc2:
	/* 0x6bc2: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_6bc9:
	/* 0x6bc9: mov    ecx,0xfffffffa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967290ULL);
x86_l_6bce:
	/* 0x6bce: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6bd1:
	/* 0x6bd1: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6bd1, 0x6c02, x86_l_6c02);
x86_l_6bd3:
	/* 0x6bd3: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_6bda:
	/* 0x6bda: mov    ecx,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967292ULL);
x86_l_6bdf:
	/* 0x6bdf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6be2:
	/* 0x6be2: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6be2, 0x6c02, x86_l_6c02);
x86_l_6be4:
	/* 0x6be4: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_6beb:
	/* 0x6beb: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_6bf0:
	/* 0x6bf0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6bf3:
	/* 0x6bf3: jne    6c02 <perf_unwind_dotnet+0x6c02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6bf3, 0x6c02, x86_l_6c02);
x86_l_6bf5:
	/* 0x6bf5: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_6bfd:
	/* 0x6bfd: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c00:
	/* 0x6c00: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6c02:
	/* 0x6c02: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6c04:
	/* 0x6c04: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_6c07:
	/* 0x6c07: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_6c0b:
	/* 0x6c0b: setne  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_NE);
x86_l_6c0e:
	/* 0x6c0e: cmove  r15d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_6c12:
	/* 0x6c12: sub    ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_6c14:
	/* 0x6c14: add    ecx,0x7e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_6c17:
	/* 0x6c17: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_6c19:
	/* 0x6c19: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_6c1c:
	/* 0x6c1c: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_6c1f:
	/* 0x6c1f: jb     5c1f <perf_unwind_dotnet+0x5c1f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6c1f, 0x5c1f, x86_l_5c1f);
x86_l_6c25:
	/* 0x6c25: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_6c2c:
	/* 0x6c2c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c2f:
	/* 0x6c2f: jne    710c <perf_unwind_dotnet+0x710c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c2f, 0x710c, x86_l_710c);
x86_l_6c35:
	/* 0x6c35: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_6c38:
	/* 0x6c38: jne    5b23 <perf_unwind_dotnet+0x5b23> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c38, 0x5b23, x86_l_5b23);
x86_l_6c3e:
	/* 0x6c3e: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_6c46:
	/* 0x6c46: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_6c4d:
	/* 0x6c4d: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6c52:
	/* 0x6c52: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_6c57:
	/* 0x6c57: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6c59:
	/* 0x6c59: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6c5c:
	/* 0x6c5c: je     6c63 <perf_unwind_dotnet+0x6c63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c5c, 0x6c63, x86_l_6c63);
x86_l_6c5e:
	/* 0x6c5e: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6c61:
	/* 0x6c61: jmp    6c73 <perf_unwind_dotnet+0x6c73> */
	X86_SIM_X86_JMP(0x6c61, 0x6c73, x86_l_6c73);
x86_l_6c63:
	/* 0x6c63: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_6c6a:
	/* 0x6c6a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c6d:
	/* 0x6c6d: jne    79e4 <perf_unwind_dotnet+0x79e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c6d, 0x79e4, x86_l_79e4);
x86_l_6c73:
	/* 0x6c73: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_6c78:
	/* 0x6c78: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_6c7d:
	/* 0x6c7d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_6c84:
	/* 0x6c84: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c87:
	/* 0x6c87: je     5b6e <perf_unwind_dotnet+0x5b6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c87, 0x5b6e, x86_l_5b6e);
x86_l_6c8d:
	/* 0x6c8d: movabs rax,0xa642520687469 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387390569ULL);
x86_l_6c97:
	/* 0x6c97: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6c9c:
	/* 0x6c9c: movabs rax,0x772064656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8583971276541485414ULL);
x86_l_6ca6:
	/* 0x6ca6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6cab:
	/* 0x6cab: movabs rax,0x2074726174735f65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338619869403242341ULL);
x86_l_6cb5:
	/* 0x6cb5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6cba:
	/* 0x6cba: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7237112116340927776ULL);
x86_l_6cc4:
	/* 0x6cc4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6cc9:
	/* 0x6cc9: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_6cd3:
	/* 0x6cd3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6cd8:
	/* 0x6cd8: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6cdd:
	/* 0x6cdd: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_6ce2:
	/* 0x6ce2: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_6ce7:
	/* 0x6ce7: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_6cec:
	/* 0x6cec: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6cee:
	/* 0x6cee: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6cf0:
	/* 0x6cf0: jmp    5b6e <perf_unwind_dotnet+0x5b6e> */
	X86_SIM_X86_JMP(0x6cf0, 0x5b6e, x86_l_5b6e);
x86_l_6cf5:
	/* 0x6cf5: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_6cfc:
	/* 0x6cfc: mov    ecx,0xffffff9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967198ULL);
x86_l_6d01:
	/* 0x6d01: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d04:
	/* 0x6d04: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d04, 0x56ee, x86_l_56ee);
x86_l_6d0a:
	/* 0x6d0a: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_6d11:
	/* 0x6d11: mov    ecx,0xffffffa0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967200ULL);
x86_l_6d16:
	/* 0x6d16: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d19:
	/* 0x6d19: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d19, 0x56ee, x86_l_56ee);
x86_l_6d1f:
	/* 0x6d1f: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_6d26:
	/* 0x6d26: mov    ecx,0xffffffa2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967202ULL);
x86_l_6d2b:
	/* 0x6d2b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d2e:
	/* 0x6d2e: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d2e, 0x56ee, x86_l_56ee);
x86_l_6d34:
	/* 0x6d34: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_6d3b:
	/* 0x6d3b: mov    ecx,0xffffffa4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967204ULL);
x86_l_6d40:
	/* 0x6d40: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d43:
	/* 0x6d43: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d43, 0x56ee, x86_l_56ee);
x86_l_6d49:
	/* 0x6d49: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_6d50:
	/* 0x6d50: mov    ecx,0xffffffa6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967206ULL);
x86_l_6d55:
	/* 0x6d55: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d58:
	/* 0x6d58: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d58, 0x56ee, x86_l_56ee);
x86_l_6d5e:
	/* 0x6d5e: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_6d65:
	/* 0x6d65: mov    ecx,0xffffffa8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967208ULL);
x86_l_6d6a:
	/* 0x6d6a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d6d:
	/* 0x6d6d: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d6d, 0x56ee, x86_l_56ee);
x86_l_6d73:
	/* 0x6d73: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_6d7a:
	/* 0x6d7a: mov    ecx,0xffffffaa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967210ULL);
x86_l_6d7f:
	/* 0x6d7f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d82:
	/* 0x6d82: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d82, 0x56ee, x86_l_56ee);
x86_l_6d88:
	/* 0x6d88: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_6d8f:
	/* 0x6d8f: mov    ecx,0xffffffac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967212ULL);
x86_l_6d94:
	/* 0x6d94: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6d97:
	/* 0x6d97: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d97, 0x56ee, x86_l_56ee);
x86_l_6d9d:
	/* 0x6d9d: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_6da4:
	/* 0x6da4: mov    ecx,0xffffffae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967214ULL);
x86_l_6da9:
	/* 0x6da9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6dac:
	/* 0x6dac: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6dac, 0x56ee, x86_l_56ee);
x86_l_6db2:
	/* 0x6db2: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_6db9:
	/* 0x6db9: mov    ecx,0xffffffb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967216ULL);
x86_l_6dbe:
	/* 0x6dbe: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6dc1:
	/* 0x6dc1: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6dc1, 0x56ee, x86_l_56ee);
x86_l_6dc7:
	/* 0x6dc7: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_6dce:
	/* 0x6dce: mov    ecx,0xffffffb2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967218ULL);
x86_l_6dd3:
	/* 0x6dd3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6dd6:
	/* 0x6dd6: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6dd6, 0x56ee, x86_l_56ee);
x86_l_6ddc:
	/* 0x6ddc: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_6de3:
	/* 0x6de3: mov    ecx,0xffffffb4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967220ULL);
x86_l_6de8:
	/* 0x6de8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6deb:
	/* 0x6deb: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6deb, 0x56ee, x86_l_56ee);
x86_l_6df1:
	/* 0x6df1: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_6df8:
	/* 0x6df8: mov    ecx,0xffffffb6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967222ULL);
x86_l_6dfd:
	/* 0x6dfd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e00:
	/* 0x6e00: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e00, 0x56ee, x86_l_56ee);
x86_l_6e06:
	/* 0x6e06: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_6e0d:
	/* 0x6e0d: mov    ecx,0xffffffb8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967224ULL);
x86_l_6e12:
	/* 0x6e12: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e15:
	/* 0x6e15: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e15, 0x56ee, x86_l_56ee);
x86_l_6e1b:
	/* 0x6e1b: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_6e22:
	/* 0x6e22: mov    ecx,0xffffffba */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967226ULL);
x86_l_6e27:
	/* 0x6e27: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e2a:
	/* 0x6e2a: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e2a, 0x56ee, x86_l_56ee);
x86_l_6e30:
	/* 0x6e30: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_6e37:
	/* 0x6e37: mov    ecx,0xffffffbc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967228ULL);
x86_l_6e3c:
	/* 0x6e3c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e3f:
	/* 0x6e3f: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e3f, 0x56ee, x86_l_56ee);
x86_l_6e45:
	/* 0x6e45: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_6e4c:
	/* 0x6e4c: mov    ecx,0xffffffbe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967230ULL);
x86_l_6e51:
	/* 0x6e51: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e54:
	/* 0x6e54: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e54, 0x56ee, x86_l_56ee);
x86_l_6e5a:
	/* 0x6e5a: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_6e61:
	/* 0x6e61: mov    ecx,0xffffffc0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967232ULL);
x86_l_6e66:
	/* 0x6e66: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e69:
	/* 0x6e69: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e69, 0x56ee, x86_l_56ee);
x86_l_6e6f:
	/* 0x6e6f: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_6e76:
	/* 0x6e76: mov    ecx,0xffffffc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967234ULL);
x86_l_6e7b:
	/* 0x6e7b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e7e:
	/* 0x6e7e: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e7e, 0x56ee, x86_l_56ee);
x86_l_6e84:
	/* 0x6e84: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_6e8b:
	/* 0x6e8b: mov    ecx,0xffffffc4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967236ULL);
x86_l_6e90:
	/* 0x6e90: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6e93:
	/* 0x6e93: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e93, 0x56ee, x86_l_56ee);
x86_l_6e99:
	/* 0x6e99: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_6ea0:
	/* 0x6ea0: mov    ecx,0xffffffc6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967238ULL);
x86_l_6ea5:
	/* 0x6ea5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ea8:
	/* 0x6ea8: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ea8, 0x56ee, x86_l_56ee);
x86_l_6eae:
	/* 0x6eae: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_6eb5:
	/* 0x6eb5: mov    ecx,0xffffffc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967240ULL);
x86_l_6eba:
	/* 0x6eba: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ebd:
	/* 0x6ebd: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ebd, 0x56ee, x86_l_56ee);
x86_l_6ec3:
	/* 0x6ec3: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_6eca:
	/* 0x6eca: mov    ecx,0xffffffca */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967242ULL);
x86_l_6ecf:
	/* 0x6ecf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ed2:
	/* 0x6ed2: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ed2, 0x56ee, x86_l_56ee);
x86_l_6ed8:
	/* 0x6ed8: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_6edf:
	/* 0x6edf: mov    ecx,0xffffffcc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967244ULL);
x86_l_6ee4:
	/* 0x6ee4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ee7:
	/* 0x6ee7: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ee7, 0x56ee, x86_l_56ee);
x86_l_6eed:
	/* 0x6eed: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_6ef4:
	/* 0x6ef4: mov    ecx,0xffffffce */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967246ULL);
x86_l_6ef9:
	/* 0x6ef9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6efc:
	/* 0x6efc: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6efc, 0x56ee, x86_l_56ee);
x86_l_6f02:
	/* 0x6f02: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_6f09:
	/* 0x6f09: mov    ecx,0xffffffd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967248ULL);
x86_l_6f0e:
	/* 0x6f0e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f11:
	/* 0x6f11: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f11, 0x56ee, x86_l_56ee);
x86_l_6f17:
	/* 0x6f17: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_6f1e:
	/* 0x6f1e: mov    ecx,0xffffffd2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967250ULL);
x86_l_6f23:
	/* 0x6f23: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f26:
	/* 0x6f26: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f26, 0x56ee, x86_l_56ee);
x86_l_6f2c:
	/* 0x6f2c: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_6f33:
	/* 0x6f33: mov    ecx,0xffffffd4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967252ULL);
x86_l_6f38:
	/* 0x6f38: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f3b:
	/* 0x6f3b: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f3b, 0x56ee, x86_l_56ee);
x86_l_6f41:
	/* 0x6f41: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_6f48:
	/* 0x6f48: mov    ecx,0xffffffd6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967254ULL);
x86_l_6f4d:
	/* 0x6f4d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f50:
	/* 0x6f50: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f50, 0x56ee, x86_l_56ee);
x86_l_6f56:
	/* 0x6f56: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_6f5d:
	/* 0x6f5d: mov    ecx,0xffffffd8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967256ULL);
x86_l_6f62:
	/* 0x6f62: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f65:
	/* 0x6f65: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f65, 0x56ee, x86_l_56ee);
x86_l_6f6b:
	/* 0x6f6b: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_6f72:
	/* 0x6f72: mov    ecx,0xffffffda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967258ULL);
x86_l_6f77:
	/* 0x6f77: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f7a:
	/* 0x6f7a: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f7a, 0x56ee, x86_l_56ee);
x86_l_6f80:
	/* 0x6f80: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_6f87:
	/* 0x6f87: mov    ecx,0xffffffdc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967260ULL);
x86_l_6f8c:
	/* 0x6f8c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6f8f:
	/* 0x6f8f: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f8f, 0x56ee, x86_l_56ee);
x86_l_6f95:
	/* 0x6f95: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_6f9c:
	/* 0x6f9c: mov    ecx,0xffffffde */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967262ULL);
x86_l_6fa1:
	/* 0x6fa1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6fa4:
	/* 0x6fa4: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6fa4, 0x56ee, x86_l_56ee);
x86_l_6faa:
	/* 0x6faa: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_6fb1:
	/* 0x6fb1: mov    ecx,0xffffffe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967264ULL);
x86_l_6fb6:
	/* 0x6fb6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6fb9:
	/* 0x6fb9: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6fb9, 0x56ee, x86_l_56ee);
x86_l_6fbf:
	/* 0x6fbf: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_6fc6:
	/* 0x6fc6: mov    ecx,0xffffffe2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967266ULL);
x86_l_6fcb:
	/* 0x6fcb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6fce:
	/* 0x6fce: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6fce, 0x56ee, x86_l_56ee);
x86_l_6fd4:
	/* 0x6fd4: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_6fdb:
	/* 0x6fdb: mov    ecx,0xffffffe4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967268ULL);
x86_l_6fe0:
	/* 0x6fe0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6fe3:
	/* 0x6fe3: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6fe3, 0x56ee, x86_l_56ee);
x86_l_6fe9:
	/* 0x6fe9: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_6ff0:
	/* 0x6ff0: mov    ecx,0xffffffe6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967270ULL);
x86_l_6ff5:
	/* 0x6ff5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6ff8:
	/* 0x6ff8: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ff8, 0x56ee, x86_l_56ee);
x86_l_6ffe:
	/* 0x6ffe: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_7005:
	/* 0x7005: mov    ecx,0xffffffe8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967272ULL);
x86_l_700a:
	/* 0x700a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_700d:
	/* 0x700d: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x700d, 0x56ee, x86_l_56ee);
x86_l_7013:
	/* 0x7013: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_701a:
	/* 0x701a: mov    ecx,0xffffffea */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967274ULL);
x86_l_701f:
	/* 0x701f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7022:
	/* 0x7022: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7022, 0x56ee, x86_l_56ee);
x86_l_7028:
	/* 0x7028: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_702f:
	/* 0x702f: mov    ecx,0xffffffec */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967276ULL);
x86_l_7034:
	/* 0x7034: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7037:
	/* 0x7037: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7037, 0x56ee, x86_l_56ee);
x86_l_703d:
	/* 0x703d: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_7044:
	/* 0x7044: mov    ecx,0xffffffee */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967278ULL);
x86_l_7049:
	/* 0x7049: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_704c:
	/* 0x704c: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x704c, 0x56ee, x86_l_56ee);
x86_l_7052:
	/* 0x7052: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_7059:
	/* 0x7059: mov    ecx,0xfffffff0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967280ULL);
x86_l_705e:
	/* 0x705e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7061:
	/* 0x7061: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7061, 0x56ee, x86_l_56ee);
x86_l_7067:
	/* 0x7067: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_706e:
	/* 0x706e: mov    ecx,0xfffffff2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967282ULL);
x86_l_7073:
	/* 0x7073: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7076:
	/* 0x7076: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7076, 0x56ee, x86_l_56ee);
x86_l_707c:
	/* 0x707c: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_7083:
	/* 0x7083: mov    ecx,0xfffffff4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967284ULL);
x86_l_7088:
	/* 0x7088: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_708b:
	/* 0x708b: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x708b, 0x56ee, x86_l_56ee);
x86_l_7091:
	/* 0x7091: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_7098:
	/* 0x7098: mov    ecx,0xfffffff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967286ULL);
x86_l_709d:
	/* 0x709d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_70a0:
	/* 0x70a0: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70a0, 0x56ee, x86_l_56ee);
x86_l_70a6:
	/* 0x70a6: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_70ad:
	/* 0x70ad: mov    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967288ULL);
x86_l_70b2:
	/* 0x70b2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_70b5:
	/* 0x70b5: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70b5, 0x56ee, x86_l_56ee);
x86_l_70bb:
	/* 0x70bb: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_70c2:
	/* 0x70c2: mov    ecx,0xfffffffa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967290ULL);
x86_l_70c7:
	/* 0x70c7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_70ca:
	/* 0x70ca: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70ca, 0x56ee, x86_l_56ee);
x86_l_70d0:
	/* 0x70d0: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_70d7:
	/* 0x70d7: mov    ecx,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967292ULL);
x86_l_70dc:
	/* 0x70dc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_70df:
	/* 0x70df: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70df, 0x56ee, x86_l_56ee);
x86_l_70e5:
	/* 0x70e5: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_70ec:
	/* 0x70ec: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_70f1:
	/* 0x70f1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_70f4:
	/* 0x70f4: jne    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70f4, 0x56ee, x86_l_56ee);
x86_l_70fa:
	/* 0x70fa: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_7102:
	/* 0x7102: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7105:
	/* 0x7105: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7107:
	/* 0x7107: jmp    56ee <perf_unwind_dotnet+0x56ee> */
	X86_SIM_X86_JMP(0x7107, 0x56ee, x86_l_56ee);
x86_l_710c:
	/* 0x710c: movabs rax,0x207972746e65202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2340027325789577260ULL);
x86_l_7116:
	/* 0x7116: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_711b:
	/* 0x711b: movabs rax,0x6425206465707069 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7216209593501773929ULL);
x86_l_7125:
	/* 0x7125: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_712a:
	/* 0x712a: movabs rax,0x6b73203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7742567619880559904ULL);
x86_l_7134:
	/* 0x7134: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7139:
	/* 0x7139: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_7143:
	/* 0x7143: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7148:
	/* 0x7148: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_7152:
	/* 0x7152: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7157:
	/* 0x7157: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_7161:
	/* 0x7161: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7166:
	/* 0x7166: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_7170:
	/* 0x7170: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7175:
	/* 0x7175: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_717d:
	/* 0x717d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7182:
	/* 0x7182: mov    eax,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_7187:
	/* 0x7187: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_718d:
	/* 0x718d: mov    esi,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 60ULL);
x86_l_7192:
	/* 0x7192: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_7195:
	/* 0x7195: mov    r8d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_32);
x86_l_7198:
	/* 0x7198: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_719a:
	/* 0x719a: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_719d:
	/* 0x719d: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_71a0:
	/* 0x71a0: jne    5b23 <perf_unwind_dotnet+0x5b23> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x71a0, 0x5b23, x86_l_5b23);
x86_l_71a6:
	/* 0x71a6: jmp    6c3e <perf_unwind_dotnet+0x6c3e> */
	X86_SIM_X86_JMP(0x71a6, 0x6c3e, x86_l_6c3e);
x86_l_71ab:
	/* 0x71ab: movabs rax,0xa642520686374 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387386228ULL);
x86_l_71b5:
	/* 0x71b5: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_71ba:
	/* 0x71ba: movabs rax,0x6374616d20737465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7166460028377068645ULL);
x86_l_71c4:
	/* 0x71c4: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_71c9:
	/* 0x71c9: movabs rax,0x7366666f5f726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315446390514935156ULL);
x86_l_71d3:
	/* 0x71d3: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_71d8:
	/* 0x71d8: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_71e2:
	/* 0x71e2: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_71e7:
	/* 0x71e7: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_71ec:
	/* 0x71ec: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_71f1:
	/* 0x71f1: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_71f6:
	/* 0x71f6: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_71fb:
	/* 0x71fb: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_7200:
	/* 0x7200: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7202:
	/* 0x7202: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7204:
	/* 0x7204: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_720b:
	/* 0x720b: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_720f:
	/* 0x720f: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_7212:
	/* 0x7212: jb     61ed <perf_unwind_dotnet+0x61ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7212, 0x61ed, x86_l_61ed);
x86_l_7218:
	/* 0x7218: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_7220:
	/* 0x7220: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_7227:
	/* 0x7227: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_722c:
	/* 0x722c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_7231:
	/* 0x7231: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7233:
	/* 0x7233: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7236:
	/* 0x7236: je     723d <perf_unwind_dotnet+0x723d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7236, 0x723d, x86_l_723d);
x86_l_7238:
	/* 0x7238: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_723b:
	/* 0x723b: jmp    724d <perf_unwind_dotnet+0x724d> */
	X86_SIM_X86_JMP(0x723b, 0x724d, x86_l_724d);
x86_l_723d:
	/* 0x723d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7244:
	/* 0x7244: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7247:
	/* 0x7247: jne    7a5f <perf_unwind_dotnet+0x7a5f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7247, 0x7a5f, x86_l_7a5f);
x86_l_724d:
	/* 0x724d: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_7252:
	/* 0x7252: cmp    r12d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 8ULL);
x86_l_7256:
	/* 0x7256: jne    8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7256, 0x8cac, x86_l_8cac);
x86_l_725c:
	/* 0x725c: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_7263:
	/* 0x7263: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_726a:
	/* 0x726a: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_7271:
	/* 0x7271: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_7279:
	/* 0x7279: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_727d:
	/* 0x727d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7284:
	/* 0x7284: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7287:
	/* 0x7287: jne    764b <perf_unwind_dotnet+0x764b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7287, 0x764b, x86_l_764b);
x86_l_728d:
	/* 0x728d: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_7290:
	/* 0x7290: jb     76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7290, 0x76bb, x86_l_76bb);
x86_l_7296:
	/* 0x7296: lea    rax,[rbx+0x2000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_729d:
	/* 0x729d: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_72a0:
	/* 0x72a0: jae    76bb <perf_unwind_dotnet+0x76bb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x72a0, 0x76bb, x86_l_76bb);
x86_l_72a6:
	/* 0x72a6: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_72ad:
	/* 0x72ad: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_72b4:
	/* 0x72b4: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_72b9:
	/* 0x72b9: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_72c1:
	/* 0x72c1: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_72c4:
	/* 0x72c4: and    rax,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_72c8:
	/* 0x72c8: cmp    rax,0x80 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_72ce:
	/* 0x72ce: jne    7312 <perf_unwind_dotnet+0x7312> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x72ce, 0x7312, x86_l_7312);
x86_l_72d0:
	/* 0x72d0: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_72d7:
	/* 0x72d7: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_72dc:
	/* 0x72dc: mov    r8d,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 112ULL);
x86_l_72e2:
	/* 0x72e2: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_72ea:
	/* 0x72ea: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_72f1:
	/* 0x72f1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_72f6:
	/* 0x72f6: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_72f9:
	/* 0x72f9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_72fc:
	/* 0x72fc: jne    19c <perf_unwind_dotnet+0x19c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x72fc, 0x19c, x86_l_19c);
x86_l_7302:
	/* 0x7302: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_730a:
	/* 0x730a: and    ebp,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_730d:
	/* 0x730d: jmp    84ed <perf_unwind_dotnet+0x84ed> */
	X86_SIM_X86_JMP(0x730d, 0x84ed, x86_l_84ed);
x86_l_7312:
	/* 0x7312: lea    rdi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7317:
	/* 0x7317: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_731c:
	/* 0x731c: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_7321:
	/* 0x7321: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_7326:
	/* 0x7326: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_7329:
	/* 0x7329: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_732b:
	/* 0x732b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_732e:
	/* 0x732e: jne    26c <perf_unwind_dotnet+0x26c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x732e, 0x26c, x86_l_26c);
x86_l_7334:
	/* 0x7334: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7338:
	/* 0x7338: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_733f:
	/* 0x733f: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7344:
	/* 0x7344: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_734b:
	/* 0x734b: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_7350:
	/* 0x7350: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_7357:
	/* 0x7357: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_735e:
	/* 0x735e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7361:
	/* 0x7361: jne    7ada <perf_unwind_dotnet+0x7ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7361, 0x7ada, x86_l_7ada);
x86_l_7367:
	/* 0x7367: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_736e:
	/* 0x736e: jb     84ed <perf_unwind_dotnet+0x84ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x736e, 0x84ed, x86_l_84ed);
x86_l_7374:
	/* 0x7374: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_737b:
	/* 0x737b: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_7382:
	/* 0x7382: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
x86_l_7385:
	/* 0x7385: sub    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_7388:
	/* 0x7388: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_738f:
	/* 0x738f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7392:
	/* 0x7392: jne    7b5f <perf_unwind_dotnet+0x7b5f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7392, 0x7b5f, x86_l_7b5f);
x86_l_7398:
	/* 0x7398: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_739b:
	/* 0x739b: shr    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_739f:
	/* 0x739f: mov    ecx,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 127ULL);
x86_l_73a4:
	/* 0x73a4: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_73a6:
	/* 0x73a6: and    ecx,0x7f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_73a9:
	/* 0x73a9: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_73ab:
	/* 0x73ab: cmp    r13,0x8000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 32768ULL);
x86_l_73b2:
	/* 0x73b2: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_73ba:
	/* 0x73ba: cmovb  rdx,rsi */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B);
x86_l_73be:
	/* 0x73be: cmovae ecx,esi */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE);
x86_l_73c1:
	/* 0x73c1: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_73c4:
	/* 0x73c4: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_73cc:
	/* 0x73cc: lea    rdi,[rax+rcx*4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_73d0:
	/* 0x73d0: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
x86_l_73d5:
	/* 0x73d5: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_73da:
	/* 0x73da: mov    esi,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 512ULL);
x86_l_73df:
	/* 0x73df: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_73e1:
	/* 0x73e1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_73e4:
	/* 0x73e4: je     741b <perf_unwind_dotnet+0x741b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73e4, 0x741b, x86_l_741b);
x86_l_73e6:
	/* 0x73e6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_73ed:
	/* 0x73ed: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_73f0:
	/* 0x73f0: jne    75dc <perf_unwind_dotnet+0x75dc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x73f0, 0x75dc, x86_l_75dc);
x86_l_73f6:
	/* 0x73f6: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_73fe:
	/* 0x73fe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_7405:
	/* 0x7405: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_740a:
	/* 0x740a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_740f:
	/* 0x740f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7411:
	/* 0x7411: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7414:
	/* 0x7414: je     7472 <perf_unwind_dotnet+0x7472> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7414, 0x7472, x86_l_7472);
x86_l_7416:
	/* 0x7416: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_7419:
	/* 0x7419: jmp    7482 <perf_unwind_dotnet+0x7482> */
	X86_SIM_X86_JMP(0x7419, 0x7482, x86_l_7482);
x86_l_741b:
	/* 0x741b: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_7422:
	/* 0x7422: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7429:
	/* 0x7429: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_742c:
	/* 0x742c: jne    7ba3 <perf_unwind_dotnet+0x7ba3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x742c, 0x7ba3, x86_l_7ba3);
x86_l_7432:
	/* 0x7432: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_7435:
	/* 0x7435: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_7437:
	/* 0x7437: shr    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_743a:
	/* 0x743a: and    al,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_743c:
	/* 0x743c: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_7441:
	/* 0x7441: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_7444:
	/* 0x7444: je     750f <perf_unwind_dotnet+0x750f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7444, 0x750f, x86_l_750f);
x86_l_744a:
	/* 0x744a: and    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_744e:
	/* 0x744e: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_7451:
	/* 0x7451: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7454:
	/* 0x7454: jne    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7454, 0x84a0, x86_l_84a0);
x86_l_745a:
	/* 0x745a: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_745d:
	/* 0x745d: shr    ecx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_7460:
	/* 0x7460: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7463:
	/* 0x7463: je     761f <perf_unwind_dotnet+0x761f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7463, 0x761f, x86_l_761f);
x86_l_7469:
	/* 0x7469: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_746d:
	/* 0x746d: jmp    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JMP(0x746d, 0x84a0, x86_l_84a0);
x86_l_7472:
	/* 0x7472: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7479:
	/* 0x7479: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_747c:
	/* 0x747c: jne    7c35 <perf_unwind_dotnet+0x7c35> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x747c, 0x7c35, x86_l_7c35);
x86_l_7482:
	/* 0x7482: mov    edx,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6002ULL);
x86_l_7487:
	/* 0x7487: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7489:
	/* 0x7489: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7490:
	/* 0x7490: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7493:
	/* 0x7493: jne    834b <perf_unwind_dotnet+0x834b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7493, 0x834b, x86_l_834b);
x86_l_7499:
	/* 0x7499: mov    eax,0x1772 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6002ULL);
x86_l_749e:
	/* 0x749e: test   bl,bl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8);
x86_l_74a0:
	/* 0x74a0: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_74a5:
	/* 0x74a5: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_74ac:
	/* 0x74ac: je     7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x74ac, 0x7712, x86_l_7712);
x86_l_74b2:
	/* 0x74b2: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_74b9:
	/* 0x74b9: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_74bd:
	/* 0x74bd: ja     4f3 <perf_unwind_dotnet+0x4f3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x74bd, 0x4f3, x86_l_4f3);
x86_l_74c3:
	/* 0x74c3: lea    ecx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_74c6:
	/* 0x74c6: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_74cd:
	/* 0x74cd: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_74d1:
	/* 0x74d1: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_74dd:
	/* 0x74dd: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_74e9:
	/* 0x74e9: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_74f2:
	/* 0x74f2: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_74fe:
	/* 0x74fe: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_750a:
	/* 0x750a: jmp    859d <perf_unwind_dotnet+0x859d> */
	X86_SIM_X86_JMP(0x750a, 0x859d, x86_l_859d);
x86_l_750f:
	/* 0x750f: and    r13,0xffffffffffffff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_7516:
	/* 0x7516: add    r13,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_751a:
	/* 0x751a: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_7521:
	/* 0x7521: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7528:
	/* 0x7528: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_752b:
	/* 0x752b: jne    7cb0 <perf_unwind_dotnet+0x7cb0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x752b, 0x7cb0, x86_l_7cb0);
x86_l_7531:
	/* 0x7531: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7533:
	/* 0x7533: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_7536:
	/* 0x7536: je     7d44 <perf_unwind_dotnet+0x7d44> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7536, 0x7d44, x86_l_7d44);
x86_l_753c:
	/* 0x753c: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_753e:
	/* 0x753e: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_7541:
	/* 0x7541: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_7544:
	/* 0x7544: jae    826e <perf_unwind_dotnet+0x826e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x7544, 0x826e, x86_l_826e);
x86_l_754a:
	/* 0x754a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_7551:
	/* 0x7551: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7554:
	/* 0x7554: je     73f6 <perf_unwind_dotnet+0x73f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7554, 0x73f6, x86_l_73f6);
x86_l_755a:
	/* 0x755a: movabs rax,0xa657361625f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2926295996587875ULL);
x86_l_7564:
	/* 0x7564: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7569:
	/* 0x7569: movabs rax,0x5f637020776f6c65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460741042564197ULL);
x86_l_7573:
	/* 0x7573: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7578:
	/* 0x7578: movabs rax,0x6220746e65772068 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7070779432469209192ULL);
x86_l_7582:
	/* 0x7582: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7587:
	/* 0x7587: movabs rax,0x6372616573207061 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7165897045450977377ULL);
x86_l_7591:
	/* 0x7591: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7596:
	/* 0x7596: movabs rax,0x6d20656c6262696e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7863396465570376046ULL);
x86_l_75a0:
	/* 0x75a0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_75a5:
	/* 0x75a5: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_75af:
	/* 0x75af: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75b4:
	/* 0x75b4: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75b9:
	/* 0x75b9: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_75be:
	/* 0x75be: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_75c3:
	/* 0x75c3: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_75c8:
	/* 0x75c8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_75ca:
	/* 0x75ca: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_75cc:
	/* 0x75cc: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_75d3:
	/* 0x75d3: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_75d6:
	/* 0x75d6: je     73f6 <perf_unwind_dotnet+0x73f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x75d6, 0x73f6, x86_l_73f6);
x86_l_75dc:
	/* 0x75dc: movabs rax,0x6e756f6620746f6e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7959390400869068654ULL);
x86_l_75e6:
	/* 0x75e6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_75eb:
	/* 0x75eb: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_75f5:
	/* 0x75f5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75fa:
	/* 0x75fa: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_7602:
	/* 0x7602: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7607:
	/* 0x7607: mov    eax,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_760c:
	/* 0x760c: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_7611:
	/* 0x7611: mov    esi,0x13 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 19ULL);
x86_l_7616:
	/* 0x7616: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7618:
	/* 0x7618: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_761a:
	/* 0x761a: jmp    73f6 <perf_unwind_dotnet+0x73f6> */
	X86_SIM_X86_JMP(0x761a, 0x73f6, x86_l_73f6);
x86_l_761f:
	/* 0x761f: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_7622:
	/* 0x7622: shr    ecx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_7625:
	/* 0x7625: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7628:
	/* 0x7628: je     7633 <perf_unwind_dotnet+0x7633> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7628, 0x7633, x86_l_7633);
x86_l_762a:
	/* 0x762a: add    r13,0xffffffffffffffc0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_762e:
	/* 0x762e: jmp    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JMP(0x762e, 0x84a0, x86_l_84a0);
x86_l_7633:
	/* 0x7633: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_7636:
	/* 0x7636: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_7639:
	/* 0x7639: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_763c:
	/* 0x763c: je     83b3 <perf_unwind_dotnet+0x83b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x763c, 0x83b3, x86_l_83b3);
x86_l_7642:
	/* 0x7642: add    r13,0xffffffffffffffa0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_7646:
	/* 0x7646: jmp    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JMP(0x7646, 0x84a0, x86_l_84a0);
x86_l_764b:
	/* 0x764b: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_7655:
	/* 0x7655: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_765a:
	/* 0x765a: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_7664:
	/* 0x7664: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7669:
	/* 0x7669: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_7673:
	/* 0x7673: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7678:
	/* 0x7678: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_7682:
	/* 0x7682: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7687:
	/* 0x7687: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_768f:
	/* 0x768f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7694:
	/* 0x7694: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_7699:
	/* 0x7699: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_769f:
	/* 0x769f: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_76a4:
	/* 0x76a4: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_76a7:
	/* 0x76a7: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_76aa:
	/* 0x76aa: mov    r8,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R13, X86_WIDTH_64);
x86_l_76ad:
	/* 0x76ad: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_76af:
	/* 0x76af: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_76b2:
	/* 0x76b2: cmp    r13,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64);
x86_l_76b5:
	/* 0x76b5: jae    7296 <perf_unwind_dotnet+0x7296> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x76b5, 0x7296, x86_l_7296);
x86_l_76bb:
	/* 0x76bb: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_76c0:
	/* 0x76c0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_76c7:
	/* 0x76c7: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_76ca:
	/* 0x76ca: jne    786f <perf_unwind_dotnet+0x786f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x76ca, 0x786f, x86_l_786f);
x86_l_76d0:
	/* 0x76d0: mov    DWORD PTR [rsp+0x68],0x5d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598877ULL);
x86_l_76d8:
	/* 0x76d8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_76df:
	/* 0x76df: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_76e4:
	/* 0x76e4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_76e9:
	/* 0x76e9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_76eb:
	/* 0x76eb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_76ee:
	/* 0x76ee: je     76fc <perf_unwind_dotnet+0x76fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76ee, 0x76fc, x86_l_76fc);
x86_l_76f0:
	/* 0x76f0: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_76f3:
	/* 0x76f3: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_76fa:
	/* 0x76fa: jmp    770d <perf_unwind_dotnet+0x770d> */
	X86_SIM_X86_JMP(0x76fa, 0x770d, x86_l_770d);
x86_l_76fc:
	/* 0x76fc: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_7703:
	/* 0x7703: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7707:
	/* 0x7707: jne    78ee <perf_unwind_dotnet+0x78ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7707, 0x78ee, x86_l_78ee);
x86_l_770d:
	/* 0x770d: mov    eax,0x1771 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 6001ULL);
x86_l_7712:
	/* 0x7712: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7715:
	/* 0x7715: mov    DWORD PTR [r14+0xf2c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3884ULL);
x86_l_771c:
	/* 0x771c: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_7724:
	/* 0x7724: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&per_cpu_records));
x86_l_772b:
	/* 0x772b: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7730:
	/* 0x7730: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_7735:
	/* 0x7735: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7737:
	/* 0x7737: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_773a:
	/* 0x773a: je     777d <perf_unwind_dotnet+0x777d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x773a, 0x777d, x86_l_777d);
x86_l_773c:
	/* 0x773c: movzx  ecx,BYTE PTR [rax+0x1384] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_7743:
	/* 0x7743: mov    edx,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_32);
x86_l_7746:
	/* 0x7746: cmp    cl,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_8, 29ULL);
x86_l_7749:
	/* 0x7749: jb     77a3 <perf_unwind_dotnet+0x77a3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7749, 0x77a3, x86_l_77a3);
x86_l_774b:
	/* 0x774b: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_774e:
	/* 0x774e: mov    DWORD PTR [rax+0xf2c],0x5 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16681652977669ULL);
x86_l_7758:
	/* 0x7758: mov    DWORD PTR [rsp+0x70],0x44 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337220ULL);
x86_l_7760:
	/* 0x7760: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_7767:
	/* 0x7767: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_776c:
	/* 0x776c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_7771:
	/* 0x7771: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7773:
	/* 0x7773: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7776:
	/* 0x7776: je     778d <perf_unwind_dotnet+0x778d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7776, 0x778d, x86_l_778d);
x86_l_7778:
	/* 0x7778: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_777b:
	/* 0x777b: jmp    7797 <perf_unwind_dotnet+0x7797> */
	X86_SIM_X86_JMP(0x777b, 0x7797, x86_l_7797);
x86_l_777d:
	/* 0x777d: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, 0, ((__u64)(long)&perf_progs));
x86_l_7784:
	/* 0x7784: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7786:
	/* 0x7786: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_778b:
	/* 0x778b: jmp    77b9 <perf_unwind_dotnet+0x77b9> */
	X86_SIM_X86_JMP(0x778b, 0x77b9, x86_l_77b9);
x86_l_778d:
	/* 0x778d: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7791:
	/* 0x7791: jne    7969 <perf_unwind_dotnet+0x7969> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7791, 0x7969, x86_l_7969);
x86_l_7797:
	/* 0x7797: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_779a:
	/* 0x779a: movzx  ecx,BYTE PTR [rbx+0x1384] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_77a1:
	/* 0x77a1: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_77a3:
	/* 0x77a3: inc    cl */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_8, X86_ALU_INC, 1);
x86_l_77a5:
	/* 0x77a5: mov    BYTE PTR [rax+0x1384],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4996ULL);
x86_l_77ab:
	/* 0x77ab: mov    ecx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_77ad:
	/* 0x77ad: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)&perf_progs));
x86_l_77b4:
	/* 0x77b4: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_77b9:
	/* 0x77b9: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)&perf_progs));
x86_l_77c0:
	/* 0x77c0: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_77c3:
	/* 0x77c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_77c5:
	/* 0x77c5: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_77c9:
	/* 0x77c9: jne    77e6 <perf_unwind_dotnet+0x77e6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77c9, 0x77e6, x86_l_77e6);
x86_l_77cb:
	/* 0x77cb: mov    eax,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_77d0:
	/* 0x77d0: add    rsp,0x98 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_77d7:
	/* 0x77d7: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_77d8:
	/* 0x77d8: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_77da:
	/* 0x77da: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_77dc:
	/* 0x77dc: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_77de:
	/* 0x77de: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_77e0:
	/* 0x77e0: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_77e1:
	/* 0x77e1: jmp    8cbf <.L__const.unwind_one_dotnet_frame.____fmt.9+0x8c6f> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_77e6:
	/* 0x77e6: movabs rax,0xa64656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2925136540426598ULL);
x86_l_77f0:
	/* 0x77f0: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_77f5:
	/* 0x77f5: movabs rax,0x6620296425282072 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7358927301220245618ULL);
x86_l_77ff:
	/* 0x77ff: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7804:
	/* 0x7804: movabs rax,0x65646e69776e7520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7306085894756136224ULL);
x86_l_780e:
	/* 0x780e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7813:
	/* 0x7813: movabs rax,0x656d617266207478 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7308604914259752056ULL);
x86_l_781d:
	/* 0x781d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7822:
	/* 0x7822: movabs rax,0x656e20726f66206c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7308814921136218220ULL);
x86_l_782c:
	/* 0x782c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7831:
	/* 0x7831: movabs rax,0x6c6163206c696174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809632219746099572ULL);
x86_l_783b:
	/* 0x783b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7840:
	/* 0x7840: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_784a:
	/* 0x784a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_784f:
	/* 0x784f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7854:
	/* 0x7854: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_7859:
	/* 0x7859: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_785e:
	/* 0x785e: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_7863:
	/* 0x7863: mov    edx,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_32);
x86_l_7866:
	/* 0x7866: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7868:
	/* 0x7868: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_786a:
	/* 0x786a: jmp    77cb <perf_unwind_dotnet+0x77cb> */
	X86_SIM_X86_JMP(0x786a, 0x77cb, x86_l_77cb);
x86_l_786f:
	/* 0x786f: movabs rax,0xa786c25202f20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155641773856ULL);
x86_l_7879:
	/* 0x7879: mov    QWORD PTR [rsp+0x35],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_787e:
	/* 0x787e: movabs rax,0x202f20786c252066 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2319108034701631590ULL);
x86_l_7888:
	/* 0x7888: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_788d:
	/* 0x788d: movabs rax,0x666f20726166206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7381153989915975791ULL);
x86_l_7897:
	/* 0x7897: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_789c:
	/* 0x789c: movabs rax,0x6f74207265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8031079711208926825ULL);
x86_l_78a6:
	/* 0x78a6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_78ab:
	/* 0x78ab: movabs rax,0x6f7020656d617266 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8029953755600482918ULL);
x86_l_78b5:
	/* 0x78b5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_78ba:
	/* 0x78ba: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_78c4:
	/* 0x78c4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_78c9:
	/* 0x78c9: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_78ce:
	/* 0x78ce: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
x86_l_78d3:
	/* 0x78d3: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_78d9:
	/* 0x78d9: mov    esi,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 45ULL);
x86_l_78de:
	/* 0x78de: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_78e1:
	/* 0x78e1: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_78e4:
	/* 0x78e4: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_78e6:
	/* 0x78e6: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_78e9:
	/* 0x78e9: jmp    76d0 <perf_unwind_dotnet+0x76d0> */
	X86_SIM_X86_JMP(0x78e9, 0x76d0, x86_l_76d0);
x86_l_78ee:
	/* 0x78ee: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_78f8:
	/* 0x78f8: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_78fd:
	/* 0x78fd: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_7907:
	/* 0x7907: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_790c:
	/* 0x790c: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_7916:
	/* 0x7916: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_791b:
	/* 0x791b: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_7925:
	/* 0x7925: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_792a:
	/* 0x792a: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_7934:
	/* 0x7934: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7939:
	/* 0x7939: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_7943:
	/* 0x7943: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7948:
	/* 0x7948: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_794d:
	/* 0x794d: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_7952:
	/* 0x7952: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_7957:
	/* 0x7957: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_795b:
	/* 0x795b: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_7960:
	/* 0x7960: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7962:
	/* 0x7962: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7964:
	/* 0x7964: jmp    770d <perf_unwind_dotnet+0x770d> */
	X86_SIM_X86_JMP(0x7964, 0x770d, x86_l_770d);
x86_l_7969:
	/* 0x7969: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_7973:
	/* 0x7973: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7978:
	/* 0x7978: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_7982:
	/* 0x7982: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7987:
	/* 0x7987: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_7991:
	/* 0x7991: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7996:
	/* 0x7996: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_79a0:
	/* 0x79a0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_79a5:
	/* 0x79a5: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_79af:
	/* 0x79af: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_79b4:
	/* 0x79b4: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_79be:
	/* 0x79be: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_79c3:
	/* 0x79c3: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_79c8:
	/* 0x79c8: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_79cd:
	/* 0x79cd: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_79d2:
	/* 0x79d2: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_79d6:
	/* 0x79d6: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_79db:
	/* 0x79db: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_79dd:
	/* 0x79dd: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_79df:
	/* 0x79df: jmp    7797 <perf_unwind_dotnet+0x7797> */
	X86_SIM_X86_JMP(0x79df, 0x7797, x86_l_7797);
x86_l_79e4:
	/* 0x79e4: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_79ee:
	/* 0x79ee: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_79f3:
	/* 0x79f3: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_79fd:
	/* 0x79fd: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7a02:
	/* 0x7a02: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_7a0c:
	/* 0x7a0c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7a11:
	/* 0x7a11: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_7a1b:
	/* 0x7a1b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7a20:
	/* 0x7a20: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_7a2a:
	/* 0x7a2a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7a2f:
	/* 0x7a2f: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_7a39:
	/* 0x7a39: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7a3e:
	/* 0x7a3e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7a43:
	/* 0x7a43: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_7a48:
	/* 0x7a48: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_7a4d:
	/* 0x7a4d: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7a51:
	/* 0x7a51: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_7a56:
	/* 0x7a56: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7a58:
	/* 0x7a58: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7a5a:
	/* 0x7a5a: jmp    6c73 <perf_unwind_dotnet+0x6c73> */
	X86_SIM_X86_JMP(0x7a5a, 0x6c73, x86_l_6c73);
x86_l_7a5f:
	/* 0x7a5f: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_7a69:
	/* 0x7a69: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7a6e:
	/* 0x7a6e: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_7a78:
	/* 0x7a78: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7a7d:
	/* 0x7a7d: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_7a87:
	/* 0x7a87: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7a8c:
	/* 0x7a8c: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_7a96:
	/* 0x7a96: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7a9b:
	/* 0x7a9b: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_7aa5:
	/* 0x7aa5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7aaa:
	/* 0x7aaa: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_7ab4:
	/* 0x7ab4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7ab9:
	/* 0x7ab9: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7abe:
	/* 0x7abe: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_7ac3:
	/* 0x7ac3: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_7ac8:
	/* 0x7ac8: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7acc:
	/* 0x7acc: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_7ad1:
	/* 0x7ad1: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7ad3:
	/* 0x7ad3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7ad5:
	/* 0x7ad5: jmp    724d <perf_unwind_dotnet+0x724d> */
	X86_SIM_X86_JMP(0x7ad5, 0x724d, x86_l_724d);
x86_l_7ada:
	/* 0x7ada: movabs rax,0x6c25203a7066202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670165600444460ULL);
x86_l_7ae4:
	/* 0x7ae4: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7ae9:
	/* 0x7ae9: movabs rax,0x786c25203a707320 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8677351402385732384ULL);
x86_l_7af3:
	/* 0x7af3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7af8:
	/* 0x7af8: movabs rax,0x2c786c25203a6370 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 3204430041584395120ULL);
x86_l_7b02:
	/* 0x7b02: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7b07:
	/* 0x7b07: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_7b11:
	/* 0x7b11: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7b16:
	/* 0x7b16: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_7b1e:
	/* 0x7b1e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7b23:
	/* 0x7b23: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_7b28:
	/* 0x7b28: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_7b2e:
	/* 0x7b2e: mov    rdx,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_7b35:
	/* 0x7b35: mov    rcx,QWORD PTR [r14+0xed8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_7b3c:
	/* 0x7b3c: mov    r8,QWORD PTR [r14+0xee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_7b43:
	/* 0x7b43: mov    esi,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 35ULL);
x86_l_7b48:
	/* 0x7b48: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7b4a:
	/* 0x7b4a: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7b4d:
	/* 0x7b4d: cmp    rbp,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_64, 256ULL);
x86_l_7b54:
	/* 0x7b54: jae    7374 <perf_unwind_dotnet+0x7374> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x7b54, 0x7374, x86_l_7374);
x86_l_7b5a:
	/* 0x7b5a: jmp    84ed <perf_unwind_dotnet+0x84ed> */
	X86_SIM_X86_JMP(0x7b5a, 0x84ed, x86_l_84ed);
x86_l_7b5f:
	/* 0x7b5f: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_7b66:
	/* 0x7b66: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7b6b:
	/* 0x7b6b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_7b70:
	/* 0x7b70: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_7b73:
	/* 0x7b73: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_7b76:
	/* 0x7b76: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_7b7d:
	/* 0x7b7d: mov    ecx,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 66ULL);
x86_l_7b82:
	/* 0x7b82: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_7b88:
	/* 0x7b88: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_7b8b:
	/* 0x7b8b: mov    esi,0x42 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 66ULL);
x86_l_7b90:
	/* 0x7b90: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_7b93:
	/* 0x7b93: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_7b96:
	/* 0x7b96: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_7b99:
	/* 0x7b99: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7b9b:
	/* 0x7b9b: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7b9e:
	/* 0x7b9e: jmp    7398 <perf_unwind_dotnet+0x7398> */
	X86_SIM_X86_JMP(0x7b9e, 0x7398, x86_l_7398);
x86_l_7ba3:
	/* 0x7ba3: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_7ba6:
	/* 0x7ba6: and    rdx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_7baa:
	/* 0x7baa: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_7bb4:
	/* 0x7bb4: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_7bb9:
	/* 0x7bb9: movabs rax,0x72746e6520747372 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8247338198237475698ULL);
x86_l_7bc3:
	/* 0x7bc3: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7bc8:
	/* 0x7bc8: movabs rax,0x6966203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7594793257107465504ULL);
x86_l_7bd2:
	/* 0x7bd2: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7bd7:
	/* 0x7bd7: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_7be1:
	/* 0x7be1: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7be6:
	/* 0x7be6: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_7bf0:
	/* 0x7bf0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7bf5:
	/* 0x7bf5: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_7bff:
	/* 0x7bff: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7c04:
	/* 0x7c04: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_7c0e:
	/* 0x7c0e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7c13:
	/* 0x7c13: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7c18:
	/* 0x7c18: mov    eax,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 54ULL);
x86_l_7c1d:
	/* 0x7c1d: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_7c23:
	/* 0x7c23: mov    esi,0x36 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 54ULL);
x86_l_7c28:
	/* 0x7c28: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_7c2b:
	/* 0x7c2b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7c2d:
	/* 0x7c2d: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7c30:
	/* 0x7c30: jmp    7432 <perf_unwind_dotnet+0x7432> */
	X86_SIM_X86_JMP(0x7c30, 0x7432, x86_l_7432);
x86_l_7c35:
	/* 0x7c35: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_7c3f:
	/* 0x7c3f: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7c44:
	/* 0x7c44: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_7c4e:
	/* 0x7c4e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7c53:
	/* 0x7c53: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_7c5d:
	/* 0x7c5d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7c62:
	/* 0x7c62: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_7c6c:
	/* 0x7c6c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7c71:
	/* 0x7c71: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_7c7b:
	/* 0x7c7b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7c80:
	/* 0x7c80: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_7c8a:
	/* 0x7c8a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7c8f:
	/* 0x7c8f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7c94:
	/* 0x7c94: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_7c99:
	/* 0x7c99: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_7c9e:
	/* 0x7c9e: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7ca2:
	/* 0x7ca2: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_7ca7:
	/* 0x7ca7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7ca9:
	/* 0x7ca9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7cab:
	/* 0x7cab: jmp    7482 <perf_unwind_dotnet+0x7482> */
	X86_SIM_X86_JMP(0x7cab, 0x7482, x86_l_7482);
x86_l_7cb0:
	/* 0x7cb0: movabs rax,0xa782520797274 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2946850621059700ULL);
x86_l_7cba:
	/* 0x7cba: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_7cbf:
	/* 0x7cbf: movabs rax,0x746e6520646e6f63 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8389754345636130659ULL);
x86_l_7cc9:
	/* 0x7cc9: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7cce:
	/* 0x7cce: movabs rax,0x6573203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310222055652992288ULL);
x86_l_7cd8:
	/* 0x7cd8: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7cdd:
	/* 0x7cdd: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_7ce7:
	/* 0x7ce7: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7cec:
	/* 0x7cec: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_7cf6:
	/* 0x7cf6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7cfb:
	/* 0x7cfb: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_7d05:
	/* 0x7d05: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7d0a:
	/* 0x7d0a: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_7d14:
	/* 0x7d14: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d19:
	/* 0x7d19: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d1e:
	/* 0x7d1e: mov    eax,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 55ULL);
x86_l_7d23:
	/* 0x7d23: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_7d29:
	/* 0x7d29: mov    esi,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 55ULL);
x86_l_7d2e:
	/* 0x7d2e: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_7d31:
	/* 0x7d31: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_7d34:
	/* 0x7d34: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7d36:
	/* 0x7d36: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7d39:
	/* 0x7d39: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7d3b:
	/* 0x7d3b: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_7d3e:
	/* 0x7d3e: jne    753c <perf_unwind_dotnet+0x753c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7d3e, 0x753c, x86_l_753c);
x86_l_7d44:
	/* 0x7d44: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_7d4b:
	/* 0x7d4b: mov    ecx,0xffffff84 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967172ULL);
x86_l_7d50:
	/* 0x7d50: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7d53:
	/* 0x7d53: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7d53, 0x824b, x86_l_824b);
x86_l_7d59:
	/* 0x7d59: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_7d60:
	/* 0x7d60: mov    ecx,0xffffff86 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967174ULL);
x86_l_7d65:
	/* 0x7d65: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7d68:
	/* 0x7d68: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7d68, 0x824b, x86_l_824b);
x86_l_7d6e:
	/* 0x7d6e: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_7d75:
	/* 0x7d75: mov    ecx,0xffffff88 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967176ULL);
x86_l_7d7a:
	/* 0x7d7a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7d7d:
	/* 0x7d7d: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7d7d, 0x824b, x86_l_824b);
x86_l_7d83:
	/* 0x7d83: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_7d8a:
	/* 0x7d8a: mov    ecx,0xffffff8a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967178ULL);
x86_l_7d8f:
	/* 0x7d8f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7d92:
	/* 0x7d92: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7d92, 0x824b, x86_l_824b);
x86_l_7d98:
	/* 0x7d98: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_7d9f:
	/* 0x7d9f: mov    ecx,0xffffff8c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967180ULL);
x86_l_7da4:
	/* 0x7da4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7da7:
	/* 0x7da7: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7da7, 0x824b, x86_l_824b);
x86_l_7dad:
	/* 0x7dad: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_7db4:
	/* 0x7db4: mov    ecx,0xffffff8e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967182ULL);
x86_l_7db9:
	/* 0x7db9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7dbc:
	/* 0x7dbc: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7dbc, 0x824b, x86_l_824b);
x86_l_7dc2:
	/* 0x7dc2: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_7dc9:
	/* 0x7dc9: mov    ecx,0xffffff90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967184ULL);
x86_l_7dce:
	/* 0x7dce: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7dd1:
	/* 0x7dd1: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7dd1, 0x824b, x86_l_824b);
x86_l_7dd7:
	/* 0x7dd7: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_7dde:
	/* 0x7dde: mov    ecx,0xffffff92 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967186ULL);
x86_l_7de3:
	/* 0x7de3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7de6:
	/* 0x7de6: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7de6, 0x824b, x86_l_824b);
x86_l_7dec:
	/* 0x7dec: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_7df3:
	/* 0x7df3: mov    ecx,0xffffff94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967188ULL);
x86_l_7df8:
	/* 0x7df8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7dfb:
	/* 0x7dfb: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7dfb, 0x824b, x86_l_824b);
x86_l_7e01:
	/* 0x7e01: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_7e08:
	/* 0x7e08: mov    ecx,0xffffff96 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967190ULL);
x86_l_7e0d:
	/* 0x7e0d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e10:
	/* 0x7e10: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e10, 0x824b, x86_l_824b);
x86_l_7e16:
	/* 0x7e16: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_7e1d:
	/* 0x7e1d: mov    ecx,0xffffff98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967192ULL);
x86_l_7e22:
	/* 0x7e22: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e25:
	/* 0x7e25: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e25, 0x824b, x86_l_824b);
x86_l_7e2b:
	/* 0x7e2b: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_7e32:
	/* 0x7e32: mov    ecx,0xffffff9a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967194ULL);
x86_l_7e37:
	/* 0x7e37: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e3a:
	/* 0x7e3a: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e3a, 0x824b, x86_l_824b);
x86_l_7e40:
	/* 0x7e40: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_7e47:
	/* 0x7e47: mov    ecx,0xffffff9c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967196ULL);
x86_l_7e4c:
	/* 0x7e4c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e4f:
	/* 0x7e4f: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e4f, 0x824b, x86_l_824b);
x86_l_7e55:
	/* 0x7e55: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_7e5c:
	/* 0x7e5c: mov    ecx,0xffffff9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967198ULL);
x86_l_7e61:
	/* 0x7e61: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e64:
	/* 0x7e64: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e64, 0x824b, x86_l_824b);
x86_l_7e6a:
	/* 0x7e6a: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_7e71:
	/* 0x7e71: mov    ecx,0xffffffa0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967200ULL);
x86_l_7e76:
	/* 0x7e76: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e79:
	/* 0x7e79: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e79, 0x824b, x86_l_824b);
x86_l_7e7f:
	/* 0x7e7f: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_7e86:
	/* 0x7e86: mov    ecx,0xffffffa2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967202ULL);
x86_l_7e8b:
	/* 0x7e8b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7e8e:
	/* 0x7e8e: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e8e, 0x824b, x86_l_824b);
x86_l_7e94:
	/* 0x7e94: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_7e9b:
	/* 0x7e9b: mov    ecx,0xffffffa4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967204ULL);
x86_l_7ea0:
	/* 0x7ea0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7ea3:
	/* 0x7ea3: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ea3, 0x824b, x86_l_824b);
x86_l_7ea9:
	/* 0x7ea9: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_7eb0:
	/* 0x7eb0: mov    ecx,0xffffffa6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967206ULL);
x86_l_7eb5:
	/* 0x7eb5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7eb8:
	/* 0x7eb8: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7eb8, 0x824b, x86_l_824b);
x86_l_7ebe:
	/* 0x7ebe: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_7ec5:
	/* 0x7ec5: mov    ecx,0xffffffa8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967208ULL);
x86_l_7eca:
	/* 0x7eca: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7ecd:
	/* 0x7ecd: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ecd, 0x824b, x86_l_824b);
x86_l_7ed3:
	/* 0x7ed3: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_7eda:
	/* 0x7eda: mov    ecx,0xffffffaa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967210ULL);
x86_l_7edf:
	/* 0x7edf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7ee2:
	/* 0x7ee2: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ee2, 0x824b, x86_l_824b);
x86_l_7ee8:
	/* 0x7ee8: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_7eef:
	/* 0x7eef: mov    ecx,0xffffffac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967212ULL);
x86_l_7ef4:
	/* 0x7ef4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7ef7:
	/* 0x7ef7: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ef7, 0x824b, x86_l_824b);
x86_l_7efd:
	/* 0x7efd: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_7f04:
	/* 0x7f04: mov    ecx,0xffffffae */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967214ULL);
x86_l_7f09:
	/* 0x7f09: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f0c:
	/* 0x7f0c: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f0c, 0x824b, x86_l_824b);
x86_l_7f12:
	/* 0x7f12: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_7f19:
	/* 0x7f19: mov    ecx,0xffffffb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967216ULL);
x86_l_7f1e:
	/* 0x7f1e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f21:
	/* 0x7f21: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f21, 0x824b, x86_l_824b);
x86_l_7f27:
	/* 0x7f27: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_7f2e:
	/* 0x7f2e: mov    ecx,0xffffffb2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967218ULL);
x86_l_7f33:
	/* 0x7f33: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f36:
	/* 0x7f36: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f36, 0x824b, x86_l_824b);
x86_l_7f3c:
	/* 0x7f3c: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_7f43:
	/* 0x7f43: mov    ecx,0xffffffb4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967220ULL);
x86_l_7f48:
	/* 0x7f48: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f4b:
	/* 0x7f4b: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f4b, 0x824b, x86_l_824b);
x86_l_7f51:
	/* 0x7f51: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_7f58:
	/* 0x7f58: mov    ecx,0xffffffb6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967222ULL);
x86_l_7f5d:
	/* 0x7f5d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f60:
	/* 0x7f60: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f60, 0x824b, x86_l_824b);
x86_l_7f66:
	/* 0x7f66: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_7f6d:
	/* 0x7f6d: mov    ecx,0xffffffb8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967224ULL);
x86_l_7f72:
	/* 0x7f72: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f75:
	/* 0x7f75: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f75, 0x824b, x86_l_824b);
x86_l_7f7b:
	/* 0x7f7b: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_7f82:
	/* 0x7f82: mov    ecx,0xffffffba */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967226ULL);
x86_l_7f87:
	/* 0x7f87: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f8a:
	/* 0x7f8a: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f8a, 0x824b, x86_l_824b);
x86_l_7f90:
	/* 0x7f90: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_7f97:
	/* 0x7f97: mov    ecx,0xffffffbc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967228ULL);
x86_l_7f9c:
	/* 0x7f9c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7f9f:
	/* 0x7f9f: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f9f, 0x824b, x86_l_824b);
x86_l_7fa5:
	/* 0x7fa5: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_7fac:
	/* 0x7fac: mov    ecx,0xffffffbe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967230ULL);
x86_l_7fb1:
	/* 0x7fb1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7fb4:
	/* 0x7fb4: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7fb4, 0x824b, x86_l_824b);
x86_l_7fba:
	/* 0x7fba: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_7fc1:
	/* 0x7fc1: mov    ecx,0xffffffc0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967232ULL);
x86_l_7fc6:
	/* 0x7fc6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7fc9:
	/* 0x7fc9: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7fc9, 0x824b, x86_l_824b);
x86_l_7fcf:
	/* 0x7fcf: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_7fd6:
	/* 0x7fd6: mov    ecx,0xffffffc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967234ULL);
x86_l_7fdb:
	/* 0x7fdb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7fde:
	/* 0x7fde: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7fde, 0x824b, x86_l_824b);
x86_l_7fe4:
	/* 0x7fe4: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_7feb:
	/* 0x7feb: mov    ecx,0xffffffc4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967236ULL);
x86_l_7ff0:
	/* 0x7ff0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7ff3:
	/* 0x7ff3: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ff3, 0x824b, x86_l_824b);
x86_l_7ff9:
	/* 0x7ff9: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_8000:
	/* 0x8000: mov    ecx,0xffffffc6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967238ULL);
x86_l_8005:
	/* 0x8005: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8008:
	/* 0x8008: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8008, 0x824b, x86_l_824b);
x86_l_800e:
	/* 0x800e: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_8015:
	/* 0x8015: mov    ecx,0xffffffc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967240ULL);
x86_l_801a:
	/* 0x801a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_801d:
	/* 0x801d: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x801d, 0x824b, x86_l_824b);
x86_l_8023:
	/* 0x8023: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_802a:
	/* 0x802a: mov    ecx,0xffffffca */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967242ULL);
x86_l_802f:
	/* 0x802f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8032:
	/* 0x8032: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8032, 0x824b, x86_l_824b);
x86_l_8038:
	/* 0x8038: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_803f:
	/* 0x803f: mov    ecx,0xffffffcc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967244ULL);
x86_l_8044:
	/* 0x8044: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8047:
	/* 0x8047: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8047, 0x824b, x86_l_824b);
x86_l_804d:
	/* 0x804d: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_8054:
	/* 0x8054: mov    ecx,0xffffffce */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967246ULL);
x86_l_8059:
	/* 0x8059: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_805c:
	/* 0x805c: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x805c, 0x824b, x86_l_824b);
x86_l_8062:
	/* 0x8062: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_8069:
	/* 0x8069: mov    ecx,0xffffffd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967248ULL);
x86_l_806e:
	/* 0x806e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8071:
	/* 0x8071: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8071, 0x824b, x86_l_824b);
x86_l_8077:
	/* 0x8077: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_807e:
	/* 0x807e: mov    ecx,0xffffffd2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967250ULL);
x86_l_8083:
	/* 0x8083: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8086:
	/* 0x8086: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8086, 0x824b, x86_l_824b);
x86_l_808c:
	/* 0x808c: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_8093:
	/* 0x8093: mov    ecx,0xffffffd4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967252ULL);
x86_l_8098:
	/* 0x8098: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_809b:
	/* 0x809b: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x809b, 0x824b, x86_l_824b);
x86_l_80a1:
	/* 0x80a1: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_80a8:
	/* 0x80a8: mov    ecx,0xffffffd6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967254ULL);
x86_l_80ad:
	/* 0x80ad: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_80b0:
	/* 0x80b0: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x80b0, 0x824b, x86_l_824b);
x86_l_80b6:
	/* 0x80b6: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_80bd:
	/* 0x80bd: mov    ecx,0xffffffd8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967256ULL);
x86_l_80c2:
	/* 0x80c2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_80c5:
	/* 0x80c5: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x80c5, 0x824b, x86_l_824b);
x86_l_80cb:
	/* 0x80cb: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_80d2:
	/* 0x80d2: mov    ecx,0xffffffda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967258ULL);
x86_l_80d7:
	/* 0x80d7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_80da:
	/* 0x80da: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x80da, 0x824b, x86_l_824b);
x86_l_80e0:
	/* 0x80e0: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_80e7:
	/* 0x80e7: mov    ecx,0xffffffdc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967260ULL);
x86_l_80ec:
	/* 0x80ec: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_80ef:
	/* 0x80ef: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x80ef, 0x824b, x86_l_824b);
x86_l_80f5:
	/* 0x80f5: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_80fc:
	/* 0x80fc: mov    ecx,0xffffffde */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967262ULL);
x86_l_8101:
	/* 0x8101: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8104:
	/* 0x8104: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8104, 0x824b, x86_l_824b);
x86_l_810a:
	/* 0x810a: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_8111:
	/* 0x8111: mov    ecx,0xffffffe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967264ULL);
x86_l_8116:
	/* 0x8116: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8119:
	/* 0x8119: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8119, 0x824b, x86_l_824b);
x86_l_811f:
	/* 0x811f: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_8126:
	/* 0x8126: mov    ecx,0xffffffe2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967266ULL);
x86_l_812b:
	/* 0x812b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_812e:
	/* 0x812e: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x812e, 0x824b, x86_l_824b);
x86_l_8134:
	/* 0x8134: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_813b:
	/* 0x813b: mov    ecx,0xffffffe4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967268ULL);
x86_l_8140:
	/* 0x8140: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8143:
	/* 0x8143: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8143, 0x824b, x86_l_824b);
x86_l_8149:
	/* 0x8149: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_8150:
	/* 0x8150: mov    ecx,0xffffffe6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967270ULL);
x86_l_8155:
	/* 0x8155: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8158:
	/* 0x8158: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8158, 0x824b, x86_l_824b);
x86_l_815e:
	/* 0x815e: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_8165:
	/* 0x8165: mov    ecx,0xffffffe8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967272ULL);
x86_l_816a:
	/* 0x816a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_816d:
	/* 0x816d: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x816d, 0x824b, x86_l_824b);
x86_l_8173:
	/* 0x8173: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_817a:
	/* 0x817a: mov    ecx,0xffffffea */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967274ULL);
x86_l_817f:
	/* 0x817f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8182:
	/* 0x8182: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8182, 0x824b, x86_l_824b);
x86_l_8188:
	/* 0x8188: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_818f:
	/* 0x818f: mov    ecx,0xffffffec */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967276ULL);
x86_l_8194:
	/* 0x8194: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8197:
	/* 0x8197: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8197, 0x824b, x86_l_824b);
x86_l_819d:
	/* 0x819d: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_81a4:
	/* 0x81a4: mov    ecx,0xffffffee */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967278ULL);
x86_l_81a9:
	/* 0x81a9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_81ac:
	/* 0x81ac: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x81ac, 0x824b, x86_l_824b);
x86_l_81b2:
	/* 0x81b2: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_81b9:
	/* 0x81b9: mov    ecx,0xfffffff0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967280ULL);
x86_l_81be:
	/* 0x81be: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_81c1:
	/* 0x81c1: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x81c1, 0x824b, x86_l_824b);
x86_l_81c7:
	/* 0x81c7: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_81ce:
	/* 0x81ce: mov    ecx,0xfffffff2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967282ULL);
x86_l_81d3:
	/* 0x81d3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_81d6:
	/* 0x81d6: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x81d6, 0x824b, x86_l_824b);
x86_l_81d8:
	/* 0x81d8: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_81df:
	/* 0x81df: mov    ecx,0xfffffff4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967284ULL);
x86_l_81e4:
	/* 0x81e4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_81e7:
	/* 0x81e7: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x81e7, 0x824b, x86_l_824b);
x86_l_81e9:
	/* 0x81e9: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_81f0:
	/* 0x81f0: mov    ecx,0xfffffff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967286ULL);
x86_l_81f5:
	/* 0x81f5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_81f8:
	/* 0x81f8: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x81f8, 0x824b, x86_l_824b);
x86_l_81fa:
	/* 0x81fa: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_8201:
	/* 0x8201: mov    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967288ULL);
x86_l_8206:
	/* 0x8206: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8209:
	/* 0x8209: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8209, 0x824b, x86_l_824b);
x86_l_820b:
	/* 0x820b: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_8212:
	/* 0x8212: mov    ecx,0xfffffffa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967290ULL);
x86_l_8217:
	/* 0x8217: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_821a:
	/* 0x821a: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x821a, 0x824b, x86_l_824b);
x86_l_821c:
	/* 0x821c: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_8223:
	/* 0x8223: mov    ecx,0xfffffffc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967292ULL);
x86_l_8228:
	/* 0x8228: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_822b:
	/* 0x822b: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x822b, 0x824b, x86_l_824b);
x86_l_822d:
	/* 0x822d: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_8234:
	/* 0x8234: mov    ecx,0xfffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967294ULL);
x86_l_8239:
	/* 0x8239: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_823c:
	/* 0x823c: jne    824b <perf_unwind_dotnet+0x824b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x823c, 0x824b, x86_l_824b);
x86_l_823e:
	/* 0x823e: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8246:
	/* 0x8246: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8249:
	/* 0x8249: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_824b:
	/* 0x824b: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_824d:
	/* 0x824d: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_8250:
	/* 0x8250: shr    r15,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_8254:
	/* 0x8254: setne  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_NE);
x86_l_8257:
	/* 0x8257: cmove  r15d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_825b:
	/* 0x825b: sub    ecx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_825d:
	/* 0x825d: add    ecx,0x7e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_8260:
	/* 0x8260: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_8262:
	/* 0x8262: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_8265:
	/* 0x8265: sub    r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_8268:
	/* 0x8268: jb     754a <perf_unwind_dotnet+0x754a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8268, 0x754a, x86_l_754a);
x86_l_826e:
	/* 0x826e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_8275:
	/* 0x8275: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8278:
	/* 0x8278: jne    83cb <perf_unwind_dotnet+0x83cb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8278, 0x83cb, x86_l_83cb);
x86_l_827e:
	/* 0x827e: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_8281:
	/* 0x8281: jne    744e <perf_unwind_dotnet+0x744e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8281, 0x744e, x86_l_744e);
x86_l_8287:
	/* 0x8287: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_828f:
	/* 0x828f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_8296:
	/* 0x8296: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_829b:
	/* 0x829b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_82a0:
	/* 0x82a0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_82a2:
	/* 0x82a2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_82a5:
	/* 0x82a5: je     82af <perf_unwind_dotnet+0x82af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82a5, 0x82af, x86_l_82af);
x86_l_82a7:
	/* 0x82a7: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_82aa:
	/* 0x82aa: jmp    8331 <perf_unwind_dotnet+0x8331> */
	X86_SIM_X86_JMP(0x82aa, 0x8331, x86_l_8331);
x86_l_82af:
	/* 0x82af: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_82b6:
	/* 0x82b6: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_82b9:
	/* 0x82b9: je     8331 <perf_unwind_dotnet+0x8331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82b9, 0x8331, x86_l_8331);
x86_l_82bb:
	/* 0x82bb: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_82c5:
	/* 0x82c5: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_82ca:
	/* 0x82ca: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_82d4:
	/* 0x82d4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_82d9:
	/* 0x82d9: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_82e3:
	/* 0x82e3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_82e8:
	/* 0x82e8: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_82f2:
	/* 0x82f2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_82f7:
	/* 0x82f7: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_8301:
	/* 0x8301: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8306:
	/* 0x8306: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_8310:
	/* 0x8310: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8315:
	/* 0x8315: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_831a:
	/* 0x831a: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_831f:
	/* 0x831f: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8324:
	/* 0x8324: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_8328:
	/* 0x8328: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_832d:
	/* 0x832d: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_832f:
	/* 0x832f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8331:
	/* 0x8331: mov    edx,0x1773 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 6003ULL);
x86_l_8336:
	/* 0x8336: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_833b:
	/* 0x833b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_8342:
	/* 0x8342: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8345:
	/* 0x8345: je     7499 <perf_unwind_dotnet+0x7499> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8345, 0x7499, x86_l_7499);
x86_l_834b:
	/* 0x834b: movabs rax,0xa642520687469 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387390569ULL);
x86_l_8355:
	/* 0x8355: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_835a:
	/* 0x835a: movabs rax,0x772064656c696166 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8583971276541485414ULL);
x86_l_8364:
	/* 0x8364: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8369:
	/* 0x8369: movabs rax,0x2074726174735f65 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2338619869403242341ULL);
x86_l_8373:
	/* 0x8373: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8378:
	/* 0x8378: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7237112116340927776ULL);
x86_l_8382:
	/* 0x8382: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8387:
	/* 0x8387: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_8391:
	/* 0x8391: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8396:
	/* 0x8396: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_839b:
	/* 0x839b: mov    eax,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 40ULL);
x86_l_83a0:
	/* 0x83a0: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_83a5:
	/* 0x83a5: mov    esi,0x28 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 40ULL);
x86_l_83aa:
	/* 0x83aa: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_83ac:
	/* 0x83ac: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_83ae:
	/* 0x83ae: jmp    7499 <perf_unwind_dotnet+0x7499> */
	X86_SIM_X86_JMP(0x83ae, 0x7499, x86_l_7499);
x86_l_83b3:
	/* 0x83b3: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_83b6:
	/* 0x83b6: shr    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_83b9:
	/* 0x83b9: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_83bc:
	/* 0x83bc: je     846a <perf_unwind_dotnet+0x846a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x83bc, 0x846a, x86_l_846a);
x86_l_83c2:
	/* 0x83c2: add    r13,0xffffffffffffff80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_83c6:
	/* 0x83c6: jmp    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JMP(0x83c6, 0x84a0, x86_l_84a0);
x86_l_83cb:
	/* 0x83cb: movabs rax,0x207972746e65202c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2340027325789577260ULL);
x86_l_83d5:
	/* 0x83d5: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_83da:
	/* 0x83da: movabs rax,0x6425206465707069 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7216209593501773929ULL);
x86_l_83e4:
	/* 0x83e4: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_83e9:
	/* 0x83e9: movabs rax,0x6b73203a786c2520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7742567619880559904ULL);
x86_l_83f3:
	/* 0x83f3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_83f8:
	/* 0x83f8: movabs rax,0x726f662074726174 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732317307252ULL);
x86_l_8402:
	/* 0x8402: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8407:
	/* 0x8407: movabs rax,0x732065646f632064 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8295741995656355940ULL);
x86_l_8411:
	/* 0x8411: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8416:
	/* 0x8416: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7956002505394826528ULL);
x86_l_8420:
	/* 0x8420: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8425:
	/* 0x8425: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_842f:
	/* 0x842f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8434:
	/* 0x8434: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_843c:
	/* 0x843c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8441:
	/* 0x8441: mov    eax,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 60ULL);
x86_l_8446:
	/* 0x8446: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_844c:
	/* 0x844c: mov    esi,0x3c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 60ULL);
x86_l_8451:
	/* 0x8451: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_8454:
	/* 0x8454: mov    r8d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_32);
x86_l_8457:
	/* 0x8457: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8459:
	/* 0x8459: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_845c:
	/* 0x845c: test   r15d,r15d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32);
x86_l_845f:
	/* 0x845f: jne    744e <perf_unwind_dotnet+0x744e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x845f, 0x744e, x86_l_744e);
x86_l_8465:
	/* 0x8465: jmp    8287 <perf_unwind_dotnet+0x8287> */
	X86_SIM_X86_JMP(0x8465, 0x8287, x86_l_8287);
x86_l_846a:
	/* 0x846a: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_846d:
	/* 0x846d: shr    ecx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_8470:
	/* 0x8470: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_8473:
	/* 0x8473: je     847e <perf_unwind_dotnet+0x847e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8473, 0x847e, x86_l_847e);
x86_l_8475:
	/* 0x8475: add    r13,0xffffffffffffff60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_847c:
	/* 0x847c: jmp    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JMP(0x847c, 0x84a0, x86_l_84a0);
x86_l_847e:
	/* 0x847e: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_8481:
	/* 0x8481: shr    ecx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_8484:
	/* 0x8484: and    ecx,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_8487:
	/* 0x8487: je     8492 <perf_unwind_dotnet+0x8492> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8487, 0x8492, x86_l_8492);
x86_l_8489:
	/* 0x8489: add    r13,0xffffffffffffff40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_8490:
	/* 0x8490: jmp    84a0 <perf_unwind_dotnet+0x84a0> */
	X86_SIM_X86_JMP(0x8490, 0x84a0, x86_l_84a0);
x86_l_8492:
	/* 0x8492: shr    r15d,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_8496:
	/* 0x8496: add    r13,0xffffffffffffff20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_849d:
	/* 0x849d: mov    ecx,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R15, X86_WIDTH_32);
x86_l_84a0:
	/* 0x84a0: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_84a3:
	/* 0x84a3: lea    r15d,[rcx*4-0x4] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 18446744073709551612ULL);
x86_l_84ab:
	/* 0x84ab: add    r15,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_84ae:
	/* 0x84ae: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_84b5:
	/* 0x84b5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84b8:
	/* 0x84b8: jne    8885 <perf_unwind_dotnet+0x8885> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x84b8, 0x8885, x86_l_8885);
x86_l_84be:
	/* 0x84be: lea    rdx,[r15-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_84c2:
	/* 0x84c2: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_84c7:
	/* 0x84c7: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_84cc:
	/* 0x84cc: mov    ecx,0x70 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 112ULL);
x86_l_84d1:
	/* 0x84d1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_84d6:
	/* 0x84d6: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_BPF_CALL_bpf_probe_read_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_84d8:
	/* 0x84d8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_84db:
	/* 0x84db: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_84e2:
	/* 0x84e2: jne    b73 <perf_unwind_dotnet+0xb73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x84e2, 0xb73, x86_l_b73);
x86_l_84e8:
	/* 0x84e8: mov    ebp,0x1f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 31ULL);
x86_l_84ed:
	/* 0x84ed: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_84f4:
	/* 0x84f4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84f7:
	/* 0x84f7: jne    8904 <perf_unwind_dotnet+0x8904> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x84f7, 0x8904, x86_l_8904);
x86_l_84fd:
	/* 0x84fd: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_8504:
	/* 0x8504: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_8508:
	/* 0x8508: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8508, 0xbc9, x86_l_bc9);
x86_l_850e:
	/* 0x850e: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8513:
	/* 0x8513: sub    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_8516:
	/* 0x8516: shl    rcx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_851a:
	/* 0x851a: add    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_851d:
	/* 0x851d: lea    edx,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_8520:
	/* 0x8520: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_8527:
	/* 0x8527: lea    rax,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_852b:
	/* 0x852b: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_8533:
	/* 0x8533: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_853b:
	/* 0x853b: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_8544:
	/* 0x8544: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_8549:
	/* 0x8549: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_8551:
	/* 0x8551: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_855d:
	/* 0x855d: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_8568:
	/* 0x8568: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_8570:
	/* 0x8570: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_8577:
	/* 0x8577: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_857c:
	/* 0x857c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_8581:
	/* 0x8581: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8583:
	/* 0x8583: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8586:
	/* 0x8586: je     858d <perf_unwind_dotnet+0x858d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8586, 0x858d, x86_l_858d);
x86_l_8588:
	/* 0x8588: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_858b:
	/* 0x858b: jmp    859d <perf_unwind_dotnet+0x859d> */
	X86_SIM_X86_JMP(0x858b, 0x859d, x86_l_859d);
x86_l_858d:
	/* 0x858d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_8594:
	/* 0x8594: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8597:
	/* 0x8597: jne    8963 <perf_unwind_dotnet+0x8963> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8597, 0x8963, x86_l_8963);
x86_l_859d:
	/* 0x859d: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_85a5:
	/* 0x85a5: mov    r13,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85a8:
	/* 0x85a8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_85af:
	/* 0x85af: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85b1:
	/* 0x85b1: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_85b4:
	/* 0x85b4: je     87f5 <perf_unwind_dotnet+0x87f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85b4, 0x87f5, x86_l_87f5);
x86_l_85ba:
	/* 0x85ba: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_85bc:
	/* 0x85bc: jne    89de <perf_unwind_dotnet+0x89de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x85bc, 0x89de, x86_l_89de);
x86_l_85c2:
	/* 0x85c2: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_85cc:
	/* 0x85cc: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_85cf:
	/* 0x85cf: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x85cf, 0x24b3, x86_l_24b3);
x86_l_85d5:
	/* 0x85d5: cmp    r13,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 4096ULL);
x86_l_85dc:
	/* 0x85dc: jb     264e <perf_unwind_dotnet+0x264e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x85dc, 0x264e, x86_l_264e);
x86_l_85e2:
	/* 0x85e2: mov    eax,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85e5:
	/* 0x85e5: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_85ed:
	/* 0x85ed: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_85f3:
	/* 0x85f3: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_MOVBE_STORE(X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_85fa:
	/* 0x85fa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&pid_page_to_mapping_info));
x86_l_8601:
	/* 0x8601: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8606:
	/* 0x8606: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_860b:
	/* 0x860b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_860d:
	/* 0x860d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8610:
	/* 0x8610: je     8740 <perf_unwind_dotnet+0x8740> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8610, 0x8740, x86_l_8740);
x86_l_8616:
	/* 0x8616: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_861a:
	/* 0x861a: movabs rcx,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_8624:
	/* 0x8624: and    rcx,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_8627:
	/* 0x8627: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_862e:
	/* 0x862e: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8631:
	/* 0x8631: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_8638:
	/* 0x8638: shr    r12,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_863c:
	/* 0x863c: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_863f:
	/* 0x863f: sub    rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_8642:
	/* 0x8642: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_8649:
	/* 0x8649: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_8650:
	/* 0x8650: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8653:
	/* 0x8653: jne    8a7b <perf_unwind_dotnet+0x8a7b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8653, 0x8a7b, x86_l_8a7b);
x86_l_8659:
	/* 0x8659: cmp    r12d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 1ULL);
x86_l_865d:
	/* 0x865d: jne    8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x865d, 0x8cac, x86_l_8cac);
x86_l_8663:
	/* 0x8663: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_866a:
	/* 0x866a: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_866f:
	/* 0x866f: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_8676:
	/* 0x8676: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&interpreter_offsets));
x86_l_867d:
	/* 0x867d: lea    rsi,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8682:
	/* 0x8682: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_8687:
	/* 0x8687: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8689:
	/* 0x8689: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_868f:
	/* 0x868f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8692:
	/* 0x8692: je     8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8692, 0x8cac, x86_l_8cac);
x86_l_8698:
	/* 0x8698: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_869b:
	/* 0x869b: cmp    QWORD PTR [rax],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_869e:
	/* 0x869e: ja     86a6 <perf_unwind_dotnet+0x86a6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x869e, 0x86a6, x86_l_86a6);
x86_l_86a0:
	/* 0x86a0: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_86a4:
	/* 0x86a4: jae    86ba <perf_unwind_dotnet+0x86ba> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x86a4, 0x86ba, x86_l_86ba);
x86_l_86a6:
	/* 0x86a6: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_86aa:
	/* 0x86aa: ja     8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_A, 0x86aa, 0x8cac, x86_l_8cac);
x86_l_86b0:
	/* 0x86b0: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_86b4:
	/* 0x86b4: jb     8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x86b4, 0x8cac, x86_l_8cac);
x86_l_86ba:
	/* 0x86ba: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_86c1:
	/* 0x86c1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86c4:
	/* 0x86c4: jne    8b90 <perf_unwind_dotnet+0x8b90> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x86c4, 0x8b90, x86_l_8b90);
x86_l_86ca:
	/* 0x86ca: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_86d1:
	/* 0x86d1: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_86d5:
	/* 0x86d5: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_86d8:
	/* 0x86d8: jae    8bfd <perf_unwind_dotnet+0x8bfd> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x86d8, 0x8bfd, x86_l_8bfd);
x86_l_86de:
	/* 0x86de: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_86e5:
	/* 0x86e5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86e8:
	/* 0x86e8: je     8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x86e8, 0x8cac, x86_l_8cac);
x86_l_86ee:
	/* 0x86ee: movabs rax,0x6e6f64207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7957689157107934318ULL);
x86_l_86f8:
	/* 0x86f8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_86fd:
	/* 0x86fd: movabs rax,0x69776e7520726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345545598324ULL);
x86_l_8707:
	/* 0x8707: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_870c:
	/* 0x870c: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_8716:
	/* 0x8716: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_871b:
	/* 0x871b: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_8723:
	/* 0x8723: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8728:
	/* 0x8728: mov    eax,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_872d:
	/* 0x872d: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8732:
	/* 0x8732: mov    esi,0x1b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 27ULL);
x86_l_8737:
	/* 0x8737: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8739:
	/* 0x8739: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_873b:
	/* 0x873b: jmp    8cac <perf_unwind_dotnet+0x8cac> */
	X86_SIM_X86_JMP(0x873b, 0x8cac, x86_l_8cac);
x86_l_8740:
	/* 0x8740: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8745:
	/* 0x8745: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_874c:
	/* 0x874c: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8750:
	/* 0x8750: jne    8767 <perf_unwind_dotnet+0x8767> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8750, 0x8767, x86_l_8767);
x86_l_8752:
	/* 0x8752: mov    DWORD PTR [r14+0xf28],0xc */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108492ULL);
x86_l_875d:
	/* 0x875d: mov    eax,0xfac */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4012ULL);
x86_l_8762:
	/* 0x8762: jmp    7712 <perf_unwind_dotnet+0x7712> */
	X86_SIM_X86_JMP(0x8762, 0x7712, x86_l_7712);
x86_l_8767:
	/* 0x8767: movabs rax,0xa786c2578302043 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 754471845770567747ULL);
x86_l_8771:
	/* 0x8771: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_8776:
	/* 0x8776: movabs rax,0x5020726f6620676e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5773740545069311854ULL);
x86_l_8780:
	/* 0x8780: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8785:
	/* 0x8785: movabs rax,0x697070616d207972 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7597696135119010162ULL);
x86_l_878f:
	/* 0x878f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8794:
	/* 0x8794: movabs rax,0x6f6d656d206c6176 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8029185230041276790ULL);
x86_l_879e:
	/* 0x879e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_87a3:
	/* 0x87a3: movabs rax,0x7265746e69207075 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243122710530519157ULL);
x86_l_87ad:
	/* 0x87ad: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_87b2:
	/* 0x87b2: movabs rax,0x206b6f6f6c206f74 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2336083356067852148ULL);
x86_l_87bc:
	/* 0x87bc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_87c1:
	/* 0x87c1: movabs rax,0x206572756c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334397830517055814ULL);
x86_l_87cb:
	/* 0x87cb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_87d0:
	/* 0x87d0: mov    BYTE PTR [rsp+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_87d5:
	/* 0x87d5: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_87da:
	/* 0x87da: mov    eax,0x39 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 57ULL);
x86_l_87df:
	/* 0x87df: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_87e4:
	/* 0x87e4: mov    esi,0x39 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 57ULL);
x86_l_87e9:
	/* 0x87e9: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_87ec:
	/* 0x87ec: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_87ee:
	/* 0x87ee: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_87f0:
	/* 0x87f0: jmp    8752 <perf_unwind_dotnet+0x8752> */
	X86_SIM_X86_JMP(0x87f0, 0x8752, x86_l_8752);
x86_l_87f5:
	/* 0x87f5: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_87fa:
	/* 0x87fa: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_8801:
	/* 0x8801: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_8803:
	/* 0x8803: je     2539 <perf_unwind_dotnet+0x2539> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8803, 0x2539, x86_l_2539);
x86_l_8809:
	/* 0x8809: movabs rax,0xa2930203d3d2043 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 732169329448919107ULL);
x86_l_8813:
	/* 0x8813: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8818:
	/* 0x8818: movabs rax,0x5028206572756c69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5775902142186744937ULL);
x86_l_8822:
	/* 0x8822: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8827:
	/* 0x8827: movabs rax,0x616620646e69776e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7018332685024720750ULL);
x86_l_8831:
	/* 0x8831: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8836:
	/* 0x8836: movabs rax,0x75206f7420657564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8439868246242719076ULL);
x86_l_8840:
	/* 0x8840: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8845:
	/* 0x8845: movabs rax,0x20646e69776e7520 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334111906139108640ULL);
x86_l_884f:
	/* 0x884f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8854:
	/* 0x8854: movabs rax,0x676e6970706f7453 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7453010364988355667ULL);
x86_l_885e:
	/* 0x885e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8863:
	/* 0x8863: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_8868:
	/* 0x8868: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_886d:
	/* 0x886d: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_8872:
	/* 0x8872: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8877:
	/* 0x8877: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_887c:
	/* 0x887c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_887e:
	/* 0x887e: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8880:
	/* 0x8880: jmp    2539 <perf_unwind_dotnet+0x2539> */
	X86_SIM_X86_JMP(0x8880, 0x2539, x86_l_2539);
x86_l_8885:
	/* 0x8885: movabs rax,0xa786c253d7465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947155643692133ULL);
x86_l_888f:
	/* 0x888f: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_8894:
	/* 0x8894: movabs rax,0x746572202c78253d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8387235363558008125ULL);
x86_l_889e:
	/* 0x889e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_88a3:
	/* 0x88a3: movabs rax,0x6c6176202c786c25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7809653109394271269ULL);
x86_l_88ad:
	/* 0x88ad: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_88b2:
	/* 0x88b2: movabs rax,0x203d2061746c6564 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2323048585730221412ULL);
x86_l_88bc:
	/* 0x88bc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_88c1:
	/* 0x88c1: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6873460740081921312ULL);
x86_l_88cb:
	/* 0x88cb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_88d0:
	/* 0x88d0: movabs rax,0x203a74656e746f64 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2322296536856555364ULL);
x86_l_88da:
	/* 0x88da: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_88df:
	/* 0x88df: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_88e4:
	/* 0x88e4: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_88e9:
	/* 0x88e9: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_88ef:
	/* 0x88ef: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_88f4:
	/* 0x88f4: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_88f7:
	/* 0x88f7: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
x86_l_88fa:
	/* 0x88fa: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_88fc:
	/* 0x88fc: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_88ff:
	/* 0x88ff: jmp    84be <perf_unwind_dotnet+0x84be> */
	X86_SIM_X86_JMP(0x88ff, 0x84be, x86_l_84be);
x86_l_8904:
	/* 0x8904: lea    rsi,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_890b:
	/* 0x890b: lea    rax,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8910:
	/* 0x8910: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_8915:
	/* 0x8915: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_8918:
	/* 0x8918: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_L_EXEC_REP_MOVS(X86_WIDTH_64, 8ULL);
x86_l_891b:
	/* 0x891b: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_8920:
	/* 0x8920: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_8927:
	/* 0x8927: mov    ecx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 67ULL);
x86_l_892c:
	/* 0x892c: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_8932:
	/* 0x8932: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8937:
	/* 0x8937: mov    r8,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_64);
x86_l_893a:
	/* 0x893a: sub    r8,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB);
x86_l_893d:
	/* 0x893d: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_8940:
	/* 0x8940: mov    esi,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 67ULL);
x86_l_8945:
	/* 0x8945: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_8948:
	/* 0x8948: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_894a:
	/* 0x894a: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_894d:
	/* 0x894d: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_8954:
	/* 0x8954: cmp    rax,0x7e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 126ULL);
x86_l_8958:
	/* 0x8958: ja     bc9 <perf_unwind_dotnet+0xbc9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8958, 0xbc9, x86_l_bc9);
x86_l_895e:
	/* 0x895e: jmp    850e <perf_unwind_dotnet+0x850e> */
	X86_SIM_X86_JMP(0x895e, 0x850e, x86_l_850e);
x86_l_8963:
	/* 0x8963: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_896d:
	/* 0x896d: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_8972:
	/* 0x8972: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_897c:
	/* 0x897c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8981:
	/* 0x8981: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_898b:
	/* 0x898b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8990:
	/* 0x8990: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_899a:
	/* 0x899a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_899f:
	/* 0x899f: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_89a9:
	/* 0x89a9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_89ae:
	/* 0x89ae: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_89b8:
	/* 0x89b8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_89bd:
	/* 0x89bd: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_89c2:
	/* 0x89c2: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_89c7:
	/* 0x89c7: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_89cc:
	/* 0x89cc: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_89d0:
	/* 0x89d0: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_89d5:
	/* 0x89d5: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_89d7:
	/* 0x89d7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_89d9:
	/* 0x89d9: jmp    859d <perf_unwind_dotnet+0x859d> */
	X86_SIM_X86_JMP(0x89d9, 0x859d, x86_l_859d);
x86_l_89de:
	/* 0x89de: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 737813247186461733ULL);
x86_l_89e8:
	/* 0x89e8: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_89ed:
	/* 0x89ed: movabs rax,0x20656d617266203a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021050ULL);
x86_l_89f7:
	/* 0x89f7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_89fc:
	/* 0x89fc: movabs rax,0x7265646e69776e75 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8243105118350175861ULL);
x86_l_8a06:
	/* 0x8a06: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8a0b:
	/* 0x8a0b: movabs rax,0x20656d6172662074 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334392247160021108ULL);
x86_l_8a15:
	/* 0x8a15: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8a1a:
	/* 0x8a1a: movabs rax,0x78656e2065766c6f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8675461342619397231ULL);
x86_l_8a24:
	/* 0x8a24: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8a29:
	/* 0x8a29: movabs rax,0x736552203d3d3d3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315142585429343549ULL);
x86_l_8a33:
	/* 0x8a33: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8a38:
	/* 0x8a38: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_8a3d:
	/* 0x8a3d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8a42:
	/* 0x8a42: mov    eax,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 49ULL);
x86_l_8a47:
	/* 0x8a47: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8a4c:
	/* 0x8a4c: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_8a53:
	/* 0x8a53: mov    esi,0x31 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 49ULL);
x86_l_8a58:
	/* 0x8a58: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8a5a:
	/* 0x8a5a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8a5c:
	/* 0x8a5c: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_8a63:
	/* 0x8a63: movabs rax,0xffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 72057594037927935ULL);
x86_l_8a6d:
	/* 0x8a6d: cmp    r13,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_8a70:
	/* 0x8a70: ja     24b3 <perf_unwind_dotnet+0x24b3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8a70, 0x24b3, x86_l_24b3);
x86_l_8a76:
	/* 0x8a76: jmp    85d5 <perf_unwind_dotnet+0x85d5> */
	X86_SIM_X86_JMP(0x8a76, 0x85d5, x86_l_85d5);
x86_l_8a7b:
	/* 0x8a7b: movabs rax,0x296425207265646e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2982549674514539630ULL);
x86_l_8a85:
	/* 0x8a85: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8a8a:
	/* 0x8a8a: movabs rax,0x69776e752820786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7599664345674446956ULL);
x86_l_8a94:
	/* 0x8a94: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8a99:
	/* 0x8a99: movabs rax,0x6c2520736920786c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7792670410291574892ULL);
x86_l_8aa3:
	/* 0x8aa3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8aa8:
	/* 0x8aa8: movabs rax,0x2520435020726f66 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2675212190078889830ULL);
x86_l_8ab2:
	/* 0x8ab2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8ab7:
	/* 0x8ab7: movabs rax,0x206469206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2334106094897424756ULL);
x86_l_8ac1:
	/* 0x8ac1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8ac6:
	/* 0x8ac6: movabs rbx,0x6365732074786554 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 7162257365632836948ULL);
x86_l_8ad0:
	/* 0x8ad0: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8ad5:
	/* 0x8ad5: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_8adc:
	/* 0x8adc: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8ae1:
	/* 0x8ae1: mov    eax,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 50ULL);
x86_l_8ae6:
	/* 0x8ae6: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_8aec:
	/* 0x8aec: mov    rcx,QWORD PTR [r14+0xf10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_8af3:
	/* 0x8af3: mov    esi,0x32 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 50ULL);
x86_l_8af8:
	/* 0x8af8: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_8afb:
	/* 0x8afb: mov    r8d,r12d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R12, X86_WIDTH_32);
x86_l_8afe:
	/* 0x8afe: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8b00:
	/* 0x8b00: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8b03:
	/* 0x8b03: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_8b0a:
	/* 0x8b0a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8b0d:
	/* 0x8b0d: je     8659 <perf_unwind_dotnet+0x8659> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8b0d, 0x8659, x86_l_8659);
x86_l_8b13:
	/* 0x8b13: movabs rax,0xa786c6c252073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2947156833280115ULL);
x86_l_8b1d:
	/* 0x8b1d: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_8b22:
	/* 0x8b22: movabs rax,0x7369207465736666 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8316213871206688358ULL);
x86_l_8b2c:
	/* 0x8b2c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8b31:
	/* 0x8b31: movabs rax,0x6f20646e61202c78 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8007510562703420536ULL);
x86_l_8b3b:
	/* 0x8b3b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8b40:
	/* 0x8b40: movabs rax,0x6c6c252073692073 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7812660274886418547ULL);
x86_l_8b4a:
	/* 0x8b4a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8b4f:
	/* 0x8b4f: movabs rax,0x616962206e6f6974 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7019249385664899444ULL);
x86_l_8b59:
	/* 0x8b59: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8b5e:
	/* 0x8b5e: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8b63:
	/* 0x8b63: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8b68:
	/* 0x8b68: mov    eax,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 47ULL);
x86_l_8b6d:
	/* 0x8b6d: mov    r8d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 6ULL);
x86_l_8b73:
	/* 0x8b73: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_8b7a:
	/* 0x8b7a: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_8b81:
	/* 0x8b81: mov    esi,0x2f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 47ULL);
x86_l_8b86:
	/* 0x8b86: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8b88:
	/* 0x8b88: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8b8b:
	/* 0x8b8b: jmp    8659 <perf_unwind_dotnet+0x8659> */
	X86_SIM_X86_JMP(0x8b8b, 0x8659, x86_l_8659);
x86_l_8b90:
	/* 0x8b90: movabs rax,0xa642520686374 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860387386228ULL);
x86_l_8b9a:
	/* 0x8b9a: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_8b9f:
	/* 0x8b9f: movabs rax,0x6374616d20737465 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7166460028377068645ULL);
x86_l_8ba9:
	/* 0x8ba9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8bae:
	/* 0x8bae: movabs rax,0x7366666f5f726574 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8315446390514935156ULL);
x86_l_8bb8:
	/* 0x8bb8: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8bbd:
	/* 0x8bbd: movabs rax,0x6572707265746e69 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310028781806448233ULL);
x86_l_8bc7:
	/* 0x8bc7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8bcc:
	/* 0x8bcc: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8bd1:
	/* 0x8bd1: mov    eax,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_8bd6:
	/* 0x8bd6: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8bdb:
	/* 0x8bdb: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_8be0:
	/* 0x8be0: mov    esi,0x1e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 30ULL);
x86_l_8be5:
	/* 0x8be5: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8be7:
	/* 0x8be7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8be9:
	/* 0x8be9: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_8bf0:
	/* 0x8bf0: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8bf4:
	/* 0x8bf4: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_8bf7:
	/* 0x8bf7: jb     86de <perf_unwind_dotnet+0x86de> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8bf7, 0x86de, x86_l_86de);
x86_l_8bfd:
	/* 0x8bfd: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_8c05:
	/* 0x8c05: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)&metrics));
x86_l_8c0c:
	/* 0x8c0c: lea    rsi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8c11:
	/* 0x8c11: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_8c16:
	/* 0x8c16: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8c18:
	/* 0x8c18: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_8c1b:
	/* 0x8c1b: je     8c25 <perf_unwind_dotnet+0x8c25> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c1b, 0x8c25, x86_l_8c25);
x86_l_8c1d:
	/* 0x8c1d: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_8c20:
	/* 0x8c20: jmp    8ca7 <perf_unwind_dotnet+0x8ca7> */
	X86_SIM_X86_JMP(0x8c20, 0x8ca7, x86_l_8ca7);
x86_l_8c25:
	/* 0x8c25: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, 0, ((__u64)(long)&with_debug_output));
x86_l_8c2c:
	/* 0x8c2c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8c2f:
	/* 0x8c2f: je     8ca7 <perf_unwind_dotnet+0x8ca7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c2f, 0x8ca7, x86_l_8ca7);
x86_l_8c31:
	/* 0x8c31: movabs rax,0xa642520444963 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 2924860385020259ULL);
x86_l_8c3b:
	/* 0x8c3b: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_8c40:
	/* 0x8c40: movabs rax,0x4963697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 5288186327763086624ULL);
x86_l_8c4a:
	/* 0x8c4a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8c4f:
	/* 0x8c4f: movabs rax,0x726f662070616d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8245921732249087264ULL);
x86_l_8c59:
	/* 0x8c59: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8c5e:
	/* 0x8c5e: movabs rax,0x7363697274656d20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8314605277356059936ULL);
x86_l_8c68:
	/* 0x8c68: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8c6d:
	/* 0x8c6d: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8103501230877974639ULL);
x86_l_8c77:
	/* 0x8c77: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8c7c:
	/* 0x8c7c: movabs rax,0x742064656c696146 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 8367798494427701574ULL);
x86_l_8c86:
	/* 0x8c86: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8c8b:
	/* 0x8c8b: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8c90:
	/* 0x8c90: mov    eax,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 46ULL);
x86_l_8c95:
	/* 0x8c95: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_8c9a:
	/* 0x8c9a: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8c9e:
	/* 0x8c9e: mov    esi,0x2e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 46ULL);
x86_l_8ca3:
	/* 0x8ca3: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8ca5:
	/* 0x8ca5: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x6ULL: X86_SIM_BPF_CALL_bpf_trace_printk(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8ca7:
	/* 0x8ca7: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_8cac:
	/* 0x8cac: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8cb1:
	/* 0x8cb1: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)&with_debug_output));
x86_l_8cb8:
	/* 0x8cb8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8cba:
	/* 0x8cba: jmp    7715 <perf_unwind_dotnet+0x7715> */
	X86_SIM_X86_JMP(0x8cba, 0x7715, x86_l_7715);
x86_l_8cbf:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}


