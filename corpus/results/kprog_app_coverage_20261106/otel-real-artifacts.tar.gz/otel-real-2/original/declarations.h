#include <linux/bpf.h>
#include <bpf_helpers.h>
typedef unsigned int u32;

typedef unsigned long long u64;

struct custom_context_map_t {
	int (*type)[6];
	u32 *key;
	u64 *value;
	int (*max_entries)[1];
};

extern struct custom_context_map_t custom_context_map;
typedef int pid_t;

struct DotnetProcInfo;

typedef struct DotnetProcInfo DotnetProcInfo;

struct dotnet_procs_t {
	int (*type)[1];
	pid_t *key;
	DotnetProcInfo *value;
	int (*max_entries)[1024];
};

extern struct dotnet_procs_t dotnet_procs;
struct HotspotProcInfo;

typedef struct HotspotProcInfo HotspotProcInfo;

struct hotspot_procs_t {
	int (*type)[1];
	pid_t *key;
	HotspotProcInfo *value;
	int (*max_entries)[256];
};

extern struct hotspot_procs_t hotspot_procs;
struct trace_events_t {
	int (*type)[4];
	int *key;
	u32 *value;
	int (*max_entries)[0];
};

extern struct trace_events_t trace_events;
struct ApmIntProcInfo;

typedef struct ApmIntProcInfo ApmIntProcInfo;

struct apm_int_procs_t {
	int (*type)[1];
	pid_t *key;
	ApmIntProcInfo *value;
	int (*max_entries)[128];
};

extern struct apm_int_procs_t apm_int_procs;
struct GoLabelsOffsets;

typedef struct GoLabelsOffsets GoLabelsOffsets;

struct go_labels_procs_t {
	int (*type)[1];
	pid_t *key;
	GoLabelsOffsets *value;
	int (*max_entries)[128];
};

extern struct go_labels_procs_t go_labels_procs;
struct inner_map_8;

struct exe_id_to_8_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_8 *values[0];
};

extern struct exe_id_to_8_stack_deltas_t exe_id_to_8_stack_deltas;
struct inner_map_9;

struct exe_id_to_9_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_9 *values[0];
};

extern struct exe_id_to_9_stack_deltas_t exe_id_to_9_stack_deltas;
struct inner_map_10;

struct exe_id_to_10_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_10 *values[0];
};

extern struct exe_id_to_10_stack_deltas_t exe_id_to_10_stack_deltas;
struct inner_map_11;

struct exe_id_to_11_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_11 *values[0];
};

extern struct exe_id_to_11_stack_deltas_t exe_id_to_11_stack_deltas;
struct inner_map_12;

struct exe_id_to_12_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_12 *values[0];
};

extern struct exe_id_to_12_stack_deltas_t exe_id_to_12_stack_deltas;
struct inner_map_13;

struct exe_id_to_13_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_13 *values[0];
};

extern struct exe_id_to_13_stack_deltas_t exe_id_to_13_stack_deltas;
struct inner_map_14;

struct exe_id_to_14_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_14 *values[0];
};

extern struct exe_id_to_14_stack_deltas_t exe_id_to_14_stack_deltas;
struct inner_map_15;

struct exe_id_to_15_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_15 *values[0];
};

extern struct exe_id_to_15_stack_deltas_t exe_id_to_15_stack_deltas;
struct inner_map_16;

struct exe_id_to_16_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_16 *values[0];
};

extern struct exe_id_to_16_stack_deltas_t exe_id_to_16_stack_deltas;
struct inner_map_17;

struct exe_id_to_17_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_17 *values[0];
};

extern struct exe_id_to_17_stack_deltas_t exe_id_to_17_stack_deltas;
struct inner_map_18;

struct exe_id_to_18_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_18 *values[0];
};

extern struct exe_id_to_18_stack_deltas_t exe_id_to_18_stack_deltas;
struct inner_map_19;

struct exe_id_to_19_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_19 *values[0];
};

extern struct exe_id_to_19_stack_deltas_t exe_id_to_19_stack_deltas;
struct inner_map_20;

struct exe_id_to_20_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_20 *values[0];
};

extern struct exe_id_to_20_stack_deltas_t exe_id_to_20_stack_deltas;
struct inner_map_21;

struct exe_id_to_21_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_21 *values[0];
};

extern struct exe_id_to_21_stack_deltas_t exe_id_to_21_stack_deltas;
struct inner_map_22;

struct exe_id_to_22_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_22 *values[0];
};

extern struct exe_id_to_22_stack_deltas_t exe_id_to_22_stack_deltas;
struct inner_map_23;

struct exe_id_to_23_stack_deltas_t {
	int (*type)[13];
	u64 *key;
	u32 *value;
	int (*max_entries)[4096];
	struct inner_map_23 *values[0];
};

extern struct exe_id_to_23_stack_deltas_t exe_id_to_23_stack_deltas;
struct UnwindInfo;

typedef struct UnwindInfo UnwindInfo;

struct unwind_info_array_t {
	int (*type)[2];
	u32 *key;
	UnwindInfo *value;
	int (*max_entries)[16384];
};

extern struct unwind_info_array_t unwind_info_array;
struct StackDeltaPageKey;

typedef struct StackDeltaPageKey StackDeltaPageKey;

struct StackDeltaPageInfo;

typedef struct StackDeltaPageInfo StackDeltaPageInfo;

struct stack_delta_page_to_info_t {
	int (*type)[1];
	StackDeltaPageKey *key;
	StackDeltaPageInfo *value;
	int (*max_entries)[40000];
};

extern struct stack_delta_page_to_info_t stack_delta_page_to_info;
struct sched_times_t {
	int (*type)[10];
	u64 *key;
	u64 *value;
	int (*max_entries)[256];
};

extern struct sched_times_t sched_times;
struct kprobe_progs_t {
	int (*type)[3];
	u32 *key;
	u32 *value;
	int (*max_entries)[10];
};

extern struct kprobe_progs_t kprobe_progs;
struct PerlProcInfo;

typedef struct PerlProcInfo PerlProcInfo;

struct perl_procs_t {
	int (*type)[1];
	pid_t *key;
	PerlProcInfo *value;
	int (*max_entries)[1024];
};

extern struct perl_procs_t perl_procs;
struct PHPProcInfo;

typedef struct PHPProcInfo PHPProcInfo;

struct php_procs_t {
	int (*type)[1];
	pid_t *key;
	PHPProcInfo *value;
	int (*max_entries)[1024];
};

extern struct php_procs_t php_procs;
struct PyProcInfo;

typedef struct PyProcInfo PyProcInfo;

struct py_procs_t {
	int (*type)[1];
	pid_t *key;
	PyProcInfo *value;
	int (*max_entries)[1024];
};

extern struct py_procs_t py_procs;
struct RubyProcInfo;

typedef struct RubyProcInfo RubyProcInfo;

struct ruby_procs_t {
	int (*type)[1];
	pid_t *key;
	RubyProcInfo *value;
	int (*max_entries)[1024];
};

extern struct ruby_procs_t ruby_procs;
struct SystemAnalysis;

struct system_analysis_t {
	int (*type)[2];
	u32 *key;
	struct SystemAnalysis *value;
	int (*max_entries)[1];
};

extern struct system_analysis_t system_analysis;
struct kernel_stackmap_t {
	int (*type)[7];
	u32 *key;
	u64 (*value)[127];
	int (*max_entries)[16384];
};

extern struct kernel_stackmap_t kernel_stackmap;
typedef _Bool bool;

struct pid_events_t {
	int (*type)[1];
	u64 *key;
	bool *value;
	int (*max_entries)[65536];
};

extern struct pid_events_t pid_events;
struct reported_pids_t {
	int (*type)[9];
	u32 *key;
	u64 *value;
	int (*max_entries)[65536];
};

extern struct reported_pids_t reported_pids;
struct inhibit_events_t {
	int (*type)[1];
	u32 *key;
	bool *value;
	int (*max_entries)[2];
};

extern struct inhibit_events_t inhibit_events;
struct report_events_t {
	int (*type)[4];
	int *key;
	u32 *value;
	int (*max_entries)[0];
};

extern struct report_events_t report_events;
struct V8ProcInfo;

typedef struct V8ProcInfo V8ProcInfo;

struct v8_procs_t {
	int (*type)[1];
	pid_t *key;
	V8ProcInfo *value;
	int (*max_entries)[1024];
};

extern struct v8_procs_t v8_procs;
struct PerCPURecord;

typedef struct PerCPURecord PerCPURecord;

struct per_cpu_records_t {
	int (*type)[6];
	int *key;
	PerCPURecord *value;
	int (*max_entries)[1];
};

extern struct per_cpu_records_t per_cpu_records;
struct metrics_t {
	int (*type)[6];
	u32 *key;
	u64 *value;
	int (*max_entries)[99];
};

extern struct metrics_t metrics;
struct PIDPage;

typedef struct PIDPage PIDPage;

struct PIDPageMappingInfo;

typedef struct PIDPageMappingInfo PIDPageMappingInfo;

struct pid_page_to_mapping_info_t {
	int (*type)[11];
	PIDPage *key;
	PIDPageMappingInfo *value;
	int (*max_entries)[524288];
	int (*map_flags)[1];
};

extern struct pid_page_to_mapping_info_t pid_page_to_mapping_info;
struct OffsetRange;

typedef struct OffsetRange OffsetRange;

struct interpreter_offsets_t {
	int (*type)[1];
	u64 *key;
	OffsetRange *value;
	int (*max_entries)[32];
};

extern struct interpreter_offsets_t interpreter_offsets;
struct perf_progs_t {
	int (*type)[3];
	u32 *key;
	u32 *value;
	int (*max_entries)[10];
};

extern struct perf_progs_t perf_progs;
extern bool filter_error_frames;
extern u32 _version;
extern bool filter_idle_frames;
extern u64 inverse_pac_mask;
extern u32 off_cpu_threshold;
extern u64 tpbase_offset;
extern u32 task_stack_offset;
extern u32 stack_ptregs_offset;
extern u32 with_debug_output;
