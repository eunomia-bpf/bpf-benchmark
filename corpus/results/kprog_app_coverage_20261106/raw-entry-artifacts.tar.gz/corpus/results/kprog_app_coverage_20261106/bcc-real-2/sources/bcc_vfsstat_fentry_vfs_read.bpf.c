#define LICENSE __x86_original_license
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/bcc-real-2/upstream/vfsstat.bpf.c"
#undef LICENSE
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/bcc-real-2/simulator/kprog/x86/x86_sim_local_bpf.h"

SEC("fentry/vfs_read")
int bcc_vfsstat_fentry_vfs_read_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&stats));
x86_l_7:
	/* 0x7: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_b:
	/* 0xb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d:
	/* 0xd: jmp    12 <fentry_vfs_read+0x12> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_12:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
