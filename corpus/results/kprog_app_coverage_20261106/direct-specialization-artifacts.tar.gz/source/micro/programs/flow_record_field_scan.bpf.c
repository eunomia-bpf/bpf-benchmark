#include "common.h"

#define STRUCT_FIELD_CLUSTER_RECORDS 32U

struct flow_record_field_scan_record {
    __u32 tag;
    __u16 flags;
    __u16 length;
    __u64 src;
    __u64 dst;
    __u32 sport;
    __u32 dport;
};

struct flow_record_field_scan_layout {
    __u32 record_count;
    __u32 record_size;
    struct flow_record_field_scan_record records[STRUCT_FIELD_CLUSTER_RECORDS];
};

#define STRUCT_FIELD_CLUSTER_INPUT_SIZE sizeof(struct flow_record_field_scan_layout)

static __always_inline int
bench_flow_record_field_scan(const u8 *data, u32 len, u64 *out)
{
    (void)len;

    const struct flow_record_field_scan_layout *layout =
        (const struct flow_record_field_scan_layout *)(const void *)data;
    if (layout->record_count != STRUCT_FIELD_CLUSTER_RECORDS ||
        layout->record_size != sizeof(struct flow_record_field_scan_record)) {
        return -1;
    }

    u64 acc = 0x9E3779B97F4A7C15ULL;
    for (u32 index = 0; index < STRUCT_FIELD_CLUSTER_RECORDS; index++) {
        const struct flow_record_field_scan_record *record = &layout->records[index];
        u64 tuple = record->src + record->dst;
        u64 ports = ((u64)record->sport << 32U) | record->dport;

        acc += tuple ^ (((u64)record->tag << 16U) | record->flags);
        if ((record->flags & 1U) != 0U) {
            acc ^= ports + record->length;
        } else {
            acc += (record->dst >> (index & 7U)) ^ ports;
        }
        acc ^= (u64)record->tag << ((index & 3U) * 8U);
        acc = micro_rotl64(acc, (record->tag & 7U) + 1U);
    }

    *out = acc;
    return 0;
}

DEFINE_STAGED_INPUT_XDP_BENCH(
    flow_record_field_scan_xdp,
    bench_flow_record_field_scan,
    flow_record_field_scan_input_value,
    STRUCT_FIELD_CLUSTER_INPUT_SIZE)
