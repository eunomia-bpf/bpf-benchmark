#!/usr/bin/env python3
"""Translate x86 native asm text into a handcraft.c candidate.

This experimental variant keeps branch/call/exit as ordinary BPF control-flow
instructions instead of emitting branch kinsn.  It is intentionally separate
from native_asm_to_handcraft.py so the strict machine-kinsn path remains visible.
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass, replace
from pathlib import Path


BPF_REG_BY_X86 = {name.lower(): f"HC_X86_{name}" for name in (
    "RAX", "RDI", "RSI", "RDX", "RCX", "R8", "R9", "R10",
    "R11", "R12", "RSP", "RBP", "RBX", "R13", "R14", "R15",
)}

HIGH_BYTE_X86_REGS = {"ah", "bh", "ch", "dh"}
X86_REG_NAMES: dict[str, tuple[str, int]] = {}
for base, names in {
    "rax": ("rax", "eax", "ax", "al", "ah"),
    "rbx": ("rbx", "ebx", "bx", "bl", "bh"),
    "rcx": ("rcx", "ecx", "cx", "cl", "ch"),
    "rdx": ("rdx", "edx", "dx", "dl", "dh"),
    "rdi": ("rdi", "edi", "di", "dil"),
    "rsi": ("rsi", "esi", "si", "sil"),
    "r8": ("r8", "r8d", "r8w", "r8b"),
    "r9": ("r9", "r9d", "r9w", "r9b"),
    "r10": ("r10", "r10d", "r10w", "r10b"),
    "r11": ("r11", "r11d", "r11w", "r11b"),
    "r12": ("r12", "r12d", "r12w", "r12b"),
    "r13": ("r13", "r13d", "r13w", "r13b"),
    "r14": ("r14", "r14d", "r14w", "r14b"),
    "r15": ("r15", "r15d", "r15w", "r15b"),
    "rbp": ("rbp", "ebp", "bp", "bpl"),
    "rsp": ("rsp", "esp", "sp", "spl"),
}.items():
    for name in names:
        width = 64 if name.startswith("r") and not name.endswith(("d", "w", "b")) else 32
        if name.endswith("w") or name in {"ax", "bx", "cx", "dx", "di", "si", "bp", "sp"}:
            width = 16
        if name.endswith("b") or name in HIGH_BYTE_X86_REGS | {"al", "bl", "cl", "dl", "dil", "sil", "bpl", "spl"}:
            width = 8
        X86_REG_NAMES[name] = (base, width)

OBJ_LINE_RE = re.compile(r"^\s*(?P<addr>[0-9a-f]+):\s+(?P<bytes>(?:[0-9a-f]{2}\s+)+)\s*(?P<asm>.*)$")
ASM_LINE_RE = re.compile(r"^\s*(?P<mnemonic>[a-z][a-z0-9]*)\s*(?P<operands>.*)$")
FUNC_LABEL_RE = re.compile(r"^\s*(?P<addr>[0-9a-f]+)\s+<(?P<name>[^>]+)>:$")
BRANCH_DELTA = "__BRANCH_DELTA__"
BRANCH_OFF = f"({BRANCH_DELTA}) - 1"
RETURN_CODE = (
    "HC_EXIT()",
)
SIZE_BY_PTR = {"BYTE": "BPF_B", "WORD": "BPF_H", "DWORD": "BPF_W", "QWORD": "BPF_DW"}
DIRECT_LOAD_SELECTOR = {"BPF_B": "MICRO_HANDCRAFT_BPF_X86_MOVZBL", "BPF_H": "MICRO_HANDCRAFT_BPF_X86_MOVZWL", "BPF_W": "MICRO_HANDCRAFT_BPF_X86_MOVL", "BPF_DW": "MICRO_HANDCRAFT_BPF_X86_MOVQ"}
DIRECT_STORE_SELECTOR = {"BPF_B": "MICRO_HANDCRAFT_BPF_X86_MOVB", "BPF_H": "MICRO_HANDCRAFT_BPF_X86_MOVW", "BPF_W": "MICRO_HANDCRAFT_BPF_X86_MOVL", "BPF_DW": "MICRO_HANDCRAFT_BPF_X86_MOVQ"}
WIDTH_SELECTOR = {
    "cmp": {8: "MICRO_HANDCRAFT_BPF_X86_CMPB", 16: "MICRO_HANDCRAFT_BPF_X86_CMPW", 32: "MICRO_HANDCRAFT_BPF_X86_CMPL", 64: "MICRO_HANDCRAFT_BPF_X86_CMPQ"},
    "mov": {8: "MICRO_HANDCRAFT_BPF_X86_MOVB", 32: "MICRO_HANDCRAFT_BPF_X86_MOVL", 64: "MICRO_HANDCRAFT_BPF_X86_MOVQ"},
    "test": {8: "MICRO_HANDCRAFT_BPF_X86_TESTB", 16: "MICRO_HANDCRAFT_BPF_X86_TESTW", 32: "MICRO_HANDCRAFT_BPF_X86_TESTL", 64: "MICRO_HANDCRAFT_BPF_X86_TESTQ"},
}
SIZE_CMP_SELECTOR = {"BPF_B": WIDTH_SELECTOR["cmp"][8], "BPF_H": WIDTH_SELECTOR["cmp"][16], "BPF_W": WIDTH_SELECTOR["cmp"][32], "BPF_DW": WIDTH_SELECTOR["cmp"][64]}
CMOV_PREFIX = {"cmovne": "CMOVNE", "cmove": "CMOVE", "cmovb": "CMOVB"}
CMOV_CMP_OP = {"cmovne": "BPF_JNE", "cmove": "BPF_JEQ", "cmovb": "BPF_JLT"}
INVERSE_JMP_OP = {
    "BPF_JEQ": "BPF_JNE",
    "BPF_JNE": "BPF_JEQ",
    "BPF_JLT": "BPF_JGE",
    "BPF_JGE": "BPF_JLT",
    "BPF_JSLT": "BPF_JSGE",
    "BPF_JSGE": "BPF_JSLT",
}
SETCC_SELECTOR = {"sete": "MICRO_HANDCRAFT_BPF_X86_SETE", "setne": "MICRO_HANDCRAFT_BPF_X86_SETNE", "setge": "MICRO_HANDCRAFT_BPF_X86_SETGE"}
ALU_OP = {"add", "sub", "xor", "or", "and", "shl", "shr"}
ALU_WIDTHS = {
    "add": {8, 32, 64}, "sub": {8, 32, 64}, "and": {32, 64},
    "shr": {8, 32, 64}, "xor": {32, 64}, "or": {16, 32, 64},
    "shl": {8, 32, 64}, "sar": {32, 64},
}
WIDTH_SUFFIX = {8: "B", 16: "W", 32: "L", 64: "Q"}
CMP_JCC_OP = {
    "ja": "BPF_JGT", "jae": "BPF_JGE", "jb": "BPF_JLT", "jbe": "BPF_JLE",
    "je": "BPF_JEQ", "jne": "BPF_JNE", "jg": "BPF_JSGT", "jge": "BPF_JSGE",
    "jl": "BPF_JSLT", "jle": "BPF_JSLE",
}
JCC_OP = set(CMP_JCC_OP) | {"js", "jns"}
FLAG_TRANSPARENT_OPS = {
    "mov", "movabs", "lea", "nop", "data16", "endbr64", "cs", "xchg",
    "push", "pop",
}
CONTEXT_KIND = "xdp"
SKB_DATA_OFF = 76
SKB_DATA_END_OFF = 80
SKB_CB0_OFF = 48
SKB_CB1_OFF = 52
SHADOW_OFF_BY_X86 = {
    "rax": "HC_X86_SHADOW_RAX_OFF",
    "rcx": "HC_X86_SHADOW_RCX_OFF",
    "rdx": "HC_X86_SHADOW_RDX_OFF",
    "rbx": "HC_X86_SHADOW_RBX_OFF",
    "rsp": "HC_X86_SHADOW_RSP_OFF",
    "rbp": "HC_X86_SHADOW_RBP_OFF",
    "rsi": "HC_X86_SHADOW_RSI_OFF",
    "rdi": "HC_X86_SHADOW_RDI_OFF",
    "r8": "HC_X86_SHADOW_R8_OFF",
    "r9": "HC_X86_SHADOW_R9_OFF",
    "r10": "HC_X86_SHADOW_R10_OFF",
    "r11": "HC_X86_SHADOW_R11_OFF",
    "r12": "HC_X86_SHADOW_R12_OFF",
    "r13": "HC_X86_SHADOW_R13_OFF",
    "r14": "HC_X86_SHADOW_R14_OFF",
    "r15": "HC_X86_SHADOW_R15_OFF",
}
RAW_BPF_WRITABLE_X86 = {
    "rax", "rdi", "rsi", "rdx", "rcx", "r8", "r15",
}
X86_BY_BPF_SCRATCH = {
    "BPF_REG_6": "HC_X86_RBX",
    "BPF_REG_7": "HC_X86_R13",
    "BPF_REG_8": "HC_X86_R14",
    "BPF_REG_9": "HC_X86_R15",
}
@dataclass(frozen=True)
class NativeInsn:
    addr: int
    size: int
    raw: str
    mnemonic: str
    operands: tuple[str, ...]


@dataclass(frozen=True)
class Translation:
    status: str
    code: tuple[str, ...]
    note: str
    target_addr: int | None = None


def parse_int(text: str) -> int:
    text = text.strip()
    if text.startswith("-"):
        return -parse_int(text[1:])
    return int(text, 16) if text.lower().startswith("0x") else int(text, 10)


def is_int(text: str) -> bool:
    return re.match(r"^-?(0x[0-9a-fA-F]+|\d+)$", text.strip()) is not None


def parse_branch_target(text: str) -> int | None:
    match = re.match(r"\s*(0x[0-9a-fA-F]+|[0-9a-fA-F]+)", text)
    return int(match.group(1), 16) if match else None


def split_operands(text: str) -> tuple[str, ...]:
    parts: list[str] = []
    start = 0
    depth = 0
    for index, char in enumerate(text):
        if char == "[":
            depth += 1
        elif char == "]":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append(text[start:index].strip())
            start = index + 1
    tail = text[start:].strip()
    if tail:
        parts.append(tail)
    return tuple(parts)


def extract_asm_text(text: str) -> str:
    match = re.search(r"^## Native ASM\n```asm\n(.*?)\n```", text, re.S | re.M)
    return match.group(1) if match else text


def selected_asm_text(text: str, entry_symbol: str | None) -> str:
    asm = extract_asm_text(text)
    title = re.search(r"^#\s+([A-Za-z0-9_]+)\s*$", text, re.M)
    root = entry_symbol or (title.group(1) if title else None)
    blocks: list[tuple[int, str, list[str]]] = []
    current: tuple[int, str, list[str]] | None = None
    for line in asm.splitlines():
        label = FUNC_LABEL_RE.match(line)
        if label:
            if current:
                blocks.append(current)
            current = (int(label.group("addr"), 16), label.group("name"), [line])
        elif current:
            current[2].append(line)
    if current:
        blocks.append(current)
    if not root or not blocks:
        return asm
    by_addr = {addr: (name, lines) for addr, name, lines in blocks}
    work = [addr for addr, name, _ in blocks if name == root or name.startswith(f"{root}_") or name.startswith(root)]
    seen: set[int] = set()
    while work:
        addr = work.pop()
        if addr in seen or addr not in by_addr:
            continue
        seen.add(addr)
        for line in by_addr[addr][1]:
            obj = OBJ_LINE_RE.match(line)
            parsed = ASM_LINE_RE.match(obj.group("asm").split("#", 1)[0].strip()) if obj else None
            if parsed and parsed.group("mnemonic") == "call":
                target = parse_branch_target(parsed.group("operands"))
                if target in by_addr:
                    work.append(target)
    return "\n".join(line for addr, _name, lines in blocks if addr in seen for line in lines) if seen else asm


def parse_native_asm(text: str, entry_symbol: str | None = None) -> list[NativeInsn]:
    insns: list[NativeInsn] = []
    for line in selected_asm_text(text, entry_symbol).splitlines():
        obj = OBJ_LINE_RE.match(line)
        if obj:
            asm = obj.group("asm").split("#", 1)[0].strip()
            size = len(obj.group("bytes").split())
            if not asm:
                if insns:
                    insns[-1] = replace(insns[-1], size=insns[-1].size + size)
                continue
            if not asm or asm.startswith("<"):
                continue
            parsed = ASM_LINE_RE.match(asm)
            if not parsed:
                continue
            insns.append(NativeInsn(int(obj.group("addr"), 16), size, asm,
                                    parsed.group("mnemonic"), split_operands(parsed.group("operands"))))
            continue
        if line.startswith("\t") or line.startswith(" "):
            asm = line.split("#", 1)[0].strip()
            parsed = ASM_LINE_RE.match(asm)
            if parsed and not asm.startswith((".", "#")):
                insns.append(NativeInsn(0, 0, asm, parsed.group("mnemonic"), split_operands(parsed.group("operands"))))
    return insns


def reg(operand: str) -> tuple[str, int] | None:
    return X86_REG_NAMES.get(operand.strip().lower().lstrip("%"))


def unsupported_reg_note(role: str, operand: str) -> str:
    return f"{role} {operand} is not in the BPF JIT register file"


def bpf_reg(operand: str) -> tuple[str, int, str] | None:
    parsed = reg(operand)
    if parsed is None:
        return None
    base, width = parsed
    mapped = BPF_REG_BY_X86.get(base)
    if mapped is None:
        return None
    return mapped, width, base


def bpf_mem_base(operand: str | None) -> tuple[str, int, str] | None:
    return bpf_reg(operand) if operand is not None else None


def byte_lane(operand: str) -> int:
    return 1 if operand.strip().lower() in HIGH_BYTE_X86_REGS else 0


def reg_reg_payload(dst: tuple[str, int, str], src: tuple[str, int, str]) -> str:
    return f"HC_X86_ARCH_RR_PAYLOAD({dst[0]}, {src[0]})"


def byte_reg_reg_payload(dst: str, src: str) -> str:
    return f"HC_X86_ARCH_RR_PAYLOAD({dst}, {src})"


def c_s32(value: int) -> str:
    value &= 0xffffffff
    if value >= 0x80000000:
        value -= 0x100000000
    return str(value)


def c_u64(value: int) -> str:
    return f"0x{value & 0xffffffffffffffff:x}ULL"


def movabs_bpf(dst: tuple[str, int, str], imm: int) -> tuple[str, ...] | None:
    return (
        f"HC_LD_IMM64_RAW(BPF_REG_6, 0, {c_u64(imm)})",
        f"HC_STX(BPF_DW, BPF_REG_10, BPF_REG_6, {SHADOW_OFF_BY_X86[dst[2]]})",
    )


def context_load(dst: tuple[str, int, str], bpf_off: int) -> tuple[str, ...] | None:
    if dst[2] in RAW_BPF_WRITABLE_X86:
        return (
            f"HC_LDX(BPF_W, {dst[0]}, BPF_REG_1, {bpf_off})",
            f"HC_STX(BPF_DW, BPF_REG_10, {dst[0]}, {SHADOW_OFF_BY_X86[dst[2]]})",
        )
    return (
        f"HC_LDX(BPF_W, BPF_REG_6, BPF_REG_1, {bpf_off})",
        f"HC_STX(BPF_DW, BPF_REG_10, BPF_REG_6, {SHADOW_OFF_BY_X86['rbx']})",
        f"HC_KINSN(HC_X86_ARCH_RR_PAYLOAD({dst[0]}, HC_X86_RBX), MICRO_HANDCRAFT_BPF_X86_MOVQ)",
        f"HC_STX(BPF_DW, BPF_REG_10, BPF_REG_6, {SHADOW_OFF_BY_X86[dst[2]]})",
    )


def machine_alu_rr_payload(dst: tuple[str, int, str], src: tuple[str, int, str]) -> str:
    return f"HC_X86_ARCH_RR_PAYLOAD({dst[0]}, {src[0]})"


def machine_alu_imm_payload(dst: tuple[str, int, str], imm: int) -> str:
    return f"HC_X86_ARCH_IMM_PAYLOAD({dst[0]}, {c_s32(imm)})"


def machine_alu_selector(op: str, width: int) -> str | None:
    if width not in ALU_WIDTHS.get(op, set()):
        return None
    return f"MICRO_HANDCRAFT_BPF_X86_{op.upper()}{WIDTH_SUFFIX[width]}"


def x86_imm_payload(dst: tuple[str, int, str], imm: int) -> str:
    return f"HC_X86_ARCH_IMM_PAYLOAD({dst[0]}, {imm})"


def bpf_ja() -> str:
    return f"HC_RAW(BPF_JMP | BPF_JA, 0, 0, {BRANCH_OFF}, 0)"


def width_of_size(size: str | None) -> int | None:
    return {"BPF_B": 8, "BPF_H": 16, "BPF_W": 32, "BPF_DW": 64}.get(size or "")


def signed_jmp(op: str) -> bool:
    return op in {"BPF_JSGT", "BPF_JSGE", "BPF_JSLT", "BPF_JSLE"}


def signed_width_value(value: int, width: int) -> int:
    value &= (1 << width) - 1
    sign = 1 << (width - 1)
    return value - (1 << width) if value & sign else value


def normalize_branch_reg(reg_name: str, width: int, signed: bool) -> tuple[str, ...]:
    if signed and width in {8, 16}:
        shift = 64 - width
        return (f"HC_ALU64_IMM(BPF_LSH, {reg_name}, {shift})",
                f"HC_RAW(BPF_ALU64 | BPF_ARSH | BPF_K, {reg_name}, 0, 0, {shift})")
    if not signed and width in {8, 16}:
        return (f"HC_ALU64_IMM(BPF_AND, {reg_name}, {hex((1 << width) - 1)})",)
    return ()


def branch_cmp(op: str, width: int, src: str, imm: int | None) -> str:
    cls = "BPF_JMP32" if width == 32 else "BPF_JMP"
    mode = "BPF_X" if imm is None else "BPF_K"
    rhs = src if imm is None else "0"
    val = 0 if imm is None else c_s32(imm)
    return f"HC_RAW({cls} | {op} | {mode}, BPF_REG_6, {rhs}, {BRANCH_OFF}, {val})"


def local_branch_cmp(op: str, width: int, src: str, imm: int | None, off: int) -> str:
    cls = "BPF_JMP32" if width == 32 else "BPF_JMP"
    mode = "BPF_X" if imm is None else "BPF_K"
    rhs = src if imm is None else "0"
    val = 0 if imm is None else c_s32(imm)
    return f"HC_RAW({cls} | {op} | {mode}, BPF_REG_6, {rhs}, {off}, {val})"


def branch_cmp_from(reg_name: str, op: str, width: int, src: str, imm: int | None) -> str:
    cls = "BPF_JMP32" if width == 32 else "BPF_JMP"
    mode = "BPF_X" if imm is None else "BPF_K"
    rhs = src if imm is None else "0"
    val = 0 if imm is None else c_s32(imm)
    return f"HC_RAW({cls} | {op} | {mode}, {reg_name}, {rhs}, {BRANCH_OFF}, {val})"


def load_branch_value(operand: str, scratch: str) -> tuple[tuple[str, ...], int] | None:
    dst = bpf_reg(operand)
    if dst:
        if dst[2] in RAW_BPF_WRITABLE_X86:
            return ((f"HC_MOV64_REG({scratch}, {dst[0]})",), dst[1])
        scratch_x86 = X86_BY_BPF_SCRATCH.get(scratch)
        if scratch_x86 is None:
            return None
        selector = "MICRO_HANDCRAFT_BPF_X86_MOVL" if dst[1] == 32 else "MICRO_HANDCRAFT_BPF_X86_MOVQ"
        return ((f"HC_KINSN(HC_X86_ARCH_TO_BPF_RR_PAYLOAD({scratch}, {dst[0]}), {selector})",), dst[1])
    mem = parse_mem(operand)
    size = size_from_mem(operand)
    width = width_of_size(size)
    if mem is None or width is None:
        return None
    base, index, _scale, off = mem
    base_reg = bpf_mem_base(base)
    if base_reg is None or index is not None:
        return None
    if base_reg[2] not in RAW_BPF_WRITABLE_X86:
        scratch_x86 = X86_BY_BPF_SCRATCH.get(scratch)
        if scratch_x86 is None:
            return None
        return ((
            f"HC_KINSN(HC_X86_ARCH_TO_BPF_RR_PAYLOAD({scratch}, {base_reg[0]}), MICRO_HANDCRAFT_BPF_X86_MOVQ)",
            f"HC_LDX({size}, {scratch}, {scratch}, {off})",
        ), width)
    return ((
        f"HC_MOV64_REG({scratch}, {base_reg[0]})",
        f"HC_LDX({size}, {scratch}, {scratch}, {off})",
    ), width)


def lower_cmp_jcc(branch: NativeInsn, cmp: NativeInsn) -> tuple[str, ...] | None:
    op = CMP_JCC_OP.get(branch.mnemonic)
    if op is None or cmp.mnemonic != "cmp" or len(cmp.operands) != 2:
        return None
    lhs = load_branch_value(cmp.operands[0], "BPF_REG_6")
    if lhs is None:
        return None
    lhs_code, width = lhs
    signed = signed_jmp(op)
    lhs_norm = normalize_branch_reg("BPF_REG_6", width, signed)
    if is_int(cmp.operands[1]):
        imm = signed_width_value(parse_int(cmp.operands[1]), width) if signed else parse_int(cmp.operands[1]) & ((1 << width) - 1)
        return (*lhs_code, *lhs_norm, branch_cmp(op, width, "0", imm))
    rhs = load_branch_value(cmp.operands[1], "BPF_REG_7")
    if rhs is None or rhs[1] != width:
        return None
    return (*lhs_code, *rhs[0], *lhs_norm, *normalize_branch_reg("BPF_REG_7", width, signed),
            branch_cmp(op, width, "BPF_REG_7", None))


def snapshot_cmp(cmp: NativeInsn) -> tuple[str, ...] | None:
    if cmp.mnemonic not in {"cmp", "test"} or len(cmp.operands) != 2:
        return None
    lhs = load_branch_value(cmp.operands[0], "BPF_REG_6")
    if lhs is None:
        return None
    code = [*lhs[0], "HC_STX(BPF_DW, BPF_REG_10, BPF_REG_6, HC_X86_BRANCH_LHS_OFF)"]
    if cmp.mnemonic == "cmp" and not is_int(cmp.operands[1]):
        rhs = load_branch_value(cmp.operands[1], "BPF_REG_7")
        if rhs is None or rhs[1] != lhs[1]:
            return None
        code.extend(rhs[0])
        code.append("HC_STX(BPF_DW, BPF_REG_10, BPF_REG_7, HC_X86_BRANCH_RHS_OFF)")
    return tuple(code)


def lower_saved_cmp_jcc(branch: NativeInsn, cmp: NativeInsn) -> tuple[str, ...] | None:
    op = CMP_JCC_OP.get(branch.mnemonic)
    if op is None or cmp.mnemonic != "cmp" or len(cmp.operands) != 2:
        return None
    lhs = load_branch_value(cmp.operands[0], "BPF_REG_6")
    if lhs is None:
        return None
    width = lhs[1]
    signed = signed_jmp(op)
    code = ["HC_LDX(BPF_DW, BPF_REG_6, BPF_REG_10, HC_X86_BRANCH_LHS_OFF)"]
    code.extend(normalize_branch_reg("BPF_REG_6", width, signed))
    if is_int(cmp.operands[1]):
        imm = signed_width_value(parse_int(cmp.operands[1]), width) if signed else parse_int(cmp.operands[1]) & ((1 << width) - 1)
        code.append(branch_cmp(op, width, "0", imm))
        return tuple(code)
    rhs = load_branch_value(cmp.operands[1], "BPF_REG_7")
    if rhs is None or rhs[1] != width:
        return None
    code.append("HC_LDX(BPF_DW, BPF_REG_7, BPF_REG_10, HC_X86_BRANCH_RHS_OFF)")
    code.extend(normalize_branch_reg("BPF_REG_7", width, signed))
    code.append(branch_cmp(op, width, "BPF_REG_7", None))
    return tuple(code)


def lower_cmp_cmov(cmov: NativeInsn, cmp: NativeInsn, saved: bool) -> tuple[str, ...] | None:
    op = CMOV_CMP_OP.get(cmov.mnemonic)
    if op is None or cmp.mnemonic != "cmp" or len(cmp.operands) != 2 or len(cmov.operands) != 2:
        return None
    inverse = INVERSE_JMP_OP[op]
    dst = bpf_reg(cmov.operands[0])
    src = bpf_reg(cmov.operands[1])
    if dst is None or src is None or dst[1] != src[1] or dst[1] not in {32, 64}:
        return None
    move_selector = "MICRO_HANDCRAFT_BPF_X86_MOVL" if dst[1] == 32 else "MICRO_HANDCRAFT_BPF_X86_MOVQ"
    move = f"HC_KINSN(HC_X86_ARCH_RR_PAYLOAD({dst[0]}, {src[0]}), {move_selector})"
    move_len = bpf_insn_len(move)

    if saved:
        lhs = load_branch_value(cmp.operands[0], "BPF_REG_6")
        if lhs is None:
            return None
        width = lhs[1]
        code = ["HC_LDX(BPF_DW, BPF_REG_6, BPF_REG_10, HC_X86_BRANCH_LHS_OFF)"]
        code.extend(normalize_branch_reg("BPF_REG_6", width, signed_jmp(op)))
        if is_int(cmp.operands[1]):
            imm = signed_width_value(parse_int(cmp.operands[1]), width) if signed_jmp(op) else parse_int(cmp.operands[1]) & ((1 << width) - 1)
            code.append(local_branch_cmp(inverse, width, "0", imm, move_len))
            code.append(move)
            return tuple(code)
        rhs = load_branch_value(cmp.operands[1], "BPF_REG_7")
        if rhs is None or rhs[1] != width:
            return None
        code.append("HC_LDX(BPF_DW, BPF_REG_7, BPF_REG_10, HC_X86_BRANCH_RHS_OFF)")
        code.extend(normalize_branch_reg("BPF_REG_7", width, signed_jmp(op)))
        code.append(local_branch_cmp(inverse, width, "BPF_REG_7", None, move_len))
        code.append(move)
        return tuple(code)

    lhs = load_branch_value(cmp.operands[0], "BPF_REG_6")
    if lhs is None:
        return None
    lhs_code, width = lhs
    code = [*lhs_code]
    code.extend(normalize_branch_reg("BPF_REG_6", width, signed_jmp(op)))
    if is_int(cmp.operands[1]):
        imm = signed_width_value(parse_int(cmp.operands[1]), width) if signed_jmp(op) else parse_int(cmp.operands[1]) & ((1 << width) - 1)
        code.append(local_branch_cmp(inverse, width, "0", imm, move_len))
        code.append(move)
        return tuple(code)
    rhs = load_branch_value(cmp.operands[1], "BPF_REG_7")
    if rhs is None or rhs[1] != width:
        return None
    code.extend(rhs[0])
    code.extend(normalize_branch_reg("BPF_REG_7", width, signed_jmp(op)))
    code.append(local_branch_cmp(inverse, width, "BPF_REG_7", None, move_len))
    code.append(move)
    return tuple(code)


def lower_saved_test_jcc(branch: NativeInsn, test: NativeInsn) -> tuple[str, ...] | None:
    if test.mnemonic != "test" or len(test.operands) != 2 or branch.mnemonic not in {"je", "jne", "js", "jns"}:
        return None
    lhs = load_branch_value(test.operands[0], "BPF_REG_6")
    if lhs is None:
        return None
    width = lhs[1]
    if branch.mnemonic in {"js", "jns"}:
        mask = 1 << (width - 1)
    elif is_int(test.operands[1]):
        mask = parse_int(test.operands[1])
    elif test.operands[0] == test.operands[1]:
        mask = (1 << width) - 1
    else:
        return None
    load = "HC_LDX(BPF_DW, BPF_REG_6, BPF_REG_10, HC_X86_BRANCH_LHS_OFF)"
    jset = f"HC_RAW(BPF_JMP | BPF_JSET | BPF_K, BPF_REG_6, 0, {BRANCH_OFF}, {c_s32(mask)})"
    if branch.mnemonic in {"jne", "js"}:
        return (load, jset)
    return (load, f"HC_RAW(BPF_JMP | BPF_JSET | BPF_K, BPF_REG_6, 0, 1, {c_s32(mask)})", bpf_ja())


def lower_test_jcc(branch: NativeInsn, test: NativeInsn) -> tuple[str, ...] | None:
    if test.mnemonic != "test" or len(test.operands) != 2 or branch.mnemonic not in {"je", "jne", "js", "jns"}:
        return None
    lhs = load_branch_value(test.operands[0], "BPF_REG_6")
    if lhs is None:
        return None
    lhs_code, width = lhs
    if branch.mnemonic in {"js", "jns"}:
        mask = 1 << (width - 1)
    elif is_int(test.operands[1]):
        mask = parse_int(test.operands[1])
    elif test.operands[0] == test.operands[1]:
        mask = (1 << width) - 1
    else:
        return None
    jset = f"HC_RAW(BPF_JMP | BPF_JSET | BPF_K, BPF_REG_6, 0, {BRANCH_OFF}, {c_s32(mask)})"
    if branch.mnemonic in {"jne", "js"}:
        return (*lhs_code, jset)
    return (*lhs_code, f"HC_RAW(BPF_JMP | BPF_JSET | BPF_K, BPF_REG_6, 0, 1, {c_s32(mask)})", bpf_ja())


def lower_result_jcc(branch: NativeInsn, producer: NativeInsn) -> tuple[str, ...] | None:
    if branch.mnemonic not in {"je", "jne", "js", "jns"} or not producer.operands:
        return None
    dst = load_branch_value(producer.operands[0], "BPF_REG_6")
    if dst is None:
        return None
    code, width = dst
    if branch.mnemonic in {"js", "jns"}:
        mask = 1 << (width - 1)
        jset = f"HC_RAW(BPF_JMP | BPF_JSET | BPF_K, BPF_REG_6, 0, {BRANCH_OFF}, {c_s32(mask)})"
        return (*code, jset) if branch.mnemonic == "js" else (*code, f"HC_RAW(BPF_JMP | BPF_JSET | BPF_K, BPF_REG_6, 0, 1, {c_s32(mask)})", bpf_ja())
    op = "BPF_JEQ" if branch.mnemonic == "je" else "BPF_JNE"
    return (*code, *normalize_branch_reg("BPF_REG_6", width, False),
            branch_cmp(op, width, "0", 0))


def reg_payload(reg_name: str) -> str:
    return f"HC_X86_ARCH_IMM_PAYLOAD({reg_name}, 0)"


def setcc_payload(reg_name: str) -> str:
    return f"HC_SETCC_PAYLOAD({reg_name})"


def mem_payload_macro(base_name: str) -> str:
    return "HC_X86_ARCH_MEM_PAYLOAD"


def store_payload_macro(base_name: str, byte_lane: bool = False) -> str:
    return "HC_X86_STORE_BYTE_PAYLOAD" if byte_lane else "HC_X86_ARCH_STORE_PAYLOAD"


def store_imm_payload_macro(base_name: str) -> str:
    return "HC_X86_ARCH_STORE_IMM_PAYLOAD"


def stack_reg_payload(operand: str) -> str | None:
    parsed = reg(operand)
    if parsed is None:
        return None
    base, _width = parsed
    mapped = BPF_REG_BY_X86.get(base)
    return mapped


def size_from_mem(text: str) -> str | None:
    for key, value in SIZE_BY_PTR.items():
        if text.strip().upper().startswith(f"{key} PTR"):
            return value
    return None


def parse_mem(text: str) -> tuple[str | None, str | None, int, int] | None:
    body_match = re.search(r"\[(.*)\]", text)
    if not body_match:
        return None
    body = body_match.group(1).replace(" ", "")
    body = body.replace("-", "+-")
    base: str | None = None
    index: str | None = None
    scale = 1
    disp = 0
    for token in filter(None, body.split("+")):
        if "*" in token:
            reg_name, scale_text = token.split("*", 1)
            index = reg_name
            scale = parse_int(scale_text)
        elif token == "rip":
            base = token
        elif reg(token):
            if base is None:
                base = token
            else:
                index = token
        else:
            disp += parse_int(token)
    return base, index, scale, disp


def scale_log2(scale: int) -> int | None:
    return {1: 0, 2: 1, 4: 2, 8: 3}.get(scale)


def translate_mem_load(dst_op: str, mem_op: str, size: str) -> Translation:
    dst = bpf_reg(dst_op)
    mem = parse_mem(mem_op)
    if dst is None:
        return Translation("warning-unmapped", (), unsupported_reg_note("destination register", dst_op))
    if mem is None:
        return Translation("warning-unmapped", (), f"unsupported memory operand {mem_op}")
    base, index, scale, off = mem
    if base is None:
        return Translation("warning-unmapped", (), "RIP/absolute memory is not expressible as verifier-safe BPF memory")
    base_reg = bpf_mem_base(base)
    if base_reg is None:
        return Translation("warning-unmapped", (), unsupported_reg_note("memory base", base))
    if base_reg[2] == "rdi" and index is None and size == "BPF_DW" and off in {0, 8}:
        if CONTEXT_KIND == "skb":
            bpf_off = SKB_DATA_OFF if off == 0 else SKB_DATA_END_OFF
            note = f"native skb shim field at off {off} maps to __sk_buff u32 ctx field at off {bpf_off}"
        else:
            bpf_off = 0 if off == 0 else 4
            note = f"native xdp_md 64-bit field at off {off} maps to BPF XDP u32 ctx field at off {bpf_off}"
        code = context_load(dst, bpf_off)
        if code is None:
            return Translation("warning-unmapped", (), f"context load destination {dst_op} is not writable")
        return Translation("context-abi", code, note)
    if index is not None:
        index_reg = bpf_reg(index)
        slog2 = scale_log2(scale)
        if index_reg is None or slog2 is None:
            return Translation("warning-unmapped", (), f"SIB index {index} scale {scale} is not expressible")
        target = {"BPF_B": "MICRO_HANDCRAFT_BPF_X86_MOVZBL", "BPF_H": "MICRO_HANDCRAFT_BPF_X86_MOVZWL", "BPF_W": "MICRO_HANDCRAFT_BPF_X86_MOVL", "BPF_DW": "MICRO_HANDCRAFT_BPF_X86_MOVQ"}.get(size)
        if target is None:
            return Translation("warning-unmapped", (), f"SIB load size {size} has no current selector")
        payload = f"HC_X86_ARCH_SIB_PAYLOAD({dst[0]}, {base_reg[0]}, {index_reg[0]}, {slog2}, {off})"
        return Translation("exact-kinsn", (f"HC_KINSN({payload}, {target})",), "indexed memory load via x86 SIB kinsn")
    target = DIRECT_LOAD_SELECTOR.get(size)
    if target is None:
        return Translation("warning-unmapped", (), f"direct load size {size} needs a machine-level mov/load kinsn")
    payload = f"{mem_payload_macro(base_reg[2])}({dst[0]}, {base_reg[0]}, {off})"
    return Translation("exact-kinsn", (f"HC_KINSN({payload}, {target})",), "direct memory load via x86 kinsn selector")


def translate(insn: NativeInsn) -> Translation:
    op = insn.mnemonic
    ops = insn.operands
    if op in {"nop", "data16", "endbr64"}:
        return Translation("padding", (), "padding is not part of BPF semantics")
    if op == "cs" and ops and ops[0].startswith("nop"):
        return Translation("padding", (), "prefixed nop padding is not part of BPF semantics")
    if op == "xchg" and len(ops) == 2 and ops[0] == "ax" and ops[1] == "ax":
        return Translation("padding", (), "xchg ax,ax is nop padding")
    if op in {"push", "pop"} and len(ops) == 1:
        payload_reg = stack_reg_payload(ops[0])
        if payload_reg is None:
            return Translation("warning-unmapped", (), f"{op} operand needs x86 stack register payload support: {insn.raw}")
        selector = "MICRO_HANDCRAFT_BPF_X86_PUSHQ" if op == "push" else "MICRO_HANDCRAFT_BPF_X86_POPQ"
        return Translation("exact-kinsn", (f"HC_KINSN({payload_reg}, {selector})",), f"{op}q kinsn")
    if op == "leave":
        return Translation("warning-unmapped", (), "leave needs a machine-level x86 stack/control kinsn; cannot be ignored in strict handcraft mode")
    if op == "mov" and ops in {("rbp", "rsp"), ("rsp", "rbp")}:
        dst = "HC_X86_RBP" if ops[0] == "rbp" else "HC_X86_RSP"
        src = "HC_X86_RBP" if ops[1] == "rbp" else "HC_X86_RSP"
        return Translation("exact-kinsn", (f"HC_KINSN(HC_X86_FRAME_PAYLOAD({dst}, {src}), MICRO_HANDCRAFT_BPF_X86_MOVQ)",), "movq frame-register kinsn")
    if op == "ret":
        return Translation("abi-boundary", RETURN_CODE, "native ret materializes x86 rax to BPF r0 then exits")
    if op == "call" and len(ops) == 1:
        target_addr = parse_branch_target(ops[0])
        if target_addr is None:
            return Translation("control-flow-gap", (), f"indirect/native call has no ordinary BPF pseudo-call target: {insn.raw}")
        return Translation("abi-boundary", (f"HC_CALL({BRANCH_DELTA})",), "native direct call maps to BPF pseudo call", target_addr)
    if op in JCC_OP:
        target_addr = parse_branch_target(ops[0]) if len(ops) == 1 else None
        if target_addr is None:
            return Translation("control-flow-gap", (), f"cannot parse x86 branch target: {insn.raw}")
        return Translation("control-flow-gap", (), f"{op} needs a direct verifier-visible branch from the preceding cmp/test", target_addr)
    if op == "jmp" and len(ops) == 1:
        target_addr = parse_branch_target(ops[0])
        if target_addr is None:
            return Translation("control-flow-gap", (), f"indirect jmp target is not an ordinary BPF register: {ops[0]}")
        return Translation("exact-bpf", (bpf_ja(),), "native jmp maps to ordinary BPF JA", target_addr)
    if op == "cmp" and len(ops) == 2:
        lhs = bpf_reg(ops[0])
        rhs = bpf_reg(ops[1])
        if "[" in ops[0] and re.match(r"^-?(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            mem = parse_mem(ops[0])
            size = size_from_mem(ops[0])
            if mem is None or size not in {"BPF_B", "BPF_W", "BPF_DW"}:
                return Translation("warning-unmapped", (), f"CMP memory immediate form has unsupported size: {insn.raw}")
            base, index, scale, off = mem
            if base is None or index is not None:
                return Translation("warning-unmapped", (), f"CMP memory immediate form is not direct base+disp: {insn.raw}")
            base_reg = bpf_mem_base(base)
            if base_reg is None:
                return Translation("warning-unmapped", (), f"CMP memory base {base} is not in the BPF register file: {insn.raw}")
            payload = f"HC_X86_CMP_ARCH_MEM_IMM_PAYLOAD({base_reg[0]}, {off}, {parse_int(ops[1])})"
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {SIZE_CMP_SELECTOR[size]})",), "cmp memory,imm kinsn")
        if "[" in ops[0] and rhs and rhs[1] == 64:
            mem = parse_mem(ops[0])
            size = size_from_mem(ops[0])
            if mem is None or size != "BPF_DW":
                return Translation("warning-unmapped", (), f"CMP memory source is not a qword operand: {insn.raw}")
            base, index, scale, off = mem
            if base is None or index is None:
                return Translation("warning-unmapped", (), f"CMP memory source is not indexed SIB: {insn.raw}")
            base_reg = bpf_mem_base(base)
            index_reg = bpf_reg(index)
            slog2 = scale_log2(scale)
            if base_reg is None or index_reg is None or slog2 is None:
                return Translation("warning-unmapped", (), f"CMP SIB operand is not in the BPF register file: {insn.raw}")
            payload = f"HC_X86_CMP_SIB_RR_PAYLOAD({base_reg[0]}, {index_reg[0]}, {slog2}, {off}, {rhs[0]})"
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_CMPQ)",), "cmpq SIB memory-source kinsn")
        if lhs and rhs and lhs[1] == rhs[1] and lhs[1] in WIDTH_SELECTOR["cmp"]:
            payload = reg_reg_payload(lhs, rhs)
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {WIDTH_SELECTOR['cmp'][lhs[1]]})",), f"cmp{lhs[1]} reg,reg kinsn")
        if lhs and lhs[1] in WIDTH_SELECTOR["cmp"] and is_int(ops[1]):
            payload = x86_imm_payload(lhs, parse_int(ops[1]))
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {WIDTH_SELECTOR['cmp'][lhs[1]]})",), f"cmp{lhs[1]} reg,imm kinsn")
        return Translation("warning-unmapped", (), f"CMP operand form has no current kinsn selector: {insn.raw}")
    if len(ops) == 2 and op in {"mov", "movabs"}:
        dst, src = ops
        dst_reg = bpf_reg(dst)
        src_reg = bpf_reg(src)
        if dst_reg and src_reg:
            if dst_reg[1] == src_reg[1] and dst_reg[1] in {32, 64}:
                payload = reg_reg_payload(dst_reg, src_reg)
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, {WIDTH_SELECTOR['mov'][dst_reg[1]]})",), f"mov{dst_reg[1]} register-to-register kinsn")
            return Translation("warning-unmapped", (), f"mixed-width register move {dst}, {src}")
        if dst_reg and re.match(r"^-?(0x[0-9a-fA-F]+|\d+)$", src):
            imm = parse_int(src)
            if op == "movabs" or dst_reg[1] == 64 and abs(imm) > 0x7fffffff:
                code = movabs_bpf(dst_reg, imm)
                if code is None:
                    return Translation("warning-unmapped", (), f"movabs into {dst_reg[0]} needs a writable x86 shadow slot")
                return Translation("exact-bpf", code, "movabs via verifier-visible BPF immediate load")
            if dst_reg[1] in WIDTH_SELECTOR["mov"]:
                payload = x86_imm_payload(dst_reg, imm)
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, {WIDTH_SELECTOR['mov'][dst_reg[1]]})",), f"mov{dst_reg[1]} immediate kinsn")
            return Translation("warning-unmapped", (), f"mov immediate width {dst_reg[1]} needs a consolidated mov kinsn form")
        mem_size = size_from_mem(src) or ("BPF_DW" if dst_reg and dst_reg[1] == 64 else "BPF_W")
        if dst_reg and "[" in src:
            return translate_mem_load(dst, src, mem_size)
        if "[" in dst and src_reg:
            mem = parse_mem(dst)
            size = size_from_mem(dst) or ("BPF_DW" if src_reg[1] == 64 else "BPF_W")
            if mem is None or mem[1] is not None:
                return Translation("warning-unmapped", (), f"store operand {dst} is not a direct base+disp memory reference")
            base = bpf_mem_base(mem[0])
            if base is None:
                return Translation("warning-unmapped", (), unsupported_reg_note("store base", mem[0] or "absolute"))
            if CONTEXT_KIND == "skb" and base[2] == "rdi" and size == "BPF_W" and mem[3] in {16, 20}:
                bpf_off = SKB_CB0_OFF if mem[3] == 16 else SKB_CB1_OFF
                payload = f"{store_payload_macro(base[2])}({src_reg[0]}, {base[0]}, {bpf_off})"
                return Translation("context-abi", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_MOVL)",),
                                   f"native skb shim cb store at off {mem[3]} maps to __sk_buff cb field at off {bpf_off}")
            target = DIRECT_STORE_SELECTOR.get(size)
            if target is None:
                return Translation("warning-unmapped", (), f"store size {size} needs a machine-level mov/store kinsn")
            if size == "BPF_B" and byte_lane(src):
                payload = f"{store_payload_macro(base[2], True)}({src_reg[0]}, {base[0]}, {mem[3]}, 1)"
            else:
                payload = f"{store_payload_macro(base[2])}({src_reg[0]}, {base[0]}, {mem[3]})"
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {target})",), "direct memory store via x86 kinsn selector")
        if "[" in dst and re.match(r"^-?(0x[0-9a-fA-F]+|\d+)$", src):
            mem = parse_mem(dst)
            size = size_from_mem(dst) or "BPF_W"
            if mem is None or mem[1] is not None:
                return Translation("warning-unmapped", (), f"store operand {dst} is not a direct base+disp memory reference")
            base = bpf_mem_base(mem[0])
            if base is None:
                return Translation("warning-unmapped", (), unsupported_reg_note("store base", mem[0] or "absolute"))
            imm = parse_int(src)
            if CONTEXT_KIND == "skb" and base[2] == "rdi" and size == "BPF_W" and mem[3] in {16, 20}:
                bpf_off = SKB_CB0_OFF if mem[3] == 16 else SKB_CB1_OFF
                return Translation("context-abi",
                                   (f"HC_KINSN({store_imm_payload_macro(base[2])}({base[0]}, {bpf_off}, {imm}), MICRO_HANDCRAFT_BPF_X86_MOVL)",),
                                   f"native skb shim cb store at off {mem[3]} maps to __sk_buff cb field at off {bpf_off}")
            if size == "BPF_B":
                return Translation("exact-kinsn",
                                   (f"HC_KINSN({store_imm_payload_macro(base[2])}({base[0]}, {mem[3]}, {imm}), MICRO_HANDCRAFT_BPF_X86_MOVB)",),
                                   "movb immediate memory store via x86 kinsn selector")
            target = DIRECT_STORE_SELECTOR.get(size)
            if target is not None:
                return Translation("exact-kinsn",
                                   (f"HC_KINSN({store_imm_payload_macro(base[2])}({base[0]}, {mem[3]}, {imm}), {target})",),
                                   "mov immediate memory store via x86 kinsn selector")
            return Translation("warning-unmapped", (), f"mov immediate store size {size} needs a machine-level store-immediate kinsn")
    if op == "movzx" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if dst and src and dst[1] == 32 and src[1] in {8, 16}:
            selector = "MICRO_HANDCRAFT_BPF_X86_MOVZBL" if src[1] == 8 else "MICRO_HANDCRAFT_BPF_X86_MOVZWL"
            return Translation("exact-kinsn", (f"HC_KINSN({reg_reg_payload(dst, src)}, {selector})",), f"movzx r32,r{src[1]} kinsn")
        size = size_from_mem(ops[1])
        if size not in {"BPF_B", "BPF_H"}:
            return Translation("warning-unmapped", (), f"movzx source size not recognized: {ops[1]}")
        return translate_mem_load(ops[0], ops[1], size)
    if op == "movsx" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if dst and src and dst[1] == 32 and src[1] == 16:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_reg_payload(dst, src)}, MICRO_HANDCRAFT_BPF_X86_MOVSWL)",), "movswl reg kinsn")
        return Translation("warning-unmapped", (), f"movsx operands are not supported: {insn.raw}")
    if op == "movsxd" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        if dst is None or dst[1] != 64:
            return Translation("warning-unmapped", (), f"movsxd destination {ops[0]} is not a writable x86 register")
        src = bpf_reg(ops[1])
        if src is not None and src[1] == 32:
            return Translation("exact-kinsn",
                               (f"HC_KINSN({reg_reg_payload(dst, src)}, MICRO_HANDCRAFT_BPF_X86_MOVSXD)",),
                               "movsxd reg kinsn")
        mem = parse_mem(ops[1])
        size = size_from_mem(ops[1])
        if mem is None or size != "BPF_W":
            return Translation("warning-unmapped", (), f"movsxd source is not a DWORD memory operand: {ops[1]}")
        base, index, scale, off = mem
        if base is None or index is None:
            return Translation("warning-unmapped", (), f"movsxd memory source is not indexed SIB: {ops[1]}")
        base_reg = bpf_mem_base(base)
        index_reg = bpf_reg(index)
        slog2 = scale_log2(scale)
        if base_reg is None or index_reg is None or slog2 is None:
            return Translation("warning-unmapped", (), f"movsxd SIB operand is not in the BPF register file: {ops[1]}")
        payload = f"HC_X86_ARCH_SIB_PAYLOAD({dst[0]}, {base_reg[0]}, {index_reg[0]}, {slog2}, {off})"
        return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_MOVSXD)",), "movsxd SIB kinsn")
    if op == "lea" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        mem = parse_mem(ops[1])
        if dst is None or mem is None:
            return Translation("warning-unmapped", (), "LEA operands are not representable")
        base, index, scale, disp = mem
        base_reg = bpf_reg(base) if base else None
        index_reg = bpf_reg(index) if index else None
        slog2 = scale_log2(scale)
        if (base and base_reg is None) or (index and index_reg is None) or slog2 is None:
            return Translation("warning-unmapped", (), f"LEA base/index not in BPF register file: {ops[1]}")
        target = "MICRO_HANDCRAFT_BPF_X86_LEAQ" if dst[1] == 64 else "MICRO_HANDCRAFT_BPF_X86_LEAL"
        note = "LEA via x86 kinsn selector"
        payload = (
            f"HC_LEA_PAYLOAD({dst[0]}, {base_reg[0] if base_reg else 0}, "
            f"{index_reg[0] if index_reg else 0}, {slog2}, {1 if base_reg else 0}, "
            f"{1 if index_reg else 0}, {disp})"
        )
        return Translation("exact-kinsn", (f"HC_KINSN({payload}, {target})",), note)
    if op == "rol" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        if dst and ops[1].lower() == "cl" and dst[1] in {32, 64}:
            selector = "MICRO_HANDCRAFT_BPF_X86_ROLQ" if dst[1] == 64 else "MICRO_HANDCRAFT_BPF_X86_ROLL"
            width = "q" if dst[1] == 64 else "l"
            return Translation("exact-kinsn", (f"HC_KINSN(HC_ROTATE_CL_PAYLOAD({dst[0]}, HC_X86_RCX), {selector})",), f"rol{width} cl kinsn")
        if dst and re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            if dst[1] == 64:
                return Translation("exact-kinsn", (f"HC_KINSN(HC_ROTATE_PAYLOAD({dst[0]}, {dst[0]}, {parse_int(ops[1])}), MICRO_HANDCRAFT_BPF_X86_ROLQ)",), "rolq imm kinsn")
            if dst[1] == 32:
                return Translation("exact-kinsn", (f"HC_KINSN(HC_ROTATE_PAYLOAD({dst[0]}, {dst[0]}, {parse_int(ops[1])}), MICRO_HANDCRAFT_BPF_X86_ROLL)",), "roll imm kinsn")
            if dst[1] == 16 and parse_int(ops[1]) == 8:
                return Translation("exact-kinsn", (f"HC_KINSN({x86_imm_payload(dst, 8)}, MICRO_HANDCRAFT_BPF_X86_ROLW)",), "rolw imm8 kinsn")
        return Translation("warning-unmapped", (), f"ROL width/register not supported by current selectors: {ops[0]}")
    if op == "popcnt" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if dst and src and dst[1] == 64 and src[1] == 64:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_reg_payload(dst, src)}, MICRO_HANDCRAFT_BPF_X86_POPCNTQ)",), "popcntq kinsn")
        return Translation("warning-unmapped", (), "only popcntq reg,reg is supported")
    if op == "imul" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if dst and src and dst[1] == 64 and src[1] == 64:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_reg_payload(dst, src)}, MICRO_HANDCRAFT_BPF_X86_IMULQ)",), "imulq reg,reg kinsn")
        return Translation("warning-unmapped", (), f"IMUL operands are not in the 64-bit BPF JIT register file: {insn.raw}")
    if op == "not" and len(ops) == 1:
        dst = bpf_reg(ops[0])
        if not dst:
            return Translation("warning-unmapped", (), unsupported_reg_note("NOT destination", ops[0]))
        selector = {8: "NOTB", 16: "NOTW", 32: "NOTL", 64: "NOTQ"}.get(dst[1])
        if selector:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_payload(dst[0])}, MICRO_HANDCRAFT_BPF_X86_{selector})",), f"not{dst[1]} reg kinsn")
        return Translation("warning-unmapped", (), f"NOT width not supported: {ops[0]}")
    if op == "bswap" and len(ops) == 1:
        dst = bpf_reg(ops[0])
        if not dst:
            return Translation("warning-unmapped", (), unsupported_reg_note("BSWAP destination", ops[0]))
        selector = {32: "MICRO_HANDCRAFT_BPF_X86_BSWAPL", 64: "MICRO_HANDCRAFT_BPF_X86_BSWAPQ"}.get(dst[1])
        if selector:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_payload(dst[0])}, {selector})",), f"bswap{dst[1]} kinsn")
        return Translation("warning-unmapped", (), f"BSWAP width not supported: {ops[0]}")
    if op in {"shld", "shrd"} and len(ops) == 3:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if not dst or not src:
            return Translation("warning-unmapped", (), f"{op.upper()} operands need explicit native-register payload support: {insn.raw}")
        if dst[1] != src[1] or dst[1] not in {32, 64}:
            return Translation("warning-unmapped", (), f"{op.upper()} width is not supported: {insn.raw}")
        if not re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[2]):
            return Translation("warning-unmapped", (), f"{op.upper()} count is not an immediate: {insn.raw}")
        if op == "shld":
            selector = "MICRO_HANDCRAFT_BPF_X86_SHLDQ" if dst[1] == 64 else "MICRO_HANDCRAFT_BPF_X86_SHLDL"
        else:
            selector = "MICRO_HANDCRAFT_BPF_X86_SHRDQ" if dst[1] == 64 else "MICRO_HANDCRAFT_BPF_X86_SHRDL"
        return Translation("exact-kinsn", (f"HC_KINSN(HC_SHD_PAYLOAD({dst[0]}, {src[0]}, {parse_int(ops[2])}), {selector})",), f"{op} imm kinsn")
    if op in ALU_OP and len(ops) == 2:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if dst is None:
            return Translation("warning-unmapped", (), unsupported_reg_note("ALU destination", ops[0]))
        bpf_class = "BPF_ALU64" if dst[1] == 64 else "BPF_ALU"
        selector = machine_alu_selector(op, dst[1])
        if src and selector:
            if op in {"shl", "shr"}:
                if src[2] != "rcx" or src[1] != 8:
                    return Translation("warning-unmapped", (), f"{op.upper()} variable count must be CL: {insn.raw}")
            elif dst[1] != src[1]:
                return Translation("warning-unmapped", (), f"{op.upper()} width is not supported: {insn.raw}")
            payload = machine_alu_rr_payload(dst, src)
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {selector})",), f"{op}{dst[1]} reg kinsn")
        if selector and re.match(r"^-?(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            payload = machine_alu_imm_payload(dst, parse_int(ops[1]))
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {selector})",), f"{op}{dst[1]} imm kinsn")
        if op == "xor" and src and dst[0] == src[0]:
            if dst[1] == 32:
                payload = machine_alu_rr_payload(dst, src)
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_XORL)",), "xorl zero-idiom kinsn")
            if dst[1] == 8:
                return Translation("exact-kinsn", (f"HC_KINSN({reg_reg_payload(dst, src)}, MICRO_HANDCRAFT_BPF_X86_XORB)",), "xorb zero-idiom kinsn")
            return Translation("warning-unmapped", (), f"{insn.raw} needs a machine-level xor zero-idiom kinsn")
        if op == "and" and dst[1] == 8 and re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            imm = parse_int(ops[1])
            if imm < 0 or imm > 0xff:
                return Translation("warning-unmapped", (), f"andb immediate is out of range: {insn.raw}")
            return Translation("exact-kinsn", (f"HC_KINSN({machine_alu_imm_payload(dst, imm)}, MICRO_HANDCRAFT_BPF_X86_ANDB)",), "andb imm kinsn")
        if op == "xor" and dst[1] == 8 and re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            imm = parse_int(ops[1])
            if imm < 0 or imm > 0xff:
                return Translation("warning-unmapped", (), f"xorb immediate is out of range: {insn.raw}")
            return Translation("exact-kinsn", (f"HC_KINSN({x86_imm_payload(dst, imm)}, MICRO_HANDCRAFT_BPF_X86_XORB)",), "xorb imm kinsn")
        if op == "xor" and dst[1] == 8 and src:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_reg_payload(dst, src)}, MICRO_HANDCRAFT_BPF_X86_XORB)",), "xorb reg kinsn")
        if op == "or" and dst[1] == 8 and src:
            payload = byte_reg_reg_payload(dst[0], src[0])
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_ORB)",), "orb reg kinsn")
        if src:
            return Translation("warning-unmapped", (), f"{insn.raw} needs a machine-level ALU register kinsn")
        if re.match(r"^-?(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            return Translation("warning-unmapped", (), f"{insn.raw} needs a machine-level ALU immediate kinsn")
        if "[" in ops[1]:
            mem = parse_mem(ops[1])
            size = size_from_mem(ops[1]) or ("BPF_DW" if dst[1] == 64 else "BPF_W")
            if mem is None:
                return Translation("warning-unmapped", (), f"ALU memory source is not parseable: {ops[1]}")
            base, index, scale, off = mem
            if base is None:
                return Translation("warning-unmapped", (), "ALU RIP/absolute memory source is not verifier-safe BPF memory")
            base_reg = bpf_mem_base(base)
            if base_reg is None:
                return Translation("warning-unmapped", (), unsupported_reg_note("ALU memory base", base))
            if index is None and selector and dst[1] in {32, 64} and size == ("BPF_DW" if dst[1] == 64 else "BPF_W"):
                payload = f"{mem_payload_macro(base_reg[2])}({dst[0]}, {base_reg[0]}, {off})"
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, {selector})",), f"{op}{dst[1]} memory-source kinsn")
            if index is None and op == "xor" and dst[1] == 16 and size == "BPF_H":
                payload = f"{mem_payload_macro(base_reg[2])}({dst[0]}, {base_reg[0]}, {off})"
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_XORW)",), "xorw memory-source kinsn")
            if index is not None and selector and dst[1] in {32, 64} and size == ("BPF_DW" if dst[1] == 64 else "BPF_W"):
                index_reg = bpf_reg(index)
                slog2 = scale_log2(scale)
                if index_reg is None or slog2 is None:
                    return Translation("warning-unmapped", (), f"ALU SIB index {index} scale {scale} is not expressible")
                payload = f"HC_X86_ARCH_SIB_PAYLOAD({dst[0]}, {base_reg[0]}, {index_reg[0]}, {slog2}, {off})"
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, {selector})",), f"{op}{dst[1]} SIB memory-source kinsn")
            if index is not None and op == "xor" and dst[1] == 8 and size == "BPF_B":
                index_reg = bpf_reg(index)
                slog2 = scale_log2(scale)
                if index_reg is None or slog2 is None:
                    return Translation("warning-unmapped", (), f"ALU SIB index {index} scale {scale} is not expressible")
                payload = f"HC_X86_ARCH_SIB_PAYLOAD({dst[0]}, {base_reg[0]}, {index_reg[0]}, {slog2}, {off})"
                return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_XORB)",), "xorb SIB memory-source kinsn")
            return Translation("warning-unmapped", (), f"ALU memory source form has no current selector: {insn.raw}")
        return Translation("warning-unmapped", (), f"ALU source {ops[1]} is not supported")
    if op == "sar" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        if dst is None:
            return Translation("warning-unmapped", (), unsupported_reg_note("SAR destination", ops[0]))
        if not re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            return Translation("warning-unmapped", (), f"SAR source {ops[1]} is not an immediate")
        selector = machine_alu_selector("sar", dst[1])
        if selector:
            payload = machine_alu_imm_payload(dst, parse_int(ops[1]))
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {selector})",), f"sar{dst[1]} imm kinsn")
        return Translation("warning-unmapped", (), f"{insn.raw} needs a machine-level sar kinsn")
    if op == "test" and len(ops) == 2:
        left = bpf_reg(ops[0])
        right = bpf_reg(ops[1])
        if "[" in ops[0] and re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            mem = parse_mem(ops[0])
            size = size_from_mem(ops[0])
            if mem is None or size != "BPF_B":
                return Translation("warning-unmapped", (), f"test memory immediate form has unsupported size: {insn.raw}")
            base, index, scale, off = mem
            if base is None or index is not None:
                return Translation("warning-unmapped", (), f"test memory immediate form is not direct base+disp: {insn.raw}")
            base_reg = bpf_mem_base(base)
            if base_reg is None:
                return Translation("warning-unmapped", (), f"test memory base {base} is not in the BPF register file: {insn.raw}")
            payload = f"HC_X86_CMP_ARCH_MEM_IMM_PAYLOAD({base_reg[0]}, {off}, {parse_int(ops[1])})"
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_TESTB)",), "testb memory,imm kinsn")
        if left and right and left[1] == right[1] and left[1] in WIDTH_SELECTOR["test"]:
            payload = reg_reg_payload(left, right)
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, {WIDTH_SELECTOR['test'][left[1]]})",), f"test{left[1]} reg,reg kinsn")
        if left and left[1] == 8 and re.match(r"^(0x[0-9a-fA-F]+|\d+)$", ops[1]):
            payload = x86_imm_payload(left, parse_int(ops[1]))
            return Translation("exact-kinsn", (f"HC_KINSN({payload}, MICRO_HANDCRAFT_BPF_X86_TESTB)",), "testb imm kinsn")
        return Translation("warning-unmapped", (), f"test operand form needs a machine-level test kinsn: {insn.raw}")
    if op == "inc" and len(ops) == 1:
        dst = bpf_reg(ops[0])
        if dst:
            if dst[1] == 8:
                return Translation("exact-kinsn", (f"HC_KINSN({reg_payload(dst[0])}, MICRO_HANDCRAFT_BPF_X86_INCB)",), "incb reg kinsn")
            if dst[1] == 32:
                return Translation("exact-kinsn", (f"HC_KINSN({reg_payload(dst[0])}, MICRO_HANDCRAFT_BPF_X86_INCL)",), "incl reg kinsn")
            if dst[1] == 64:
                return Translation("exact-kinsn", (f"HC_KINSN({reg_payload(dst[0])}, MICRO_HANDCRAFT_BPF_X86_INCQ)",), "incq reg kinsn")
            return Translation("warning-unmapped", (), f"inc width {dst[1]} needs a machine-level inc kinsn")
        return Translation("warning-unmapped", (), unsupported_reg_note("INC destination", ops[0]))
    if op == "div" and len(ops) == 1:
        src = bpf_reg(ops[0])
        if src and src[1] == 32:
            return Translation("exact-kinsn", (f"HC_KINSN({reg_payload(src[0])}, MICRO_HANDCRAFT_BPF_X86_DIVL)",), "divl reg kinsn")
        return Translation("warning-unmapped", (), f"DIV operand form needs a machine-level divl kinsn: {insn.raw}")
    if op in {"cmovne", "cmove", "cmovb"} and len(ops) == 2:
        dst = bpf_reg(ops[0])
        src = bpf_reg(ops[1])
        if dst and src and dst[1] == src[1] and dst[1] in {32, 64}:
            selector = f"MICRO_HANDCRAFT_BPF_X86_{CMOV_PREFIX[op]}{'Q' if dst[1] == 64 else 'L'}"
            return Translation("exact-kinsn", (f"HC_KINSN(HC_CMOV_PAYLOAD({dst[0]}, {src[0]}), {selector})",), "cmov kinsn using module shadow flags")
        return Translation("warning-unmapped", (), f"{op} operands are not supported")
    if op in {"sete", "setne", "setge"} and len(ops) == 1:
        dst = bpf_reg(ops[0])
        if dst:
            selector = SETCC_SELECTOR[op]
            return Translation("exact-kinsn", (f"HC_KINSN({setcc_payload(dst[0])}, {selector})",), "setcc kinsn using module shadow flags")
        return Translation("warning-unmapped", (), unsupported_reg_note("SETcc destination", ops[0]))
    if op == "sbb" and len(ops) == 2:
        dst = bpf_reg(ops[0])
        if dst and dst[1] == 32 and is_int(ops[1]) and parse_int(ops[1]) == 0:
            return Translation("exact-kinsn", (f"HC_KINSN({machine_alu_imm_payload(dst, 0)}, MICRO_HANDCRAFT_BPF_X86_SBBL)",),
                               "sbbl imm0 kinsn using module shadow CF")
        return Translation("warning-unmapped", (), f"SBB operand form has no current kinsn selector: {insn.raw}")
    return Translation("warning-unmapped", (), f"unsupported mnemonic or operand form: {insn.raw}")


def translate_all(insns: list[NativeInsn]) -> list[Translation]:
    def flag_source(index: int) -> int | None:
        cursor = index - 1
        while cursor >= 0:
            mnemonic = insns[cursor].mnemonic
            if mnemonic in {"cmp", "test"}:
                return cursor
            if mnemonic in FLAG_TRANSPARENT_OPS:
                cursor -= 1
                continue
            return None
        return None

    jcc_source = {
        index: flag_source(index)
        for index, insn in enumerate(insns)
        if insn.mnemonic in JCC_OP
    }
    cmov_source = {
        index: flag_source(index)
        for index, insn in enumerate(insns)
        if insn.mnemonic in CMOV_CMP_OP
    }
    snapshot_sources = {
        source
        for index, source in {**jcc_source, **cmov_source}.items()
        if source is not None and source != index - 1
    }

    out: list[Translation] = []
    for index, insn in enumerate(insns):
        trans = translate(insn)
        if index in snapshot_sources:
            snapshot = snapshot_cmp(insn)
            if snapshot is not None:
                trans = Translation("control-flow-operand", snapshot,
                                    f"{insn.mnemonic} snapshotted for later ordinary BPF branch")
        if insn.mnemonic in JCC_OP and index > 0:
            prev = insns[index - 1]
            code = lower_cmp_jcc(insn, prev)
            consume_prev = code is not None and prev.mnemonic == "cmp"
            if code is None:
                code = lower_test_jcc(insn, prev)
                consume_prev = code is not None and prev.mnemonic == "test"
            if code is None:
                code = lower_result_jcc(insn, prev)
            source = jcc_source.get(index)
            if code is None and source is not None and source != index - 1:
                producer = insns[source]
                code = lower_saved_cmp_jcc(insn, producer)
                if code is None:
                    code = lower_saved_test_jcc(insn, producer)
            if code is not None:
                trans = Translation("exact-bpf", code, f"{insn.mnemonic} as ordinary BPF branch", trans.target_addr)
                if consume_prev:
                    out[-1] = Translation("control-flow-operand", (), f"{prev.mnemonic} folded into BPF branch")
            out.append(trans)
            continue
        if insn.mnemonic in CMOV_CMP_OP:
            source = cmov_source.get(index)
            code = None
            consume_prev = False
            if source is not None:
                producer = insns[source]
                code = lower_cmp_cmov(insn, producer, saved=source != index - 1)
                consume_prev = code is not None and source == index - 1
            if code is not None:
                trans = Translation("exact-bpf", code, f"{insn.mnemonic} as ordinary BPF conditional move")
                if consume_prev:
                    out[-1] = Translation("control-flow-operand", (), f"{insns[source].mnemonic} folded into BPF conditional move")
        out.append(trans)
    return out



def bpf_insn_len(code: str) -> int:
    if code.startswith("HC_INIT_X86_STACK("):
        return 4
    if code.startswith("HC_LD_IMM64_RAW("):
        return 2
    if code.startswith("HC_KINSN("):
        return 2
    return 1


def relocate_branch_offsets(insns: list[NativeInsn], translations: list[Translation]) -> list[Translation]:
    pc_by_addr: dict[int, int] = {}
    pc_by_index: list[int] = []
    pc = 0
    for index, (insn, trans) in enumerate(zip(insns, translations, strict=True)):
        pc_by_addr.setdefault(insn.addr, pc)
        pc_by_index.append(pc)
        pc += sum(bpf_insn_len(code) for code in trans.code)

    patched: list[Translation] = []
    for index, trans in enumerate(translations):
        if trans.target_addr is None:
            patched.append(trans)
            continue
        target_pc = pc_by_addr.get(trans.target_addr)
        if target_pc is None:
            if trans.status in {"abi-boundary", "exact-bpf"}:
                patched.append(Translation("control-flow-gap", (),
                                           f"{trans.note}; target 0x{trans.target_addr:x} is outside parsed asm",
                                           trans.target_addr))
                continue
            patched.append(Translation("warning-unmapped", (),
                                       f"{trans.note}; branch target 0x{trans.target_addr:x} is outside parsed asm",
                                       trans.target_addr))
            continue
        code = []
        code_pc = pc_by_index[index]
        for item in trans.code:
            if item.startswith("HC_KINSN("):
                if BRANCH_DELTA in item:
                    raise ValueError(f"kinsn payload cannot carry program branch target: 0x{insns[index].addr:x}")
                delta = 0
            else:
                delta = target_pc - code_pc
            code.append(item.replace(BRANCH_DELTA, str(delta)))
            code_pc += bpf_insn_len(item)
        code = tuple(code)
        patched.append(Translation(trans.status, code, trans.note, trans.target_addr))
    return patched


def write_outputs(insns: list[NativeInsn], translations: list[Translation], output: Path) -> None:
    warnings = sum(1 for item in translations if item.status.startswith("warning"))
    output_lines = [
        '#include "handcraft_common.h"',
        "",
        "#define HC_LEA_PAYLOAD(DST, BASE, INDEX, SCALE, HAS_BASE, HAS_INDEX, DISP) \\",
        "    ((__u64)(HC_X86_FORM_ARCH_MEM) | ((__u64)(DST) << 4) | \\",
        "     ((__u64)(BASE) << 8) | ((__u64)(INDEX) << 12) | \\",
        "     ((__u64)(SCALE) << 16) | ((__u64)(HAS_INDEX) << 18) | \\",
        "     ((__u64)(HAS_BASE) << 19) | ((__u64)(__u32)(DISP) << 20))",
        "",
    ]
    if warnings:
        output_lines.extend([
            "/*",
            f" * native asm to handcraft warnings: {warnings}",
            " *",
        ])
        for insn, trans in zip(insns, translations, strict=True):
            if trans.status.startswith("warning"):
                output_lines.append(f" * - 0x{insn.addr:x}: {insn.raw} [{trans.status}: {trans.note}]")
        output_lines.extend([" */", ""])
    output_lines.append("static const struct bpf_insn program[] = {")
    output_lines.extend([
        "    HC_INIT_X86_STACK(),",
        "    HC_MOV64_IMM(BPF_REG_6, 0),",
        "    HC_MOV64_IMM(BPF_REG_7, 0),",
        "    HC_MOV64_IMM(BPF_REG_8, 0),",
        "    HC_MOV64_IMM(BPF_REG_9, 0),",
    ])
    for insn, trans in zip(insns, translations, strict=True):
        prefix = f"    /* 0x{insn.addr:x}: {insn.raw} [{trans.status}: {trans.note}] */"
        output_lines.append(prefix)
        for code in trans.code:
            output_lines.append(f"    {code},")
    output_lines.extend(["};", "", "HC_EXPORT_PROGRAM(program)", ""])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(output_lines))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path, help="native asm plain text or micro md containing a Native ASM section")
    parser.add_argument("--output", required=True, type=Path, help="generated .handcraft.c path")
    parser.add_argument("--entry-symbol", help="entry function when the input contains full objdump output")
    parser.add_argument("--context-kind", choices=("xdp", "skb"), default="xdp")
    args = parser.parse_args()

    global CONTEXT_KIND
    CONTEXT_KIND = args.context_kind
    insns = parse_native_asm(args.input.read_text(), args.entry_symbol)
    translations = relocate_branch_offsets(insns, translate_all(insns))
    fatal = [
        (insn, trans)
        for insn, trans in zip(insns, translations, strict=True)
        if not trans.code and trans.status not in {"padding", "control-flow-operand"}
    ]
    if fatal:
        for insn, trans in fatal:
            print(f"error: 0x{insn.addr:x}: {insn.raw}: {trans.status}: {trans.note}")
        return 1
    write_outputs(insns, translations, args.output)
    warnings = sum(1 for item in translations if item.status.startswith("warning"))
    exact = sum(1 for item in translations if item.status == "exact-kinsn")
    padding = sum(1 for item in translations if item.status == "padding")
    print(
        f"insns={len(insns)} exact_kinsn={exact} "
        f"padding={padding} warnings={warnings}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
