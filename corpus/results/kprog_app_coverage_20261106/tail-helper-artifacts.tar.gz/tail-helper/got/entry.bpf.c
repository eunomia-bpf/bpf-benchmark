#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("socket")
int tail_got_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: call   QWORD PTR [rip+0x0] */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_coarse_ns);
x86_l_6:
	/* 0x6: jmp    b <entry+0xb> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_b:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
