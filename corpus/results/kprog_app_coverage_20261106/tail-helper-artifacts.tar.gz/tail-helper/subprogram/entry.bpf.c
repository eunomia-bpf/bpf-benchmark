#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("socket")
int tail_subprogram_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: call   a <inner> */
	X86_SIM_X86_CALL(x86_l_a, 0x5ULL);
x86_l_5:
	/* 0x5: jmp    10 <inner+0x6> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_10:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_a */
x86_l_a:
	/* 0xa: call   f <inner+0x5> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_coarse_ns);
x86_l_f:
	/* 0xf: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x5ULL: goto x86_l_5;
	case 0xfULL: goto x86_l_f;
	}

}

X86_SIM_LICENSE();
