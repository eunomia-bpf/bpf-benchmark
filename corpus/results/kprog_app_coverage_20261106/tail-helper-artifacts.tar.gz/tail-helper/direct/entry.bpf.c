#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("socket")
int tail_direct_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: call   5 <entry+0x5> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_coarse_ns);
x86_l_5:
	/* 0x5: jmp    a <entry+0xa> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_a:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
