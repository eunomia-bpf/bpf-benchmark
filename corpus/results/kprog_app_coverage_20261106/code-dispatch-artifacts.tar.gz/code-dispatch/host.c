#include <stdio.h>
struct context { void *data,*end; };
extern unsigned join_blob(struct context *),cmov_blob(struct context *),call_blob(struct context *);
extern unsigned pc32_blob(struct context *);
int main(void) {
    unsigned char packet[9]={}; struct context ctx={packet,packet+9};
    for(unsigned bit=0;bit<2;bit++) {
        packet[8]=bit;
        unsigned a=join_blob(&ctx),b=cmov_blob(&ctx),c=call_blob(&ctx),d=pc32_blob(&ctx);
        printf("input=%u join=%u cmov=%u nested_call=%u pc32=%u\n",bit,a,b,c,d);
        if(a!=(bit?17:42)||b!=a||c!=(bit?14:6)||d!=42)return 1;
    }
    return 0;
}
