#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

SEC("xdp")
int pc32_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: lea    rax,[rip+0x7] */
	X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0xeULL);
x86_l_7:
	/* 0x7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_X86_CALL(x86_l_e, 0x9ULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_9:
	/* 0x9: jmp    14 <pc32_callee+0x6> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_14:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_e */
x86_l_e:
	/* 0xe: mov    eax,0x2a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 42ULL);
x86_l_13:
	/* 0x13: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x9ULL: goto x86_l_9;
	}

}

X86_SIM_LICENSE();
