#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int dispatch_orig(struct xdp_md *ctx) { return 42; }
char LICENSE[] SEC("license")="GPL";
