#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

SEC("xdp")
int join_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    rcx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: lea    rax,[rdx+0x9] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 9ULL);
x86_l_b:
	/* 0xb: cmp    rax,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_e:
	/* 0xe: ja     3c <join_native+0x3c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe, 0x3c, x86_l_3c);
x86_l_10:
	/* 0x10: cmp    BYTE PTR [rdx+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_14:
	/* 0x14: jne    1f <join_native+0x1f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14, 0x1f, x86_l_1f);
x86_l_16:
	/* 0x16: lea    rax,[rip+0xb] */
	X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x28ULL);
x86_l_1d:
	/* 0x1d: jmp    26 <join_native+0x26> */
	X86_SIM_X86_JMP(0x1d, 0x26, x86_l_26);
x86_l_1f:
	/* 0x1f: lea    rax,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x32ULL);
x86_l_26:
	/* 0x26: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x28ULL: goto x86_l_28;
			case 0x32ULL: goto x86_l_32;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28:
	/* 0x28: mov    eax,0x2a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 42ULL);
x86_l_2d:
	/* 0x2d: jmp    46 <join_native+0x46> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_32:
	/* 0x32: mov    eax,0x11 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_37:
	/* 0x37: jmp    46 <join_native+0x46> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_3c:
	/* 0x3c: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_41:
	/* 0x41: jmp    46 <join_native+0x46> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_46:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
