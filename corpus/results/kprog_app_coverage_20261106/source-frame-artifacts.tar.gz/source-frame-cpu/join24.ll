; ModuleID = 'bpf-source'
source_filename = "bpf-source"

define i64 @bpf_main(ptr %0) {
setupBlock:
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 0, ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  store i64 0, ptr %r4, align 4
  store i64 0, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, i32 24, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 24
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %0, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  %1 = call i64 @_bpf_helper_ext_0007()
  store i64 %1, ptr %r0, align 4
  br label %bb_inst_1

bb_inst_1:                                        ; preds = %bb_inst_0
  %2 = load i64, ptr %r10, align 4
  store i64 %2, ptr %r1, align 4
  %3 = load i64, ptr %r0, align 4
  %4 = icmp eq i64 %3, 0
  br i1 %4, label %bb_inst_5, label %bb_inst_3

bb_inst_3:                                        ; preds = %bb_inst_1
  %5 = load i64, ptr %r1, align 4
  %6 = add i64 %5, -8
  store i64 %6, ptr %r1, align 4
  br label %bb_inst_6

bb_inst_5:                                        ; preds = %bb_inst_1
  %7 = load i64, ptr %r1, align 4
  %8 = add i64 %7, -24
  store i64 %8, ptr %r1, align 4
  br label %bb_inst_6

bb_inst_6:                                        ; preds = %bb_inst_5, %bb_inst_3
  %9 = load ptr, ptr %r1, align 8
  %10 = getelementptr i8, ptr %9, i64 0
  store i64 42, ptr %10, align 8
  store i64 0, ptr %r0, align 4
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_6
  %11 = load i64, ptr %r0, align 4
  ret i64 %11
}

declare i64 @_bpf_helper_ext_0007()
