#include <stddef.h>
#include <stdlib.h>
#include <string.h>
unsigned observed_calls;
long bpf_probe_read_kernel(void *buffer, unsigned size, const void *source) {
 if (size != 8 || source != NULL) abort();
 ++observed_calls; memset(buffer, 0, size); return -14;
}
