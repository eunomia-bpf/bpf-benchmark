; ModuleID = 'bpf-source'
source_filename = "bpf-source"

define i64 @bpf_main(ptr %0) {
setupBlock:
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 0, ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  store i64 0, ptr %r4, align 4
  store i64 0, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, i32 512, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 512
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %0, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  %1 = load i64, ptr %r10, align 4
  store i64 %1, ptr %r1, align 4
  %2 = load i64, ptr %r1, align 4
  %3 = load ptr, ptr %r10, align 8
  %4 = getelementptr i8, ptr %3, i64 -8
  store i64 %2, ptr %4, align 8
  %5 = load ptr, ptr %r10, align 8
  %6 = getelementptr i8, ptr %5, i64 -8
  %7 = load i64, ptr %6, align 8
  store i64 %7, ptr %r2, align 4
  %8 = load i64, ptr %r2, align 4
  %9 = add i64 %8, -24
  store i64 %9, ptr %r2, align 4
  %10 = load ptr, ptr %r2, align 8
  %11 = getelementptr i8, ptr %10, i64 0
  store i64 42, ptr %11, align 8
  store i64 0, ptr %r0, align 4
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_0
  %12 = load i64, ptr %r0, align 4
  ret i64 %12
}
