; ModuleID = '/workspaces/repository/corpus/results/kprog_app_coverage_20261106/startup-lift/frame_five_args/native.ll'
source_filename = "bpf-source"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @bpf_main(ptr nocapture readnone %0) local_unnamed_addr #0 {
setupBlock:
  ret i64 165
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i64 @__llvmbpf_pseudo_call_pc_00000007(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4) local_unnamed_addr #0 {
setupBlock:
  %5 = add i64 %1, %0
  %6 = add i64 %5, %2
  %7 = add i64 %6, %3
  %8 = add i64 %7, %4
  ret i64 %8
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
