#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("tracepoint/native/startup")
int bcc_trace_frame_cfg_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4:
	/* 0x4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_9:
	/* 0x9: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b:
	/* 0xb: call   10 <bpf_main+0x10> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_10:
	/* 0x10: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: jmp    16 <bpf_main+0x16> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_16:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
