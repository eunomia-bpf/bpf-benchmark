; ModuleID = 'bpf-source'
source_filename = "bpf-source"

define i64 @bpf_main(ptr %0) {
setupBlock:
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 0, ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  store i64 0, ptr %r4, align 4
  store i64 0, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, i32 8, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 8
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %0, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  store i64 12, ptr %r6, align 4
  store i64 11, ptr %r1, align 4
  store i64 22, ptr %r2, align 4
  store i64 33, ptr %r3, align 4
  store i64 44, ptr %r4, align 4
  store i64 55, ptr %r5, align 4
  %1 = load i64, ptr %r1, align 4
  %2 = load i64, ptr %r2, align 4
  %3 = load i64, ptr %r3, align 4
  %4 = load i64, ptr %r4, align 4
  %5 = load i64, ptr %r5, align 4
  %6 = call i64 @__llvmbpf_pseudo_call_pc_00000009(i64 %1, i64 %2, i64 %3, i64 %4, i64 %5)
  store i64 %6, ptr %r0, align 4
  br label %bb_inst_7

bb_inst_7:                                        ; preds = %bb_inst_0
  %7 = load i64, ptr %r0, align 4
  %8 = load i64, ptr %r6, align 4
  %9 = add i64 %7, %8
  store i64 %9, ptr %r0, align 4
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_7
  %10 = load i64, ptr %r0, align 4
  ret i64 %10
}

define i64 @__llvmbpf_pseudo_call_pc_00000009(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4) {
setupBlock:
  %5 = inttoptr i64 %0 to ptr
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 %1, ptr %r2, align 4
  store i64 %2, ptr %r3, align 4
  store i64 %3, ptr %r4, align 4
  store i64 %4, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, i32 8, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 8
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %5, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  %6 = load i64, ptr %r1, align 4
  store i64 %6, ptr %r0, align 4
  %7 = load i64, ptr %r0, align 4
  %8 = load i64, ptr %r2, align 4
  %9 = add i64 %7, %8
  store i64 %9, ptr %r0, align 4
  %10 = load i64, ptr %r0, align 4
  %11 = load i64, ptr %r3, align 4
  %12 = add i64 %10, %11
  store i64 %12, ptr %r0, align 4
  %13 = load i64, ptr %r0, align 4
  %14 = load i64, ptr %r4, align 4
  %15 = add i64 %13, %14
  store i64 %15, ptr %r0, align 4
  %16 = load i64, ptr %r0, align 4
  %17 = load i64, ptr %r5, align 4
  %18 = add i64 %16, %17
  store i64 %18, ptr %r0, align 4
  store i64 99, ptr %r6, align 4
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_0
  %19 = load i64, ptr %r0, align 4
  ret i64 %19
}
