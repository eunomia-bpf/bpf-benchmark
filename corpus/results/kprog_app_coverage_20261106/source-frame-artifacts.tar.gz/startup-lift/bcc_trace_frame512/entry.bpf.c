#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 520U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("tracepoint/native/startup")
int bcc_trace_frame512_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x208 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 520ULL);
x86_l_7:
	/* 0x7: lea    rdi,[rsp+0x200] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 512ULL);
x86_l_f:
	/* 0xf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_14:
	/* 0x14: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16:
	/* 0x16: call   1b <bpf_main+0x1b> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_1b:
	/* 0x1b: add    rsp,0x208 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 520ULL);
x86_l_22:
	/* 0x22: jmp    27 <bpf_main+0x27> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_27:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
