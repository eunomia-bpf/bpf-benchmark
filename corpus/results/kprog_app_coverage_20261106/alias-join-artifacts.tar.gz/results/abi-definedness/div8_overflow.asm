
/workspaces/repository/corpus/results/kprog_app_coverage_20261106/abi-definedness/div8_overflow.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b8 00 01 00 00                                  	mov    eax,0x100
   5:	31 d2                                           	xor    edx,edx
   7:	b9 01 00 00 00                                  	mov    ecx,0x1
   c:	f6 f1                                           	div    cl
   e:	b8 02 00 00 00                                  	mov    eax,0x2
  13:	c3                                              	ret
