
/workspaces/repository/corpus/results/kprog_app_coverage_20261106/abi-definedness/unsupported_instruction.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	0f 0b                                           	ud2
   2:	b8 02 00 00 00                                  	mov    eax,0x2
   7:	c3                                              	ret
