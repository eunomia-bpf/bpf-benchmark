#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int tracee_http_method_prefix_detect_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rcx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: mov    rdx,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a:
	/* 0xa: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c:
	/* 0xc: cmp    rdx,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_f:
	/* 0xf: jbe    16 <tracee_http_method_prefix_detect_xdp+0x16> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xf, 0x16, x86_l_16);
x86_l_11:
	/* 0x11: jmp    2b6 <tracee_http_method_prefix_detect_xdp+0x2b6> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_16:
	/* 0x16: lea    rdi,[rdx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a:
	/* 0x1a: cmp    rdi,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_1d:
	/* 0x1d: ja     11 <tracee_http_method_prefix_detect_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d, 0x11, x86_l_11);
x86_l_1f:
	/* 0x1f: lea    rdi,[rdx+0x90] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_26:
	/* 0x26: cmp    rdi,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_29:
	/* 0x29: ja     11 <tracee_http_method_prefix_detect_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x29, 0x11, x86_l_11);
x86_l_2b:
	/* 0x2b: cmp    DWORD PTR [rdx+0x8],0x8 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738376ULL);
x86_l_2f:
	/* 0x2f: jne    11 <tracee_http_method_prefix_detect_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f, 0x11, x86_l_11);
x86_l_31:
	/* 0x31: cmp    DWORD PTR [rdx+0xc],0x10 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607568ULL);
x86_l_35:
	/* 0x35: jne    11 <tracee_http_method_prefix_detect_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35, 0x11, x86_l_11);
x86_l_37:
	/* 0x37: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_39:
	/* 0x39: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3a:
	/* 0x3a: add    rdx,0x16 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 22ULL);
x86_l_3e:
	/* 0x3e: movabs rbx,0xa0761d6478bd642f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 11562461410679940143ULL);
x86_l_48:
	/* 0x48: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4d:
	/* 0x4d: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_50:
	/* 0x50: movzx  edi,BYTE PTR [rdx-0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551610ULL);
x86_l_54:
	/* 0x54: movzx  r8d,BYTE PTR [rdx-0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551611ULL);
x86_l_59:
	/* 0x59: cmp    edi,0x47 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 71ULL);
x86_l_5c:
	/* 0x5c: jg     a5 <tracee_http_method_prefix_detect_xdp+0xa5> */
	X86_SIM_X86_JCC(X86_CC_G, 0x5c, 0xa5, x86_l_a5);
x86_l_5e:
	/* 0x5e: cmp    edi,0x44 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 68ULL);
x86_l_61:
	/* 0x61: je     110 <tracee_http_method_prefix_detect_xdp+0x110> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61, 0x110, x86_l_110);
x86_l_67:
	/* 0x67: cmp    edi,0x47 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 71ULL);
x86_l_6a:
	/* 0x6a: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a, 0x20c, x86_l_20c);
x86_l_70:
	/* 0x70: cmp    r8b,0x45 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_8, 69ULL);
x86_l_74:
	/* 0x74: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x74, 0x20c, x86_l_20c);
x86_l_7a:
	/* 0x7a: mov    r8d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 69ULL);
x86_l_80:
	/* 0x80: cmp    BYTE PTR [rdx-0x4],0x54 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744056529682516ULL);
x86_l_84:
	/* 0x84: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x84, 0x20c, x86_l_20c);
x86_l_8a:
	/* 0x8a: mov    r10d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 69ULL);
x86_l_90:
	/* 0x90: cmp    BYTE PTR [rdx-0x3],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744060824649760ULL);
x86_l_94:
	/* 0x94: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x94, 0x20c, x86_l_20c);
x86_l_9a:
	/* 0x9a: mov    r9d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 1ULL);
x86_l_a0:
	/* 0xa0: jmp    1d2 <tracee_http_method_prefix_detect_xdp+0x1d2> */
	X86_SIM_X86_JMP(0xa0, 0x1d2, x86_l_1d2);
x86_l_a5:
	/* 0xa5: movzx  r9d,r8b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_WIDTH_8);
x86_l_a9:
	/* 0xa9: cmp    edi,0x48 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 72ULL);
x86_l_ac:
	/* 0xac: je     16e <tracee_http_method_prefix_detect_xdp+0x16e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac, 0x16e, x86_l_16e);
x86_l_b2:
	/* 0xb2: cmp    edi,0x50 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 80ULL);
x86_l_b5:
	/* 0xb5: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb5, 0x20c, x86_l_20c);
x86_l_bb:
	/* 0xbb: cmp    r9d,0x55 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_32, 85ULL);
x86_l_bf:
	/* 0xbf: je     1b4 <tracee_http_method_prefix_detect_xdp+0x1b4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbf, 0x1b4, x86_l_1b4);
x86_l_c5:
	/* 0xc5: cmp    r9d,0x4f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_32, 79ULL);
x86_l_c9:
	/* 0xc9: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc9, 0x20c, x86_l_20c);
x86_l_cf:
	/* 0xcf: mov    r8d,0x4f */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 79ULL);
x86_l_d5:
	/* 0xd5: cmp    BYTE PTR [rdx-0x4],0x53 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744056529682515ULL);
x86_l_d9:
	/* 0xd9: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd9, 0x20c, x86_l_20c);
x86_l_df:
	/* 0xdf: cmp    BYTE PTR [rdx-0x3],0x54 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744060824649812ULL);
x86_l_e3:
	/* 0xe3: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe3, 0x20c, x86_l_20c);
x86_l_e9:
	/* 0xe9: mov    r10d,0x4f */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 79ULL);
x86_l_ef:
	/* 0xef: cmp    BYTE PTR [rdx-0x2],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617056ULL);
x86_l_f3:
	/* 0xf3: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf3, 0x20c, x86_l_20c);
x86_l_f9:
	/* 0xf9: mov    r9d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 2ULL);
x86_l_ff:
	/* 0xff: mov    r8d,0x53 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 83ULL);
x86_l_105:
	/* 0x105: mov    r11d,0x54 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 84ULL);
x86_l_10b:
	/* 0x10b: jmp    21c <tracee_http_method_prefix_detect_xdp+0x21c> */
	X86_SIM_X86_JMP(0x10b, 0x21c, x86_l_21c);
x86_l_110:
	/* 0x110: cmp    r8b,0x45 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_8, 69ULL);
x86_l_114:
	/* 0x114: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x114, 0x20c, x86_l_20c);
x86_l_11a:
	/* 0x11a: mov    r8d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 69ULL);
x86_l_120:
	/* 0x120: cmp    BYTE PTR [rdx-0x4],0x4c */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744056529682508ULL);
x86_l_124:
	/* 0x124: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x124, 0x20c, x86_l_20c);
x86_l_12a:
	/* 0x12a: cmp    BYTE PTR [rdx-0x3],0x45 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744060824649797ULL);
x86_l_12e:
	/* 0x12e: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12e, 0x20c, x86_l_20c);
x86_l_134:
	/* 0x134: cmp    BYTE PTR [rdx-0x2],0x54 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617108ULL);
x86_l_138:
	/* 0x138: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x138, 0x20c, x86_l_20c);
x86_l_13e:
	/* 0x13e: cmp    BYTE PTR [rdx-0x1],0x45 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744069414584389ULL);
x86_l_142:
	/* 0x142: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x142, 0x20c, x86_l_20c);
x86_l_148:
	/* 0x148: mov    r11d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 69ULL);
x86_l_14e:
	/* 0x14e: cmp    BYTE PTR [rdx],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_151:
	/* 0x151: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x151, 0x20c, x86_l_20c);
x86_l_157:
	/* 0x157: mov    r9d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 4ULL);
x86_l_15d:
	/* 0x15d: mov    r8d,0x4c */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 76ULL);
x86_l_163:
	/* 0x163: mov    r10d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 69ULL);
x86_l_169:
	/* 0x169: jmp    21c <tracee_http_method_prefix_detect_xdp+0x21c> */
	X86_SIM_X86_JMP(0x169, 0x21c, x86_l_21c);
x86_l_16e:
	/* 0x16e: cmp    r9d,0x54 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_32, 84ULL);
x86_l_172:
	/* 0x172: je     1e0 <tracee_http_method_prefix_detect_xdp+0x1e0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172, 0x1e0, x86_l_1e0);
x86_l_174:
	/* 0x174: cmp    r9d,0x45 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_32, 69ULL);
x86_l_178:
	/* 0x178: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x178, 0x20c, x86_l_20c);
x86_l_17e:
	/* 0x17e: mov    r8d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 69ULL);
x86_l_184:
	/* 0x184: cmp    BYTE PTR [rdx-0x4],0x41 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744056529682497ULL);
x86_l_188:
	/* 0x188: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x188, 0x20c, x86_l_20c);
x86_l_18e:
	/* 0x18e: cmp    BYTE PTR [rdx-0x3],0x44 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744060824649796ULL);
x86_l_192:
	/* 0x192: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x192, 0x20c, x86_l_20c);
x86_l_194:
	/* 0x194: mov    r10d,0x45 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 69ULL);
x86_l_19a:
	/* 0x19a: cmp    BYTE PTR [rdx-0x2],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617056ULL);
x86_l_19e:
	/* 0x19e: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19e, 0x20c, x86_l_20c);
x86_l_1a0:
	/* 0x1a0: mov    r9d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 5ULL);
x86_l_1a6:
	/* 0x1a6: mov    r8d,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 65ULL);
x86_l_1ac:
	/* 0x1ac: mov    r11d,0x44 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 68ULL);
x86_l_1b2:
	/* 0x1b2: jmp    21c <tracee_http_method_prefix_detect_xdp+0x21c> */
	X86_SIM_X86_JMP(0x1b2, 0x21c, x86_l_21c);
x86_l_1b4:
	/* 0x1b4: mov    r8d,0x55 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 85ULL);
x86_l_1ba:
	/* 0x1ba: cmp    BYTE PTR [rdx-0x4],0x54 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744056529682516ULL);
x86_l_1be:
	/* 0x1be: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1be, 0x20c, x86_l_20c);
x86_l_1c0:
	/* 0x1c0: mov    r10d,0x55 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 85ULL);
x86_l_1c6:
	/* 0x1c6: cmp    BYTE PTR [rdx-0x3],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744060824649760ULL);
x86_l_1ca:
	/* 0x1ca: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ca, 0x20c, x86_l_20c);
x86_l_1cc:
	/* 0x1cc: mov    r9d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 3ULL);
x86_l_1d2:
	/* 0x1d2: mov    r8d,0x54 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 84ULL);
x86_l_1d8:
	/* 0x1d8: mov    r11d,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 32ULL);
x86_l_1de:
	/* 0x1de: jmp    21c <tracee_http_method_prefix_detect_xdp+0x21c> */
	X86_SIM_X86_JMP(0x1de, 0x21c, x86_l_21c);
x86_l_1e0:
	/* 0x1e0: mov    r8d,0x54 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 84ULL);
x86_l_1e6:
	/* 0x1e6: cmp    BYTE PTR [rdx-0x4],0x54 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744056529682516ULL);
x86_l_1ea:
	/* 0x1ea: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ea, 0x20c, x86_l_20c);
x86_l_1ec:
	/* 0x1ec: cmp    BYTE PTR [rdx-0x3],0x50 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744060824649808ULL);
x86_l_1f0:
	/* 0x1f0: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f0, 0x20c, x86_l_20c);
x86_l_1f2:
	/* 0x1f2: cmp    BYTE PTR [rdx-0x2],0x2f */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617071ULL);
x86_l_1f6:
	/* 0x1f6: jne    20c <tracee_http_method_prefix_detect_xdp+0x20c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f6, 0x20c, x86_l_20c);
x86_l_1f8:
	/* 0x1f8: mov    r9d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 6ULL);
x86_l_1fe:
	/* 0x1fe: mov    r11d,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 80ULL);
x86_l_204:
	/* 0x204: mov    r10d,0x54 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 84ULL);
x86_l_20a:
	/* 0x20a: jmp    21c <tracee_http_method_prefix_detect_xdp+0x21c> */
	X86_SIM_X86_JMP(0x20a, 0x21c, x86_l_21c);
x86_l_20c:
	/* 0x20c: mov    r10d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_R8, X86_WIDTH_32);
x86_l_20f:
	/* 0x20f: movzx  r8d,BYTE PTR [rdx-0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551612ULL);
x86_l_214:
	/* 0x214: movzx  r11d,BYTE PTR [rdx-0x3] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551613ULL);
x86_l_219:
	/* 0x219: xor    r9d,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR);
x86_l_21c:
	/* 0x21c: movzx  r11d,r11b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_WIDTH_8);
x86_l_220:
	/* 0x220: lea    ebx,[r9+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_224:
	/* 0x224: lea    r14,[rax+0xa] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 10ULL);
x86_l_228:
	/* 0x228: imul   rbx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_IMUL);
x86_l_22c:
	/* 0x22c: add    rsi,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_22f:
	/* 0x22f: shl    r11,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_233:
	/* 0x233: movzx  r8d,r8b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_WIDTH_8);
x86_l_237:
	/* 0x237: shl    r8d,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_SHL, 24ULL);
x86_l_23b:
	/* 0x23b: movzx  r10d,r10b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_WIDTH_8);
x86_l_23f:
	/* 0x23f: shl    r10d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_243:
	/* 0x243: shl    edi,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_246:
	/* 0x246: or     edi,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R10, X86_WIDTH_32, X86_ALU_OR);
x86_l_249:
	/* 0x249: or     edi,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_OR);
x86_l_24c:
	/* 0x24c: or     rdi,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R11, X86_WIDTH_64, X86_ALU_OR);
x86_l_24f:
	/* 0x24f: mov    r8d,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R9, X86_WIDTH_32);
x86_l_252:
	/* 0x252: or     r8,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_255:
	/* 0x255: shlx   rbx,r8,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RBX, X86_R8, X86_WIDTH_64, X86_RAX, X86_ALU_SHL);
x86_l_25a:
	/* 0x25a: xor    rbx,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RSI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_25d:
	/* 0x25d: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_261:
	/* 0x261: inc    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_264:
	/* 0x264: cmp    rax,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 9ULL);
x86_l_268:
	/* 0x268: jne    4d <tracee_http_method_prefix_detect_xdp+0x4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x268, 0x4d, x86_l_4d);
x86_l_26e:
	/* 0x26e: mov    BYTE PTR [rcx],sil */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_271:
	/* 0x271: mov    BYTE PTR [rcx+0x1],bh */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RBX, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_REG_AUX_SRC_SHIFT(8)), 1ULL);
x86_l_274:
	/* 0x274: mov    eax,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_32);
x86_l_276:
	/* 0x276: shr    eax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_279:
	/* 0x279: mov    BYTE PTR [rcx+0x2],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_27c:
	/* 0x27c: mov    eax,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_32);
x86_l_27e:
	/* 0x27e: shr    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_281:
	/* 0x281: mov    BYTE PTR [rcx+0x3],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_284:
	/* 0x284: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_287:
	/* 0x287: shr    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_28b:
	/* 0x28b: mov    BYTE PTR [rcx+0x4],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_28e:
	/* 0x28e: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_291:
	/* 0x291: shr    rax,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 40ULL);
x86_l_295:
	/* 0x295: mov    BYTE PTR [rcx+0x5],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_298:
	/* 0x298: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_29b:
	/* 0x29b: shr    rax,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 48ULL);
x86_l_29f:
	/* 0x29f: mov    BYTE PTR [rcx+0x6],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_2a2:
	/* 0x2a2: shr    rbx,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_2a6:
	/* 0x2a6: mov    BYTE PTR [rcx+0x7],bl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RBX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_2a9:
	/* 0x2a9: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2ae:
	/* 0x2ae: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2af:
	/* 0x2af: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2b1:
	/* 0x2b1: jmp    2b6 <tracee_http_method_prefix_detect_xdp+0x2b6> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2b6:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
