#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("tracepoint/native/startup")
int bcc_trace_read_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: lea    rdi,[rsp-0x7] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551609ULL);
x86_l_6:
	/* 0x6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_b:
	/* 0xb: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d:
	/* 0xd: call   12 <bpf_main+0x12> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_probe_read_kernel);
x86_l_12:
	/* 0x12: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_13:
	/* 0x13: jmp    18 <bpf_main+0x18> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_18:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
