
/workspaces/repository/corpus/results/kprog_app_coverage_20261106/ret-after/outer_ret_zero.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 04 24 00 00 00 00                         	mov    QWORD PTR [rsp],0x0
   8:	b8 02 00 00 00                                  	mov    eax,0x2
   d:	c3                                              	ret
