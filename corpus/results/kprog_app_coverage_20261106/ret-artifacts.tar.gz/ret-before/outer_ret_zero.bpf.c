#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_ENABLE_STACK_DEEP 1
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/ret-before/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int outer_ret_zero_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    QWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8:
	/* 0x8: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_d:
	/* 0xd: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
