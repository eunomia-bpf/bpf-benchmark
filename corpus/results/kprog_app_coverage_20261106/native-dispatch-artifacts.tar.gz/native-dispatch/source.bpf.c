#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int dispatch_source(struct xdp_md *ctx) {
    unsigned char *data=(void *)(long)ctx->data,*end=(void *)(long)ctx->data_end;
    if(data+9>end) return 0;
    int which=data[8]!=0;
#ifdef INVERT
    which=!which;
#endif
    if(which) { bpf_get_current_uid_gid(); return
#ifdef GOT_RESULT
      2;
#else
      15;
#endif
    }
    bpf_get_current_pid_tgid(); return
#ifdef GOT_RESULT
      2;
#else
      14;
#endif
}
char LICENSE[] SEC("license")="GPL";
