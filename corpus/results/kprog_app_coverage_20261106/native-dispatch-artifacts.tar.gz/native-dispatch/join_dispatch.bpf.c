#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

SEC("xdp")
int join_dispatch_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4:
	/* 0x4: mov    rcx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8:
	/* 0x8: lea    rax,[rdx+0x9] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 9ULL);
x86_l_c:
	/* 0xc: cmp    rax,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_f:
	/* 0xf: ja     2d <join_dispatch_native+0x2d> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf, 0x2d, x86_l_2d);
x86_l_11:
	/* 0x11: cmp    BYTE PTR [rdx+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_15:
	/* 0x15: jne    1e <join_dispatch_native+0x1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15, 0x1e, x86_l_1e);
x86_l_17:
	/* 0x17: mov    ebx,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 14ULL);
x86_l_1c:
	/* 0x1c: jmp    23 <join_dispatch_native+0x23> */
	X86_SIM_X86_JMP(0x1c, 0x23, x86_l_23);
x86_l_1e:
	/* 0x1e: mov    ebx,0xf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 15ULL);
x86_l_23:
	/* 0x23: call   rbx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RBX);
		switch (X86_SIM_L_REG_TAG(X86_RBX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			case 0xfULL: X86_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			case 0xfULL: X86_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25:
	/* 0x25: mov    eax,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_32);
x86_l_27:
	/* 0x27: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28:
	/* 0x28: jmp    38 <join_dispatch_native+0x38> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2d:
	/* 0x2d: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_32:
	/* 0x32: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_33:
	/* 0x33: jmp    38 <join_dispatch_native+0x38> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_38:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
