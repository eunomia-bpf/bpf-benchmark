#include <stdint.h>
#include <stdio.h>
struct context { void *data,*end; };
unsigned called;
uint64_t host_pid(void) { called=14; return 47; }
uint64_t host_uid(void) { called=15; return 83; }
extern unsigned join_dispatch_blob(struct context *),cmov_dispatch_blob(struct context *);
extern unsigned got_dispatch_blob(struct context *);
int main(void) {
    unsigned char packet[9]={};
    struct context ctx={packet,packet+9};
    for(unsigned bit=0;bit<2;bit++) {
        packet[8]=bit;
        unsigned a=join_dispatch_blob(&ctx),ac=called;
        unsigned b=cmov_dispatch_blob(&ctx),bc=called;
        unsigned c=got_dispatch_blob(&ctx),cc=called;
        printf("input=%u join=%u called=%u cmov=%u called=%u got=%u called=%u\n",bit,a,ac,b,bc,c,cc);
        if(a!=14+bit || ac!=a || b!=15-bit || bc!=b || c!=2 || cc!=14+bit) return 1;
    }
    return 0;
}
