extern char addr4lpm_maps;
extern char addr6lpm_maps;
extern char argfilter_maps;
extern char fexit_calls;
extern char filter_map;
extern char heap_ro_zero;
extern char process_call_heap;
extern char retprobe_map;
extern char string_maps_0;
extern char string_maps_1;
extern char string_maps_10;
extern char string_maps_2;
extern char string_maps_3;
extern char string_maps_4;
extern char string_maps_5;
extern char string_maps_6;
extern char string_maps_7;
extern char string_maps_8;
extern char string_maps_9;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char string_prefix_maps_heap;
extern char substring_map;
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_ENABLE_STACK_DEEP 1
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/baseline/simulator/x86/x86_sim_local_bpf.h"

SEC("xdp")
int tetragon_bpf_generic_fexit_v511_generic_fexit_filter_arg_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH(X86_RBP);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH(X86_R15);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH(X86_R14);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_L_EXEC_PUSH(X86_R13);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_L_EXEC_PUSH(X86_R12);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH(X86_RBX);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x9c],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&process_call_heap));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x9c] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_2e:
	/* 0x2e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_33:
	/* 0x33: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_35:
	/* 0x35: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_38:
	/* 0x38: je     187 <generic_fexit_filter_arg+0x187> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38, 0x187, x86_l_187);
x86_l_3e:
	/* 0x3e: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_41:
	/* 0x41: mov    r15d,DWORD PTR [rax+0x5f00] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_48:
	/* 0x48: lea    rsi,[rax+0x5ef8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_4f:
	/* 0x4f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_map));
x86_l_56:
	/* 0x56: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5b:
	/* 0x5b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5d:
	/* 0x5d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_60:
	/* 0x60: je     16c <generic_fexit_filter_arg+0x16c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60, 0x16c, x86_l_16c);
x86_l_66:
	/* 0x66: cmp    BYTE PTR [r14+0x5ee0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104316165685248ULL);
x86_l_6e:
	/* 0x6e: je     16c <generic_fexit_filter_arg+0x16c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e, 0x16c, x86_l_16c);
x86_l_74:
	/* 0x74: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_77:
	/* 0x77: mov    QWORD PTR [rsp+0xa8],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_7f:
	/* 0x7f: mov    eax,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_32);
x86_l_82:
	/* 0x82: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_85:
	/* 0x85: cmp    BYTE PTR [r14+rax*1+0x5ec1],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 104183021699072ULL);
x86_l_8e:
	/* 0x8e: je     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e, 0xc2, x86_l_c2);
x86_l_90:
	/* 0x90: mov    eax,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_92:
	/* 0x92: mov    ecx,DWORD PTR [rdi+rax*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_96:
	/* 0x96: lea    r11,[rcx+rax*4] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_9a:
	/* 0x9a: add    r11,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_9e:
	/* 0x9e: mov    r9d,r11d */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R11, X86_WIDTH_32);
x86_l_a1:
	/* 0xa1: and    r9d,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_a8:
	/* 0xa8: cmp    DWORD PTR [rdi+r9*1],0x19 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 25ULL);
x86_l_ad:
	/* 0xad: jae    116 <generic_fexit_filter_arg+0x116> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xad, 0x116, x86_l_116);
x86_l_af:
	/* 0xaf: cmp    r9,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_64, 1ULL);
x86_l_b3:
	/* 0xb3: je     16c <generic_fexit_filter_arg+0x16c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb3, 0x16c, x86_l_16c);
x86_l_b9:
	/* 0xb9: test   r9d,r9d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32);
x86_l_bc:
	/* 0xbc: jne    14a <generic_fexit_filter_arg+0x14a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbc, 0x14a, x86_l_14a);
x86_l_c2:
	/* 0xc2: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_ca:
	/* 0xca: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_cd:
	/* 0xcd: jg     eb <generic_fexit_filter_arg+0xeb> */
	X86_SIM_X86_JCC(X86_CC_G, 0xcd, 0xeb, x86_l_eb);
x86_l_cf:
	/* 0xcf: cmp    eax,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_d2:
	/* 0xd2: je     19f <generic_fexit_filter_arg+0x19f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd2, 0x19f, x86_l_19f);
x86_l_d8:
	/* 0xd8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_da:
	/* 0xda: je     1ab <generic_fexit_filter_arg+0x1ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda, 0x1ab, x86_l_1ab);
x86_l_e0:
	/* 0xe0: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_e3:
	/* 0xe3: je     1ba <generic_fexit_filter_arg+0x1ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe3, 0x1ba, x86_l_1ba);
x86_l_e9:
	/* 0xe9: jmp    106 <generic_fexit_filter_arg+0x106> */
	X86_SIM_X86_JMP(0xe9, 0x106, x86_l_106);
x86_l_eb:
	/* 0xeb: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_ee:
	/* 0xee: je     1c9 <generic_fexit_filter_arg+0x1c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xee, 0x1c9, x86_l_1c9);
x86_l_f4:
	/* 0xf4: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_f7:
	/* 0xf7: je     1d8 <generic_fexit_filter_arg+0x1d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf7, 0x1d8, x86_l_1d8);
x86_l_fd:
	/* 0xfd: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_100:
	/* 0x100: je     1e7 <generic_fexit_filter_arg+0x1e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x100, 0x1e7, x86_l_1e7);
x86_l_106:
	/* 0x106: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_109:
	/* 0x109: jg     218 <generic_fexit_filter_arg+0x218> */
	X86_SIM_X86_JCC(X86_CC_G, 0x109, 0x218, x86_l_218);
x86_l_10f:
	/* 0x10f: inc    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_111:
	/* 0x111: jmp    1f6 <generic_fexit_filter_arg+0x1f6> */
	X86_SIM_X86_JMP(0x111, 0x1f6, x86_l_1f6);
x86_l_116:
	/* 0x116: lea    rax,[rdi+r9*1] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_11a:
	/* 0x11a: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_122:
	/* 0x122: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_125:
	/* 0x125: lea    rax,[rsp+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_12a:
	/* 0x12a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12f:
	/* 0x12f: mov    QWORD PTR [rsp+0xa0],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_137:
	/* 0x137: mov    QWORD PTR [rsp],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13b:
	/* 0x13b: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_140:
	/* 0x140: mov    QWORD PTR [rsp+0x10],r11 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_145:
	/* 0x145: jmp    287 <generic_fexit_filter_arg+0x287> */
	X86_SIM_X86_JMP(0x145, 0x287, x86_l_287);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [r14+0x5f04],r9d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_151:
	/* 0x151: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&fexit_calls));
x86_l_158:
	/* 0x158: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_15d:
	/* 0x15d: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_162:
	/* 0x162: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_165:
	/* 0x165: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_16a:
	/* 0x16a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_16c:
	/* 0x16c: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&fexit_calls));
x86_l_173:
	/* 0x173: mov    ecx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_178:
	/* 0x178: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_17d:
	/* 0x17d: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_180:
	/* 0x180: mov    edx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_185:
	/* 0x185: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_187:
	/* 0x187: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_189:
	/* 0x189: add    rsp,0xb8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_190:
	/* 0x190: pop    rbx */
	X86_SIM_L_EXEC_POP(X86_RBX, X86_WIDTH_64);
x86_l_191:
	/* 0x191: pop    r12 */
	X86_SIM_L_EXEC_POP(X86_R12, X86_WIDTH_64);
x86_l_193:
	/* 0x193: pop    r13 */
	X86_SIM_L_EXEC_POP(X86_R13, X86_WIDTH_64);
x86_l_195:
	/* 0x195: pop    r14 */
	X86_SIM_L_EXEC_POP(X86_R14, X86_WIDTH_64);
x86_l_197:
	/* 0x197: pop    r15 */
	X86_SIM_L_EXEC_POP(X86_R15, X86_WIDTH_64);
x86_l_199:
	/* 0x199: pop    rbp */
	X86_SIM_L_EXEC_POP(X86_RBP, X86_WIDTH_64);
x86_l_19a:
	/* 0x19a: jmp    366d <native_bpf_strncasestr+0x72> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_19f:
	/* 0x19f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1a1:
	/* 0x1a1: cmp    BYTE PTR [r14+0x5ec1],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104183021699072ULL);
x86_l_1a9:
	/* 0x1a9: jne    1f6 <generic_fexit_filter_arg+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a9, 0x1f6, x86_l_1f6);
x86_l_1ab:
	/* 0x1ab: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1b0:
	/* 0x1b0: cmp    BYTE PTR [r14+0x5ec2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104187316666368ULL);
x86_l_1b8:
	/* 0x1b8: jne    1f6 <generic_fexit_filter_arg+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b8, 0x1f6, x86_l_1f6);
x86_l_1ba:
	/* 0x1ba: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1bf:
	/* 0x1bf: cmp    BYTE PTR [r14+0x5ec3],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104191611633664ULL);
x86_l_1c7:
	/* 0x1c7: jne    1f6 <generic_fexit_filter_arg+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c7, 0x1f6, x86_l_1f6);
x86_l_1c9:
	/* 0x1c9: mov    eax,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_1ce:
	/* 0x1ce: cmp    BYTE PTR [r14+0x5ec4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104195906600960ULL);
x86_l_1d6:
	/* 0x1d6: jne    1f6 <generic_fexit_filter_arg+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d6, 0x1f6, x86_l_1f6);
x86_l_1d8:
	/* 0x1d8: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1dd:
	/* 0x1dd: cmp    BYTE PTR [r14+0x5ec5],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104200201568256ULL);
x86_l_1e5:
	/* 0x1e5: jne    1f6 <generic_fexit_filter_arg+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e5, 0x1f6, x86_l_1f6);
x86_l_1e7:
	/* 0x1e7: mov    eax,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 5ULL);
x86_l_1ec:
	/* 0x1ec: cmp    BYTE PTR [r14+0x5ec6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104204496535552ULL);
x86_l_1f4:
	/* 0x1f4: je     218 <generic_fexit_filter_arg+0x218> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f4, 0x218, x86_l_218);
x86_l_1f6:
	/* 0x1f6: mov    DWORD PTR [r14+0x5f00],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_1fd:
	/* 0x1fd: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&fexit_calls));
x86_l_204:
	/* 0x204: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_209:
	/* 0x209: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_20e:
	/* 0x20e: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_211:
	/* 0x211: mov    edx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_216:
	/* 0x216: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_218:
	/* 0x218: mov    rbx,QWORD PTR [r14+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_21c:
	/* 0x21c: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_221:
	/* 0x221: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_223:
	/* 0x223: mov    QWORD PTR [rsp+0x38],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_228:
	/* 0x228: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_22d:
	/* 0x22d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&retprobe_map));
x86_l_234:
	/* 0x234: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_239:
	/* 0x239: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_23e:
	/* 0x23e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_240:
	/* 0x240: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_243:
	/* 0x243: je     187 <generic_fexit_filter_arg+0x187> */
	X86_SIM_X86_JCC(X86_CC_E, 0x243, 0x187, x86_l_187);
x86_l_249:
	/* 0x249: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&retprobe_map));
x86_l_250:
	/* 0x250: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_255:
	/* 0x255: mov    eax,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_25a:
	/* 0x25a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_25c:
	/* 0x25c: jmp    187 <generic_fexit_filter_arg+0x187> */
	X86_SIM_X86_JMP(0x25c, 0x187, x86_l_187);
x86_l_261:
	/* 0x261: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_263:
	/* 0x263: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_266:
	/* 0x266: sete   bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_E);
x86_l_269:
	/* 0x269: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
x86_l_26c:
	/* 0x26c: mov    rbx,QWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_274:
	/* 0x274: je     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x274, 0xc2, x86_l_c2);
x86_l_27a:
	/* 0x27a: inc    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_27d:
	/* 0x27d: cmp    r15,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_64, 5ULL);
x86_l_281:
	/* 0x281: je     af <generic_fexit_filter_arg+0xaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281, 0xaf, x86_l_af);
x86_l_287:
	/* 0x287: mov    rax,QWORD PTR [rsp+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_28f:
	/* 0x28f: mov    r12d,DWORD PTR [rax+r15*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 4ULL);
x86_l_294:
	/* 0x294: test   r12d,0x3ff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R12, X86_WIDTH_32, 1023ULL);
x86_l_29b:
	/* 0x29b: je     af <generic_fexit_filter_arg+0xaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29b, 0xaf, x86_l_af);
x86_l_2a1:
	/* 0x2a1: add    r12d,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R11, X86_WIDTH_32, X86_ALU_ADD);
x86_l_2a4:
	/* 0x2a4: and    r12d,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_2ab:
	/* 0x2ab: mov    eax,DWORD PTR [rdi+r12*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R12, 0), 4ULL);
x86_l_2b0:
	/* 0x2b0: cmp    eax,0x23 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_2b3:
	/* 0x2b3: je     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b3, 0xc2, x86_l_c2);
x86_l_2b9:
	/* 0x2b9: add    r12,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2bc:
	/* 0x2bc: mov    ecx,DWORD PTR [r12] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c0:
	/* 0x2c0: cmp    rcx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 4ULL);
x86_l_2c4:
	/* 0x2c4: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c4, 0xc2, x86_l_c2);
x86_l_2ca:
	/* 0x2ca: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_2d3:
	/* 0x2d3: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d3, 0xc2, x86_l_c2);
x86_l_2d9:
	/* 0x2d9: mov    rcx,QWORD PTR [r14+rcx*8+0x5e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 3), 24184ULL);
x86_l_2e1:
	/* 0x2e1: and    ecx,0x7ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_2e7:
	/* 0x2e7: lea    r13,[r14+rcx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2eb:
	/* 0x2eb: add    r13,0x90 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2f2:
	/* 0x2f2: mov    ecx,DWORD PTR [r12+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2f7:
	/* 0x2f7: cmp    ecx,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 27ULL);
x86_l_2fa:
	/* 0x2fa: jle    31b <generic_fexit_filter_arg+0x31b> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2fa, 0x31b, x86_l_31b);
x86_l_2fc:
	/* 0x2fc: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_2ff:
	/* 0x2ff: jg     346 <generic_fexit_filter_arg+0x346> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2ff, 0x346, x86_l_346);
x86_l_301:
	/* 0x301: lea    edx,[rcx-0x1c] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551588ULL);
x86_l_304:
	/* 0x304: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_307:
	/* 0x307: jb     38c <generic_fexit_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x307, 0x38c, x86_l_38c);
x86_l_30d:
	/* 0x30d: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_310:
	/* 0x310: je     5af <generic_fexit_filter_arg+0x5af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x310, 0x5af, x86_l_5af);
x86_l_316:
	/* 0x316: jmp    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JMP(0x316, 0x27a, x86_l_27a);
x86_l_31b:
	/* 0x31b: cmp    ecx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_31e:
	/* 0x31e: jle    36c <generic_fexit_filter_arg+0x36c> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x31e, 0x36c, x86_l_36c);
x86_l_320:
	/* 0x320: lea    edx,[rcx-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_323:
	/* 0x323: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_326:
	/* 0x326: jb     38c <generic_fexit_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x326, 0x38c, x86_l_38c);
x86_l_328:
	/* 0x328: lea    edx,[rcx-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_32b:
	/* 0x32b: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_32e:
	/* 0x32e: jb     5af <generic_fexit_filter_arg+0x5af> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32e, 0x5af, x86_l_5af);
x86_l_334:
	/* 0x334: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_337:
	/* 0x337: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x337, 0x27a, x86_l_27a);
x86_l_33d:
	/* 0x33d: add    r13,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_341:
	/* 0x341: jmp    5af <generic_fexit_filter_arg+0x5af> */
	X86_SIM_X86_JMP(0x341, 0x5af, x86_l_5af);
x86_l_346:
	/* 0x346: cmp    ecx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 41ULL);
x86_l_349:
	/* 0x349: jg     50d <generic_fexit_filter_arg+0x50d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x349, 0x50d, x86_l_50d);
x86_l_34f:
	/* 0x34f: lea    edx,[rcx-0x26] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_352:
	/* 0x352: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_355:
	/* 0x355: jb     4a8 <generic_fexit_filter_arg+0x4a8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x355, 0x4a8, x86_l_4a8);
x86_l_35b:
	/* 0x35b: lea    edx,[rcx-0x28] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551576ULL);
x86_l_35e:
	/* 0x35e: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_361:
	/* 0x361: jb     453 <generic_fexit_filter_arg+0x453> */
	X86_SIM_X86_JCC(X86_CC_B, 0x361, 0x453, x86_l_453);
x86_l_367:
	/* 0x367: jmp    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JMP(0x367, 0x27a, x86_l_27a);
x86_l_36c:
	/* 0x36c: cmp    ecx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_36f:
	/* 0x36f: jg     440 <generic_fexit_filter_arg+0x440> */
	X86_SIM_X86_JCC(X86_CC_G, 0x36f, 0x440, x86_l_440);
x86_l_375:
	/* 0x375: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_378:
	/* 0x378: je     38c <generic_fexit_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x378, 0x38c, x86_l_38c);
x86_l_37a:
	/* 0x37a: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_37d:
	/* 0x37d: je     b42 <generic_fexit_filter_arg+0xb42> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37d, 0xb42, x86_l_b42);
x86_l_383:
	/* 0x383: cmp    ecx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_386:
	/* 0x386: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x386, 0x27a, x86_l_27a);
x86_l_38c:
	/* 0x38c: cmp    ecx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 11ULL);
x86_l_38f:
	/* 0x38f: jle    41d <generic_fexit_filter_arg+0x41d> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x38f, 0x41d, x86_l_41d);
x86_l_395:
	/* 0x395: cmp    ecx,0x24 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 36ULL);
x86_l_398:
	/* 0x398: ja     6d7 <generic_fexit_filter_arg+0x6d7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x398, 0x6d7, x86_l_6d7);
x86_l_39e:
	/* 0x39e: mov    edx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_3a0:
	/* 0x3a0: movabs rsi,0x1e00000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_64, 128849018880ULL);
x86_l_3aa:
	/* 0x3aa: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_3ae:
	/* 0x3ae: jb     4e1 <generic_fexit_filter_arg+0x4e1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3ae, 0x4e1, x86_l_4e1);
x86_l_3b4:
	/* 0x3b4: mov    esi,0x60000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1610612736ULL);
x86_l_3b9:
	/* 0x3b9: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_3bd:
	/* 0x3bd: jb     918 <generic_fexit_filter_arg+0x918> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3bd, 0x918, x86_l_918);
x86_l_3c3:
	/* 0x3c3: movabs rsi,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_64, 6442450944ULL);
x86_l_3cd:
	/* 0x3cd: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_3d1:
	/* 0x3d1: jae    6d7 <generic_fexit_filter_arg+0x6d7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3d1, 0x6d7, x86_l_6d7);
x86_l_3d7:
	/* 0x3d7: cmp    eax,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_3da:
	/* 0x3da: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3da, 0xc2, x86_l_c2);
x86_l_3e0:
	/* 0x3e0: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_3e2:
	/* 0x3e2: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_3e7:
	/* 0x3e7: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_3eb:
	/* 0x3eb: jae    105e <generic_fexit_filter_arg+0x105e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3eb, 0x105e, x86_l_105e);
x86_l_3f1:
	/* 0x3f1: mov    ecx,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f6:
	/* 0x3f6: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3f9:
	/* 0x3f9: jle    15b3 <generic_fexit_filter_arg+0x15b3> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3f9, 0x15b3, x86_l_15b3);
x86_l_3ff:
	/* 0x3ff: lea    edx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_402:
	/* 0x402: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_405:
	/* 0x405: jae    1d2d <generic_fexit_filter_arg+0x1d2d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x405, 0x1d2d, x86_l_1d2d);
x86_l_40b:
	/* 0x40b: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_410:
	/* 0x410: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_412:
	/* 0x412: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x412, 0x261, x86_l_261);
x86_l_418:
	/* 0x418: jmp    1e54 <generic_fexit_filter_arg+0x1e54> */
	X86_SIM_X86_JMP(0x418, 0x1e54, x86_l_1e54);
x86_l_41d:
	/* 0x41d: lea    edx,[rcx-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_420:
	/* 0x420: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_423:
	/* 0x423: jb     bc1 <generic_fexit_filter_arg+0xbc1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x423, 0xbc1, x86_l_bc1);
x86_l_429:
	/* 0x429: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_42c:
	/* 0x42c: je     6e3 <generic_fexit_filter_arg+0x6e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42c, 0x6e3, x86_l_6e3);
x86_l_432:
	/* 0x432: cmp    ecx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_435:
	/* 0x435: je     6e3 <generic_fexit_filter_arg+0x6e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x435, 0x6e3, x86_l_6e3);
x86_l_43b:
	/* 0x43b: jmp    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JMP(0x43b, 0x27a, x86_l_27a);
x86_l_440:
	/* 0x440: cmp    ecx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_443:
	/* 0x443: je     453 <generic_fexit_filter_arg+0x453> */
	X86_SIM_X86_JCC(X86_CC_E, 0x443, 0x453, x86_l_453);
x86_l_445:
	/* 0x445: cmp    ecx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_448:
	/* 0x448: je     4a8 <generic_fexit_filter_arg+0x4a8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x448, 0x4a8, x86_l_4a8);
x86_l_44a:
	/* 0x44a: cmp    ecx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_44d:
	/* 0x44d: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44d, 0x27a, x86_l_27a);
x86_l_453:
	/* 0x453: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_45c:
	/* 0x45c: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_465:
	/* 0x465: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_46e:
	/* 0x46e: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_477:
	/* 0x477: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_480:
	/* 0x480: cmp    ecx,0x27 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 39ULL);
x86_l_483:
	/* 0x483: jg     722 <generic_fexit_filter_arg+0x722> */
	X86_SIM_X86_JCC(X86_CC_G, 0x483, 0x722, x86_l_722);
x86_l_489:
	/* 0x489: cmp    ecx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_48c:
	/* 0x48c: je     d23 <generic_fexit_filter_arg+0xd23> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48c, 0xd23, x86_l_d23);
x86_l_492:
	/* 0x492: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_495:
	/* 0x495: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_49a:
	/* 0x49a: cmp    ecx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_49d:
	/* 0x49d: je     d25 <generic_fexit_filter_arg+0xd25> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49d, 0xd25, x86_l_d25);
x86_l_4a3:
	/* 0x4a3: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x4a3, 0x269, x86_l_269);
x86_l_4a8:
	/* 0x4a8: mov    ebp,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ac:
	/* 0x4ac: add    r13,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4b0:
	/* 0x4b0: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_4b3:
	/* 0x4b3: jg     7a7 <generic_fexit_filter_arg+0x7a7> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4b3, 0x7a7, x86_l_7a7);
x86_l_4b9:
	/* 0x4b9: lea    ecx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_4bc:
	/* 0x4bc: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_4bf:
	/* 0x4bf: jb     f7c <generic_fexit_filter_arg+0xf7c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4bf, 0xf7c, x86_l_f7c);
x86_l_4c5:
	/* 0x4c5: cmp    eax,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_4c8:
	/* 0x4c8: je     ee5 <generic_fexit_filter_arg+0xee5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c8, 0xee5, x86_l_ee5);
x86_l_4ce:
	/* 0x4ce: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_4d3:
	/* 0x4d3: cmp    eax,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 9ULL);
x86_l_4d6:
	/* 0x4d6: je     7c7 <generic_fexit_filter_arg+0x7c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d6, 0x7c7, x86_l_7c7);
x86_l_4dc:
	/* 0x4dc: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x4dc, 0x358b, x86_l_358b);
x86_l_4e1:
	/* 0x4e1: cmp    eax,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 9ULL);
x86_l_4e4:
	/* 0x4e4: jle    b31 <generic_fexit_filter_arg+0xb31> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4e4, 0xb31, x86_l_b31);
x86_l_4ea:
	/* 0x4ea: cmp    eax,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 29ULL);
x86_l_4ed:
	/* 0x4ed: jg     e9d <generic_fexit_filter_arg+0xe9d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4ed, 0xe9d, x86_l_e9d);
x86_l_4f3:
	/* 0x4f3: lea    edx,[rax-0xa] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_4f6:
	/* 0x4f6: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_4f9:
	/* 0x4f9: jb     c4f <generic_fexit_filter_arg+0xc4f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4f9, 0xc4f, x86_l_c4f);
x86_l_4ff:
	/* 0x4ff: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_502:
	/* 0x502: je     bd7 <generic_fexit_filter_arg+0xbd7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x502, 0xbd7, x86_l_bd7);
x86_l_508:
	/* 0x508: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x508, 0xc2, x86_l_c2);
x86_l_50d:
	/* 0x50d: cmp    ecx,0x2a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 42ULL);
x86_l_510:
	/* 0x510: je     5af <generic_fexit_filter_arg+0x5af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x510, 0x5af, x86_l_5af);
x86_l_516:
	/* 0x516: cmp    ecx,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 44ULL);
x86_l_519:
	/* 0x519: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x519, 0x27a, x86_l_27a);
x86_l_51f:
	/* 0x51f: lea    rsi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_523:
	/* 0x523: movzx  r8d,BYTE PTR [r13+0x3] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_528:
	/* 0x528: movzx  ebp,r8b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RBP, X86_R8, X86_WIDTH_32, X86_WIDTH_8);
x86_l_52c:
	/* 0x52c: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_52f:
	/* 0x52f: jg     1340 <generic_fexit_filter_arg+0x1340> */
	X86_SIM_X86_JCC(X86_CC_G, 0x52f, 0x1340, x86_l_1340);
x86_l_535:
	/* 0x535: lea    ecx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_538:
	/* 0x538: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_53b:
	/* 0x53b: jae    18ad <generic_fexit_filter_arg+0x18ad> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x53b, 0x18ad, x86_l_18ad);
x86_l_541:
	/* 0x541: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_549:
	/* 0x549: mov    r10d,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 256ULL);
x86_l_54f:
	/* 0x54f: cmp    bpl,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_8, 144ULL);
x86_l_553:
	/* 0x553: ja     167f <generic_fexit_filter_arg+0x167f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x553, 0x167f, x86_l_167f);
x86_l_559:
	/* 0x559: movzx  eax,r8b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_WIDTH_8);
x86_l_55d:
	/* 0x55d: imul   eax,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RAX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_563:
	/* 0x563: shr    eax,0x9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_566:
	/* 0x566: and    eax,0xfffffff8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_569:
	/* 0x569: lea    ecx,[rax+rax*2] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_56c:
	/* 0x56c: mov    eax,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R8, X86_WIDTH_32);
x86_l_56f:
	/* 0x56f: sub    al,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_571:
	/* 0x571: test   r8b,r8b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_8);
x86_l_574:
	/* 0x574: je     57d <generic_fexit_filter_arg+0x57d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x574, 0x57d, x86_l_57d);
x86_l_576:
	/* 0x576: mov    r10d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RBP, X86_WIDTH_32);
x86_l_579:
	/* 0x579: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_57b:
	/* 0x57b: je     598 <generic_fexit_filter_arg+0x598> */
	X86_SIM_X86_JCC(X86_CC_E, 0x57b, 0x598, x86_l_598);
x86_l_57d:
	/* 0x57d: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_580:
	/* 0x580: movzx  ecx,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_583:
	/* 0x583: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_585:
	/* 0x585: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_587:
	/* 0x587: add    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_58a:
	/* 0x58a: movzx  r10d,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R10, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_58e:
	/* 0x58e: cmp    cx,0x78 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_16, 120ULL);
x86_l_592:
	/* 0x592: ja     167f <generic_fexit_filter_arg+0x167f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x592, 0x167f, x86_l_167f);
x86_l_598:
	/* 0x598: movzx  eax,r10b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_R10, X86_WIDTH_32, X86_WIDTH_8);
x86_l_59c:
	/* 0x59c: imul   r13d,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R13, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_5a3:
	/* 0x5a3: shr    r13d,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_5a7:
	/* 0x5a7: dec    r13d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_5aa:
	/* 0x5aa: jmp    24ce <generic_fexit_filter_arg+0x24ce> */
	X86_SIM_X86_JMP(0x5aa, 0x24ce, x86_l_24ce);
x86_l_5af:
	/* 0x5af: mov    ebp,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b3:
	/* 0x5b3: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_5b5:
	/* 0x5b5: and    ecx,0xfffffffe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_5b8:
	/* 0x5b8: cmp    ecx,0x24 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 36ULL);
x86_l_5bb:
	/* 0x5bb: je     5c5 <generic_fexit_filter_arg+0x5c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5bb, 0x5c5, x86_l_5c5);
x86_l_5bd:
	/* 0x5bd: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_5bf:
	/* 0x5bf: je     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5bf, 0xc2, x86_l_c2);
x86_l_5c5:
	/* 0x5c5: cmp    eax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 37ULL);
x86_l_5c8:
	/* 0x5c8: ja     8f5 <generic_fexit_filter_arg+0x8f5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5c8, 0x8f5, x86_l_8f5);
x86_l_5ce:
	/* 0x5ce: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_5d0:
	/* 0x5d0: mov    edx,0x4000100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 67109120ULL);
x86_l_5d5:
	/* 0x5d5: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5d9:
	/* 0x5d9: jb     a90 <generic_fexit_filter_arg+0xa90> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5d9, 0xa90, x86_l_a90);
x86_l_5df:
	/* 0x5df: mov    edx,0x8000200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 134218240ULL);
x86_l_5e4:
	/* 0x5e4: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5e8:
	/* 0x5e8: jb     95e <generic_fexit_filter_arg+0x95e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5e8, 0x95e, x86_l_95e);
x86_l_5ee:
	/* 0x5ee: movabs rdx,0x3000000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 206158430208ULL);
x86_l_5f8:
	/* 0x5f8: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_5fc:
	/* 0x5fc: jae    8f5 <generic_fexit_filter_arg+0x8f5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5fc, 0x8f5, x86_l_8f5);
x86_l_602:
	/* 0x602: mov    WORD PTR [rsp+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_609:
	/* 0x609: cmp    ebp,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 4096ULL);
x86_l_60f:
	/* 0x60f: ja     911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_A, 0x60f, 0x911, x86_l_911);
x86_l_615:
	/* 0x615: lea    rcx,[rbp*1+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 8ULL);
x86_l_61d:
	/* 0x61d: add    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
x86_l_620:
	/* 0x620: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_625:
	/* 0x625: lea    rdi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_62a:
	/* 0x62a: mov    edx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_62f:
	/* 0x62f: mov    ecx,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_633:
	/* 0x633: lea    rdx,[rcx+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_637:
	/* 0x637: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_63b:
	/* 0x63b: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_640:
	/* 0x640: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_642:
	/* 0x642: mov    ecx,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_647:
	/* 0x647: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_649:
	/* 0x649: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x649, 0x31df, x86_l_31df);
x86_l_64f:
	/* 0x64f: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_654:
	/* 0x654: and    eax,0xf000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_659:
	/* 0x659: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_65e:
	/* 0x65e: cmp    ecx,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_660:
	/* 0x660: je     31e1 <generic_fexit_filter_arg+0x31e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x660, 0x31e1, x86_l_31e1);
x86_l_666:
	/* 0x666: mov    ecx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_66b:
	/* 0x66b: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_66e:
	/* 0x66e: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_672:
	/* 0x672: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_677:
	/* 0x677: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_67c:
	/* 0x67c: jb     911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_B, 0x67c, 0x911, x86_l_911);
x86_l_682:
	/* 0x682: mov    edx,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_687:
	/* 0x687: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_689:
	/* 0x689: je     911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x689, 0x911, x86_l_911);
x86_l_68f:
	/* 0x68f: cmp    edx,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_691:
	/* 0x691: je     31ef <generic_fexit_filter_arg+0x31ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x691, 0x31ef, x86_l_31ef);
x86_l_697:
	/* 0x697: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_69a:
	/* 0x69a: jb     911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_B, 0x69a, 0x911, x86_l_911);
x86_l_6a0:
	/* 0x6a0: mov    edx,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6a5:
	/* 0x6a5: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_6a7:
	/* 0x6a7: je     911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a7, 0x911, x86_l_911);
x86_l_6ad:
	/* 0x6ad: cmp    edx,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_6af:
	/* 0x6af: je     31ef <generic_fexit_filter_arg+0x31ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6af, 0x31ef, x86_l_31ef);
x86_l_6b5:
	/* 0x6b5: cmp    ecx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 21ULL);
x86_l_6b8:
	/* 0x6b8: jb     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6b8, 0x31df, x86_l_31df);
x86_l_6be:
	/* 0x6be: mov    ecx,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_6c3:
	/* 0x6c3: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_6c5:
	/* 0x6c5: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c5, 0x31df, x86_l_31df);
x86_l_6cb:
	/* 0x6cb: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6cd:
	/* 0x6cd: cmp    ecx,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_6cf:
	/* 0x6cf: sete   bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_E);
x86_l_6d2:
	/* 0x6d2: jmp    31e1 <generic_fexit_filter_arg+0x31e1> */
	X86_SIM_X86_JMP(0x6d2, 0x31e1, x86_l_31e1);
x86_l_6d7:
	/* 0x6d7: lea    edx,[rcx-0xc] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_6da:
	/* 0x6da: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_6dd:
	/* 0x6dd: jae    bb8 <generic_fexit_filter_arg+0xbb8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6dd, 0xbb8, x86_l_bb8);
x86_l_6e3:
	/* 0x6e3: cmp    eax,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_6e6:
	/* 0x6e6: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6e6, 0xc2, x86_l_c2);
x86_l_6ec:
	/* 0x6ec: mov    edx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_6ee:
	/* 0x6ee: mov    esi,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4126ULL);
x86_l_6f3:
	/* 0x6f3: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_6f7:
	/* 0x6f7: jae    741 <generic_fexit_filter_arg+0x741> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6f7, 0x741, x86_l_741);
x86_l_6f9:
	/* 0x6f9: mov    edx,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6fe:
	/* 0x6fe: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_701:
	/* 0x701: jle    b80 <generic_fexit_filter_arg+0xb80> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x701, 0xb80, x86_l_b80);
x86_l_707:
	/* 0x707: lea    esi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_70a:
	/* 0x70a: cmp    esi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_70d:
	/* 0x70d: jae    1046 <generic_fexit_filter_arg+0x1046> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x70d, 0x1046, x86_l_1046);
x86_l_713:
	/* 0x713: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_717:
	/* 0x717: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x717, 0x261, x86_l_261);
x86_l_71d:
	/* 0x71d: jmp    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JMP(0x71d, 0x218e, x86_l_218e);
x86_l_722:
	/* 0x722: cmp    ecx,0x28 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 40ULL);
x86_l_725:
	/* 0x725: je     cf8 <generic_fexit_filter_arg+0xcf8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x725, 0xcf8, x86_l_cf8);
x86_l_72b:
	/* 0x72b: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_72e:
	/* 0x72e: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_733:
	/* 0x733: cmp    ecx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 41ULL);
x86_l_736:
	/* 0x736: je     d25 <generic_fexit_filter_arg+0xd25> */
	X86_SIM_X86_JCC(X86_CC_E, 0x736, 0xd25, x86_l_d25);
x86_l_73c:
	/* 0x73c: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x73c, 0x269, x86_l_269);
x86_l_741:
	/* 0x741: mov    esi,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 3072ULL);
x86_l_746:
	/* 0x746: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_74a:
	/* 0x74a: jb     cb7 <generic_fexit_filter_arg+0xcb7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x74a, 0xcb7, x86_l_cb7);
x86_l_750:
	/* 0x750: movabs rsi,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_64, 6442450944ULL);
x86_l_75a:
	/* 0x75a: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_75e:
	/* 0x75e: jae    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x75e, 0xc2, x86_l_c2);
x86_l_764:
	/* 0x764: cmp    eax,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 31ULL);
x86_l_767:
	/* 0x767: jne    130b <generic_fexit_filter_arg+0x130b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x767, 0x130b, x86_l_130b);
x86_l_76d:
	/* 0x76d: mov    esi,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_772:
	/* 0x772: mov    edx,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_777:
	/* 0x777: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_77a:
	/* 0x77a: ja     1ed5 <generic_fexit_filter_arg+0x1ed5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x77a, 0x1ed5, x86_l_1ed5);
x86_l_780:
	/* 0x780: mov    eax,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 5122ULL);
x86_l_785:
	/* 0x785: bt     eax,ecx */
	X86_SIM_L_EXEC_BT(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_788:
	/* 0x788: jae    1ed5 <generic_fexit_filter_arg+0x1ed5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x788, 0x1ed5, x86_l_1ed5);
x86_l_78e:
	/* 0x78e: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_792:
	/* 0x792: cmp    esi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_32);
x86_l_794:
	/* 0x794: jg     1ee5 <generic_fexit_filter_arg+0x1ee5> */
	X86_SIM_X86_JCC(X86_CC_G, 0x794, 0x1ee5, x86_l_1ee5);
x86_l_79a:
	/* 0x79a: cmp    eax,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32);
x86_l_79c:
	/* 0x79c: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x79c, 0x27a, x86_l_27a);
x86_l_7a2:
	/* 0x7a2: jmp    1ee5 <generic_fexit_filter_arg+0x1ee5> */
	X86_SIM_X86_JMP(0x7a2, 0x1ee5, x86_l_1ee5);
x86_l_7a7:
	/* 0x7a7: cmp    eax,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_7aa:
	/* 0x7aa: jg     da9 <generic_fexit_filter_arg+0xda9> */
	X86_SIM_X86_JCC(X86_CC_G, 0x7aa, 0xda9, x86_l_da9);
x86_l_7b0:
	/* 0x7b0: cmp    eax,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 26ULL);
x86_l_7b3:
	/* 0x7b3: je     ee5 <generic_fexit_filter_arg+0xee5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b3, 0xee5, x86_l_ee5);
x86_l_7b9:
	/* 0x7b9: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_7be:
	/* 0x7be: cmp    eax,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_7c1:
	/* 0x7c1: jne    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7c1, 0x358b, x86_l_358b);
x86_l_7c7:
	/* 0x7c7: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7cc:
	/* 0x7cc: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7d0:
	/* 0x7d0: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_7d8:
	/* 0x7d8: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_7dd:
	/* 0x7dd: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7e2:
	/* 0x7e2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps));
x86_l_7e9:
	/* 0x7e9: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_7eb:
	/* 0x7eb: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_7ed:
	/* 0x7ed: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7ed, 0x357b, x86_l_357b);
x86_l_7f3:
	/* 0x7f3: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_7f8:
	/* 0x7f8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_7fb:
	/* 0x7fb: je     357d <generic_fexit_filter_arg+0x357d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7fb, 0x357d, x86_l_357d);
x86_l_801:
	/* 0x801: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_806:
	/* 0x806: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_80b:
	/* 0x80b: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_810:
	/* 0x810: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap));
x86_l_817:
	/* 0x817: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_819:
	/* 0x819: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_81c:
	/* 0x81c: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x81c, 0x357b, x86_l_357b);
x86_l_822:
	/* 0x822: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_825:
	/* 0x825: cmp    ebp,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 127ULL);
x86_l_828:
	/* 0x828: mov    eax,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 127ULL);
x86_l_82d:
	/* 0x82d: cmovb  eax,ebp */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RBP, X86_WIDTH_32, X86_CC_B);
x86_l_830:
	/* 0x830: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_833:
	/* 0x833: mov    DWORD PTR [rdi],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_835:
	/* 0x835: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_838:
	/* 0x838: neg    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_83b:
	/* 0x83b: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_840:
	/* 0x840: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_843:
	/* 0x843: lea    edx,[rbp-0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_846:
	/* 0x846: mov    QWORD PTR [rsp+0x68],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_84b:
	/* 0x84b: add    rdi,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_84f:
	/* 0x84f: mov    r8d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 2ULL);
x86_l_855:
	/* 0x855: sub    r8,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_858:
	/* 0x858: lea    r9d,[rbp-0x3] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_85c:
	/* 0x85c: mov    r10d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 1ULL);
x86_l_862:
	/* 0x862: sub    r10,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_865:
	/* 0x865: lea    r11d,[rbp-0x2] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_869:
	/* 0x869: dec    ebp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_86b:
	/* 0x86b: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_86d:
	/* 0x86d: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_870:
	/* 0x870: lea    r13d,[rbx+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_874:
	/* 0x874: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_87b:
	/* 0x87b: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_880:
	/* 0x880: mov    BYTE PTR [rdi-0x3],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_884:
	/* 0x884: cmp    r10,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R10, X86_RBX, X86_WIDTH_64);
x86_l_887:
	/* 0x887: je     8e1 <generic_fexit_filter_arg+0x8e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x887, 0x8e1, x86_l_8e1);
x86_l_889:
	/* 0x889: lea    r13d,[r11+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R11, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_88d:
	/* 0x88d: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_894:
	/* 0x894: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_899:
	/* 0x899: mov    BYTE PTR [rdi-0x2],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_89d:
	/* 0x89d: cmp    r8,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RBX, X86_WIDTH_64);
x86_l_8a0:
	/* 0x8a0: je     8e1 <generic_fexit_filter_arg+0x8e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a0, 0x8e1, x86_l_8e1);
x86_l_8a2:
	/* 0x8a2: lea    r13d,[r9+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_8a6:
	/* 0x8a6: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_8ad:
	/* 0x8ad: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_8b2:
	/* 0x8b2: mov    BYTE PTR [rdi-0x1],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_8b6:
	/* 0x8b6: cmp    rcx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_8b9:
	/* 0x8b9: je     8e1 <generic_fexit_filter_arg+0x8e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8b9, 0x8e1, x86_l_8e1);
x86_l_8bb:
	/* 0x8bb: cmp    rbx,0xffffffffffffff84 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551492ULL);
x86_l_8bf:
	/* 0x8bf: je     8e1 <generic_fexit_filter_arg+0x8e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8bf, 0x8e1, x86_l_8e1);
x86_l_8c1:
	/* 0x8c1: lea    r13d,[rdx+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_8c5:
	/* 0x8c5: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_8cc:
	/* 0x8cc: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_8d1:
	/* 0x8d1: mov    BYTE PTR [rdi],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8d4:
	/* 0x8d4: add    rbx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_8d8:
	/* 0x8d8: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_8dc:
	/* 0x8dc: cmp    rax,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_8df:
	/* 0x8df: jne    870 <generic_fexit_filter_arg+0x870> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8df, 0x870, x86_l_870);
x86_l_8e1:
	/* 0x8e1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_8e6:
	/* 0x8e6: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8eb:
	/* 0x8eb: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8f0:
	/* 0x8f0: jmp    1a26 <generic_fexit_filter_arg+0x1a26> */
	X86_SIM_X86_JMP(0x8f0, 0x1a26, x86_l_1a26);
x86_l_8f5:
	/* 0x8f5: add    eax,0xfffffffd */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 4294967293ULL);
x86_l_8f8:
	/* 0x8f8: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_8fb:
	/* 0x8fb: jae    911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x8fb, 0x911, x86_l_911);
x86_l_8fd:
	/* 0x8fd: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_905:
	/* 0x905: cmp    ebp,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 4096ULL);
x86_l_90b:
	/* 0x90b: jbe    1150 <generic_fexit_filter_arg+0x1150> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x90b, 0x1150, x86_l_1150);
x86_l_911:
	/* 0x911: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_913:
	/* 0x913: jmp    31ef <generic_fexit_filter_arg+0x31ef> */
	X86_SIM_X86_JMP(0x913, 0x31ef, x86_l_31ef);
x86_l_918:
	/* 0x918: cmp    eax,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_91b:
	/* 0x91b: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x91b, 0xc2, x86_l_c2);
x86_l_921:
	/* 0x921: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_923:
	/* 0x923: mov    edx,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4126ULL);
x86_l_928:
	/* 0x928: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_92c:
	/* 0x92c: jae    1091 <generic_fexit_filter_arg+0x1091> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x92c, 0x1091, x86_l_1091);
x86_l_932:
	/* 0x932: mov    ecx,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_937:
	/* 0x937: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_93a:
	/* 0x93a: jle    15d7 <generic_fexit_filter_arg+0x15d7> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x93a, 0x15d7, x86_l_15d7);
x86_l_940:
	/* 0x940: lea    edx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_943:
	/* 0x943: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_946:
	/* 0x946: jae    1d48 <generic_fexit_filter_arg+0x1d48> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x946, 0x1d48, x86_l_1d48);
x86_l_94c:
	/* 0x94c: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_951:
	/* 0x951: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_953:
	/* 0x953: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x953, 0x261, x86_l_261);
x86_l_959:
	/* 0x959: jmp    1e9b <generic_fexit_filter_arg+0x1e9b> */
	X86_SIM_X86_JMP(0x959, 0x1e9b, x86_l_1e9b);
x86_l_95e:
	/* 0x95e: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_963:
	/* 0x963: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_967:
	/* 0x967: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_96f:
	/* 0x96f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_974:
	/* 0x974: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_979:
	/* 0x979: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps));
x86_l_980:
	/* 0x980: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_982:
	/* 0x982: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_984:
	/* 0x984: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x984, 0x31df, x86_l_31df);
x86_l_98a:
	/* 0x98a: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_98f:
	/* 0x98f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_992:
	/* 0x992: je     31e1 <generic_fexit_filter_arg+0x31e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x992, 0x31e1, x86_l_31e1);
x86_l_998:
	/* 0x998: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_99d:
	/* 0x99d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_9a2:
	/* 0x9a2: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9a7:
	/* 0x9a7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap));
x86_l_9ae:
	/* 0x9ae: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_9b0:
	/* 0x9b0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_9b3:
	/* 0x9b3: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b3, 0x31df, x86_l_31df);
x86_l_9b9:
	/* 0x9b9: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_9bc:
	/* 0x9bc: cmp    ebp,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 127ULL);
x86_l_9bf:
	/* 0x9bf: mov    eax,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 127ULL);
x86_l_9c4:
	/* 0x9c4: cmovb  eax,ebp */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RBP, X86_WIDTH_32, X86_CC_B);
x86_l_9c7:
	/* 0x9c7: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_9ca:
	/* 0x9ca: mov    DWORD PTR [rdi],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9cc:
	/* 0x9cc: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_9cf:
	/* 0x9cf: neg    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_9d2:
	/* 0x9d2: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_9d7:
	/* 0x9d7: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_9da:
	/* 0x9da: lea    edx,[rbp-0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_9dd:
	/* 0x9dd: mov    QWORD PTR [rsp+0x68],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_9e2:
	/* 0x9e2: add    rdi,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_9e6:
	/* 0x9e6: mov    r8d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 2ULL);
x86_l_9ec:
	/* 0x9ec: sub    r8,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_9ef:
	/* 0x9ef: lea    r9d,[rbp-0x3] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_9f3:
	/* 0x9f3: mov    r10d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 1ULL);
x86_l_9f9:
	/* 0x9f9: sub    r10,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_9fc:
	/* 0x9fc: lea    r11d,[rbp-0x2] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_a00:
	/* 0xa00: dec    ebp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_a02:
	/* 0xa02: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a04:
	/* 0xa04: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_a07:
	/* 0xa07: lea    r13d,[rbx+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_a0b:
	/* 0xa0b: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_a12:
	/* 0xa12: movzx  r13d,BYTE PTR [rsi+r13*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 4ULL);
x86_l_a18:
	/* 0xa18: mov    BYTE PTR [rdi-0x3],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_a1c:
	/* 0xa1c: cmp    r10,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R10, X86_RBX, X86_WIDTH_64);
x86_l_a1f:
	/* 0xa1f: je     a7c <generic_fexit_filter_arg+0xa7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa1f, 0xa7c, x86_l_a7c);
x86_l_a21:
	/* 0xa21: lea    r13d,[r11+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R11, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_a25:
	/* 0xa25: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_a2c:
	/* 0xa2c: movzx  r13d,BYTE PTR [rsi+r13*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 4ULL);
x86_l_a32:
	/* 0xa32: mov    BYTE PTR [rdi-0x2],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_a36:
	/* 0xa36: cmp    r8,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RBX, X86_WIDTH_64);
x86_l_a39:
	/* 0xa39: je     a7c <generic_fexit_filter_arg+0xa7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa39, 0xa7c, x86_l_a7c);
x86_l_a3b:
	/* 0xa3b: lea    r13d,[r9+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_a3f:
	/* 0xa3f: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_a46:
	/* 0xa46: movzx  r13d,BYTE PTR [rsi+r13*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 4ULL);
x86_l_a4c:
	/* 0xa4c: mov    BYTE PTR [rdi-0x1],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_a50:
	/* 0xa50: cmp    rcx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_a53:
	/* 0xa53: je     a7c <generic_fexit_filter_arg+0xa7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa53, 0xa7c, x86_l_a7c);
x86_l_a55:
	/* 0xa55: cmp    rbx,0xffffffffffffff84 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551492ULL);
x86_l_a59:
	/* 0xa59: je     a7c <generic_fexit_filter_arg+0xa7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa59, 0xa7c, x86_l_a7c);
x86_l_a5b:
	/* 0xa5b: lea    r13d,[rdx+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_a5f:
	/* 0xa5f: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_a66:
	/* 0xa66: movzx  r13d,BYTE PTR [rsi+r13*1+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 4ULL);
x86_l_a6c:
	/* 0xa6c: mov    BYTE PTR [rdi],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a6f:
	/* 0xa6f: add    rbx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_a73:
	/* 0xa73: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_a77:
	/* 0xa77: cmp    rax,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_a7a:
	/* 0xa7a: jne    a07 <generic_fexit_filter_arg+0xa07> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa7a, 0xa07, x86_l_a07);
x86_l_a7c:
	/* 0xa7c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_a81:
	/* 0xa81: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a86:
	/* 0xa86: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a8b:
	/* 0xa8b: jmp    31d3 <generic_fexit_filter_arg+0x31d3> */
	X86_SIM_X86_JMP(0xa8b, 0x31d3, x86_l_31d3);
x86_l_a90:
	/* 0xa90: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a95:
	/* 0xa95: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a9a:
	/* 0xa9a: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_a9e:
	/* 0xa9e: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_aa6:
	/* 0xaa6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_aab:
	/* 0xaab: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ab0:
	/* 0xab0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps));
x86_l_ab7:
	/* 0xab7: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_ab9:
	/* 0xab9: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_abb:
	/* 0xabb: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0xabb, 0x31df, x86_l_31df);
x86_l_ac1:
	/* 0xac1: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_ac4:
	/* 0xac4: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_ac9:
	/* 0xac9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_acc:
	/* 0xacc: je     31e1 <generic_fexit_filter_arg+0x31e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xacc, 0x31e1, x86_l_31e1);
x86_l_ad2:
	/* 0xad2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_ad7:
	/* 0xad7: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_adc:
	/* 0xadc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap));
x86_l_ae3:
	/* 0xae3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_ae5:
	/* 0xae5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ae8:
	/* 0xae8: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae8, 0x31df, x86_l_31df);
x86_l_aee:
	/* 0xaee: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_af1:
	/* 0xaf1: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_af6:
	/* 0xaf6: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_afa:
	/* 0xafa: cmp    ebp,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 255ULL);
x86_l_b00:
	/* 0xb00: mov    eax,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 255ULL);
x86_l_b05:
	/* 0xb05: cmovae ebp,eax */
	X86_SIM_L_EXEC_CMOV(X86_RBP, X86_RAX, X86_WIDTH_32, X86_CC_AE);
x86_l_b08:
	/* 0xb08: lea    eax,[rbp*8+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 3), 0ULL);
x86_l_b0f:
	/* 0xb0f: mov    DWORD PTR [rbx],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b11:
	/* 0xb11: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_b14:
	/* 0xb14: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_b18:
	/* 0xb18: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_b1d:
	/* 0xb1d: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_b1f:
	/* 0xb1f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_b21:
	/* 0xb21: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b26:
	/* 0xb26: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_b29:
	/* 0xb29: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_b2c:
	/* 0xb2c: jmp    31d3 <generic_fexit_filter_arg+0x31d3> */
	X86_SIM_X86_JMP(0xb2c, 0x31d3, x86_l_31d3);
x86_l_b31:
	/* 0xb31: lea    edx,[rax-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_b34:
	/* 0xb34: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_b37:
	/* 0xb37: jb     bd7 <generic_fexit_filter_arg+0xbd7> */
	X86_SIM_X86_JCC(X86_CC_B, 0xb37, 0xbd7, x86_l_bd7);
x86_l_b3d:
	/* 0xb3d: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0xb3d, 0xc2, x86_l_c2);
x86_l_b42:
	/* 0xb42: mov    ebp,DWORD PTR [r13+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b46:
	/* 0xb46: add    r13,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_b4a:
	/* 0xb4a: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_b4d:
	/* 0xb4d: jg     11b3 <generic_fexit_filter_arg+0x11b3> */
	X86_SIM_X86_JCC(X86_CC_G, 0xb4d, 0x11b3, x86_l_11b3);
x86_l_b53:
	/* 0xb53: lea    ecx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_b56:
	/* 0xb56: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_b59:
	/* 0xb59: jb     1a35 <generic_fexit_filter_arg+0x1a35> */
	X86_SIM_X86_JCC(X86_CC_B, 0xb59, 0x1a35, x86_l_1a35);
x86_l_b5f:
	/* 0xb5f: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_b64:
	/* 0xb64: cmp    eax,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_b67:
	/* 0xb67: je     1993 <generic_fexit_filter_arg+0x1993> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb67, 0x1993, x86_l_1993);
x86_l_b6d:
	/* 0xb6d: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_b72:
	/* 0xb72: cmp    eax,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 9ULL);
x86_l_b75:
	/* 0xb75: je     11d8 <generic_fexit_filter_arg+0x11d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb75, 0x11d8, x86_l_11d8);
x86_l_b7b:
	/* 0xb7b: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0xb7b, 0x358b, x86_l_358b);
x86_l_b80:
	/* 0xb80: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b83:
	/* 0xb83: je     149a <generic_fexit_filter_arg+0x149a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb83, 0x149a, x86_l_149a);
x86_l_b89:
	/* 0xb89: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_b8c:
	/* 0xb8c: jne    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb8c, 0x218e, x86_l_218e);
x86_l_b92:
	/* 0xb92: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_b95:
	/* 0xb95: ja     2184 <generic_fexit_filter_arg+0x2184> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb95, 0x2184, x86_l_2184);
x86_l_b9b:
	/* 0xb9b: mov    esi,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 5122ULL);
x86_l_ba0:
	/* 0xba0: bt     esi,ecx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_ba3:
	/* 0xba3: jae    2184 <generic_fexit_filter_arg+0x2184> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xba3, 0x2184, x86_l_2184);
x86_l_ba9:
	/* 0xba9: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bad:
	/* 0xbad: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0xbad, 0x27a, x86_l_27a);
x86_l_bb3:
	/* 0xbb3: jmp    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JMP(0xbb3, 0x218e, x86_l_218e);
x86_l_bb8:
	/* 0xbb8: cmp    ecx,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 28ULL);
x86_l_bbb:
	/* 0xbbb: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbbb, 0x27a, x86_l_27a);
x86_l_bc1:
	/* 0xbc1: cmp    eax,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_bc4:
	/* 0xbc4: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0xbc4, 0xc2, x86_l_c2);
x86_l_bca:
	/* 0xbca: mov    edx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_bcc:
	/* 0xbcc: mov    esi,0x101e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4126ULL);
x86_l_bd1:
	/* 0xbd1: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_bd5:
	/* 0xbd5: jae    bfc <generic_fexit_filter_arg+0xbfc> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xbd5, 0xbfc, x86_l_bfc);
x86_l_bd7:
	/* 0xbd7: mov    rdx,QWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bdc:
	/* 0xbdc: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_bdf:
	/* 0xbdf: jle    c20 <generic_fexit_filter_arg+0xc20> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xbdf, 0xc20, x86_l_c20);
x86_l_be1:
	/* 0xbe1: lea    esi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_be4:
	/* 0xbe4: cmp    esi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_be7:
	/* 0xbe7: jae    e85 <generic_fexit_filter_arg+0xe85> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xbe7, 0xe85, x86_l_e85);
x86_l_bed:
	/* 0xbed: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf1:
	/* 0xbf1: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbf1, 0x261, x86_l_261);
x86_l_bf7:
	/* 0xbf7: jmp    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JMP(0xbf7, 0x1caf, x86_l_1caf);
x86_l_bfc:
	/* 0xbfc: mov    esi,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 3072ULL);
x86_l_c01:
	/* 0xc01: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_c05:
	/* 0xc05: jb     c4f <generic_fexit_filter_arg+0xc4f> */
	X86_SIM_X86_JCC(X86_CC_B, 0xc05, 0xc4f, x86_l_c4f);
x86_l_c07:
	/* 0xc07: movabs rsi,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_64, 6442450944ULL);
x86_l_c11:
	/* 0xc11: bt     rsi,rdx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_c15:
	/* 0xc15: jb     ea9 <generic_fexit_filter_arg+0xea9> */
	X86_SIM_X86_JCC(X86_CC_B, 0xc15, 0xea9, x86_l_ea9);
x86_l_c1b:
	/* 0xc1b: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0xc1b, 0xc2, x86_l_c2);
x86_l_c20:
	/* 0xc20: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_c23:
	/* 0xc23: je     1133 <generic_fexit_filter_arg+0x1133> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc23, 0x1133, x86_l_1133);
x86_l_c29:
	/* 0xc29: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_c2c:
	/* 0xc2c: jne    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc2c, 0x1caf, x86_l_1caf);
x86_l_c32:
	/* 0xc32: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_c35:
	/* 0xc35: je     c40 <generic_fexit_filter_arg+0xc40> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc35, 0xc40, x86_l_c40);
x86_l_c37:
	/* 0xc37: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_c3a:
	/* 0xc3a: jne    1ca5 <generic_fexit_filter_arg+0x1ca5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc3a, 0x1ca5, x86_l_1ca5);
x86_l_c40:
	/* 0xc40: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c44:
	/* 0xc44: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0xc44, 0x27a, x86_l_27a);
x86_l_c4a:
	/* 0xc4a: jmp    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JMP(0xc4a, 0x1caf, x86_l_1caf);
x86_l_c4f:
	/* 0xc4f: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_c55:
	/* 0xc55: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c59:
	/* 0xc59: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_c5e:
	/* 0xc5e: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c63:
	/* 0xc63: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_c6a:
	/* 0xc6a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_c6c:
	/* 0xc6c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_c6f:
	/* 0xc6f: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6f, 0x20f6, x86_l_20f6);
x86_l_c75:
	/* 0xc75: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_c78:
	/* 0xc78: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c7c:
	/* 0xc7c: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c81:
	/* 0xc81: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_c86:
	/* 0xc86: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c8b:
	/* 0xc8b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_c8d:
	/* 0xc8d: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_c92:
	/* 0xc92: cmp    ecx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 11ULL);
x86_l_c95:
	/* 0xc95: je     17d1 <generic_fexit_filter_arg+0x17d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc95, 0x17d1, x86_l_17d1);
x86_l_c9b:
	/* 0xc9b: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_c9e:
	/* 0xc9e: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ca2:
	/* 0xca2: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ca7:
	/* 0xca7: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cac:
	/* 0xcac: je     17b9 <generic_fexit_filter_arg+0x17b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcac, 0x17b9, x86_l_17b9);
x86_l_cb2:
	/* 0xcb2: jmp    17c7 <generic_fexit_filter_arg+0x17c7> */
	X86_SIM_X86_JMP(0xcb2, 0x17c7, x86_l_17c7);
x86_l_cb7:
	/* 0xcb7: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_cbd:
	/* 0xcbd: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_cc1:
	/* 0xcc1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_cc6:
	/* 0xcc6: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_ccb:
	/* 0xccb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_cd2:
	/* 0xcd2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_cd4:
	/* 0xcd4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_cd7:
	/* 0xcd7: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd7, 0x20f6, x86_l_20f6);
x86_l_cdd:
	/* 0xcdd: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_ce0:
	/* 0xce0: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce4:
	/* 0xce4: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ce9:
	/* 0xce9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_cee:
	/* 0xcee: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_cf3:
	/* 0xcf3: jmp    1b8c <generic_fexit_filter_arg+0x1b8c> */
	X86_SIM_X86_JMP(0xcf3, 0x1b8c, x86_l_1b8c);
x86_l_cf8:
	/* 0xcf8: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_cfd:
	/* 0xcfd: mov    WORD PTR [rsp+0x5e],dx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 94ULL);
x86_l_d02:
	/* 0xd02: movzx  edx,WORD PTR [r13+0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_d07:
	/* 0xd07: mov    WORD PTR [rsp+0x58],dx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_d0c:
	/* 0xd0c: mov    rdx,QWORD PTR [r13+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d10:
	/* 0xd10: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d15:
	/* 0xd15: mov    rdx,QWORD PTR [r13+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d19:
	/* 0xd19: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d1e:
	/* 0xd1e: lea    r13,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d23:
	/* 0xd23: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d25:
	/* 0xd25: cmp    eax,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_d28:
	/* 0xd28: jle    d51 <generic_fexit_filter_arg+0xd51> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xd28, 0xd51, x86_l_d51);
x86_l_d2a:
	/* 0xd2a: cmp    eax,0x17 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 23ULL);
x86_l_d2d:
	/* 0xd2d: jg     d84 <generic_fexit_filter_arg+0xd84> */
	X86_SIM_X86_JCC(X86_CC_G, 0xd2d, 0xd84, x86_l_d84);
x86_l_d2f:
	/* 0xd2f: lea    ecx,[rax-0x14] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_d32:
	/* 0xd32: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_d35:
	/* 0xd35: jb     137c <generic_fexit_filter_arg+0x137c> */
	X86_SIM_X86_JCC(X86_CC_B, 0xd35, 0x137c, x86_l_137c);
x86_l_d3b:
	/* 0xd3b: lea    ecx,[rax-0x16] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_d3e:
	/* 0xd3e: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_d43:
	/* 0xd43: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_d46:
	/* 0xd46: jb     1372 <generic_fexit_filter_arg+0x1372> */
	X86_SIM_X86_JCC(X86_CC_B, 0xd46, 0x1372, x86_l_1372);
x86_l_d4c:
	/* 0xd4c: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0xd4c, 0x269, x86_l_269);
x86_l_d51:
	/* 0xd51: cmp    eax,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 15ULL);
x86_l_d54:
	/* 0xd54: jle    ff3 <generic_fexit_filter_arg+0xff3> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xd54, 0xff3, x86_l_ff3);
x86_l_d5a:
	/* 0xd5a: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_d5d:
	/* 0xd5d: jg     135f <generic_fexit_filter_arg+0x135f> */
	X86_SIM_X86_JCC(X86_CC_G, 0xd5d, 0x135f, x86_l_135f);
x86_l_d63:
	/* 0xd63: cmp    eax,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_d66:
	/* 0xd66: je     1372 <generic_fexit_filter_arg+0x1372> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd66, 0x1372, x86_l_1372);
x86_l_d6c:
	/* 0xd6c: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_d71:
	/* 0xd71: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_d74:
	/* 0xd74: jne    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd74, 0x269, x86_l_269);
x86_l_d7a:
	/* 0xd7a: movzx  ebx,WORD PTR [r13+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_d7f:
	/* 0xd7f: jmp    1b51 <generic_fexit_filter_arg+0x1b51> */
	X86_SIM_X86_JMP(0xd7f, 0x1b51, x86_l_1b51);
x86_l_d84:
	/* 0xd84: cmp    eax,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_d87:
	/* 0xd87: jg     13bd <generic_fexit_filter_arg+0x13bd> */
	X86_SIM_X86_JCC(X86_CC_G, 0xd87, 0x13bd, x86_l_13bd);
x86_l_d8d:
	/* 0xd8d: cmp    eax,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 24ULL);
x86_l_d90:
	/* 0xd90: je     13fa <generic_fexit_filter_arg+0x13fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd90, 0x13fa, x86_l_13fa);
x86_l_d96:
	/* 0xd96: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_d9b:
	/* 0xd9b: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_d9e:
	/* 0xd9e: je     13ed <generic_fexit_filter_arg+0x13ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd9e, 0x13ed, x86_l_13ed);
x86_l_da4:
	/* 0xda4: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0xda4, 0x269, x86_l_269);
x86_l_da9:
	/* 0xda9: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_dac:
	/* 0xdac: je     14c0 <generic_fexit_filter_arg+0x14c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdac, 0x14c0, x86_l_14c0);
x86_l_db2:
	/* 0xdb2: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_db7:
	/* 0xdb7: cmp    eax,0x22 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 34ULL);
x86_l_dba:
	/* 0xdba: jne    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdba, 0x358b, x86_l_358b);
x86_l_dc0:
	/* 0xdc0: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_dc5:
	/* 0xdc5: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_dc7:
	/* 0xdc7: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_dca:
	/* 0xdca: mov    eax,DWORD PTR [r12+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_dcf:
	/* 0xdcf: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_dd3:
	/* 0xdd3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_dd8:
	/* 0xdd8: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ddd:
	/* 0xddd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&substring_map));
x86_l_de4:
	/* 0xde4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_de6:
	/* 0xde6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_de9:
	/* 0xde9: je     210b <generic_fexit_filter_arg+0x210b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xde9, 0x210b, x86_l_210b);
x86_l_def:
	/* 0xdef: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_df1:
	/* 0xdf1: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_df6:
	/* 0xdf6: je     e62 <generic_fexit_filter_arg+0xe62> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf6, 0xe62, x86_l_e62);
x86_l_df8:
	/* 0xdf8: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_dfd:
	/* 0xdfd: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_dff:
	/* 0xdff: jmp    e0c <generic_fexit_filter_arg+0xe0c> */
	X86_SIM_X86_JMP(0xdff, 0xe0c, x86_l_e0c);
x86_l_e01:
	/* 0xe01: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e04:
	/* 0xe04: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e07:
	/* 0xe07: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_e0a:
	/* 0xe0a: je     e62 <generic_fexit_filter_arg+0xe62> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe0a, 0xe62, x86_l_e62);
x86_l_e0c:
	/* 0xe0c: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e0e:
	/* 0xe0e: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_e12:
	/* 0xe12: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_e15:
	/* 0xe15: jae    e01 <generic_fexit_filter_arg+0xe01> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xe15, 0xe01, x86_l_e01);
x86_l_e17:
	/* 0xe17: movsx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_e1b:
	/* 0xe1b: test   edi,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32);
x86_l_e1d:
	/* 0xe1d: je     e5a <generic_fexit_filter_arg+0xe5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe1d, 0xe5a, x86_l_e5a);
x86_l_e1f:
	/* 0xe1f: movsx  r9d,BYTE PTR [rdx+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_e24:
	/* 0xe24: lea    r10d,[r9-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_e28:
	/* 0xe28: mov    r8d,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R9, X86_WIDTH_32);
x86_l_e2b:
	/* 0xe2b: or     r8d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_e2f:
	/* 0xe2f: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_e33:
	/* 0xe33: cmovae r8d,r9d */
	X86_SIM_L_EXEC_CMOV(X86_R8, X86_R9, X86_WIDTH_32, X86_CC_AE);
x86_l_e37:
	/* 0xe37: lea    r10d,[rdi-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_e3b:
	/* 0xe3b: mov    r9d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RDI, X86_WIDTH_32);
x86_l_e3e:
	/* 0xe3e: or     r9d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_e42:
	/* 0xe42: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_e46:
	/* 0xe46: cmovae r9d,edi */
	X86_SIM_L_EXEC_CMOV(X86_R9, X86_RDI, X86_WIDTH_32, X86_CC_AE);
x86_l_e4a:
	/* 0xe4a: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_e4e:
	/* 0xe4e: ja     e01 <generic_fexit_filter_arg+0xe01> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe4e, 0xe01, x86_l_e01);
x86_l_e50:
	/* 0xe50: inc    rsi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e53:
	/* 0xe53: cmp    r8d,r9d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_R9, X86_WIDTH_32);
x86_l_e56:
	/* 0xe56: je     e0e <generic_fexit_filter_arg+0xe0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe56, 0xe0e, x86_l_e0e);
x86_l_e58:
	/* 0xe58: jmp    e01 <generic_fexit_filter_arg+0xe01> */
	X86_SIM_X86_JMP(0xe58, 0xe01, x86_l_e01);
x86_l_e5a:
	/* 0xe5a: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_e5c:
	/* 0xe5c: jns    244d <generic_fexit_filter_arg+0x244d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe5c, 0x244d, x86_l_244d);
x86_l_e62:
	/* 0xe62: lea    eax,[r13+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_e66:
	/* 0xe66: cmp    eax,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_e6b:
	/* 0xe6b: jae    e7e <generic_fexit_filter_arg+0xe7e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xe6b, 0xe7e, x86_l_e7e);
x86_l_e6d:
	/* 0xe6d: add    r13d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_e71:
	/* 0xe71: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e74:
	/* 0xe74: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_e78:
	/* 0xe78: jne    dca <generic_fexit_filter_arg+0xdca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe78, 0xdca, x86_l_dca);
x86_l_e7e:
	/* 0xe7e: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e80:
	/* 0xe80: jmp    2452 <generic_fexit_filter_arg+0x2452> */
	X86_SIM_X86_JMP(0xe80, 0x2452, x86_l_2452);
x86_l_e85:
	/* 0xe85: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_e88:
	/* 0xe88: jne    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe88, 0x1caf, x86_l_1caf);
x86_l_e8e:
	/* 0xe8e: test   QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e92:
	/* 0xe92: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe92, 0x27a, x86_l_27a);
x86_l_e98:
	/* 0xe98: jmp    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JMP(0xe98, 0x1caf, x86_l_1caf);
x86_l_e9d:
	/* 0xe9d: lea    edx,[rax-0x1f] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551585ULL);
x86_l_ea0:
	/* 0xea0: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_ea3:
	/* 0xea3: jae    17d9 <generic_fexit_filter_arg+0x17d9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xea3, 0x17d9, x86_l_17d9);
x86_l_ea9:
	/* 0xea9: cmp    eax,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 31ULL);
x86_l_eac:
	/* 0xeac: jne    1018 <generic_fexit_filter_arg+0x1018> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xeac, 0x1018, x86_l_1018);
x86_l_eb2:
	/* 0xeb2: mov    rsi,QWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eb7:
	/* 0xeb7: mov    rdx,QWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ebc:
	/* 0xebc: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_ebf:
	/* 0xebf: je     eca <generic_fexit_filter_arg+0xeca> */
	X86_SIM_X86_JCC(X86_CC_E, 0xebf, 0xeca, x86_l_eca);
x86_l_ec1:
	/* 0xec1: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_ec4:
	/* 0xec4: jne    1aac <generic_fexit_filter_arg+0x1aac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xec4, 0x1aac, x86_l_1aac);
x86_l_eca:
	/* 0xeca: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ece:
	/* 0xece: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_ed1:
	/* 0xed1: jg     1abe <generic_fexit_filter_arg+0x1abe> */
	X86_SIM_X86_JCC(X86_CC_G, 0xed1, 0x1abe, x86_l_1abe);
x86_l_ed7:
	/* 0xed7: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_eda:
	/* 0xeda: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xeda, 0x27a, x86_l_27a);
x86_l_ee0:
	/* 0xee0: jmp    1abe <generic_fexit_filter_arg+0x1abe> */
	X86_SIM_X86_JMP(0xee0, 0x1abe, x86_l_1abe);
x86_l_ee5:
	/* 0xee5: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_eea:
	/* 0xeea: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eef:
	/* 0xeef: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ef3:
	/* 0xef3: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_efb:
	/* 0xefb: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_f00:
	/* 0xf00: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_f05:
	/* 0xf05: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps));
x86_l_f0c:
	/* 0xf0c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_f0e:
	/* 0xf0e: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_f10:
	/* 0xf10: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf10, 0x357b, x86_l_357b);
x86_l_f16:
	/* 0xf16: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_f19:
	/* 0xf19: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_f1e:
	/* 0xf1e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_f21:
	/* 0xf21: je     357d <generic_fexit_filter_arg+0x357d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf21, 0x357d, x86_l_357d);
x86_l_f27:
	/* 0xf27: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_f2c:
	/* 0xf2c: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_f31:
	/* 0xf31: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap));
x86_l_f38:
	/* 0xf38: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_f3a:
	/* 0xf3a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_f3d:
	/* 0xf3d: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf3d, 0x357b, x86_l_357b);
x86_l_f43:
	/* 0xf43: cmp    ebp,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 255ULL);
x86_l_f49:
	/* 0xf49: mov    ecx,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 255ULL);
x86_l_f4e:
	/* 0xf4e: cmovae ebp,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RBP, X86_RCX, X86_WIDTH_32, X86_CC_AE);
x86_l_f51:
	/* 0xf51: lea    ecx,[rbp*8+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 3), 0ULL);
x86_l_f58:
	/* 0xf58: mov    DWORD PTR [rax],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f5a:
	/* 0xf5a: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_f5d:
	/* 0xf5d: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_f61:
	/* 0xf61: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_f64:
	/* 0xf64: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_f69:
	/* 0xf69: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f6e:
	/* 0xf6e: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_f70:
	/* 0xf70: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_f72:
	/* 0xf72: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_f77:
	/* 0xf77: jmp    1a20 <generic_fexit_filter_arg+0x1a20> */
	X86_SIM_X86_JMP(0xf77, 0x1a20, x86_l_1a20);
x86_l_f7c:
	/* 0xf7c: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_f84:
	/* 0xf84: cmp    ebp,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 4096ULL);
x86_l_f8a:
	/* 0xf8a: ja     299a <generic_fexit_filter_arg+0x299a> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf8a, 0x299a, x86_l_299a);
x86_l_f90:
	/* 0xf90: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_f93:
	/* 0xf93: cmp    eax,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 144ULL);
x86_l_f98:
	/* 0xf98: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f9d:
	/* 0xf9d: ja     1c32 <generic_fexit_filter_arg+0x1c32> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf9d, 0x1c32, x86_l_1c32);
x86_l_fa3:
	/* 0xfa3: movzx  eax,bpl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_8);
x86_l_fa7:
	/* 0xfa7: imul   ecx,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RCX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_fad:
	/* 0xfad: shr    ecx,0x9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_fb0:
	/* 0xfb0: and    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_fb3:
	/* 0xfb3: lea    ecx,[rcx+rcx*2] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_fb6:
	/* 0xfb6: sub    al,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_fb8:
	/* 0xfb8: test   bp,bp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_16);
x86_l_fbb:
	/* 0xfbb: je     fc5 <generic_fexit_filter_arg+0xfc5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfbb, 0xfc5, x86_l_fc5);
x86_l_fbd:
	/* 0xfbd: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_fbf:
	/* 0xfbf: mov    edx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_32);
x86_l_fc1:
	/* 0xfc1: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_fc3:
	/* 0xfc3: je     fe0 <generic_fexit_filter_arg+0xfe0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc3, 0xfe0, x86_l_fe0);
x86_l_fc5:
	/* 0xfc5: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_fc8:
	/* 0xfc8: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_fca:
	/* 0xfca: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_fcc:
	/* 0xfcc: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_fce:
	/* 0xfce: add    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_fd1:
	/* 0xfd1: movzx  edx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_fd4:
	/* 0xfd4: cmp    cx,0x78 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_16, 120ULL);
x86_l_fd8:
	/* 0xfd8: ja     1c69 <generic_fexit_filter_arg+0x1c69> */
	X86_SIM_X86_JCC(X86_CC_A, 0xfd8, 0x1c69, x86_l_1c69);
x86_l_fde:
	/* 0xfde: mov    ecx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_fe0:
	/* 0xfe0: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_fe3:
	/* 0xfe3: imul   ecx,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RCX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_fe9:
	/* 0xfe9: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_fec:
	/* 0xfec: dec    ecx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_fee:
	/* 0xfee: jmp    28d5 <generic_fexit_filter_arg+0x28d5> */
	X86_SIM_X86_JMP(0xfee, 0x28d5, x86_l_28d5);
x86_l_ff3:
	/* 0xff3: cmp    eax,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 13ULL);
x86_l_ff6:
	/* 0xff6: je     13fa <generic_fexit_filter_arg+0x13fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff6, 0x13fa, x86_l_13fa);
x86_l_ffc:
	/* 0xffc: cmp    eax,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_fff:
	/* 0xfff: je     13ed <generic_fexit_filter_arg+0x13ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfff, 0x13ed, x86_l_13ed);
x86_l_1005:
	/* 0x1005: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_100a:
	/* 0x100a: cmp    eax,0xf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 15ULL);
x86_l_100d:
	/* 0x100d: je     137c <generic_fexit_filter_arg+0x137c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x100d, 0x137c, x86_l_137c);
x86_l_1013:
	/* 0x1013: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x1013, 0x269, x86_l_269);
x86_l_1018:
	/* 0x1018: mov    rsi,QWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_101d:
	/* 0x101d: mov    rax,QWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1022:
	/* 0x1022: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1025:
	/* 0x1025: je     1030 <generic_fexit_filter_arg+0x1030> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1025, 0x1030, x86_l_1030);
x86_l_1027:
	/* 0x1027: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_102a:
	/* 0x102a: jne    1aff <generic_fexit_filter_arg+0x1aff> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x102a, 0x1aff, x86_l_1aff);
x86_l_1030:
	/* 0x1030: mov    rdx,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1034:
	/* 0x1034: cmp    rsi,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_1037:
	/* 0x1037: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_103b:
	/* 0x103b: cmp    rdx,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_103e:
	/* 0x103e: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_1041:
	/* 0x1041: jmp    1b10 <generic_fexit_filter_arg+0x1b10> */
	X86_SIM_X86_JMP(0x1041, 0x1b10, x86_l_1b10);
x86_l_1046:
	/* 0x1046: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1049:
	/* 0x1049: jne    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1049, 0x218e, x86_l_218e);
x86_l_104f:
	/* 0x104f: test   DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1053:
	/* 0x1053: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1053, 0x27a, x86_l_27a);
x86_l_1059:
	/* 0x1059: jmp    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JMP(0x1059, 0x218e, x86_l_218e);
x86_l_105e:
	/* 0x105e: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_1063:
	/* 0x1063: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1067:
	/* 0x1067: jb     15fb <generic_fexit_filter_arg+0x15fb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1067, 0x15fb, x86_l_15fb);
x86_l_106d:
	/* 0x106d: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_1077:
	/* 0x1077: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_107b:
	/* 0x107b: jae    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x107b, 0xc2, x86_l_c2);
x86_l_1081:
	/* 0x1081: cmp    eax,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 31ULL);
x86_l_1084:
	/* 0x1084: jne    1d9c <generic_fexit_filter_arg+0x1d9c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1084, 0x1d9c, x86_l_1d9c);
x86_l_108a:
	/* 0x108a: movzx  eax,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_108f:
	/* 0x108f: jmp    10c2 <generic_fexit_filter_arg+0x10c2> */
	X86_SIM_X86_JMP(0x108f, 0x10c2, x86_l_10c2);
x86_l_1091:
	/* 0x1091: mov    edx,0xc00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3072ULL);
x86_l_1096:
	/* 0x1096: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_109a:
	/* 0x109a: jb     163d <generic_fexit_filter_arg+0x163d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x109a, 0x163d, x86_l_163d);
x86_l_10a0:
	/* 0x10a0: movabs rdx,0x180000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 6442450944ULL);
x86_l_10aa:
	/* 0x10aa: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_10ae:
	/* 0x10ae: jae    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10ae, 0xc2, x86_l_c2);
x86_l_10b4:
	/* 0x10b4: cmp    eax,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 31ULL);
x86_l_10b7:
	/* 0x10b7: jne    1da8 <generic_fexit_filter_arg+0x1da8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10b7, 0x1da8, x86_l_1da8);
x86_l_10bd:
	/* 0x10bd: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_10c2:
	/* 0x10c2: cmp    DWORD PTR [r12+0x10],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10c7:
	/* 0x10c7: ja     10d4 <generic_fexit_filter_arg+0x10d4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10c7, 0x10d4, x86_l_10d4);
x86_l_10c9:
	/* 0x10c9: cmp    DWORD PTR [r12+0x14],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_10ce:
	/* 0x10ce: jae    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10ce, 0x27a, x86_l_27a);
x86_l_10d4:
	/* 0x10d4: mov    ecx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10d9:
	/* 0x10d9: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_10dc:
	/* 0x10dc: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10dc, 0xc2, x86_l_c2);
x86_l_10e2:
	/* 0x10e2: cmp    DWORD PTR [r12+0x18],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_10e7:
	/* 0x10e7: ja     10f4 <generic_fexit_filter_arg+0x10f4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10e7, 0x10f4, x86_l_10f4);
x86_l_10e9:
	/* 0x10e9: cmp    DWORD PTR [r12+0x1c],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_10ee:
	/* 0x10ee: jae    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10ee, 0x27a, x86_l_27a);
x86_l_10f4:
	/* 0x10f4: cmp    ecx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 25ULL);
x86_l_10f7:
	/* 0x10f7: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10f7, 0xc2, x86_l_c2);
x86_l_10fd:
	/* 0x10fd: cmp    DWORD PTR [r12+0x20],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1102:
	/* 0x1102: ja     110f <generic_fexit_filter_arg+0x110f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1102, 0x110f, x86_l_110f);
x86_l_1104:
	/* 0x1104: cmp    DWORD PTR [r12+0x24],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1109:
	/* 0x1109: jae    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1109, 0x27a, x86_l_27a);
x86_l_110f:
	/* 0x110f: cmp    ecx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 33ULL);
x86_l_1112:
	/* 0x1112: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1112, 0xc2, x86_l_c2);
x86_l_1118:
	/* 0x1118: cmp    DWORD PTR [r12+0x28],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_111d:
	/* 0x111d: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x111d, 0xc2, x86_l_c2);
x86_l_1123:
	/* 0x1123: cmp    DWORD PTR [r12+0x2c],eax */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1128:
	/* 0x1128: jae    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1128, 0x27a, x86_l_27a);
x86_l_112e:
	/* 0x112e: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x112e, 0xc2, x86_l_c2);
x86_l_1133:
	/* 0x1133: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1136:
	/* 0x1136: je     1141 <generic_fexit_filter_arg+0x1141> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1136, 0x1141, x86_l_1141);
x86_l_1138:
	/* 0x1138: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_113b:
	/* 0x113b: jne    1c99 <generic_fexit_filter_arg+0x1c99> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x113b, 0x1c99, x86_l_1c99);
x86_l_1141:
	/* 0x1141: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1145:
	/* 0x1145: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1145, 0x27a, x86_l_27a);
x86_l_114b:
	/* 0x114b: jmp    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JMP(0x114b, 0x1caf, x86_l_1caf);
x86_l_1150:
	/* 0x1150: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1153:
	/* 0x1153: cmp    eax,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 144ULL);
x86_l_1158:
	/* 0x1158: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_115d:
	/* 0x115d: ja     16d5 <generic_fexit_filter_arg+0x16d5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x115d, 0x16d5, x86_l_16d5);
x86_l_1163:
	/* 0x1163: movzx  eax,bpl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1167:
	/* 0x1167: imul   ecx,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RCX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_116d:
	/* 0x116d: shr    ecx,0x9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_1170:
	/* 0x1170: and    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1173:
	/* 0x1173: lea    ecx,[rcx+rcx*2] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_1176:
	/* 0x1176: sub    al,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_1178:
	/* 0x1178: test   bp,bp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_16);
x86_l_117b:
	/* 0x117b: je     1185 <generic_fexit_filter_arg+0x1185> */
	X86_SIM_X86_JCC(X86_CC_E, 0x117b, 0x1185, x86_l_1185);
x86_l_117d:
	/* 0x117d: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_117f:
	/* 0x117f: mov    edx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_32);
x86_l_1181:
	/* 0x1181: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_1183:
	/* 0x1183: je     11a0 <generic_fexit_filter_arg+0x11a0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1183, 0x11a0, x86_l_11a0);
x86_l_1185:
	/* 0x1185: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1188:
	/* 0x1188: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_118a:
	/* 0x118a: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_118c:
	/* 0x118c: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_118e:
	/* 0x118e: add    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_1191:
	/* 0x1191: movzx  edx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1194:
	/* 0x1194: cmp    cx,0x78 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_16, 120ULL);
x86_l_1198:
	/* 0x1198: ja     170c <generic_fexit_filter_arg+0x170c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1198, 0x170c, x86_l_170c);
x86_l_119e:
	/* 0x119e: mov    ecx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_11a0:
	/* 0x11a0: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_11a3:
	/* 0x11a3: imul   ecx,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RCX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_11a9:
	/* 0x11a9: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_11ac:
	/* 0x11ac: dec    ecx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_11ae:
	/* 0x11ae: jmp    22a4 <generic_fexit_filter_arg+0x22a4> */
	X86_SIM_X86_JMP(0x11ae, 0x22a4, x86_l_22a4);
x86_l_11b3:
	/* 0x11b3: cmp    eax,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 32ULL);
x86_l_11b6:
	/* 0x11b6: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11bb:
	/* 0x11bb: jg     1820 <generic_fexit_filter_arg+0x1820> */
	X86_SIM_X86_JCC(X86_CC_G, 0x11bb, 0x1820, x86_l_1820);
x86_l_11c1:
	/* 0x11c1: cmp    eax,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 26ULL);
x86_l_11c4:
	/* 0x11c4: je     1993 <generic_fexit_filter_arg+0x1993> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11c4, 0x1993, x86_l_1993);
x86_l_11ca:
	/* 0x11ca: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_11cf:
	/* 0x11cf: cmp    eax,0x1b */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 27ULL);
x86_l_11d2:
	/* 0x11d2: jne    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11d2, 0x358b, x86_l_358b);
x86_l_11d8:
	/* 0x11d8: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11dd:
	/* 0x11dd: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_11e1:
	/* 0x11e1: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_11e9:
	/* 0x11e9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_11ee:
	/* 0x11ee: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_11f3:
	/* 0x11f3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps));
x86_l_11fa:
	/* 0x11fa: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_11fc:
	/* 0x11fc: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_11fe:
	/* 0x11fe: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11fe, 0x357b, x86_l_357b);
x86_l_1204:
	/* 0x1204: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_1207:
	/* 0x1207: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_120c:
	/* 0x120c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_120f:
	/* 0x120f: je     357d <generic_fexit_filter_arg+0x357d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x120f, 0x357d, x86_l_357d);
x86_l_1215:
	/* 0x1215: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_121a:
	/* 0x121a: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_121f:
	/* 0x121f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap));
x86_l_1226:
	/* 0x1226: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1228:
	/* 0x1228: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_122b:
	/* 0x122b: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x122b, 0x357b, x86_l_357b);
x86_l_1231:
	/* 0x1231: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1234:
	/* 0x1234: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1239:
	/* 0x1239: cmp    ebp,0x7f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 127ULL);
x86_l_123c:
	/* 0x123c: mov    eax,0x7f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 127ULL);
x86_l_1241:
	/* 0x1241: cmovb  eax,ebp */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RBP, X86_WIDTH_32, X86_CC_B);
x86_l_1244:
	/* 0x1244: shl    eax,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1247:
	/* 0x1247: mov    DWORD PTR [rdi],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1249:
	/* 0x1249: mov    rax,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBP, X86_WIDTH_64);
x86_l_124c:
	/* 0x124c: neg    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_124f:
	/* 0x124f: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_1254:
	/* 0x1254: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_1257:
	/* 0x1257: lea    edx,[rbp-0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_125a:
	/* 0x125a: mov    QWORD PTR [rsp+0x68],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_125f:
	/* 0x125f: add    rdi,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_1263:
	/* 0x1263: mov    r8d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 2ULL);
x86_l_1269:
	/* 0x1269: sub    r8,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_126c:
	/* 0x126c: lea    r9d,[rbp-0x3] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1270:
	/* 0x1270: mov    r10d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 1ULL);
x86_l_1276:
	/* 0x1276: sub    r10,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
x86_l_1279:
	/* 0x1279: lea    r11d,[rbp-0x2] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_127d:
	/* 0x127d: dec    ebp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_127f:
	/* 0x127f: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1281:
	/* 0x1281: mov    rsi,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1286:
	/* 0x1286: lea    r13d,[rbx+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_128a:
	/* 0x128a: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1291:
	/* 0x1291: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_1296:
	/* 0x1296: mov    BYTE PTR [rdi-0x3],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_129a:
	/* 0x129a: cmp    r10,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R10, X86_RBX, X86_WIDTH_64);
x86_l_129d:
	/* 0x129d: je     12f7 <generic_fexit_filter_arg+0x12f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x129d, 0x12f7, x86_l_12f7);
x86_l_129f:
	/* 0x129f: lea    r13d,[r11+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R11, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_12a3:
	/* 0x12a3: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_12aa:
	/* 0x12aa: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_12af:
	/* 0x12af: mov    BYTE PTR [rdi-0x2],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_12b3:
	/* 0x12b3: cmp    r8,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RBX, X86_WIDTH_64);
x86_l_12b6:
	/* 0x12b6: je     12f7 <generic_fexit_filter_arg+0x12f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12b6, 0x12f7, x86_l_12f7);
x86_l_12b8:
	/* 0x12b8: lea    r13d,[r9+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_12bc:
	/* 0x12bc: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_12c3:
	/* 0x12c3: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_12c8:
	/* 0x12c8: mov    BYTE PTR [rdi-0x1],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_12cc:
	/* 0x12cc: cmp    rcx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_12cf:
	/* 0x12cf: je     12f7 <generic_fexit_filter_arg+0x12f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12cf, 0x12f7, x86_l_12f7);
x86_l_12d1:
	/* 0x12d1: cmp    rbx,0xffffffffffffff84 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551492ULL);
x86_l_12d5:
	/* 0x12d5: je     12f7 <generic_fexit_filter_arg+0x12f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12d5, 0x12f7, x86_l_12f7);
x86_l_12d7:
	/* 0x12d7: lea    r13d,[rdx+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_12db:
	/* 0x12db: and    r13d,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_12e2:
	/* 0x12e2: movzx  r13d,BYTE PTR [rsi+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R13, 0, X86_WIDTH_8), 0ULL);
x86_l_12e7:
	/* 0x12e7: mov    BYTE PTR [rdi],r13b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12ea:
	/* 0x12ea: add    rbx,0xfffffffffffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_12ee:
	/* 0x12ee: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_12f2:
	/* 0x12f2: cmp    rax,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_12f5:
	/* 0x12f5: jne    1286 <generic_fexit_filter_arg+0x1286> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12f5, 0x1286, x86_l_1286);
x86_l_12f7:
	/* 0x12f7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_12fc:
	/* 0x12fc: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1301:
	/* 0x1301: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1306:
	/* 0x1306: jmp    1a26 <generic_fexit_filter_arg+0x1a26> */
	X86_SIM_X86_JMP(0x1306, 0x1a26, x86_l_1a26);
x86_l_130b:
	/* 0x130b: mov    esi,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1310:
	/* 0x1310: mov    eax,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1315:
	/* 0x1315: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1318:
	/* 0x1318: ja     1f2f <generic_fexit_filter_arg+0x1f2f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1318, 0x1f2f, x86_l_1f2f);
x86_l_131e:
	/* 0x131e: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1323:
	/* 0x1323: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_1326:
	/* 0x1326: jae    1f2f <generic_fexit_filter_arg+0x1f2f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1326, 0x1f2f, x86_l_1f2f);
x86_l_132c:
	/* 0x132c: mov    edx,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1330:
	/* 0x1330: cmp    esi,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1332:
	/* 0x1332: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_1336:
	/* 0x1336: cmp    edx,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1338:
	/* 0x1338: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_133b:
	/* 0x133b: jmp    1f3e <generic_fexit_filter_arg+0x1f3e> */
	X86_SIM_X86_JMP(0x133b, 0x1f3e, x86_l_1f3e);
x86_l_1340:
	/* 0x1340: cmp    eax,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 28ULL);
x86_l_1343:
	/* 0x1343: je     1951 <generic_fexit_filter_arg+0x1951> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1343, 0x1951, x86_l_1951);
x86_l_1349:
	/* 0x1349: mov    r13d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R8, X86_WIDTH_32);
x86_l_134c:
	/* 0x134c: mov    QWORD PTR [rsp+0x18],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1351:
	/* 0x1351: cmp    eax,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 26ULL);
x86_l_1354:
	/* 0x1354: je     18be <generic_fexit_filter_arg+0x18be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1354, 0x18be, x86_l_18be);
x86_l_135a:
	/* 0x135a: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x135a, 0xc2, x86_l_c2);
x86_l_135f:
	/* 0x135f: cmp    eax,0x12 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 18ULL);
x86_l_1362:
	/* 0x1362: je     137c <generic_fexit_filter_arg+0x137c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1362, 0x137c, x86_l_137c);
x86_l_1364:
	/* 0x1364: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_1369:
	/* 0x1369: cmp    eax,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 19ULL);
x86_l_136c:
	/* 0x136c: jne    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x136c, 0x269, x86_l_269);
x86_l_1372:
	/* 0x1372: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1375:
	/* 0x1375: movzx  ebp,WORD PTR [r13+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_137a:
	/* 0x137a: jmp    1384 <generic_fexit_filter_arg+0x1384> */
	X86_SIM_X86_JMP(0x137a, 0x1384, x86_l_1384);
x86_l_137c:
	/* 0x137c: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_137f:
	/* 0x137f: movzx  ebp,WORD PTR [r13+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1384:
	/* 0x1384: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1386:
	/* 0x1386: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1389:
	/* 0x1389: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_138c:
	/* 0x138c: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_138e:
	/* 0x138e: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1391:
	/* 0x1391: jg     1415 <generic_fexit_filter_arg+0x1415> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1391, 0x1415, x86_l_1415);
x86_l_1397:
	/* 0x1397: lea    ecx,[rax-0xd] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_139a:
	/* 0x139a: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_139d:
	/* 0x139d: jb     1448 <generic_fexit_filter_arg+0x1448> */
	X86_SIM_X86_JCC(X86_CC_B, 0x139d, 0x1448, x86_l_1448);
x86_l_13a3:
	/* 0x13a3: lea    ecx,[rax-0xf] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_13a6:
	/* 0x13a6: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_13a9:
	/* 0x13a9: jb     1573 <generic_fexit_filter_arg+0x1573> */
	X86_SIM_X86_JCC(X86_CC_B, 0x13a9, 0x1573, x86_l_1573);
x86_l_13af:
	/* 0x13af: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_13b2:
	/* 0x13b2: je     1b51 <generic_fexit_filter_arg+0x1b51> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13b2, 0x1b51, x86_l_1b51);
x86_l_13b8:
	/* 0x13b8: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x13b8, 0x269, x86_l_269);
x86_l_13bd:
	/* 0x13bd: cmp    eax,0x1c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 28ULL);
x86_l_13c0:
	/* 0x13c0: je     1b4c <generic_fexit_filter_arg+0x1b4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13c0, 0x1b4c, x86_l_1b4c);
x86_l_13c6:
	/* 0x13c6: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_13cb:
	/* 0x13cb: cmp    eax,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 29ULL);
x86_l_13ce:
	/* 0x13ce: jne    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13ce, 0x269, x86_l_269);
x86_l_13d4:
	/* 0x13d4: cmp    ecx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_13d7:
	/* 0x13d7: jne    209d <generic_fexit_filter_arg+0x209d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13d7, 0x209d, x86_l_209d);
x86_l_13dd:
	/* 0x13dd: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
x86_l_13e0:
	/* 0x13e0: jne    20a9 <generic_fexit_filter_arg+0x20a9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13e0, 0x20a9, x86_l_20a9);
x86_l_13e6:
	/* 0x13e6: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13e8:
	/* 0x13e8: jmp    20bb <generic_fexit_filter_arg+0x20bb> */
	X86_SIM_X86_JMP(0x13e8, 0x20bb, x86_l_20bb);
x86_l_13ed:
	/* 0x13ed: mov    rsi,QWORD PTR [r13+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13f1:
	/* 0x13f1: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_13f4:
	/* 0x13f4: mov    r8,QWORD PTR [r13+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_13f8:
	/* 0x13f8: jmp    1405 <generic_fexit_filter_arg+0x1405> */
	X86_SIM_X86_JMP(0x13f8, 0x1405, x86_l_1405);
x86_l_13fa:
	/* 0x13fa: mov    rsi,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13fe:
	/* 0x13fe: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1401:
	/* 0x1401: mov    r8,QWORD PTR [r13+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1405:
	/* 0x1405: mov    r13,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RSI, X86_WIDTH_64);
x86_l_1408:
	/* 0x1408: shr    r13,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_140c:
	/* 0x140c: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_140e:
	/* 0x140e: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1410:
	/* 0x1410: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1413:
	/* 0x1413: jle    1397 <generic_fexit_filter_arg+0x1397> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1413, 0x1397, x86_l_1397);
x86_l_1415:
	/* 0x1415: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1418:
	/* 0x1418: ja     1567 <generic_fexit_filter_arg+0x1567> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1418, 0x1567, x86_l_1567);
x86_l_141e:
	/* 0x141e: mov    ecx,0x500000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 5242880ULL);
x86_l_1423:
	/* 0x1423: bt     ecx,eax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_1426:
	/* 0x1426: jb     16b1 <generic_fexit_filter_arg+0x16b1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1426, 0x16b1, x86_l_16b1);
x86_l_142c:
	/* 0x142c: mov    ecx,0xa00000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 10485760ULL);
x86_l_1431:
	/* 0x1431: bt     ecx,eax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_1434:
	/* 0x1434: jb     16c3 <generic_fexit_filter_arg+0x16c3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1434, 0x16c3, x86_l_16c3);
x86_l_143a:
	/* 0x143a: mov    ecx,0x3000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 50331648ULL);
x86_l_143f:
	/* 0x143f: bt     ecx,eax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_1442:
	/* 0x1442: jae    1567 <generic_fexit_filter_arg+0x1567> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1442, 0x1567, x86_l_1567);
x86_l_1448:
	/* 0x1448: movzx  eax,WORD PTR [rdx+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_144c:
	/* 0x144c: cmp    eax,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 10ULL);
x86_l_144f:
	/* 0x144f: je     173c <generic_fexit_filter_arg+0x173c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x144f, 0x173c, x86_l_173c);
x86_l_1455:
	/* 0x1455: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1458:
	/* 0x1458: jne    17c7 <generic_fexit_filter_arg+0x17c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1458, 0x17c7, x86_l_17c7);
x86_l_145e:
	/* 0x145e: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_1461:
	/* 0x1461: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1466:
	/* 0x1466: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_146a:
	/* 0x146a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_146f:
	/* 0x146f: lea    rsi,[rsp+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1474:
	/* 0x1474: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&addr4lpm_maps));
x86_l_147b:
	/* 0x147b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_147d:
	/* 0x147d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1480:
	/* 0x1480: je     1c0e <generic_fexit_filter_arg+0x1c0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1480, 0x1c0e, x86_l_1c0e);
x86_l_1486:
	/* 0x1486: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1489:
	/* 0x1489: mov    DWORD PTR [rsp+0x70],0x20 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337184ULL);
x86_l_1491:
	/* 0x1491: mov    DWORD PTR [rsp+0x74],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1495:
	/* 0x1495: jmp    178a <generic_fexit_filter_arg+0x178a> */
	X86_SIM_X86_JMP(0x1495, 0x178a, x86_l_178a);
x86_l_149a:
	/* 0x149a: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_149d:
	/* 0x149d: ja     2178 <generic_fexit_filter_arg+0x2178> */
	X86_SIM_X86_JCC(X86_CC_A, 0x149d, 0x2178, x86_l_2178);
x86_l_14a3:
	/* 0x14a3: mov    esi,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 5122ULL);
x86_l_14a8:
	/* 0x14a8: bt     esi,ecx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_14ab:
	/* 0x14ab: jae    2178 <generic_fexit_filter_arg+0x2178> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x14ab, 0x2178, x86_l_2178);
x86_l_14b1:
	/* 0x14b1: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14b5:
	/* 0x14b5: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x14b5, 0x27a, x86_l_27a);
x86_l_14bb:
	/* 0x14bb: jmp    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JMP(0x14bb, 0x218e, x86_l_218e);
x86_l_14c0:
	/* 0x14c0: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_14c5:
	/* 0x14c5: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14c7:
	/* 0x14c7: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14ca:
	/* 0x14ca: mov    eax,DWORD PTR [r12+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_14cf:
	/* 0x14cf: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_14d3:
	/* 0x14d3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_14d8:
	/* 0x14d8: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_14dd:
	/* 0x14dd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&substring_map));
x86_l_14e4:
	/* 0x14e4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_14e6:
	/* 0x14e6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_14e9:
	/* 0x14e9: je     2040 <generic_fexit_filter_arg+0x2040> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e9, 0x2040, x86_l_2040);
x86_l_14ef:
	/* 0x14ef: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_14f1:
	/* 0x14f1: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14f6:
	/* 0x14f6: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14fb:
	/* 0x14fb: je     1542 <generic_fexit_filter_arg+0x1542> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14fb, 0x1542, x86_l_1542);
x86_l_14fd:
	/* 0x14fd: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1502:
	/* 0x1502: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1504:
	/* 0x1504: jmp    1511 <generic_fexit_filter_arg+0x1511> */
	X86_SIM_X86_JMP(0x1504, 0x1511, x86_l_1511);
x86_l_1506:
	/* 0x1506: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1509:
	/* 0x1509: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_150c:
	/* 0x150c: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_150f:
	/* 0x150f: je     1542 <generic_fexit_filter_arg+0x1542> */
	X86_SIM_X86_JCC(X86_CC_E, 0x150f, 0x1542, x86_l_1542);
x86_l_1511:
	/* 0x1511: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1513:
	/* 0x1513: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1517:
	/* 0x1517: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_151a:
	/* 0x151a: jae    1506 <generic_fexit_filter_arg+0x1506> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x151a, 0x1506, x86_l_1506);
x86_l_151c:
	/* 0x151c: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1520:
	/* 0x1520: test   dil,dil */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8);
x86_l_1523:
	/* 0x1523: je     153a <generic_fexit_filter_arg+0x153a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1523, 0x153a, x86_l_153a);
x86_l_1525:
	/* 0x1525: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_1529:
	/* 0x1529: ja     1506 <generic_fexit_filter_arg+0x1506> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1529, 0x1506, x86_l_1506);
x86_l_152b:
	/* 0x152b: lea    r8,[rsi+0x1] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_152f:
	/* 0x152f: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1533:
	/* 0x1533: mov    rsi,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R8, X86_WIDTH_64);
x86_l_1536:
	/* 0x1536: je     1513 <generic_fexit_filter_arg+0x1513> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1536, 0x1513, x86_l_1513);
x86_l_1538:
	/* 0x1538: jmp    1506 <generic_fexit_filter_arg+0x1506> */
	X86_SIM_X86_JMP(0x1538, 0x1506, x86_l_1506);
x86_l_153a:
	/* 0x153a: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_153c:
	/* 0x153c: jns    2283 <generic_fexit_filter_arg+0x2283> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x153c, 0x2283, x86_l_2283);
x86_l_1542:
	/* 0x1542: lea    eax,[r13+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1546:
	/* 0x1546: cmp    eax,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_154b:
	/* 0x154b: jae    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x154b, 0x2035, x86_l_2035);
x86_l_1551:
	/* 0x1551: add    r13d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_1555:
	/* 0x1555: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1558:
	/* 0x1558: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_155c:
	/* 0x155c: jne    14ca <generic_fexit_filter_arg+0x14ca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x155c, 0x14ca, x86_l_14ca);
x86_l_1562:
	/* 0x1562: jmp    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JMP(0x1562, 0x2035, x86_l_2035);
x86_l_1567:
	/* 0x1567: add    eax,0xffffffee */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_156a:
	/* 0x156a: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_156d:
	/* 0x156d: jae    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x156d, 0x269, x86_l_269);
x86_l_1573:
	/* 0x1573: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1579:
	/* 0x1579: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_157d:
	/* 0x157d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1582:
	/* 0x1582: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_1589:
	/* 0x1589: lea    rsi,[rsp+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_158e:
	/* 0x158e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1590:
	/* 0x1590: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1593:
	/* 0x1593: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1593, 0x20f6, x86_l_20f6);
x86_l_1599:
	/* 0x1599: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_159c:
	/* 0x159c: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_159f:
	/* 0x159f: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_15a4:
	/* 0x15a4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15a9:
	/* 0x15a9: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_15ae:
	/* 0x15ae: jmp    1b8c <generic_fexit_filter_arg+0x1b8c> */
	X86_SIM_X86_JMP(0x15ae, 0x1b8c, x86_l_1b8c);
x86_l_15b3:
	/* 0x15b3: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15b6:
	/* 0x15b6: je     1e47 <generic_fexit_filter_arg+0x1e47> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15b6, 0x1e47, x86_l_1e47);
x86_l_15bc:
	/* 0x15bc: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_15bf:
	/* 0x15bf: jne    1e54 <generic_fexit_filter_arg+0x1e54> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15bf, 0x1e54, x86_l_1e54);
x86_l_15c5:
	/* 0x15c5: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_15ca:
	/* 0x15ca: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_15cc:
	/* 0x15cc: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x15cc, 0x27a, x86_l_27a);
x86_l_15d2:
	/* 0x15d2: jmp    1e54 <generic_fexit_filter_arg+0x1e54> */
	X86_SIM_X86_JMP(0x15d2, 0x1e54, x86_l_1e54);
x86_l_15d7:
	/* 0x15d7: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15da:
	/* 0x15da: je     1e8e <generic_fexit_filter_arg+0x1e8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15da, 0x1e8e, x86_l_1e8e);
x86_l_15e0:
	/* 0x15e0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_15e3:
	/* 0x15e3: jne    1e9b <generic_fexit_filter_arg+0x1e9b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15e3, 0x1e9b, x86_l_1e9b);
x86_l_15e9:
	/* 0x15e9: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_15ee:
	/* 0x15ee: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_15f0:
	/* 0x15f0: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x15f0, 0x27a, x86_l_27a);
x86_l_15f6:
	/* 0x15f6: jmp    1e9b <generic_fexit_filter_arg+0x1e9b> */
	X86_SIM_X86_JMP(0x15f6, 0x1e9b, x86_l_1e9b);
x86_l_15fb:
	/* 0x15fb: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1601:
	/* 0x1601: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1605:
	/* 0x1605: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_160a:
	/* 0x160a: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_160f:
	/* 0x160f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_1616:
	/* 0x1616: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1618:
	/* 0x1618: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_161b:
	/* 0x161b: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x161b, 0x20f6, x86_l_20f6);
x86_l_1621:
	/* 0x1621: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1624:
	/* 0x1624: movzx  eax,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1629:
	/* 0x1629: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_162e:
	/* 0x162e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1633:
	/* 0x1633: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1638:
	/* 0x1638: jmp    1b8c <generic_fexit_filter_arg+0x1b8c> */
	X86_SIM_X86_JMP(0x1638, 0x1b8c, x86_l_1b8c);
x86_l_163d:
	/* 0x163d: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1643:
	/* 0x1643: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1647:
	/* 0x1647: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_164c:
	/* 0x164c: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1651:
	/* 0x1651: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_1658:
	/* 0x1658: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_165a:
	/* 0x165a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_165d:
	/* 0x165d: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x165d, 0x20f6, x86_l_20f6);
x86_l_1663:
	/* 0x1663: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1666:
	/* 0x1666: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_166b:
	/* 0x166b: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1670:
	/* 0x1670: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1675:
	/* 0x1675: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_167a:
	/* 0x167a: jmp    1b8c <generic_fexit_filter_arg+0x1b8c> */
	X86_SIM_X86_JMP(0x167a, 0x1b8c, x86_l_1b8c);
x86_l_167f:
	/* 0x167f: lea    eax,[r10-0x100] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_1686:
	/* 0x1686: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_168c:
	/* 0x168c: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_168f:
	/* 0x168f: jg     1e2a <generic_fexit_filter_arg+0x1e2a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x168f, 0x1e2a, x86_l_1e2a);
x86_l_1695:
	/* 0x1695: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1697:
	/* 0x1697: je     24c0 <generic_fexit_filter_arg+0x24c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1697, 0x24c0, x86_l_24c0);
x86_l_169d:
	/* 0x169d: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_16a0:
	/* 0x16a0: jne    24b8 <generic_fexit_filter_arg+0x24b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16a0, 0x24b8, x86_l_24b8);
x86_l_16a6:
	/* 0x16a6: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_16ac:
	/* 0x16ac: jmp    24ce <generic_fexit_filter_arg+0x24ce> */
	X86_SIM_X86_JMP(0x16ac, 0x24ce, x86_l_24ce);
x86_l_16b1:
	/* 0x16b1: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_16b4:
	/* 0x16b4: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16b6:
	/* 0x16b6: cmp    eax,0x400 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1024ULL);
x86_l_16bb:
	/* 0x16bb: setb   bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_B);
x86_l_16be:
	/* 0x16be: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x16be, 0x269, x86_l_269);
x86_l_16c3:
	/* 0x16c3: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_16c6:
	/* 0x16c6: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16c8:
	/* 0x16c8: cmp    eax,0x400 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1024ULL);
x86_l_16cd:
	/* 0x16cd: setae  bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_AE);
x86_l_16d0:
	/* 0x16d0: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x16d0, 0x269, x86_l_269);
x86_l_16d5:
	/* 0x16d5: mov    edx,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 256ULL);
x86_l_16da:
	/* 0x16da: cmp    eax,0x101 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 257ULL);
x86_l_16df:
	/* 0x16df: jb     170c <generic_fexit_filter_arg+0x170c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16df, 0x170c, x86_l_170c);
x86_l_16e1:
	/* 0x16e1: mov    edx,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 512ULL);
x86_l_16e6:
	/* 0x16e6: cmp    eax,0x201 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 513ULL);
x86_l_16eb:
	/* 0x16eb: jb     170c <generic_fexit_filter_arg+0x170c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16eb, 0x170c, x86_l_170c);
x86_l_16ed:
	/* 0x16ed: mov    edx,0x400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_16f2:
	/* 0x16f2: cmp    eax,0x401 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1025ULL);
x86_l_16f7:
	/* 0x16f7: jb     170c <generic_fexit_filter_arg+0x170c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16f7, 0x170c, x86_l_170c);
x86_l_16f9:
	/* 0x16f9: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16fb:
	/* 0x16fb: cmp    eax,0x801 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2049ULL);
x86_l_1700:
	/* 0x1700: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_1703:
	/* 0x1703: shl    edx,0xb */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_1706:
	/* 0x1706: add    edx,0x800 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_170c:
	/* 0x170c: lea    eax,[rdx-0x100] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_1712:
	/* 0x1712: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_1718:
	/* 0x1718: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_171b:
	/* 0x171b: jg     1d63 <generic_fexit_filter_arg+0x1d63> */
	X86_SIM_X86_JCC(X86_CC_G, 0x171b, 0x1d63, x86_l_1d63);
x86_l_1721:
	/* 0x1721: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1723:
	/* 0x1723: je     2298 <generic_fexit_filter_arg+0x2298> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1723, 0x2298, x86_l_2298);
x86_l_1729:
	/* 0x1729: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_172c:
	/* 0x172c: jne    2291 <generic_fexit_filter_arg+0x2291> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x172c, 0x2291, x86_l_2291);
x86_l_1732:
	/* 0x1732: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_1737:
	/* 0x1737: jmp    22a4 <generic_fexit_filter_arg+0x22a4> */
	X86_SIM_X86_JMP(0x1737, 0x22a4, x86_l_22a4);
x86_l_173c:
	/* 0x173c: mov    rbp,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R8, X86_WIDTH_64);
x86_l_173f:
	/* 0x173f: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
x86_l_1742:
	/* 0x1742: mov    eax,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1747:
	/* 0x1747: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_174b:
	/* 0x174b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1750:
	/* 0x1750: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&addr6lpm_maps));
x86_l_1757:
	/* 0x1757: lea    rsi,[rsp+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_175c:
	/* 0x175c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_175e:
	/* 0x175e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1761:
	/* 0x1761: je     1c0e <generic_fexit_filter_arg+0x1c0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1761, 0x1c0e, x86_l_1c0e);
x86_l_1767:
	/* 0x1767: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_176a:
	/* 0x176a: mov    DWORD PTR [rsp+0x70],0x80 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337280ULL);
x86_l_1772:
	/* 0x1772: mov    DWORD PTR [rsp+0x74],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1776:
	/* 0x1776: mov    DWORD PTR [rsp+0x78],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_177b:
	/* 0x177b: mov    DWORD PTR [rsp+0x7c],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_177f:
	/* 0x177f: shr    rbp,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1783:
	/* 0x1783: mov    DWORD PTR [rsp+0x80],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_178a:
	/* 0x178a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_178f:
	/* 0x178f: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1794:
	/* 0x1794: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1796:
	/* 0x1796: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_179b:
	/* 0x179b: lea    edx,[rcx-0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_179e:
	/* 0x179e: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_17a1:
	/* 0x17a1: jb     17d1 <generic_fexit_filter_arg+0x17d1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x17a1, 0x17d1, x86_l_17d1);
x86_l_17a3:
	/* 0x17a3: add    ecx,0xfffffff3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_17a6:
	/* 0x17a6: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_17a9:
	/* 0x17a9: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17ad:
	/* 0x17ad: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17b2:
	/* 0x17b2: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17b7:
	/* 0x17b7: ja     17c7 <generic_fexit_filter_arg+0x17c7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17b7, 0x17c7, x86_l_17c7);
x86_l_17b9:
	/* 0x17b9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17bc:
	/* 0x17bc: setne  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NE);
x86_l_17bf:
	/* 0x17bf: movzx  ebx,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_17c2:
	/* 0x17c2: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x17c2, 0x269, x86_l_269);
x86_l_17c7:
	/* 0x17c7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_17c9:
	/* 0x17c9: movzx  ebx,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_17cc:
	/* 0x17cc: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x17cc, 0x269, x86_l_269);
x86_l_17d1:
	/* 0x17d1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_17d4:
	/* 0x17d4: jmp    1c19 <generic_fexit_filter_arg+0x1c19> */
	X86_SIM_X86_JMP(0x17d4, 0x1c19, x86_l_1c19);
x86_l_17d9:
	/* 0x17d9: cmp    eax,0x1e */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 30ULL);
x86_l_17dc:
	/* 0x17dc: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17dc, 0xc2, x86_l_c2);
x86_l_17e2:
	/* 0x17e2: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17e7:
	/* 0x17e7: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_17ea:
	/* 0x17ea: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
x86_l_17ec:
	/* 0x17ec: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_17f5:
	/* 0x17f5: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17f5, 0xc2, x86_l_c2);
x86_l_17fb:
	/* 0x17fb: mov    rcx,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17ff:
	/* 0x17ff: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_1807:
	/* 0x1807: and    eax,0x7ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_180c:
	/* 0x180c: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_180e:
	/* 0x180e: andn   rax,rcx,QWORD PTR [r14+rax*1+0x90] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_R14)), 144ULL);
x86_l_1818:
	/* 0x1818: setne  bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_NE);
x86_l_181b:
	/* 0x181b: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x181b, 0x269, x86_l_269);
x86_l_1820:
	/* 0x1820: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1823:
	/* 0x1823: je     1fa0 <generic_fexit_filter_arg+0x1fa0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1823, 0x1fa0, x86_l_1fa0);
x86_l_1829:
	/* 0x1829: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_182e:
	/* 0x182e: cmp    eax,0x22 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 34ULL);
x86_l_1831:
	/* 0x1831: jne    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1831, 0x358b, x86_l_358b);
x86_l_1837:
	/* 0x1837: mov    r13d,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 16ULL);
x86_l_183d:
	/* 0x183d: mov    eax,DWORD PTR [r12+r13*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1841:
	/* 0x1841: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1845:
	/* 0x1845: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_184a:
	/* 0x184a: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_184f:
	/* 0x184f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&substring_map));
x86_l_1856:
	/* 0x1856: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1858:
	/* 0x1858: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_185b:
	/* 0x185b: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x185b, 0x357b, x86_l_357b);
x86_l_1861:
	/* 0x1861: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1866:
	/* 0x1866: mov    rsi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_1869:
	/* 0x1869: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_186c:
	/* 0x186c: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_35fb, 0x1871ULL);
x86_l_1871:
	/* 0x1871: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1873:
	/* 0x1873: jns    2c03 <generic_fexit_filter_arg+0x2c03> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1873, 0x2c03, x86_l_2c03);
x86_l_1879:
	/* 0x1879: add    r13,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_187d:
	/* 0x187d: lea    eax,[r13-0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_1881:
	/* 0x1881: cmp    eax,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1886:
	/* 0x1886: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_188a:
	/* 0x188a: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_188f:
	/* 0x188f: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1894:
	/* 0x1894: jae    299a <generic_fexit_filter_arg+0x299a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1894, 0x299a, x86_l_299a);
x86_l_189a:
	/* 0x189a: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_189f:
	/* 0x189f: cmp    r13,0x1a0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 416ULL);
x86_l_18a6:
	/* 0x18a6: jne    183d <generic_fexit_filter_arg+0x183d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18a6, 0x183d, x86_l_183d);
x86_l_18a8:
	/* 0x18a8: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x18a8, 0x358b, x86_l_358b);
x86_l_18ad:
	/* 0x18ad: mov    r13d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R8, X86_WIDTH_32);
x86_l_18b0:
	/* 0x18b0: mov    QWORD PTR [rsp+0x18],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18b5:
	/* 0x18b5: cmp    eax,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_18b8:
	/* 0x18b8: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18b8, 0xc2, x86_l_c2);
x86_l_18be:
	/* 0x18be: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18c3:
	/* 0x18c3: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_18c7:
	/* 0x18c7: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_18cf:
	/* 0x18cf: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_18d4:
	/* 0x18d4: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_18d9:
	/* 0x18d9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps));
x86_l_18e0:
	/* 0x18e0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_18e2:
	/* 0x18e2: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_18e5:
	/* 0x18e5: je     1bd6 <generic_fexit_filter_arg+0x1bd6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18e5, 0x1bd6, x86_l_1bd6);
x86_l_18eb:
	/* 0x18eb: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_18f0:
	/* 0x18f0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_18f3:
	/* 0x18f3: je     1bd8 <generic_fexit_filter_arg+0x1bd8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18f3, 0x1bd8, x86_l_1bd8);
x86_l_18f9:
	/* 0x18f9: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_18fc:
	/* 0x18fc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1901:
	/* 0x1901: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1906:
	/* 0x1906: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap));
x86_l_190d:
	/* 0x190d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_190f:
	/* 0x190f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1912:
	/* 0x1912: je     1bd6 <generic_fexit_filter_arg+0x1bd6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1912, 0x1bd6, x86_l_1bd6);
x86_l_1918:
	/* 0x1918: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_191a:
	/* 0x191a: shl    ecx,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_191d:
	/* 0x191d: mov    DWORD PTR [rax],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_191f:
	/* 0x191f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1922:
	/* 0x1922: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1926:
	/* 0x1926: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_1929:
	/* 0x1929: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_192e:
	/* 0x192e: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1933:
	/* 0x1933: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_1935:
	/* 0x1935: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1937:
	/* 0x1937: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_193c:
	/* 0x193c: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_193f:
	/* 0x193f: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_1942:
	/* 0x1942: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1944:
	/* 0x1944: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1946:
	/* 0x1946: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1949:
	/* 0x1949: setne  bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_NE);
x86_l_194c:
	/* 0x194c: jmp    1bd8 <generic_fexit_filter_arg+0x1bd8> */
	X86_SIM_X86_JMP(0x194c, 0x1bd8, x86_l_1bd8);
x86_l_1951:
	/* 0x1951: movzx  ebx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1956:
	/* 0x1956: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_195c:
	/* 0x195c: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1960:
	/* 0x1960: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1965:
	/* 0x1965: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_196a:
	/* 0x196a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_1971:
	/* 0x1971: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1973:
	/* 0x1973: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1976:
	/* 0x1976: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1976, 0x20f6, x86_l_20f6);
x86_l_197c:
	/* 0x197c: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_197f:
	/* 0x197f: mov    QWORD PTR [rsp+0x38],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1984:
	/* 0x1984: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1989:
	/* 0x1989: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_198e:
	/* 0x198e: jmp    1b8c <generic_fexit_filter_arg+0x1b8c> */
	X86_SIM_X86_JMP(0x198e, 0x1b8c, x86_l_1b8c);
x86_l_1993:
	/* 0x1993: mov    eax,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1998:
	/* 0x1998: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_199c:
	/* 0x199c: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_19a4:
	/* 0x19a4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_19a9:
	/* 0x19a9: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_19ae:
	/* 0x19ae: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps));
x86_l_19b5:
	/* 0x19b5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_19b7:
	/* 0x19b7: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_19b9:
	/* 0x19b9: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19b9, 0x357b, x86_l_357b);
x86_l_19bf:
	/* 0x19bf: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_19c2:
	/* 0x19c2: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_19c7:
	/* 0x19c7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19ca:
	/* 0x19ca: je     357d <generic_fexit_filter_arg+0x357d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ca, 0x357d, x86_l_357d);
x86_l_19d0:
	/* 0x19d0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_19d5:
	/* 0x19d5: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19da:
	/* 0x19da: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap));
x86_l_19e1:
	/* 0x19e1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_19e3:
	/* 0x19e3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19e6:
	/* 0x19e6: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19e6, 0x357b, x86_l_357b);
x86_l_19ec:
	/* 0x19ec: cmp    ebp,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 255ULL);
x86_l_19f2:
	/* 0x19f2: mov    ecx,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 255ULL);
x86_l_19f7:
	/* 0x19f7: cmovae ebp,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RBP, X86_RCX, X86_WIDTH_32, X86_CC_AE);
x86_l_19fa:
	/* 0x19fa: lea    ecx,[rbp*8+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 3), 0ULL);
x86_l_1a01:
	/* 0x1a01: mov    DWORD PTR [rax],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a03:
	/* 0x1a03: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1a06:
	/* 0x1a06: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1a0a:
	/* 0x1a0a: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_1a0d:
	/* 0x1a0d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1a12:
	/* 0x1a12: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a17:
	/* 0x1a17: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_1a19:
	/* 0x1a19: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1a1b:
	/* 0x1a1b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1a20:
	/* 0x1a20: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1a23:
	/* 0x1a23: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_1a26:
	/* 0x1a26: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1a28:
	/* 0x1a28: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1a2a:
	/* 0x1a2a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1a2d:
	/* 0x1a2d: setne  bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_NE);
x86_l_1a30:
	/* 0x1a30: jmp    357d <generic_fexit_filter_arg+0x357d> */
	X86_SIM_X86_JMP(0x1a30, 0x357d, x86_l_357d);
x86_l_1a35:
	/* 0x1a35: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_1a3d:
	/* 0x1a3d: cmp    ebp,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 4096ULL);
x86_l_1a43:
	/* 0x1a43: ja     299a <generic_fexit_filter_arg+0x299a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1a43, 0x299a, x86_l_299a);
x86_l_1a49:
	/* 0x1a49: movzx  eax,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1a4c:
	/* 0x1a4c: cmp    eax,0x90 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 144ULL);
x86_l_1a51:
	/* 0x1a51: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a56:
	/* 0x1a56: ja     26d8 <generic_fexit_filter_arg+0x26d8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1a56, 0x26d8, x86_l_26d8);
x86_l_1a5c:
	/* 0x1a5c: movzx  eax,bpl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1a60:
	/* 0x1a60: imul   ecx,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RCX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_1a66:
	/* 0x1a66: shr    ecx,0x9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_1a69:
	/* 0x1a69: and    ecx,0xfffffff8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1a6c:
	/* 0x1a6c: lea    ecx,[rcx+rcx*2] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_1a6f:
	/* 0x1a6f: sub    al,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_1a71:
	/* 0x1a71: test   bp,bp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_16);
x86_l_1a74:
	/* 0x1a74: je     1a7e <generic_fexit_filter_arg+0x1a7e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a74, 0x1a7e, x86_l_1a7e);
x86_l_1a76:
	/* 0x1a76: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_1a78:
	/* 0x1a78: mov    edx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_32);
x86_l_1a7a:
	/* 0x1a7a: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_1a7c:
	/* 0x1a7c: je     1a99 <generic_fexit_filter_arg+0x1a99> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a7c, 0x1a99, x86_l_1a99);
x86_l_1a7e:
	/* 0x1a7e: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1a81:
	/* 0x1a81: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
x86_l_1a83:
	/* 0x1a83: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1a85:
	/* 0x1a85: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_1a87:
	/* 0x1a87: add    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_1a8a:
	/* 0x1a8a: movzx  edx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1a8d:
	/* 0x1a8d: cmp    cx,0x78 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_16, 120ULL);
x86_l_1a91:
	/* 0x1a91: ja     270f <generic_fexit_filter_arg+0x270f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1a91, 0x270f, x86_l_270f);
x86_l_1a97:
	/* 0x1a97: mov    ecx,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_1a99:
	/* 0x1a99: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1a9c:
	/* 0x1a9c: imul   ecx,eax,0xab */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RCX, X86_RAX, X86_WIDTH_32, 171ULL);
x86_l_1aa2:
	/* 0x1aa2: shr    ecx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_1aa5:
	/* 0x1aa5: dec    ecx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1aa7:
	/* 0x1aa7: jmp    2f81 <generic_fexit_filter_arg+0x2f81> */
	X86_SIM_X86_JMP(0x1aa7, 0x2f81, x86_l_2f81);
x86_l_1aac:
	/* 0x1aac: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab0:
	/* 0x1ab0: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_1ab3:
	/* 0x1ab3: ja     1abe <generic_fexit_filter_arg+0x1abe> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ab3, 0x1abe, x86_l_1abe);
x86_l_1ab5:
	/* 0x1ab5: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_1ab8:
	/* 0x1ab8: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1ab8, 0x27a, x86_l_27a);
x86_l_1abe:
	/* 0x1abe: mov    edx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ac3:
	/* 0x1ac3: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1ac6:
	/* 0x1ac6: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ac6, 0xc2, x86_l_c2);
x86_l_1acc:
	/* 0x1acc: mov    rdi,QWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ad1:
	/* 0x1ad1: mov    rsi,QWORD PTR [r12+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ad6:
	/* 0x1ad6: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1ad9:
	/* 0x1ad9: je     1ae4 <generic_fexit_filter_arg+0x1ae4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ad9, 0x1ae4, x86_l_1ae4);
x86_l_1adb:
	/* 0x1adb: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_1ade:
	/* 0x1ade: jne    2117 <generic_fexit_filter_arg+0x2117> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ade, 0x2117, x86_l_2117);
x86_l_1ae4:
	/* 0x1ae4: cmp    rdi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1ae7:
	/* 0x1ae7: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aeb:
	/* 0x1aeb: jg     2129 <generic_fexit_filter_arg+0x2129> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1aeb, 0x2129, x86_l_2129);
x86_l_1af1:
	/* 0x1af1: cmp    rax,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64);
x86_l_1af4:
	/* 0x1af4: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1af4, 0x27a, x86_l_27a);
x86_l_1afa:
	/* 0x1afa: jmp    2129 <generic_fexit_filter_arg+0x2129> */
	X86_SIM_X86_JMP(0x1afa, 0x2129, x86_l_2129);
x86_l_1aff:
	/* 0x1aff: mov    rdx,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b03:
	/* 0x1b03: cmp    rsi,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_1b06:
	/* 0x1b06: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_1b0a:
	/* 0x1b0a: cmp    rdx,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_1b0d:
	/* 0x1b0d: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_1b10:
	/* 0x1b10: and    al,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_8, X86_ALU_AND);
x86_l_1b13:
	/* 0x1b13: mov    esi,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b18:
	/* 0x1b18: cmp    esi,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 25ULL);
x86_l_1b1b:
	/* 0x1b1b: jb     2dfb <generic_fexit_filter_arg+0x2dfb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b1b, 0x2dfb, x86_l_2dfb);
x86_l_1b21:
	/* 0x1b21: mov    r8,QWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b26:
	/* 0x1b26: mov    rdi,QWORD PTR [r12+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b2b:
	/* 0x1b2b: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1b2e:
	/* 0x1b2e: je     1b39 <generic_fexit_filter_arg+0x1b39> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b2e, 0x1b39, x86_l_1b39);
x86_l_1b30:
	/* 0x1b30: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_1b33:
	/* 0x1b33: jne    2055 <generic_fexit_filter_arg+0x2055> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b33, 0x2055, x86_l_2055);
x86_l_1b39:
	/* 0x1b39: cmp    r8,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_64);
x86_l_1b3c:
	/* 0x1b3c: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1b40:
	/* 0x1b40: cmp    rdx,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_1b43:
	/* 0x1b43: setle  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_LE);
x86_l_1b47:
	/* 0x1b47: jmp    2063 <generic_fexit_filter_arg+0x2063> */
	X86_SIM_X86_JMP(0x1b47, 0x2063, x86_l_2063);
x86_l_1b4c:
	/* 0x1b4c: movzx  ebx,WORD PTR [r13+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_1b51:
	/* 0x1b51: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1b57:
	/* 0x1b57: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1b5b:
	/* 0x1b5b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1b60:
	/* 0x1b60: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_1b67:
	/* 0x1b67: lea    rsi,[rsp+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1b6c:
	/* 0x1b6c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1b6e:
	/* 0x1b6e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1b71:
	/* 0x1b71: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b71, 0x20f6, x86_l_20f6);
x86_l_1b77:
	/* 0x1b77: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1b7a:
	/* 0x1b7a: movzx  eax,bx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1b7d:
	/* 0x1b7d: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1b82:
	/* 0x1b82: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1b87:
	/* 0x1b87: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b8c:
	/* 0x1b8c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1b8e:
	/* 0x1b8e: mov    edx,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b93:
	/* 0x1b93: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1b95:
	/* 0x1b95: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_1b98:
	/* 0x1b98: ja     2165 <generic_fexit_filter_arg+0x2165> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1b98, 0x2165, x86_l_2165);
x86_l_1b9e:
	/* 0x1b9e: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_1ba3:
	/* 0x1ba3: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1ba6:
	/* 0x1ba6: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1baa:
	/* 0x1baa: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1baf:
	/* 0x1baf: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bb4:
	/* 0x1bb4: jae    1bbe <generic_fexit_filter_arg+0x1bbe> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1bb4, 0x1bbe, x86_l_1bbe);
x86_l_1bb6:
	/* 0x1bb6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1bb9:
	/* 0x1bb9: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_1bbc:
	/* 0x1bbc: jmp    1bce <generic_fexit_filter_arg+0x1bce> */
	X86_SIM_X86_JMP(0x1bbc, 0x1bce, x86_l_1bce);
x86_l_1bbe:
	/* 0x1bbe: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_1bc3:
	/* 0x1bc3: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1bc6:
	/* 0x1bc6: jae    1bce <generic_fexit_filter_arg+0x1bce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1bc6, 0x1bce, x86_l_1bce);
x86_l_1bc8:
	/* 0x1bc8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1bcb:
	/* 0x1bcb: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_1bce:
	/* 0x1bce: movzx  ebx,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1bd1:
	/* 0x1bd1: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x1bd1, 0x269, x86_l_269);
x86_l_1bd6:
	/* 0x1bd6: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1bd8:
	/* 0x1bd8: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bdd:
	/* 0x1bdd: cmp    rax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 37ULL);
x86_l_1be1:
	/* 0x1be1: ja     20f8 <generic_fexit_filter_arg+0x20f8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1be1, 0x20f8, x86_l_20f8);
x86_l_1be7:
	/* 0x1be7: movabs rcx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 137640280144ULL);
x86_l_1bf1:
	/* 0x1bf1: bt     rcx,rax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1bf5:
	/* 0x1bf5: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf9:
	/* 0x1bf9: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bfe:
	/* 0x1bfe: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c03:
	/* 0x1c03: jb     3212 <generic_fexit_filter_arg+0x3212> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c03, 0x3212, x86_l_3212);
x86_l_1c09:
	/* 0x1c09: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x1c09, 0x269, x86_l_269);
x86_l_1c0e:
	/* 0x1c0e: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c13:
	/* 0x1c13: and    eax,0xfffffffe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_1c16:
	/* 0x1c16: cmp    eax,0x18 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 24ULL);
x86_l_1c19:
	/* 0x1c19: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1c1c:
	/* 0x1c1c: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c20:
	/* 0x1c20: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c25:
	/* 0x1c25: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c2a:
	/* 0x1c2a: movzx  ebx,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1c2d:
	/* 0x1c2d: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x1c2d, 0x269, x86_l_269);
x86_l_1c32:
	/* 0x1c32: mov    edx,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 256ULL);
x86_l_1c37:
	/* 0x1c37: cmp    eax,0x101 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 257ULL);
x86_l_1c3c:
	/* 0x1c3c: jb     1c69 <generic_fexit_filter_arg+0x1c69> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c3c, 0x1c69, x86_l_1c69);
x86_l_1c3e:
	/* 0x1c3e: mov    edx,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 512ULL);
x86_l_1c43:
	/* 0x1c43: cmp    eax,0x201 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 513ULL);
x86_l_1c48:
	/* 0x1c48: jb     1c69 <generic_fexit_filter_arg+0x1c69> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c48, 0x1c69, x86_l_1c69);
x86_l_1c4a:
	/* 0x1c4a: mov    edx,0x400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_1c4f:
	/* 0x1c4f: cmp    eax,0x401 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1025ULL);
x86_l_1c54:
	/* 0x1c54: jb     1c69 <generic_fexit_filter_arg+0x1c69> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c54, 0x1c69, x86_l_1c69);
x86_l_1c56:
	/* 0x1c56: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1c58:
	/* 0x1c58: cmp    eax,0x801 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2049ULL);
x86_l_1c5d:
	/* 0x1c5d: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_1c60:
	/* 0x1c60: shl    edx,0xb */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_1c63:
	/* 0x1c63: add    edx,0x800 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_1c69:
	/* 0x1c69: lea    eax,[rdx-0x100] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_1c6f:
	/* 0x1c6f: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_1c75:
	/* 0x1c75: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1c78:
	/* 0x1c78: jg     1f84 <generic_fexit_filter_arg+0x1f84> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1c78, 0x1f84, x86_l_1f84);
x86_l_1c7e:
	/* 0x1c7e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1c80:
	/* 0x1c80: je     28c9 <generic_fexit_filter_arg+0x28c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c80, 0x28c9, x86_l_28c9);
x86_l_1c86:
	/* 0x1c86: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1c89:
	/* 0x1c89: jne    28c2 <generic_fexit_filter_arg+0x28c2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c89, 0x28c2, x86_l_28c2);
x86_l_1c8f:
	/* 0x1c8f: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_1c94:
	/* 0x1c94: jmp    28d5 <generic_fexit_filter_arg+0x28d5> */
	X86_SIM_X86_JMP(0x1c94, 0x28d5, x86_l_28d5);
x86_l_1c99:
	/* 0x1c99: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c9d:
	/* 0x1c9d: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1c9d, 0x27a, x86_l_27a);
x86_l_1ca3:
	/* 0x1ca3: jmp    1caf <generic_fexit_filter_arg+0x1caf> */
	X86_SIM_X86_JMP(0x1ca3, 0x1caf, x86_l_1caf);
x86_l_1ca5:
	/* 0x1ca5: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca9:
	/* 0x1ca9: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ca9, 0x27a, x86_l_27a);
x86_l_1caf:
	/* 0x1caf: mov    edx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cb4:
	/* 0x1cb4: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1cb7:
	/* 0x1cb7: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cb7, 0x35ea, x86_l_35ea);
x86_l_1cbd:
	/* 0x1cbd: mov    rsi,QWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cc2:
	/* 0x1cc2: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1cc5:
	/* 0x1cc5: jle    1ce2 <generic_fexit_filter_arg+0x1ce2> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1cc5, 0x1ce2, x86_l_1ce2);
x86_l_1cc7:
	/* 0x1cc7: lea    edi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1cca:
	/* 0x1cca: cmp    edi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_1ccd:
	/* 0x1ccd: jae    1d11 <generic_fexit_filter_arg+0x1d11> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ccd, 0x1d11, x86_l_1d11);
x86_l_1ccf:
	/* 0x1ccf: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd3:
	/* 0x1cd3: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd7:
	/* 0x1cd7: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd7, 0x261, x86_l_261);
x86_l_1cdd:
	/* 0x1cdd: jmp    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JMP(0x1cdd, 0x27e2, x86_l_27e2);
x86_l_1ce2:
	/* 0x1ce2: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ce5:
	/* 0x1ce5: je     1d7f <generic_fexit_filter_arg+0x1d7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce5, 0x1d7f, x86_l_1d7f);
x86_l_1ceb:
	/* 0x1ceb: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1cee:
	/* 0x1cee: jne    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cee, 0x27e2, x86_l_27e2);
x86_l_1cf4:
	/* 0x1cf4: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1cf7:
	/* 0x1cf7: je     1d02 <generic_fexit_filter_arg+0x1d02> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cf7, 0x1d02, x86_l_1d02);
x86_l_1cf9:
	/* 0x1cf9: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_1cfc:
	/* 0x1cfc: jne    27d8 <generic_fexit_filter_arg+0x27d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cfc, 0x27d8, x86_l_27d8);
x86_l_1d02:
	/* 0x1d02: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d06:
	/* 0x1d06: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d06, 0x27a, x86_l_27a);
x86_l_1d0c:
	/* 0x1d0c: jmp    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JMP(0x1d0c, 0x27e2, x86_l_27e2);
x86_l_1d11:
	/* 0x1d11: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1d14:
	/* 0x1d14: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d18:
	/* 0x1d18: jne    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d18, 0x27e2, x86_l_27e2);
x86_l_1d1e:
	/* 0x1d1e: test   QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d22:
	/* 0x1d22: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d22, 0x27a, x86_l_27a);
x86_l_1d28:
	/* 0x1d28: jmp    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JMP(0x1d28, 0x27e2, x86_l_27e2);
x86_l_1d2d:
	/* 0x1d2d: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1d30:
	/* 0x1d30: jne    1e54 <generic_fexit_filter_arg+0x1e54> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d30, 0x1e54, x86_l_1e54);
x86_l_1d36:
	/* 0x1d36: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1d3b:
	/* 0x1d3b: test   ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_1d3d:
	/* 0x1d3d: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d3d, 0x27a, x86_l_27a);
x86_l_1d43:
	/* 0x1d43: jmp    1e54 <generic_fexit_filter_arg+0x1e54> */
	X86_SIM_X86_JMP(0x1d43, 0x1e54, x86_l_1e54);
x86_l_1d48:
	/* 0x1d48: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1d4b:
	/* 0x1d4b: jne    1e9b <generic_fexit_filter_arg+0x1e9b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d4b, 0x1e9b, x86_l_1e9b);
x86_l_1d51:
	/* 0x1d51: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1d56:
	/* 0x1d56: test   ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_1d58:
	/* 0x1d58: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d58, 0x27a, x86_l_27a);
x86_l_1d5e:
	/* 0x1d5e: jmp    1e9b <generic_fexit_filter_arg+0x1e9b> */
	X86_SIM_X86_JMP(0x1d5e, 0x1e9b, x86_l_1e9b);
x86_l_1d63:
	/* 0x1d63: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_1d66:
	/* 0x1d66: je     229f <generic_fexit_filter_arg+0x229f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d66, 0x229f, x86_l_229f);
x86_l_1d6c:
	/* 0x1d6c: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_1d6f:
	/* 0x1d6f: jne    2291 <generic_fexit_filter_arg+0x2291> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d6f, 0x2291, x86_l_2291);
x86_l_1d75:
	/* 0x1d75: mov    ecx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_1d7a:
	/* 0x1d7a: jmp    22a4 <generic_fexit_filter_arg+0x22a4> */
	X86_SIM_X86_JMP(0x1d7a, 0x22a4, x86_l_22a4);
x86_l_1d7f:
	/* 0x1d7f: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1d82:
	/* 0x1d82: je     1d8d <generic_fexit_filter_arg+0x1d8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d82, 0x1d8d, x86_l_1d8d);
x86_l_1d84:
	/* 0x1d84: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_1d87:
	/* 0x1d87: jne    27cc <generic_fexit_filter_arg+0x27cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d87, 0x27cc, x86_l_27cc);
x86_l_1d8d:
	/* 0x1d8d: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d91:
	/* 0x1d91: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1d91, 0x27a, x86_l_27a);
x86_l_1d97:
	/* 0x1d97: jmp    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JMP(0x1d97, 0x27e2, x86_l_27e2);
x86_l_1d9c:
	/* 0x1d9c: mov    edx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1da1:
	/* 0x1da1: movzx  ecx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1da6:
	/* 0x1da6: jmp    1db2 <generic_fexit_filter_arg+0x1db2> */
	X86_SIM_X86_JMP(0x1da6, 0x1db2, x86_l_1db2);
x86_l_1da8:
	/* 0x1da8: mov    edx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dad:
	/* 0x1dad: movzx  ecx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1db2:
	/* 0x1db2: cmp    DWORD PTR [r12+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1db7:
	/* 0x1db7: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_1dbb:
	/* 0x1dbb: cmp    DWORD PTR [r12+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1dc0:
	/* 0x1dc0: setae  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_AE);
x86_l_1dc3:
	/* 0x1dc3: and    al,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_8, X86_ALU_AND);
x86_l_1dc6:
	/* 0x1dc6: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1dc9:
	/* 0x1dc9: jb     2dfb <generic_fexit_filter_arg+0x2dfb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1dc9, 0x2dfb, x86_l_2dfb);
x86_l_1dcf:
	/* 0x1dcf: cmp    DWORD PTR [r12+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1dd4:
	/* 0x1dd4: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_1dd8:
	/* 0x1dd8: cmp    DWORD PTR [r12+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1ddd:
	/* 0x1ddd: setae  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_AE);
x86_l_1de1:
	/* 0x1de1: and    dil,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_8, X86_ALU_AND);
x86_l_1de4:
	/* 0x1de4: or     al,dil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_8, X86_ALU_OR);
x86_l_1de7:
	/* 0x1de7: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1dea:
	/* 0x1dea: jb     2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1dea, 0x2df7, x86_l_2df7);
x86_l_1df0:
	/* 0x1df0: cmp    DWORD PTR [r12+0x20],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1df5:
	/* 0x1df5: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_1df9:
	/* 0x1df9: cmp    DWORD PTR [r12+0x24],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1dfe:
	/* 0x1dfe: setae  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_AE);
x86_l_1e02:
	/* 0x1e02: and    dil,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_8, X86_ALU_AND);
x86_l_1e05:
	/* 0x1e05: or     al,dil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_8, X86_ALU_OR);
x86_l_1e08:
	/* 0x1e08: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1e0b:
	/* 0x1e0b: jb     2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e0b, 0x2df7, x86_l_2df7);
x86_l_1e11:
	/* 0x1e11: cmp    DWORD PTR [r12+0x28],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1e16:
	/* 0x1e16: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_1e19:
	/* 0x1e19: cmp    DWORD PTR [r12+0x2c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1e1e:
	/* 0x1e1e: setae  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_AE);
x86_l_1e21:
	/* 0x1e21: and    cl,dl */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1e23:
	/* 0x1e23: or     al,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_OR);
x86_l_1e25:
	/* 0x1e25: jmp    2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JMP(0x1e25, 0x2df7, x86_l_2df7);
x86_l_1e2a:
	/* 0x1e2a: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_1e2d:
	/* 0x1e2d: je     24c8 <generic_fexit_filter_arg+0x24c8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e2d, 0x24c8, x86_l_24c8);
x86_l_1e33:
	/* 0x1e33: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_1e36:
	/* 0x1e36: jne    24b8 <generic_fexit_filter_arg+0x24b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e36, 0x24b8, x86_l_24b8);
x86_l_1e3c:
	/* 0x1e3c: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_1e42:
	/* 0x1e42: jmp    24ce <generic_fexit_filter_arg+0x24ce> */
	X86_SIM_X86_JMP(0x1e42, 0x24ce, x86_l_24ce);
x86_l_1e47:
	/* 0x1e47: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1e4c:
	/* 0x1e4c: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_1e4e:
	/* 0x1e4e: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e4e, 0x27a, x86_l_27a);
x86_l_1e54:
	/* 0x1e54: mov    ecx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e59:
	/* 0x1e59: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_1e5c:
	/* 0x1e5c: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e5c, 0x35ea, x86_l_35ea);
x86_l_1e62:
	/* 0x1e62: mov    edx,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1e67:
	/* 0x1e67: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1e6a:
	/* 0x1e6a: jle    223b <generic_fexit_filter_arg+0x223b> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1e6a, 0x223b, x86_l_223b);
x86_l_1e70:
	/* 0x1e70: lea    esi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1e73:
	/* 0x1e73: cmp    esi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1e76:
	/* 0x1e76: jae    285b <generic_fexit_filter_arg+0x285b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1e76, 0x285b, x86_l_285b);
x86_l_1e7c:
	/* 0x1e7c: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1e81:
	/* 0x1e81: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_1e83:
	/* 0x1e83: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e83, 0x261, x86_l_261);
x86_l_1e89:
	/* 0x1e89: jmp    2ae6 <generic_fexit_filter_arg+0x2ae6> */
	X86_SIM_X86_JMP(0x1e89, 0x2ae6, x86_l_2ae6);
x86_l_1e8e:
	/* 0x1e8e: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1e93:
	/* 0x1e93: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_1e95:
	/* 0x1e95: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e95, 0x27a, x86_l_27a);
x86_l_1e9b:
	/* 0x1e9b: mov    ecx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ea0:
	/* 0x1ea0: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_1ea3:
	/* 0x1ea3: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ea3, 0x35ea, x86_l_35ea);
x86_l_1ea9:
	/* 0x1ea9: mov    edx,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1eae:
	/* 0x1eae: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1eb1:
	/* 0x1eb1: jle    225f <generic_fexit_filter_arg+0x225f> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1eb1, 0x225f, x86_l_225f);
x86_l_1eb7:
	/* 0x1eb7: lea    esi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1eba:
	/* 0x1eba: cmp    esi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1ebd:
	/* 0x1ebd: jae    2876 <generic_fexit_filter_arg+0x2876> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ebd, 0x2876, x86_l_2876);
x86_l_1ec3:
	/* 0x1ec3: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ec8:
	/* 0x1ec8: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_1eca:
	/* 0x1eca: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eca, 0x261, x86_l_261);
x86_l_1ed0:
	/* 0x1ed0: jmp    2b28 <generic_fexit_filter_arg+0x2b28> */
	X86_SIM_X86_JMP(0x1ed0, 0x2b28, x86_l_2b28);
x86_l_1ed5:
	/* 0x1ed5: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ed9:
	/* 0x1ed9: cmp    esi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_32);
x86_l_1edb:
	/* 0x1edb: ja     1ee5 <generic_fexit_filter_arg+0x1ee5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1edb, 0x1ee5, x86_l_1ee5);
x86_l_1edd:
	/* 0x1edd: cmp    eax,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32);
x86_l_1edf:
	/* 0x1edf: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1edf, 0x27a, x86_l_27a);
x86_l_1ee5:
	/* 0x1ee5: mov    edx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eea:
	/* 0x1eea: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1eed:
	/* 0x1eed: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1eed, 0xc2, x86_l_c2);
x86_l_1ef3:
	/* 0x1ef3: mov    edi,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ef8:
	/* 0x1ef8: mov    esi,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1efd:
	/* 0x1efd: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1f00:
	/* 0x1f00: ja     2683 <generic_fexit_filter_arg+0x2683> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1f00, 0x2683, x86_l_2683);
x86_l_1f06:
	/* 0x1f06: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_1f0c:
	/* 0x1f0c: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_1f10:
	/* 0x1f10: jae    2683 <generic_fexit_filter_arg+0x2683> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1f10, 0x2683, x86_l_2683);
x86_l_1f16:
	/* 0x1f16: cmp    edi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_32);
x86_l_1f18:
	/* 0x1f18: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f1c:
	/* 0x1f1c: jg     2693 <generic_fexit_filter_arg+0x2693> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1f1c, 0x2693, x86_l_2693);
x86_l_1f22:
	/* 0x1f22: cmp    eax,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_1f24:
	/* 0x1f24: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1f24, 0x27a, x86_l_27a);
x86_l_1f2a:
	/* 0x1f2a: jmp    2693 <generic_fexit_filter_arg+0x2693> */
	X86_SIM_X86_JMP(0x1f2a, 0x2693, x86_l_2693);
x86_l_1f2f:
	/* 0x1f2f: mov    edx,DWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f33:
	/* 0x1f33: cmp    esi,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1f35:
	/* 0x1f35: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_1f39:
	/* 0x1f39: cmp    edx,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1f3b:
	/* 0x1f3b: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_1f3e:
	/* 0x1f3e: and    al,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_8, X86_ALU_AND);
x86_l_1f41:
	/* 0x1f41: mov    esi,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f46:
	/* 0x1f46: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_1f49:
	/* 0x1f49: jb     2dfb <generic_fexit_filter_arg+0x2dfb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f49, 0x2dfb, x86_l_2dfb);
x86_l_1f4f:
	/* 0x1f4f: mov    r8d,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f54:
	/* 0x1f54: mov    edi,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1f59:
	/* 0x1f59: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1f5c:
	/* 0x1f5c: ja     2460 <generic_fexit_filter_arg+0x2460> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1f5c, 0x2460, x86_l_2460);
x86_l_1f62:
	/* 0x1f62: mov    r10d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 5122ULL);
x86_l_1f68:
	/* 0x1f68: bt     r10d,ecx */
	X86_SIM_L_EXEC_BT(X86_R10, X86_RCX, X86_WIDTH_32);
x86_l_1f6c:
	/* 0x1f6c: jae    2460 <generic_fexit_filter_arg+0x2460> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1f6c, 0x2460, x86_l_2460);
x86_l_1f72:
	/* 0x1f72: cmp    r8d,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_32);
x86_l_1f75:
	/* 0x1f75: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1f79:
	/* 0x1f79: cmp    edx,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_32);
x86_l_1f7b:
	/* 0x1f7b: setle  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_LE);
x86_l_1f7f:
	/* 0x1f7f: jmp    246d <generic_fexit_filter_arg+0x246d> */
	X86_SIM_X86_JMP(0x1f7f, 0x246d, x86_l_246d);
x86_l_1f84:
	/* 0x1f84: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_1f87:
	/* 0x1f87: je     28d0 <generic_fexit_filter_arg+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f87, 0x28d0, x86_l_28d0);
x86_l_1f8d:
	/* 0x1f8d: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_1f90:
	/* 0x1f90: jne    28c2 <generic_fexit_filter_arg+0x28c2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f90, 0x28c2, x86_l_28c2);
x86_l_1f96:
	/* 0x1f96: mov    ecx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_1f9b:
	/* 0x1f9b: jmp    28d5 <generic_fexit_filter_arg+0x28d5> */
	X86_SIM_X86_JMP(0x1f9b, 0x28d5, x86_l_28d5);
x86_l_1fa0:
	/* 0x1fa0: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fa2:
	/* 0x1fa2: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fa5:
	/* 0x1fa5: mov    eax,DWORD PTR [r12+rbx*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_1faa:
	/* 0x1faa: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1fae:
	/* 0x1fae: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1fb3:
	/* 0x1fb3: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1fb8:
	/* 0x1fb8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&substring_map));
x86_l_1fbf:
	/* 0x1fbf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1fc1:
	/* 0x1fc1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1fc4:
	/* 0x1fc4: je     2040 <generic_fexit_filter_arg+0x2040> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fc4, 0x2040, x86_l_2040);
x86_l_1fc6:
	/* 0x1fc6: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_1fc8:
	/* 0x1fc8: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fcd:
	/* 0x1fcd: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fd2:
	/* 0x1fd2: je     2019 <generic_fexit_filter_arg+0x2019> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd2, 0x2019, x86_l_2019);
x86_l_1fd4:
	/* 0x1fd4: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1fd9:
	/* 0x1fd9: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fdb:
	/* 0x1fdb: jmp    1fe8 <generic_fexit_filter_arg+0x1fe8> */
	X86_SIM_X86_JMP(0x1fdb, 0x1fe8, x86_l_1fe8);
x86_l_1fdd:
	/* 0x1fdd: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1fe0:
	/* 0x1fe0: inc    rdx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1fe3:
	/* 0x1fe3: cmp    rcx,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_1fe6:
	/* 0x1fe6: je     2019 <generic_fexit_filter_arg+0x2019> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe6, 0x2019, x86_l_2019);
x86_l_1fe8:
	/* 0x1fe8: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fea:
	/* 0x1fea: lea    rdi,[rcx+rsi*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1fee:
	/* 0x1fee: cmp    rdi,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_1ff1:
	/* 0x1ff1: jae    1fdd <generic_fexit_filter_arg+0x1fdd> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ff1, 0x1fdd, x86_l_1fdd);
x86_l_1ff3:
	/* 0x1ff3: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1ff7:
	/* 0x1ff7: test   dil,dil */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8);
x86_l_1ffa:
	/* 0x1ffa: je     2011 <generic_fexit_filter_arg+0x2011> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ffa, 0x2011, x86_l_2011);
x86_l_1ffc:
	/* 0x1ffc: cmp    rsi,0x62 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 98ULL);
x86_l_2000:
	/* 0x2000: ja     1fdd <generic_fexit_filter_arg+0x1fdd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2000, 0x1fdd, x86_l_1fdd);
x86_l_2002:
	/* 0x2002: lea    r8,[rsi+0x1] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2006:
	/* 0x2006: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_200a:
	/* 0x200a: mov    rsi,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R8, X86_WIDTH_64);
x86_l_200d:
	/* 0x200d: je     1fea <generic_fexit_filter_arg+0x1fea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x200d, 0x1fea, x86_l_1fea);
x86_l_200f:
	/* 0x200f: jmp    1fdd <generic_fexit_filter_arg+0x1fdd> */
	X86_SIM_X86_JMP(0x200f, 0x1fdd, x86_l_1fdd);
x86_l_2011:
	/* 0x2011: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_2013:
	/* 0x2013: jns    2283 <generic_fexit_filter_arg+0x2283> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2013, 0x2283, x86_l_2283);
x86_l_2019:
	/* 0x2019: lea    eax,[r13+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_201d:
	/* 0x201d: cmp    eax,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_2022:
	/* 0x2022: jae    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2022, 0x2035, x86_l_2035);
x86_l_2024:
	/* 0x2024: add    r13d,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_2028:
	/* 0x2028: inc    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_202b:
	/* 0x202b: cmp    rbx,0x64 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 100ULL);
x86_l_202f:
	/* 0x202f: jne    1fa5 <generic_fexit_filter_arg+0x1fa5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x202f, 0x1fa5, x86_l_1fa5);
x86_l_2035:
	/* 0x2035: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2037:
	/* 0x2037: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203b:
	/* 0x203b: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x203b, 0x358b, x86_l_358b);
x86_l_2040:
	/* 0x2040: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2042:
	/* 0x2042: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2047:
	/* 0x2047: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_204c:
	/* 0x204c: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2050:
	/* 0x2050: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x2050, 0x358b, x86_l_358b);
x86_l_2055:
	/* 0x2055: cmp    r8,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_64);
x86_l_2058:
	/* 0x2058: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_205c:
	/* 0x205c: cmp    rdx,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_205f:
	/* 0x205f: setbe  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_BE);
x86_l_2063:
	/* 0x2063: and    dil,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2066:
	/* 0x2066: or     al,dil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2069:
	/* 0x2069: cmp    esi,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 41ULL);
x86_l_206c:
	/* 0x206c: jb     2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x206c, 0x2df7, x86_l_2df7);
x86_l_2072:
	/* 0x2072: mov    r8,QWORD PTR [r12+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2077:
	/* 0x2077: mov    rdi,QWORD PTR [r12+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_207c:
	/* 0x207c: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_207f:
	/* 0x207f: je     208a <generic_fexit_filter_arg+0x208a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207f, 0x208a, x86_l_208a);
x86_l_2081:
	/* 0x2081: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_2084:
	/* 0x2084: jne    273f <generic_fexit_filter_arg+0x273f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2084, 0x273f, x86_l_273f);
x86_l_208a:
	/* 0x208a: cmp    r8,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_64);
x86_l_208d:
	/* 0x208d: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_2091:
	/* 0x2091: cmp    rdx,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_2094:
	/* 0x2094: setle  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_LE);
x86_l_2098:
	/* 0x2098: jmp    274d <generic_fexit_filter_arg+0x274d> */
	X86_SIM_X86_JMP(0x2098, 0x274d, x86_l_274d);
x86_l_209d:
	/* 0x209d: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_209f:
	/* 0x209f: cmp    ecx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 41ULL);
x86_l_20a2:
	/* 0x20a2: jne    20ad <generic_fexit_filter_arg+0x20ad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20a2, 0x20ad, x86_l_20ad);
x86_l_20a4:
	/* 0x20a4: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
x86_l_20a7:
	/* 0x20a7: je     20ad <generic_fexit_filter_arg+0x20ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a7, 0x20ad, x86_l_20ad);
x86_l_20a9:
	/* 0x20a9: movzx  ebx,BYTE PTR [rdx+0x3a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_20ad:
	/* 0x20ad: cmp    ecx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 41ULL);
x86_l_20b0:
	/* 0x20b0: je     20bb <generic_fexit_filter_arg+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b0, 0x20bb, x86_l_20bb);
x86_l_20b2:
	/* 0x20b2: cmp    ecx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_20b5:
	/* 0x20b5: jne    24b1 <generic_fexit_filter_arg+0x24b1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20b5, 0x24b1, x86_l_24b1);
x86_l_20bb:
	/* 0x20bb: movzx  eax,BYTE PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_20c1:
	/* 0x20c1: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_20c5:
	/* 0x20c5: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_20ca:
	/* 0x20ca: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&argfilter_maps));
x86_l_20d1:
	/* 0x20d1: lea    rsi,[rsp+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_20d6:
	/* 0x20d6: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_20d8:
	/* 0x20d8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_20db:
	/* 0x20db: je     20f6 <generic_fexit_filter_arg+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20db, 0x20f6, x86_l_20f6);
x86_l_20dd:
	/* 0x20dd: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_20e0:
	/* 0x20e0: mov    eax,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_32);
x86_l_20e2:
	/* 0x20e2: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_20e7:
	/* 0x20e7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_20ec:
	/* 0x20ec: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20f1:
	/* 0x20f1: jmp    1b8c <generic_fexit_filter_arg+0x1b8c> */
	X86_SIM_X86_JMP(0x20f1, 0x1b8c, x86_l_1b8c);
x86_l_20f6:
	/* 0x20f6: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20f8:
	/* 0x20f8: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20fc:
	/* 0x20fc: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2101:
	/* 0x2101: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2106:
	/* 0x2106: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x2106, 0x269, x86_l_269);
x86_l_210b:
	/* 0x210b: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_210d:
	/* 0x210d: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2112:
	/* 0x2112: jmp    2452 <generic_fexit_filter_arg+0x2452> */
	X86_SIM_X86_JMP(0x2112, 0x2452, x86_l_2452);
x86_l_2117:
	/* 0x2117: cmp    rdi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_211a:
	/* 0x211a: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_211e:
	/* 0x211e: ja     2129 <generic_fexit_filter_arg+0x2129> */
	X86_SIM_X86_JCC(X86_CC_A, 0x211e, 0x2129, x86_l_2129);
x86_l_2120:
	/* 0x2120: cmp    rax,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64);
x86_l_2123:
	/* 0x2123: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2123, 0x27a, x86_l_27a);
x86_l_2129:
	/* 0x2129: cmp    edx,0x29 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 41ULL);
x86_l_212c:
	/* 0x212c: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x212c, 0xc2, x86_l_c2);
x86_l_2132:
	/* 0x2132: mov    rdi,QWORD PTR [r12+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2137:
	/* 0x2137: mov    rsi,QWORD PTR [r12+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_213c:
	/* 0x213c: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_213f:
	/* 0x213f: je     214a <generic_fexit_filter_arg+0x214a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x213f, 0x214a, x86_l_214a);
x86_l_2141:
	/* 0x2141: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_2144:
	/* 0x2144: jne    2782 <generic_fexit_filter_arg+0x2782> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2144, 0x2782, x86_l_2782);
x86_l_214a:
	/* 0x214a: cmp    rdi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_214d:
	/* 0x214d: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2151:
	/* 0x2151: jg     2794 <generic_fexit_filter_arg+0x2794> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2151, 0x2794, x86_l_2794);
x86_l_2157:
	/* 0x2157: cmp    rax,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64);
x86_l_215a:
	/* 0x215a: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x215a, 0x27a, x86_l_27a);
x86_l_2160:
	/* 0x2160: jmp    2794 <generic_fexit_filter_arg+0x2794> */
	X86_SIM_X86_JMP(0x2160, 0x2794, x86_l_2794);
x86_l_2165:
	/* 0x2165: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2169:
	/* 0x2169: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_216e:
	/* 0x216e: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2173:
	/* 0x2173: jmp    1bce <generic_fexit_filter_arg+0x1bce> */
	X86_SIM_X86_JMP(0x2173, 0x1bce, x86_l_1bce);
x86_l_2178:
	/* 0x2178: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_217c:
	/* 0x217c: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x217c, 0x27a, x86_l_27a);
x86_l_2182:
	/* 0x2182: jmp    218e <generic_fexit_filter_arg+0x218e> */
	X86_SIM_X86_JMP(0x2182, 0x218e, x86_l_218e);
x86_l_2184:
	/* 0x2184: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2188:
	/* 0x2188: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2188, 0x27a, x86_l_27a);
x86_l_218e:
	/* 0x218e: mov    edx,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2193:
	/* 0x2193: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2196:
	/* 0x2196: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2196, 0x35ea, x86_l_35ea);
x86_l_219c:
	/* 0x219c: mov    esi,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_21a1:
	/* 0x21a1: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_21a4:
	/* 0x21a4: jle    21c1 <generic_fexit_filter_arg+0x21c1> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x21a4, 0x21c1, x86_l_21c1);
x86_l_21a6:
	/* 0x21a6: lea    edi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_21a9:
	/* 0x21a9: cmp    edi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_21ac:
	/* 0x21ac: jae    21f7 <generic_fexit_filter_arg+0x21f7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x21ac, 0x21f7, x86_l_21f7);
x86_l_21ae:
	/* 0x21ae: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b2:
	/* 0x21b2: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b6:
	/* 0x21b6: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b6, 0x261, x86_l_261);
x86_l_21bc:
	/* 0x21bc: jmp    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JMP(0x21bc, 0x2c74, x86_l_2c74);
x86_l_21c1:
	/* 0x21c1: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_21c4:
	/* 0x21c4: je     2213 <generic_fexit_filter_arg+0x2213> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21c4, 0x2213, x86_l_2213);
x86_l_21c6:
	/* 0x21c6: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_21c9:
	/* 0x21c9: jne    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21c9, 0x2c74, x86_l_2c74);
x86_l_21cf:
	/* 0x21cf: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_21d2:
	/* 0x21d2: ja     2c6a <generic_fexit_filter_arg+0x2c6a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x21d2, 0x2c6a, x86_l_2c6a);
x86_l_21d8:
	/* 0x21d8: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_21de:
	/* 0x21de: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_21e2:
	/* 0x21e2: jae    2c6a <generic_fexit_filter_arg+0x2c6a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x21e2, 0x2c6a, x86_l_2c6a);
x86_l_21e8:
	/* 0x21e8: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21ec:
	/* 0x21ec: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x21ec, 0x27a, x86_l_27a);
x86_l_21f2:
	/* 0x21f2: jmp    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JMP(0x21f2, 0x2c74, x86_l_2c74);
x86_l_21f7:
	/* 0x21f7: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_21fa:
	/* 0x21fa: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21fe:
	/* 0x21fe: jne    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21fe, 0x2c74, x86_l_2c74);
x86_l_2204:
	/* 0x2204: test   DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2208:
	/* 0x2208: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2208, 0x27a, x86_l_27a);
x86_l_220e:
	/* 0x220e: jmp    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JMP(0x220e, 0x2c74, x86_l_2c74);
x86_l_2213:
	/* 0x2213: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2216:
	/* 0x2216: ja     2c5e <generic_fexit_filter_arg+0x2c5e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2216, 0x2c5e, x86_l_2c5e);
x86_l_221c:
	/* 0x221c: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_2222:
	/* 0x2222: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_2226:
	/* 0x2226: jae    2c5e <generic_fexit_filter_arg+0x2c5e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2226, 0x2c5e, x86_l_2c5e);
x86_l_222c:
	/* 0x222c: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2230:
	/* 0x2230: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2230, 0x27a, x86_l_27a);
x86_l_2236:
	/* 0x2236: jmp    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JMP(0x2236, 0x2c74, x86_l_2c74);
x86_l_223b:
	/* 0x223b: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_223e:
	/* 0x223e: je     2ad9 <generic_fexit_filter_arg+0x2ad9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x223e, 0x2ad9, x86_l_2ad9);
x86_l_2244:
	/* 0x2244: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2247:
	/* 0x2247: jne    2ae6 <generic_fexit_filter_arg+0x2ae6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2247, 0x2ae6, x86_l_2ae6);
x86_l_224d:
	/* 0x224d: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2252:
	/* 0x2252: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2254:
	/* 0x2254: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2254, 0x27a, x86_l_27a);
x86_l_225a:
	/* 0x225a: jmp    2ae6 <generic_fexit_filter_arg+0x2ae6> */
	X86_SIM_X86_JMP(0x225a, 0x2ae6, x86_l_2ae6);
x86_l_225f:
	/* 0x225f: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2262:
	/* 0x2262: je     2b1b <generic_fexit_filter_arg+0x2b1b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2262, 0x2b1b, x86_l_2b1b);
x86_l_2268:
	/* 0x2268: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_226b:
	/* 0x226b: jne    2b28 <generic_fexit_filter_arg+0x2b28> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x226b, 0x2b28, x86_l_2b28);
x86_l_2271:
	/* 0x2271: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2276:
	/* 0x2276: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2278:
	/* 0x2278: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2278, 0x27a, x86_l_27a);
x86_l_227e:
	/* 0x227e: jmp    2b28 <generic_fexit_filter_arg+0x2b28> */
	X86_SIM_X86_JMP(0x227e, 0x2b28, x86_l_2b28);
x86_l_2283:
	/* 0x2283: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2288:
	/* 0x2288: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_228c:
	/* 0x228c: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x228c, 0x358b, x86_l_358b);
x86_l_2291:
	/* 0x2291: mov    ecx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_2296:
	/* 0x2296: jmp    22a4 <generic_fexit_filter_arg+0x22a4> */
	X86_SIM_X86_JMP(0x2296, 0x22a4, x86_l_22a4);
x86_l_2298:
	/* 0x2298: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_229d:
	/* 0x229d: jmp    22a4 <generic_fexit_filter_arg+0x22a4> */
	X86_SIM_X86_JMP(0x229d, 0x22a4, x86_l_22a4);
x86_l_229f:
	/* 0x229f: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_22a4:
	/* 0x22a4: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_22a6:
	/* 0x22a6: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_22a9:
	/* 0x22a9: mov    eax,DWORD PTR [r12+rax*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_22ae:
	/* 0x22ae: cmp    eax,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_22b1:
	/* 0x22b1: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b1, 0x31df, x86_l_31df);
x86_l_22b7:
	/* 0x22b7: mov    DWORD PTR [rsp+0x64],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_22bb:
	/* 0x22bb: mov    DWORD PTR [rsp+0x88],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_22c2:
	/* 0x22c2: mov    QWORD PTR [rsp+0x68],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_22c7:
	/* 0x22c7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_22cc:
	/* 0x22cc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_heap));
x86_l_22d3:
	/* 0x22d3: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_22d8:
	/* 0x22d8: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_22db:
	/* 0x22db: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_22dd:
	/* 0x22dd: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_22e0:
	/* 0x22e0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_22e5:
	/* 0x22e5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_22ec:
	/* 0x22ec: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_22ef:
	/* 0x22ef: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_22f1:
	/* 0x22f1: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22f6:
	/* 0x22f6: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_22f9:
	/* 0x22f9: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22f9, 0x31df, x86_l_31df);
x86_l_22ff:
	/* 0x22ff: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_2304:
	/* 0x2304: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2307:
	/* 0x2307: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_230b:
	/* 0x230b: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2310:
	/* 0x2310: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2315:
	/* 0x2315: je     31ef <generic_fexit_filter_arg+0x31ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2315, 0x31ef, x86_l_31ef);
x86_l_231b:
	/* 0x231b: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2323:
	/* 0x2323: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2328:
	/* 0x2328: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_232c:
	/* 0x232c: mov    ebx,DWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2333:
	/* 0x2333: cmp    ebx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_2336:
	/* 0x2336: jg     237c <generic_fexit_filter_arg+0x237c> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2336, 0x237c, x86_l_237c);
x86_l_2338:
	/* 0x2338: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_233d:
	/* 0x233d: mov    BYTE PTR [rax],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2340:
	/* 0x2340: lea    rdi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2344:
	/* 0x2344: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2349:
	/* 0x2349: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_234b:
	/* 0x234b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_234d:
	/* 0x234d: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2352:
	/* 0x2352: sub    esi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2354:
	/* 0x2354: mov    r13d,DWORD PTR [rsp+0x64] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_2359:
	/* 0x2359: jbe    23c1 <generic_fexit_filter_arg+0x23c1> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2359, 0x23c1, x86_l_23c1);
x86_l_235b:
	/* 0x235b: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2360:
	/* 0x2360: lea    rdi,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2364:
	/* 0x2364: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_2367:
	/* 0x2367: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_236d:
	/* 0x236d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2372:
	/* 0x2372: mov    rdx,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_237a:
	/* 0x237a: jmp    23bf <generic_fexit_filter_arg+0x23bf> */
	X86_SIM_X86_JMP(0x237a, 0x23bf, x86_l_23bf);
x86_l_237c:
	/* 0x237c: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2381:
	/* 0x2381: mov    WORD PTR [rax],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2384:
	/* 0x2384: lea    rdi,[rax+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_2388:
	/* 0x2388: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_238d:
	/* 0x238d: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_238f:
	/* 0x238f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2391:
	/* 0x2391: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2396:
	/* 0x2396: sub    esi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2398:
	/* 0x2398: mov    r13d,DWORD PTR [rsp+0x64] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_239d:
	/* 0x239d: jbe    23c1 <generic_fexit_filter_arg+0x23c1> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x239d, 0x23c1, x86_l_23c1);
x86_l_239f:
	/* 0x239f: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23a4:
	/* 0x23a4: lea    rdi,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_23a8:
	/* 0x23a8: add    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_23ac:
	/* 0x23ac: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_23b2:
	/* 0x23b2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_23b7:
	/* 0x23b7: mov    rdx,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_23bf:
	/* 0x23bf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_23c1:
	/* 0x23c1: mov    DWORD PTR [rsp+0x38],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_23c6:
	/* 0x23c6: cmp    ebx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_23c9:
	/* 0x23c9: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23cd:
	/* 0x23cd: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23d2:
	/* 0x23d2: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23d7:
	/* 0x23d7: jle    2413 <generic_fexit_filter_arg+0x2413> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x23d7, 0x2413, x86_l_2413);
x86_l_23d9:
	/* 0x23d9: cmp    ebx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_23dc:
	/* 0x23dc: jg     2891 <generic_fexit_filter_arg+0x2891> */
	X86_SIM_X86_JCC(X86_CC_G, 0x23dc, 0x2891, x86_l_2891);
x86_l_23e2:
	/* 0x23e2: cmp    ebx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_23e5:
	/* 0x23e5: je     2f2d <generic_fexit_filter_arg+0x2f2d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23e5, 0x2f2d, x86_l_2f2d);
x86_l_23eb:
	/* 0x23eb: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_23ee:
	/* 0x23ee: je     2ef4 <generic_fexit_filter_arg+0x2ef4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ee, 0x2ef4, x86_l_2ef4);
x86_l_23f4:
	/* 0x23f4: cmp    ebx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_23f7:
	/* 0x23f7: jne    911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23f7, 0x911, x86_l_911);
x86_l_23fd:
	/* 0x23fd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2402:
	/* 0x2402: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2407:
	/* 0x2407: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_7));
x86_l_240e:
	/* 0x240e: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x240e, 0x2f51, x86_l_2f51);
x86_l_2413:
	/* 0x2413: cmp    ebx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2416:
	/* 0x2416: jle    2b5d <generic_fexit_filter_arg+0x2b5d> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2416, 0x2b5d, x86_l_2b5d);
x86_l_241c:
	/* 0x241c: cmp    ebx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_241f:
	/* 0x241f: je     2f1a <generic_fexit_filter_arg+0x2f1a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x241f, 0x2f1a, x86_l_2f1a);
x86_l_2425:
	/* 0x2425: cmp    ebx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_2428:
	/* 0x2428: je     2ee1 <generic_fexit_filter_arg+0x2ee1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2428, 0x2ee1, x86_l_2ee1);
x86_l_242e:
	/* 0x242e: cmp    ebx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_2431:
	/* 0x2431: jne    911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2431, 0x911, x86_l_911);
x86_l_2437:
	/* 0x2437: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_243c:
	/* 0x243c: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2441:
	/* 0x2441: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_4));
x86_l_2448:
	/* 0x2448: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2448, 0x2f51, x86_l_2f51);
x86_l_244d:
	/* 0x244d: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2452:
	/* 0x2452: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2456:
	/* 0x2456: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_245b:
	/* 0x245b: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x245b, 0x358b, x86_l_358b);
x86_l_2460:
	/* 0x2460: cmp    r8d,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_32);
x86_l_2463:
	/* 0x2463: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2467:
	/* 0x2467: cmp    edx,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_32);
x86_l_2469:
	/* 0x2469: setbe  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_BE);
x86_l_246d:
	/* 0x246d: and    dil,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2470:
	/* 0x2470: or     al,dil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2473:
	/* 0x2473: cmp    esi,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 25ULL);
x86_l_2476:
	/* 0x2476: jb     2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2476, 0x2df7, x86_l_2df7);
x86_l_247c:
	/* 0x247c: mov    r8d,DWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2481:
	/* 0x2481: mov    edi,DWORD PTR [r12+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2486:
	/* 0x2486: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2489:
	/* 0x2489: ja     2bb5 <generic_fexit_filter_arg+0x2bb5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2489, 0x2bb5, x86_l_2bb5);
x86_l_248f:
	/* 0x248f: mov    r10d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_32, 5122ULL);
x86_l_2495:
	/* 0x2495: bt     r10d,ecx */
	X86_SIM_L_EXEC_BT(X86_R10, X86_RCX, X86_WIDTH_32);
x86_l_2499:
	/* 0x2499: jae    2bb5 <generic_fexit_filter_arg+0x2bb5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2499, 0x2bb5, x86_l_2bb5);
x86_l_249f:
	/* 0x249f: cmp    r8d,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_32);
x86_l_24a2:
	/* 0x24a2: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_24a6:
	/* 0x24a6: cmp    edx,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_32);
x86_l_24a8:
	/* 0x24a8: setle  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_LE);
x86_l_24ac:
	/* 0x24ac: jmp    2bc2 <generic_fexit_filter_arg+0x2bc2> */
	X86_SIM_X86_JMP(0x24ac, 0x2bc2, x86_l_2bc2);
x86_l_24b1:
	/* 0x24b1: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24b3:
	/* 0x24b3: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x24b3, 0x269, x86_l_269);
x86_l_24b8:
	/* 0x24b8: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_24be:
	/* 0x24be: jmp    24ce <generic_fexit_filter_arg+0x24ce> */
	X86_SIM_X86_JMP(0x24be, 0x24ce, x86_l_24ce);
x86_l_24c0:
	/* 0x24c0: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_24c6:
	/* 0x24c6: jmp    24ce <generic_fexit_filter_arg+0x24ce> */
	X86_SIM_X86_JMP(0x24c6, 0x24ce, x86_l_24ce);
x86_l_24c8:
	/* 0x24c8: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_24ce:
	/* 0x24ce: mov    eax,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_32);
x86_l_24d1:
	/* 0x24d1: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_24d4:
	/* 0x24d4: mov    eax,DWORD PTR [r12+rax*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_24d9:
	/* 0x24d9: cmp    eax,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_24dc:
	/* 0x24dc: je     2d4d <generic_fexit_filter_arg+0x2d4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24dc, 0x2d4d, x86_l_2d4d);
x86_l_24e2:
	/* 0x24e2: mov    DWORD PTR [rsp+0x64],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_24e6:
	/* 0x24e6: mov    QWORD PTR [rsp+0x68],r10 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_24eb:
	/* 0x24eb: mov    BYTE PTR [rsp+0x88],r8b */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_24f3:
	/* 0x24f3: mov    QWORD PTR [rsp+0x18],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24f8:
	/* 0x24f8: mov    QWORD PTR [rsp+0x20],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24fd:
	/* 0x24fd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2502:
	/* 0x2502: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_heap));
x86_l_2509:
	/* 0x2509: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_250e:
	/* 0x250e: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2511:
	/* 0x2511: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2513:
	/* 0x2513: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_2516:
	/* 0x2516: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_251b:
	/* 0x251b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_2522:
	/* 0x2522: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2525:
	/* 0x2525: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2527:
	/* 0x2527: test   rbp,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64);
x86_l_252a:
	/* 0x252a: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x252a, 0x31df, x86_l_31df);
x86_l_2530:
	/* 0x2530: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_2535:
	/* 0x2535: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2538:
	/* 0x2538: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_253c:
	/* 0x253c: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2541:
	/* 0x2541: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2546:
	/* 0x2546: je     31ef <generic_fexit_filter_arg+0x31ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2546, 0x31ef, x86_l_31ef);
x86_l_254c:
	/* 0x254c: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
x86_l_254f:
	/* 0x254f: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_2552:
	/* 0x2552: mov    ebp,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_32);
x86_l_2555:
	/* 0x2555: cmp    r13d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 5ULL);
x86_l_2559:
	/* 0x2559: mov    QWORD PTR [rsp+0x90],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2561:
	/* 0x2561: jg     25ae <generic_fexit_filter_arg+0x25ae> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2561, 0x25ae, x86_l_25ae);
x86_l_2563:
	/* 0x2563: mov    rax,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_2566:
	/* 0x2566: movzx  ecx,BYTE PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 136ULL);
x86_l_256e:
	/* 0x256e: mov    BYTE PTR [rax],cl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2570:
	/* 0x2570: lea    rdi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2574:
	/* 0x2574: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2579:
	/* 0x2579: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_257e:
	/* 0x257e: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2583:
	/* 0x2583: mov    esi,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_32);
x86_l_2586:
	/* 0x2586: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2588:
	/* 0x2588: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_258d:
	/* 0x258d: sub    esi,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_R13, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2590:
	/* 0x2590: jbe    25f4 <generic_fexit_filter_arg+0x25f4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2590, 0x25f4, x86_l_25f4);
x86_l_2592:
	/* 0x2592: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_259a:
	/* 0x259a: lea    rdi,[rax+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_259e:
	/* 0x259e: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_25a1:
	/* 0x25a1: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_25a7:
	/* 0x25a7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_25ac:
	/* 0x25ac: jmp    25ef <generic_fexit_filter_arg+0x25ef> */
	X86_SIM_X86_JMP(0x25ac, 0x25ef, x86_l_25ef);
x86_l_25ae:
	/* 0x25ae: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25b3:
	/* 0x25b3: mov    WORD PTR [rcx],r13w */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25b7:
	/* 0x25b7: lea    rdi,[rcx+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_25bb:
	/* 0x25bb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_25c0:
	/* 0x25c0: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25c5:
	/* 0x25c5: mov    esi,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_32);
x86_l_25c8:
	/* 0x25c8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_25ca:
	/* 0x25ca: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_25cf:
	/* 0x25cf: sub    esi,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_R13, X86_WIDTH_32, X86_ALU_SUB);
x86_l_25d2:
	/* 0x25d2: jbe    25f4 <generic_fexit_filter_arg+0x25f4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x25d2, 0x25f4, x86_l_25f4);
x86_l_25d4:
	/* 0x25d4: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_25dc:
	/* 0x25dc: lea    rdi,[rax+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_25e0:
	/* 0x25e0: add    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_25e4:
	/* 0x25e4: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_25ea:
	/* 0x25ea: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_25ef:
	/* 0x25ef: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_25f2:
	/* 0x25f2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_25f4:
	/* 0x25f4: mov    eax,DWORD PTR [rsp+0x64] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_25f8:
	/* 0x25f8: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_25fc:
	/* 0x25fc: cmp    ebp,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 4ULL);
x86_l_25ff:
	/* 0x25ff: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2603:
	/* 0x2603: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2608:
	/* 0x2608: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_260d:
	/* 0x260d: jle    2649 <generic_fexit_filter_arg+0x2649> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x260d, 0x2649, x86_l_2649);
x86_l_260f:
	/* 0x260f: cmp    ebp,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 7ULL);
x86_l_2612:
	/* 0x2612: jg     2a8c <generic_fexit_filter_arg+0x2a8c> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2612, 0x2a8c, x86_l_2a8c);
x86_l_2618:
	/* 0x2618: cmp    ebp,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 5ULL);
x86_l_261b:
	/* 0x261b: je     3198 <generic_fexit_filter_arg+0x3198> */
	X86_SIM_X86_JCC(X86_CC_E, 0x261b, 0x3198, x86_l_3198);
x86_l_2621:
	/* 0x2621: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_2624:
	/* 0x2624: je     315f <generic_fexit_filter_arg+0x315f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2624, 0x315f, x86_l_315f);
x86_l_262a:
	/* 0x262a: cmp    ebp,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 7ULL);
x86_l_262d:
	/* 0x262d: jne    2d4d <generic_fexit_filter_arg+0x2d4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x262d, 0x2d4d, x86_l_2d4d);
x86_l_2633:
	/* 0x2633: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2638:
	/* 0x2638: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_263d:
	/* 0x263d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_7));
x86_l_2644:
	/* 0x2644: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x2644, 0x31bc, x86_l_31bc);
x86_l_2649:
	/* 0x2649: cmp    ebp,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 1ULL);
x86_l_264c:
	/* 0x264c: jle    2d2a <generic_fexit_filter_arg+0x2d2a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x264c, 0x2d2a, x86_l_2d2a);
x86_l_2652:
	/* 0x2652: cmp    ebp,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 2ULL);
x86_l_2655:
	/* 0x2655: je     3185 <generic_fexit_filter_arg+0x3185> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2655, 0x3185, x86_l_3185);
x86_l_265b:
	/* 0x265b: cmp    ebp,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 3ULL);
x86_l_265e:
	/* 0x265e: je     314c <generic_fexit_filter_arg+0x314c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x265e, 0x314c, x86_l_314c);
x86_l_2664:
	/* 0x2664: cmp    ebp,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 4ULL);
x86_l_2667:
	/* 0x2667: jne    2d4d <generic_fexit_filter_arg+0x2d4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2667, 0x2d4d, x86_l_2d4d);
x86_l_266d:
	/* 0x266d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2672:
	/* 0x2672: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2677:
	/* 0x2677: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_4));
x86_l_267e:
	/* 0x267e: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x267e, 0x31bc, x86_l_31bc);
x86_l_2683:
	/* 0x2683: cmp    edi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_32);
x86_l_2685:
	/* 0x2685: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2689:
	/* 0x2689: ja     2693 <generic_fexit_filter_arg+0x2693> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2689, 0x2693, x86_l_2693);
x86_l_268b:
	/* 0x268b: cmp    eax,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_268d:
	/* 0x268d: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x268d, 0x27a, x86_l_27a);
x86_l_2693:
	/* 0x2693: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_2696:
	/* 0x2696: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2696, 0xc2, x86_l_c2);
x86_l_269c:
	/* 0x269c: mov    edi,DWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_26a1:
	/* 0x26a1: mov    esi,DWORD PTR [r12+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_26a6:
	/* 0x26a6: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_26a9:
	/* 0x26a9: ja     2c0d <generic_fexit_filter_arg+0x2c0d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x26a9, 0x2c0d, x86_l_2c0d);
x86_l_26af:
	/* 0x26af: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_26b5:
	/* 0x26b5: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_26b9:
	/* 0x26b9: jae    2c0d <generic_fexit_filter_arg+0x2c0d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x26b9, 0x2c0d, x86_l_2c0d);
x86_l_26bf:
	/* 0x26bf: cmp    edi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_32);
x86_l_26c1:
	/* 0x26c1: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c5:
	/* 0x26c5: jg     2c1d <generic_fexit_filter_arg+0x2c1d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x26c5, 0x2c1d, x86_l_2c1d);
x86_l_26cb:
	/* 0x26cb: cmp    eax,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_26cd:
	/* 0x26cd: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x26cd, 0x27a, x86_l_27a);
x86_l_26d3:
	/* 0x26d3: jmp    2c1d <generic_fexit_filter_arg+0x2c1d> */
	X86_SIM_X86_JMP(0x26d3, 0x2c1d, x86_l_2c1d);
x86_l_26d8:
	/* 0x26d8: mov    edx,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 256ULL);
x86_l_26dd:
	/* 0x26dd: cmp    eax,0x101 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 257ULL);
x86_l_26e2:
	/* 0x26e2: jb     270f <generic_fexit_filter_arg+0x270f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26e2, 0x270f, x86_l_270f);
x86_l_26e4:
	/* 0x26e4: mov    edx,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 512ULL);
x86_l_26e9:
	/* 0x26e9: cmp    eax,0x201 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 513ULL);
x86_l_26ee:
	/* 0x26ee: jb     270f <generic_fexit_filter_arg+0x270f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26ee, 0x270f, x86_l_270f);
x86_l_26f0:
	/* 0x26f0: mov    edx,0x400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1024ULL);
x86_l_26f5:
	/* 0x26f5: cmp    eax,0x401 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1025ULL);
x86_l_26fa:
	/* 0x26fa: jb     270f <generic_fexit_filter_arg+0x270f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26fa, 0x270f, x86_l_270f);
x86_l_26fc:
	/* 0x26fc: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_26fe:
	/* 0x26fe: cmp    eax,0x801 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2049ULL);
x86_l_2703:
	/* 0x2703: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_2706:
	/* 0x2706: shl    edx,0xb */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_2709:
	/* 0x2709: add    edx,0x800 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_270f:
	/* 0x270f: lea    eax,[rdx-0x100] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_2715:
	/* 0x2715: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_271b:
	/* 0x271b: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_271e:
	/* 0x271e: jg     2abd <generic_fexit_filter_arg+0x2abd> */
	X86_SIM_X86_JCC(X86_CC_G, 0x271e, 0x2abd, x86_l_2abd);
x86_l_2724:
	/* 0x2724: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2726:
	/* 0x2726: je     2f75 <generic_fexit_filter_arg+0x2f75> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2726, 0x2f75, x86_l_2f75);
x86_l_272c:
	/* 0x272c: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_272f:
	/* 0x272f: jne    2f6e <generic_fexit_filter_arg+0x2f6e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x272f, 0x2f6e, x86_l_2f6e);
x86_l_2735:
	/* 0x2735: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_273a:
	/* 0x273a: jmp    2f81 <generic_fexit_filter_arg+0x2f81> */
	X86_SIM_X86_JMP(0x273a, 0x2f81, x86_l_2f81);
x86_l_273f:
	/* 0x273f: cmp    r8,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_64);
x86_l_2742:
	/* 0x2742: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2746:
	/* 0x2746: cmp    rdx,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_2749:
	/* 0x2749: setbe  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_BE);
x86_l_274d:
	/* 0x274d: and    dil,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2750:
	/* 0x2750: or     al,dil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2753:
	/* 0x2753: cmp    esi,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 57ULL);
x86_l_2756:
	/* 0x2756: jb     2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2756, 0x2df7, x86_l_2df7);
x86_l_275c:
	/* 0x275c: mov    rdi,QWORD PTR [r12+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2761:
	/* 0x2761: mov    rsi,QWORD PTR [r12+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2766:
	/* 0x2766: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2769:
	/* 0x2769: je     2774 <generic_fexit_filter_arg+0x2774> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2769, 0x2774, x86_l_2774);
x86_l_276b:
	/* 0x276b: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_276e:
	/* 0x276e: jne    2d1c <generic_fexit_filter_arg+0x2d1c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x276e, 0x2d1c, x86_l_2d1c);
x86_l_2774:
	/* 0x2774: cmp    rdi,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_64);
x86_l_2777:
	/* 0x2777: setle  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_LE);
x86_l_277a:
	/* 0x277a: cmp    rdx,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_277d:
	/* 0x277d: jmp    2bfb <generic_fexit_filter_arg+0x2bfb> */
	X86_SIM_X86_JMP(0x277d, 0x2bfb, x86_l_2bfb);
x86_l_2782:
	/* 0x2782: cmp    rdi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2785:
	/* 0x2785: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2789:
	/* 0x2789: ja     2794 <generic_fexit_filter_arg+0x2794> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2789, 0x2794, x86_l_2794);
x86_l_278b:
	/* 0x278b: cmp    rax,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64);
x86_l_278e:
	/* 0x278e: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x278e, 0x27a, x86_l_27a);
x86_l_2794:
	/* 0x2794: cmp    edx,0x39 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 57ULL);
x86_l_2797:
	/* 0x2797: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2797, 0xc2, x86_l_c2);
x86_l_279d:
	/* 0x279d: mov    rsi,QWORD PTR [r12+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_27a2:
	/* 0x27a2: mov    rdx,QWORD PTR [r12+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_27a7:
	/* 0x27a7: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_27aa:
	/* 0x27aa: je     27b5 <generic_fexit_filter_arg+0x27b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27aa, 0x27b5, x86_l_27b5);
x86_l_27ac:
	/* 0x27ac: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_27af:
	/* 0x27af: jne    2d63 <generic_fexit_filter_arg+0x2d63> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27af, 0x2d63, x86_l_2d63);
x86_l_27b5:
	/* 0x27b5: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_27b8:
	/* 0x27b8: jg     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27b8, 0xc2, x86_l_c2);
x86_l_27be:
	/* 0x27be: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_27c1:
	/* 0x27c1: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x27c1, 0x27a, x86_l_27a);
x86_l_27c7:
	/* 0x27c7: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x27c7, 0xc2, x86_l_c2);
x86_l_27cc:
	/* 0x27cc: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d0:
	/* 0x27d0: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x27d0, 0x27a, x86_l_27a);
x86_l_27d6:
	/* 0x27d6: jmp    27e2 <generic_fexit_filter_arg+0x27e2> */
	X86_SIM_X86_JMP(0x27d6, 0x27e2, x86_l_27e2);
x86_l_27d8:
	/* 0x27d8: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27dc:
	/* 0x27dc: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27dc, 0x27a, x86_l_27a);
x86_l_27e2:
	/* 0x27e2: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_27e5:
	/* 0x27e5: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27e5, 0x35ea, x86_l_35ea);
x86_l_27eb:
	/* 0x27eb: mov    rsi,QWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_27f0:
	/* 0x27f0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_27f3:
	/* 0x27f3: jle    2810 <generic_fexit_filter_arg+0x2810> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x27f3, 0x2810, x86_l_2810);
x86_l_27f5:
	/* 0x27f5: lea    edi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_27f8:
	/* 0x27f8: cmp    edi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_27fb:
	/* 0x27fb: jae    283f <generic_fexit_filter_arg+0x283f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x27fb, 0x283f, x86_l_283f);
x86_l_27fd:
	/* 0x27fd: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2801:
	/* 0x2801: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2805:
	/* 0x2805: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2805, 0x261, x86_l_261);
x86_l_280b:
	/* 0x280b: jmp    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JMP(0x280b, 0x2e1e, x86_l_2e1e);
x86_l_2810:
	/* 0x2810: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2813:
	/* 0x2813: je     2a6f <generic_fexit_filter_arg+0x2a6f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2813, 0x2a6f, x86_l_2a6f);
x86_l_2819:
	/* 0x2819: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_281c:
	/* 0x281c: jne    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x281c, 0x2e1e, x86_l_2e1e);
x86_l_2822:
	/* 0x2822: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2825:
	/* 0x2825: je     2830 <generic_fexit_filter_arg+0x2830> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2825, 0x2830, x86_l_2830);
x86_l_2827:
	/* 0x2827: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_282a:
	/* 0x282a: jne    2e14 <generic_fexit_filter_arg+0x2e14> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x282a, 0x2e14, x86_l_2e14);
x86_l_2830:
	/* 0x2830: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2834:
	/* 0x2834: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2834, 0x27a, x86_l_27a);
x86_l_283a:
	/* 0x283a: jmp    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JMP(0x283a, 0x2e1e, x86_l_2e1e);
x86_l_283f:
	/* 0x283f: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2842:
	/* 0x2842: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2846:
	/* 0x2846: jne    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2846, 0x2e1e, x86_l_2e1e);
x86_l_284c:
	/* 0x284c: test   QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2850:
	/* 0x2850: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2850, 0x27a, x86_l_27a);
x86_l_2856:
	/* 0x2856: jmp    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JMP(0x2856, 0x2e1e, x86_l_2e1e);
x86_l_285b:
	/* 0x285b: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_285e:
	/* 0x285e: jne    2ae6 <generic_fexit_filter_arg+0x2ae6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x285e, 0x2ae6, x86_l_2ae6);
x86_l_2864:
	/* 0x2864: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2869:
	/* 0x2869: test   edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_286b:
	/* 0x286b: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x286b, 0x27a, x86_l_27a);
x86_l_2871:
	/* 0x2871: jmp    2ae6 <generic_fexit_filter_arg+0x2ae6> */
	X86_SIM_X86_JMP(0x2871, 0x2ae6, x86_l_2ae6);
x86_l_2876:
	/* 0x2876: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2879:
	/* 0x2879: jne    2b28 <generic_fexit_filter_arg+0x2b28> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2879, 0x2b28, x86_l_2b28);
x86_l_287f:
	/* 0x287f: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2884:
	/* 0x2884: test   edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2886:
	/* 0x2886: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2886, 0x27a, x86_l_27a);
x86_l_288c:
	/* 0x288c: jmp    2b28 <generic_fexit_filter_arg+0x2b28> */
	X86_SIM_X86_JMP(0x288c, 0x2b28, x86_l_2b28);
x86_l_2891:
	/* 0x2891: cmp    ebx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_2894:
	/* 0x2894: je     2f40 <generic_fexit_filter_arg+0x2f40> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2894, 0x2f40, x86_l_2f40);
x86_l_289a:
	/* 0x289a: cmp    ebx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_289d:
	/* 0x289d: je     2f07 <generic_fexit_filter_arg+0x2f07> */
	X86_SIM_X86_JCC(X86_CC_E, 0x289d, 0x2f07, x86_l_2f07);
x86_l_28a3:
	/* 0x28a3: cmp    ebx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_28a6:
	/* 0x28a6: jne    911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28a6, 0x911, x86_l_911);
x86_l_28ac:
	/* 0x28ac: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_28b1:
	/* 0x28b1: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_28b6:
	/* 0x28b6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_10));
x86_l_28bd:
	/* 0x28bd: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x28bd, 0x2f51, x86_l_2f51);
x86_l_28c2:
	/* 0x28c2: mov    ecx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_28c7:
	/* 0x28c7: jmp    28d5 <generic_fexit_filter_arg+0x28d5> */
	X86_SIM_X86_JMP(0x28c7, 0x28d5, x86_l_28d5);
x86_l_28c9:
	/* 0x28c9: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_28ce:
	/* 0x28ce: jmp    28d5 <generic_fexit_filter_arg+0x28d5> */
	X86_SIM_X86_JMP(0x28ce, 0x28d5, x86_l_28d5);
x86_l_28d0:
	/* 0x28d0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_28d5:
	/* 0x28d5: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_28d7:
	/* 0x28d7: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_28da:
	/* 0x28da: mov    eax,DWORD PTR [r12+rax*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_28df:
	/* 0x28df: cmp    eax,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_28e2:
	/* 0x28e2: je     299a <generic_fexit_filter_arg+0x299a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28e2, 0x299a, x86_l_299a);
x86_l_28e8:
	/* 0x28e8: mov    DWORD PTR [rsp+0x64],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_28ec:
	/* 0x28ec: mov    DWORD PTR [rsp+0x68],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_28f0:
	/* 0x28f0: mov    QWORD PTR [rsp+0x88],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_28f8:
	/* 0x28f8: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_28fd:
	/* 0x28fd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_heap));
x86_l_2904:
	/* 0x2904: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2909:
	/* 0x2909: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_290c:
	/* 0x290c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_290e:
	/* 0x290e: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_2911:
	/* 0x2911: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2916:
	/* 0x2916: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_291d:
	/* 0x291d: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2920:
	/* 0x2920: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2922:
	/* 0x2922: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2927:
	/* 0x2927: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_292a:
	/* 0x292a: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x292a, 0x357b, x86_l_357b);
x86_l_2930:
	/* 0x2930: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_2935:
	/* 0x2935: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2938:
	/* 0x2938: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_293c:
	/* 0x293c: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2941:
	/* 0x2941: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2946:
	/* 0x2946: je     358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2946, 0x358b, x86_l_358b);
x86_l_294c:
	/* 0x294c: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_294f:
	/* 0x294f: mov    ebx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2953:
	/* 0x2953: cmp    ebx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_2956:
	/* 0x2956: jg     29a1 <generic_fexit_filter_arg+0x29a1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2956, 0x29a1, x86_l_29a1);
x86_l_2958:
	/* 0x2958: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_295d:
	/* 0x295d: mov    BYTE PTR [rax],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2960:
	/* 0x2960: lea    rdi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2964:
	/* 0x2964: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2969:
	/* 0x2969: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_296e:
	/* 0x296e: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_2970:
	/* 0x2970: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2972:
	/* 0x2972: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_297a:
	/* 0x297a: sub    esi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_297c:
	/* 0x297c: jbe    29e4 <generic_fexit_filter_arg+0x29e4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x297c, 0x29e4, x86_l_29e4);
x86_l_297e:
	/* 0x297e: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2983:
	/* 0x2983: lea    rdi,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2987:
	/* 0x2987: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_298a:
	/* 0x298a: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2990:
	/* 0x2990: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2995:
	/* 0x2995: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_2998:
	/* 0x2998: jmp    29e2 <generic_fexit_filter_arg+0x29e2> */
	X86_SIM_X86_JMP(0x2998, 0x29e2, x86_l_29e2);
x86_l_299a:
	/* 0x299a: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_299c:
	/* 0x299c: jmp    358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JMP(0x299c, 0x358b, x86_l_358b);
x86_l_29a1:
	/* 0x29a1: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29a6:
	/* 0x29a6: mov    WORD PTR [rax],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29a9:
	/* 0x29a9: lea    rdi,[rax+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_29ad:
	/* 0x29ad: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_29b2:
	/* 0x29b2: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_29b7:
	/* 0x29b7: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_29b9:
	/* 0x29b9: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_29bb:
	/* 0x29bb: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_29c3:
	/* 0x29c3: sub    esi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_29c5:
	/* 0x29c5: jbe    29e4 <generic_fexit_filter_arg+0x29e4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x29c5, 0x29e4, x86_l_29e4);
x86_l_29c7:
	/* 0x29c7: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29cc:
	/* 0x29cc: lea    rdi,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_29d0:
	/* 0x29d0: add    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_29d4:
	/* 0x29d4: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_29da:
	/* 0x29da: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_29df:
	/* 0x29df: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_29e2:
	/* 0x29e2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_29e4:
	/* 0x29e4: mov    eax,DWORD PTR [rsp+0x64] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_29e8:
	/* 0x29e8: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29ec:
	/* 0x29ec: cmp    ebx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_29ef:
	/* 0x29ef: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29f4:
	/* 0x29f4: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29f9:
	/* 0x29f9: jle    2a35 <generic_fexit_filter_arg+0x2a35> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x29f9, 0x2a35, x86_l_2a35);
x86_l_29fb:
	/* 0x29fb: cmp    ebx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_29fe:
	/* 0x29fe: jg     2b84 <generic_fexit_filter_arg+0x2b84> */
	X86_SIM_X86_JCC(X86_CC_G, 0x29fe, 0x2b84, x86_l_2b84);
x86_l_2a04:
	/* 0x2a04: cmp    ebx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_2a07:
	/* 0x2a07: je     327a <generic_fexit_filter_arg+0x327a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a07, 0x327a, x86_l_327a);
x86_l_2a0d:
	/* 0x2a0d: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_2a10:
	/* 0x2a10: je     3241 <generic_fexit_filter_arg+0x3241> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a10, 0x3241, x86_l_3241);
x86_l_2a16:
	/* 0x2a16: cmp    ebx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_2a19:
	/* 0x2a19: jne    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a19, 0x2035, x86_l_2035);
x86_l_2a1f:
	/* 0x2a1f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2a24:
	/* 0x2a24: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a29:
	/* 0x2a29: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_7));
x86_l_2a30:
	/* 0x2a30: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x2a30, 0x329e, x86_l_329e);
x86_l_2a35:
	/* 0x2a35: cmp    ebx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2a38:
	/* 0x2a38: jle    2dc2 <generic_fexit_filter_arg+0x2dc2> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2a38, 0x2dc2, x86_l_2dc2);
x86_l_2a3e:
	/* 0x2a3e: cmp    ebx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_2a41:
	/* 0x2a41: je     3267 <generic_fexit_filter_arg+0x3267> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a41, 0x3267, x86_l_3267);
x86_l_2a47:
	/* 0x2a47: cmp    ebx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_2a4a:
	/* 0x2a4a: je     322e <generic_fexit_filter_arg+0x322e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a4a, 0x322e, x86_l_322e);
x86_l_2a50:
	/* 0x2a50: cmp    ebx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_2a53:
	/* 0x2a53: jne    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a53, 0x2035, x86_l_2035);
x86_l_2a59:
	/* 0x2a59: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2a5e:
	/* 0x2a5e: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a63:
	/* 0x2a63: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_4));
x86_l_2a6a:
	/* 0x2a6a: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x2a6a, 0x329e, x86_l_329e);
x86_l_2a6f:
	/* 0x2a6f: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2a72:
	/* 0x2a72: je     2a7d <generic_fexit_filter_arg+0x2a7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a72, 0x2a7d, x86_l_2a7d);
x86_l_2a74:
	/* 0x2a74: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_2a77:
	/* 0x2a77: jne    2e08 <generic_fexit_filter_arg+0x2e08> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a77, 0x2e08, x86_l_2e08);
x86_l_2a7d:
	/* 0x2a7d: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a81:
	/* 0x2a81: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2a81, 0x27a, x86_l_27a);
x86_l_2a87:
	/* 0x2a87: jmp    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JMP(0x2a87, 0x2e1e, x86_l_2e1e);
x86_l_2a8c:
	/* 0x2a8c: cmp    ebp,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 8ULL);
x86_l_2a8f:
	/* 0x2a8f: je     31ab <generic_fexit_filter_arg+0x31ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a8f, 0x31ab, x86_l_31ab);
x86_l_2a95:
	/* 0x2a95: cmp    ebp,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 9ULL);
x86_l_2a98:
	/* 0x2a98: je     3172 <generic_fexit_filter_arg+0x3172> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a98, 0x3172, x86_l_3172);
x86_l_2a9e:
	/* 0x2a9e: cmp    ebp,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 10ULL);
x86_l_2aa1:
	/* 0x2aa1: jne    2d4d <generic_fexit_filter_arg+0x2d4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2aa1, 0x2d4d, x86_l_2d4d);
x86_l_2aa7:
	/* 0x2aa7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2aac:
	/* 0x2aac: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ab1:
	/* 0x2ab1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_10));
x86_l_2ab8:
	/* 0x2ab8: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x2ab8, 0x31bc, x86_l_31bc);
x86_l_2abd:
	/* 0x2abd: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_2ac0:
	/* 0x2ac0: je     2f7c <generic_fexit_filter_arg+0x2f7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ac0, 0x2f7c, x86_l_2f7c);
x86_l_2ac6:
	/* 0x2ac6: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_2ac9:
	/* 0x2ac9: jne    2f6e <generic_fexit_filter_arg+0x2f6e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ac9, 0x2f6e, x86_l_2f6e);
x86_l_2acf:
	/* 0x2acf: mov    ecx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_2ad4:
	/* 0x2ad4: jmp    2f81 <generic_fexit_filter_arg+0x2f81> */
	X86_SIM_X86_JMP(0x2ad4, 0x2f81, x86_l_2f81);
x86_l_2ad9:
	/* 0x2ad9: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2ade:
	/* 0x2ade: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2ae0:
	/* 0x2ae0: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2ae0, 0x27a, x86_l_27a);
x86_l_2ae6:
	/* 0x2ae6: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_2ae9:
	/* 0x2ae9: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2ae9, 0x35ea, x86_l_35ea);
x86_l_2aef:
	/* 0x2aef: mov    edx,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2af4:
	/* 0x2af4: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2af7:
	/* 0x2af7: jle    2d7a <generic_fexit_filter_arg+0x2d7a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2af7, 0x2d7a, x86_l_2d7a);
x86_l_2afd:
	/* 0x2afd: lea    esi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_2b00:
	/* 0x2b00: cmp    esi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_2b03:
	/* 0x2b03: jae    2e98 <generic_fexit_filter_arg+0x2e98> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2b03, 0x2e98, x86_l_2e98);
x86_l_2b09:
	/* 0x2b09: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2b0e:
	/* 0x2b0e: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2b10:
	/* 0x2b10: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b10, 0x261, x86_l_261);
x86_l_2b16:
	/* 0x2b16: jmp    32c8 <generic_fexit_filter_arg+0x32c8> */
	X86_SIM_X86_JMP(0x2b16, 0x32c8, x86_l_32c8);
x86_l_2b1b:
	/* 0x2b1b: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2b20:
	/* 0x2b20: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2b22:
	/* 0x2b22: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b22, 0x27a, x86_l_27a);
x86_l_2b28:
	/* 0x2b28: cmp    ecx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 17ULL);
x86_l_2b2b:
	/* 0x2b2b: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b2b, 0x35ea, x86_l_35ea);
x86_l_2b31:
	/* 0x2b31: mov    edx,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b36:
	/* 0x2b36: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2b39:
	/* 0x2b39: jle    2d9e <generic_fexit_filter_arg+0x2d9e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2b39, 0x2d9e, x86_l_2d9e);
x86_l_2b3f:
	/* 0x2b3f: lea    esi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_2b42:
	/* 0x2b42: cmp    esi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_2b45:
	/* 0x2b45: jae    2eb3 <generic_fexit_filter_arg+0x2eb3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2b45, 0x2eb3, x86_l_2eb3);
x86_l_2b4b:
	/* 0x2b4b: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2b50:
	/* 0x2b50: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2b52:
	/* 0x2b52: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b52, 0x261, x86_l_261);
x86_l_2b58:
	/* 0x2b58: jmp    3311 <generic_fexit_filter_arg+0x3311> */
	X86_SIM_X86_JMP(0x2b58, 0x3311, x86_l_3311);
x86_l_2b5d:
	/* 0x2b5d: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
x86_l_2b5f:
	/* 0x2b5f: je     2ece <generic_fexit_filter_arg+0x2ece> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b5f, 0x2ece, x86_l_2ece);
x86_l_2b65:
	/* 0x2b65: cmp    ebx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2b68:
	/* 0x2b68: jne    911 <generic_fexit_filter_arg+0x911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b68, 0x911, x86_l_911);
x86_l_2b6e:
	/* 0x2b6e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2b73:
	/* 0x2b73: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b78:
	/* 0x2b78: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_1));
x86_l_2b7f:
	/* 0x2b7f: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2b7f, 0x2f51, x86_l_2f51);
x86_l_2b84:
	/* 0x2b84: cmp    ebx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_2b87:
	/* 0x2b87: je     328d <generic_fexit_filter_arg+0x328d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b87, 0x328d, x86_l_328d);
x86_l_2b8d:
	/* 0x2b8d: cmp    ebx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_2b90:
	/* 0x2b90: je     3254 <generic_fexit_filter_arg+0x3254> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b90, 0x3254, x86_l_3254);
x86_l_2b96:
	/* 0x2b96: cmp    ebx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_2b99:
	/* 0x2b99: jne    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b99, 0x2035, x86_l_2035);
x86_l_2b9f:
	/* 0x2b9f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2ba4:
	/* 0x2ba4: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ba9:
	/* 0x2ba9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_10));
x86_l_2bb0:
	/* 0x2bb0: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x2bb0, 0x329e, x86_l_329e);
x86_l_2bb5:
	/* 0x2bb5: cmp    r8d,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_32);
x86_l_2bb8:
	/* 0x2bb8: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2bbc:
	/* 0x2bbc: cmp    edx,edi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_32);
x86_l_2bbe:
	/* 0x2bbe: setbe  dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_BE);
x86_l_2bc2:
	/* 0x2bc2: and    dil,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2bc5:
	/* 0x2bc5: or     al,dil */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2bc8:
	/* 0x2bc8: cmp    esi,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 33ULL);
x86_l_2bcb:
	/* 0x2bcb: jb     2df7 <generic_fexit_filter_arg+0x2df7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2bcb, 0x2df7, x86_l_2df7);
x86_l_2bd1:
	/* 0x2bd1: mov    edi,DWORD PTR [r12+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2bd6:
	/* 0x2bd6: mov    esi,DWORD PTR [r12+0x2c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2bdb:
	/* 0x2bdb: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2bde:
	/* 0x2bde: ja     2de9 <generic_fexit_filter_arg+0x2de9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2bde, 0x2de9, x86_l_2de9);
x86_l_2be4:
	/* 0x2be4: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_2bea:
	/* 0x2bea: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_2bee:
	/* 0x2bee: jae    2de9 <generic_fexit_filter_arg+0x2de9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2bee, 0x2de9, x86_l_2de9);
x86_l_2bf4:
	/* 0x2bf4: cmp    edi,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_32);
x86_l_2bf6:
	/* 0x2bf6: setle  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_LE);
x86_l_2bf9:
	/* 0x2bf9: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2bfb:
	/* 0x2bfb: setle  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_LE);
x86_l_2bfe:
	/* 0x2bfe: jmp    2df3 <generic_fexit_filter_arg+0x2df3> */
	X86_SIM_X86_JMP(0x2bfe, 0x2df3, x86_l_2df3);
x86_l_2c03:
	/* 0x2c03: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2c08:
	/* 0x2c08: jmp    357d <generic_fexit_filter_arg+0x357d> */
	X86_SIM_X86_JMP(0x2c08, 0x357d, x86_l_357d);
x86_l_2c0d:
	/* 0x2c0d: cmp    edi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_32);
x86_l_2c0f:
	/* 0x2c0f: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c13:
	/* 0x2c13: ja     2c1d <generic_fexit_filter_arg+0x2c1d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c13, 0x2c1d, x86_l_2c1d);
x86_l_2c15:
	/* 0x2c15: cmp    eax,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2c17:
	/* 0x2c17: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2c17, 0x27a, x86_l_27a);
x86_l_2c1d:
	/* 0x2c1d: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_2c20:
	/* 0x2c20: jb     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c20, 0xc2, x86_l_c2);
x86_l_2c26:
	/* 0x2c26: mov    esi,DWORD PTR [r12+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2c2b:
	/* 0x2c2b: mov    edx,DWORD PTR [r12+0x2c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2c30:
	/* 0x2c30: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2c33:
	/* 0x2c33: ja     3107 <generic_fexit_filter_arg+0x3107> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c33, 0x3107, x86_l_3107);
x86_l_2c39:
	/* 0x2c39: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_2c3f:
	/* 0x2c3f: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_2c43:
	/* 0x2c43: jae    3107 <generic_fexit_filter_arg+0x3107> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2c43, 0x3107, x86_l_3107);
x86_l_2c49:
	/* 0x2c49: cmp    esi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_32);
x86_l_2c4b:
	/* 0x2c4b: jg     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2c4b, 0xc2, x86_l_c2);
x86_l_2c51:
	/* 0x2c51: cmp    eax,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32);
x86_l_2c53:
	/* 0x2c53: jle    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2c53, 0x27a, x86_l_27a);
x86_l_2c59:
	/* 0x2c59: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x2c59, 0xc2, x86_l_c2);
x86_l_2c5e:
	/* 0x2c5e: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c62:
	/* 0x2c62: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c62, 0x27a, x86_l_27a);
x86_l_2c68:
	/* 0x2c68: jmp    2c74 <generic_fexit_filter_arg+0x2c74> */
	X86_SIM_X86_JMP(0x2c68, 0x2c74, x86_l_2c74);
x86_l_2c6a:
	/* 0x2c6a: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c6e:
	/* 0x2c6e: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c6e, 0x27a, x86_l_27a);
x86_l_2c74:
	/* 0x2c74: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2c77:
	/* 0x2c77: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c77, 0x35ea, x86_l_35ea);
x86_l_2c7d:
	/* 0x2c7d: mov    esi,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c82:
	/* 0x2c82: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2c85:
	/* 0x2c85: jle    2ca2 <generic_fexit_filter_arg+0x2ca2> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2c85, 0x2ca2, x86_l_2ca2);
x86_l_2c87:
	/* 0x2c87: lea    edi,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_2c8a:
	/* 0x2c8a: cmp    edi,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 2ULL);
x86_l_2c8d:
	/* 0x2c8d: jae    2cd8 <generic_fexit_filter_arg+0x2cd8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2c8d, 0x2cd8, x86_l_2cd8);
x86_l_2c8f:
	/* 0x2c8f: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c93:
	/* 0x2c93: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c97:
	/* 0x2c97: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c97, 0x261, x86_l_261);
x86_l_2c9d:
	/* 0x2c9d: jmp    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JMP(0x2c9d, 0x339f, x86_l_339f);
x86_l_2ca2:
	/* 0x2ca2: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2ca5:
	/* 0x2ca5: je     2cf4 <generic_fexit_filter_arg+0x2cf4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ca5, 0x2cf4, x86_l_2cf4);
x86_l_2ca7:
	/* 0x2ca7: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2caa:
	/* 0x2caa: jne    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2caa, 0x339f, x86_l_339f);
x86_l_2cb0:
	/* 0x2cb0: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2cb3:
	/* 0x2cb3: ja     3395 <generic_fexit_filter_arg+0x3395> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cb3, 0x3395, x86_l_3395);
x86_l_2cb9:
	/* 0x2cb9: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_2cbf:
	/* 0x2cbf: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_2cc3:
	/* 0x2cc3: jae    3395 <generic_fexit_filter_arg+0x3395> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2cc3, 0x3395, x86_l_3395);
x86_l_2cc9:
	/* 0x2cc9: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ccd:
	/* 0x2ccd: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2ccd, 0x27a, x86_l_27a);
x86_l_2cd3:
	/* 0x2cd3: jmp    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JMP(0x2cd3, 0x339f, x86_l_339f);
x86_l_2cd8:
	/* 0x2cd8: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2cdb:
	/* 0x2cdb: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cdf:
	/* 0x2cdf: jne    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cdf, 0x339f, x86_l_339f);
x86_l_2ce5:
	/* 0x2ce5: test   DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ce9:
	/* 0x2ce9: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ce9, 0x27a, x86_l_27a);
x86_l_2cef:
	/* 0x2cef: jmp    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JMP(0x2cef, 0x339f, x86_l_339f);
x86_l_2cf4:
	/* 0x2cf4: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2cf7:
	/* 0x2cf7: ja     3389 <generic_fexit_filter_arg+0x3389> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cf7, 0x3389, x86_l_3389);
x86_l_2cfd:
	/* 0x2cfd: mov    r8d,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 5122ULL);
x86_l_2d03:
	/* 0x2d03: bt     r8d,ecx */
	X86_SIM_L_EXEC_BT(X86_R8, X86_RCX, X86_WIDTH_32);
x86_l_2d07:
	/* 0x2d07: jae    3389 <generic_fexit_filter_arg+0x3389> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2d07, 0x3389, x86_l_3389);
x86_l_2d0d:
	/* 0x2d0d: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d11:
	/* 0x2d11: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d11, 0x27a, x86_l_27a);
x86_l_2d17:
	/* 0x2d17: jmp    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JMP(0x2d17, 0x339f, x86_l_339f);
x86_l_2d1c:
	/* 0x2d1c: cmp    rdi,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_64);
x86_l_2d1f:
	/* 0x2d1f: setbe  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_BE);
x86_l_2d22:
	/* 0x2d22: cmp    rdx,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_2d25:
	/* 0x2d25: jmp    2df0 <generic_fexit_filter_arg+0x2df0> */
	X86_SIM_X86_JMP(0x2d25, 0x2df0, x86_l_2df0);
x86_l_2d2a:
	/* 0x2d2a: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
x86_l_2d2c:
	/* 0x2d2c: je     3139 <generic_fexit_filter_arg+0x3139> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d2c, 0x3139, x86_l_3139);
x86_l_2d32:
	/* 0x2d32: cmp    ebp,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 1ULL);
x86_l_2d35:
	/* 0x2d35: jne    2d4d <generic_fexit_filter_arg+0x2d4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d35, 0x2d4d, x86_l_2d4d);
x86_l_2d37:
	/* 0x2d37: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2d3c:
	/* 0x2d3c: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2d41:
	/* 0x2d41: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_1));
x86_l_2d48:
	/* 0x2d48: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x2d48, 0x31bc, x86_l_31bc);
x86_l_2d4d:
	/* 0x2d4d: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d4f:
	/* 0x2d4f: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2d54:
	/* 0x2d54: cmp    rax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 37ULL);
x86_l_2d58:
	/* 0x2d58: jbe    31fe <generic_fexit_filter_arg+0x31fe> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2d58, 0x31fe, x86_l_31fe);
x86_l_2d5e:
	/* 0x2d5e: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x2d5e, 0x269, x86_l_269);
x86_l_2d63:
	/* 0x2d63: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_2d66:
	/* 0x2d66: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d66, 0xc2, x86_l_c2);
x86_l_2d6c:
	/* 0x2d6c: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_2d6f:
	/* 0x2d6f: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2d6f, 0x27a, x86_l_27a);
x86_l_2d75:
	/* 0x2d75: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x2d75, 0xc2, x86_l_c2);
x86_l_2d7a:
	/* 0x2d7a: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2d7d:
	/* 0x2d7d: je     32bb <generic_fexit_filter_arg+0x32bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d7d, 0x32bb, x86_l_32bb);
x86_l_2d83:
	/* 0x2d83: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2d86:
	/* 0x2d86: jne    32c8 <generic_fexit_filter_arg+0x32c8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d86, 0x32c8, x86_l_32c8);
x86_l_2d8c:
	/* 0x2d8c: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2d91:
	/* 0x2d91: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2d93:
	/* 0x2d93: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d93, 0x27a, x86_l_27a);
x86_l_2d99:
	/* 0x2d99: jmp    32c8 <generic_fexit_filter_arg+0x32c8> */
	X86_SIM_X86_JMP(0x2d99, 0x32c8, x86_l_32c8);
x86_l_2d9e:
	/* 0x2d9e: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2da1:
	/* 0x2da1: je     3304 <generic_fexit_filter_arg+0x3304> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2da1, 0x3304, x86_l_3304);
x86_l_2da7:
	/* 0x2da7: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2daa:
	/* 0x2daa: jne    3311 <generic_fexit_filter_arg+0x3311> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2daa, 0x3311, x86_l_3311);
x86_l_2db0:
	/* 0x2db0: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2db5:
	/* 0x2db5: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2db7:
	/* 0x2db7: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2db7, 0x27a, x86_l_27a);
x86_l_2dbd:
	/* 0x2dbd: jmp    3311 <generic_fexit_filter_arg+0x3311> */
	X86_SIM_X86_JMP(0x2dbd, 0x3311, x86_l_3311);
x86_l_2dc2:
	/* 0x2dc2: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
x86_l_2dc4:
	/* 0x2dc4: je     321b <generic_fexit_filter_arg+0x321b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dc4, 0x321b, x86_l_321b);
x86_l_2dca:
	/* 0x2dca: cmp    ebx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2dcd:
	/* 0x2dcd: jne    2035 <generic_fexit_filter_arg+0x2035> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dcd, 0x2035, x86_l_2035);
x86_l_2dd3:
	/* 0x2dd3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2dd8:
	/* 0x2dd8: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ddd:
	/* 0x2ddd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_1));
x86_l_2de4:
	/* 0x2de4: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x2de4, 0x329e, x86_l_329e);
x86_l_2de9:
	/* 0x2de9: cmp    edi,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_32);
x86_l_2deb:
	/* 0x2deb: setbe  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_BE);
x86_l_2dee:
	/* 0x2dee: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2df0:
	/* 0x2df0: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_2df3:
	/* 0x2df3: and    dl,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_8, X86_ALU_AND);
x86_l_2df5:
	/* 0x2df5: or     al,dl */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDX, X86_WIDTH_8, X86_ALU_OR);
x86_l_2df7:
	/* 0x2df7: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dfb:
	/* 0x2dfb: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_2dfd:
	/* 0x2dfd: je     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dfd, 0x27a, x86_l_27a);
x86_l_2e03:
	/* 0x2e03: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x2e03, 0xc2, x86_l_c2);
x86_l_2e08:
	/* 0x2e08: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e0c:
	/* 0x2e0c: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e0c, 0x27a, x86_l_27a);
x86_l_2e12:
	/* 0x2e12: jmp    2e1e <generic_fexit_filter_arg+0x2e1e> */
	X86_SIM_X86_JMP(0x2e12, 0x2e1e, x86_l_2e1e);
x86_l_2e14:
	/* 0x2e14: cmp    QWORD PTR [r13+0x0],rsi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e18:
	/* 0x2e18: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e18, 0x27a, x86_l_27a);
x86_l_2e1e:
	/* 0x2e1e: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_2e21:
	/* 0x2e21: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e21, 0x35ea, x86_l_35ea);
x86_l_2e27:
	/* 0x2e27: mov    rdx,QWORD PTR [r12+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2e2c:
	/* 0x2e2c: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2e2f:
	/* 0x2e2f: jle    2e5a <generic_fexit_filter_arg+0x2e5a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2e2f, 0x2e5a, x86_l_2e5a);
x86_l_2e31:
	/* 0x2e31: lea    ecx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_2e34:
	/* 0x2e34: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_2e37:
	/* 0x2e37: jb     2e89 <generic_fexit_filter_arg+0x2e89> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e37, 0x2e89, x86_l_2e89);
x86_l_2e39:
	/* 0x2e39: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_2e3c:
	/* 0x2e3c: je     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e3c, 0x27a, x86_l_27a);
x86_l_2e42:
	/* 0x2e42: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2e45:
	/* 0x2e45: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e45, 0xc2, x86_l_c2);
x86_l_2e4b:
	/* 0x2e4b: test   QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e4f:
	/* 0x2e4f: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e4f, 0x27a, x86_l_27a);
x86_l_2e55:
	/* 0x2e55: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x2e55, 0x35ea, x86_l_35ea);
x86_l_2e5a:
	/* 0x2e5a: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2e5d:
	/* 0x2e5d: je     311c <generic_fexit_filter_arg+0x311c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e5d, 0x311c, x86_l_311c);
x86_l_2e63:
	/* 0x2e63: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2e66:
	/* 0x2e66: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e66, 0xc2, x86_l_c2);
x86_l_2e6c:
	/* 0x2e6c: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2e6f:
	/* 0x2e6f: je     2e7a <generic_fexit_filter_arg+0x2e7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e6f, 0x2e7a, x86_l_2e7a);
x86_l_2e71:
	/* 0x2e71: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_2e74:
	/* 0x2e74: jne    34c1 <generic_fexit_filter_arg+0x34c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e74, 0x34c1, x86_l_34c1);
x86_l_2e7a:
	/* 0x2e7a: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e7e:
	/* 0x2e7e: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2e7e, 0x27a, x86_l_27a);
x86_l_2e84:
	/* 0x2e84: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x2e84, 0x35ea, x86_l_35ea);
x86_l_2e89:
	/* 0x2e89: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e8d:
	/* 0x2e8d: jne    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e8d, 0x35ea, x86_l_35ea);
x86_l_2e93:
	/* 0x2e93: jmp    261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JMP(0x2e93, 0x261, x86_l_261);
x86_l_2e98:
	/* 0x2e98: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2e9b:
	/* 0x2e9b: jne    32c8 <generic_fexit_filter_arg+0x32c8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e9b, 0x32c8, x86_l_32c8);
x86_l_2ea1:
	/* 0x2ea1: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2ea6:
	/* 0x2ea6: test   edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2ea8:
	/* 0x2ea8: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ea8, 0x27a, x86_l_27a);
x86_l_2eae:
	/* 0x2eae: jmp    32c8 <generic_fexit_filter_arg+0x32c8> */
	X86_SIM_X86_JMP(0x2eae, 0x32c8, x86_l_32c8);
x86_l_2eb3:
	/* 0x2eb3: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2eb6:
	/* 0x2eb6: jne    3311 <generic_fexit_filter_arg+0x3311> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2eb6, 0x3311, x86_l_3311);
x86_l_2ebc:
	/* 0x2ebc: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2ec1:
	/* 0x2ec1: test   edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2ec3:
	/* 0x2ec3: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ec3, 0x27a, x86_l_27a);
x86_l_2ec9:
	/* 0x2ec9: jmp    3311 <generic_fexit_filter_arg+0x3311> */
	X86_SIM_X86_JMP(0x2ec9, 0x3311, x86_l_3311);
x86_l_2ece:
	/* 0x2ece: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2ed3:
	/* 0x2ed3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_0));
x86_l_2eda:
	/* 0x2eda: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2edf:
	/* 0x2edf: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2edf, 0x2f51, x86_l_2f51);
x86_l_2ee1:
	/* 0x2ee1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2ee6:
	/* 0x2ee6: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2eeb:
	/* 0x2eeb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_3));
x86_l_2ef2:
	/* 0x2ef2: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2ef2, 0x2f51, x86_l_2f51);
x86_l_2ef4:
	/* 0x2ef4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2ef9:
	/* 0x2ef9: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2efe:
	/* 0x2efe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_6));
x86_l_2f05:
	/* 0x2f05: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2f05, 0x2f51, x86_l_2f51);
x86_l_2f07:
	/* 0x2f07: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2f0c:
	/* 0x2f0c: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f11:
	/* 0x2f11: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_9));
x86_l_2f18:
	/* 0x2f18: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2f18, 0x2f51, x86_l_2f51);
x86_l_2f1a:
	/* 0x2f1a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2f1f:
	/* 0x2f1f: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f24:
	/* 0x2f24: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_2));
x86_l_2f2b:
	/* 0x2f2b: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2f2b, 0x2f51, x86_l_2f51);
x86_l_2f2d:
	/* 0x2f2d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2f32:
	/* 0x2f32: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f37:
	/* 0x2f37: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_5));
x86_l_2f3e:
	/* 0x2f3e: jmp    2f51 <generic_fexit_filter_arg+0x2f51> */
	X86_SIM_X86_JMP(0x2f3e, 0x2f51, x86_l_2f51);
x86_l_2f40:
	/* 0x2f40: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2f45:
	/* 0x2f45: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f4a:
	/* 0x2f4a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_8));
x86_l_2f51:
	/* 0x2f51: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2f53:
	/* 0x2f53: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2f56:
	/* 0x2f56: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f56, 0x31df, x86_l_31df);
x86_l_2f5c:
	/* 0x2f5c: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2f5f:
	/* 0x2f5f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2f64:
	/* 0x2f64: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f69:
	/* 0x2f69: jmp    31d3 <generic_fexit_filter_arg+0x31d3> */
	X86_SIM_X86_JMP(0x2f69, 0x31d3, x86_l_31d3);
x86_l_2f6e:
	/* 0x2f6e: mov    ecx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_2f73:
	/* 0x2f73: jmp    2f81 <generic_fexit_filter_arg+0x2f81> */
	X86_SIM_X86_JMP(0x2f73, 0x2f81, x86_l_2f81);
x86_l_2f75:
	/* 0x2f75: mov    ecx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_2f7a:
	/* 0x2f7a: jmp    2f81 <generic_fexit_filter_arg+0x2f81> */
	X86_SIM_X86_JMP(0x2f7a, 0x2f81, x86_l_2f81);
x86_l_2f7c:
	/* 0x2f7c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2f81:
	/* 0x2f81: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_2f83:
	/* 0x2f83: and    eax,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2f86:
	/* 0x2f86: mov    eax,DWORD PTR [r12+rax*4+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_2f8b:
	/* 0x2f8b: cmp    eax,0xffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_2f8e:
	/* 0x2f8e: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f8e, 0x357b, x86_l_357b);
x86_l_2f94:
	/* 0x2f94: mov    DWORD PTR [rsp+0x88],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2f9b:
	/* 0x2f9b: mov    DWORD PTR [rsp+0x64],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_2f9f:
	/* 0x2f9f: mov    QWORD PTR [rsp+0x68],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2fa4:
	/* 0x2fa4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2fa9:
	/* 0x2fa9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_heap));
x86_l_2fb0:
	/* 0x2fb0: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2fb5:
	/* 0x2fb5: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2fb8:
	/* 0x2fb8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2fba:
	/* 0x2fba: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_2fbd:
	/* 0x2fbd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2fc2:
	/* 0x2fc2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_2fc9:
	/* 0x2fc9: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_2fcc:
	/* 0x2fcc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2fce:
	/* 0x2fce: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2fd3:
	/* 0x2fd3: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_2fd6:
	/* 0x2fd6: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fd6, 0x357b, x86_l_357b);
x86_l_2fdc:
	/* 0x2fdc: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
x86_l_2fe1:
	/* 0x2fe1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2fe4:
	/* 0x2fe4: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe8:
	/* 0x2fe8: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2fed:
	/* 0x2fed: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ff2:
	/* 0x2ff2: je     358b <generic_fexit_filter_arg+0x358b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ff2, 0x358b, x86_l_358b);
x86_l_2ff8:
	/* 0x2ff8: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_2ffb:
	/* 0x2ffb: mov    ebx,DWORD PTR [rsp+0x64] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_2fff:
	/* 0x2fff: cmp    ebx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_3002:
	/* 0x3002: jg     3043 <generic_fexit_filter_arg+0x3043> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3002, 0x3043, x86_l_3043);
x86_l_3004:
	/* 0x3004: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3009:
	/* 0x3009: mov    BYTE PTR [rax],bpl */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_300c:
	/* 0x300c: lea    rdi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3010:
	/* 0x3010: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3015:
	/* 0x3015: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_301a:
	/* 0x301a: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_301c:
	/* 0x301c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_301e:
	/* 0x301e: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3023:
	/* 0x3023: sub    esi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3025:
	/* 0x3025: jbe    3083 <generic_fexit_filter_arg+0x3083> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3025, 0x3083, x86_l_3083);
x86_l_3027:
	/* 0x3027: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_302c:
	/* 0x302c: lea    rdi,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3030:
	/* 0x3030: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_3033:
	/* 0x3033: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3039:
	/* 0x3039: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_303e:
	/* 0x303e: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3041:
	/* 0x3041: jmp    3081 <generic_fexit_filter_arg+0x3081> */
	X86_SIM_X86_JMP(0x3041, 0x3081, x86_l_3081);
x86_l_3043:
	/* 0x3043: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3048:
	/* 0x3048: mov    WORD PTR [rax],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_304b:
	/* 0x304b: lea    rdi,[rax+0x2] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_304f:
	/* 0x304f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3054:
	/* 0x3054: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3059:
	/* 0x3059: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
x86_l_305b:
	/* 0x305b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_305d:
	/* 0x305d: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3062:
	/* 0x3062: sub    esi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3064:
	/* 0x3064: jbe    3083 <generic_fexit_filter_arg+0x3083> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3064, 0x3083, x86_l_3083);
x86_l_3066:
	/* 0x3066: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_306b:
	/* 0x306b: lea    rdi,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_306f:
	/* 0x306f: add    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_3073:
	/* 0x3073: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3079:
	/* 0x3079: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_307e:
	/* 0x307e: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_3081:
	/* 0x3081: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3083:
	/* 0x3083: mov    eax,DWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_308a:
	/* 0x308a: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_308e:
	/* 0x308e: cmp    ebx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_3091:
	/* 0x3091: jle    30cd <generic_fexit_filter_arg+0x30cd> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3091, 0x30cd, x86_l_30cd);
x86_l_3093:
	/* 0x3093: cmp    ebx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_3096:
	/* 0x3096: jg     3358 <generic_fexit_filter_arg+0x3358> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3096, 0x3358, x86_l_3358);
x86_l_309c:
	/* 0x309c: cmp    ebx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_309f:
	/* 0x309f: je     353e <generic_fexit_filter_arg+0x353e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x309f, 0x353e, x86_l_353e);
x86_l_30a5:
	/* 0x30a5: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_30a8:
	/* 0x30a8: je     3505 <generic_fexit_filter_arg+0x3505> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30a8, 0x3505, x86_l_3505);
x86_l_30ae:
	/* 0x30ae: cmp    ebx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_30b1:
	/* 0x30b1: jne    357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30b1, 0x357b, x86_l_357b);
x86_l_30b7:
	/* 0x30b7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_30bc:
	/* 0x30bc: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30c1:
	/* 0x30c1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_7));
x86_l_30c8:
	/* 0x30c8: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x30c8, 0x3562, x86_l_3562);
x86_l_30cd:
	/* 0x30cd: cmp    ebx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_30d0:
	/* 0x30d0: jle    3444 <generic_fexit_filter_arg+0x3444> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x30d0, 0x3444, x86_l_3444);
x86_l_30d6:
	/* 0x30d6: cmp    ebx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_30d9:
	/* 0x30d9: je     352b <generic_fexit_filter_arg+0x352b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30d9, 0x352b, x86_l_352b);
x86_l_30df:
	/* 0x30df: cmp    ebx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_30e2:
	/* 0x30e2: je     34f2 <generic_fexit_filter_arg+0x34f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30e2, 0x34f2, x86_l_34f2);
x86_l_30e8:
	/* 0x30e8: cmp    ebx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_30eb:
	/* 0x30eb: jne    357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30eb, 0x357b, x86_l_357b);
x86_l_30f1:
	/* 0x30f1: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_30f6:
	/* 0x30f6: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30fb:
	/* 0x30fb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_4));
x86_l_3102:
	/* 0x3102: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x3102, 0x3562, x86_l_3562);
x86_l_3107:
	/* 0x3107: cmp    esi,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_32);
x86_l_3109:
	/* 0x3109: ja     c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3109, 0xc2, x86_l_c2);
x86_l_310f:
	/* 0x310f: cmp    eax,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32);
x86_l_3111:
	/* 0x3111: jbe    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3111, 0x27a, x86_l_27a);
x86_l_3117:
	/* 0x3117: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x3117, 0xc2, x86_l_c2);
x86_l_311c:
	/* 0x311c: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_311f:
	/* 0x311f: je     312a <generic_fexit_filter_arg+0x312a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x311f, 0x312a, x86_l_312a);
x86_l_3121:
	/* 0x3121: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_3124:
	/* 0x3124: jne    34d0 <generic_fexit_filter_arg+0x34d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3124, 0x34d0, x86_l_34d0);
x86_l_312a:
	/* 0x312a: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_312e:
	/* 0x312e: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x312e, 0x27a, x86_l_27a);
x86_l_3134:
	/* 0x3134: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x3134, 0x35ea, x86_l_35ea);
x86_l_3139:
	/* 0x3139: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_313e:
	/* 0x313e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_0));
x86_l_3145:
	/* 0x3145: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_314a:
	/* 0x314a: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x314a, 0x31bc, x86_l_31bc);
x86_l_314c:
	/* 0x314c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3151:
	/* 0x3151: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3156:
	/* 0x3156: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_3));
x86_l_315d:
	/* 0x315d: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x315d, 0x31bc, x86_l_31bc);
x86_l_315f:
	/* 0x315f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3164:
	/* 0x3164: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3169:
	/* 0x3169: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_6));
x86_l_3170:
	/* 0x3170: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x3170, 0x31bc, x86_l_31bc);
x86_l_3172:
	/* 0x3172: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3177:
	/* 0x3177: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_317c:
	/* 0x317c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_9));
x86_l_3183:
	/* 0x3183: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x3183, 0x31bc, x86_l_31bc);
x86_l_3185:
	/* 0x3185: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_318a:
	/* 0x318a: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_318f:
	/* 0x318f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_2));
x86_l_3196:
	/* 0x3196: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x3196, 0x31bc, x86_l_31bc);
x86_l_3198:
	/* 0x3198: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_319d:
	/* 0x319d: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31a2:
	/* 0x31a2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_5));
x86_l_31a9:
	/* 0x31a9: jmp    31bc <generic_fexit_filter_arg+0x31bc> */
	X86_SIM_X86_JMP(0x31a9, 0x31bc, x86_l_31bc);
x86_l_31ab:
	/* 0x31ab: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_31b0:
	/* 0x31b0: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31b5:
	/* 0x31b5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_8));
x86_l_31bc:
	/* 0x31bc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_31be:
	/* 0x31be: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_31c1:
	/* 0x31c1: je     31df <generic_fexit_filter_arg+0x31df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c1, 0x31df, x86_l_31df);
x86_l_31c3:
	/* 0x31c3: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_31c6:
	/* 0x31c6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_31cb:
	/* 0x31cb: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_31d3:
	/* 0x31d3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_31d5:
	/* 0x31d5: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31d7:
	/* 0x31d7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_31da:
	/* 0x31da: setne  bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_NE);
x86_l_31dd:
	/* 0x31dd: jmp    31e1 <generic_fexit_filter_arg+0x31e1> */
	X86_SIM_X86_JMP(0x31dd, 0x31e1, x86_l_31e1);
x86_l_31df:
	/* 0x31df: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31e1:
	/* 0x31e1: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31e5:
	/* 0x31e5: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31ea:
	/* 0x31ea: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31ef:
	/* 0x31ef: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_31f4:
	/* 0x31f4: cmp    rax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 37ULL);
x86_l_31f8:
	/* 0x31f8: ja     269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_A, 0x31f8, 0x269, x86_l_269);
x86_l_31fe:
	/* 0x31fe: movabs rcx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 137640280144ULL);
x86_l_3208:
	/* 0x3208: bt     rcx,rax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_320c:
	/* 0x320c: jae    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x320c, 0x269, x86_l_269);
x86_l_3212:
	/* 0x3212: xor    rbx,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_3216:
	/* 0x3216: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x3216, 0x269, x86_l_269);
x86_l_321b:
	/* 0x321b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3220:
	/* 0x3220: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_0));
x86_l_3227:
	/* 0x3227: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_322c:
	/* 0x322c: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x322c, 0x329e, x86_l_329e);
x86_l_322e:
	/* 0x322e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3233:
	/* 0x3233: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3238:
	/* 0x3238: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_3));
x86_l_323f:
	/* 0x323f: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x323f, 0x329e, x86_l_329e);
x86_l_3241:
	/* 0x3241: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3246:
	/* 0x3246: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_324b:
	/* 0x324b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_6));
x86_l_3252:
	/* 0x3252: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x3252, 0x329e, x86_l_329e);
x86_l_3254:
	/* 0x3254: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3259:
	/* 0x3259: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_325e:
	/* 0x325e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_9));
x86_l_3265:
	/* 0x3265: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x3265, 0x329e, x86_l_329e);
x86_l_3267:
	/* 0x3267: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_326c:
	/* 0x326c: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3271:
	/* 0x3271: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_2));
x86_l_3278:
	/* 0x3278: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x3278, 0x329e, x86_l_329e);
x86_l_327a:
	/* 0x327a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_327f:
	/* 0x327f: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3284:
	/* 0x3284: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_5));
x86_l_328b:
	/* 0x328b: jmp    329e <generic_fexit_filter_arg+0x329e> */
	X86_SIM_X86_JMP(0x328b, 0x329e, x86_l_329e);
x86_l_328d:
	/* 0x328d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3292:
	/* 0x3292: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3297:
	/* 0x3297: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_8));
x86_l_329e:
	/* 0x329e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_32a0:
	/* 0x32a0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_32a3:
	/* 0x32a3: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32a3, 0x357b, x86_l_357b);
x86_l_32a9:
	/* 0x32a9: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_32ac:
	/* 0x32ac: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_32b1:
	/* 0x32b1: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_32b6:
	/* 0x32b6: jmp    1a26 <generic_fexit_filter_arg+0x1a26> */
	X86_SIM_X86_JMP(0x32b6, 0x1a26, x86_l_1a26);
x86_l_32bb:
	/* 0x32bb: movzx  esi,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_32c0:
	/* 0x32c0: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_32c2:
	/* 0x32c2: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32c2, 0x27a, x86_l_27a);
x86_l_32c8:
	/* 0x32c8: cmp    ecx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 21ULL);
x86_l_32cb:
	/* 0x32cb: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32cb, 0x35ea, x86_l_35ea);
x86_l_32d1:
	/* 0x32d1: mov    ecx,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_32d6:
	/* 0x32d6: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_32d9:
	/* 0x32d9: jle    346b <generic_fexit_filter_arg+0x346b> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x32d9, 0x346b, x86_l_346b);
x86_l_32df:
	/* 0x32df: lea    edx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_32e2:
	/* 0x32e2: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_32e5:
	/* 0x32e5: jb     34a8 <generic_fexit_filter_arg+0x34a8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32e5, 0x34a8, x86_l_34a8);
x86_l_32eb:
	/* 0x32eb: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_32ee:
	/* 0x32ee: je     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32ee, 0x27a, x86_l_27a);
x86_l_32f4:
	/* 0x32f4: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_32f7:
	/* 0x32f7: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32f7, 0xc2, x86_l_c2);
x86_l_32fd:
	/* 0x32fd: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_3302:
	/* 0x3302: jmp    334b <generic_fexit_filter_arg+0x334b> */
	X86_SIM_X86_JMP(0x3302, 0x334b, x86_l_334b);
x86_l_3304:
	/* 0x3304: movzx  esi,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3309:
	/* 0x3309: cmp    edx,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_330b:
	/* 0x330b: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x330b, 0x27a, x86_l_27a);
x86_l_3311:
	/* 0x3311: cmp    ecx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 21ULL);
x86_l_3314:
	/* 0x3314: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3314, 0x35ea, x86_l_35ea);
x86_l_331a:
	/* 0x331a: mov    ecx,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_331f:
	/* 0x331f: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3322:
	/* 0x3322: jle    3484 <generic_fexit_filter_arg+0x3484> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3322, 0x3484, x86_l_3484);
x86_l_3328:
	/* 0x3328: lea    edx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_332b:
	/* 0x332b: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_332e:
	/* 0x332e: jb     34af <generic_fexit_filter_arg+0x34af> */
	X86_SIM_X86_JCC(X86_CC_B, 0x332e, 0x34af, x86_l_34af);
x86_l_3334:
	/* 0x3334: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_3337:
	/* 0x3337: je     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3337, 0x27a, x86_l_27a);
x86_l_333d:
	/* 0x333d: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_3340:
	/* 0x3340: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3340, 0xc2, x86_l_c2);
x86_l_3346:
	/* 0x3346: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_334b:
	/* 0x334b: test   ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_334d:
	/* 0x334d: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x334d, 0x27a, x86_l_27a);
x86_l_3353:
	/* 0x3353: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x3353, 0x35ea, x86_l_35ea);
x86_l_3358:
	/* 0x3358: cmp    ebx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_335b:
	/* 0x335b: je     3551 <generic_fexit_filter_arg+0x3551> */
	X86_SIM_X86_JCC(X86_CC_E, 0x335b, 0x3551, x86_l_3551);
x86_l_3361:
	/* 0x3361: cmp    ebx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_3364:
	/* 0x3364: je     3518 <generic_fexit_filter_arg+0x3518> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3364, 0x3518, x86_l_3518);
x86_l_336a:
	/* 0x336a: cmp    ebx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_336d:
	/* 0x336d: jne    357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x336d, 0x357b, x86_l_357b);
x86_l_3373:
	/* 0x3373: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3378:
	/* 0x3378: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_337d:
	/* 0x337d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_10));
x86_l_3384:
	/* 0x3384: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x3384, 0x3562, x86_l_3562);
x86_l_3389:
	/* 0x3389: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_338d:
	/* 0x338d: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x338d, 0x27a, x86_l_27a);
x86_l_3393:
	/* 0x3393: jmp    339f <generic_fexit_filter_arg+0x339f> */
	X86_SIM_X86_JMP(0x3393, 0x339f, x86_l_339f);
x86_l_3395:
	/* 0x3395: cmp    DWORD PTR [r13+0x0],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3399:
	/* 0x3399: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3399, 0x27a, x86_l_27a);
x86_l_339f:
	/* 0x339f: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_33a2:
	/* 0x33a2: jb     35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x33a2, 0x35ea, x86_l_35ea);
x86_l_33a8:
	/* 0x33a8: mov    edx,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_33ad:
	/* 0x33ad: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_33b0:
	/* 0x33b0: jle    33db <generic_fexit_filter_arg+0x33db> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x33b0, 0x33db, x86_l_33db);
x86_l_33b2:
	/* 0x33b2: lea    ecx,[rax-0x3] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_33b5:
	/* 0x33b5: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_33b8:
	/* 0x33b8: jb     340f <generic_fexit_filter_arg+0x340f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x33b8, 0x340f, x86_l_340f);
x86_l_33ba:
	/* 0x33ba: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_33bd:
	/* 0x33bd: je     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33bd, 0x27a, x86_l_27a);
x86_l_33c3:
	/* 0x33c3: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_33c6:
	/* 0x33c6: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33c6, 0xc2, x86_l_c2);
x86_l_33cc:
	/* 0x33cc: test   DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33d0:
	/* 0x33d0: jne    27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33d0, 0x27a, x86_l_27a);
x86_l_33d6:
	/* 0x33d6: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x33d6, 0x35ea, x86_l_35ea);
x86_l_33db:
	/* 0x33db: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_33de:
	/* 0x33de: je     341e <generic_fexit_filter_arg+0x341e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33de, 0x341e, x86_l_341e);
x86_l_33e0:
	/* 0x33e0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_33e3:
	/* 0x33e3: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33e3, 0xc2, x86_l_c2);
x86_l_33e9:
	/* 0x33e9: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_33ec:
	/* 0x33ec: ja     35d4 <generic_fexit_filter_arg+0x35d4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x33ec, 0x35d4, x86_l_35d4);
x86_l_33f2:
	/* 0x33f2: mov    esi,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 5122ULL);
x86_l_33f7:
	/* 0x33f7: bt     esi,ecx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_33fa:
	/* 0x33fa: jae    35d4 <generic_fexit_filter_arg+0x35d4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x33fa, 0x35d4, x86_l_35d4);
x86_l_3400:
	/* 0x3400: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3404:
	/* 0x3404: jl     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3404, 0x27a, x86_l_27a);
x86_l_340a:
	/* 0x340a: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x340a, 0x35ea, x86_l_35ea);
x86_l_340f:
	/* 0x340f: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3413:
	/* 0x3413: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3413, 0x261, x86_l_261);
x86_l_3419:
	/* 0x3419: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x3419, 0x35ea, x86_l_35ea);
x86_l_341e:
	/* 0x341e: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_3421:
	/* 0x3421: ja     35e0 <generic_fexit_filter_arg+0x35e0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3421, 0x35e0, x86_l_35e0);
x86_l_3427:
	/* 0x3427: mov    esi,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 5122ULL);
x86_l_342c:
	/* 0x342c: bt     esi,ecx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_342f:
	/* 0x342f: jae    35e0 <generic_fexit_filter_arg+0x35e0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x342f, 0x35e0, x86_l_35e0);
x86_l_3435:
	/* 0x3435: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3439:
	/* 0x3439: jg     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3439, 0x27a, x86_l_27a);
x86_l_343f:
	/* 0x343f: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x343f, 0x35ea, x86_l_35ea);
x86_l_3444:
	/* 0x3444: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
x86_l_3446:
	/* 0x3446: je     34df <generic_fexit_filter_arg+0x34df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3446, 0x34df, x86_l_34df);
x86_l_344c:
	/* 0x344c: cmp    ebx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_344f:
	/* 0x344f: jne    357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x344f, 0x357b, x86_l_357b);
x86_l_3455:
	/* 0x3455: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_345a:
	/* 0x345a: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_345f:
	/* 0x345f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_1));
x86_l_3466:
	/* 0x3466: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x3466, 0x3562, x86_l_3562);
x86_l_346b:
	/* 0x346b: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_346e:
	/* 0x346e: je     35be <generic_fexit_filter_arg+0x35be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x346e, 0x35be, x86_l_35be);
x86_l_3474:
	/* 0x3474: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3477:
	/* 0x3477: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3477, 0xc2, x86_l_c2);
x86_l_347d:
	/* 0x347d: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_3482:
	/* 0x3482: jmp    349b <generic_fexit_filter_arg+0x349b> */
	X86_SIM_X86_JMP(0x3482, 0x349b, x86_l_349b);
x86_l_3484:
	/* 0x3484: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3487:
	/* 0x3487: je     35c5 <generic_fexit_filter_arg+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3487, 0x35c5, x86_l_35c5);
x86_l_348d:
	/* 0x348d: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3490:
	/* 0x3490: jne    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3490, 0xc2, x86_l_c2);
x86_l_3496:
	/* 0x3496: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_349b:
	/* 0x349b: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_349d:
	/* 0x349d: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x349d, 0x27a, x86_l_27a);
x86_l_34a3:
	/* 0x34a3: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x34a3, 0x35ea, x86_l_35ea);
x86_l_34a8:
	/* 0x34a8: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_34ad:
	/* 0x34ad: jmp    34b4 <generic_fexit_filter_arg+0x34b4> */
	X86_SIM_X86_JMP(0x34ad, 0x34b4, x86_l_34b4);
x86_l_34af:
	/* 0x34af: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_34b4:
	/* 0x34b4: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_34b6:
	/* 0x34b6: je     261 <generic_fexit_filter_arg+0x261> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34b6, 0x261, x86_l_261);
x86_l_34bc:
	/* 0x34bc: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x34bc, 0x35ea, x86_l_35ea);
x86_l_34c1:
	/* 0x34c1: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34c5:
	/* 0x34c5: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x34c5, 0x27a, x86_l_27a);
x86_l_34cb:
	/* 0x34cb: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x34cb, 0x35ea, x86_l_35ea);
x86_l_34d0:
	/* 0x34d0: cmp    QWORD PTR [r13+0x0],rdx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34d4:
	/* 0x34d4: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x34d4, 0x27a, x86_l_27a);
x86_l_34da:
	/* 0x34da: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x34da, 0x35ea, x86_l_35ea);
x86_l_34df:
	/* 0x34df: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_34e4:
	/* 0x34e4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_0));
x86_l_34eb:
	/* 0x34eb: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_34f0:
	/* 0x34f0: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x34f0, 0x3562, x86_l_3562);
x86_l_34f2:
	/* 0x34f2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_34f7:
	/* 0x34f7: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_34fc:
	/* 0x34fc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_3));
x86_l_3503:
	/* 0x3503: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x3503, 0x3562, x86_l_3562);
x86_l_3505:
	/* 0x3505: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_350a:
	/* 0x350a: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_350f:
	/* 0x350f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_6));
x86_l_3516:
	/* 0x3516: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x3516, 0x3562, x86_l_3562);
x86_l_3518:
	/* 0x3518: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_351d:
	/* 0x351d: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3522:
	/* 0x3522: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_9));
x86_l_3529:
	/* 0x3529: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x3529, 0x3562, x86_l_3562);
x86_l_352b:
	/* 0x352b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3530:
	/* 0x3530: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3535:
	/* 0x3535: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_2));
x86_l_353c:
	/* 0x353c: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x353c, 0x3562, x86_l_3562);
x86_l_353e:
	/* 0x353e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3543:
	/* 0x3543: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3548:
	/* 0x3548: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_5));
x86_l_354f:
	/* 0x354f: jmp    3562 <generic_fexit_filter_arg+0x3562> */
	X86_SIM_X86_JMP(0x354f, 0x3562, x86_l_3562);
x86_l_3551:
	/* 0x3551: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3556:
	/* 0x3556: lea    rsi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_355b:
	/* 0x355b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&string_maps_8));
x86_l_3562:
	/* 0x3562: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3564:
	/* 0x3564: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3567:
	/* 0x3567: je     357b <generic_fexit_filter_arg+0x357b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3567, 0x357b, x86_l_357b);
x86_l_3569:
	/* 0x3569: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_356c:
	/* 0x356c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3571:
	/* 0x3571: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3576:
	/* 0x3576: jmp    1a26 <generic_fexit_filter_arg+0x1a26> */
	X86_SIM_X86_JMP(0x3576, 0x1a26, x86_l_1a26);
x86_l_357b:
	/* 0x357b: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_357d:
	/* 0x357d: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3581:
	/* 0x3581: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3586:
	/* 0x3586: mov    r11,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_358b:
	/* 0x358b: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3590:
	/* 0x3590: cmp    rax,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 37ULL);
x86_l_3594:
	/* 0x3594: ja     269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3594, 0x269, x86_l_269);
x86_l_359a:
	/* 0x359a: movabs rcx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_64, 137640280144ULL);
x86_l_35a4:
	/* 0x35a4: bt     rcx,rax */
	X86_SIM_L_EXEC_BT(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_35a8:
	/* 0x35a8: jae    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x35a8, 0x269, x86_l_269);
x86_l_35ae:
	/* 0x35ae: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_35b0:
	/* 0x35b0: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
x86_l_35b3:
	/* 0x35b3: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_35b6:
	/* 0x35b6: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_35b9:
	/* 0x35b9: jmp    269 <generic_fexit_filter_arg+0x269> */
	X86_SIM_X86_JMP(0x35b9, 0x269, x86_l_269);
x86_l_35be:
	/* 0x35be: movzx  edx,BYTE PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_35c3:
	/* 0x35c3: jmp    35ca <generic_fexit_filter_arg+0x35ca> */
	X86_SIM_X86_JMP(0x35c3, 0x35ca, x86_l_35ca);
x86_l_35c5:
	/* 0x35c5: movzx  edx,WORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_35ca:
	/* 0x35ca: cmp    ecx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32);
x86_l_35cc:
	/* 0x35cc: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x35cc, 0x27a, x86_l_27a);
x86_l_35d2:
	/* 0x35d2: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x35d2, 0x35ea, x86_l_35ea);
x86_l_35d4:
	/* 0x35d4: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35d8:
	/* 0x35d8: jb     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x35d8, 0x27a, x86_l_27a);
x86_l_35de:
	/* 0x35de: jmp    35ea <generic_fexit_filter_arg+0x35ea> */
	X86_SIM_X86_JMP(0x35de, 0x35ea, x86_l_35ea);
x86_l_35e0:
	/* 0x35e0: cmp    DWORD PTR [r13+0x0],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35e4:
	/* 0x35e4: ja     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x35e4, 0x27a, x86_l_27a);
x86_l_35ea:
	/* 0x35ea: or     eax,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_35ed:
	/* 0x35ed: cmp    eax,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 6ULL);
x86_l_35f0:
	/* 0x35f0: je     27a <generic_fexit_filter_arg+0x27a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35f0, 0x27a, x86_l_27a);
x86_l_35f6:
	/* 0x35f6: jmp    c2 <generic_fexit_filter_arg+0xc2> */
	X86_SIM_X86_JMP(0x35f6, 0xc2, x86_l_c2);
x86_l_366d:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_35fb */
x86_l_35fb:
	/* 0x35fb: mov    eax,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_3600:
	/* 0x3600: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
x86_l_3603:
	/* 0x3603: je     366c <native_bpf_strncasestr+0x71> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3603, 0x366c, x86_l_366c);
x86_l_3605:
	/* 0x3605: push   rbx */
	X86_SIM_L_EXEC_PUSH(X86_RBX);
x86_l_3606:
	/* 0x3606: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3608:
	/* 0x3608: jmp    3615 <native_bpf_strncasestr+0x1a> */
	X86_SIM_X86_SUB_JMP(0x3608, 0x3615, x86_l_3615);
x86_l_360a:
	/* 0x360a: inc    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_360d:
	/* 0x360d: inc    rdi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_3610:
	/* 0x3610: cmp    rcx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64);
x86_l_3613:
	/* 0x3613: je     366b <native_bpf_strncasestr+0x70> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3613, 0x366b, x86_l_366b);
x86_l_3615:
	/* 0x3615: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3618:
	/* 0x3618: lea    r9,[rcx+r8*1] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_361c:
	/* 0x361c: cmp    r9,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64);
x86_l_361f:
	/* 0x361f: jae    360a <native_bpf_strncasestr+0xf> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x361f, 0x360a, x86_l_360a);
x86_l_3621:
	/* 0x3621: movsx  r9d,BYTE PTR [rsi+r8*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R9, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_3626:
	/* 0x3626: test   r9d,r9d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32);
x86_l_3629:
	/* 0x3629: je     3669 <native_bpf_strncasestr+0x6e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3629, 0x3669, x86_l_3669);
x86_l_362b:
	/* 0x362b: movsx  r10d,BYTE PTR [rdi+r8*1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_3630:
	/* 0x3630: lea    r11d,[r10-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R11, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_3634:
	/* 0x3634: mov    ebx,r10d */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R10, X86_WIDTH_32);
x86_l_3637:
	/* 0x3637: or     ebx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_363a:
	/* 0x363a: cmp    r11d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R11, X86_WIDTH_32, 26ULL);
x86_l_363e:
	/* 0x363e: cmovae ebx,r10d */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_R10, X86_WIDTH_32, X86_CC_AE);
x86_l_3642:
	/* 0x3642: lea    r10d,[r9-0x41] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_3646:
	/* 0x3646: mov    r11d,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R9, X86_WIDTH_32);
x86_l_3649:
	/* 0x3649: or     r11d,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_364d:
	/* 0x364d: cmp    r10d,0x1a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 26ULL);
x86_l_3651:
	/* 0x3651: cmovae r11d,r9d */
	X86_SIM_L_EXEC_CMOV(X86_R11, X86_R9, X86_WIDTH_32, X86_CC_AE);
x86_l_3655:
	/* 0x3655: cmp    ebx,r11d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RBX, X86_R11, X86_WIDTH_32);
x86_l_3658:
	/* 0x3658: jne    360a <native_bpf_strncasestr+0xf> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3658, 0x360a, x86_l_360a);
x86_l_365a:
	/* 0x365a: lea    r9,[r8+0x1] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_365e:
	/* 0x365e: cmp    r8,0x63 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_64, 99ULL);
x86_l_3662:
	/* 0x3662: mov    r8,r9 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R9, X86_WIDTH_64);
x86_l_3665:
	/* 0x3665: jb     3618 <native_bpf_strncasestr+0x1d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x3665, 0x3618, x86_l_3618);
x86_l_3667:
	/* 0x3667: jmp    360a <native_bpf_strncasestr+0xf> */
	X86_SIM_X86_SUB_JMP(0x3667, 0x360a, x86_l_360a);
x86_l_3669:
	/* 0x3669: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
x86_l_366b:
	/* 0x366b: pop    rbx */
	X86_SIM_L_EXEC_POP(X86_RBX, X86_WIDTH_64);
x86_l_366c:
	/* 0x366c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x35ULL: goto x86_l_35;
	case 0x5dULL: goto x86_l_5d;
	case 0x16cULL: goto x86_l_16c;
	case 0x187ULL: goto x86_l_187;
	case 0x218ULL: goto x86_l_218;
	case 0x223ULL: goto x86_l_223;
	case 0x240ULL: goto x86_l_240;
	case 0x25cULL: goto x86_l_25c;
	case 0x642ULL: goto x86_l_642;
	case 0x7ebULL: goto x86_l_7eb;
	case 0x819ULL: goto x86_l_819;
	case 0x982ULL: goto x86_l_982;
	case 0x9b0ULL: goto x86_l_9b0;
	case 0xab9ULL: goto x86_l_ab9;
	case 0xae5ULL: goto x86_l_ae5;
	case 0xb21ULL: goto x86_l_b21;
	case 0xc6cULL: goto x86_l_c6c;
	case 0xc8dULL: goto x86_l_c8d;
	case 0xcd4ULL: goto x86_l_cd4;
	case 0xde6ULL: goto x86_l_de6;
	case 0xf0eULL: goto x86_l_f0e;
	case 0xf3aULL: goto x86_l_f3a;
	case 0xf72ULL: goto x86_l_f72;
	case 0x11fcULL: goto x86_l_11fc;
	case 0x1228ULL: goto x86_l_1228;
	case 0x147dULL: goto x86_l_147d;
	case 0x14e6ULL: goto x86_l_14e6;
	case 0x1590ULL: goto x86_l_1590;
	case 0x1618ULL: goto x86_l_1618;
	case 0x165aULL: goto x86_l_165a;
	case 0x175eULL: goto x86_l_175e;
	case 0x1796ULL: goto x86_l_1796;
	case 0x1858ULL: goto x86_l_1858;
	case 0x1871ULL: goto x86_l_1871;
	case 0x18e2ULL: goto x86_l_18e2;
	case 0x190fULL: goto x86_l_190f;
	case 0x1937ULL: goto x86_l_1937;
	case 0x1944ULL: goto x86_l_1944;
	case 0x1973ULL: goto x86_l_1973;
	case 0x19b7ULL: goto x86_l_19b7;
	case 0x19e3ULL: goto x86_l_19e3;
	case 0x1a1bULL: goto x86_l_1a1b;
	case 0x1a28ULL: goto x86_l_1a28;
	case 0x1b6eULL: goto x86_l_1b6e;
	case 0x1b8eULL: goto x86_l_1b8e;
	case 0x1fc1ULL: goto x86_l_1fc1;
	case 0x20d8ULL: goto x86_l_20d8;
	case 0x22ddULL: goto x86_l_22dd;
	case 0x22f1ULL: goto x86_l_22f1;
	case 0x234dULL: goto x86_l_234d;
	case 0x2391ULL: goto x86_l_2391;
	case 0x23c1ULL: goto x86_l_23c1;
	case 0x2513ULL: goto x86_l_2513;
	case 0x2527ULL: goto x86_l_2527;
	case 0x2588ULL: goto x86_l_2588;
	case 0x25caULL: goto x86_l_25ca;
	case 0x25f4ULL: goto x86_l_25f4;
	case 0x290eULL: goto x86_l_290e;
	case 0x2922ULL: goto x86_l_2922;
	case 0x2972ULL: goto x86_l_2972;
	case 0x29bbULL: goto x86_l_29bb;
	case 0x29e4ULL: goto x86_l_29e4;
	case 0x2f53ULL: goto x86_l_2f53;
	case 0x2fbaULL: goto x86_l_2fba;
	case 0x2fceULL: goto x86_l_2fce;
	case 0x301eULL: goto x86_l_301e;
	case 0x305dULL: goto x86_l_305d;
	case 0x3083ULL: goto x86_l_3083;
	case 0x31beULL: goto x86_l_31be;
	case 0x31d5ULL: goto x86_l_31d5;
	case 0x32a0ULL: goto x86_l_32a0;
	case 0x3564ULL: goto x86_l_3564;
	}

}

X86_SIM_LICENSE();
