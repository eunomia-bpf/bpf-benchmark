extern char config_map;
extern char heap_ro_zero;
extern char sleepable_preload;
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_ENABLE_STACK_DEEP 1
#include "../x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

SEC("xdp")
int tetragon_bpf_generic_usdt_v53_generic_sleepable_preload_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xa8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 168ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xa4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&config_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xa4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2e:
	/* 0x2e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_33:
	/* 0x33: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_35:
	/* 0x35: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_38:
	/* 0x38: je     125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38, 0x125, x86_l_125);
x86_l_3e:
	/* 0x3e: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_41:
	/* 0x41: lea    rax,[r14+0x98] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_48:
	/* 0x48: mov    QWORD PTR [rsp+0x60],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4d:
	/* 0x4d: lea    rax,[r14+0x80] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_54:
	/* 0x54: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_59:
	/* 0x59: lea    rax,[r14+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5d:
	/* 0x5d: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_65:
	/* 0x65: lea    rax,[r14+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_69:
	/* 0x69: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_6e:
	/* 0x6e: lea    rax,[r14+0x60] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_7a:
	/* 0x7a: lea    rax,[r14+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_7e:
	/* 0x7e: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_83:
	/* 0x83: lea    rax,[r14+0x50] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_87:
	/* 0x87: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_8f:
	/* 0x8f: lea    rax,[r14+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_98:
	/* 0x98: lea    rax,[r14+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9c:
	/* 0x9c: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_a4:
	/* 0xa4: lea    rax,[r14+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_a8:
	/* 0xa8: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ad:
	/* 0xad: lea    rax,[r14+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b1:
	/* 0xb1: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_b6:
	/* 0xb6: lea    rax,[r14+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_ba:
	/* 0xba: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_bf:
	/* 0xbf: lea    rax,[r14+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c3:
	/* 0xc3: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c8:
	/* 0xc8: lea    rax,[r14+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_cc:
	/* 0xcc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d1:
	/* 0xd1: lea    rax,[r14+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d5:
	/* 0xd5: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_da:
	/* 0xda: lea    rax,[r14+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_e3:
	/* 0xe3: mov    eax,DWORD PTR [rbx+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e6:
	/* 0xe6: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_eb:
	/* 0xeb: jne    13d <generic_sleepable_preload+0x13d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xeb, 0x13d, x86_l_13d);
x86_l_ed:
	/* 0xed: mov    eax,DWORD PTR [rbx+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_f0:
	/* 0xf0: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_f5:
	/* 0xf5: jne    19d <generic_sleepable_preload+0x19d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf5, 0x19d, x86_l_19d);
x86_l_fb:
	/* 0xfb: mov    eax,DWORD PTR [rbx+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_fe:
	/* 0xfe: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_103:
	/* 0x103: jne    1fd <generic_sleepable_preload+0x1fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x103, 0x1fd, x86_l_1fd);
x86_l_109:
	/* 0x109: mov    eax,DWORD PTR [rbx+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_10c:
	/* 0x10c: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_111:
	/* 0x111: jne    25d <generic_sleepable_preload+0x25d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x111, 0x25d, x86_l_25d);
x86_l_117:
	/* 0x117: mov    eax,DWORD PTR [rbx+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11a:
	/* 0x11a: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_11f:
	/* 0x11f: jne    2bd <generic_sleepable_preload+0x2bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11f, 0x2bd, x86_l_2bd);
x86_l_125:
	/* 0x125: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_127:
	/* 0x127: add    rsp,0xa8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_12e:
	/* 0x12e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_12f:
	/* 0x12f: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_131:
	/* 0x131: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_133:
	/* 0x133: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_135:
	/* 0x135: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_137:
	/* 0x137: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_138:
	/* 0x138: jmp    39dd <generic_sleepable_preload+0x39dd> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_13d:
	/* 0x13d: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_13f:
	/* 0x13f: js     31f <generic_sleepable_preload+0x31f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13f, 0x31f, x86_l_31f);
x86_l_145:
	/* 0x145: movzx  eax,BYTE PTR [rbx+0x211] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 529ULL);
x86_l_14c:
	/* 0x14c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14e:
	/* 0x14e: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_151:
	/* 0x151: jg     50e <generic_sleepable_preload+0x50e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x151, 0x50e, x86_l_50e);
x86_l_157:
	/* 0x157: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_15a:
	/* 0x15a: je     a54 <generic_sleepable_preload+0xa54> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15a, 0xa54, x86_l_a54);
x86_l_160:
	/* 0x160: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_163:
	/* 0x163: jne    bbf <generic_sleepable_preload+0xbbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x163, 0xbbf, x86_l_bbf);
x86_l_169:
	/* 0x169: mov    edx,DWORD PTR [rbx+0x208] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 520ULL);
x86_l_16f:
	/* 0x16f: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_175:
	/* 0x175: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_178:
	/* 0x178: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17d:
	/* 0x17d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_182:
	/* 0x182: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_187:
	/* 0x187: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_18c:
	/* 0x18c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18e:
	/* 0x18e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_190:
	/* 0x190: je     a60 <generic_sleepable_preload+0xa60> */
	X86_SIM_X86_JCC(X86_CC_E, 0x190, 0xa60, x86_l_a60);
x86_l_196:
	/* 0x196: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_198:
	/* 0x198: jmp    bbf <generic_sleepable_preload+0xbbf> */
	X86_SIM_X86_JMP(0x198, 0xbbf, x86_l_bbf);
x86_l_19d:
	/* 0x19d: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_19f:
	/* 0x19f: js     382 <generic_sleepable_preload+0x382> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19f, 0x382, x86_l_382);
x86_l_1a5:
	/* 0x1a5: movzx  eax,BYTE PTR [rbx+0x229] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 553ULL);
x86_l_1ac:
	/* 0x1ac: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1ae:
	/* 0x1ae: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1b1:
	/* 0x1b1: jg     5d3 <generic_sleepable_preload+0x5d3> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1b1, 0x5d3, x86_l_5d3);
x86_l_1b7:
	/* 0x1b7: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ba:
	/* 0x1ba: je     a88 <generic_sleepable_preload+0xa88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ba, 0xa88, x86_l_a88);
x86_l_1c0:
	/* 0x1c0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1c3:
	/* 0x1c3: jne    f60 <generic_sleepable_preload+0xf60> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c3, 0xf60, x86_l_f60);
x86_l_1c9:
	/* 0x1c9: mov    edx,DWORD PTR [rbx+0x220] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 544ULL);
x86_l_1cf:
	/* 0x1cf: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d5:
	/* 0x1d5: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1d8:
	/* 0x1d8: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dd:
	/* 0x1dd: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1e2:
	/* 0x1e2: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_1e7:
	/* 0x1e7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1ec:
	/* 0x1ec: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ee:
	/* 0x1ee: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1f0:
	/* 0x1f0: je     a94 <generic_sleepable_preload+0xa94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f0, 0xa94, x86_l_a94);
x86_l_1f6:
	/* 0x1f6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f8:
	/* 0x1f8: jmp    f60 <generic_sleepable_preload+0xf60> */
	X86_SIM_X86_JMP(0x1f8, 0xf60, x86_l_f60);
x86_l_1fd:
	/* 0x1fd: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_1ff:
	/* 0x1ff: js     3e5 <generic_sleepable_preload+0x3e5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ff, 0x3e5, x86_l_3e5);
x86_l_205:
	/* 0x205: movzx  eax,BYTE PTR [rbx+0x241] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 577ULL);
x86_l_20c:
	/* 0x20c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_20e:
	/* 0x20e: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_211:
	/* 0x211: jg     64d <generic_sleepable_preload+0x64d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x211, 0x64d, x86_l_64d);
x86_l_217:
	/* 0x217: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_21a:
	/* 0x21a: je     ac1 <generic_sleepable_preload+0xac1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a, 0xac1, x86_l_ac1);
x86_l_220:
	/* 0x220: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_223:
	/* 0x223: jne    1313 <generic_sleepable_preload+0x1313> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x223, 0x1313, x86_l_1313);
x86_l_229:
	/* 0x229: mov    edx,DWORD PTR [rbx+0x238] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 568ULL);
x86_l_22f:
	/* 0x22f: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_235:
	/* 0x235: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_238:
	/* 0x238: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23d:
	/* 0x23d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_242:
	/* 0x242: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_247:
	/* 0x247: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_24c:
	/* 0x24c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_24e:
	/* 0x24e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_250:
	/* 0x250: je     acd <generic_sleepable_preload+0xacd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x250, 0xacd, x86_l_acd);
x86_l_256:
	/* 0x256: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_258:
	/* 0x258: jmp    1313 <generic_sleepable_preload+0x1313> */
	X86_SIM_X86_JMP(0x258, 0x1313, x86_l_1313);
x86_l_25d:
	/* 0x25d: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_25f:
	/* 0x25f: js     448 <generic_sleepable_preload+0x448> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25f, 0x448, x86_l_448);
x86_l_265:
	/* 0x265: movzx  eax,BYTE PTR [rbx+0x259] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 601ULL);
x86_l_26c:
	/* 0x26c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_26e:
	/* 0x26e: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_271:
	/* 0x271: jg     6c7 <generic_sleepable_preload+0x6c7> */
	X86_SIM_X86_JCC(X86_CC_G, 0x271, 0x6c7, x86_l_6c7);
x86_l_277:
	/* 0x277: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_27a:
	/* 0x27a: je     af5 <generic_sleepable_preload+0xaf5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a, 0xaf5, x86_l_af5);
x86_l_280:
	/* 0x280: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_283:
	/* 0x283: jne    16c6 <generic_sleepable_preload+0x16c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x283, 0x16c6, x86_l_16c6);
x86_l_289:
	/* 0x289: mov    edx,DWORD PTR [rbx+0x250] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 592ULL);
x86_l_28f:
	/* 0x28f: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_295:
	/* 0x295: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_298:
	/* 0x298: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29d:
	/* 0x29d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2a2:
	/* 0x2a2: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_2a7:
	/* 0x2a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2ac:
	/* 0x2ac: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ae:
	/* 0x2ae: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b0:
	/* 0x2b0: je     b01 <generic_sleepable_preload+0xb01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b0, 0xb01, x86_l_b01);
x86_l_2b6:
	/* 0x2b6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2b8:
	/* 0x2b8: jmp    16c6 <generic_sleepable_preload+0x16c6> */
	X86_SIM_X86_JMP(0x2b8, 0x16c6, x86_l_16c6);
x86_l_2bd:
	/* 0x2bd: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_2bf:
	/* 0x2bf: js     4ab <generic_sleepable_preload+0x4ab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bf, 0x4ab, x86_l_4ab);
x86_l_2c5:
	/* 0x2c5: movzx  eax,BYTE PTR [rbx+0x271] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 625ULL);
x86_l_2cc:
	/* 0x2cc: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2ce:
	/* 0x2ce: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2d1:
	/* 0x2d1: jg     741 <generic_sleepable_preload+0x741> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d1, 0x741, x86_l_741);
x86_l_2d7:
	/* 0x2d7: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2da:
	/* 0x2da: je     b29 <generic_sleepable_preload+0xb29> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2da, 0xb29, x86_l_b29);
x86_l_2e0:
	/* 0x2e0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2e3:
	/* 0x2e3: jne    1a7b <generic_sleepable_preload+0x1a7b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e3, 0x1a7b, x86_l_1a7b);
x86_l_2e9:
	/* 0x2e9: mov    eax,DWORD PTR [rbx+0x268] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 616ULL);
x86_l_2ef:
	/* 0x2ef: and    eax,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2f4:
	/* 0x2f4: add    r14,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2f7:
	/* 0x2f7: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2fc:
	/* 0x2fc: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_301:
	/* 0x301: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_306:
	/* 0x306: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_30b:
	/* 0x30b: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_30e:
	/* 0x30e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_310:
	/* 0x310: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_312:
	/* 0x312: je     b35 <generic_sleepable_preload+0xb35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x312, 0xb35, x86_l_b35);
x86_l_318:
	/* 0x318: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31a:
	/* 0x31a: jmp    1a7b <generic_sleepable_preload+0x1a7b> */
	X86_SIM_X86_JMP(0x31a, 0x1a7b, x86_l_1a7b);
x86_l_31f:
	/* 0x31f: movzx  eax,BYTE PTR [rbx+0x2c2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 706ULL);
x86_l_326:
	/* 0x326: movzx  ecx,WORD PTR [rbx+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 704ULL);
x86_l_32d:
	/* 0x32d: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_333:
	/* 0x333: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_335:
	/* 0x335: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_338:
	/* 0x338: jle    7bd <generic_sleepable_preload+0x7bd> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x338, 0x7bd, x86_l_7bd);
x86_l_33e:
	/* 0x33e: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_341:
	/* 0x341: jle    8a1 <generic_sleepable_preload+0x8a1> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x341, 0x8a1, x86_l_8a1);
x86_l_347:
	/* 0x347: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_34a:
	/* 0x34a: jle    1fb3 <generic_sleepable_preload+0x1fb3> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x34a, 0x1fb3, x86_l_1fb3);
x86_l_350:
	/* 0x350: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_358:
	/* 0x358: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_35b:
	/* 0x35b: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35b, 0x1fca, x86_l_1fca);
x86_l_361:
	/* 0x361: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_366:
	/* 0x366: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_369:
	/* 0x369: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x369, 0x1fca, x86_l_1fca);
x86_l_36f:
	/* 0x36f: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_372:
	/* 0x372: jne    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x372, 0x1fdd, x86_l_1fdd);
x86_l_378:
	/* 0x378: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_37d:
	/* 0x37d: jmp    1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JMP(0x37d, 0x1fca, x86_l_1fca);
x86_l_382:
	/* 0x382: movzx  eax,BYTE PTR [rbx+0x2c6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 710ULL);
x86_l_389:
	/* 0x389: movzx  ecx,WORD PTR [rbx+0x2c4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 708ULL);
x86_l_390:
	/* 0x390: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_396:
	/* 0x396: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_398:
	/* 0x398: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_39b:
	/* 0x39b: jle    7ed <generic_sleepable_preload+0x7ed> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x39b, 0x7ed, x86_l_7ed);
x86_l_3a1:
	/* 0x3a1: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_3a4:
	/* 0x3a4: jle    8ce <generic_sleepable_preload+0x8ce> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3a4, 0x8ce, x86_l_8ce);
x86_l_3aa:
	/* 0x3aa: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_3ad:
	/* 0x3ad: jle    22ae <generic_sleepable_preload+0x22ae> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3ad, 0x22ae, x86_l_22ae);
x86_l_3b3:
	/* 0x3b3: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3bb:
	/* 0x3bb: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_3be:
	/* 0x3be: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3be, 0x2672, x86_l_2672);
x86_l_3c4:
	/* 0x3c4: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3c9:
	/* 0x3c9: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_3cc:
	/* 0x3cc: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3cc, 0x2672, x86_l_2672);
x86_l_3d2:
	/* 0x3d2: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3d7:
	/* 0x3d7: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_3da:
	/* 0x3da: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3da, 0x2672, x86_l_2672);
x86_l_3e0:
	/* 0x3e0: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x3e0, 0x2685, x86_l_2685);
x86_l_3e5:
	/* 0x3e5: movzx  eax,BYTE PTR [rbx+0x2ca] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 714ULL);
x86_l_3ec:
	/* 0x3ec: movzx  ecx,WORD PTR [rbx+0x2c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 712ULL);
x86_l_3f3:
	/* 0x3f3: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_3f9:
	/* 0x3f9: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3fb:
	/* 0x3fb: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_3fe:
	/* 0x3fe: jle    81a <generic_sleepable_preload+0x81a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3fe, 0x81a, x86_l_81a);
x86_l_404:
	/* 0x404: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_407:
	/* 0x407: jle    8fb <generic_sleepable_preload+0x8fb> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x407, 0x8fb, x86_l_8fb);
x86_l_40d:
	/* 0x40d: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_410:
	/* 0x410: jle    22d2 <generic_sleepable_preload+0x22d2> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x410, 0x22d2, x86_l_22d2);
x86_l_416:
	/* 0x416: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_41e:
	/* 0x41e: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_421:
	/* 0x421: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x421, 0x2976, x86_l_2976);
x86_l_427:
	/* 0x427: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_42c:
	/* 0x42c: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_42f:
	/* 0x42f: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42f, 0x2976, x86_l_2976);
x86_l_435:
	/* 0x435: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_43a:
	/* 0x43a: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_43d:
	/* 0x43d: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43d, 0x2976, x86_l_2976);
x86_l_443:
	/* 0x443: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x443, 0x2989, x86_l_2989);
x86_l_448:
	/* 0x448: movzx  eax,BYTE PTR [rbx+0x2ce] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 718ULL);
x86_l_44f:
	/* 0x44f: movzx  ecx,WORD PTR [rbx+0x2cc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 716ULL);
x86_l_456:
	/* 0x456: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_45c:
	/* 0x45c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_45e:
	/* 0x45e: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_461:
	/* 0x461: jle    847 <generic_sleepable_preload+0x847> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x461, 0x847, x86_l_847);
x86_l_467:
	/* 0x467: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_46a:
	/* 0x46a: jle    928 <generic_sleepable_preload+0x928> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x46a, 0x928, x86_l_928);
x86_l_470:
	/* 0x470: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_473:
	/* 0x473: jle    22f6 <generic_sleepable_preload+0x22f6> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x473, 0x22f6, x86_l_22f6);
x86_l_479:
	/* 0x479: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_481:
	/* 0x481: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_484:
	/* 0x484: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x484, 0x2c7a, x86_l_2c7a);
x86_l_48a:
	/* 0x48a: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_48f:
	/* 0x48f: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_492:
	/* 0x492: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x492, 0x2c7a, x86_l_2c7a);
x86_l_498:
	/* 0x498: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_49d:
	/* 0x49d: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_4a0:
	/* 0x4a0: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a0, 0x2c7a, x86_l_2c7a);
x86_l_4a6:
	/* 0x4a6: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x4a6, 0x2c8d, x86_l_2c8d);
x86_l_4ab:
	/* 0x4ab: movzx  eax,BYTE PTR [rbx+0x2d2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 722ULL);
x86_l_4b2:
	/* 0x4b2: movzx  ecx,WORD PTR [rbx+0x2d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 720ULL);
x86_l_4b9:
	/* 0x4b9: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_4bf:
	/* 0x4bf: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4c1:
	/* 0x4c1: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_4c4:
	/* 0x4c4: jle    874 <generic_sleepable_preload+0x874> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4c4, 0x874, x86_l_874);
x86_l_4ca:
	/* 0x4ca: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_4cd:
	/* 0x4cd: jle    955 <generic_sleepable_preload+0x955> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4cd, 0x955, x86_l_955);
x86_l_4d3:
	/* 0x4d3: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_4d6:
	/* 0x4d6: jle    231a <generic_sleepable_preload+0x231a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4d6, 0x231a, x86_l_231a);
x86_l_4dc:
	/* 0x4dc: mov    r14,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4e4:
	/* 0x4e4: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_4e7:
	/* 0x4e7: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e7, 0x2331, x86_l_2331);
x86_l_4ed:
	/* 0x4ed: mov    r14,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4f2:
	/* 0x4f2: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_4f5:
	/* 0x4f5: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f5, 0x2331, x86_l_2331);
x86_l_4fb:
	/* 0x4fb: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_500:
	/* 0x500: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_503:
	/* 0x503: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x503, 0x2331, x86_l_2331);
x86_l_509:
	/* 0x509: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0x509, 0x2344, x86_l_2344);
x86_l_50e:
	/* 0x50e: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_511:
	/* 0x511: je     b5d <generic_sleepable_preload+0xb5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x511, 0xb5d, x86_l_b5d);
x86_l_517:
	/* 0x517: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_51a:
	/* 0x51a: jne    bbf <generic_sleepable_preload+0xbbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51a, 0xbbf, x86_l_bbf);
x86_l_520:
	/* 0x520: mov    edx,DWORD PTR [rbx+0x208] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 520ULL);
x86_l_526:
	/* 0x526: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_52c:
	/* 0x52c: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_52f:
	/* 0x52f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_534:
	/* 0x534: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_539:
	/* 0x539: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_53e:
	/* 0x53e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_543:
	/* 0x543: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_545:
	/* 0x545: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_547:
	/* 0x547: jne    bbc <generic_sleepable_preload+0xbbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x547, 0xbbc, x86_l_bbc);
x86_l_54d:
	/* 0x54d: mov    edx,DWORD PTR [rbx+0x20c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 524ULL);
x86_l_553:
	/* 0x553: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_559:
	/* 0x559: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_55c:
	/* 0x55c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_55f:
	/* 0x55f: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_564:
	/* 0x564: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_569:
	/* 0x569: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_56e:
	/* 0x56e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_570:
	/* 0x570: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_572:
	/* 0x572: jne    bbc <generic_sleepable_preload+0xbbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x572, 0xbbc, x86_l_bbc);
x86_l_578:
	/* 0x578: movzx  eax,BYTE PTR [rbx+0x213] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 531ULL);
x86_l_57f:
	/* 0x57f: shlx   rax,QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_585:
	/* 0x585: mov    rcx,QWORD PTR [rbx+0x200] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 512ULL);
x86_l_58c:
	/* 0x58c: add    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_591:
	/* 0x591: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_594:
	/* 0x594: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_599:
	/* 0x599: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_59e:
	/* 0x59e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5a3:
	/* 0x5a3: movzx  ecx,BYTE PTR [rbx+0x213] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 531ULL);
x86_l_5aa:
	/* 0x5aa: shlx   rcx,QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_5b0:
	/* 0x5b0: mov    rdx,QWORD PTR [rbx+0x200] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 512ULL);
x86_l_5b7:
	/* 0x5b7: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_5bc:
	/* 0x5bc: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5bf:
	/* 0x5bf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5c4:
	/* 0x5c4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5c6:
	/* 0x5c6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5c8:
	/* 0x5c8: jne    bbc <generic_sleepable_preload+0xbbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c8, 0xbbc, x86_l_bbc);
x86_l_5ce:
	/* 0x5ce: jmp    a60 <generic_sleepable_preload+0xa60> */
	X86_SIM_X86_JMP(0x5ce, 0xa60, x86_l_a60);
x86_l_5d3:
	/* 0x5d3: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_5d6:
	/* 0x5d6: je     eb3 <generic_sleepable_preload+0xeb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d6, 0xeb3, x86_l_eb3);
x86_l_5dc:
	/* 0x5dc: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_5df:
	/* 0x5df: jne    f60 <generic_sleepable_preload+0xf60> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5df, 0xf60, x86_l_f60);
x86_l_5e5:
	/* 0x5e5: mov    edx,DWORD PTR [rbx+0x220] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 544ULL);
x86_l_5eb:
	/* 0x5eb: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_5f1:
	/* 0x5f1: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5f4:
	/* 0x5f4: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f9:
	/* 0x5f9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_5fe:
	/* 0x5fe: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_603:
	/* 0x603: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_608:
	/* 0x608: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_60a:
	/* 0x60a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_60c:
	/* 0x60c: jne    f5d <generic_sleepable_preload+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x60c, 0xf5d, x86_l_f5d);
x86_l_612:
	/* 0x612: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_617:
	/* 0x617: add    rcx,QWORD PTR [rbx+0x218] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 536ULL);
x86_l_61e:
	/* 0x61e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_623:
	/* 0x623: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_628:
	/* 0x628: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_62d:
	/* 0x62d: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_632:
	/* 0x632: add    rdx,QWORD PTR [rbx+0x218] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 536ULL);
x86_l_639:
	/* 0x639: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_63e:
	/* 0x63e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_640:
	/* 0x640: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_642:
	/* 0x642: jne    f5d <generic_sleepable_preload+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x642, 0xf5d, x86_l_f5d);
x86_l_648:
	/* 0x648: jmp    a94 <generic_sleepable_preload+0xa94> */
	X86_SIM_X86_JMP(0x648, 0xa94, x86_l_a94);
x86_l_64d:
	/* 0x64d: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_650:
	/* 0x650: je     1266 <generic_sleepable_preload+0x1266> */
	X86_SIM_X86_JCC(X86_CC_E, 0x650, 0x1266, x86_l_1266);
x86_l_656:
	/* 0x656: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_659:
	/* 0x659: jne    1313 <generic_sleepable_preload+0x1313> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x659, 0x1313, x86_l_1313);
x86_l_65f:
	/* 0x65f: mov    edx,DWORD PTR [rbx+0x238] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 568ULL);
x86_l_665:
	/* 0x665: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_66b:
	/* 0x66b: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_66e:
	/* 0x66e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_673:
	/* 0x673: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_678:
	/* 0x678: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_67d:
	/* 0x67d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_682:
	/* 0x682: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_684:
	/* 0x684: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_686:
	/* 0x686: jne    1310 <generic_sleepable_preload+0x1310> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x686, 0x1310, x86_l_1310);
x86_l_68c:
	/* 0x68c: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_691:
	/* 0x691: add    rcx,QWORD PTR [rbx+0x230] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 560ULL);
x86_l_698:
	/* 0x698: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_69d:
	/* 0x69d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_6a2:
	/* 0x6a2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_6a7:
	/* 0x6a7: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6ac:
	/* 0x6ac: add    rdx,QWORD PTR [rbx+0x230] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 560ULL);
x86_l_6b3:
	/* 0x6b3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_6b8:
	/* 0x6b8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6ba:
	/* 0x6ba: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_6bc:
	/* 0x6bc: jne    1310 <generic_sleepable_preload+0x1310> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6bc, 0x1310, x86_l_1310);
x86_l_6c2:
	/* 0x6c2: jmp    acd <generic_sleepable_preload+0xacd> */
	X86_SIM_X86_JMP(0x6c2, 0xacd, x86_l_acd);
x86_l_6c7:
	/* 0x6c7: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_6ca:
	/* 0x6ca: je     1619 <generic_sleepable_preload+0x1619> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ca, 0x1619, x86_l_1619);
x86_l_6d0:
	/* 0x6d0: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_6d3:
	/* 0x6d3: jne    16c6 <generic_sleepable_preload+0x16c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d3, 0x16c6, x86_l_16c6);
x86_l_6d9:
	/* 0x6d9: mov    edx,DWORD PTR [rbx+0x250] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 592ULL);
x86_l_6df:
	/* 0x6df: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_6e5:
	/* 0x6e5: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_6e8:
	/* 0x6e8: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6ed:
	/* 0x6ed: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_6f2:
	/* 0x6f2: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_6f7:
	/* 0x6f7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_6fc:
	/* 0x6fc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6fe:
	/* 0x6fe: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_700:
	/* 0x700: jne    16c3 <generic_sleepable_preload+0x16c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x700, 0x16c3, x86_l_16c3);
x86_l_706:
	/* 0x706: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_70b:
	/* 0x70b: add    rcx,QWORD PTR [rbx+0x248] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 584ULL);
x86_l_712:
	/* 0x712: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_717:
	/* 0x717: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_71c:
	/* 0x71c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_721:
	/* 0x721: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_726:
	/* 0x726: add    rdx,QWORD PTR [rbx+0x248] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 584ULL);
x86_l_72d:
	/* 0x72d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_732:
	/* 0x732: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_734:
	/* 0x734: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_736:
	/* 0x736: jne    16c3 <generic_sleepable_preload+0x16c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x736, 0x16c3, x86_l_16c3);
x86_l_73c:
	/* 0x73c: jmp    b01 <generic_sleepable_preload+0xb01> */
	X86_SIM_X86_JMP(0x73c, 0xb01, x86_l_b01);
x86_l_741:
	/* 0x741: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_744:
	/* 0x744: je     19cc <generic_sleepable_preload+0x19cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x744, 0x19cc, x86_l_19cc);
x86_l_74a:
	/* 0x74a: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_74d:
	/* 0x74d: jne    1a7b <generic_sleepable_preload+0x1a7b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x74d, 0x1a7b, x86_l_1a7b);
x86_l_753:
	/* 0x753: mov    eax,DWORD PTR [rbx+0x268] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 616ULL);
x86_l_759:
	/* 0x759: and    eax,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_75e:
	/* 0x75e: add    r14,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_761:
	/* 0x761: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_766:
	/* 0x766: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_76b:
	/* 0x76b: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_770:
	/* 0x770: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_775:
	/* 0x775: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_778:
	/* 0x778: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_77a:
	/* 0x77a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_77c:
	/* 0x77c: jne    1a78 <generic_sleepable_preload+0x1a78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77c, 0x1a78, x86_l_1a78);
x86_l_782:
	/* 0x782: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_787:
	/* 0x787: add    rcx,QWORD PTR [rbx+0x260] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 608ULL);
x86_l_78e:
	/* 0x78e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_793:
	/* 0x793: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_798:
	/* 0x798: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_79d:
	/* 0x79d: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7a2:
	/* 0x7a2: add    rdx,QWORD PTR [rbx+0x260] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 608ULL);
x86_l_7a9:
	/* 0x7a9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_7ae:
	/* 0x7ae: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7b0:
	/* 0x7b0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_7b2:
	/* 0x7b2: jne    1a78 <generic_sleepable_preload+0x1a78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b2, 0x1a78, x86_l_1a78);
x86_l_7b8:
	/* 0x7b8: jmp    b35 <generic_sleepable_preload+0xb35> */
	X86_SIM_X86_JMP(0x7b8, 0xb35, x86_l_b35);
x86_l_7bd:
	/* 0x7bd: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_7c0:
	/* 0x7c0: jg     982 <generic_sleepable_preload+0x982> */
	X86_SIM_X86_JCC(X86_CC_G, 0x7c0, 0x982, x86_l_982);
x86_l_7c6:
	/* 0x7c6: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_7c9:
	/* 0x7c9: jg     1e69 <generic_sleepable_preload+0x1e69> */
	X86_SIM_X86_JCC(X86_CC_G, 0x7c9, 0x1e69, x86_l_1e69);
x86_l_7cf:
	/* 0x7cf: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_7d2:
	/* 0x7d2: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_7d4:
	/* 0x7d4: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d4, 0x1fca, x86_l_1fca);
x86_l_7da:
	/* 0x7da: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7df:
	/* 0x7df: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_7e2:
	/* 0x7e2: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7e2, 0x1fca, x86_l_1fca);
x86_l_7e8:
	/* 0x7e8: jmp    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JMP(0x7e8, 0x1fdd, x86_l_1fdd);
x86_l_7ed:
	/* 0x7ed: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_7f0:
	/* 0x7f0: jg     9ac <generic_sleepable_preload+0x9ac> */
	X86_SIM_X86_JCC(X86_CC_G, 0x7f0, 0x9ac, x86_l_9ac);
x86_l_7f6:
	/* 0x7f6: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_7f9:
	/* 0x7f9: jg     1e8a <generic_sleepable_preload+0x1e8a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x7f9, 0x1e8a, x86_l_1e8a);
x86_l_7ff:
	/* 0x7ff: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_801:
	/* 0x801: je     266f <generic_sleepable_preload+0x266f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x801, 0x266f, x86_l_266f);
x86_l_807:
	/* 0x807: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_80c:
	/* 0x80c: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_80f:
	/* 0x80f: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x80f, 0x2672, x86_l_2672);
x86_l_815:
	/* 0x815: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x815, 0x2685, x86_l_2685);
x86_l_81a:
	/* 0x81a: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_81d:
	/* 0x81d: jg     9d6 <generic_sleepable_preload+0x9d6> */
	X86_SIM_X86_JCC(X86_CC_G, 0x81d, 0x9d6, x86_l_9d6);
x86_l_823:
	/* 0x823: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_826:
	/* 0x826: jg     1eab <generic_sleepable_preload+0x1eab> */
	X86_SIM_X86_JCC(X86_CC_G, 0x826, 0x1eab, x86_l_1eab);
x86_l_82c:
	/* 0x82c: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_82e:
	/* 0x82e: je     2973 <generic_sleepable_preload+0x2973> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82e, 0x2973, x86_l_2973);
x86_l_834:
	/* 0x834: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_839:
	/* 0x839: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_83c:
	/* 0x83c: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x83c, 0x2976, x86_l_2976);
x86_l_842:
	/* 0x842: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x842, 0x2989, x86_l_2989);
x86_l_847:
	/* 0x847: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_84a:
	/* 0x84a: jg     a00 <generic_sleepable_preload+0xa00> */
	X86_SIM_X86_JCC(X86_CC_G, 0x84a, 0xa00, x86_l_a00);
x86_l_850:
	/* 0x850: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_853:
	/* 0x853: jg     1ecc <generic_sleepable_preload+0x1ecc> */
	X86_SIM_X86_JCC(X86_CC_G, 0x853, 0x1ecc, x86_l_1ecc);
x86_l_859:
	/* 0x859: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_85b:
	/* 0x85b: je     2c77 <generic_sleepable_preload+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85b, 0x2c77, x86_l_2c77);
x86_l_861:
	/* 0x861: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_866:
	/* 0x866: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_869:
	/* 0x869: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x869, 0x2c7a, x86_l_2c7a);
x86_l_86f:
	/* 0x86f: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x86f, 0x2c8d, x86_l_2c8d);
x86_l_874:
	/* 0x874: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_877:
	/* 0x877: jg     a2a <generic_sleepable_preload+0xa2a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x877, 0xa2a, x86_l_a2a);
x86_l_87d:
	/* 0x87d: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_880:
	/* 0x880: jg     1eed <generic_sleepable_preload+0x1eed> */
	X86_SIM_X86_JCC(X86_CC_G, 0x880, 0x1eed, x86_l_1eed);
x86_l_886:
	/* 0x886: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_888:
	/* 0x888: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x888, 0x2331, x86_l_2331);
x86_l_88e:
	/* 0x88e: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_891:
	/* 0x891: mov    r14,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_896:
	/* 0x896: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x896, 0x2331, x86_l_2331);
x86_l_89c:
	/* 0x89c: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0x89c, 0x2344, x86_l_2344);
x86_l_8a1:
	/* 0x8a1: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_8a4:
	/* 0x8a4: jg     1db5 <generic_sleepable_preload+0x1db5> */
	X86_SIM_X86_JCC(X86_CC_G, 0x8a4, 0x1db5, x86_l_1db5);
x86_l_8aa:
	/* 0x8aa: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8b2:
	/* 0x8b2: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_8b5:
	/* 0x8b5: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8b5, 0x1fca, x86_l_1fca);
x86_l_8bb:
	/* 0x8bb: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8c0:
	/* 0x8c0: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_8c3:
	/* 0x8c3: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c3, 0x1fca, x86_l_1fca);
x86_l_8c9:
	/* 0x8c9: jmp    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JMP(0x8c9, 0x1fdd, x86_l_1fdd);
x86_l_8ce:
	/* 0x8ce: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_8d1:
	/* 0x8d1: jg     1dd9 <generic_sleepable_preload+0x1dd9> */
	X86_SIM_X86_JCC(X86_CC_G, 0x8d1, 0x1dd9, x86_l_1dd9);
x86_l_8d7:
	/* 0x8d7: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8df:
	/* 0x8df: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_8e2:
	/* 0x8e2: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e2, 0x2672, x86_l_2672);
x86_l_8e8:
	/* 0x8e8: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8ed:
	/* 0x8ed: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_8f0:
	/* 0x8f0: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8f0, 0x2672, x86_l_2672);
x86_l_8f6:
	/* 0x8f6: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x8f6, 0x2685, x86_l_2685);
x86_l_8fb:
	/* 0x8fb: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_8fe:
	/* 0x8fe: jg     1dfd <generic_sleepable_preload+0x1dfd> */
	X86_SIM_X86_JCC(X86_CC_G, 0x8fe, 0x1dfd, x86_l_1dfd);
x86_l_904:
	/* 0x904: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_90c:
	/* 0x90c: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_90f:
	/* 0x90f: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90f, 0x2976, x86_l_2976);
x86_l_915:
	/* 0x915: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_91a:
	/* 0x91a: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_91d:
	/* 0x91d: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x91d, 0x2976, x86_l_2976);
x86_l_923:
	/* 0x923: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x923, 0x2989, x86_l_2989);
x86_l_928:
	/* 0x928: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_92b:
	/* 0x92b: jg     1e21 <generic_sleepable_preload+0x1e21> */
	X86_SIM_X86_JCC(X86_CC_G, 0x92b, 0x1e21, x86_l_1e21);
x86_l_931:
	/* 0x931: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_939:
	/* 0x939: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_93c:
	/* 0x93c: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x93c, 0x2c7a, x86_l_2c7a);
x86_l_942:
	/* 0x942: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_947:
	/* 0x947: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_94a:
	/* 0x94a: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94a, 0x2c7a, x86_l_2c7a);
x86_l_950:
	/* 0x950: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x950, 0x2c8d, x86_l_2c8d);
x86_l_955:
	/* 0x955: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_958:
	/* 0x958: jg     1e45 <generic_sleepable_preload+0x1e45> */
	X86_SIM_X86_JCC(X86_CC_G, 0x958, 0x1e45, x86_l_1e45);
x86_l_95e:
	/* 0x95e: mov    r14,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_966:
	/* 0x966: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_969:
	/* 0x969: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x969, 0x2331, x86_l_2331);
x86_l_96f:
	/* 0x96f: mov    r14,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_974:
	/* 0x974: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_977:
	/* 0x977: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x977, 0x2331, x86_l_2331);
x86_l_97d:
	/* 0x97d: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0x97d, 0x2344, x86_l_2344);
x86_l_982:
	/* 0x982: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_985:
	/* 0x985: jg     1f0e <generic_sleepable_preload+0x1f0e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x985, 0x1f0e, x86_l_1f0e);
x86_l_98b:
	/* 0x98b: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_990:
	/* 0x990: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_993:
	/* 0x993: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x993, 0x1fca, x86_l_1fca);
x86_l_999:
	/* 0x999: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_99e:
	/* 0x99e: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_9a1:
	/* 0x9a1: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a1, 0x1fca, x86_l_1fca);
x86_l_9a7:
	/* 0x9a7: jmp    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JMP(0x9a7, 0x1fdd, x86_l_1fdd);
x86_l_9ac:
	/* 0x9ac: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_9af:
	/* 0x9af: jg     1f2f <generic_sleepable_preload+0x1f2f> */
	X86_SIM_X86_JCC(X86_CC_G, 0x9af, 0x1f2f, x86_l_1f2f);
x86_l_9b5:
	/* 0x9b5: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_9ba:
	/* 0x9ba: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_9bd:
	/* 0x9bd: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9bd, 0x2672, x86_l_2672);
x86_l_9c3:
	/* 0x9c3: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9c8:
	/* 0x9c8: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_9cb:
	/* 0x9cb: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9cb, 0x2672, x86_l_2672);
x86_l_9d1:
	/* 0x9d1: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x9d1, 0x2685, x86_l_2685);
x86_l_9d6:
	/* 0x9d6: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_9d9:
	/* 0x9d9: jg     1f50 <generic_sleepable_preload+0x1f50> */
	X86_SIM_X86_JCC(X86_CC_G, 0x9d9, 0x1f50, x86_l_1f50);
x86_l_9df:
	/* 0x9df: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_9e4:
	/* 0x9e4: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_9e7:
	/* 0x9e7: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e7, 0x2976, x86_l_2976);
x86_l_9ed:
	/* 0x9ed: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9f2:
	/* 0x9f2: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_9f5:
	/* 0x9f5: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f5, 0x2976, x86_l_2976);
x86_l_9fb:
	/* 0x9fb: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x9fb, 0x2989, x86_l_2989);
x86_l_a00:
	/* 0xa00: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_a03:
	/* 0xa03: jg     1f71 <generic_sleepable_preload+0x1f71> */
	X86_SIM_X86_JCC(X86_CC_G, 0xa03, 0x1f71, x86_l_1f71);
x86_l_a09:
	/* 0xa09: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_a0e:
	/* 0xa0e: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_a11:
	/* 0xa11: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa11, 0x2c7a, x86_l_2c7a);
x86_l_a17:
	/* 0xa17: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a1c:
	/* 0xa1c: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_a1f:
	/* 0xa1f: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa1f, 0x2c7a, x86_l_2c7a);
x86_l_a25:
	/* 0xa25: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0xa25, 0x2c8d, x86_l_2c8d);
x86_l_a2a:
	/* 0xa2a: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_a2d:
	/* 0xa2d: jg     1f92 <generic_sleepable_preload+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_G, 0xa2d, 0x1f92, x86_l_1f92);
x86_l_a33:
	/* 0xa33: mov    r14,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_a38:
	/* 0xa38: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_a3b:
	/* 0xa3b: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa3b, 0x2331, x86_l_2331);
x86_l_a41:
	/* 0xa41: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a46:
	/* 0xa46: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_a49:
	/* 0xa49: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa49, 0x2331, x86_l_2331);
x86_l_a4f:
	/* 0xa4f: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0xa4f, 0x2344, x86_l_2344);
x86_l_a54:
	/* 0xa54: mov    rax,QWORD PTR [rbx+0x200] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 512ULL);
x86_l_a5b:
	/* 0xa5b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a60:
	/* 0xa60: movzx  eax,BYTE PTR [rbx+0x210] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 528ULL);
x86_l_a67:
	/* 0xa67: shlx   rcx,QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((16ULL << 32) | X86_ALU_SHL));
x86_l_a6e:
	/* 0xa6e: cmp    BYTE PTR [rbx+0x212],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2276332666880ULL);
x86_l_a75:
	/* 0xa75: shrx   rdx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SHR);
x86_l_a7a:
	/* 0xa7a: sarx   rcx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SAR);
x86_l_a7f:
	/* 0xa7f: cmove  rcx,rdx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_64, X86_CC_E);
x86_l_a83:
	/* 0xa83: jmp    bbf <generic_sleepable_preload+0xbbf> */
	X86_SIM_X86_JMP(0xa83, 0xbbf, x86_l_bbf);
x86_l_a88:
	/* 0xa88: mov    rax,QWORD PTR [rbx+0x218] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_a8f:
	/* 0xa8f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a94:
	/* 0xa94: movzx  eax,BYTE PTR [rbx+0x228] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 552ULL);
x86_l_a9b:
	/* 0xa9b: shlx   rcx,QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((16ULL << 32) | X86_ALU_SHL));
x86_l_aa2:
	/* 0xaa2: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_aa7:
	/* 0xaa7: cmp    BYTE PTR [rbx+0x22a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2379411881984ULL);
x86_l_aae:
	/* 0xaae: shrx   rdx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SHR);
x86_l_ab3:
	/* 0xab3: sarx   rcx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SAR);
x86_l_ab8:
	/* 0xab8: cmove  rcx,rdx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_64, X86_CC_E);
x86_l_abc:
	/* 0xabc: jmp    f60 <generic_sleepable_preload+0xf60> */
	X86_SIM_X86_JMP(0xabc, 0xf60, x86_l_f60);
x86_l_ac1:
	/* 0xac1: mov    rax,QWORD PTR [rbx+0x230] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 560ULL);
x86_l_ac8:
	/* 0xac8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_acd:
	/* 0xacd: movzx  eax,BYTE PTR [rbx+0x240] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 576ULL);
x86_l_ad4:
	/* 0xad4: shlx   rcx,QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((16ULL << 32) | X86_ALU_SHL));
x86_l_adb:
	/* 0xadb: cmp    BYTE PTR [rbx+0x242],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2482491097088ULL);
x86_l_ae2:
	/* 0xae2: shrx   rdx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SHR);
x86_l_ae7:
	/* 0xae7: sarx   rcx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SAR);
x86_l_aec:
	/* 0xaec: cmove  rcx,rdx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_64, X86_CC_E);
x86_l_af0:
	/* 0xaf0: jmp    1313 <generic_sleepable_preload+0x1313> */
	X86_SIM_X86_JMP(0xaf0, 0x1313, x86_l_1313);
x86_l_af5:
	/* 0xaf5: mov    rax,QWORD PTR [rbx+0x248] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 584ULL);
x86_l_afc:
	/* 0xafc: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b01:
	/* 0xb01: movzx  eax,BYTE PTR [rbx+0x258] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 600ULL);
x86_l_b08:
	/* 0xb08: shlx   rcx,QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((16ULL << 32) | X86_ALU_SHL));
x86_l_b0f:
	/* 0xb0f: cmp    BYTE PTR [rbx+0x25a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2585570312192ULL);
x86_l_b16:
	/* 0xb16: shrx   rdx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SHR);
x86_l_b1b:
	/* 0xb1b: sarx   rcx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SAR);
x86_l_b20:
	/* 0xb20: cmove  rcx,rdx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_64, X86_CC_E);
x86_l_b24:
	/* 0xb24: jmp    16c6 <generic_sleepable_preload+0x16c6> */
	X86_SIM_X86_JMP(0xb24, 0x16c6, x86_l_16c6);
x86_l_b29:
	/* 0xb29: mov    rax,QWORD PTR [rbx+0x260] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 608ULL);
x86_l_b30:
	/* 0xb30: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b35:
	/* 0xb35: movzx  eax,BYTE PTR [rbx+0x270] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 624ULL);
x86_l_b3c:
	/* 0xb3c: shlx   rcx,QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((16ULL << 32) | X86_ALU_SHL));
x86_l_b43:
	/* 0xb43: cmp    BYTE PTR [rbx+0x272],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2688649527296ULL);
x86_l_b4a:
	/* 0xb4a: shrx   rdx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SHR);
x86_l_b4f:
	/* 0xb4f: sarx   rcx,rcx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RAX, X86_ALU_SAR);
x86_l_b54:
	/* 0xb54: cmove  rcx,rdx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_64, X86_CC_E);
x86_l_b58:
	/* 0xb58: jmp    1a7b <generic_sleepable_preload+0x1a7b> */
	X86_SIM_X86_JMP(0xb58, 0x1a7b, x86_l_1a7b);
x86_l_b5d:
	/* 0xb5d: mov    edx,DWORD PTR [rbx+0x208] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 520ULL);
x86_l_b63:
	/* 0xb63: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_b69:
	/* 0xb69: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_b6c:
	/* 0xb6c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b71:
	/* 0xb71: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_b76:
	/* 0xb76: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_b7b:
	/* 0xb7b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_b80:
	/* 0xb80: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b82:
	/* 0xb82: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_b84:
	/* 0xb84: jne    bbc <generic_sleepable_preload+0xbbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb84, 0xbbc, x86_l_bbc);
x86_l_b86:
	/* 0xb86: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b8b:
	/* 0xb8b: add    rcx,QWORD PTR [rbx+0x200] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 512ULL);
x86_l_b92:
	/* 0xb92: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b97:
	/* 0xb97: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_b9c:
	/* 0xb9c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_ba1:
	/* 0xba1: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ba6:
	/* 0xba6: add    rdx,QWORD PTR [rbx+0x200] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 512ULL);
x86_l_bad:
	/* 0xbad: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_bb2:
	/* 0xbb2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_bb4:
	/* 0xbb4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_bb6:
	/* 0xbb6: je     a60 <generic_sleepable_preload+0xa60> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb6, 0xa60, x86_l_a60);
x86_l_bbc:
	/* 0xbbc: movsxd rcx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_bbf:
	/* 0xbbf: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bc4:
	/* 0xbc4: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_bc7:
	/* 0xbc7: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_bca:
	/* 0xbca: cmp    WORD PTR [rbx+0x76],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 506806140928ULL);
x86_l_bcf:
	/* 0xbcf: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbcf, 0x3130, x86_l_3130);
x86_l_bd5:
	/* 0xbd5: mov    eax,DWORD PTR [rbx+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_bd8:
	/* 0xbd8: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_bdb:
	/* 0xbdb: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be0:
	/* 0xbe0: cmp    WORD PTR [rbx+0x74],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 498216206336ULL);
x86_l_be5:
	/* 0xbe5: je     c0a <generic_sleepable_preload+0xc0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbe5, 0xc0a, x86_l_c0a);
x86_l_be7:
	/* 0xbe7: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bec:
	/* 0xbec: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_bf1:
	/* 0xbf1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_bf6:
	/* 0xbf6: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bfb:
	/* 0xbfb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_c00:
	/* 0xc00: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c02:
	/* 0xc02: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_c04:
	/* 0xc04: js     1d7f <generic_sleepable_preload+0x1d7f> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc04, 0x1d7f, x86_l_1d7f);
x86_l_c0a:
	/* 0xc0a: cmp    WORD PTR [rbx+0x7e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 541165879296ULL);
x86_l_c0f:
	/* 0xc0f: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc0f, 0x3130, x86_l_3130);
x86_l_c15:
	/* 0xc15: mov    ecx,DWORD PTR [rbx+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_c18:
	/* 0xc18: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_c1d:
	/* 0xc1d: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c22:
	/* 0xc22: cmp    WORD PTR [rbx+0x7c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_c27:
	/* 0xc27: je     c4c <generic_sleepable_preload+0xc4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc27, 0xc4c, x86_l_c4c);
x86_l_c29:
	/* 0xc29: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c2e:
	/* 0xc2e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_c33:
	/* 0xc33: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_c38:
	/* 0xc38: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c3d:
	/* 0xc3d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_c42:
	/* 0xc42: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c44:
	/* 0xc44: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_c46:
	/* 0xc46: js     2624 <generic_sleepable_preload+0x2624> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc46, 0x2624, x86_l_2624);
x86_l_c4c:
	/* 0xc4c: cmp    WORD PTR [rbx+0x86],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 575525617664ULL);
x86_l_c54:
	/* 0xc54: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc54, 0x3130, x86_l_3130);
x86_l_c5a:
	/* 0xc5a: mov    ecx,DWORD PTR [rbx+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c60:
	/* 0xc60: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_c65:
	/* 0xc65: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c6a:
	/* 0xc6a: cmp    WORD PTR [rbx+0x84],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_c72:
	/* 0xc72: je     c97 <generic_sleepable_preload+0xc97> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc72, 0xc97, x86_l_c97);
x86_l_c74:
	/* 0xc74: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c79:
	/* 0xc79: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_c7e:
	/* 0xc7e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_c83:
	/* 0xc83: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c88:
	/* 0xc88: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_c8d:
	/* 0xc8d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c8f:
	/* 0xc8f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_c91:
	/* 0xc91: js     2f7b <generic_sleepable_preload+0x2f7b> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc91, 0x2f7b, x86_l_2f7b);
x86_l_c97:
	/* 0xc97: cmp    WORD PTR [rbx+0x8e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 609885356032ULL);
x86_l_c9f:
	/* 0xc9f: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc9f, 0x3130, x86_l_3130);
x86_l_ca5:
	/* 0xca5: mov    ecx,DWORD PTR [rbx+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_cab:
	/* 0xcab: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_cb0:
	/* 0xcb0: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cb5:
	/* 0xcb5: cmp    WORD PTR [rbx+0x8c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_cbd:
	/* 0xcbd: je     ce2 <generic_sleepable_preload+0xce2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcbd, 0xce2, x86_l_ce2);
x86_l_cbf:
	/* 0xcbf: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cc4:
	/* 0xcc4: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_cc9:
	/* 0xcc9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_cce:
	/* 0xcce: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cd3:
	/* 0xcd3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_cd8:
	/* 0xcd8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_cda:
	/* 0xcda: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_cdc:
	/* 0xcdc: js     2fe7 <generic_sleepable_preload+0x2fe7> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcdc, 0x2fe7, x86_l_2fe7);
x86_l_ce2:
	/* 0xce2: cmp    WORD PTR [rbx+0x96],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 644245094400ULL);
x86_l_cea:
	/* 0xcea: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcea, 0x3130, x86_l_3130);
x86_l_cf0:
	/* 0xcf0: mov    ecx,DWORD PTR [rbx+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_cf6:
	/* 0xcf6: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_cfb:
	/* 0xcfb: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d00:
	/* 0xd00: cmp    WORD PTR [rbx+0x94],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_d08:
	/* 0xd08: je     d2d <generic_sleepable_preload+0xd2d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd08, 0xd2d, x86_l_d2d);
x86_l_d0a:
	/* 0xd0a: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d0f:
	/* 0xd0f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_d14:
	/* 0xd14: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_d19:
	/* 0xd19: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d1e:
	/* 0xd1e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_d23:
	/* 0xd23: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d25:
	/* 0xd25: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_d27:
	/* 0xd27: js     3053 <generic_sleepable_preload+0x3053> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd27, 0x3053, x86_l_3053);
x86_l_d2d:
	/* 0xd2d: cmp    WORD PTR [rbx+0x9e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 678604832768ULL);
x86_l_d35:
	/* 0xd35: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd35, 0x3130, x86_l_3130);
x86_l_d3b:
	/* 0xd3b: mov    ecx,DWORD PTR [rbx+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_d41:
	/* 0xd41: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_d46:
	/* 0xd46: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d4b:
	/* 0xd4b: cmp    WORD PTR [rbx+0x9c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_d53:
	/* 0xd53: je     d78 <generic_sleepable_preload+0xd78> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd53, 0xd78, x86_l_d78);
x86_l_d55:
	/* 0xd55: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d5a:
	/* 0xd5a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_d5f:
	/* 0xd5f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_d64:
	/* 0xd64: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d69:
	/* 0xd69: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_d6e:
	/* 0xd6e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d70:
	/* 0xd70: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_d72:
	/* 0xd72: js     30bf <generic_sleepable_preload+0x30bf> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd72, 0x30bf, x86_l_30bf);
x86_l_d78:
	/* 0xd78: cmp    WORD PTR [rbx+0xa6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 712964571136ULL);
x86_l_d80:
	/* 0xd80: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd80, 0x3130, x86_l_3130);
x86_l_d86:
	/* 0xd86: mov    ecx,DWORD PTR [rbx+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_d8c:
	/* 0xd8c: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_d91:
	/* 0xd91: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d96:
	/* 0xd96: cmp    WORD PTR [rbx+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_d9e:
	/* 0xd9e: je     dc3 <generic_sleepable_preload+0xdc3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd9e, 0xdc3, x86_l_dc3);
x86_l_da0:
	/* 0xda0: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_da5:
	/* 0xda5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_daa:
	/* 0xdaa: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_daf:
	/* 0xdaf: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_db4:
	/* 0xdb4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_db9:
	/* 0xdb9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_dbb:
	/* 0xdbb: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_dbd:
	/* 0xdbd: js     3128 <generic_sleepable_preload+0x3128> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdbd, 0x3128, x86_l_3128);
x86_l_dc3:
	/* 0xdc3: cmp    WORD PTR [rbx+0xae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 747324309504ULL);
x86_l_dcb:
	/* 0xdcb: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdcb, 0x3130, x86_l_3130);
x86_l_dd1:
	/* 0xdd1: mov    ecx,DWORD PTR [rbx+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_dd7:
	/* 0xdd7: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_ddc:
	/* 0xddc: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_de1:
	/* 0xde1: cmp    WORD PTR [rbx+0xac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_de9:
	/* 0xde9: je     e0e <generic_sleepable_preload+0xe0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xde9, 0xe0e, x86_l_e0e);
x86_l_deb:
	/* 0xdeb: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_df0:
	/* 0xdf0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_df5:
	/* 0xdf5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_dfa:
	/* 0xdfa: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dff:
	/* 0xdff: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_e04:
	/* 0xe04: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e06:
	/* 0xe06: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_e08:
	/* 0xe08: js     38bd <generic_sleepable_preload+0x38bd> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe08, 0x38bd, x86_l_38bd);
x86_l_e0e:
	/* 0xe0e: cmp    WORD PTR [rbx+0xb6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 781684047872ULL);
x86_l_e16:
	/* 0xe16: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe16, 0x3130, x86_l_3130);
x86_l_e1c:
	/* 0xe1c: mov    ecx,DWORD PTR [rbx+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_e22:
	/* 0xe22: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_e27:
	/* 0xe27: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e2c:
	/* 0xe2c: cmp    WORD PTR [rbx+0xb4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113280ULL);
x86_l_e34:
	/* 0xe34: je     e59 <generic_sleepable_preload+0xe59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe34, 0xe59, x86_l_e59);
x86_l_e36:
	/* 0xe36: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e3b:
	/* 0xe3b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_e40:
	/* 0xe40: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_e45:
	/* 0xe45: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e4a:
	/* 0xe4a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_e4f:
	/* 0xe4f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e51:
	/* 0xe51: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_e53:
	/* 0xe53: js     3971 <generic_sleepable_preload+0x3971> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe53, 0x3971, x86_l_3971);
x86_l_e59:
	/* 0xe59: cmp    WORD PTR [rbx+0xbe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 816043786240ULL);
x86_l_e61:
	/* 0xe61: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe61, 0x3130, x86_l_3130);
x86_l_e67:
	/* 0xe67: mov    ecx,DWORD PTR [rbx+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_e6d:
	/* 0xe6d: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_e72:
	/* 0xe72: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e77:
	/* 0xe77: cmp    WORD PTR [rbx+0xbc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_e7f:
	/* 0xe7f: je     3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe7f, 0x3130, x86_l_3130);
x86_l_e85:
	/* 0xe85: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e8a:
	/* 0xe8a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_e8f:
	/* 0xe8f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_e94:
	/* 0xe94: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e99:
	/* 0xe99: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_e9e:
	/* 0xe9e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ea0:
	/* 0xea0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_ea2:
	/* 0xea2: jns    3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xea2, 0x3130, x86_l_3130);
x86_l_ea8:
	/* 0xea8: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_eae:
	/* 0xeae: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0xeae, 0x312e, x86_l_312e);
x86_l_eb3:
	/* 0xeb3: mov    edx,DWORD PTR [rbx+0x220] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 544ULL);
x86_l_eb9:
	/* 0xeb9: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_ebf:
	/* 0xebf: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_ec2:
	/* 0xec2: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ec7:
	/* 0xec7: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_ecc:
	/* 0xecc: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_ed1:
	/* 0xed1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_ed6:
	/* 0xed6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ed8:
	/* 0xed8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_eda:
	/* 0xeda: jne    f5d <generic_sleepable_preload+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xeda, 0xf5d, x86_l_f5d);
x86_l_ee0:
	/* 0xee0: mov    edx,DWORD PTR [rbx+0x224] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 548ULL);
x86_l_ee6:
	/* 0xee6: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_eec:
	/* 0xeec: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_eef:
	/* 0xeef: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_ef2:
	/* 0xef2: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_ef7:
	/* 0xef7: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_efc:
	/* 0xefc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_f01:
	/* 0xf01: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f03:
	/* 0xf03: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_f05:
	/* 0xf05: jne    f5d <generic_sleepable_preload+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf05, 0xf5d, x86_l_f5d);
x86_l_f07:
	/* 0xf07: movzx  eax,BYTE PTR [rbx+0x22b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 555ULL);
x86_l_f0e:
	/* 0xf0e: shlx   rax,QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_f14:
	/* 0xf14: mov    rcx,QWORD PTR [rbx+0x218] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_f1b:
	/* 0xf1b: add    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_f20:
	/* 0xf20: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_f23:
	/* 0xf23: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f28:
	/* 0xf28: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_f2d:
	/* 0xf2d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_f32:
	/* 0xf32: movzx  ecx,BYTE PTR [rbx+0x22b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 555ULL);
x86_l_f39:
	/* 0xf39: shlx   rcx,QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_f3f:
	/* 0xf3f: mov    rdx,QWORD PTR [rbx+0x218] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_f46:
	/* 0xf46: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_f4b:
	/* 0xf4b: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_f4e:
	/* 0xf4e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_f53:
	/* 0xf53: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f55:
	/* 0xf55: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_f57:
	/* 0xf57: je     a94 <generic_sleepable_preload+0xa94> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf57, 0xa94, x86_l_a94);
x86_l_f5d:
	/* 0xf5d: movsxd rcx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_f60:
	/* 0xf60: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f65:
	/* 0xf65: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_f68:
	/* 0xf68: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_f6b:
	/* 0xf6b: cmp    WORD PTR [rbx+0xc6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 850403524608ULL);
x86_l_f73:
	/* 0xf73: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf73, 0x31f9, x86_l_31f9);
x86_l_f79:
	/* 0xf79: mov    eax,DWORD PTR [rbx+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_f7f:
	/* 0xf7f: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_f82:
	/* 0xf82: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f87:
	/* 0xf87: cmp    WORD PTR [rbx+0xc4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 841813590016ULL);
x86_l_f8f:
	/* 0xf8f: je     fb4 <generic_sleepable_preload+0xfb4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf8f, 0xfb4, x86_l_fb4);
x86_l_f91:
	/* 0xf91: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f96:
	/* 0xf96: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_f9b:
	/* 0xf9b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_fa0:
	/* 0xfa0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fa5:
	/* 0xfa5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_faa:
	/* 0xfaa: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_fac:
	/* 0xfac: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_fae:
	/* 0xfae: js     1d8a <generic_sleepable_preload+0x1d8a> */
	X86_SIM_X86_JCC(X86_CC_S, 0xfae, 0x1d8a, x86_l_1d8a);
x86_l_fb4:
	/* 0xfb4: cmp    WORD PTR [rbx+0xce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 884763262976ULL);
x86_l_fbc:
	/* 0xfbc: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfbc, 0x31f9, x86_l_31f9);
x86_l_fc2:
	/* 0xfc2: mov    ecx,DWORD PTR [rbx+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_fc8:
	/* 0xfc8: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_fcd:
	/* 0xfcd: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fd2:
	/* 0xfd2: cmp    WORD PTR [rbx+0xcc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_fda:
	/* 0xfda: je     fff <generic_sleepable_preload+0xfff> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfda, 0xfff, x86_l_fff);
x86_l_fdc:
	/* 0xfdc: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fe1:
	/* 0xfe1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_fe6:
	/* 0xfe6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_feb:
	/* 0xfeb: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ff0:
	/* 0xff0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_ff5:
	/* 0xff5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ff7:
	/* 0xff7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_ff9:
	/* 0xff9: js     262f <generic_sleepable_preload+0x262f> */
	X86_SIM_X86_JCC(X86_CC_S, 0xff9, 0x262f, x86_l_262f);
x86_l_fff:
	/* 0xfff: cmp    WORD PTR [rbx+0xd6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 919123001344ULL);
x86_l_1007:
	/* 0x1007: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1007, 0x31f9, x86_l_31f9);
x86_l_100d:
	/* 0x100d: mov    ecx,DWORD PTR [rbx+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1013:
	/* 0x1013: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1018:
	/* 0x1018: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_101d:
	/* 0x101d: cmp    WORD PTR [rbx+0xd4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_1025:
	/* 0x1025: je     104a <generic_sleepable_preload+0x104a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1025, 0x104a, x86_l_104a);
x86_l_1027:
	/* 0x1027: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_102c:
	/* 0x102c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1031:
	/* 0x1031: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1036:
	/* 0x1036: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_103b:
	/* 0x103b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1040:
	/* 0x1040: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1042:
	/* 0x1042: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1044:
	/* 0x1044: js     2f86 <generic_sleepable_preload+0x2f86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1044, 0x2f86, x86_l_2f86);
x86_l_104a:
	/* 0x104a: cmp    WORD PTR [rbx+0xde],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 953482739712ULL);
x86_l_1052:
	/* 0x1052: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1052, 0x31f9, x86_l_31f9);
x86_l_1058:
	/* 0x1058: mov    ecx,DWORD PTR [rbx+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_105e:
	/* 0x105e: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1063:
	/* 0x1063: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1068:
	/* 0x1068: cmp    WORD PTR [rbx+0xdc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 944892805120ULL);
x86_l_1070:
	/* 0x1070: je     1095 <generic_sleepable_preload+0x1095> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1070, 0x1095, x86_l_1095);
x86_l_1072:
	/* 0x1072: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1077:
	/* 0x1077: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_107c:
	/* 0x107c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1081:
	/* 0x1081: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1086:
	/* 0x1086: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_108b:
	/* 0x108b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_108d:
	/* 0x108d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_108f:
	/* 0x108f: js     2ff2 <generic_sleepable_preload+0x2ff2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x108f, 0x2ff2, x86_l_2ff2);
x86_l_1095:
	/* 0x1095: cmp    WORD PTR [rbx+0xe6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 987842478080ULL);
x86_l_109d:
	/* 0x109d: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x109d, 0x31f9, x86_l_31f9);
x86_l_10a3:
	/* 0x10a3: mov    ecx,DWORD PTR [rbx+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_10a9:
	/* 0x10a9: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_10ae:
	/* 0x10ae: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10b3:
	/* 0x10b3: cmp    WORD PTR [rbx+0xe4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 979252543488ULL);
x86_l_10bb:
	/* 0x10bb: je     10e0 <generic_sleepable_preload+0x10e0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10bb, 0x10e0, x86_l_10e0);
x86_l_10bd:
	/* 0x10bd: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10c2:
	/* 0x10c2: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_10c7:
	/* 0x10c7: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_10cc:
	/* 0x10cc: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10d1:
	/* 0x10d1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_10d6:
	/* 0x10d6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10d8:
	/* 0x10d8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_10da:
	/* 0x10da: js     305e <generic_sleepable_preload+0x305e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10da, 0x305e, x86_l_305e);
x86_l_10e0:
	/* 0x10e0: cmp    WORD PTR [rbx+0xee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1022202216448ULL);
x86_l_10e8:
	/* 0x10e8: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e8, 0x31f9, x86_l_31f9);
x86_l_10ee:
	/* 0x10ee: mov    ecx,DWORD PTR [rbx+0xe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_10f4:
	/* 0x10f4: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_10f9:
	/* 0x10f9: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10fe:
	/* 0x10fe: cmp    WORD PTR [rbx+0xec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_1106:
	/* 0x1106: je     112b <generic_sleepable_preload+0x112b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1106, 0x112b, x86_l_112b);
x86_l_1108:
	/* 0x1108: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_110d:
	/* 0x110d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1112:
	/* 0x1112: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1117:
	/* 0x1117: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_111c:
	/* 0x111c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1121:
	/* 0x1121: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1123:
	/* 0x1123: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1125:
	/* 0x1125: js     30c7 <generic_sleepable_preload+0x30c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1125, 0x30c7, x86_l_30c7);
x86_l_112b:
	/* 0x112b: cmp    WORD PTR [rbx+0xf6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1056561954816ULL);
x86_l_1133:
	/* 0x1133: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1133, 0x31f9, x86_l_31f9);
x86_l_1139:
	/* 0x1139: mov    ecx,DWORD PTR [rbx+0xf0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_113f:
	/* 0x113f: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1144:
	/* 0x1144: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1149:
	/* 0x1149: cmp    WORD PTR [rbx+0xf4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_1151:
	/* 0x1151: je     1176 <generic_sleepable_preload+0x1176> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1151, 0x1176, x86_l_1176);
x86_l_1153:
	/* 0x1153: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1158:
	/* 0x1158: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_115d:
	/* 0x115d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1162:
	/* 0x1162: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1167:
	/* 0x1167: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_116c:
	/* 0x116c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_116e:
	/* 0x116e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1170:
	/* 0x1170: js     31f1 <generic_sleepable_preload+0x31f1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1170, 0x31f1, x86_l_31f1);
x86_l_1176:
	/* 0x1176: cmp    WORD PTR [rbx+0xfe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1090921693184ULL);
x86_l_117e:
	/* 0x117e: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x117e, 0x31f9, x86_l_31f9);
x86_l_1184:
	/* 0x1184: mov    ecx,DWORD PTR [rbx+0xf8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_118a:
	/* 0x118a: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_118f:
	/* 0x118f: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1194:
	/* 0x1194: cmp    WORD PTR [rbx+0xfc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_119c:
	/* 0x119c: je     11c1 <generic_sleepable_preload+0x11c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x119c, 0x11c1, x86_l_11c1);
x86_l_119e:
	/* 0x119e: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11a3:
	/* 0x11a3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_11a8:
	/* 0x11a8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_11ad:
	/* 0x11ad: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11b2:
	/* 0x11b2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_11b7:
	/* 0x11b7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11b9:
	/* 0x11b9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_11bb:
	/* 0x11bb: js     38ca <generic_sleepable_preload+0x38ca> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11bb, 0x38ca, x86_l_38ca);
x86_l_11c1:
	/* 0x11c1: cmp    WORD PTR [rbx+0x106],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1125281431552ULL);
x86_l_11c9:
	/* 0x11c9: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11c9, 0x31f9, x86_l_31f9);
x86_l_11cf:
	/* 0x11cf: mov    ecx,DWORD PTR [rbx+0x100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_11d5:
	/* 0x11d5: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_11da:
	/* 0x11da: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11df:
	/* 0x11df: cmp    WORD PTR [rbx+0x104],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1116691496960ULL);
x86_l_11e7:
	/* 0x11e7: je     120c <generic_sleepable_preload+0x120c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11e7, 0x120c, x86_l_120c);
x86_l_11e9:
	/* 0x11e9: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11ee:
	/* 0x11ee: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_11f3:
	/* 0x11f3: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_11f8:
	/* 0x11f8: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11fd:
	/* 0x11fd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1202:
	/* 0x1202: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1204:
	/* 0x1204: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1206:
	/* 0x1206: js     397c <generic_sleepable_preload+0x397c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1206, 0x397c, x86_l_397c);
x86_l_120c:
	/* 0x120c: cmp    WORD PTR [rbx+0x10e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1159641169920ULL);
x86_l_1214:
	/* 0x1214: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1214, 0x31f9, x86_l_31f9);
x86_l_121a:
	/* 0x121a: mov    ecx,DWORD PTR [rbx+0x108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_1220:
	/* 0x1220: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1225:
	/* 0x1225: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_122a:
	/* 0x122a: cmp    WORD PTR [rbx+0x10c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1151051235328ULL);
x86_l_1232:
	/* 0x1232: je     31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1232, 0x31f9, x86_l_31f9);
x86_l_1238:
	/* 0x1238: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_123d:
	/* 0x123d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1242:
	/* 0x1242: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1247:
	/* 0x1247: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_124c:
	/* 0x124c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1251:
	/* 0x1251: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1253:
	/* 0x1253: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1255:
	/* 0x1255: jns    31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1255, 0x31f9, x86_l_31f9);
x86_l_125b:
	/* 0x125b: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_1261:
	/* 0x1261: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x1261, 0x31f7, x86_l_31f7);
x86_l_1266:
	/* 0x1266: mov    edx,DWORD PTR [rbx+0x238] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 568ULL);
x86_l_126c:
	/* 0x126c: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1272:
	/* 0x1272: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1275:
	/* 0x1275: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_127a:
	/* 0x127a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_127f:
	/* 0x127f: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_1284:
	/* 0x1284: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1289:
	/* 0x1289: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_128b:
	/* 0x128b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_128d:
	/* 0x128d: jne    1310 <generic_sleepable_preload+0x1310> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x128d, 0x1310, x86_l_1310);
x86_l_1293:
	/* 0x1293: mov    edx,DWORD PTR [rbx+0x23c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 572ULL);
x86_l_1299:
	/* 0x1299: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_129f:
	/* 0x129f: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_12a2:
	/* 0x12a2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_12a5:
	/* 0x12a5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_12aa:
	/* 0x12aa: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_12af:
	/* 0x12af: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_12b4:
	/* 0x12b4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_12b6:
	/* 0x12b6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_12b8:
	/* 0x12b8: jne    1310 <generic_sleepable_preload+0x1310> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12b8, 0x1310, x86_l_1310);
x86_l_12ba:
	/* 0x12ba: movzx  eax,BYTE PTR [rbx+0x243] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 579ULL);
x86_l_12c1:
	/* 0x12c1: shlx   rax,QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_12c7:
	/* 0x12c7: mov    rcx,QWORD PTR [rbx+0x230] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 560ULL);
x86_l_12ce:
	/* 0x12ce: add    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_12d3:
	/* 0x12d3: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_12d6:
	/* 0x12d6: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12db:
	/* 0x12db: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_12e0:
	/* 0x12e0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_12e5:
	/* 0x12e5: movzx  ecx,BYTE PTR [rbx+0x243] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 579ULL);
x86_l_12ec:
	/* 0x12ec: shlx   rcx,QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_12f2:
	/* 0x12f2: mov    rdx,QWORD PTR [rbx+0x230] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 560ULL);
x86_l_12f9:
	/* 0x12f9: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_12fe:
	/* 0x12fe: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1301:
	/* 0x1301: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1306:
	/* 0x1306: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1308:
	/* 0x1308: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_130a:
	/* 0x130a: je     acd <generic_sleepable_preload+0xacd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x130a, 0xacd, x86_l_acd);
x86_l_1310:
	/* 0x1310: movsxd rcx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_1313:
	/* 0x1313: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1318:
	/* 0x1318: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_131b:
	/* 0x131b: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_131e:
	/* 0x131e: cmp    WORD PTR [rbx+0x116],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1194000908288ULL);
x86_l_1326:
	/* 0x1326: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1326, 0x32bf, x86_l_32bf);
x86_l_132c:
	/* 0x132c: mov    eax,DWORD PTR [rbx+0x110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_1332:
	/* 0x1332: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1335:
	/* 0x1335: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_133a:
	/* 0x133a: cmp    WORD PTR [rbx+0x114],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1185410973696ULL);
x86_l_1342:
	/* 0x1342: je     1367 <generic_sleepable_preload+0x1367> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1342, 0x1367, x86_l_1367);
x86_l_1344:
	/* 0x1344: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1349:
	/* 0x1349: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_134e:
	/* 0x134e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1353:
	/* 0x1353: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1358:
	/* 0x1358: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_135d:
	/* 0x135d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_135f:
	/* 0x135f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1361:
	/* 0x1361: js     1d95 <generic_sleepable_preload+0x1d95> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1361, 0x1d95, x86_l_1d95);
x86_l_1367:
	/* 0x1367: cmp    WORD PTR [rbx+0x11e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1228360646656ULL);
x86_l_136f:
	/* 0x136f: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x136f, 0x32bf, x86_l_32bf);
x86_l_1375:
	/* 0x1375: mov    ecx,DWORD PTR [rbx+0x118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_137b:
	/* 0x137b: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1380:
	/* 0x1380: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1385:
	/* 0x1385: cmp    WORD PTR [rbx+0x11c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1219770712064ULL);
x86_l_138d:
	/* 0x138d: je     13b2 <generic_sleepable_preload+0x13b2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x138d, 0x13b2, x86_l_13b2);
x86_l_138f:
	/* 0x138f: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1394:
	/* 0x1394: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1399:
	/* 0x1399: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_139e:
	/* 0x139e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13a3:
	/* 0x13a3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13a8:
	/* 0x13a8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13aa:
	/* 0x13aa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_13ac:
	/* 0x13ac: js     263a <generic_sleepable_preload+0x263a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13ac, 0x263a, x86_l_263a);
x86_l_13b2:
	/* 0x13b2: cmp    WORD PTR [rbx+0x126],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1262720385024ULL);
x86_l_13ba:
	/* 0x13ba: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13ba, 0x32bf, x86_l_32bf);
x86_l_13c0:
	/* 0x13c0: mov    ecx,DWORD PTR [rbx+0x120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_13c6:
	/* 0x13c6: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_13cb:
	/* 0x13cb: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13d0:
	/* 0x13d0: cmp    WORD PTR [rbx+0x124],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1254130450432ULL);
x86_l_13d8:
	/* 0x13d8: je     13fd <generic_sleepable_preload+0x13fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13d8, 0x13fd, x86_l_13fd);
x86_l_13da:
	/* 0x13da: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13df:
	/* 0x13df: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_13e4:
	/* 0x13e4: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_13e9:
	/* 0x13e9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13ee:
	/* 0x13ee: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13f3:
	/* 0x13f3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13f5:
	/* 0x13f5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_13f7:
	/* 0x13f7: js     2f91 <generic_sleepable_preload+0x2f91> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13f7, 0x2f91, x86_l_2f91);
x86_l_13fd:
	/* 0x13fd: cmp    WORD PTR [rbx+0x12e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1297080123392ULL);
x86_l_1405:
	/* 0x1405: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1405, 0x32bf, x86_l_32bf);
x86_l_140b:
	/* 0x140b: mov    ecx,DWORD PTR [rbx+0x128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_1411:
	/* 0x1411: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1416:
	/* 0x1416: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_141b:
	/* 0x141b: cmp    WORD PTR [rbx+0x12c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1288490188800ULL);
x86_l_1423:
	/* 0x1423: je     1448 <generic_sleepable_preload+0x1448> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1423, 0x1448, x86_l_1448);
x86_l_1425:
	/* 0x1425: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_142a:
	/* 0x142a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_142f:
	/* 0x142f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1434:
	/* 0x1434: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1439:
	/* 0x1439: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_143e:
	/* 0x143e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1440:
	/* 0x1440: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1442:
	/* 0x1442: js     2ffd <generic_sleepable_preload+0x2ffd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1442, 0x2ffd, x86_l_2ffd);
x86_l_1448:
	/* 0x1448: cmp    WORD PTR [rbx+0x136],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1331439861760ULL);
x86_l_1450:
	/* 0x1450: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1450, 0x32bf, x86_l_32bf);
x86_l_1456:
	/* 0x1456: mov    ecx,DWORD PTR [rbx+0x130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_145c:
	/* 0x145c: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1461:
	/* 0x1461: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1466:
	/* 0x1466: cmp    WORD PTR [rbx+0x134],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1322849927168ULL);
x86_l_146e:
	/* 0x146e: je     1493 <generic_sleepable_preload+0x1493> */
	X86_SIM_X86_JCC(X86_CC_E, 0x146e, 0x1493, x86_l_1493);
x86_l_1470:
	/* 0x1470: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1475:
	/* 0x1475: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_147a:
	/* 0x147a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_147f:
	/* 0x147f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1484:
	/* 0x1484: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1489:
	/* 0x1489: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_148b:
	/* 0x148b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_148d:
	/* 0x148d: js     3069 <generic_sleepable_preload+0x3069> */
	X86_SIM_X86_JCC(X86_CC_S, 0x148d, 0x3069, x86_l_3069);
x86_l_1493:
	/* 0x1493: cmp    WORD PTR [rbx+0x13e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1365799600128ULL);
x86_l_149b:
	/* 0x149b: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x149b, 0x32bf, x86_l_32bf);
x86_l_14a1:
	/* 0x14a1: mov    ecx,DWORD PTR [rbx+0x138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_14a7:
	/* 0x14a7: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_14ac:
	/* 0x14ac: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14b1:
	/* 0x14b1: cmp    WORD PTR [rbx+0x13c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1357209665536ULL);
x86_l_14b9:
	/* 0x14b9: je     14de <generic_sleepable_preload+0x14de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14b9, 0x14de, x86_l_14de);
x86_l_14bb:
	/* 0x14bb: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14c0:
	/* 0x14c0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_14c5:
	/* 0x14c5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_14ca:
	/* 0x14ca: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14cf:
	/* 0x14cf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_14d4:
	/* 0x14d4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_14d6:
	/* 0x14d6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_14d8:
	/* 0x14d8: js     30d2 <generic_sleepable_preload+0x30d2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14d8, 0x30d2, x86_l_30d2);
x86_l_14de:
	/* 0x14de: cmp    WORD PTR [rbx+0x146],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1400159338496ULL);
x86_l_14e6:
	/* 0x14e6: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e6, 0x32bf, x86_l_32bf);
x86_l_14ec:
	/* 0x14ec: mov    ecx,DWORD PTR [rbx+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_14f2:
	/* 0x14f2: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_14f7:
	/* 0x14f7: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14fc:
	/* 0x14fc: cmp    WORD PTR [rbx+0x144],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1391569403904ULL);
x86_l_1504:
	/* 0x1504: je     1529 <generic_sleepable_preload+0x1529> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1504, 0x1529, x86_l_1529);
x86_l_1506:
	/* 0x1506: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_150b:
	/* 0x150b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1510:
	/* 0x1510: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1515:
	/* 0x1515: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_151a:
	/* 0x151a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_151f:
	/* 0x151f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1521:
	/* 0x1521: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1523:
	/* 0x1523: js     32b7 <generic_sleepable_preload+0x32b7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1523, 0x32b7, x86_l_32b7);
x86_l_1529:
	/* 0x1529: cmp    WORD PTR [rbx+0x14e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1434519076864ULL);
x86_l_1531:
	/* 0x1531: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1531, 0x32bf, x86_l_32bf);
x86_l_1537:
	/* 0x1537: mov    ecx,DWORD PTR [rbx+0x148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_153d:
	/* 0x153d: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1542:
	/* 0x1542: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1547:
	/* 0x1547: cmp    WORD PTR [rbx+0x14c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1425929142272ULL);
x86_l_154f:
	/* 0x154f: je     1574 <generic_sleepable_preload+0x1574> */
	X86_SIM_X86_JCC(X86_CC_E, 0x154f, 0x1574, x86_l_1574);
x86_l_1551:
	/* 0x1551: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1556:
	/* 0x1556: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_155b:
	/* 0x155b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1560:
	/* 0x1560: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1565:
	/* 0x1565: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_156a:
	/* 0x156a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_156c:
	/* 0x156c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_156e:
	/* 0x156e: js     38d7 <generic_sleepable_preload+0x38d7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x156e, 0x38d7, x86_l_38d7);
x86_l_1574:
	/* 0x1574: cmp    WORD PTR [rbx+0x156],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1468878815232ULL);
x86_l_157c:
	/* 0x157c: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x157c, 0x32bf, x86_l_32bf);
x86_l_1582:
	/* 0x1582: mov    ecx,DWORD PTR [rbx+0x150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_1588:
	/* 0x1588: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_158d:
	/* 0x158d: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1592:
	/* 0x1592: cmp    WORD PTR [rbx+0x154],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1460288880640ULL);
x86_l_159a:
	/* 0x159a: je     15bf <generic_sleepable_preload+0x15bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x159a, 0x15bf, x86_l_15bf);
x86_l_159c:
	/* 0x159c: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15a1:
	/* 0x15a1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_15a6:
	/* 0x15a6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_15ab:
	/* 0x15ab: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15b0:
	/* 0x15b0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_15b5:
	/* 0x15b5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15b7:
	/* 0x15b7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_15b9:
	/* 0x15b9: js     3987 <generic_sleepable_preload+0x3987> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15b9, 0x3987, x86_l_3987);
x86_l_15bf:
	/* 0x15bf: cmp    WORD PTR [rbx+0x15e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1503238553600ULL);
x86_l_15c7:
	/* 0x15c7: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15c7, 0x32bf, x86_l_32bf);
x86_l_15cd:
	/* 0x15cd: mov    ecx,DWORD PTR [rbx+0x158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_15d3:
	/* 0x15d3: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_15d8:
	/* 0x15d8: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15dd:
	/* 0x15dd: cmp    WORD PTR [rbx+0x15c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619008ULL);
x86_l_15e5:
	/* 0x15e5: je     32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15e5, 0x32bf, x86_l_32bf);
x86_l_15eb:
	/* 0x15eb: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15f0:
	/* 0x15f0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_15f5:
	/* 0x15f5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_15fa:
	/* 0x15fa: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15ff:
	/* 0x15ff: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1604:
	/* 0x1604: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1606:
	/* 0x1606: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1608:
	/* 0x1608: jns    32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1608, 0x32bf, x86_l_32bf);
x86_l_160e:
	/* 0x160e: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_1614:
	/* 0x1614: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x1614, 0x32bd, x86_l_32bd);
x86_l_1619:
	/* 0x1619: mov    edx,DWORD PTR [rbx+0x250] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 592ULL);
x86_l_161f:
	/* 0x161f: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1625:
	/* 0x1625: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1628:
	/* 0x1628: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_162d:
	/* 0x162d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1632:
	/* 0x1632: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_1637:
	/* 0x1637: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_163c:
	/* 0x163c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_163e:
	/* 0x163e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1640:
	/* 0x1640: jne    16c3 <generic_sleepable_preload+0x16c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1640, 0x16c3, x86_l_16c3);
x86_l_1646:
	/* 0x1646: mov    edx,DWORD PTR [rbx+0x254] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 596ULL);
x86_l_164c:
	/* 0x164c: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1652:
	/* 0x1652: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1655:
	/* 0x1655: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1658:
	/* 0x1658: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_165d:
	/* 0x165d: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_1662:
	/* 0x1662: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1667:
	/* 0x1667: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1669:
	/* 0x1669: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_166b:
	/* 0x166b: jne    16c3 <generic_sleepable_preload+0x16c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x166b, 0x16c3, x86_l_16c3);
x86_l_166d:
	/* 0x166d: movzx  eax,BYTE PTR [rbx+0x25b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 603ULL);
x86_l_1674:
	/* 0x1674: shlx   rax,QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_167a:
	/* 0x167a: mov    rcx,QWORD PTR [rbx+0x248] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 584ULL);
x86_l_1681:
	/* 0x1681: add    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1686:
	/* 0x1686: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1689:
	/* 0x1689: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_168e:
	/* 0x168e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1693:
	/* 0x1693: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1698:
	/* 0x1698: movzx  ecx,BYTE PTR [rbx+0x25b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 603ULL);
x86_l_169f:
	/* 0x169f: shlx   rcx,QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_16a5:
	/* 0x16a5: mov    rdx,QWORD PTR [rbx+0x248] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 584ULL);
x86_l_16ac:
	/* 0x16ac: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_16b1:
	/* 0x16b1: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_16b4:
	/* 0x16b4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_16b9:
	/* 0x16b9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16bb:
	/* 0x16bb: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_16bd:
	/* 0x16bd: je     b01 <generic_sleepable_preload+0xb01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16bd, 0xb01, x86_l_b01);
x86_l_16c3:
	/* 0x16c3: movsxd rcx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_16c6:
	/* 0x16c6: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16cb:
	/* 0x16cb: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16ce:
	/* 0x16ce: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_16d1:
	/* 0x16d1: cmp    WORD PTR [rbx+0x166],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1537598291968ULL);
x86_l_16d9:
	/* 0x16d9: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d9, 0x3385, x86_l_3385);
x86_l_16df:
	/* 0x16df: mov    eax,DWORD PTR [rbx+0x160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_16e5:
	/* 0x16e5: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_16e8:
	/* 0x16e8: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16ed:
	/* 0x16ed: cmp    WORD PTR [rbx+0x164],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1529008357376ULL);
x86_l_16f5:
	/* 0x16f5: je     171a <generic_sleepable_preload+0x171a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16f5, 0x171a, x86_l_171a);
x86_l_16f7:
	/* 0x16f7: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16fc:
	/* 0x16fc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1701:
	/* 0x1701: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1706:
	/* 0x1706: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_170b:
	/* 0x170b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1710:
	/* 0x1710: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1712:
	/* 0x1712: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1714:
	/* 0x1714: js     1da0 <generic_sleepable_preload+0x1da0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1714, 0x1da0, x86_l_1da0);
x86_l_171a:
	/* 0x171a: cmp    WORD PTR [rbx+0x16e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1571958030336ULL);
x86_l_1722:
	/* 0x1722: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1722, 0x3385, x86_l_3385);
x86_l_1728:
	/* 0x1728: mov    ecx,DWORD PTR [rbx+0x168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_172e:
	/* 0x172e: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1733:
	/* 0x1733: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1738:
	/* 0x1738: cmp    WORD PTR [rbx+0x16c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1563368095744ULL);
x86_l_1740:
	/* 0x1740: je     1765 <generic_sleepable_preload+0x1765> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1740, 0x1765, x86_l_1765);
x86_l_1742:
	/* 0x1742: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1747:
	/* 0x1747: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_174c:
	/* 0x174c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1751:
	/* 0x1751: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1756:
	/* 0x1756: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_175b:
	/* 0x175b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_175d:
	/* 0x175d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_175f:
	/* 0x175f: js     2645 <generic_sleepable_preload+0x2645> */
	X86_SIM_X86_JCC(X86_CC_S, 0x175f, 0x2645, x86_l_2645);
x86_l_1765:
	/* 0x1765: cmp    WORD PTR [rbx+0x176],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1606317768704ULL);
x86_l_176d:
	/* 0x176d: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x176d, 0x3385, x86_l_3385);
x86_l_1773:
	/* 0x1773: mov    ecx,DWORD PTR [rbx+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_1779:
	/* 0x1779: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_177e:
	/* 0x177e: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1783:
	/* 0x1783: cmp    WORD PTR [rbx+0x174],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1597727834112ULL);
x86_l_178b:
	/* 0x178b: je     17b0 <generic_sleepable_preload+0x17b0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x178b, 0x17b0, x86_l_17b0);
x86_l_178d:
	/* 0x178d: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1792:
	/* 0x1792: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1797:
	/* 0x1797: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_179c:
	/* 0x179c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17a1:
	/* 0x17a1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_17a6:
	/* 0x17a6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17a8:
	/* 0x17a8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_17aa:
	/* 0x17aa: js     2f9c <generic_sleepable_preload+0x2f9c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x17aa, 0x2f9c, x86_l_2f9c);
x86_l_17b0:
	/* 0x17b0: cmp    WORD PTR [rbx+0x17e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1640677507072ULL);
x86_l_17b8:
	/* 0x17b8: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b8, 0x3385, x86_l_3385);
x86_l_17be:
	/* 0x17be: mov    ecx,DWORD PTR [rbx+0x178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_17c4:
	/* 0x17c4: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_17c9:
	/* 0x17c9: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17ce:
	/* 0x17ce: cmp    WORD PTR [rbx+0x17c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1632087572480ULL);
x86_l_17d6:
	/* 0x17d6: je     17fb <generic_sleepable_preload+0x17fb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17d6, 0x17fb, x86_l_17fb);
x86_l_17d8:
	/* 0x17d8: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17dd:
	/* 0x17dd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_17e2:
	/* 0x17e2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_17e7:
	/* 0x17e7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17ec:
	/* 0x17ec: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_17f1:
	/* 0x17f1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17f3:
	/* 0x17f3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_17f5:
	/* 0x17f5: js     3008 <generic_sleepable_preload+0x3008> */
	X86_SIM_X86_JCC(X86_CC_S, 0x17f5, 0x3008, x86_l_3008);
x86_l_17fb:
	/* 0x17fb: cmp    WORD PTR [rbx+0x186],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1675037245440ULL);
x86_l_1803:
	/* 0x1803: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1803, 0x3385, x86_l_3385);
x86_l_1809:
	/* 0x1809: mov    ecx,DWORD PTR [rbx+0x180] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_180f:
	/* 0x180f: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1814:
	/* 0x1814: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1819:
	/* 0x1819: cmp    WORD PTR [rbx+0x184],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1666447310848ULL);
x86_l_1821:
	/* 0x1821: je     1846 <generic_sleepable_preload+0x1846> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1821, 0x1846, x86_l_1846);
x86_l_1823:
	/* 0x1823: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1828:
	/* 0x1828: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_182d:
	/* 0x182d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1832:
	/* 0x1832: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1837:
	/* 0x1837: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_183c:
	/* 0x183c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_183e:
	/* 0x183e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1840:
	/* 0x1840: js     3074 <generic_sleepable_preload+0x3074> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1840, 0x3074, x86_l_3074);
x86_l_1846:
	/* 0x1846: cmp    WORD PTR [rbx+0x18e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1709396983808ULL);
x86_l_184e:
	/* 0x184e: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184e, 0x3385, x86_l_3385);
x86_l_1854:
	/* 0x1854: mov    ecx,DWORD PTR [rbx+0x188] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 392ULL);
x86_l_185a:
	/* 0x185a: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_185f:
	/* 0x185f: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1864:
	/* 0x1864: cmp    WORD PTR [rbx+0x18c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1700807049216ULL);
x86_l_186c:
	/* 0x186c: je     1891 <generic_sleepable_preload+0x1891> */
	X86_SIM_X86_JCC(X86_CC_E, 0x186c, 0x1891, x86_l_1891);
x86_l_186e:
	/* 0x186e: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1873:
	/* 0x1873: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1878:
	/* 0x1878: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_187d:
	/* 0x187d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1882:
	/* 0x1882: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1887:
	/* 0x1887: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1889:
	/* 0x1889: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_188b:
	/* 0x188b: js     30dd <generic_sleepable_preload+0x30dd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x188b, 0x30dd, x86_l_30dd);
x86_l_1891:
	/* 0x1891: cmp    WORD PTR [rbx+0x196],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1743756722176ULL);
x86_l_1899:
	/* 0x1899: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1899, 0x3385, x86_l_3385);
x86_l_189f:
	/* 0x189f: mov    ecx,DWORD PTR [rbx+0x190] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 400ULL);
x86_l_18a5:
	/* 0x18a5: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_18aa:
	/* 0x18aa: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18af:
	/* 0x18af: cmp    WORD PTR [rbx+0x194],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1735166787584ULL);
x86_l_18b7:
	/* 0x18b7: je     18dc <generic_sleepable_preload+0x18dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b7, 0x18dc, x86_l_18dc);
x86_l_18b9:
	/* 0x18b9: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18be:
	/* 0x18be: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_18c3:
	/* 0x18c3: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_18c8:
	/* 0x18c8: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18cd:
	/* 0x18cd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_18d2:
	/* 0x18d2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18d4:
	/* 0x18d4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_18d6:
	/* 0x18d6: js     337d <generic_sleepable_preload+0x337d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x18d6, 0x337d, x86_l_337d);
x86_l_18dc:
	/* 0x18dc: cmp    WORD PTR [rbx+0x19e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1778116460544ULL);
x86_l_18e4:
	/* 0x18e4: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18e4, 0x3385, x86_l_3385);
x86_l_18ea:
	/* 0x18ea: mov    ecx,DWORD PTR [rbx+0x198] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 408ULL);
x86_l_18f0:
	/* 0x18f0: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_18f5:
	/* 0x18f5: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18fa:
	/* 0x18fa: cmp    WORD PTR [rbx+0x19c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1769526525952ULL);
x86_l_1902:
	/* 0x1902: je     1927 <generic_sleepable_preload+0x1927> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1902, 0x1927, x86_l_1927);
x86_l_1904:
	/* 0x1904: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1909:
	/* 0x1909: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_190e:
	/* 0x190e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1913:
	/* 0x1913: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1918:
	/* 0x1918: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_191d:
	/* 0x191d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_191f:
	/* 0x191f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1921:
	/* 0x1921: js     38e4 <generic_sleepable_preload+0x38e4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1921, 0x38e4, x86_l_38e4);
x86_l_1927:
	/* 0x1927: cmp    WORD PTR [rbx+0x1a6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1812476198912ULL);
x86_l_192f:
	/* 0x192f: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x192f, 0x3385, x86_l_3385);
x86_l_1935:
	/* 0x1935: mov    ecx,DWORD PTR [rbx+0x1a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 416ULL);
x86_l_193b:
	/* 0x193b: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1940:
	/* 0x1940: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1945:
	/* 0x1945: cmp    WORD PTR [rbx+0x1a4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1803886264320ULL);
x86_l_194d:
	/* 0x194d: je     1972 <generic_sleepable_preload+0x1972> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194d, 0x1972, x86_l_1972);
x86_l_194f:
	/* 0x194f: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1954:
	/* 0x1954: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1959:
	/* 0x1959: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_195e:
	/* 0x195e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1963:
	/* 0x1963: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1968:
	/* 0x1968: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_196a:
	/* 0x196a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_196c:
	/* 0x196c: js     3992 <generic_sleepable_preload+0x3992> */
	X86_SIM_X86_JCC(X86_CC_S, 0x196c, 0x3992, x86_l_3992);
x86_l_1972:
	/* 0x1972: cmp    WORD PTR [rbx+0x1ae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1846835937280ULL);
x86_l_197a:
	/* 0x197a: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x197a, 0x3385, x86_l_3385);
x86_l_1980:
	/* 0x1980: mov    ecx,DWORD PTR [rbx+0x1a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 424ULL);
x86_l_1986:
	/* 0x1986: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_198b:
	/* 0x198b: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1990:
	/* 0x1990: cmp    WORD PTR [rbx+0x1ac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1838246002688ULL);
x86_l_1998:
	/* 0x1998: je     3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1998, 0x3385, x86_l_3385);
x86_l_199e:
	/* 0x199e: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19a3:
	/* 0x19a3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_19a8:
	/* 0x19a8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_19ad:
	/* 0x19ad: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b2:
	/* 0x19b2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_19b7:
	/* 0x19b7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_19b9:
	/* 0x19b9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_19bb:
	/* 0x19bb: jns    3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19bb, 0x3385, x86_l_3385);
x86_l_19c1:
	/* 0x19c1: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_19c7:
	/* 0x19c7: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x19c7, 0x3383, x86_l_3383);
x86_l_19cc:
	/* 0x19cc: mov    edx,DWORD PTR [rbx+0x268] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 616ULL);
x86_l_19d2:
	/* 0x19d2: and    edx,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_19d8:
	/* 0x19d8: add    rdx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_19db:
	/* 0x19db: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19e0:
	/* 0x19e0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_19e5:
	/* 0x19e5: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_19ea:
	/* 0x19ea: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_19ef:
	/* 0x19ef: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_19f1:
	/* 0x19f1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_19f3:
	/* 0x19f3: jne    1a78 <generic_sleepable_preload+0x1a78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19f3, 0x1a78, x86_l_1a78);
x86_l_19f9:
	/* 0x19f9: mov    eax,DWORD PTR [rbx+0x26c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 620ULL);
x86_l_19ff:
	/* 0x19ff: and    eax,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1a04:
	/* 0x1a04: add    r14,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1a07:
	/* 0x1a07: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1a0a:
	/* 0x1a0a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1a0f:
	/* 0x1a0f: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
x86_l_1a14:
	/* 0x1a14: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a19:
	/* 0x1a19: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_1a1c:
	/* 0x1a1c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a1e:
	/* 0x1a1e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1a20:
	/* 0x1a20: jne    1a78 <generic_sleepable_preload+0x1a78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a20, 0x1a78, x86_l_1a78);
x86_l_1a22:
	/* 0x1a22: movzx  eax,BYTE PTR [rbx+0x273] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 627ULL);
x86_l_1a29:
	/* 0x1a29: shlx   rax,QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_1a2f:
	/* 0x1a2f: mov    rcx,QWORD PTR [rbx+0x260] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 608ULL);
x86_l_1a36:
	/* 0x1a36: add    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1a3b:
	/* 0x1a3b: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1a3e:
	/* 0x1a3e: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a43:
	/* 0x1a43: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1a48:
	/* 0x1a48: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1a4d:
	/* 0x1a4d: movzx  ecx,BYTE PTR [rbx+0x273] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 627ULL);
x86_l_1a54:
	/* 0x1a54: shlx   rcx,QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((0ULL << 32) | X86_ALU_SHL));
x86_l_1a5a:
	/* 0x1a5a: mov    rdx,QWORD PTR [rbx+0x260] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 608ULL);
x86_l_1a61:
	/* 0x1a61: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1a66:
	/* 0x1a66: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1a69:
	/* 0x1a69: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a6e:
	/* 0x1a6e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a70:
	/* 0x1a70: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1a72:
	/* 0x1a72: je     b35 <generic_sleepable_preload+0xb35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a72, 0xb35, x86_l_b35);
x86_l_1a78:
	/* 0x1a78: movsxd rcx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_1a7b:
	/* 0x1a7b: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a80:
	/* 0x1a80: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1a82:
	/* 0x1a82: mov    r12b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_8, 1ULL);
x86_l_1a85:
	/* 0x1a85: cmp    WORD PTR [rbx+0x1b6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1881195675648ULL);
x86_l_1a8d:
	/* 0x1a8d: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8d, 0x344b, x86_l_344b);
x86_l_1a93:
	/* 0x1a93: mov    eax,DWORD PTR [rbx+0x1b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 432ULL);
x86_l_1a99:
	/* 0x1a99: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1a9c:
	/* 0x1a9c: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1aa1:
	/* 0x1aa1: cmp    WORD PTR [rbx+0x1b4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1872605741056ULL);
x86_l_1aa9:
	/* 0x1aa9: je     1ace <generic_sleepable_preload+0x1ace> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1aa9, 0x1ace, x86_l_1ace);
x86_l_1aab:
	/* 0x1aab: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ab0:
	/* 0x1ab0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1ab5:
	/* 0x1ab5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1aba:
	/* 0x1aba: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1abf:
	/* 0x1abf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1ac4:
	/* 0x1ac4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ac6:
	/* 0x1ac6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1ac8:
	/* 0x1ac8: js     1dab <generic_sleepable_preload+0x1dab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ac8, 0x1dab, x86_l_1dab);
x86_l_1ace:
	/* 0x1ace: cmp    WORD PTR [rbx+0x1be],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1915555414016ULL);
x86_l_1ad6:
	/* 0x1ad6: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ad6, 0x344b, x86_l_344b);
x86_l_1adc:
	/* 0x1adc: mov    ecx,DWORD PTR [rbx+0x1b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 440ULL);
x86_l_1ae2:
	/* 0x1ae2: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1ae7:
	/* 0x1ae7: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1aec:
	/* 0x1aec: cmp    WORD PTR [rbx+0x1bc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1906965479424ULL);
x86_l_1af4:
	/* 0x1af4: je     1b19 <generic_sleepable_preload+0x1b19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1af4, 0x1b19, x86_l_1b19);
x86_l_1af6:
	/* 0x1af6: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1afb:
	/* 0x1afb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1b00:
	/* 0x1b00: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1b05:
	/* 0x1b05: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b0a:
	/* 0x1b0a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1b0f:
	/* 0x1b0f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b11:
	/* 0x1b11: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1b13:
	/* 0x1b13: js     2650 <generic_sleepable_preload+0x2650> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b13, 0x2650, x86_l_2650);
x86_l_1b19:
	/* 0x1b19: cmp    WORD PTR [rbx+0x1c6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1949915152384ULL);
x86_l_1b21:
	/* 0x1b21: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b21, 0x344b, x86_l_344b);
x86_l_1b27:
	/* 0x1b27: mov    ecx,DWORD PTR [rbx+0x1c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 448ULL);
x86_l_1b2d:
	/* 0x1b2d: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1b32:
	/* 0x1b32: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b37:
	/* 0x1b37: cmp    WORD PTR [rbx+0x1c4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1941325217792ULL);
x86_l_1b3f:
	/* 0x1b3f: je     1b64 <generic_sleepable_preload+0x1b64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b3f, 0x1b64, x86_l_1b64);
x86_l_1b41:
	/* 0x1b41: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b46:
	/* 0x1b46: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1b4b:
	/* 0x1b4b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1b50:
	/* 0x1b50: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b55:
	/* 0x1b55: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1b5a:
	/* 0x1b5a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b5c:
	/* 0x1b5c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1b5e:
	/* 0x1b5e: js     2fa7 <generic_sleepable_preload+0x2fa7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b5e, 0x2fa7, x86_l_2fa7);
x86_l_1b64:
	/* 0x1b64: cmp    WORD PTR [rbx+0x1ce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1984274890752ULL);
x86_l_1b6c:
	/* 0x1b6c: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b6c, 0x344b, x86_l_344b);
x86_l_1b72:
	/* 0x1b72: mov    ecx,DWORD PTR [rbx+0x1c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 456ULL);
x86_l_1b78:
	/* 0x1b78: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1b7d:
	/* 0x1b7d: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b82:
	/* 0x1b82: cmp    WORD PTR [rbx+0x1cc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1975684956160ULL);
x86_l_1b8a:
	/* 0x1b8a: je     1baf <generic_sleepable_preload+0x1baf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b8a, 0x1baf, x86_l_1baf);
x86_l_1b8c:
	/* 0x1b8c: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b91:
	/* 0x1b91: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1b96:
	/* 0x1b96: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1b9b:
	/* 0x1b9b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ba0:
	/* 0x1ba0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1ba5:
	/* 0x1ba5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ba7:
	/* 0x1ba7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1ba9:
	/* 0x1ba9: js     3013 <generic_sleepable_preload+0x3013> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ba9, 0x3013, x86_l_3013);
x86_l_1baf:
	/* 0x1baf: cmp    WORD PTR [rbx+0x1d6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2018634629120ULL);
x86_l_1bb7:
	/* 0x1bb7: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bb7, 0x344b, x86_l_344b);
x86_l_1bbd:
	/* 0x1bbd: mov    ecx,DWORD PTR [rbx+0x1d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 464ULL);
x86_l_1bc3:
	/* 0x1bc3: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1bc8:
	/* 0x1bc8: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bcd:
	/* 0x1bcd: cmp    WORD PTR [rbx+0x1d4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2010044694528ULL);
x86_l_1bd5:
	/* 0x1bd5: je     1bfa <generic_sleepable_preload+0x1bfa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bd5, 0x1bfa, x86_l_1bfa);
x86_l_1bd7:
	/* 0x1bd7: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bdc:
	/* 0x1bdc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1be1:
	/* 0x1be1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1be6:
	/* 0x1be6: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1beb:
	/* 0x1beb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1bf0:
	/* 0x1bf0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1bf2:
	/* 0x1bf2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1bf4:
	/* 0x1bf4: js     307f <generic_sleepable_preload+0x307f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bf4, 0x307f, x86_l_307f);
x86_l_1bfa:
	/* 0x1bfa: cmp    WORD PTR [rbx+0x1de],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2052994367488ULL);
x86_l_1c02:
	/* 0x1c02: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c02, 0x344b, x86_l_344b);
x86_l_1c08:
	/* 0x1c08: mov    ecx,DWORD PTR [rbx+0x1d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 472ULL);
x86_l_1c0e:
	/* 0x1c0e: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1c13:
	/* 0x1c13: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c18:
	/* 0x1c18: cmp    WORD PTR [rbx+0x1dc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2044404432896ULL);
x86_l_1c20:
	/* 0x1c20: je     1c45 <generic_sleepable_preload+0x1c45> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c20, 0x1c45, x86_l_1c45);
x86_l_1c22:
	/* 0x1c22: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c27:
	/* 0x1c27: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1c2c:
	/* 0x1c2c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1c31:
	/* 0x1c31: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c36:
	/* 0x1c36: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1c3b:
	/* 0x1c3b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c3d:
	/* 0x1c3d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1c3f:
	/* 0x1c3f: js     30e8 <generic_sleepable_preload+0x30e8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c3f, 0x30e8, x86_l_30e8);
x86_l_1c45:
	/* 0x1c45: cmp    WORD PTR [rbx+0x1e6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2087354105856ULL);
x86_l_1c4d:
	/* 0x1c4d: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4d, 0x344b, x86_l_344b);
x86_l_1c53:
	/* 0x1c53: mov    ecx,DWORD PTR [rbx+0x1e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 480ULL);
x86_l_1c59:
	/* 0x1c59: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1c5e:
	/* 0x1c5e: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c63:
	/* 0x1c63: cmp    WORD PTR [rbx+0x1e4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2078764171264ULL);
x86_l_1c6b:
	/* 0x1c6b: je     1c90 <generic_sleepable_preload+0x1c90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c6b, 0x1c90, x86_l_1c90);
x86_l_1c6d:
	/* 0x1c6d: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c72:
	/* 0x1c72: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1c77:
	/* 0x1c77: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1c7c:
	/* 0x1c7c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c81:
	/* 0x1c81: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1c86:
	/* 0x1c86: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c88:
	/* 0x1c88: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1c8a:
	/* 0x1c8a: js     3443 <generic_sleepable_preload+0x3443> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c8a, 0x3443, x86_l_3443);
x86_l_1c90:
	/* 0x1c90: cmp    WORD PTR [rbx+0x1ee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2121713844224ULL);
x86_l_1c98:
	/* 0x1c98: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c98, 0x344b, x86_l_344b);
x86_l_1c9e:
	/* 0x1c9e: mov    ecx,DWORD PTR [rbx+0x1e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 488ULL);
x86_l_1ca4:
	/* 0x1ca4: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1ca9:
	/* 0x1ca9: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cae:
	/* 0x1cae: cmp    WORD PTR [rbx+0x1ec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2113123909632ULL);
x86_l_1cb6:
	/* 0x1cb6: je     1cdb <generic_sleepable_preload+0x1cdb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cb6, 0x1cdb, x86_l_1cdb);
x86_l_1cb8:
	/* 0x1cb8: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cbd:
	/* 0x1cbd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1cc2:
	/* 0x1cc2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1cc7:
	/* 0x1cc7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ccc:
	/* 0x1ccc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1cd1:
	/* 0x1cd1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cd3:
	/* 0x1cd3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1cd5:
	/* 0x1cd5: js     38f1 <generic_sleepable_preload+0x38f1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1cd5, 0x38f1, x86_l_38f1);
x86_l_1cdb:
	/* 0x1cdb: cmp    WORD PTR [rbx+0x1f6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2156073582592ULL);
x86_l_1ce3:
	/* 0x1ce3: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce3, 0x344b, x86_l_344b);
x86_l_1ce9:
	/* 0x1ce9: mov    ecx,DWORD PTR [rbx+0x1f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 496ULL);
x86_l_1cef:
	/* 0x1cef: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1cf4:
	/* 0x1cf4: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cf9:
	/* 0x1cf9: cmp    WORD PTR [rbx+0x1f4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2147483648000ULL);
x86_l_1d01:
	/* 0x1d01: je     1d26 <generic_sleepable_preload+0x1d26> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d01, 0x1d26, x86_l_1d26);
x86_l_1d03:
	/* 0x1d03: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d08:
	/* 0x1d08: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1d0d:
	/* 0x1d0d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1d12:
	/* 0x1d12: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d17:
	/* 0x1d17: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1d1c:
	/* 0x1d1c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d1e:
	/* 0x1d1e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1d20:
	/* 0x1d20: js     399d <generic_sleepable_preload+0x399d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d20, 0x399d, x86_l_399d);
x86_l_1d26:
	/* 0x1d26: cmp    WORD PTR [rbx+0x1fe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2190433320960ULL);
x86_l_1d2e:
	/* 0x1d2e: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d2e, 0x344b, x86_l_344b);
x86_l_1d34:
	/* 0x1d34: mov    ecx,DWORD PTR [rbx+0x1f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 504ULL);
x86_l_1d3a:
	/* 0x1d3a: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1d3f:
	/* 0x1d3f: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d44:
	/* 0x1d44: cmp    WORD PTR [rbx+0x1fc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2181843386368ULL);
x86_l_1d4c:
	/* 0x1d4c: je     344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d4c, 0x344b, x86_l_344b);
x86_l_1d52:
	/* 0x1d52: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d57:
	/* 0x1d57: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1d5c:
	/* 0x1d5c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1d61:
	/* 0x1d61: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d66:
	/* 0x1d66: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1d6b:
	/* 0x1d6b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d6d:
	/* 0x1d6d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1d6f:
	/* 0x1d6f: jns    344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d6f, 0x344b, x86_l_344b);
x86_l_1d75:
	/* 0x1d75: mov    ebp,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 10ULL);
x86_l_1d7a:
	/* 0x1d7a: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x1d7a, 0x3448, x86_l_3448);
x86_l_1d7f:
	/* 0x1d7f: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_1d85:
	/* 0x1d85: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x1d85, 0x312e, x86_l_312e);
x86_l_1d8a:
	/* 0x1d8a: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_1d90:
	/* 0x1d90: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x1d90, 0x31f7, x86_l_31f7);
x86_l_1d95:
	/* 0x1d95: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_1d9b:
	/* 0x1d9b: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x1d9b, 0x32bd, x86_l_32bd);
x86_l_1da0:
	/* 0x1da0: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_1da6:
	/* 0x1da6: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x1da6, 0x3383, x86_l_3383);
x86_l_1dab:
	/* 0x1dab: mov    ebp,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 1ULL);
x86_l_1db0:
	/* 0x1db0: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x1db0, 0x3448, x86_l_3448);
x86_l_1db5:
	/* 0x1db5: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1dbd:
	/* 0x1dbd: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_1dc0:
	/* 0x1dc0: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dc0, 0x1fca, x86_l_1fca);
x86_l_1dc6:
	/* 0x1dc6: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1dcb:
	/* 0x1dcb: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_1dce:
	/* 0x1dce: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dce, 0x1fca, x86_l_1fca);
x86_l_1dd4:
	/* 0x1dd4: jmp    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JMP(0x1dd4, 0x1fdd, x86_l_1fdd);
x86_l_1dd9:
	/* 0x1dd9: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1de1:
	/* 0x1de1: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_1de4:
	/* 0x1de4: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de4, 0x2672, x86_l_2672);
x86_l_1dea:
	/* 0x1dea: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1def:
	/* 0x1def: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_1df2:
	/* 0x1df2: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1df2, 0x2672, x86_l_2672);
x86_l_1df8:
	/* 0x1df8: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x1df8, 0x2685, x86_l_2685);
x86_l_1dfd:
	/* 0x1dfd: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1e05:
	/* 0x1e05: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_1e08:
	/* 0x1e08: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e08, 0x2976, x86_l_2976);
x86_l_1e0e:
	/* 0x1e0e: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e13:
	/* 0x1e13: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_1e16:
	/* 0x1e16: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e16, 0x2976, x86_l_2976);
x86_l_1e1c:
	/* 0x1e1c: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x1e1c, 0x2989, x86_l_2989);
x86_l_1e21:
	/* 0x1e21: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1e29:
	/* 0x1e29: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_1e2c:
	/* 0x1e2c: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e2c, 0x2c7a, x86_l_2c7a);
x86_l_1e32:
	/* 0x1e32: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e37:
	/* 0x1e37: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_1e3a:
	/* 0x1e3a: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e3a, 0x2c7a, x86_l_2c7a);
x86_l_1e40:
	/* 0x1e40: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x1e40, 0x2c8d, x86_l_2c8d);
x86_l_1e45:
	/* 0x1e45: mov    r14,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1e4d:
	/* 0x1e4d: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_1e50:
	/* 0x1e50: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e50, 0x2331, x86_l_2331);
x86_l_1e56:
	/* 0x1e56: mov    r14,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e5b:
	/* 0x1e5b: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_1e5e:
	/* 0x1e5e: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e5e, 0x2331, x86_l_2331);
x86_l_1e64:
	/* 0x1e64: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0x1e64, 0x2344, x86_l_2344);
x86_l_1e69:
	/* 0x1e69: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1e6e:
	/* 0x1e6e: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1e71:
	/* 0x1e71: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e71, 0x1fca, x86_l_1fca);
x86_l_1e77:
	/* 0x1e77: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e7c:
	/* 0x1e7c: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1e7f:
	/* 0x1e7f: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e7f, 0x1fca, x86_l_1fca);
x86_l_1e85:
	/* 0x1e85: jmp    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JMP(0x1e85, 0x1fdd, x86_l_1fdd);
x86_l_1e8a:
	/* 0x1e8a: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1e8f:
	/* 0x1e8f: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1e92:
	/* 0x1e92: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e92, 0x2672, x86_l_2672);
x86_l_1e98:
	/* 0x1e98: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e9d:
	/* 0x1e9d: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1ea0:
	/* 0x1ea0: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea0, 0x2672, x86_l_2672);
x86_l_1ea6:
	/* 0x1ea6: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x1ea6, 0x2685, x86_l_2685);
x86_l_1eab:
	/* 0x1eab: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1eb0:
	/* 0x1eb0: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1eb3:
	/* 0x1eb3: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eb3, 0x2976, x86_l_2976);
x86_l_1eb9:
	/* 0x1eb9: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ebe:
	/* 0x1ebe: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1ec1:
	/* 0x1ec1: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ec1, 0x2976, x86_l_2976);
x86_l_1ec7:
	/* 0x1ec7: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x1ec7, 0x2989, x86_l_2989);
x86_l_1ecc:
	/* 0x1ecc: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1ed1:
	/* 0x1ed1: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1ed4:
	/* 0x1ed4: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed4, 0x2c7a, x86_l_2c7a);
x86_l_1eda:
	/* 0x1eda: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1edf:
	/* 0x1edf: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1ee2:
	/* 0x1ee2: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee2, 0x2c7a, x86_l_2c7a);
x86_l_1ee8:
	/* 0x1ee8: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x1ee8, 0x2c8d, x86_l_2c8d);
x86_l_1eed:
	/* 0x1eed: mov    r14,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1ef2:
	/* 0x1ef2: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1ef5:
	/* 0x1ef5: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef5, 0x2331, x86_l_2331);
x86_l_1efb:
	/* 0x1efb: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f00:
	/* 0x1f00: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1f03:
	/* 0x1f03: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f03, 0x2331, x86_l_2331);
x86_l_1f09:
	/* 0x1f09: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0x1f09, 0x2344, x86_l_2344);
x86_l_1f0e:
	/* 0x1f0e: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1f13:
	/* 0x1f13: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_1f16:
	/* 0x1f16: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f16, 0x1fca, x86_l_1fca);
x86_l_1f1c:
	/* 0x1f1c: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f21:
	/* 0x1f21: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_1f24:
	/* 0x1f24: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f24, 0x1fca, x86_l_1fca);
x86_l_1f2a:
	/* 0x1f2a: jmp    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JMP(0x1f2a, 0x1fdd, x86_l_1fdd);
x86_l_1f2f:
	/* 0x1f2f: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1f34:
	/* 0x1f34: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_1f37:
	/* 0x1f37: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f37, 0x2672, x86_l_2672);
x86_l_1f3d:
	/* 0x1f3d: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f42:
	/* 0x1f42: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_1f45:
	/* 0x1f45: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f45, 0x2672, x86_l_2672);
x86_l_1f4b:
	/* 0x1f4b: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x1f4b, 0x2685, x86_l_2685);
x86_l_1f50:
	/* 0x1f50: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1f55:
	/* 0x1f55: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_1f58:
	/* 0x1f58: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f58, 0x2976, x86_l_2976);
x86_l_1f5e:
	/* 0x1f5e: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f63:
	/* 0x1f63: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_1f66:
	/* 0x1f66: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f66, 0x2976, x86_l_2976);
x86_l_1f6c:
	/* 0x1f6c: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x1f6c, 0x2989, x86_l_2989);
x86_l_1f71:
	/* 0x1f71: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1f76:
	/* 0x1f76: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_1f79:
	/* 0x1f79: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f79, 0x2c7a, x86_l_2c7a);
x86_l_1f7f:
	/* 0x1f7f: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f84:
	/* 0x1f84: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_1f87:
	/* 0x1f87: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f87, 0x2c7a, x86_l_2c7a);
x86_l_1f8d:
	/* 0x1f8d: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x1f8d, 0x2c8d, x86_l_2c8d);
x86_l_1f92:
	/* 0x1f92: mov    r14,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1f97:
	/* 0x1f97: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_1f9a:
	/* 0x1f9a: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f9a, 0x2331, x86_l_2331);
x86_l_1fa0:
	/* 0x1fa0: mov    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1fa5:
	/* 0x1fa5: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_1fa8:
	/* 0x1fa8: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fa8, 0x2331, x86_l_2331);
x86_l_1fae:
	/* 0x1fae: jmp    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JMP(0x1fae, 0x2344, x86_l_2344);
x86_l_1fb3:
	/* 0x1fb3: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1fbb:
	/* 0x1fbb: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_1fbe:
	/* 0x1fbe: je     1fca <generic_sleepable_preload+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fbe, 0x1fca, x86_l_1fca);
x86_l_1fc0:
	/* 0x1fc0: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1fc5:
	/* 0x1fc5: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1fc8:
	/* 0x1fc8: jne    1fdd <generic_sleepable_preload+0x1fdd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fc8, 0x1fdd, x86_l_1fdd);
x86_l_1fca:
	/* 0x1fca: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_1fcd:
	/* 0x1fcd: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_1fcf:
	/* 0x1fcf: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_1fd1:
	/* 0x1fd1: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_1fd6:
	/* 0x1fd6: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1fd8:
	/* 0x1fd8: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_1fdd:
	/* 0x1fdd: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe1:
	/* 0x1fe1: mov    r15d,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1fe5:
	/* 0x1fe5: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fe8:
	/* 0x1fe8: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_1feb:
	/* 0x1feb: cmp    WORD PTR [rbx+0x76],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 506806140928ULL);
x86_l_1ff0:
	/* 0x1ff0: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ff0, 0x3502, x86_l_3502);
x86_l_1ff6:
	/* 0x1ff6: mov    eax,DWORD PTR [rbx+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1ff9:
	/* 0x1ff9: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1ffc:
	/* 0x1ffc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2000:
	/* 0x2000: cmp    WORD PTR [rbx+0x74],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 498216206336ULL);
x86_l_2005:
	/* 0x2005: je     2027 <generic_sleepable_preload+0x2027> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2005, 0x2027, x86_l_2027);
x86_l_2007:
	/* 0x2007: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_200a:
	/* 0x200a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_200f:
	/* 0x200f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2014:
	/* 0x2014: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2018:
	/* 0x2018: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_201d:
	/* 0x201d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_201f:
	/* 0x201f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2021:
	/* 0x2021: js     22a3 <generic_sleepable_preload+0x22a3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2021, 0x22a3, x86_l_22a3);
x86_l_2027:
	/* 0x2027: cmp    WORD PTR [rbx+0x7e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 541165879296ULL);
x86_l_202c:
	/* 0x202c: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x202c, 0x3502, x86_l_3502);
x86_l_2032:
	/* 0x2032: mov    ecx,DWORD PTR [rbx+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2035:
	/* 0x2035: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2039:
	/* 0x2039: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203d:
	/* 0x203d: cmp    WORD PTR [rbx+0x7c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_2042:
	/* 0x2042: je     2064 <generic_sleepable_preload+0x2064> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2042, 0x2064, x86_l_2064);
x86_l_2044:
	/* 0x2044: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2047:
	/* 0x2047: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_204c:
	/* 0x204c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2051:
	/* 0x2051: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2055:
	/* 0x2055: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_205a:
	/* 0x205a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_205c:
	/* 0x205c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_205e:
	/* 0x205e: js     265a <generic_sleepable_preload+0x265a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x205e, 0x265a, x86_l_265a);
x86_l_2064:
	/* 0x2064: cmp    WORD PTR [rbx+0x86],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 575525617664ULL);
x86_l_206c:
	/* 0x206c: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x206c, 0x3502, x86_l_3502);
x86_l_2072:
	/* 0x2072: mov    ecx,DWORD PTR [rbx+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2078:
	/* 0x2078: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_207c:
	/* 0x207c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2080:
	/* 0x2080: cmp    WORD PTR [rbx+0x84],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_2088:
	/* 0x2088: je     20aa <generic_sleepable_preload+0x20aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2088, 0x20aa, x86_l_20aa);
x86_l_208a:
	/* 0x208a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_208d:
	/* 0x208d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2092:
	/* 0x2092: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2097:
	/* 0x2097: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_209b:
	/* 0x209b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_20a0:
	/* 0x20a0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20a2:
	/* 0x20a2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_20a4:
	/* 0x20a4: js     2fb1 <generic_sleepable_preload+0x2fb1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20a4, 0x2fb1, x86_l_2fb1);
x86_l_20aa:
	/* 0x20aa: cmp    WORD PTR [rbx+0x8e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 609885356032ULL);
x86_l_20b2:
	/* 0x20b2: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b2, 0x3502, x86_l_3502);
x86_l_20b8:
	/* 0x20b8: mov    ecx,DWORD PTR [rbx+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_20be:
	/* 0x20be: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_20c2:
	/* 0x20c2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c6:
	/* 0x20c6: cmp    WORD PTR [rbx+0x8c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_20ce:
	/* 0x20ce: je     20f0 <generic_sleepable_preload+0x20f0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ce, 0x20f0, x86_l_20f0);
x86_l_20d0:
	/* 0x20d0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_20d3:
	/* 0x20d3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_20d8:
	/* 0x20d8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_20dd:
	/* 0x20dd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20e1:
	/* 0x20e1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_20e6:
	/* 0x20e6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20e8:
	/* 0x20e8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_20ea:
	/* 0x20ea: js     301d <generic_sleepable_preload+0x301d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20ea, 0x301d, x86_l_301d);
x86_l_20f0:
	/* 0x20f0: cmp    WORD PTR [rbx+0x96],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 644245094400ULL);
x86_l_20f8:
	/* 0x20f8: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20f8, 0x3502, x86_l_3502);
x86_l_20fe:
	/* 0x20fe: mov    ecx,DWORD PTR [rbx+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2104:
	/* 0x2104: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2108:
	/* 0x2108: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_210c:
	/* 0x210c: cmp    WORD PTR [rbx+0x94],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_2114:
	/* 0x2114: je     2136 <generic_sleepable_preload+0x2136> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2114, 0x2136, x86_l_2136);
x86_l_2116:
	/* 0x2116: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2119:
	/* 0x2119: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_211e:
	/* 0x211e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2123:
	/* 0x2123: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2127:
	/* 0x2127: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_212c:
	/* 0x212c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_212e:
	/* 0x212e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2130:
	/* 0x2130: js     3089 <generic_sleepable_preload+0x3089> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2130, 0x3089, x86_l_3089);
x86_l_2136:
	/* 0x2136: cmp    WORD PTR [rbx+0x9e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 678604832768ULL);
x86_l_213e:
	/* 0x213e: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x213e, 0x3502, x86_l_3502);
x86_l_2144:
	/* 0x2144: mov    ecx,DWORD PTR [rbx+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_214a:
	/* 0x214a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_214e:
	/* 0x214e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2152:
	/* 0x2152: cmp    WORD PTR [rbx+0x9c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_215a:
	/* 0x215a: je     217c <generic_sleepable_preload+0x217c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215a, 0x217c, x86_l_217c);
x86_l_215c:
	/* 0x215c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_215f:
	/* 0x215f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2164:
	/* 0x2164: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2169:
	/* 0x2169: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_216d:
	/* 0x216d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2172:
	/* 0x2172: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2174:
	/* 0x2174: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2176:
	/* 0x2176: js     30f2 <generic_sleepable_preload+0x30f2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2176, 0x30f2, x86_l_30f2);
x86_l_217c:
	/* 0x217c: cmp    WORD PTR [rbx+0xa6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 712964571136ULL);
x86_l_2184:
	/* 0x2184: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2184, 0x3502, x86_l_3502);
x86_l_218a:
	/* 0x218a: mov    ecx,DWORD PTR [rbx+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2190:
	/* 0x2190: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2194:
	/* 0x2194: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2198:
	/* 0x2198: cmp    WORD PTR [rbx+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_21a0:
	/* 0x21a0: je     21c2 <generic_sleepable_preload+0x21c2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a0, 0x21c2, x86_l_21c2);
x86_l_21a2:
	/* 0x21a2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_21a5:
	/* 0x21a5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_21aa:
	/* 0x21aa: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_21af:
	/* 0x21af: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b3:
	/* 0x21b3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21b8:
	/* 0x21b8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_21ba:
	/* 0x21ba: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_21bc:
	/* 0x21bc: js     34fa <generic_sleepable_preload+0x34fa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21bc, 0x34fa, x86_l_34fa);
x86_l_21c2:
	/* 0x21c2: cmp    WORD PTR [rbx+0xae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 747324309504ULL);
x86_l_21ca:
	/* 0x21ca: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ca, 0x3502, x86_l_3502);
x86_l_21d0:
	/* 0x21d0: mov    ecx,DWORD PTR [rbx+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_21d6:
	/* 0x21d6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_21da:
	/* 0x21da: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21de:
	/* 0x21de: cmp    WORD PTR [rbx+0xac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_21e6:
	/* 0x21e6: je     2208 <generic_sleepable_preload+0x2208> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e6, 0x2208, x86_l_2208);
x86_l_21e8:
	/* 0x21e8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_21eb:
	/* 0x21eb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_21f0:
	/* 0x21f0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_21f5:
	/* 0x21f5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21f9:
	/* 0x21f9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21fe:
	/* 0x21fe: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2200:
	/* 0x2200: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2202:
	/* 0x2202: js     38fe <generic_sleepable_preload+0x38fe> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2202, 0x38fe, x86_l_38fe);
x86_l_2208:
	/* 0x2208: cmp    WORD PTR [rbx+0xb6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 781684047872ULL);
x86_l_2210:
	/* 0x2210: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2210, 0x3502, x86_l_3502);
x86_l_2216:
	/* 0x2216: mov    ecx,DWORD PTR [rbx+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_221c:
	/* 0x221c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2220:
	/* 0x2220: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2224:
	/* 0x2224: cmp    WORD PTR [rbx+0xb4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113280ULL);
x86_l_222c:
	/* 0x222c: je     224e <generic_sleepable_preload+0x224e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222c, 0x224e, x86_l_224e);
x86_l_222e:
	/* 0x222e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2231:
	/* 0x2231: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2236:
	/* 0x2236: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_223b:
	/* 0x223b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_223f:
	/* 0x223f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2244:
	/* 0x2244: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2246:
	/* 0x2246: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2248:
	/* 0x2248: js     39a7 <generic_sleepable_preload+0x39a7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2248, 0x39a7, x86_l_39a7);
x86_l_224e:
	/* 0x224e: cmp    WORD PTR [rbx+0xbe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 816043786240ULL);
x86_l_2256:
	/* 0x2256: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2256, 0x3502, x86_l_3502);
x86_l_225c:
	/* 0x225c: mov    ecx,DWORD PTR [rbx+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2262:
	/* 0x2262: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2266:
	/* 0x2266: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_226a:
	/* 0x226a: cmp    WORD PTR [rbx+0xbc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_2272:
	/* 0x2272: je     3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2272, 0x3502, x86_l_3502);
x86_l_2278:
	/* 0x2278: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_227b:
	/* 0x227b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2280:
	/* 0x2280: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2285:
	/* 0x2285: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2289:
	/* 0x2289: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_228e:
	/* 0x228e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2290:
	/* 0x2290: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2292:
	/* 0x2292: jns    3502 <generic_sleepable_preload+0x3502> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2292, 0x3502, x86_l_3502);
x86_l_2298:
	/* 0x2298: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_229e:
	/* 0x229e: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x229e, 0x3500, x86_l_3500);
x86_l_22a3:
	/* 0x22a3: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_22a9:
	/* 0x22a9: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x22a9, 0x3500, x86_l_3500);
x86_l_22ae:
	/* 0x22ae: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_22b6:
	/* 0x22b6: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_22b9:
	/* 0x22b9: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b9, 0x2672, x86_l_2672);
x86_l_22bf:
	/* 0x22bf: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_22c4:
	/* 0x22c4: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_22c7:
	/* 0x22c7: je     2672 <generic_sleepable_preload+0x2672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c7, 0x2672, x86_l_2672);
x86_l_22cd:
	/* 0x22cd: jmp    2685 <generic_sleepable_preload+0x2685> */
	X86_SIM_X86_JMP(0x22cd, 0x2685, x86_l_2685);
x86_l_22d2:
	/* 0x22d2: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_22da:
	/* 0x22da: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_22dd:
	/* 0x22dd: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22dd, 0x2976, x86_l_2976);
x86_l_22e3:
	/* 0x22e3: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_22e8:
	/* 0x22e8: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_22eb:
	/* 0x22eb: je     2976 <generic_sleepable_preload+0x2976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22eb, 0x2976, x86_l_2976);
x86_l_22f1:
	/* 0x22f1: jmp    2989 <generic_sleepable_preload+0x2989> */
	X86_SIM_X86_JMP(0x22f1, 0x2989, x86_l_2989);
x86_l_22f6:
	/* 0x22f6: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_22fe:
	/* 0x22fe: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_2301:
	/* 0x2301: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2301, 0x2c7a, x86_l_2c7a);
x86_l_2307:
	/* 0x2307: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_230c:
	/* 0x230c: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_230f:
	/* 0x230f: je     2c7a <generic_sleepable_preload+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x230f, 0x2c7a, x86_l_2c7a);
x86_l_2315:
	/* 0x2315: jmp    2c8d <generic_sleepable_preload+0x2c8d> */
	X86_SIM_X86_JMP(0x2315, 0x2c8d, x86_l_2c8d);
x86_l_231a:
	/* 0x231a: mov    r14,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2322:
	/* 0x2322: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_2325:
	/* 0x2325: je     2331 <generic_sleepable_preload+0x2331> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2325, 0x2331, x86_l_2331);
x86_l_2327:
	/* 0x2327: mov    r14,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_232c:
	/* 0x232c: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_232f:
	/* 0x232f: jne    2344 <generic_sleepable_preload+0x2344> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x232f, 0x2344, x86_l_2344);
x86_l_2331:
	/* 0x2331: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_2334:
	/* 0x2334: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_2336:
	/* 0x2336: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_2338:
	/* 0x2338: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_233d:
	/* 0x233d: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_233f:
	/* 0x233f: bzhi   rcx,QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_2344:
	/* 0x2344: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2348:
	/* 0x2348: mov    r14d,DWORD PTR [rbx+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_234c:
	/* 0x234c: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_234e:
	/* 0x234e: mov    r12b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_8, 1ULL);
x86_l_2351:
	/* 0x2351: cmp    WORD PTR [rbx+0x1b6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1881195675648ULL);
x86_l_2359:
	/* 0x2359: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2359, 0x35c5, x86_l_35c5);
x86_l_235f:
	/* 0x235f: mov    eax,DWORD PTR [rbx+0x1b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 432ULL);
x86_l_2365:
	/* 0x2365: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2368:
	/* 0x2368: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_236c:
	/* 0x236c: cmp    WORD PTR [rbx+0x1b4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1872605741056ULL);
x86_l_2374:
	/* 0x2374: je     2396 <generic_sleepable_preload+0x2396> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2374, 0x2396, x86_l_2396);
x86_l_2376:
	/* 0x2376: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2379:
	/* 0x2379: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_237e:
	/* 0x237e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2383:
	/* 0x2383: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2387:
	/* 0x2387: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_238c:
	/* 0x238c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_238e:
	/* 0x238e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2390:
	/* 0x2390: js     261a <generic_sleepable_preload+0x261a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2390, 0x261a, x86_l_261a);
x86_l_2396:
	/* 0x2396: cmp    WORD PTR [rbx+0x1be],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1915555414016ULL);
x86_l_239e:
	/* 0x239e: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x239e, 0x35c5, x86_l_35c5);
x86_l_23a4:
	/* 0x23a4: mov    ecx,DWORD PTR [rbx+0x1b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 440ULL);
x86_l_23aa:
	/* 0x23aa: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_23ae:
	/* 0x23ae: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23b2:
	/* 0x23b2: cmp    WORD PTR [rbx+0x1bc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1906965479424ULL);
x86_l_23ba:
	/* 0x23ba: je     23dc <generic_sleepable_preload+0x23dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ba, 0x23dc, x86_l_23dc);
x86_l_23bc:
	/* 0x23bc: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_23bf:
	/* 0x23bf: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_23c4:
	/* 0x23c4: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_23c9:
	/* 0x23c9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23cd:
	/* 0x23cd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_23d2:
	/* 0x23d2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23d4:
	/* 0x23d4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_23d6:
	/* 0x23d6: js     2665 <generic_sleepable_preload+0x2665> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23d6, 0x2665, x86_l_2665);
x86_l_23dc:
	/* 0x23dc: cmp    WORD PTR [rbx+0x1c6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1949915152384ULL);
x86_l_23e4:
	/* 0x23e4: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23e4, 0x35c5, x86_l_35c5);
x86_l_23ea:
	/* 0x23ea: mov    ecx,DWORD PTR [rbx+0x1c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 448ULL);
x86_l_23f0:
	/* 0x23f0: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_23f4:
	/* 0x23f4: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f8:
	/* 0x23f8: cmp    WORD PTR [rbx+0x1c4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1941325217792ULL);
x86_l_2400:
	/* 0x2400: je     2422 <generic_sleepable_preload+0x2422> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2400, 0x2422, x86_l_2422);
x86_l_2402:
	/* 0x2402: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2405:
	/* 0x2405: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_240a:
	/* 0x240a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_240f:
	/* 0x240f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2413:
	/* 0x2413: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2418:
	/* 0x2418: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_241a:
	/* 0x241a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_241c:
	/* 0x241c: js     2fbc <generic_sleepable_preload+0x2fbc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x241c, 0x2fbc, x86_l_2fbc);
x86_l_2422:
	/* 0x2422: cmp    WORD PTR [rbx+0x1ce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1984274890752ULL);
x86_l_242a:
	/* 0x242a: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x242a, 0x35c5, x86_l_35c5);
x86_l_2430:
	/* 0x2430: mov    ecx,DWORD PTR [rbx+0x1c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 456ULL);
x86_l_2436:
	/* 0x2436: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_243a:
	/* 0x243a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_243e:
	/* 0x243e: cmp    WORD PTR [rbx+0x1cc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1975684956160ULL);
x86_l_2446:
	/* 0x2446: je     2468 <generic_sleepable_preload+0x2468> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2446, 0x2468, x86_l_2468);
x86_l_2448:
	/* 0x2448: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_244b:
	/* 0x244b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2450:
	/* 0x2450: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2455:
	/* 0x2455: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2459:
	/* 0x2459: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_245e:
	/* 0x245e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2460:
	/* 0x2460: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2462:
	/* 0x2462: js     3028 <generic_sleepable_preload+0x3028> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2462, 0x3028, x86_l_3028);
x86_l_2468:
	/* 0x2468: cmp    WORD PTR [rbx+0x1d6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2018634629120ULL);
x86_l_2470:
	/* 0x2470: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2470, 0x35c5, x86_l_35c5);
x86_l_2476:
	/* 0x2476: mov    ecx,DWORD PTR [rbx+0x1d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 464ULL);
x86_l_247c:
	/* 0x247c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2480:
	/* 0x2480: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2484:
	/* 0x2484: cmp    WORD PTR [rbx+0x1d4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2010044694528ULL);
x86_l_248c:
	/* 0x248c: je     24ae <generic_sleepable_preload+0x24ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x248c, 0x24ae, x86_l_24ae);
x86_l_248e:
	/* 0x248e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2491:
	/* 0x2491: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2496:
	/* 0x2496: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_249b:
	/* 0x249b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_249f:
	/* 0x249f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_24a4:
	/* 0x24a4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_24a6:
	/* 0x24a6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_24a8:
	/* 0x24a8: js     3094 <generic_sleepable_preload+0x3094> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24a8, 0x3094, x86_l_3094);
x86_l_24ae:
	/* 0x24ae: cmp    WORD PTR [rbx+0x1de],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2052994367488ULL);
x86_l_24b6:
	/* 0x24b6: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24b6, 0x35c5, x86_l_35c5);
x86_l_24bc:
	/* 0x24bc: mov    ecx,DWORD PTR [rbx+0x1d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 472ULL);
x86_l_24c2:
	/* 0x24c2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_24c6:
	/* 0x24c6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24ca:
	/* 0x24ca: cmp    WORD PTR [rbx+0x1dc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2044404432896ULL);
x86_l_24d2:
	/* 0x24d2: je     24f4 <generic_sleepable_preload+0x24f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d2, 0x24f4, x86_l_24f4);
x86_l_24d4:
	/* 0x24d4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_24d7:
	/* 0x24d7: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_24dc:
	/* 0x24dc: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_24e1:
	/* 0x24e1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e5:
	/* 0x24e5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_24ea:
	/* 0x24ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_24ec:
	/* 0x24ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_24ee:
	/* 0x24ee: js     30fd <generic_sleepable_preload+0x30fd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24ee, 0x30fd, x86_l_30fd);
x86_l_24f4:
	/* 0x24f4: cmp    WORD PTR [rbx+0x1e6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2087354105856ULL);
x86_l_24fc:
	/* 0x24fc: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24fc, 0x35c5, x86_l_35c5);
x86_l_2502:
	/* 0x2502: mov    ecx,DWORD PTR [rbx+0x1e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 480ULL);
x86_l_2508:
	/* 0x2508: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_250c:
	/* 0x250c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2510:
	/* 0x2510: cmp    WORD PTR [rbx+0x1e4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2078764171264ULL);
x86_l_2518:
	/* 0x2518: je     253a <generic_sleepable_preload+0x253a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2518, 0x253a, x86_l_253a);
x86_l_251a:
	/* 0x251a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_251d:
	/* 0x251d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2522:
	/* 0x2522: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2527:
	/* 0x2527: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_252b:
	/* 0x252b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2530:
	/* 0x2530: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2532:
	/* 0x2532: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2534:
	/* 0x2534: js     35bd <generic_sleepable_preload+0x35bd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2534, 0x35bd, x86_l_35bd);
x86_l_253a:
	/* 0x253a: cmp    WORD PTR [rbx+0x1ee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2121713844224ULL);
x86_l_2542:
	/* 0x2542: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2542, 0x35c5, x86_l_35c5);
x86_l_2548:
	/* 0x2548: mov    ecx,DWORD PTR [rbx+0x1e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 488ULL);
x86_l_254e:
	/* 0x254e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2552:
	/* 0x2552: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2556:
	/* 0x2556: cmp    WORD PTR [rbx+0x1ec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2113123909632ULL);
x86_l_255e:
	/* 0x255e: je     2580 <generic_sleepable_preload+0x2580> */
	X86_SIM_X86_JCC(X86_CC_E, 0x255e, 0x2580, x86_l_2580);
x86_l_2560:
	/* 0x2560: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2563:
	/* 0x2563: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2568:
	/* 0x2568: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_256d:
	/* 0x256d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2571:
	/* 0x2571: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2576:
	/* 0x2576: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2578:
	/* 0x2578: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_257a:
	/* 0x257a: js     3915 <generic_sleepable_preload+0x3915> */
	X86_SIM_X86_JCC(X86_CC_S, 0x257a, 0x3915, x86_l_3915);
x86_l_2580:
	/* 0x2580: cmp    WORD PTR [rbx+0x1f6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2156073582592ULL);
x86_l_2588:
	/* 0x2588: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2588, 0x35c5, x86_l_35c5);
x86_l_258e:
	/* 0x258e: mov    ecx,DWORD PTR [rbx+0x1f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 496ULL);
x86_l_2594:
	/* 0x2594: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2598:
	/* 0x2598: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_259c:
	/* 0x259c: cmp    WORD PTR [rbx+0x1f4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2147483648000ULL);
x86_l_25a4:
	/* 0x25a4: je     25c6 <generic_sleepable_preload+0x25c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a4, 0x25c6, x86_l_25c6);
x86_l_25a6:
	/* 0x25a6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_25a9:
	/* 0x25a9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_25ae:
	/* 0x25ae: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_25b3:
	/* 0x25b3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25b7:
	/* 0x25b7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_25bc:
	/* 0x25bc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25be:
	/* 0x25be: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_25c0:
	/* 0x25c0: js     39b2 <generic_sleepable_preload+0x39b2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c0, 0x39b2, x86_l_39b2);
x86_l_25c6:
	/* 0x25c6: cmp    WORD PTR [rbx+0x1fe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2190433320960ULL);
x86_l_25ce:
	/* 0x25ce: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ce, 0x35c5, x86_l_35c5);
x86_l_25d4:
	/* 0x25d4: mov    ecx,DWORD PTR [rbx+0x1f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 504ULL);
x86_l_25da:
	/* 0x25da: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_25de:
	/* 0x25de: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25e2:
	/* 0x25e2: cmp    WORD PTR [rbx+0x1fc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2181843386368ULL);
x86_l_25ea:
	/* 0x25ea: je     35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ea, 0x35c5, x86_l_35c5);
x86_l_25f0:
	/* 0x25f0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_25f3:
	/* 0x25f3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_25f8:
	/* 0x25f8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_25fd:
	/* 0x25fd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2601:
	/* 0x2601: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2606:
	/* 0x2606: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2608:
	/* 0x2608: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_260a:
	/* 0x260a: jns    35c5 <generic_sleepable_preload+0x35c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x260a, 0x35c5, x86_l_35c5);
x86_l_2610:
	/* 0x2610: mov    ebp,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 10ULL);
x86_l_2615:
	/* 0x2615: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x2615, 0x35c2, x86_l_35c2);
x86_l_261a:
	/* 0x261a: mov    ebp,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 1ULL);
x86_l_261f:
	/* 0x261f: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x261f, 0x35c2, x86_l_35c2);
x86_l_2624:
	/* 0x2624: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_262a:
	/* 0x262a: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x262a, 0x312e, x86_l_312e);
x86_l_262f:
	/* 0x262f: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_2635:
	/* 0x2635: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x2635, 0x31f7, x86_l_31f7);
x86_l_263a:
	/* 0x263a: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_2640:
	/* 0x2640: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x2640, 0x32bd, x86_l_32bd);
x86_l_2645:
	/* 0x2645: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_264b:
	/* 0x264b: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x264b, 0x3383, x86_l_3383);
x86_l_2650:
	/* 0x2650: mov    ebp,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 2ULL);
x86_l_2655:
	/* 0x2655: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x2655, 0x3448, x86_l_3448);
x86_l_265a:
	/* 0x265a: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_2660:
	/* 0x2660: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x2660, 0x3500, x86_l_3500);
x86_l_2665:
	/* 0x2665: mov    ebp,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 2ULL);
x86_l_266a:
	/* 0x266a: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x266a, 0x35c2, x86_l_35c2);
x86_l_266f:
	/* 0x266f: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_2672:
	/* 0x2672: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_2675:
	/* 0x2675: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_2677:
	/* 0x2677: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_2679:
	/* 0x2679: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_267e:
	/* 0x267e: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2680:
	/* 0x2680: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_2685:
	/* 0x2685: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2689:
	/* 0x2689: mov    r15d,DWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_268d:
	/* 0x268d: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2690:
	/* 0x2690: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_2693:
	/* 0x2693: cmp    WORD PTR [rbx+0xc6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 850403524608ULL);
x86_l_269b:
	/* 0x269b: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x269b, 0x367c, x86_l_367c);
x86_l_26a1:
	/* 0x26a1: mov    eax,DWORD PTR [rbx+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_26a7:
	/* 0x26a7: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_26aa:
	/* 0x26aa: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26ae:
	/* 0x26ae: cmp    WORD PTR [rbx+0xc4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 841813590016ULL);
x86_l_26b6:
	/* 0x26b6: je     26d8 <generic_sleepable_preload+0x26d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26b6, 0x26d8, x86_l_26d8);
x86_l_26b8:
	/* 0x26b8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_26bb:
	/* 0x26bb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_26c0:
	/* 0x26c0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_26c5:
	/* 0x26c5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c9:
	/* 0x26c9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_26ce:
	/* 0x26ce: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26d0:
	/* 0x26d0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_26d2:
	/* 0x26d2: js     295d <generic_sleepable_preload+0x295d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26d2, 0x295d, x86_l_295d);
x86_l_26d8:
	/* 0x26d8: cmp    WORD PTR [rbx+0xce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 884763262976ULL);
x86_l_26e0:
	/* 0x26e0: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e0, 0x367c, x86_l_367c);
x86_l_26e6:
	/* 0x26e6: mov    ecx,DWORD PTR [rbx+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_26ec:
	/* 0x26ec: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_26f0:
	/* 0x26f0: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f4:
	/* 0x26f4: cmp    WORD PTR [rbx+0xcc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_26fc:
	/* 0x26fc: je     271e <generic_sleepable_preload+0x271e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26fc, 0x271e, x86_l_271e);
x86_l_26fe:
	/* 0x26fe: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2701:
	/* 0x2701: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2706:
	/* 0x2706: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_270b:
	/* 0x270b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_270f:
	/* 0x270f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2714:
	/* 0x2714: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2716:
	/* 0x2716: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2718:
	/* 0x2718: js     2968 <generic_sleepable_preload+0x2968> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2718, 0x2968, x86_l_2968);
x86_l_271e:
	/* 0x271e: cmp    WORD PTR [rbx+0xd6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 919123001344ULL);
x86_l_2726:
	/* 0x2726: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2726, 0x367c, x86_l_367c);
x86_l_272c:
	/* 0x272c: mov    ecx,DWORD PTR [rbx+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2732:
	/* 0x2732: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2736:
	/* 0x2736: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_273a:
	/* 0x273a: cmp    WORD PTR [rbx+0xd4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_2742:
	/* 0x2742: je     2764 <generic_sleepable_preload+0x2764> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2742, 0x2764, x86_l_2764);
x86_l_2744:
	/* 0x2744: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2747:
	/* 0x2747: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_274c:
	/* 0x274c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2751:
	/* 0x2751: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2755:
	/* 0x2755: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_275a:
	/* 0x275a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_275c:
	/* 0x275c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_275e:
	/* 0x275e: js     2fc6 <generic_sleepable_preload+0x2fc6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x275e, 0x2fc6, x86_l_2fc6);
x86_l_2764:
	/* 0x2764: cmp    WORD PTR [rbx+0xde],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 953482739712ULL);
x86_l_276c:
	/* 0x276c: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x276c, 0x367c, x86_l_367c);
x86_l_2772:
	/* 0x2772: mov    ecx,DWORD PTR [rbx+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2778:
	/* 0x2778: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_277c:
	/* 0x277c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2780:
	/* 0x2780: cmp    WORD PTR [rbx+0xdc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 944892805120ULL);
x86_l_2788:
	/* 0x2788: je     27aa <generic_sleepable_preload+0x27aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2788, 0x27aa, x86_l_27aa);
x86_l_278a:
	/* 0x278a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_278d:
	/* 0x278d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2792:
	/* 0x2792: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2797:
	/* 0x2797: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_279b:
	/* 0x279b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_27a0:
	/* 0x27a0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_27a2:
	/* 0x27a2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_27a4:
	/* 0x27a4: js     3032 <generic_sleepable_preload+0x3032> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27a4, 0x3032, x86_l_3032);
x86_l_27aa:
	/* 0x27aa: cmp    WORD PTR [rbx+0xe6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 987842478080ULL);
x86_l_27b2:
	/* 0x27b2: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27b2, 0x367c, x86_l_367c);
x86_l_27b8:
	/* 0x27b8: mov    ecx,DWORD PTR [rbx+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_27be:
	/* 0x27be: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_27c2:
	/* 0x27c2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c6:
	/* 0x27c6: cmp    WORD PTR [rbx+0xe4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 979252543488ULL);
x86_l_27ce:
	/* 0x27ce: je     27f0 <generic_sleepable_preload+0x27f0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ce, 0x27f0, x86_l_27f0);
x86_l_27d0:
	/* 0x27d0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_27d3:
	/* 0x27d3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_27d8:
	/* 0x27d8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_27dd:
	/* 0x27dd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27e1:
	/* 0x27e1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_27e6:
	/* 0x27e6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_27e8:
	/* 0x27e8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_27ea:
	/* 0x27ea: js     309e <generic_sleepable_preload+0x309e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27ea, 0x309e, x86_l_309e);
x86_l_27f0:
	/* 0x27f0: cmp    WORD PTR [rbx+0xee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1022202216448ULL);
x86_l_27f8:
	/* 0x27f8: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f8, 0x367c, x86_l_367c);
x86_l_27fe:
	/* 0x27fe: mov    ecx,DWORD PTR [rbx+0xe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_2804:
	/* 0x2804: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2808:
	/* 0x2808: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280c:
	/* 0x280c: cmp    WORD PTR [rbx+0xec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_2814:
	/* 0x2814: je     2836 <generic_sleepable_preload+0x2836> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2814, 0x2836, x86_l_2836);
x86_l_2816:
	/* 0x2816: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2819:
	/* 0x2819: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_281e:
	/* 0x281e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2823:
	/* 0x2823: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2827:
	/* 0x2827: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_282c:
	/* 0x282c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_282e:
	/* 0x282e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2830:
	/* 0x2830: js     3107 <generic_sleepable_preload+0x3107> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2830, 0x3107, x86_l_3107);
x86_l_2836:
	/* 0x2836: cmp    WORD PTR [rbx+0xf6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1056561954816ULL);
x86_l_283e:
	/* 0x283e: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x283e, 0x367c, x86_l_367c);
x86_l_2844:
	/* 0x2844: mov    ecx,DWORD PTR [rbx+0xf0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_284a:
	/* 0x284a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_284e:
	/* 0x284e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2852:
	/* 0x2852: cmp    WORD PTR [rbx+0xf4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_285a:
	/* 0x285a: je     287c <generic_sleepable_preload+0x287c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x285a, 0x287c, x86_l_287c);
x86_l_285c:
	/* 0x285c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_285f:
	/* 0x285f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2864:
	/* 0x2864: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2869:
	/* 0x2869: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_286d:
	/* 0x286d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2872:
	/* 0x2872: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2874:
	/* 0x2874: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2876:
	/* 0x2876: js     3674 <generic_sleepable_preload+0x3674> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2876, 0x3674, x86_l_3674);
x86_l_287c:
	/* 0x287c: cmp    WORD PTR [rbx+0xfe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1090921693184ULL);
x86_l_2884:
	/* 0x2884: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2884, 0x367c, x86_l_367c);
x86_l_288a:
	/* 0x288a: mov    ecx,DWORD PTR [rbx+0xf8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2890:
	/* 0x2890: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2894:
	/* 0x2894: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2898:
	/* 0x2898: cmp    WORD PTR [rbx+0xfc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_28a0:
	/* 0x28a0: je     28c2 <generic_sleepable_preload+0x28c2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a0, 0x28c2, x86_l_28c2);
x86_l_28a2:
	/* 0x28a2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_28a5:
	/* 0x28a5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_28aa:
	/* 0x28aa: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_28af:
	/* 0x28af: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b3:
	/* 0x28b3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_28b8:
	/* 0x28b8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28ba:
	/* 0x28ba: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_28bc:
	/* 0x28bc: js     392c <generic_sleepable_preload+0x392c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28bc, 0x392c, x86_l_392c);
x86_l_28c2:
	/* 0x28c2: cmp    WORD PTR [rbx+0x106],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1125281431552ULL);
x86_l_28ca:
	/* 0x28ca: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28ca, 0x367c, x86_l_367c);
x86_l_28d0:
	/* 0x28d0: mov    ecx,DWORD PTR [rbx+0x100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_28d6:
	/* 0x28d6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_28da:
	/* 0x28da: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28de:
	/* 0x28de: cmp    WORD PTR [rbx+0x104],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1116691496960ULL);
x86_l_28e6:
	/* 0x28e6: je     2908 <generic_sleepable_preload+0x2908> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28e6, 0x2908, x86_l_2908);
x86_l_28e8:
	/* 0x28e8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_28eb:
	/* 0x28eb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_28f0:
	/* 0x28f0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_28f5:
	/* 0x28f5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28f9:
	/* 0x28f9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_28fe:
	/* 0x28fe: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2900:
	/* 0x2900: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2902:
	/* 0x2902: js     39bc <generic_sleepable_preload+0x39bc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2902, 0x39bc, x86_l_39bc);
x86_l_2908:
	/* 0x2908: cmp    WORD PTR [rbx+0x10e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1159641169920ULL);
x86_l_2910:
	/* 0x2910: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2910, 0x367c, x86_l_367c);
x86_l_2916:
	/* 0x2916: mov    ecx,DWORD PTR [rbx+0x108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_291c:
	/* 0x291c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2920:
	/* 0x2920: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2924:
	/* 0x2924: cmp    WORD PTR [rbx+0x10c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1151051235328ULL);
x86_l_292c:
	/* 0x292c: je     367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x292c, 0x367c, x86_l_367c);
x86_l_2932:
	/* 0x2932: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2935:
	/* 0x2935: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_293a:
	/* 0x293a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_293f:
	/* 0x293f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2943:
	/* 0x2943: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2948:
	/* 0x2948: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_294a:
	/* 0x294a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_294c:
	/* 0x294c: jns    367c <generic_sleepable_preload+0x367c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x294c, 0x367c, x86_l_367c);
x86_l_2952:
	/* 0x2952: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_2958:
	/* 0x2958: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x2958, 0x367a, x86_l_367a);
x86_l_295d:
	/* 0x295d: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_2963:
	/* 0x2963: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x2963, 0x367a, x86_l_367a);
x86_l_2968:
	/* 0x2968: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_296e:
	/* 0x296e: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x296e, 0x367a, x86_l_367a);
x86_l_2973:
	/* 0x2973: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_2976:
	/* 0x2976: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_2979:
	/* 0x2979: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_297b:
	/* 0x297b: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_297d:
	/* 0x297d: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_2982:
	/* 0x2982: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2984:
	/* 0x2984: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_2989:
	/* 0x2989: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_298d:
	/* 0x298d: mov    r15d,DWORD PTR [rbx+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2991:
	/* 0x2991: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2994:
	/* 0x2994: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_2997:
	/* 0x2997: cmp    WORD PTR [rbx+0x116],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1194000908288ULL);
x86_l_299f:
	/* 0x299f: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x299f, 0x373f, x86_l_373f);
x86_l_29a5:
	/* 0x29a5: mov    eax,DWORD PTR [rbx+0x110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_29ab:
	/* 0x29ab: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_29ae:
	/* 0x29ae: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b2:
	/* 0x29b2: cmp    WORD PTR [rbx+0x114],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1185410973696ULL);
x86_l_29ba:
	/* 0x29ba: je     29dc <generic_sleepable_preload+0x29dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29ba, 0x29dc, x86_l_29dc);
x86_l_29bc:
	/* 0x29bc: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_29bf:
	/* 0x29bf: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_29c4:
	/* 0x29c4: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_29c9:
	/* 0x29c9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29cd:
	/* 0x29cd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_29d2:
	/* 0x29d2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29d4:
	/* 0x29d4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_29d6:
	/* 0x29d6: js     2c61 <generic_sleepable_preload+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29d6, 0x2c61, x86_l_2c61);
x86_l_29dc:
	/* 0x29dc: cmp    WORD PTR [rbx+0x11e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1228360646656ULL);
x86_l_29e4:
	/* 0x29e4: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29e4, 0x373f, x86_l_373f);
x86_l_29ea:
	/* 0x29ea: mov    ecx,DWORD PTR [rbx+0x118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_29f0:
	/* 0x29f0: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_29f4:
	/* 0x29f4: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29f8:
	/* 0x29f8: cmp    WORD PTR [rbx+0x11c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1219770712064ULL);
x86_l_2a00:
	/* 0x2a00: je     2a22 <generic_sleepable_preload+0x2a22> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a00, 0x2a22, x86_l_2a22);
x86_l_2a02:
	/* 0x2a02: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2a05:
	/* 0x2a05: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2a0a:
	/* 0x2a0a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2a0f:
	/* 0x2a0f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a13:
	/* 0x2a13: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2a18:
	/* 0x2a18: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a1a:
	/* 0x2a1a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2a1c:
	/* 0x2a1c: js     2c6c <generic_sleepable_preload+0x2c6c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a1c, 0x2c6c, x86_l_2c6c);
x86_l_2a22:
	/* 0x2a22: cmp    WORD PTR [rbx+0x126],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1262720385024ULL);
x86_l_2a2a:
	/* 0x2a2a: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a2a, 0x373f, x86_l_373f);
x86_l_2a30:
	/* 0x2a30: mov    ecx,DWORD PTR [rbx+0x120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_2a36:
	/* 0x2a36: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2a3a:
	/* 0x2a3a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a3e:
	/* 0x2a3e: cmp    WORD PTR [rbx+0x124],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1254130450432ULL);
x86_l_2a46:
	/* 0x2a46: je     2a68 <generic_sleepable_preload+0x2a68> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a46, 0x2a68, x86_l_2a68);
x86_l_2a48:
	/* 0x2a48: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2a4b:
	/* 0x2a4b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2a50:
	/* 0x2a50: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2a55:
	/* 0x2a55: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a59:
	/* 0x2a59: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2a5e:
	/* 0x2a5e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a60:
	/* 0x2a60: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2a62:
	/* 0x2a62: js     2fd1 <generic_sleepable_preload+0x2fd1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a62, 0x2fd1, x86_l_2fd1);
x86_l_2a68:
	/* 0x2a68: cmp    WORD PTR [rbx+0x12e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1297080123392ULL);
x86_l_2a70:
	/* 0x2a70: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a70, 0x373f, x86_l_373f);
x86_l_2a76:
	/* 0x2a76: mov    ecx,DWORD PTR [rbx+0x128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_2a7c:
	/* 0x2a7c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2a80:
	/* 0x2a80: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a84:
	/* 0x2a84: cmp    WORD PTR [rbx+0x12c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1288490188800ULL);
x86_l_2a8c:
	/* 0x2a8c: je     2aae <generic_sleepable_preload+0x2aae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a8c, 0x2aae, x86_l_2aae);
x86_l_2a8e:
	/* 0x2a8e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2a91:
	/* 0x2a91: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2a96:
	/* 0x2a96: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2a9b:
	/* 0x2a9b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a9f:
	/* 0x2a9f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2aa4:
	/* 0x2aa4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2aa6:
	/* 0x2aa6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2aa8:
	/* 0x2aa8: js     303d <generic_sleepable_preload+0x303d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2aa8, 0x303d, x86_l_303d);
x86_l_2aae:
	/* 0x2aae: cmp    WORD PTR [rbx+0x136],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1331439861760ULL);
x86_l_2ab6:
	/* 0x2ab6: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ab6, 0x373f, x86_l_373f);
x86_l_2abc:
	/* 0x2abc: mov    ecx,DWORD PTR [rbx+0x130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_2ac2:
	/* 0x2ac2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2ac6:
	/* 0x2ac6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aca:
	/* 0x2aca: cmp    WORD PTR [rbx+0x134],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1322849927168ULL);
x86_l_2ad2:
	/* 0x2ad2: je     2af4 <generic_sleepable_preload+0x2af4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ad2, 0x2af4, x86_l_2af4);
x86_l_2ad4:
	/* 0x2ad4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ad7:
	/* 0x2ad7: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2adc:
	/* 0x2adc: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2ae1:
	/* 0x2ae1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae5:
	/* 0x2ae5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2aea:
	/* 0x2aea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2aec:
	/* 0x2aec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2aee:
	/* 0x2aee: js     30a9 <generic_sleepable_preload+0x30a9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2aee, 0x30a9, x86_l_30a9);
x86_l_2af4:
	/* 0x2af4: cmp    WORD PTR [rbx+0x13e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1365799600128ULL);
x86_l_2afc:
	/* 0x2afc: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2afc, 0x373f, x86_l_373f);
x86_l_2b02:
	/* 0x2b02: mov    ecx,DWORD PTR [rbx+0x138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_2b08:
	/* 0x2b08: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2b0c:
	/* 0x2b0c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b10:
	/* 0x2b10: cmp    WORD PTR [rbx+0x13c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1357209665536ULL);
x86_l_2b18:
	/* 0x2b18: je     2b3a <generic_sleepable_preload+0x2b3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b18, 0x2b3a, x86_l_2b3a);
x86_l_2b1a:
	/* 0x2b1a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2b1d:
	/* 0x2b1d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2b22:
	/* 0x2b22: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2b27:
	/* 0x2b27: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b2b:
	/* 0x2b2b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b30:
	/* 0x2b30: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b32:
	/* 0x2b32: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b34:
	/* 0x2b34: js     3112 <generic_sleepable_preload+0x3112> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b34, 0x3112, x86_l_3112);
x86_l_2b3a:
	/* 0x2b3a: cmp    WORD PTR [rbx+0x146],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1400159338496ULL);
x86_l_2b42:
	/* 0x2b42: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b42, 0x373f, x86_l_373f);
x86_l_2b48:
	/* 0x2b48: mov    ecx,DWORD PTR [rbx+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_2b4e:
	/* 0x2b4e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2b52:
	/* 0x2b52: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b56:
	/* 0x2b56: cmp    WORD PTR [rbx+0x144],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1391569403904ULL);
x86_l_2b5e:
	/* 0x2b5e: je     2b80 <generic_sleepable_preload+0x2b80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b5e, 0x2b80, x86_l_2b80);
x86_l_2b60:
	/* 0x2b60: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2b63:
	/* 0x2b63: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2b68:
	/* 0x2b68: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2b6d:
	/* 0x2b6d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b71:
	/* 0x2b71: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b76:
	/* 0x2b76: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b78:
	/* 0x2b78: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b7a:
	/* 0x2b7a: js     3737 <generic_sleepable_preload+0x3737> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b7a, 0x3737, x86_l_3737);
x86_l_2b80:
	/* 0x2b80: cmp    WORD PTR [rbx+0x14e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1434519076864ULL);
x86_l_2b88:
	/* 0x2b88: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b88, 0x373f, x86_l_373f);
x86_l_2b8e:
	/* 0x2b8e: mov    ecx,DWORD PTR [rbx+0x148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_2b94:
	/* 0x2b94: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2b98:
	/* 0x2b98: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b9c:
	/* 0x2b9c: cmp    WORD PTR [rbx+0x14c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1425929142272ULL);
x86_l_2ba4:
	/* 0x2ba4: je     2bc6 <generic_sleepable_preload+0x2bc6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ba4, 0x2bc6, x86_l_2bc6);
x86_l_2ba6:
	/* 0x2ba6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ba9:
	/* 0x2ba9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2bae:
	/* 0x2bae: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2bb3:
	/* 0x2bb3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bb7:
	/* 0x2bb7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2bbc:
	/* 0x2bbc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2bbe:
	/* 0x2bbe: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2bc0:
	/* 0x2bc0: js     3943 <generic_sleepable_preload+0x3943> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bc0, 0x3943, x86_l_3943);
x86_l_2bc6:
	/* 0x2bc6: cmp    WORD PTR [rbx+0x156],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1468878815232ULL);
x86_l_2bce:
	/* 0x2bce: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bce, 0x373f, x86_l_373f);
x86_l_2bd4:
	/* 0x2bd4: mov    ecx,DWORD PTR [rbx+0x150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_2bda:
	/* 0x2bda: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2bde:
	/* 0x2bde: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2be2:
	/* 0x2be2: cmp    WORD PTR [rbx+0x154],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1460288880640ULL);
x86_l_2bea:
	/* 0x2bea: je     2c0c <generic_sleepable_preload+0x2c0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bea, 0x2c0c, x86_l_2c0c);
x86_l_2bec:
	/* 0x2bec: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2bef:
	/* 0x2bef: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2bf4:
	/* 0x2bf4: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2bf9:
	/* 0x2bf9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bfd:
	/* 0x2bfd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2c02:
	/* 0x2c02: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c04:
	/* 0x2c04: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2c06:
	/* 0x2c06: js     39c7 <generic_sleepable_preload+0x39c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c06, 0x39c7, x86_l_39c7);
x86_l_2c0c:
	/* 0x2c0c: cmp    WORD PTR [rbx+0x15e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1503238553600ULL);
x86_l_2c14:
	/* 0x2c14: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c14, 0x373f, x86_l_373f);
x86_l_2c1a:
	/* 0x2c1a: mov    ecx,DWORD PTR [rbx+0x158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_2c20:
	/* 0x2c20: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2c24:
	/* 0x2c24: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c28:
	/* 0x2c28: cmp    WORD PTR [rbx+0x15c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619008ULL);
x86_l_2c30:
	/* 0x2c30: je     373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c30, 0x373f, x86_l_373f);
x86_l_2c36:
	/* 0x2c36: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2c39:
	/* 0x2c39: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2c3e:
	/* 0x2c3e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2c43:
	/* 0x2c43: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c47:
	/* 0x2c47: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2c4c:
	/* 0x2c4c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c4e:
	/* 0x2c4e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2c50:
	/* 0x2c50: jns    373f <generic_sleepable_preload+0x373f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c50, 0x373f, x86_l_373f);
x86_l_2c56:
	/* 0x2c56: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_2c5c:
	/* 0x2c5c: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x2c5c, 0x373d, x86_l_373d);
x86_l_2c61:
	/* 0x2c61: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_2c67:
	/* 0x2c67: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x2c67, 0x373d, x86_l_373d);
x86_l_2c6c:
	/* 0x2c6c: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_2c72:
	/* 0x2c72: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x2c72, 0x373d, x86_l_373d);
x86_l_2c77:
	/* 0x2c77: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_2c7a:
	/* 0x2c7a: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_2c7d:
	/* 0x2c7d: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_2c7f:
	/* 0x2c7f: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_2c81:
	/* 0x2c81: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_2c86:
	/* 0x2c86: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2c88:
	/* 0x2c88: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_2c8d:
	/* 0x2c8d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c91:
	/* 0x2c91: mov    r15d,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c95:
	/* 0x2c95: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2c98:
	/* 0x2c98: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_2c9b:
	/* 0x2c9b: cmp    WORD PTR [rbx+0x166],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1537598291968ULL);
x86_l_2ca3:
	/* 0x2ca3: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ca3, 0x3802, x86_l_3802);
x86_l_2ca9:
	/* 0x2ca9: mov    eax,DWORD PTR [rbx+0x160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_2caf:
	/* 0x2caf: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2cb2:
	/* 0x2cb2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cb6:
	/* 0x2cb6: cmp    WORD PTR [rbx+0x164],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1529008357376ULL);
x86_l_2cbe:
	/* 0x2cbe: je     2ce0 <generic_sleepable_preload+0x2ce0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cbe, 0x2ce0, x86_l_2ce0);
x86_l_2cc0:
	/* 0x2cc0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2cc3:
	/* 0x2cc3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2cc8:
	/* 0x2cc8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2ccd:
	/* 0x2ccd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cd1:
	/* 0x2cd1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2cd6:
	/* 0x2cd6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2cd8:
	/* 0x2cd8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2cda:
	/* 0x2cda: js     2f65 <generic_sleepable_preload+0x2f65> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2cda, 0x2f65, x86_l_2f65);
x86_l_2ce0:
	/* 0x2ce0: cmp    WORD PTR [rbx+0x16e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1571958030336ULL);
x86_l_2ce8:
	/* 0x2ce8: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ce8, 0x3802, x86_l_3802);
x86_l_2cee:
	/* 0x2cee: mov    ecx,DWORD PTR [rbx+0x168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_2cf4:
	/* 0x2cf4: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2cf8:
	/* 0x2cf8: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cfc:
	/* 0x2cfc: cmp    WORD PTR [rbx+0x16c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1563368095744ULL);
x86_l_2d04:
	/* 0x2d04: je     2d26 <generic_sleepable_preload+0x2d26> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d04, 0x2d26, x86_l_2d26);
x86_l_2d06:
	/* 0x2d06: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2d09:
	/* 0x2d09: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2d0e:
	/* 0x2d0e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2d13:
	/* 0x2d13: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d17:
	/* 0x2d17: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2d1c:
	/* 0x2d1c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d1e:
	/* 0x2d1e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2d20:
	/* 0x2d20: js     2f70 <generic_sleepable_preload+0x2f70> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d20, 0x2f70, x86_l_2f70);
x86_l_2d26:
	/* 0x2d26: cmp    WORD PTR [rbx+0x176],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1606317768704ULL);
x86_l_2d2e:
	/* 0x2d2e: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d2e, 0x3802, x86_l_3802);
x86_l_2d34:
	/* 0x2d34: mov    ecx,DWORD PTR [rbx+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_2d3a:
	/* 0x2d3a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2d3e:
	/* 0x2d3e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d42:
	/* 0x2d42: cmp    WORD PTR [rbx+0x174],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1597727834112ULL);
x86_l_2d4a:
	/* 0x2d4a: je     2d6c <generic_sleepable_preload+0x2d6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d4a, 0x2d6c, x86_l_2d6c);
x86_l_2d4c:
	/* 0x2d4c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2d4f:
	/* 0x2d4f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2d54:
	/* 0x2d54: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2d59:
	/* 0x2d59: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d5d:
	/* 0x2d5d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2d62:
	/* 0x2d62: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d64:
	/* 0x2d64: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2d66:
	/* 0x2d66: js     2fdc <generic_sleepable_preload+0x2fdc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d66, 0x2fdc, x86_l_2fdc);
x86_l_2d6c:
	/* 0x2d6c: cmp    WORD PTR [rbx+0x17e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1640677507072ULL);
x86_l_2d74:
	/* 0x2d74: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d74, 0x3802, x86_l_3802);
x86_l_2d7a:
	/* 0x2d7a: mov    ecx,DWORD PTR [rbx+0x178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_2d80:
	/* 0x2d80: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2d84:
	/* 0x2d84: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d88:
	/* 0x2d88: cmp    WORD PTR [rbx+0x17c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1632087572480ULL);
x86_l_2d90:
	/* 0x2d90: je     2db2 <generic_sleepable_preload+0x2db2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d90, 0x2db2, x86_l_2db2);
x86_l_2d92:
	/* 0x2d92: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2d95:
	/* 0x2d95: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2d9a:
	/* 0x2d9a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2d9f:
	/* 0x2d9f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da3:
	/* 0x2da3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2da8:
	/* 0x2da8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2daa:
	/* 0x2daa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2dac:
	/* 0x2dac: js     3048 <generic_sleepable_preload+0x3048> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dac, 0x3048, x86_l_3048);
x86_l_2db2:
	/* 0x2db2: cmp    WORD PTR [rbx+0x186],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1675037245440ULL);
x86_l_2dba:
	/* 0x2dba: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dba, 0x3802, x86_l_3802);
x86_l_2dc0:
	/* 0x2dc0: mov    ecx,DWORD PTR [rbx+0x180] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_2dc6:
	/* 0x2dc6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2dca:
	/* 0x2dca: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dce:
	/* 0x2dce: cmp    WORD PTR [rbx+0x184],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1666447310848ULL);
x86_l_2dd6:
	/* 0x2dd6: je     2df8 <generic_sleepable_preload+0x2df8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dd6, 0x2df8, x86_l_2df8);
x86_l_2dd8:
	/* 0x2dd8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ddb:
	/* 0x2ddb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2de0:
	/* 0x2de0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2de5:
	/* 0x2de5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2de9:
	/* 0x2de9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2dee:
	/* 0x2dee: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2df0:
	/* 0x2df0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2df2:
	/* 0x2df2: js     30b4 <generic_sleepable_preload+0x30b4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2df2, 0x30b4, x86_l_30b4);
x86_l_2df8:
	/* 0x2df8: cmp    WORD PTR [rbx+0x18e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1709396983808ULL);
x86_l_2e00:
	/* 0x2e00: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e00, 0x3802, x86_l_3802);
x86_l_2e06:
	/* 0x2e06: mov    ecx,DWORD PTR [rbx+0x188] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 392ULL);
x86_l_2e0c:
	/* 0x2e0c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2e10:
	/* 0x2e10: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e14:
	/* 0x2e14: cmp    WORD PTR [rbx+0x18c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1700807049216ULL);
x86_l_2e1c:
	/* 0x2e1c: je     2e3e <generic_sleepable_preload+0x2e3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e1c, 0x2e3e, x86_l_2e3e);
x86_l_2e1e:
	/* 0x2e1e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2e21:
	/* 0x2e21: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2e26:
	/* 0x2e26: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2e2b:
	/* 0x2e2b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e2f:
	/* 0x2e2f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2e34:
	/* 0x2e34: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e36:
	/* 0x2e36: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2e38:
	/* 0x2e38: js     311d <generic_sleepable_preload+0x311d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e38, 0x311d, x86_l_311d);
x86_l_2e3e:
	/* 0x2e3e: cmp    WORD PTR [rbx+0x196],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1743756722176ULL);
x86_l_2e46:
	/* 0x2e46: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e46, 0x3802, x86_l_3802);
x86_l_2e4c:
	/* 0x2e4c: mov    ecx,DWORD PTR [rbx+0x190] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 400ULL);
x86_l_2e52:
	/* 0x2e52: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2e56:
	/* 0x2e56: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e5a:
	/* 0x2e5a: cmp    WORD PTR [rbx+0x194],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1735166787584ULL);
x86_l_2e62:
	/* 0x2e62: je     2e84 <generic_sleepable_preload+0x2e84> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e62, 0x2e84, x86_l_2e84);
x86_l_2e64:
	/* 0x2e64: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2e67:
	/* 0x2e67: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2e6c:
	/* 0x2e6c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2e71:
	/* 0x2e71: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e75:
	/* 0x2e75: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2e7a:
	/* 0x2e7a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e7c:
	/* 0x2e7c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2e7e:
	/* 0x2e7e: js     37fa <generic_sleepable_preload+0x37fa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e7e, 0x37fa, x86_l_37fa);
x86_l_2e84:
	/* 0x2e84: cmp    WORD PTR [rbx+0x19e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1778116460544ULL);
x86_l_2e8c:
	/* 0x2e8c: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e8c, 0x3802, x86_l_3802);
x86_l_2e92:
	/* 0x2e92: mov    ecx,DWORD PTR [rbx+0x198] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 408ULL);
x86_l_2e98:
	/* 0x2e98: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2e9c:
	/* 0x2e9c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ea0:
	/* 0x2ea0: cmp    WORD PTR [rbx+0x19c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1769526525952ULL);
x86_l_2ea8:
	/* 0x2ea8: je     2eca <generic_sleepable_preload+0x2eca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ea8, 0x2eca, x86_l_2eca);
x86_l_2eaa:
	/* 0x2eaa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ead:
	/* 0x2ead: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2eb2:
	/* 0x2eb2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2eb7:
	/* 0x2eb7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ebb:
	/* 0x2ebb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2ec0:
	/* 0x2ec0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ec2:
	/* 0x2ec2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2ec4:
	/* 0x2ec4: js     395a <generic_sleepable_preload+0x395a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ec4, 0x395a, x86_l_395a);
x86_l_2eca:
	/* 0x2eca: cmp    WORD PTR [rbx+0x1a6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1812476198912ULL);
x86_l_2ed2:
	/* 0x2ed2: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ed2, 0x3802, x86_l_3802);
x86_l_2ed8:
	/* 0x2ed8: mov    ecx,DWORD PTR [rbx+0x1a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 416ULL);
x86_l_2ede:
	/* 0x2ede: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2ee2:
	/* 0x2ee2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ee6:
	/* 0x2ee6: cmp    WORD PTR [rbx+0x1a4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1803886264320ULL);
x86_l_2eee:
	/* 0x2eee: je     2f10 <generic_sleepable_preload+0x2f10> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2eee, 0x2f10, x86_l_2f10);
x86_l_2ef0:
	/* 0x2ef0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ef3:
	/* 0x2ef3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2ef8:
	/* 0x2ef8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2efd:
	/* 0x2efd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f01:
	/* 0x2f01: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2f06:
	/* 0x2f06: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f08:
	/* 0x2f08: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2f0a:
	/* 0x2f0a: js     39d2 <generic_sleepable_preload+0x39d2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f0a, 0x39d2, x86_l_39d2);
x86_l_2f10:
	/* 0x2f10: cmp    WORD PTR [rbx+0x1ae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1846835937280ULL);
x86_l_2f18:
	/* 0x2f18: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f18, 0x3802, x86_l_3802);
x86_l_2f1e:
	/* 0x2f1e: mov    ecx,DWORD PTR [rbx+0x1a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 424ULL);
x86_l_2f24:
	/* 0x2f24: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2f28:
	/* 0x2f28: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f2c:
	/* 0x2f2c: cmp    WORD PTR [rbx+0x1ac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1838246002688ULL);
x86_l_2f34:
	/* 0x2f34: je     3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f34, 0x3802, x86_l_3802);
x86_l_2f3a:
	/* 0x2f3a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2f3d:
	/* 0x2f3d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2f42:
	/* 0x2f42: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2f47:
	/* 0x2f47: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f4b:
	/* 0x2f4b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2f50:
	/* 0x2f50: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x94ULL: X86_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f52:
	/* 0x2f52: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2f54:
	/* 0x2f54: jns    3802 <generic_sleepable_preload+0x3802> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f54, 0x3802, x86_l_3802);
x86_l_2f5a:
	/* 0x2f5a: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_2f60:
	/* 0x2f60: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x2f60, 0x3800, x86_l_3800);
x86_l_2f65:
	/* 0x2f65: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_2f6b:
	/* 0x2f6b: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x2f6b, 0x3800, x86_l_3800);
x86_l_2f70:
	/* 0x2f70: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_2f76:
	/* 0x2f76: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x2f76, 0x3800, x86_l_3800);
x86_l_2f7b:
	/* 0x2f7b: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2f81:
	/* 0x2f81: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x2f81, 0x312e, x86_l_312e);
x86_l_2f86:
	/* 0x2f86: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2f8c:
	/* 0x2f8c: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x2f8c, 0x31f7, x86_l_31f7);
x86_l_2f91:
	/* 0x2f91: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2f97:
	/* 0x2f97: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x2f97, 0x32bd, x86_l_32bd);
x86_l_2f9c:
	/* 0x2f9c: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2fa2:
	/* 0x2fa2: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x2fa2, 0x3383, x86_l_3383);
x86_l_2fa7:
	/* 0x2fa7: mov    ebp,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 3ULL);
x86_l_2fac:
	/* 0x2fac: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x2fac, 0x3448, x86_l_3448);
x86_l_2fb1:
	/* 0x2fb1: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2fb7:
	/* 0x2fb7: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x2fb7, 0x3500, x86_l_3500);
x86_l_2fbc:
	/* 0x2fbc: mov    ebp,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 3ULL);
x86_l_2fc1:
	/* 0x2fc1: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x2fc1, 0x35c2, x86_l_35c2);
x86_l_2fc6:
	/* 0x2fc6: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2fcc:
	/* 0x2fcc: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x2fcc, 0x367a, x86_l_367a);
x86_l_2fd1:
	/* 0x2fd1: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2fd7:
	/* 0x2fd7: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x2fd7, 0x373d, x86_l_373d);
x86_l_2fdc:
	/* 0x2fdc: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_2fe2:
	/* 0x2fe2: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x2fe2, 0x3800, x86_l_3800);
x86_l_2fe7:
	/* 0x2fe7: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_2fed:
	/* 0x2fed: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x2fed, 0x312e, x86_l_312e);
x86_l_2ff2:
	/* 0x2ff2: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_2ff8:
	/* 0x2ff8: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x2ff8, 0x31f7, x86_l_31f7);
x86_l_2ffd:
	/* 0x2ffd: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_3003:
	/* 0x3003: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x3003, 0x32bd, x86_l_32bd);
x86_l_3008:
	/* 0x3008: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_300e:
	/* 0x300e: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x300e, 0x3383, x86_l_3383);
x86_l_3013:
	/* 0x3013: mov    ebp,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4ULL);
x86_l_3018:
	/* 0x3018: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x3018, 0x3448, x86_l_3448);
x86_l_301d:
	/* 0x301d: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_3023:
	/* 0x3023: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x3023, 0x3500, x86_l_3500);
x86_l_3028:
	/* 0x3028: mov    ebp,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4ULL);
x86_l_302d:
	/* 0x302d: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x302d, 0x35c2, x86_l_35c2);
x86_l_3032:
	/* 0x3032: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_3038:
	/* 0x3038: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x3038, 0x367a, x86_l_367a);
x86_l_303d:
	/* 0x303d: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_3043:
	/* 0x3043: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x3043, 0x373d, x86_l_373d);
x86_l_3048:
	/* 0x3048: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_304e:
	/* 0x304e: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x304e, 0x3800, x86_l_3800);
x86_l_3053:
	/* 0x3053: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_3059:
	/* 0x3059: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x3059, 0x312e, x86_l_312e);
x86_l_305e:
	/* 0x305e: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_3064:
	/* 0x3064: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x3064, 0x31f7, x86_l_31f7);
x86_l_3069:
	/* 0x3069: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_306f:
	/* 0x306f: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x306f, 0x32bd, x86_l_32bd);
x86_l_3074:
	/* 0x3074: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_307a:
	/* 0x307a: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x307a, 0x3383, x86_l_3383);
x86_l_307f:
	/* 0x307f: mov    ebp,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 5ULL);
x86_l_3084:
	/* 0x3084: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x3084, 0x3448, x86_l_3448);
x86_l_3089:
	/* 0x3089: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_308f:
	/* 0x308f: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x308f, 0x3500, x86_l_3500);
x86_l_3094:
	/* 0x3094: mov    ebp,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 5ULL);
x86_l_3099:
	/* 0x3099: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x3099, 0x35c2, x86_l_35c2);
x86_l_309e:
	/* 0x309e: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_30a4:
	/* 0x30a4: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x30a4, 0x367a, x86_l_367a);
x86_l_30a9:
	/* 0x30a9: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_30af:
	/* 0x30af: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x30af, 0x373d, x86_l_373d);
x86_l_30b4:
	/* 0x30b4: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_30ba:
	/* 0x30ba: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x30ba, 0x3800, x86_l_3800);
x86_l_30bf:
	/* 0x30bf: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_30c5:
	/* 0x30c5: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x30c5, 0x312e, x86_l_312e);
x86_l_30c7:
	/* 0x30c7: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_30cd:
	/* 0x30cd: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x30cd, 0x31f7, x86_l_31f7);
x86_l_30d2:
	/* 0x30d2: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_30d8:
	/* 0x30d8: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x30d8, 0x32bd, x86_l_32bd);
x86_l_30dd:
	/* 0x30dd: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_30e3:
	/* 0x30e3: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x30e3, 0x3383, x86_l_3383);
x86_l_30e8:
	/* 0x30e8: mov    ebp,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_30ed:
	/* 0x30ed: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x30ed, 0x3448, x86_l_3448);
x86_l_30f2:
	/* 0x30f2: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_30f8:
	/* 0x30f8: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x30f8, 0x3500, x86_l_3500);
x86_l_30fd:
	/* 0x30fd: mov    ebp,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_3102:
	/* 0x3102: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x3102, 0x35c2, x86_l_35c2);
x86_l_3107:
	/* 0x3107: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_310d:
	/* 0x310d: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x310d, 0x367a, x86_l_367a);
x86_l_3112:
	/* 0x3112: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_3118:
	/* 0x3118: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x3118, 0x373d, x86_l_373d);
x86_l_311d:
	/* 0x311d: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_3123:
	/* 0x3123: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x3123, 0x3800, x86_l_3800);
x86_l_3128:
	/* 0x3128: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_312e:
	/* 0x312e: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3130:
	/* 0x3130: mov    r15d,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3134:
	/* 0x3134: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3139:
	/* 0x3139: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_313e:
	/* 0x313e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3143:
	/* 0x3143: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3148:
	/* 0x3148: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_314b:
	/* 0x314b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_314d:
	/* 0x314d: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3151:
	/* 0x3151: jne    ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3151, 0xed, x86_l_ed);
x86_l_3157:
	/* 0x3157: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_315c:
	/* 0x315c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3161:
	/* 0x3161: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_3166:
	/* 0x3166: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3168:
	/* 0x3168: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_316d:
	/* 0x316d: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3174:
	/* 0x3174: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_317b:
	/* 0x317b: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_317e:
	/* 0x317e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3183:
	/* 0x3183: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3185:
	/* 0x3185: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3188:
	/* 0x3188: je     ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3188, 0xed, x86_l_ed);
x86_l_318e:
	/* 0x318e: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3191:
	/* 0x3191: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_3198:
	/* 0x3198: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_319a:
	/* 0x319a: mov    r15d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RBP, X86_WIDTH_32);
x86_l_319d:
	/* 0x319d: mov    ebp,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_32);
x86_l_31a0:
	/* 0x31a0: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31a5:
	/* 0x31a5: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_31aa:
	/* 0x31aa: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_31ad:
	/* 0x31ad: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_31b0:
	/* 0x31b0: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31b2:
	/* 0x31b2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31b4:
	/* 0x31b4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_31b9:
	/* 0x31b9: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_31bc:
	/* 0x31bc: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_31bf:
	/* 0x31bf: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31c1:
	/* 0x31c1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_31c4:
	/* 0x31c4: je     ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c4, 0xed, x86_l_ed);
x86_l_31ca:
	/* 0x31ca: test   r15b,r15b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8);
x86_l_31cd:
	/* 0x31cd: je     35b6 <generic_sleepable_preload+0x35b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31cd, 0x35b6, x86_l_35b6);
x86_l_31d3:
	/* 0x31d3: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_31d6:
	/* 0x31d6: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_31da:
	/* 0x31da: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_31df:
	/* 0x31df: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_31e2:
	/* 0x31e2: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_31e7:
	/* 0x31e7: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31ec:
	/* 0x31ec: jmp    359f <generic_sleepable_preload+0x359f> */
	X86_SIM_X86_JMP(0x31ec, 0x359f, x86_l_359f);
x86_l_31f1:
	/* 0x31f1: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_31f7:
	/* 0x31f7: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31f9:
	/* 0x31f9: mov    r15d,DWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31fd:
	/* 0x31fd: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3202:
	/* 0x3202: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3207:
	/* 0x3207: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_320c:
	/* 0x320c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3211:
	/* 0x3211: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_3214:
	/* 0x3214: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3216:
	/* 0x3216: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_321a:
	/* 0x321a: jne    fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x321a, 0xfb, x86_l_fb);
x86_l_3220:
	/* 0x3220: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3225:
	/* 0x3225: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_322a:
	/* 0x322a: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_322f:
	/* 0x322f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3231:
	/* 0x3231: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3236:
	/* 0x3236: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_323d:
	/* 0x323d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_3244:
	/* 0x3244: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_3247:
	/* 0x3247: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_324c:
	/* 0x324c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_324e:
	/* 0x324e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3251:
	/* 0x3251: je     fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3251, 0xfb, x86_l_fb);
x86_l_3257:
	/* 0x3257: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_325a:
	/* 0x325a: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_3261:
	/* 0x3261: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3263:
	/* 0x3263: mov    r15d,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_32);
x86_l_3266:
	/* 0x3266: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_326b:
	/* 0x326b: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3270:
	/* 0x3270: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3273:
	/* 0x3273: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3276:
	/* 0x3276: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3278:
	/* 0x3278: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_327a:
	/* 0x327a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_327f:
	/* 0x327f: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3282:
	/* 0x3282: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3285:
	/* 0x3285: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3287:
	/* 0x3287: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_328a:
	/* 0x328a: je     fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x328a, 0xfb, x86_l_fb);
x86_l_3290:
	/* 0x3290: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
x86_l_3293:
	/* 0x3293: je     372f <generic_sleepable_preload+0x372f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3293, 0x372f, x86_l_372f);
x86_l_3299:
	/* 0x3299: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_329c:
	/* 0x329c: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_32a0:
	/* 0x32a0: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_32a5:
	/* 0x32a5: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_32a8:
	/* 0x32a8: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_32ad:
	/* 0x32ad: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32b2:
	/* 0x32b2: jmp    3716 <generic_sleepable_preload+0x3716> */
	X86_SIM_X86_JMP(0x32b2, 0x3716, x86_l_3716);
x86_l_32b7:
	/* 0x32b7: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_32bd:
	/* 0x32bd: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_32bf:
	/* 0x32bf: mov    r15d,DWORD PTR [rbx+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_32c3:
	/* 0x32c3: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32c8:
	/* 0x32c8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_32cd:
	/* 0x32cd: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_32d2:
	/* 0x32d2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_32d7:
	/* 0x32d7: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_32da:
	/* 0x32da: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_32dc:
	/* 0x32dc: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_32e0:
	/* 0x32e0: jne    109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32e0, 0x109, x86_l_109);
x86_l_32e6:
	/* 0x32e6: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32eb:
	/* 0x32eb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32f0:
	/* 0x32f0: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_32f5:
	/* 0x32f5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_32f7:
	/* 0x32f7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32fc:
	/* 0x32fc: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3303:
	/* 0x3303: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_330a:
	/* 0x330a: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_330d:
	/* 0x330d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3312:
	/* 0x3312: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3314:
	/* 0x3314: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3317:
	/* 0x3317: je     109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3317, 0x109, x86_l_109);
x86_l_331d:
	/* 0x331d: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3320:
	/* 0x3320: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_3327:
	/* 0x3327: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3329:
	/* 0x3329: mov    r15d,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_32);
x86_l_332c:
	/* 0x332c: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3331:
	/* 0x3331: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3336:
	/* 0x3336: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3339:
	/* 0x3339: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_333c:
	/* 0x333c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_333e:
	/* 0x333e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3340:
	/* 0x3340: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3345:
	/* 0x3345: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3348:
	/* 0x3348: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_334b:
	/* 0x334b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_334d:
	/* 0x334d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3350:
	/* 0x3350: je     109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3350, 0x109, x86_l_109);
x86_l_3356:
	/* 0x3356: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
x86_l_3359:
	/* 0x3359: je     37f2 <generic_sleepable_preload+0x37f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3359, 0x37f2, x86_l_37f2);
x86_l_335f:
	/* 0x335f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3362:
	/* 0x3362: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3366:
	/* 0x3366: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_336b:
	/* 0x336b: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_336e:
	/* 0x336e: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3373:
	/* 0x3373: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3378:
	/* 0x3378: jmp    37d9 <generic_sleepable_preload+0x37d9> */
	X86_SIM_X86_JMP(0x3378, 0x37d9, x86_l_37d9);
x86_l_337d:
	/* 0x337d: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_3383:
	/* 0x3383: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3385:
	/* 0x3385: mov    r15d,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3389:
	/* 0x3389: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_338e:
	/* 0x338e: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3393:
	/* 0x3393: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3398:
	/* 0x3398: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_339d:
	/* 0x339d: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_33a0:
	/* 0x33a0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33a2:
	/* 0x33a2: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_33a6:
	/* 0x33a6: jne    117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33a6, 0x117, x86_l_117);
x86_l_33ac:
	/* 0x33ac: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33b1:
	/* 0x33b1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_33b6:
	/* 0x33b6: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_33bb:
	/* 0x33bb: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33bd:
	/* 0x33bd: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33c2:
	/* 0x33c2: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33c9:
	/* 0x33c9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_33d0:
	/* 0x33d0: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_33d3:
	/* 0x33d3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_33d8:
	/* 0x33d8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33da:
	/* 0x33da: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_33dd:
	/* 0x33dd: je     117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33dd, 0x117, x86_l_117);
x86_l_33e3:
	/* 0x33e3: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_33e6:
	/* 0x33e6: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_33ed:
	/* 0x33ed: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_33ef:
	/* 0x33ef: mov    r15d,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_32);
x86_l_33f2:
	/* 0x33f2: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33f7:
	/* 0x33f7: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_33fc:
	/* 0x33fc: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_33ff:
	/* 0x33ff: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3402:
	/* 0x3402: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3404:
	/* 0x3404: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3406:
	/* 0x3406: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_340b:
	/* 0x340b: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_340e:
	/* 0x340e: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3411:
	/* 0x3411: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3413:
	/* 0x3413: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3416:
	/* 0x3416: je     117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3416, 0x117, x86_l_117);
x86_l_341c:
	/* 0x341c: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
x86_l_341f:
	/* 0x341f: je     38b5 <generic_sleepable_preload+0x38b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x341f, 0x38b5, x86_l_38b5);
x86_l_3425:
	/* 0x3425: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3428:
	/* 0x3428: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_342c:
	/* 0x342c: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_3431:
	/* 0x3431: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_3434:
	/* 0x3434: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3439:
	/* 0x3439: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_343e:
	/* 0x343e: jmp    389c <generic_sleepable_preload+0x389c> */
	X86_SIM_X86_JMP(0x343e, 0x389c, x86_l_389c);
x86_l_3443:
	/* 0x3443: mov    ebp,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 7ULL);
x86_l_3448:
	/* 0x3448: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_344b:
	/* 0x344b: mov    ebx,DWORD PTR [rbx+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_344e:
	/* 0x344e: lea    rdi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3453:
	/* 0x3453: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3458:
	/* 0x3458: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_345d:
	/* 0x345d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3462:
	/* 0x3462: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_3465:
	/* 0x3465: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3467:
	/* 0x3467: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_346a:
	/* 0x346a: jne    125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x346a, 0x125, x86_l_125);
x86_l_3470:
	/* 0x3470: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3475:
	/* 0x3475: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_347a:
	/* 0x347a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_347c:
	/* 0x347c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3481:
	/* 0x3481: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3488:
	/* 0x3488: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_348f:
	/* 0x348f: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_3492:
	/* 0x3492: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3497:
	/* 0x3497: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3499:
	/* 0x3499: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_349c:
	/* 0x349c: je     125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_E, 0x349c, 0x125, x86_l_125);
x86_l_34a2:
	/* 0x34a2: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_34a5:
	/* 0x34a5: mov    r14,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_34ac:
	/* 0x34ac: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_34ae:
	/* 0x34ae: lea    r15,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_34b3:
	/* 0x34b3: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_34b8:
	/* 0x34b8: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_34bb:
	/* 0x34bb: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_34be:
	/* 0x34be: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_34c0:
	/* 0x34c0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34c2:
	/* 0x34c2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_34c7:
	/* 0x34c7: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_34ca:
	/* 0x34ca: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_34cd:
	/* 0x34cd: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34cf:
	/* 0x34cf: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_34d2:
	/* 0x34d2: je     125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34d2, 0x125, x86_l_125);
x86_l_34d8:
	/* 0x34d8: test   r12b,r12b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8);
x86_l_34db:
	/* 0x34db: je     366d <generic_sleepable_preload+0x366d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34db, 0x366d, x86_l_366d);
x86_l_34e1:
	/* 0x34e1: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_34e4:
	/* 0x34e4: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_34e8:
	/* 0x34e8: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_34ed:
	/* 0x34ed: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_34f0:
	/* 0x34f0: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_34f5:
	/* 0x34f5: jmp    3652 <generic_sleepable_preload+0x3652> */
	X86_SIM_X86_JMP(0x34f5, 0x3652, x86_l_3652);
x86_l_34fa:
	/* 0x34fa: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_3500:
	/* 0x3500: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3502:
	/* 0x3502: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3506:
	/* 0x3506: jne    ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3506, 0xed, x86_l_ed);
x86_l_350c:
	/* 0x350c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3510:
	/* 0x3510: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3515:
	/* 0x3515: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_351a:
	/* 0x351a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_351c:
	/* 0x351c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3521:
	/* 0x3521: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3529:
	/* 0x3529: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_3530:
	/* 0x3530: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3535:
	/* 0x3535: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_353a:
	/* 0x353a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_353c:
	/* 0x353c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_353f:
	/* 0x353f: je     ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x353f, 0xed, x86_l_ed);
x86_l_3545:
	/* 0x3545: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3548:
	/* 0x3548: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_354f:
	/* 0x354f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3551:
	/* 0x3551: mov    r15d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RBP, X86_WIDTH_32);
x86_l_3554:
	/* 0x3554: mov    ebp,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_32);
x86_l_3557:
	/* 0x3557: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_355c:
	/* 0x355c: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3561:
	/* 0x3561: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3564:
	/* 0x3564: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3567:
	/* 0x3567: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3569:
	/* 0x3569: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_356b:
	/* 0x356b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3570:
	/* 0x3570: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3573:
	/* 0x3573: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3576:
	/* 0x3576: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3578:
	/* 0x3578: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_357b:
	/* 0x357b: je     ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x357b, 0xed, x86_l_ed);
x86_l_3581:
	/* 0x3581: test   r15b,r15b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8);
x86_l_3584:
	/* 0x3584: je     35b6 <generic_sleepable_preload+0x35b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3584, 0x35b6, x86_l_35b6);
x86_l_3586:
	/* 0x3586: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3589:
	/* 0x3589: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_358d:
	/* 0x358d: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_3592:
	/* 0x3592: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_3595:
	/* 0x3595: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_359a:
	/* 0x359a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_359f:
	/* 0x359f: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_35a4:
	/* 0x35a4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_35a6:
	/* 0x35a6: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_35a9:
	/* 0x35a9: mov    rax,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_64);
x86_l_35ac:
	/* 0x35ac: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_35af:
	/* 0x35af: jns    35b6 <generic_sleepable_preload+0x35b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35af, 0x35b6, x86_l_35b6);
x86_l_35b1:
	/* 0x35b1: mov    ebp,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4294967295ULL);
x86_l_35b6:
	/* 0x35b6: mov    DWORD PTR [rax],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35b8:
	/* 0x35b8: jmp    ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JMP(0x35b8, 0xed, x86_l_ed);
x86_l_35bd:
	/* 0x35bd: mov    ebp,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 7ULL);
x86_l_35c2:
	/* 0x35c2: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_35c5:
	/* 0x35c5: cmp    r14d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 6ULL);
x86_l_35c9:
	/* 0x35c9: jne    125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35c9, 0x125, x86_l_125);
x86_l_35cf:
	/* 0x35cf: mov    rbx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35d3:
	/* 0x35d3: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_35d8:
	/* 0x35d8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_35da:
	/* 0x35da: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35df:
	/* 0x35df: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_35e7:
	/* 0x35e7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_35ee:
	/* 0x35ee: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35f3:
	/* 0x35f3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_35f8:
	/* 0x35f8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_35fa:
	/* 0x35fa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_35fd:
	/* 0x35fd: je     125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35fd, 0x125, x86_l_125);
x86_l_3603:
	/* 0x3603: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3606:
	/* 0x3606: mov    r14,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_360d:
	/* 0x360d: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_360f:
	/* 0x360f: lea    r15,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3614:
	/* 0x3614: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3619:
	/* 0x3619: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_361c:
	/* 0x361c: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_361f:
	/* 0x361f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3621:
	/* 0x3621: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3623:
	/* 0x3623: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3628:
	/* 0x3628: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_362b:
	/* 0x362b: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_362e:
	/* 0x362e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3630:
	/* 0x3630: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3633:
	/* 0x3633: je     125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3633, 0x125, x86_l_125);
x86_l_3639:
	/* 0x3639: test   r12b,r12b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8);
x86_l_363c:
	/* 0x363c: je     366d <generic_sleepable_preload+0x366d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x363c, 0x366d, x86_l_366d);
x86_l_363e:
	/* 0x363e: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3641:
	/* 0x3641: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3645:
	/* 0x3645: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_364a:
	/* 0x364a: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_364d:
	/* 0x364d: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3652:
	/* 0x3652: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_3657:
	/* 0x3657: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_365a:
	/* 0x365a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_365c:
	/* 0x365c: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_365f:
	/* 0x365f: mov    rax,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R14, X86_WIDTH_64);
x86_l_3662:
	/* 0x3662: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3665:
	/* 0x3665: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_366a:
	/* 0x366a: cmovs  ebp,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RBP, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_366d:
	/* 0x366d: mov    DWORD PTR [rax],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_366f:
	/* 0x366f: jmp    125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JMP(0x366f, 0x125, x86_l_125);
x86_l_3674:
	/* 0x3674: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_367a:
	/* 0x367a: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_367c:
	/* 0x367c: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3680:
	/* 0x3680: jne    fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3680, 0xfb, x86_l_fb);
x86_l_3686:
	/* 0x3686: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_368a:
	/* 0x368a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_368f:
	/* 0x368f: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_3694:
	/* 0x3694: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3696:
	/* 0x3696: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_369b:
	/* 0x369b: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_36a3:
	/* 0x36a3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_36aa:
	/* 0x36aa: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36af:
	/* 0x36af: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_36b4:
	/* 0x36b4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36b6:
	/* 0x36b6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_36b9:
	/* 0x36b9: je     fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36b9, 0xfb, x86_l_fb);
x86_l_36bf:
	/* 0x36bf: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_36c2:
	/* 0x36c2: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_36c9:
	/* 0x36c9: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_36cb:
	/* 0x36cb: mov    r15d,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_32);
x86_l_36ce:
	/* 0x36ce: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_36d3:
	/* 0x36d3: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_36d8:
	/* 0x36d8: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_36db:
	/* 0x36db: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_36de:
	/* 0x36de: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_36e0:
	/* 0x36e0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36e2:
	/* 0x36e2: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_36e7:
	/* 0x36e7: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_36ea:
	/* 0x36ea: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_36ed:
	/* 0x36ed: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36ef:
	/* 0x36ef: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_36f2:
	/* 0x36f2: je     fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36f2, 0xfb, x86_l_fb);
x86_l_36f8:
	/* 0x36f8: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
x86_l_36fb:
	/* 0x36fb: je     372f <generic_sleepable_preload+0x372f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36fb, 0x372f, x86_l_372f);
x86_l_36fd:
	/* 0x36fd: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3700:
	/* 0x3700: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3704:
	/* 0x3704: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_3709:
	/* 0x3709: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_370c:
	/* 0x370c: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3711:
	/* 0x3711: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3716:
	/* 0x3716: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_371b:
	/* 0x371b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_371d:
	/* 0x371d: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_3720:
	/* 0x3720: mov    rax,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_64);
x86_l_3723:
	/* 0x3723: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3726:
	/* 0x3726: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_372b:
	/* 0x372b: cmovs  r15d,ecx */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_372f:
	/* 0x372f: mov    DWORD PTR [rax],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3732:
	/* 0x3732: jmp    fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JMP(0x3732, 0xfb, x86_l_fb);
x86_l_3737:
	/* 0x3737: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_373d:
	/* 0x373d: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_373f:
	/* 0x373f: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3743:
	/* 0x3743: jne    109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3743, 0x109, x86_l_109);
x86_l_3749:
	/* 0x3749: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_374d:
	/* 0x374d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3752:
	/* 0x3752: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_3757:
	/* 0x3757: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3759:
	/* 0x3759: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_375e:
	/* 0x375e: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3766:
	/* 0x3766: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_376d:
	/* 0x376d: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3772:
	/* 0x3772: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3777:
	/* 0x3777: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3779:
	/* 0x3779: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_377c:
	/* 0x377c: je     109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_E, 0x377c, 0x109, x86_l_109);
x86_l_3782:
	/* 0x3782: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3785:
	/* 0x3785: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_378c:
	/* 0x378c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_378e:
	/* 0x378e: mov    r15d,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_32);
x86_l_3791:
	/* 0x3791: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3796:
	/* 0x3796: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_379b:
	/* 0x379b: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_379e:
	/* 0x379e: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_37a1:
	/* 0x37a1: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_37a3:
	/* 0x37a3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_37a5:
	/* 0x37a5: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_37aa:
	/* 0x37aa: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_37ad:
	/* 0x37ad: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_37b0:
	/* 0x37b0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_37b2:
	/* 0x37b2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_37b5:
	/* 0x37b5: je     109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37b5, 0x109, x86_l_109);
x86_l_37bb:
	/* 0x37bb: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
x86_l_37be:
	/* 0x37be: je     37f2 <generic_sleepable_preload+0x37f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37be, 0x37f2, x86_l_37f2);
x86_l_37c0:
	/* 0x37c0: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_37c3:
	/* 0x37c3: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_37c7:
	/* 0x37c7: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_37cc:
	/* 0x37cc: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_37cf:
	/* 0x37cf: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_37d4:
	/* 0x37d4: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_37d9:
	/* 0x37d9: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_37de:
	/* 0x37de: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_37e0:
	/* 0x37e0: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_37e3:
	/* 0x37e3: mov    rax,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_64);
x86_l_37e6:
	/* 0x37e6: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_37e9:
	/* 0x37e9: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_37ee:
	/* 0x37ee: cmovs  r15d,ecx */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_37f2:
	/* 0x37f2: mov    DWORD PTR [rax],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37f5:
	/* 0x37f5: jmp    109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JMP(0x37f5, 0x109, x86_l_109);
x86_l_37fa:
	/* 0x37fa: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_3800:
	/* 0x3800: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3802:
	/* 0x3802: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3806:
	/* 0x3806: jne    117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3806, 0x117, x86_l_117);
x86_l_380c:
	/* 0x380c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3810:
	/* 0x3810: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3815:
	/* 0x3815: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_381a:
	/* 0x381a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_381c:
	/* 0x381c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3821:
	/* 0x3821: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3829:
	/* 0x3829: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_3830:
	/* 0x3830: lea    rsi,[rsp+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3835:
	/* 0x3835: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_383a:
	/* 0x383a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_383c:
	/* 0x383c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_383f:
	/* 0x383f: je     117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_E, 0x383f, 0x117, x86_l_117);
x86_l_3845:
	/* 0x3845: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3848:
	/* 0x3848: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_384f:
	/* 0x384f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3851:
	/* 0x3851: mov    r15d,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R13, X86_WIDTH_32);
x86_l_3854:
	/* 0x3854: lea    r13,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3859:
	/* 0x3859: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_385e:
	/* 0x385e: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3861:
	/* 0x3861: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3864:
	/* 0x3864: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3866:
	/* 0x3866: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3868:
	/* 0x3868: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_386d:
	/* 0x386d: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_3870:
	/* 0x3870: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_3873:
	/* 0x3873: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3875:
	/* 0x3875: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3878:
	/* 0x3878: je     117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3878, 0x117, x86_l_117);
x86_l_387e:
	/* 0x387e: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
x86_l_3881:
	/* 0x3881: je     38b5 <generic_sleepable_preload+0x38b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3881, 0x38b5, x86_l_38b5);
x86_l_3883:
	/* 0x3883: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3886:
	/* 0x3886: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_388a:
	/* 0x388a: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_388f:
	/* 0x388f: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_3892:
	/* 0x3892: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3897:
	/* 0x3897: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_389c:
	/* 0x389c: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_38a1:
	/* 0x38a1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x72ULL: X86_SIM_BPF_CALL_bpf_probe_read_user_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_38a3:
	/* 0x38a3: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_38a6:
	/* 0x38a6: mov    rax,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_64);
x86_l_38a9:
	/* 0x38a9: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_38ac:
	/* 0x38ac: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_38b1:
	/* 0x38b1: cmovs  r15d,ecx */
	X86_SIM_L_EXEC_CMOV(X86_R15, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_38b5:
	/* 0x38b5: mov    DWORD PTR [rax],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38b8:
	/* 0x38b8: jmp    117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JMP(0x38b8, 0x117, x86_l_117);
x86_l_38bd:
	/* 0x38bd: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_38bf:
	/* 0x38bf: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_38c5:
	/* 0x38c5: jmp    3130 <generic_sleepable_preload+0x3130> */
	X86_SIM_X86_JMP(0x38c5, 0x3130, x86_l_3130);
x86_l_38ca:
	/* 0x38ca: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_38cc:
	/* 0x38cc: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_38d2:
	/* 0x38d2: jmp    31f9 <generic_sleepable_preload+0x31f9> */
	X86_SIM_X86_JMP(0x38d2, 0x31f9, x86_l_31f9);
x86_l_38d7:
	/* 0x38d7: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_38d9:
	/* 0x38d9: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_38df:
	/* 0x38df: jmp    32bf <generic_sleepable_preload+0x32bf> */
	X86_SIM_X86_JMP(0x38df, 0x32bf, x86_l_32bf);
x86_l_38e4:
	/* 0x38e4: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_38e6:
	/* 0x38e6: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_38ec:
	/* 0x38ec: jmp    3385 <generic_sleepable_preload+0x3385> */
	X86_SIM_X86_JMP(0x38ec, 0x3385, x86_l_3385);
x86_l_38f1:
	/* 0x38f1: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_38f4:
	/* 0x38f4: mov    ebp,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 8ULL);
x86_l_38f9:
	/* 0x38f9: jmp    344b <generic_sleepable_preload+0x344b> */
	X86_SIM_X86_JMP(0x38f9, 0x344b, x86_l_344b);
x86_l_38fe:
	/* 0x38fe: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3900:
	/* 0x3900: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_3906:
	/* 0x3906: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_390a:
	/* 0x390a: jne    ed <generic_sleepable_preload+0xed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x390a, 0xed, x86_l_ed);
x86_l_3910:
	/* 0x3910: jmp    350c <generic_sleepable_preload+0x350c> */
	X86_SIM_X86_JMP(0x3910, 0x350c, x86_l_350c);
x86_l_3915:
	/* 0x3915: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3918:
	/* 0x3918: mov    ebp,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 8ULL);
x86_l_391d:
	/* 0x391d: cmp    r14d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 6ULL);
x86_l_3921:
	/* 0x3921: jne    125 <generic_sleepable_preload+0x125> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3921, 0x125, x86_l_125);
x86_l_3927:
	/* 0x3927: jmp    35cf <generic_sleepable_preload+0x35cf> */
	X86_SIM_X86_JMP(0x3927, 0x35cf, x86_l_35cf);
x86_l_392c:
	/* 0x392c: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_392e:
	/* 0x392e: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_3934:
	/* 0x3934: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3938:
	/* 0x3938: jne    fb <generic_sleepable_preload+0xfb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3938, 0xfb, x86_l_fb);
x86_l_393e:
	/* 0x393e: jmp    3686 <generic_sleepable_preload+0x3686> */
	X86_SIM_X86_JMP(0x393e, 0x3686, x86_l_3686);
x86_l_3943:
	/* 0x3943: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3945:
	/* 0x3945: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_394b:
	/* 0x394b: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_394f:
	/* 0x394f: jne    109 <generic_sleepable_preload+0x109> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x394f, 0x109, x86_l_109);
x86_l_3955:
	/* 0x3955: jmp    3749 <generic_sleepable_preload+0x3749> */
	X86_SIM_X86_JMP(0x3955, 0x3749, x86_l_3749);
x86_l_395a:
	/* 0x395a: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_395c:
	/* 0x395c: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_3962:
	/* 0x3962: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_3966:
	/* 0x3966: jne    117 <generic_sleepable_preload+0x117> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3966, 0x117, x86_l_117);
x86_l_396c:
	/* 0x396c: jmp    380c <generic_sleepable_preload+0x380c> */
	X86_SIM_X86_JMP(0x396c, 0x380c, x86_l_380c);
x86_l_3971:
	/* 0x3971: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_3977:
	/* 0x3977: jmp    312e <generic_sleepable_preload+0x312e> */
	X86_SIM_X86_JMP(0x3977, 0x312e, x86_l_312e);
x86_l_397c:
	/* 0x397c: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_3982:
	/* 0x3982: jmp    31f7 <generic_sleepable_preload+0x31f7> */
	X86_SIM_X86_JMP(0x3982, 0x31f7, x86_l_31f7);
x86_l_3987:
	/* 0x3987: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_398d:
	/* 0x398d: jmp    32bd <generic_sleepable_preload+0x32bd> */
	X86_SIM_X86_JMP(0x398d, 0x32bd, x86_l_32bd);
x86_l_3992:
	/* 0x3992: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_3998:
	/* 0x3998: jmp    3383 <generic_sleepable_preload+0x3383> */
	X86_SIM_X86_JMP(0x3998, 0x3383, x86_l_3383);
x86_l_399d:
	/* 0x399d: mov    ebp,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 9ULL);
x86_l_39a2:
	/* 0x39a2: jmp    3448 <generic_sleepable_preload+0x3448> */
	X86_SIM_X86_JMP(0x39a2, 0x3448, x86_l_3448);
x86_l_39a7:
	/* 0x39a7: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_39ad:
	/* 0x39ad: jmp    3500 <generic_sleepable_preload+0x3500> */
	X86_SIM_X86_JMP(0x39ad, 0x3500, x86_l_3500);
x86_l_39b2:
	/* 0x39b2: mov    ebp,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 9ULL);
x86_l_39b7:
	/* 0x39b7: jmp    35c2 <generic_sleepable_preload+0x35c2> */
	X86_SIM_X86_JMP(0x39b7, 0x35c2, x86_l_35c2);
x86_l_39bc:
	/* 0x39bc: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_39c2:
	/* 0x39c2: jmp    367a <generic_sleepable_preload+0x367a> */
	X86_SIM_X86_JMP(0x39c2, 0x367a, x86_l_367a);
x86_l_39c7:
	/* 0x39c7: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_39cd:
	/* 0x39cd: jmp    373d <generic_sleepable_preload+0x373d> */
	X86_SIM_X86_JMP(0x39cd, 0x373d, x86_l_373d);
x86_l_39d2:
	/* 0x39d2: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_39d8:
	/* 0x39d8: jmp    3800 <generic_sleepable_preload+0x3800> */
	X86_SIM_X86_JMP(0x39d8, 0x3800, x86_l_3800);
x86_l_39dd:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
