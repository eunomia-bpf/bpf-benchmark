#include <linux/bpf.h>
#include <stdint.h>
#include <stdio.h>
struct native_ctx { void *data, *data_end; };
static unsigned char packet[9];
int join_native(struct native_ctx *);
int join_x86_sim_xdp(struct xdp_md *);
int cmov_native(struct native_ctx *);
int cmov_x86_sim_xdp(struct xdp_md *);
int call_native(struct native_ctx *);
int call_x86_sim_xdp(struct xdp_md *);
int main(void) {
    int failures = 0;
    struct native_ctx native_ctx = {packet, packet+9};
    struct xdp_md ctx = {.data=(uintptr_t)packet, .data_end=(uintptr_t)(packet+9)};
    for (unsigned i=0; i<2; ++i) {
        packet[8] = i;
        { int native=join_native(&native_ctx), sim=join_x86_sim_xdp(&ctx);
           int expected=(i ? 17 : 42);
           printf("join input=%u native=%d simulator=%d expected=%d\n",i,native,sim,expected);
           failures += native != expected || sim != native; }
        { int native=cmov_native(&native_ctx), sim=cmov_x86_sim_xdp(&ctx);
           int expected=(i ? 17 : 42);
           printf("cmov input=%u native=%d simulator=%d expected=%d\n",i,native,sim,expected);
           failures += native != expected || sim != native; }
        { int native=call_native(&native_ctx), sim=call_x86_sim_xdp(&ctx);
           int expected=(i ? 14 : 6);
           printf("call input=%u native=%d simulator=%d expected=%d\n",i,native,sim,expected);
           failures += native != expected || sim != native; }
    }
    return failures != 0;
}
