#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int dispatch_orig(struct xdp_md *ctx) {
    unsigned char *data=(void *)(long)ctx->data;
    unsigned char *end=(void *)(long)ctx->data_end;
    if (data+9>end) return 0;
#ifdef CALL_FIXTURE
    return data[8] ? 14 : 6;
#else
    return data[8] ? 17 : 42;
#endif
}
char LICENSE[] SEC("license")="GPL";
