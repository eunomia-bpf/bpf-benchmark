#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

SEC("xdp")
int cmov_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    rcx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: lea    rax,[rdx+0x9] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 9ULL);
x86_l_b:
	/* 0xb: cmp    rax,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_e:
	/* 0xe: ja     34 <cmov_native+0x34> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe, 0x34, x86_l_34);
x86_l_10:
	/* 0x10: cmp    BYTE PTR [rdx+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_14:
	/* 0x14: lea    rax,[rip+0xd] */
	X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x28ULL);
x86_l_1b:
	/* 0x1b: lea    rcx,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_RCX, 0x2eULL);
x86_l_22:
	/* 0x22: cmovne rax,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RCX, X86_WIDTH_64, X86_CC_NE);
x86_l_26:
	/* 0x26: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x28ULL: goto x86_l_28;
			case 0x2eULL: goto x86_l_2e;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28:
	/* 0x28: mov    eax,0x2a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 42ULL);
x86_l_2d:
	/* 0x2d: ret */
	X86_SIM_X86_RET();
x86_l_2e:
	/* 0x2e: mov    eax,0x11 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_33:
	/* 0x33: ret */
	X86_SIM_X86_RET();
x86_l_34:
	/* 0x34: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_39:
	/* 0x39: ret */
	X86_SIM_X86_RET();
x86_l_3a:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
