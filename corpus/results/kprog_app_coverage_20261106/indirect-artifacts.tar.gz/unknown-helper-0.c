#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
void probe(void) { X86_SIM_L_DECLARE_STATE(); X86_SIM_BPF_CALL_ID(0ULL); }
