extern char CONFIG_ITER_NUM;
extern char config_map;
extern char heap_ro_zero;
extern char sleepable_preload;
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_ENABLE_STACK_DEEP 1
#include "../x86_sim_local_bpf.h"

SEC("xdp")
int tetragon_bpf_generic_uprobe_v511_generic_sleepable_preload_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH(X86_RBP);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH(X86_R15);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH(X86_R14);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_L_EXEC_PUSH(X86_R13);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_L_EXEC_PUSH(X86_R12);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH(X86_RBX);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    QWORD PTR [rsp+0x48],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_16:
	/* 0x16: mov    DWORD PTR [rsp+0xac],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_21:
	/* 0x21: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&config_map));
x86_l_28:
	/* 0x28: lea    rsi,[rsp+0xac] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_30:
	/* 0x30: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_35:
	/* 0x35: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_37:
	/* 0x37: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3a:
	/* 0x3a: je     4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a, 0x4d78, x86_l_4d78);
x86_l_40:
	/* 0x40: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_43:
	/* 0x43: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_4a:
	/* 0x4a: mov    rcx,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_4f:
	/* 0x4f: lea    rdx,[rcx+0x98] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_56:
	/* 0x56: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5b:
	/* 0x5b: lea    rdx,[rcx+0x80] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_62:
	/* 0x62: mov    QWORD PTR [rsp+0x70],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_67:
	/* 0x67: lea    rdx,[rcx+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6b:
	/* 0x6b: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_70:
	/* 0x70: lea    rdx,[rcx+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_74:
	/* 0x74: mov    QWORD PTR [rsp+0x30],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_79:
	/* 0x79: lea    rdx,[rcx+0x60] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_7d:
	/* 0x7d: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_82:
	/* 0x82: lea    rdx,[rcx+0x58] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_86:
	/* 0x86: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8b:
	/* 0x8b: lea    rdx,[rcx+0x50] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8f:
	/* 0x8f: mov    QWORD PTR [rsp+0x98],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_97:
	/* 0x97: lea    rdx,[rcx+0x48] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_9b:
	/* 0x9b: mov    QWORD PTR [rsp+0x28],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a0:
	/* 0xa0: lea    rdx,[rcx+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a4:
	/* 0xa4: mov    QWORD PTR [rsp+0x90],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_ac:
	/* 0xac: lea    rdx,[rcx+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_b0:
	/* 0xb0: mov    QWORD PTR [rsp+0x68],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_b5:
	/* 0xb5: lea    rdx,[rcx+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b9:
	/* 0xb9: mov    QWORD PTR [rsp+0x88],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_c1:
	/* 0xc1: lea    rdx,[rcx+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c5:
	/* 0xc5: mov    QWORD PTR [rsp+0x60],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_ca:
	/* 0xca: lea    rdx,[rcx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ce:
	/* 0xce: mov    QWORD PTR [rsp+0x80],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d6:
	/* 0xd6: lea    rdx,[rcx+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_da:
	/* 0xda: mov    QWORD PTR [rsp+0x58],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_df:
	/* 0xdf: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e2:
	/* 0xe2: lea    rax,[rcx+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e6:
	/* 0xe6: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_eb:
	/* 0xeb: lea    r14,[rcx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ef:
	/* 0xef: mov    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f4:
	/* 0xf4: je     f08 <generic_sleepable_preload+0xf08> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf4, 0xf08, x86_l_f08);
x86_l_fa:
	/* 0xfa: mov    QWORD PTR [rsp+0xb0],r14 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_102:
	/* 0x102: mov    rbx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R12, X86_WIDTH_64);
x86_l_105:
	/* 0x105: add    rbx,0xbe */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 190ULL);
x86_l_10c:
	/* 0x10c: xor    r14d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10f:
	/* 0x10f: jmp    129 <generic_sleepable_preload+0x129> */
	X86_SIM_X86_JMP(0x10f, 0x129, x86_l_129);
x86_l_111:
	/* 0x111: mov    DWORD PTR [rax],ebp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_113:
	/* 0x113: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_118:
	/* 0x118: inc    r14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_11b:
	/* 0x11b: add    rbx,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_11f:
	/* 0x11f: cmp    r14,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_64, 5ULL);
x86_l_123:
	/* 0x123: je     4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x123, 0x4d78, x86_l_4d78);
x86_l_129:
	/* 0x129: mov    eax,DWORD PTR [r12+r14*4+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 24ULL);
x86_l_12e:
	/* 0x12e: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_133:
	/* 0x133: je     118 <generic_sleepable_preload+0x118> */
	X86_SIM_X86_JCC(X86_CC_E, 0x133, 0x118, x86_l_118);
x86_l_135:
	/* 0x135: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_137:
	/* 0x137: js     16c <generic_sleepable_preload+0x16c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x137, 0x16c, x86_l_16c);
x86_l_139:
	/* 0x139: mov    eax,DWORD PTR [r12+r14*4+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 64ULL);
x86_l_13e:
	/* 0x13e: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_141:
	/* 0x141: jle    205 <generic_sleepable_preload+0x205> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x141, 0x205, x86_l_205);
x86_l_147:
	/* 0x147: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_14a:
	/* 0x14a: je     281 <generic_sleepable_preload+0x281> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14a, 0x281, x86_l_281);
x86_l_150:
	/* 0x150: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_153:
	/* 0x153: je     288 <generic_sleepable_preload+0x288> */
	X86_SIM_X86_JCC(X86_CC_E, 0x153, 0x288, x86_l_288);
x86_l_159:
	/* 0x159: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_15c:
	/* 0x15c: jne    29b <generic_sleepable_preload+0x29b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15c, 0x29b, x86_l_29b);
x86_l_162:
	/* 0x162: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_167:
	/* 0x167: jmp    294 <generic_sleepable_preload+0x294> */
	X86_SIM_X86_JMP(0x167, 0x294, x86_l_294);
x86_l_16c:
	/* 0x16c: movzx  eax,BYTE PTR [r12+r14*4+0x2c2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R14, 2, X86_WIDTH_8), 706ULL);
x86_l_175:
	/* 0x175: movzx  ecx,WORD PTR [r12+r14*4+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R14, 2, X86_WIDTH_16), 704ULL);
x86_l_17e:
	/* 0x17e: rorx   ecx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_184:
	/* 0x184: cmp    ecx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_187:
	/* 0x187: jle    1cf <generic_sleepable_preload+0x1cf> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x187, 0x1cf, x86_l_1cf);
x86_l_189:
	/* 0x189: cmp    ecx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 11ULL);
x86_l_18c:
	/* 0x18c: jle    21d <generic_sleepable_preload+0x21d> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x18c, 0x21d, x86_l_21d);
x86_l_192:
	/* 0x192: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_195:
	/* 0x195: jle    7c5 <generic_sleepable_preload+0x7c5> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x195, 0x7c5, x86_l_7c5);
x86_l_19b:
	/* 0x19b: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1a0:
	/* 0x1a0: cmp    ecx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 14ULL);
x86_l_1a3:
	/* 0x1a3: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a3, 0x7de, x86_l_7de);
x86_l_1a9:
	/* 0x1a9: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1ae:
	/* 0x1ae: cmp    ecx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_1b1:
	/* 0x1b1: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b1, 0x7de, x86_l_7de);
x86_l_1b7:
	/* 0x1b7: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_1bc:
	/* 0x1bc: cmp    ecx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 19ULL);
x86_l_1bf:
	/* 0x1bf: jne    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bf, 0x7f1, x86_l_7f1);
x86_l_1c5:
	/* 0x1c5: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ca:
	/* 0x1ca: jmp    7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JMP(0x1ca, 0x7de, x86_l_7de);
x86_l_1cf:
	/* 0x1cf: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_1d2:
	/* 0x1d2: jg     24f <generic_sleepable_preload+0x24f> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1d2, 0x24f, x86_l_24f);
x86_l_1d4:
	/* 0x1d4: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1d7:
	/* 0x1d7: jg     78c <generic_sleepable_preload+0x78c> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1d7, 0x78c, x86_l_78c);
x86_l_1dd:
	/* 0x1dd: mov    rdx,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1e2:
	/* 0x1e2: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1e4:
	/* 0x1e4: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e4, 0x7de, x86_l_7de);
x86_l_1ea:
	/* 0x1ea: mov    rdx,QWORD PTR [rsp+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1f2:
	/* 0x1f2: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_1f7:
	/* 0x1f7: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1fa:
	/* 0x1fa: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fa, 0x7de, x86_l_7de);
x86_l_200:
	/* 0x200: jmp    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JMP(0x200, 0x7f1, x86_l_7f1);
x86_l_205:
	/* 0x205: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_207:
	/* 0x207: je     28f <generic_sleepable_preload+0x28f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207, 0x28f, x86_l_28f);
x86_l_20d:
	/* 0x20d: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_210:
	/* 0x210: jne    29b <generic_sleepable_preload+0x29b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x210, 0x29b, x86_l_29b);
x86_l_216:
	/* 0x216: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21b:
	/* 0x21b: jmp    294 <generic_sleepable_preload+0x294> */
	X86_SIM_X86_JMP(0x21b, 0x294, x86_l_294);
x86_l_21d:
	/* 0x21d: cmp    ecx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_220:
	/* 0x220: jg     76e <generic_sleepable_preload+0x76e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x220, 0x76e, x86_l_76e);
x86_l_226:
	/* 0x226: mov    rdx,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_22e:
	/* 0x22e: cmp    ecx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_231:
	/* 0x231: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x231, 0x7de, x86_l_7de);
x86_l_237:
	/* 0x237: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23c:
	/* 0x23c: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_241:
	/* 0x241: cmp    ecx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 9ULL);
x86_l_244:
	/* 0x244: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244, 0x7de, x86_l_7de);
x86_l_24a:
	/* 0x24a: jmp    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JMP(0x24a, 0x7f1, x86_l_7f1);
x86_l_24f:
	/* 0x24f: cmp    ecx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_252:
	/* 0x252: jg     7a7 <generic_sleepable_preload+0x7a7> */
	X86_SIM_X86_JCC(X86_CC_G, 0x252, 0x7a7, x86_l_7a7);
x86_l_258:
	/* 0x258: mov    rdx,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_260:
	/* 0x260: cmp    ecx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_263:
	/* 0x263: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x263, 0x7de, x86_l_7de);
x86_l_269:
	/* 0x269: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_26e:
	/* 0x26e: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_273:
	/* 0x273: cmp    ecx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 5ULL);
x86_l_276:
	/* 0x276: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x276, 0x7de, x86_l_7de);
x86_l_27c:
	/* 0x27c: jmp    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JMP(0x27c, 0x7f1, x86_l_7f1);
x86_l_281:
	/* 0x281: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_286:
	/* 0x286: jmp    294 <generic_sleepable_preload+0x294> */
	X86_SIM_X86_JMP(0x286, 0x294, x86_l_294);
x86_l_288:
	/* 0x288: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28d:
	/* 0x28d: jmp    294 <generic_sleepable_preload+0x294> */
	X86_SIM_X86_JMP(0x28d, 0x294, x86_l_294);
x86_l_28f:
	/* 0x28f: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_294:
	/* 0x294: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_297:
	/* 0x297: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b:
	/* 0x29b: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_29e:
	/* 0x29e: mov    bpl,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_8, 1ULL);
x86_l_2a1:
	/* 0x2a1: cmp    WORD PTR [rbx-0x48],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743764471906304ULL);
x86_l_2a6:
	/* 0x2a6: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a6, 0xd2c, x86_l_d2c);
x86_l_2ac:
	/* 0x2ac: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_2b3:
	/* 0x2b3: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2b6:
	/* 0x2b6: mov    eax,DWORD PTR [rbx-0x4e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551538ULL);
x86_l_2b9:
	/* 0x2b9: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2bc:
	/* 0x2bc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c0:
	/* 0x2c0: movzx  eax,WORD PTR [rbx-0x4a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18446744073709551542ULL);
x86_l_2c4:
	/* 0x2c4: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_2c6:
	/* 0x2c6: je     50b <generic_sleepable_preload+0x50b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c6, 0x50b, x86_l_50b);
x86_l_2cc:
	/* 0x2cc: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_2cf:
	/* 0x2cf: je     2f1 <generic_sleepable_preload+0x2f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cf, 0x2f1, x86_l_2f1);
x86_l_2d1:
	/* 0x2d1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2d6:
	/* 0x2d6: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2db:
	/* 0x2db: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2de:
	/* 0x2de: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e2:
	/* 0x2e2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2e7:
	/* 0x2e7: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2e9:
	/* 0x2e9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2eb:
	/* 0x2eb: js     763 <generic_sleepable_preload+0x763> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2eb, 0x763, x86_l_763);
x86_l_2f1:
	/* 0x2f1: cmp    WORD PTR [rbx-0x40],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743798831644672ULL);
x86_l_2f6:
	/* 0x2f6: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f6, 0xd2c, x86_l_d2c);
x86_l_2fc:
	/* 0x2fc: mov    ecx,DWORD PTR [rbx-0x46] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551546ULL);
x86_l_2ff:
	/* 0x2ff: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_303:
	/* 0x303: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_307:
	/* 0x307: cmp    WORD PTR [rbx-0x42],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743790241710080ULL);
x86_l_30c:
	/* 0x30c: je     32e <generic_sleepable_preload+0x32e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30c, 0x32e, x86_l_32e);
x86_l_30e:
	/* 0x30e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_313:
	/* 0x313: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_318:
	/* 0x318: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_31b:
	/* 0x31b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31f:
	/* 0x31f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_324:
	/* 0x324: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_326:
	/* 0x326: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_328:
	/* 0x328: js     cca <generic_sleepable_preload+0xcca> */
	X86_SIM_X86_JCC(X86_CC_S, 0x328, 0xcca, x86_l_cca);
x86_l_32e:
	/* 0x32e: cmp    WORD PTR [rbx-0x38],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743833191383040ULL);
x86_l_333:
	/* 0x333: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x333, 0xd2c, x86_l_d2c);
x86_l_339:
	/* 0x339: mov    ecx,DWORD PTR [rbx-0x3e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551554ULL);
x86_l_33c:
	/* 0x33c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_340:
	/* 0x340: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_344:
	/* 0x344: cmp    WORD PTR [rbx-0x3a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743824601448448ULL);
x86_l_349:
	/* 0x349: je     36b <generic_sleepable_preload+0x36b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x349, 0x36b, x86_l_36b);
x86_l_34b:
	/* 0x34b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_350:
	/* 0x350: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_355:
	/* 0x355: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_358:
	/* 0x358: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35c:
	/* 0x35c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_361:
	/* 0x361: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_363:
	/* 0x363: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_365:
	/* 0x365: js     cdc <generic_sleepable_preload+0xcdc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x365, 0xcdc, x86_l_cdc);
x86_l_36b:
	/* 0x36b: cmp    WORD PTR [rbx-0x30],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743867551121408ULL);
x86_l_370:
	/* 0x370: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x370, 0xd2c, x86_l_d2c);
x86_l_376:
	/* 0x376: mov    ecx,DWORD PTR [rbx-0x36] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551562ULL);
x86_l_379:
	/* 0x379: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_37d:
	/* 0x37d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_381:
	/* 0x381: cmp    WORD PTR [rbx-0x32],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743858961186816ULL);
x86_l_386:
	/* 0x386: je     3a8 <generic_sleepable_preload+0x3a8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x386, 0x3a8, x86_l_3a8);
x86_l_388:
	/* 0x388: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_38d:
	/* 0x38d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_392:
	/* 0x392: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_395:
	/* 0x395: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_399:
	/* 0x399: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_39e:
	/* 0x39e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3a0:
	/* 0x3a0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3a2:
	/* 0x3a2: js     cee <generic_sleepable_preload+0xcee> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3a2, 0xcee, x86_l_cee);
x86_l_3a8:
	/* 0x3a8: cmp    WORD PTR [rbx-0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743901910859776ULL);
x86_l_3ad:
	/* 0x3ad: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ad, 0xd2c, x86_l_d2c);
x86_l_3b3:
	/* 0x3b3: mov    ecx,DWORD PTR [rbx-0x2e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551570ULL);
x86_l_3b6:
	/* 0x3b6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3ba:
	/* 0x3ba: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3be:
	/* 0x3be: cmp    WORD PTR [rbx-0x2a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743893320925184ULL);
x86_l_3c3:
	/* 0x3c3: je     3e5 <generic_sleepable_preload+0x3e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3c3, 0x3e5, x86_l_3e5);
x86_l_3c5:
	/* 0x3c5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3ca:
	/* 0x3ca: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3cf:
	/* 0x3cf: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3d2:
	/* 0x3d2: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d6:
	/* 0x3d6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3db:
	/* 0x3db: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3dd:
	/* 0x3dd: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3df:
	/* 0x3df: js     d00 <generic_sleepable_preload+0xd00> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3df, 0xd00, x86_l_d00);
x86_l_3e5:
	/* 0x3e5: cmp    WORD PTR [rbx-0x20],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743936270598144ULL);
x86_l_3ea:
	/* 0x3ea: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ea, 0xd2c, x86_l_d2c);
x86_l_3f0:
	/* 0x3f0: mov    ecx,DWORD PTR [rbx-0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_3f3:
	/* 0x3f3: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3f7:
	/* 0x3f7: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fb:
	/* 0x3fb: cmp    WORD PTR [rbx-0x22],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743927680663552ULL);
x86_l_400:
	/* 0x400: je     422 <generic_sleepable_preload+0x422> */
	X86_SIM_X86_JCC(X86_CC_E, 0x400, 0x422, x86_l_422);
x86_l_402:
	/* 0x402: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_407:
	/* 0x407: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_40c:
	/* 0x40c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_40f:
	/* 0x40f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_413:
	/* 0x413: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_418:
	/* 0x418: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_41a:
	/* 0x41a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_41c:
	/* 0x41c: js     d12 <generic_sleepable_preload+0xd12> */
	X86_SIM_X86_JCC(X86_CC_S, 0x41c, 0xd12, x86_l_d12);
x86_l_422:
	/* 0x422: cmp    WORD PTR [rbx-0x18],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743970630336512ULL);
x86_l_427:
	/* 0x427: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x427, 0xd2c, x86_l_d2c);
x86_l_42d:
	/* 0x42d: mov    ecx,DWORD PTR [rbx-0x1e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551586ULL);
x86_l_430:
	/* 0x430: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_434:
	/* 0x434: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_438:
	/* 0x438: cmp    WORD PTR [rbx-0x1a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743962040401920ULL);
x86_l_43d:
	/* 0x43d: je     45f <generic_sleepable_preload+0x45f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43d, 0x45f, x86_l_45f);
x86_l_43f:
	/* 0x43f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_444:
	/* 0x444: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_449:
	/* 0x449: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_44c:
	/* 0x44c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_450:
	/* 0x450: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_455:
	/* 0x455: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_457:
	/* 0x457: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_459:
	/* 0x459: js     d24 <generic_sleepable_preload+0xd24> */
	X86_SIM_X86_JCC(X86_CC_S, 0x459, 0xd24, x86_l_d24);
x86_l_45f:
	/* 0x45f: cmp    WORD PTR [rbx-0x10],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744004990074880ULL);
x86_l_464:
	/* 0x464: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x464, 0xd2c, x86_l_d2c);
x86_l_46a:
	/* 0x46a: mov    ecx,DWORD PTR [rbx-0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_46d:
	/* 0x46d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_471:
	/* 0x471: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_475:
	/* 0x475: cmp    WORD PTR [rbx-0x12],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743996400140288ULL);
x86_l_47a:
	/* 0x47a: je     49c <generic_sleepable_preload+0x49c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47a, 0x49c, x86_l_49c);
x86_l_47c:
	/* 0x47c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_481:
	/* 0x481: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_486:
	/* 0x486: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_489:
	/* 0x489: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48d:
	/* 0x48d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_492:
	/* 0x492: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_494:
	/* 0x494: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_496:
	/* 0x496: js     ecf <generic_sleepable_preload+0xecf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x496, 0xecf, x86_l_ecf);
x86_l_49c:
	/* 0x49c: cmp    WORD PTR [rbx-0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744039349813248ULL);
x86_l_4a1:
	/* 0x4a1: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a1, 0xd2c, x86_l_d2c);
x86_l_4a7:
	/* 0x4a7: mov    ecx,DWORD PTR [rbx-0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551602ULL);
x86_l_4aa:
	/* 0x4aa: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4ae:
	/* 0x4ae: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b2:
	/* 0x4b2: cmp    WORD PTR [rbx-0xa],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744030759878656ULL);
x86_l_4b7:
	/* 0x4b7: je     4d9 <generic_sleepable_preload+0x4d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b7, 0x4d9, x86_l_4d9);
x86_l_4b9:
	/* 0x4b9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4be:
	/* 0x4be: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4c3:
	/* 0x4c3: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4c6:
	/* 0x4c6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ca:
	/* 0x4ca: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4cf:
	/* 0x4cf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4d1:
	/* 0x4d1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4d3:
	/* 0x4d3: js     ef3 <generic_sleepable_preload+0xef3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4d3, 0xef3, x86_l_ef3);
x86_l_4d9:
	/* 0x4d9: cmp    WORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4dd:
	/* 0x4dd: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dd, 0xd2c, x86_l_d2c);
x86_l_4e3:
	/* 0x4e3: mov    ecx,DWORD PTR [rbx-0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_4e6:
	/* 0x4e6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4ea:
	/* 0x4ea: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ee:
	/* 0x4ee: cmp    WORD PTR [rbx-0x2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617024ULL);
x86_l_4f3:
	/* 0x4f3: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f3, 0xd2c, x86_l_d2c);
x86_l_4f9:
	/* 0x4f9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4fe:
	/* 0x4fe: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_503:
	/* 0x503: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_506:
	/* 0x506: jmp    745 <generic_sleepable_preload+0x745> */
	X86_SIM_X86_JMP(0x506, 0x745, x86_l_745);
x86_l_50b:
	/* 0x50b: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_50e:
	/* 0x50e: je     530 <generic_sleepable_preload+0x530> */
	X86_SIM_X86_JCC(X86_CC_E, 0x50e, 0x530, x86_l_530);
x86_l_510:
	/* 0x510: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_515:
	/* 0x515: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_51a:
	/* 0x51a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_51d:
	/* 0x51d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_521:
	/* 0x521: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_526:
	/* 0x526: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_528:
	/* 0x528: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_52a:
	/* 0x52a: js     763 <generic_sleepable_preload+0x763> */
	X86_SIM_X86_JCC(X86_CC_S, 0x52a, 0x763, x86_l_763);
x86_l_530:
	/* 0x530: cmp    WORD PTR [rbx-0x40],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743798831644672ULL);
x86_l_535:
	/* 0x535: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x535, 0xd2c, x86_l_d2c);
x86_l_53b:
	/* 0x53b: mov    ecx,DWORD PTR [rbx-0x46] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551546ULL);
x86_l_53e:
	/* 0x53e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_542:
	/* 0x542: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_546:
	/* 0x546: cmp    WORD PTR [rbx-0x42],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743790241710080ULL);
x86_l_54b:
	/* 0x54b: je     56d <generic_sleepable_preload+0x56d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54b, 0x56d, x86_l_56d);
x86_l_54d:
	/* 0x54d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_552:
	/* 0x552: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_557:
	/* 0x557: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_55a:
	/* 0x55a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55e:
	/* 0x55e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_563:
	/* 0x563: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_565:
	/* 0x565: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_567:
	/* 0x567: js     cca <generic_sleepable_preload+0xcca> */
	X86_SIM_X86_JCC(X86_CC_S, 0x567, 0xcca, x86_l_cca);
x86_l_56d:
	/* 0x56d: cmp    WORD PTR [rbx-0x38],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743833191383040ULL);
x86_l_572:
	/* 0x572: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x572, 0xd2c, x86_l_d2c);
x86_l_578:
	/* 0x578: mov    ecx,DWORD PTR [rbx-0x3e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551554ULL);
x86_l_57b:
	/* 0x57b: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_57f:
	/* 0x57f: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_583:
	/* 0x583: cmp    WORD PTR [rbx-0x3a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743824601448448ULL);
x86_l_588:
	/* 0x588: je     5aa <generic_sleepable_preload+0x5aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x588, 0x5aa, x86_l_5aa);
x86_l_58a:
	/* 0x58a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_58f:
	/* 0x58f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_594:
	/* 0x594: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_597:
	/* 0x597: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59b:
	/* 0x59b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5a0:
	/* 0x5a0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5a2:
	/* 0x5a2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5a4:
	/* 0x5a4: js     cdc <generic_sleepable_preload+0xcdc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5a4, 0xcdc, x86_l_cdc);
x86_l_5aa:
	/* 0x5aa: cmp    WORD PTR [rbx-0x30],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743867551121408ULL);
x86_l_5af:
	/* 0x5af: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5af, 0xd2c, x86_l_d2c);
x86_l_5b5:
	/* 0x5b5: mov    ecx,DWORD PTR [rbx-0x36] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551562ULL);
x86_l_5b8:
	/* 0x5b8: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5bc:
	/* 0x5bc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c0:
	/* 0x5c0: cmp    WORD PTR [rbx-0x32],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743858961186816ULL);
x86_l_5c5:
	/* 0x5c5: je     5e7 <generic_sleepable_preload+0x5e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c5, 0x5e7, x86_l_5e7);
x86_l_5c7:
	/* 0x5c7: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5cc:
	/* 0x5cc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5d1:
	/* 0x5d1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5d4:
	/* 0x5d4: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d8:
	/* 0x5d8: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5dd:
	/* 0x5dd: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5df:
	/* 0x5df: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5e1:
	/* 0x5e1: js     cee <generic_sleepable_preload+0xcee> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5e1, 0xcee, x86_l_cee);
x86_l_5e7:
	/* 0x5e7: cmp    WORD PTR [rbx-0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743901910859776ULL);
x86_l_5ec:
	/* 0x5ec: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ec, 0xd2c, x86_l_d2c);
x86_l_5f2:
	/* 0x5f2: mov    ecx,DWORD PTR [rbx-0x2e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551570ULL);
x86_l_5f5:
	/* 0x5f5: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5f9:
	/* 0x5f9: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5fd:
	/* 0x5fd: cmp    WORD PTR [rbx-0x2a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743893320925184ULL);
x86_l_602:
	/* 0x602: je     624 <generic_sleepable_preload+0x624> */
	X86_SIM_X86_JCC(X86_CC_E, 0x602, 0x624, x86_l_624);
x86_l_604:
	/* 0x604: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_609:
	/* 0x609: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_60e:
	/* 0x60e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_611:
	/* 0x611: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_615:
	/* 0x615: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_61a:
	/* 0x61a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_61c:
	/* 0x61c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_61e:
	/* 0x61e: js     d00 <generic_sleepable_preload+0xd00> */
	X86_SIM_X86_JCC(X86_CC_S, 0x61e, 0xd00, x86_l_d00);
x86_l_624:
	/* 0x624: cmp    WORD PTR [rbx-0x20],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743936270598144ULL);
x86_l_629:
	/* 0x629: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x629, 0xd2c, x86_l_d2c);
x86_l_62f:
	/* 0x62f: mov    ecx,DWORD PTR [rbx-0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_632:
	/* 0x632: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_636:
	/* 0x636: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_63a:
	/* 0x63a: cmp    WORD PTR [rbx-0x22],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743927680663552ULL);
x86_l_63f:
	/* 0x63f: je     661 <generic_sleepable_preload+0x661> */
	X86_SIM_X86_JCC(X86_CC_E, 0x63f, 0x661, x86_l_661);
x86_l_641:
	/* 0x641: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_646:
	/* 0x646: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_64b:
	/* 0x64b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_64e:
	/* 0x64e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_652:
	/* 0x652: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_657:
	/* 0x657: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_659:
	/* 0x659: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_65b:
	/* 0x65b: js     d12 <generic_sleepable_preload+0xd12> */
	X86_SIM_X86_JCC(X86_CC_S, 0x65b, 0xd12, x86_l_d12);
x86_l_661:
	/* 0x661: cmp    WORD PTR [rbx-0x18],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743970630336512ULL);
x86_l_666:
	/* 0x666: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x666, 0xd2c, x86_l_d2c);
x86_l_66c:
	/* 0x66c: mov    ecx,DWORD PTR [rbx-0x1e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551586ULL);
x86_l_66f:
	/* 0x66f: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_673:
	/* 0x673: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_677:
	/* 0x677: cmp    WORD PTR [rbx-0x1a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743962040401920ULL);
x86_l_67c:
	/* 0x67c: je     69e <generic_sleepable_preload+0x69e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67c, 0x69e, x86_l_69e);
x86_l_67e:
	/* 0x67e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_683:
	/* 0x683: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_688:
	/* 0x688: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_68b:
	/* 0x68b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_68f:
	/* 0x68f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_694:
	/* 0x694: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_696:
	/* 0x696: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_698:
	/* 0x698: js     d24 <generic_sleepable_preload+0xd24> */
	X86_SIM_X86_JCC(X86_CC_S, 0x698, 0xd24, x86_l_d24);
x86_l_69e:
	/* 0x69e: cmp    WORD PTR [rbx-0x10],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744004990074880ULL);
x86_l_6a3:
	/* 0x6a3: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a3, 0xd2c, x86_l_d2c);
x86_l_6a9:
	/* 0x6a9: mov    ecx,DWORD PTR [rbx-0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_6ac:
	/* 0x6ac: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_6b0:
	/* 0x6b0: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6b4:
	/* 0x6b4: cmp    WORD PTR [rbx-0x12],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743996400140288ULL);
x86_l_6b9:
	/* 0x6b9: je     6db <generic_sleepable_preload+0x6db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b9, 0x6db, x86_l_6db);
x86_l_6bb:
	/* 0x6bb: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_6c0:
	/* 0x6c0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_6c5:
	/* 0x6c5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_6c8:
	/* 0x6c8: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6cc:
	/* 0x6cc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_6d1:
	/* 0x6d1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_6d3:
	/* 0x6d3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_6d5:
	/* 0x6d5: js     ecf <generic_sleepable_preload+0xecf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x6d5, 0xecf, x86_l_ecf);
x86_l_6db:
	/* 0x6db: cmp    WORD PTR [rbx-0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744039349813248ULL);
x86_l_6e0:
	/* 0x6e0: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e0, 0xd2c, x86_l_d2c);
x86_l_6e6:
	/* 0x6e6: mov    ecx,DWORD PTR [rbx-0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551602ULL);
x86_l_6e9:
	/* 0x6e9: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_6ed:
	/* 0x6ed: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f1:
	/* 0x6f1: cmp    WORD PTR [rbx-0xa],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744030759878656ULL);
x86_l_6f6:
	/* 0x6f6: je     718 <generic_sleepable_preload+0x718> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f6, 0x718, x86_l_718);
x86_l_6f8:
	/* 0x6f8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_6fd:
	/* 0x6fd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_702:
	/* 0x702: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_705:
	/* 0x705: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_709:
	/* 0x709: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_70e:
	/* 0x70e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_710:
	/* 0x710: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_712:
	/* 0x712: js     ef3 <generic_sleepable_preload+0xef3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x712, 0xef3, x86_l_ef3);
x86_l_718:
	/* 0x718: cmp    WORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_71c:
	/* 0x71c: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x71c, 0xd2c, x86_l_d2c);
x86_l_722:
	/* 0x722: mov    ecx,DWORD PTR [rbx-0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_725:
	/* 0x725: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_729:
	/* 0x729: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_72d:
	/* 0x72d: cmp    WORD PTR [rbx-0x2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617024ULL);
x86_l_732:
	/* 0x732: je     d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x732, 0xd2c, x86_l_d2c);
x86_l_738:
	/* 0x738: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_73d:
	/* 0x73d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_742:
	/* 0x742: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_745:
	/* 0x745: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_749:
	/* 0x749: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_74e:
	/* 0x74e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_750:
	/* 0x750: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_752:
	/* 0x752: jns    d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x752, 0xd2c, x86_l_d2c);
x86_l_758:
	/* 0x758: mov    r13d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 10ULL);
x86_l_75e:
	/* 0x75e: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0x75e, 0xd2a, x86_l_d2a);
x86_l_763:
	/* 0x763: mov    r13d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 1ULL);
x86_l_769:
	/* 0x769: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0x769, 0xd2a, x86_l_d2a);
x86_l_76e:
	/* 0x76e: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_776:
	/* 0x776: cmp    ecx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 10ULL);
x86_l_779:
	/* 0x779: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x779, 0x7de, x86_l_7de);
x86_l_77b:
	/* 0x77b: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_780:
	/* 0x780: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_785:
	/* 0x785: cmp    ecx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 11ULL);
x86_l_788:
	/* 0x788: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x788, 0x7de, x86_l_7de);
x86_l_78a:
	/* 0x78a: jmp    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JMP(0x78a, 0x7f1, x86_l_7f1);
x86_l_78c:
	/* 0x78c: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_791:
	/* 0x791: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_794:
	/* 0x794: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x794, 0x7de, x86_l_7de);
x86_l_796:
	/* 0x796: mov    rdx,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_79b:
	/* 0x79b: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_7a0:
	/* 0x7a0: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_7a3:
	/* 0x7a3: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a3, 0x7de, x86_l_7de);
x86_l_7a5:
	/* 0x7a5: jmp    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JMP(0x7a5, 0x7f1, x86_l_7f1);
x86_l_7a7:
	/* 0x7a7: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_7af:
	/* 0x7af: cmp    ecx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 6ULL);
x86_l_7b2:
	/* 0x7b2: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b2, 0x7de, x86_l_7de);
x86_l_7b4:
	/* 0x7b4: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7b9:
	/* 0x7b9: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_7be:
	/* 0x7be: cmp    ecx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_7c1:
	/* 0x7c1: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c1, 0x7de, x86_l_7de);
x86_l_7c3:
	/* 0x7c3: jmp    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JMP(0x7c3, 0x7f1, x86_l_7f1);
x86_l_7c5:
	/* 0x7c5: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7ca:
	/* 0x7ca: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_7cd:
	/* 0x7cd: je     7de <generic_sleepable_preload+0x7de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7cd, 0x7de, x86_l_7de);
x86_l_7cf:
	/* 0x7cf: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7d4:
	/* 0x7d4: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_7d9:
	/* 0x7d9: cmp    ecx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 13ULL);
x86_l_7dc:
	/* 0x7dc: jne    7f1 <generic_sleepable_preload+0x7f1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7dc, 0x7f1, x86_l_7f1);
x86_l_7de:
	/* 0x7de: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_7e1:
	/* 0x7e1: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_7e3:
	/* 0x7e3: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_7e5:
	/* 0x7e5: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_7ea:
	/* 0x7ea: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_7ec:
	/* 0x7ec: bzhi   rsi,QWORD PTR [rdx],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RSI, X86_RDX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_7f1:
	/* 0x7f1: mov    QWORD PTR [rsp],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f5:
	/* 0x7f5: mov    r12d,DWORD PTR [r12+r14*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_7fa:
	/* 0x7fa: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7fc:
	/* 0x7fc: mov    r15b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_8, 1ULL);
x86_l_7ff:
	/* 0x7ff: cmp    WORD PTR [rbx-0x48],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743764471906304ULL);
x86_l_804:
	/* 0x804: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x804, 0xe14, x86_l_e14);
x86_l_80a:
	/* 0x80a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_811:
	/* 0x811: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_814:
	/* 0x814: mov    eax,DWORD PTR [rbx-0x4e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551538ULL);
x86_l_817:
	/* 0x817: add    rsi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_81a:
	/* 0x81a: mov    QWORD PTR [rsp],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_81e:
	/* 0x81e: movzx  eax,WORD PTR [rbx-0x4a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18446744073709551542ULL);
x86_l_822:
	/* 0x822: test   cl,cl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8);
x86_l_824:
	/* 0x824: je     a69 <generic_sleepable_preload+0xa69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x824, 0xa69, x86_l_a69);
x86_l_82a:
	/* 0x82a: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_82d:
	/* 0x82d: je     84f <generic_sleepable_preload+0x84f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82d, 0x84f, x86_l_84f);
x86_l_82f:
	/* 0x82f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_834:
	/* 0x834: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_839:
	/* 0x839: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_83c:
	/* 0x83c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_840:
	/* 0x840: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_845:
	/* 0x845: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_847:
	/* 0x847: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_849:
	/* 0x849: js     cc0 <generic_sleepable_preload+0xcc0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x849, 0xcc0, x86_l_cc0);
x86_l_84f:
	/* 0x84f: cmp    WORD PTR [rbx-0x40],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743798831644672ULL);
x86_l_854:
	/* 0x854: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x854, 0xe14, x86_l_e14);
x86_l_85a:
	/* 0x85a: mov    ecx,DWORD PTR [rbx-0x46] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551546ULL);
x86_l_85d:
	/* 0x85d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_861:
	/* 0x861: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_865:
	/* 0x865: cmp    WORD PTR [rbx-0x42],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743790241710080ULL);
x86_l_86a:
	/* 0x86a: je     88c <generic_sleepable_preload+0x88c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x86a, 0x88c, x86_l_88c);
x86_l_86c:
	/* 0x86c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_871:
	/* 0x871: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_876:
	/* 0x876: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_879:
	/* 0x879: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_87d:
	/* 0x87d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_882:
	/* 0x882: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_884:
	/* 0x884: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_886:
	/* 0x886: js     cd2 <generic_sleepable_preload+0xcd2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x886, 0xcd2, x86_l_cd2);
x86_l_88c:
	/* 0x88c: cmp    WORD PTR [rbx-0x38],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743833191383040ULL);
x86_l_891:
	/* 0x891: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x891, 0xe14, x86_l_e14);
x86_l_897:
	/* 0x897: mov    ecx,DWORD PTR [rbx-0x3e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551554ULL);
x86_l_89a:
	/* 0x89a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_89e:
	/* 0x89e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8a2:
	/* 0x8a2: cmp    WORD PTR [rbx-0x3a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743824601448448ULL);
x86_l_8a7:
	/* 0x8a7: je     8c9 <generic_sleepable_preload+0x8c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a7, 0x8c9, x86_l_8c9);
x86_l_8a9:
	/* 0x8a9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_8ae:
	/* 0x8ae: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_8b3:
	/* 0x8b3: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_8b6:
	/* 0x8b6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8ba:
	/* 0x8ba: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_8bf:
	/* 0x8bf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_8c1:
	/* 0x8c1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_8c3:
	/* 0x8c3: js     ce4 <generic_sleepable_preload+0xce4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8c3, 0xce4, x86_l_ce4);
x86_l_8c9:
	/* 0x8c9: cmp    WORD PTR [rbx-0x30],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743867551121408ULL);
x86_l_8ce:
	/* 0x8ce: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ce, 0xe14, x86_l_e14);
x86_l_8d4:
	/* 0x8d4: mov    ecx,DWORD PTR [rbx-0x36] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551562ULL);
x86_l_8d7:
	/* 0x8d7: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_8db:
	/* 0x8db: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8df:
	/* 0x8df: cmp    WORD PTR [rbx-0x32],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743858961186816ULL);
x86_l_8e4:
	/* 0x8e4: je     906 <generic_sleepable_preload+0x906> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e4, 0x906, x86_l_906);
x86_l_8e6:
	/* 0x8e6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_8eb:
	/* 0x8eb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_8f0:
	/* 0x8f0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_8f3:
	/* 0x8f3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8f7:
	/* 0x8f7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_8fc:
	/* 0x8fc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_8fe:
	/* 0x8fe: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_900:
	/* 0x900: js     cf6 <generic_sleepable_preload+0xcf6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x900, 0xcf6, x86_l_cf6);
x86_l_906:
	/* 0x906: cmp    WORD PTR [rbx-0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743901910859776ULL);
x86_l_90b:
	/* 0x90b: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90b, 0xe14, x86_l_e14);
x86_l_911:
	/* 0x911: mov    ecx,DWORD PTR [rbx-0x2e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551570ULL);
x86_l_914:
	/* 0x914: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_918:
	/* 0x918: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_91c:
	/* 0x91c: cmp    WORD PTR [rbx-0x2a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743893320925184ULL);
x86_l_921:
	/* 0x921: je     943 <generic_sleepable_preload+0x943> */
	X86_SIM_X86_JCC(X86_CC_E, 0x921, 0x943, x86_l_943);
x86_l_923:
	/* 0x923: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_928:
	/* 0x928: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_92d:
	/* 0x92d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_930:
	/* 0x930: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_934:
	/* 0x934: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_939:
	/* 0x939: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_93b:
	/* 0x93b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_93d:
	/* 0x93d: js     d08 <generic_sleepable_preload+0xd08> */
	X86_SIM_X86_JCC(X86_CC_S, 0x93d, 0xd08, x86_l_d08);
x86_l_943:
	/* 0x943: cmp    WORD PTR [rbx-0x20],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743936270598144ULL);
x86_l_948:
	/* 0x948: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x948, 0xe14, x86_l_e14);
x86_l_94e:
	/* 0x94e: mov    ecx,DWORD PTR [rbx-0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_951:
	/* 0x951: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_955:
	/* 0x955: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_959:
	/* 0x959: cmp    WORD PTR [rbx-0x22],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743927680663552ULL);
x86_l_95e:
	/* 0x95e: je     980 <generic_sleepable_preload+0x980> */
	X86_SIM_X86_JCC(X86_CC_E, 0x95e, 0x980, x86_l_980);
x86_l_960:
	/* 0x960: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_965:
	/* 0x965: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_96a:
	/* 0x96a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_96d:
	/* 0x96d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_971:
	/* 0x971: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_976:
	/* 0x976: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_978:
	/* 0x978: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_97a:
	/* 0x97a: js     d1a <generic_sleepable_preload+0xd1a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x97a, 0xd1a, x86_l_d1a);
x86_l_980:
	/* 0x980: cmp    WORD PTR [rbx-0x18],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743970630336512ULL);
x86_l_985:
	/* 0x985: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x985, 0xe14, x86_l_e14);
x86_l_98b:
	/* 0x98b: mov    ecx,DWORD PTR [rbx-0x1e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551586ULL);
x86_l_98e:
	/* 0x98e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_992:
	/* 0x992: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_996:
	/* 0x996: cmp    WORD PTR [rbx-0x1a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743962040401920ULL);
x86_l_99b:
	/* 0x99b: je     9bd <generic_sleepable_preload+0x9bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x99b, 0x9bd, x86_l_9bd);
x86_l_99d:
	/* 0x99d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_9a2:
	/* 0x9a2: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_9a7:
	/* 0x9a7: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_9aa:
	/* 0x9aa: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9ae:
	/* 0x9ae: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_9b3:
	/* 0x9b3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_9b5:
	/* 0x9b5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_9b7:
	/* 0x9b7: js     e0c <generic_sleepable_preload+0xe0c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x9b7, 0xe0c, x86_l_e0c);
x86_l_9bd:
	/* 0x9bd: cmp    WORD PTR [rbx-0x10],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744004990074880ULL);
x86_l_9c2:
	/* 0x9c2: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c2, 0xe14, x86_l_e14);
x86_l_9c8:
	/* 0x9c8: mov    ecx,DWORD PTR [rbx-0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_9cb:
	/* 0x9cb: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_9cf:
	/* 0x9cf: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9d3:
	/* 0x9d3: cmp    WORD PTR [rbx-0x12],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743996400140288ULL);
x86_l_9d8:
	/* 0x9d8: je     9fa <generic_sleepable_preload+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d8, 0x9fa, x86_l_9fa);
x86_l_9da:
	/* 0x9da: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_9df:
	/* 0x9df: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_9e4:
	/* 0x9e4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_9e7:
	/* 0x9e7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9eb:
	/* 0x9eb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_9f0:
	/* 0x9f0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_9f2:
	/* 0x9f2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_9f4:
	/* 0x9f4: js     edc <generic_sleepable_preload+0xedc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x9f4, 0xedc, x86_l_edc);
x86_l_9fa:
	/* 0x9fa: cmp    WORD PTR [rbx-0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744039349813248ULL);
x86_l_9ff:
	/* 0x9ff: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ff, 0xe14, x86_l_e14);
x86_l_a05:
	/* 0xa05: mov    ecx,DWORD PTR [rbx-0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551602ULL);
x86_l_a08:
	/* 0xa08: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_a0c:
	/* 0xa0c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a10:
	/* 0xa10: cmp    WORD PTR [rbx-0xa],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744030759878656ULL);
x86_l_a15:
	/* 0xa15: je     a37 <generic_sleepable_preload+0xa37> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa15, 0xa37, x86_l_a37);
x86_l_a17:
	/* 0xa17: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_a1c:
	/* 0xa1c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_a21:
	/* 0xa21: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_a24:
	/* 0xa24: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a28:
	/* 0xa28: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_a2d:
	/* 0xa2d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_a2f:
	/* 0xa2f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_a31:
	/* 0xa31: js     efe <generic_sleepable_preload+0xefe> */
	X86_SIM_X86_JCC(X86_CC_S, 0xa31, 0xefe, x86_l_efe);
x86_l_a37:
	/* 0xa37: cmp    WORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a3b:
	/* 0xa3b: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa3b, 0xe14, x86_l_e14);
x86_l_a41:
	/* 0xa41: mov    ecx,DWORD PTR [rbx-0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_a44:
	/* 0xa44: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_a48:
	/* 0xa48: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a4c:
	/* 0xa4c: cmp    WORD PTR [rbx-0x2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617024ULL);
x86_l_a51:
	/* 0xa51: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa51, 0xe14, x86_l_e14);
x86_l_a57:
	/* 0xa57: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_a5c:
	/* 0xa5c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_a61:
	/* 0xa61: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_a64:
	/* 0xa64: jmp    ca3 <generic_sleepable_preload+0xca3> */
	X86_SIM_X86_JMP(0xa64, 0xca3, x86_l_ca3);
x86_l_a69:
	/* 0xa69: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_a6c:
	/* 0xa6c: je     a8e <generic_sleepable_preload+0xa8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa6c, 0xa8e, x86_l_a8e);
x86_l_a6e:
	/* 0xa6e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_a73:
	/* 0xa73: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_a78:
	/* 0xa78: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_a7b:
	/* 0xa7b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a7f:
	/* 0xa7f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_a84:
	/* 0xa84: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_a86:
	/* 0xa86: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_a88:
	/* 0xa88: js     cc0 <generic_sleepable_preload+0xcc0> */
	X86_SIM_X86_JCC(X86_CC_S, 0xa88, 0xcc0, x86_l_cc0);
x86_l_a8e:
	/* 0xa8e: cmp    WORD PTR [rbx-0x40],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743798831644672ULL);
x86_l_a93:
	/* 0xa93: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa93, 0xe14, x86_l_e14);
x86_l_a99:
	/* 0xa99: mov    ecx,DWORD PTR [rbx-0x46] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551546ULL);
x86_l_a9c:
	/* 0xa9c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_aa0:
	/* 0xaa0: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_aa4:
	/* 0xaa4: cmp    WORD PTR [rbx-0x42],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743790241710080ULL);
x86_l_aa9:
	/* 0xaa9: je     acb <generic_sleepable_preload+0xacb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaa9, 0xacb, x86_l_acb);
x86_l_aab:
	/* 0xaab: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_ab0:
	/* 0xab0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_ab5:
	/* 0xab5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_ab8:
	/* 0xab8: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_abc:
	/* 0xabc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_ac1:
	/* 0xac1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_ac3:
	/* 0xac3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_ac5:
	/* 0xac5: js     cd2 <generic_sleepable_preload+0xcd2> */
	X86_SIM_X86_JCC(X86_CC_S, 0xac5, 0xcd2, x86_l_cd2);
x86_l_acb:
	/* 0xacb: cmp    WORD PTR [rbx-0x38],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743833191383040ULL);
x86_l_ad0:
	/* 0xad0: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad0, 0xe14, x86_l_e14);
x86_l_ad6:
	/* 0xad6: mov    ecx,DWORD PTR [rbx-0x3e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551554ULL);
x86_l_ad9:
	/* 0xad9: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_add:
	/* 0xadd: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ae1:
	/* 0xae1: cmp    WORD PTR [rbx-0x3a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743824601448448ULL);
x86_l_ae6:
	/* 0xae6: je     b08 <generic_sleepable_preload+0xb08> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae6, 0xb08, x86_l_b08);
x86_l_ae8:
	/* 0xae8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_aed:
	/* 0xaed: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_af2:
	/* 0xaf2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_af5:
	/* 0xaf5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af9:
	/* 0xaf9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_afe:
	/* 0xafe: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_b00:
	/* 0xb00: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_b02:
	/* 0xb02: js     ce4 <generic_sleepable_preload+0xce4> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb02, 0xce4, x86_l_ce4);
x86_l_b08:
	/* 0xb08: cmp    WORD PTR [rbx-0x30],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743867551121408ULL);
x86_l_b0d:
	/* 0xb0d: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb0d, 0xe14, x86_l_e14);
x86_l_b13:
	/* 0xb13: mov    ecx,DWORD PTR [rbx-0x36] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551562ULL);
x86_l_b16:
	/* 0xb16: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_b1a:
	/* 0xb1a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b1e:
	/* 0xb1e: cmp    WORD PTR [rbx-0x32],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743858961186816ULL);
x86_l_b23:
	/* 0xb23: je     b45 <generic_sleepable_preload+0xb45> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb23, 0xb45, x86_l_b45);
x86_l_b25:
	/* 0xb25: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_b2a:
	/* 0xb2a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_b2f:
	/* 0xb2f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_b32:
	/* 0xb32: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b36:
	/* 0xb36: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_b3b:
	/* 0xb3b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_b3d:
	/* 0xb3d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_b3f:
	/* 0xb3f: js     cf6 <generic_sleepable_preload+0xcf6> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb3f, 0xcf6, x86_l_cf6);
x86_l_b45:
	/* 0xb45: cmp    WORD PTR [rbx-0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743901910859776ULL);
x86_l_b4a:
	/* 0xb4a: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4a, 0xe14, x86_l_e14);
x86_l_b50:
	/* 0xb50: mov    ecx,DWORD PTR [rbx-0x2e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551570ULL);
x86_l_b53:
	/* 0xb53: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_b57:
	/* 0xb57: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b5b:
	/* 0xb5b: cmp    WORD PTR [rbx-0x2a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743893320925184ULL);
x86_l_b60:
	/* 0xb60: je     b82 <generic_sleepable_preload+0xb82> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb60, 0xb82, x86_l_b82);
x86_l_b62:
	/* 0xb62: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_b67:
	/* 0xb67: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_b6c:
	/* 0xb6c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_b6f:
	/* 0xb6f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b73:
	/* 0xb73: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_b78:
	/* 0xb78: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_b7a:
	/* 0xb7a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_b7c:
	/* 0xb7c: js     d08 <generic_sleepable_preload+0xd08> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb7c, 0xd08, x86_l_d08);
x86_l_b82:
	/* 0xb82: cmp    WORD PTR [rbx-0x20],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743936270598144ULL);
x86_l_b87:
	/* 0xb87: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb87, 0xe14, x86_l_e14);
x86_l_b8d:
	/* 0xb8d: mov    ecx,DWORD PTR [rbx-0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_b90:
	/* 0xb90: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_b94:
	/* 0xb94: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b98:
	/* 0xb98: cmp    WORD PTR [rbx-0x22],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743927680663552ULL);
x86_l_b9d:
	/* 0xb9d: je     bbf <generic_sleepable_preload+0xbbf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9d, 0xbbf, x86_l_bbf);
x86_l_b9f:
	/* 0xb9f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_ba4:
	/* 0xba4: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_ba9:
	/* 0xba9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_bac:
	/* 0xbac: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bb0:
	/* 0xbb0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_bb5:
	/* 0xbb5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_bb7:
	/* 0xbb7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_bb9:
	/* 0xbb9: js     d1a <generic_sleepable_preload+0xd1a> */
	X86_SIM_X86_JCC(X86_CC_S, 0xbb9, 0xd1a, x86_l_d1a);
x86_l_bbf:
	/* 0xbbf: cmp    WORD PTR [rbx-0x18],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743970630336512ULL);
x86_l_bc4:
	/* 0xbc4: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc4, 0xe14, x86_l_e14);
x86_l_bca:
	/* 0xbca: mov    ecx,DWORD PTR [rbx-0x1e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551586ULL);
x86_l_bcd:
	/* 0xbcd: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_bd1:
	/* 0xbd1: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd5:
	/* 0xbd5: cmp    WORD PTR [rbx-0x1a],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743962040401920ULL);
x86_l_bda:
	/* 0xbda: je     bfc <generic_sleepable_preload+0xbfc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbda, 0xbfc, x86_l_bfc);
x86_l_bdc:
	/* 0xbdc: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_be1:
	/* 0xbe1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_be6:
	/* 0xbe6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_be9:
	/* 0xbe9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bed:
	/* 0xbed: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_bf2:
	/* 0xbf2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_bf4:
	/* 0xbf4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_bf6:
	/* 0xbf6: js     e0c <generic_sleepable_preload+0xe0c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xbf6, 0xe0c, x86_l_e0c);
x86_l_bfc:
	/* 0xbfc: cmp    WORD PTR [rbx-0x10],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744004990074880ULL);
x86_l_c01:
	/* 0xc01: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc01, 0xe14, x86_l_e14);
x86_l_c07:
	/* 0xc07: mov    ecx,DWORD PTR [rbx-0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_c0a:
	/* 0xc0a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_c0e:
	/* 0xc0e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c12:
	/* 0xc12: cmp    WORD PTR [rbx-0x12],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446743996400140288ULL);
x86_l_c17:
	/* 0xc17: je     c39 <generic_sleepable_preload+0xc39> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc17, 0xc39, x86_l_c39);
x86_l_c19:
	/* 0xc19: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_c1e:
	/* 0xc1e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_c23:
	/* 0xc23: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_c26:
	/* 0xc26: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c2a:
	/* 0xc2a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_c2f:
	/* 0xc2f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_c31:
	/* 0xc31: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_c33:
	/* 0xc33: js     edc <generic_sleepable_preload+0xedc> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc33, 0xedc, x86_l_edc);
x86_l_c39:
	/* 0xc39: cmp    WORD PTR [rbx-0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744039349813248ULL);
x86_l_c3e:
	/* 0xc3e: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3e, 0xe14, x86_l_e14);
x86_l_c44:
	/* 0xc44: mov    ecx,DWORD PTR [rbx-0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551602ULL);
x86_l_c47:
	/* 0xc47: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_c4b:
	/* 0xc4b: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c4f:
	/* 0xc4f: cmp    WORD PTR [rbx-0xa],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744030759878656ULL);
x86_l_c54:
	/* 0xc54: je     c76 <generic_sleepable_preload+0xc76> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc54, 0xc76, x86_l_c76);
x86_l_c56:
	/* 0xc56: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_c5b:
	/* 0xc5b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_c60:
	/* 0xc60: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_c63:
	/* 0xc63: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c67:
	/* 0xc67: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_c6c:
	/* 0xc6c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_c6e:
	/* 0xc6e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_c70:
	/* 0xc70: js     efe <generic_sleepable_preload+0xefe> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc70, 0xefe, x86_l_efe);
x86_l_c76:
	/* 0xc76: cmp    WORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c7a:
	/* 0xc7a: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc7a, 0xe14, x86_l_e14);
x86_l_c80:
	/* 0xc80: mov    ecx,DWORD PTR [rbx-0x6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_c83:
	/* 0xc83: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_c87:
	/* 0xc87: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c8b:
	/* 0xc8b: cmp    WORD PTR [rbx-0x2],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18446744065119617024ULL);
x86_l_c90:
	/* 0xc90: je     e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc90, 0xe14, x86_l_e14);
x86_l_c96:
	/* 0xc96: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_c9b:
	/* 0xc9b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_ca0:
	/* 0xca0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_ca3:
	/* 0xca3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ca7:
	/* 0xca7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_cac:
	/* 0xcac: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_cae:
	/* 0xcae: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_cb0:
	/* 0xcb0: jns    e14 <generic_sleepable_preload+0xe14> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcb0, 0xe14, x86_l_e14);
x86_l_cb6:
	/* 0xcb6: mov    ebp,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 10ULL);
x86_l_cbb:
	/* 0xcbb: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xcbb, 0xe11, x86_l_e11);
x86_l_cc0:
	/* 0xcc0: mov    ebp,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 1ULL);
x86_l_cc5:
	/* 0xcc5: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xcc5, 0xe11, x86_l_e11);
x86_l_cca:
	/* 0xcca: mov    r13d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2ULL);
x86_l_cd0:
	/* 0xcd0: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0xcd0, 0xd2a, x86_l_d2a);
x86_l_cd2:
	/* 0xcd2: mov    ebp,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 2ULL);
x86_l_cd7:
	/* 0xcd7: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xcd7, 0xe11, x86_l_e11);
x86_l_cdc:
	/* 0xcdc: mov    r13d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 3ULL);
x86_l_ce2:
	/* 0xce2: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0xce2, 0xd2a, x86_l_d2a);
x86_l_ce4:
	/* 0xce4: mov    ebp,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 3ULL);
x86_l_ce9:
	/* 0xce9: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xce9, 0xe11, x86_l_e11);
x86_l_cee:
	/* 0xcee: mov    r13d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 4ULL);
x86_l_cf4:
	/* 0xcf4: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0xcf4, 0xd2a, x86_l_d2a);
x86_l_cf6:
	/* 0xcf6: mov    ebp,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4ULL);
x86_l_cfb:
	/* 0xcfb: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xcfb, 0xe11, x86_l_e11);
x86_l_d00:
	/* 0xd00: mov    r13d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 5ULL);
x86_l_d06:
	/* 0xd06: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0xd06, 0xd2a, x86_l_d2a);
x86_l_d08:
	/* 0xd08: mov    ebp,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 5ULL);
x86_l_d0d:
	/* 0xd0d: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xd0d, 0xe11, x86_l_e11);
x86_l_d12:
	/* 0xd12: mov    r13d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 6ULL);
x86_l_d18:
	/* 0xd18: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0xd18, 0xd2a, x86_l_d2a);
x86_l_d1a:
	/* 0xd1a: mov    ebp,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_d1f:
	/* 0xd1f: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xd1f, 0xe11, x86_l_e11);
x86_l_d24:
	/* 0xd24: mov    r13d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 7ULL);
x86_l_d2a:
	/* 0xd2a: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d2c:
	/* 0xd2c: mov    r15d,DWORD PTR [r12+r14*4+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_d31:
	/* 0xd31: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_d36:
	/* 0xd36: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_d3b:
	/* 0xd3b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_d3e:
	/* 0xd3e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_d43:
	/* 0xd43: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_d46:
	/* 0xd46: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_d48:
	/* 0xd48: cmp    r15d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 6ULL);
x86_l_d4c:
	/* 0xd4c: jne    118 <generic_sleepable_preload+0x118> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd4c, 0x118, x86_l_118);
x86_l_d52:
	/* 0xd52: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d56:
	/* 0xd56: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_d5e:
	/* 0xd5e: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_d63:
	/* 0xd63: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_d65:
	/* 0xd65: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d6a:
	/* 0xd6a: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_d72:
	/* 0xd72: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_d77:
	/* 0xd77: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_d7e:
	/* 0xd7e: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_d83:
	/* 0xd83: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_d85:
	/* 0xd85: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_d88:
	/* 0xd88: je     113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd88, 0x113, x86_l_113);
x86_l_d8e:
	/* 0xd8e: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_d91:
	/* 0xd91: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_d96:
	/* 0xd96: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d98:
	/* 0xd98: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_d9f:
	/* 0xd9f: mov    r12d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RBP, X86_WIDTH_32);
x86_l_da2:
	/* 0xda2: mov    ebp,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_32);
x86_l_da5:
	/* 0xda5: lea    r13,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_daa:
	/* 0xdaa: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_dad:
	/* 0xdad: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_db0:
	/* 0xdb0: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_db2:
	/* 0xdb2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_db4:
	/* 0xdb4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_db9:
	/* 0xdb9: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_dbc:
	/* 0xdbc: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_dbf:
	/* 0xdbf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_dc1:
	/* 0xdc1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_dc4:
	/* 0xdc4: je     113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc4, 0x113, x86_l_113);
x86_l_dca:
	/* 0xdca: test   r12b,r12b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8);
x86_l_dcd:
	/* 0xdcd: je     111 <generic_sleepable_preload+0x111> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdcd, 0x111, x86_l_111);
x86_l_dd3:
	/* 0xdd3: lea    rdi,[rax+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_dd7:
	/* 0xdd7: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_dda:
	/* 0xdda: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_ddf:
	/* 0xddf: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_de4:
	/* 0xde4: mov    rdx,QWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_dec:
	/* 0xdec: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_df1:
	/* 0xdf1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_df3:
	/* 0xdf3: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_df6:
	/* 0xdf6: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_df9:
	/* 0xdf9: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_dfc:
	/* 0xdfc: jns    111 <generic_sleepable_preload+0x111> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdfc, 0x111, x86_l_111);
x86_l_e02:
	/* 0xe02: mov    ebp,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4294967295ULL);
x86_l_e07:
	/* 0xe07: jmp    111 <generic_sleepable_preload+0x111> */
	X86_SIM_X86_JMP(0xe07, 0x111, x86_l_111);
x86_l_e0c:
	/* 0xe0c: mov    ebp,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 7ULL);
x86_l_e11:
	/* 0xe11: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e14:
	/* 0xe14: cmp    r12d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 6ULL);
x86_l_e18:
	/* 0xe18: jne    113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe18, 0x113, x86_l_113);
x86_l_e1e:
	/* 0xe1e: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e22:
	/* 0xe22: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_e2a:
	/* 0xe2a: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_e2f:
	/* 0xe2f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_e31:
	/* 0xe31: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e36:
	/* 0xe36: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_e3e:
	/* 0xe3e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_e43:
	/* 0xe43: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_e4a:
	/* 0xe4a: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_e4f:
	/* 0xe4f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_e51:
	/* 0xe51: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_e54:
	/* 0xe54: je     113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe54, 0x113, x86_l_113);
x86_l_e5a:
	/* 0xe5a: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_e5d:
	/* 0xe5d: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_e62:
	/* 0xe62: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e64:
	/* 0xe64: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_e6b:
	/* 0xe6b: mov    r12d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_R15, X86_WIDTH_32);
x86_l_e6e:
	/* 0xe6e: mov    r15d,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RBP, X86_WIDTH_32);
x86_l_e71:
	/* 0xe71: lea    rbp,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e76:
	/* 0xe76: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_e79:
	/* 0xe79: mov    rsi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_64);
x86_l_e7c:
	/* 0xe7c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_e7e:
	/* 0xe7e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_e80:
	/* 0xe80: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_e85:
	/* 0xe85: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_e88:
	/* 0xe88: mov    rsi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_64);
x86_l_e8b:
	/* 0xe8b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_e8d:
	/* 0xe8d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_e90:
	/* 0xe90: je     113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe90, 0x113, x86_l_113);
x86_l_e96:
	/* 0xe96: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_e99:
	/* 0xe99: test   r12b,r12b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8);
x86_l_e9c:
	/* 0xe9c: je     ec6 <generic_sleepable_preload+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe9c, 0xec6, x86_l_ec6);
x86_l_e9e:
	/* 0xe9e: lea    rdi,[r13+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ea2:
	/* 0xea2: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_ea7:
	/* 0xea7: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_eac:
	/* 0xeac: mov    rdx,QWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_eb4:
	/* 0xeb4: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_eb9:
	/* 0xeb9: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_ebb:
	/* 0xebb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ebe:
	/* 0xebe: jns    ec6 <generic_sleepable_preload+0xec6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xebe, 0xec6, x86_l_ec6);
x86_l_ec0:
	/* 0xec0: mov    r15d,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 4294967295ULL);
x86_l_ec6:
	/* 0xec6: mov    DWORD PTR [r13+0x0],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eca:
	/* 0xeca: jmp    113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JMP(0xeca, 0x113, x86_l_113);
x86_l_ecf:
	/* 0xecf: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_ed1:
	/* 0xed1: mov    r13d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 8ULL);
x86_l_ed7:
	/* 0xed7: jmp    d2c <generic_sleepable_preload+0xd2c> */
	X86_SIM_X86_JMP(0xed7, 0xd2c, x86_l_d2c);
x86_l_edc:
	/* 0xedc: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_edf:
	/* 0xedf: mov    ebp,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 8ULL);
x86_l_ee4:
	/* 0xee4: cmp    r12d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 6ULL);
x86_l_ee8:
	/* 0xee8: jne    113 <generic_sleepable_preload+0x113> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xee8, 0x113, x86_l_113);
x86_l_eee:
	/* 0xeee: jmp    e1e <generic_sleepable_preload+0xe1e> */
	X86_SIM_X86_JMP(0xeee, 0xe1e, x86_l_e1e);
x86_l_ef3:
	/* 0xef3: mov    r13d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 9ULL);
x86_l_ef9:
	/* 0xef9: jmp    d2a <generic_sleepable_preload+0xd2a> */
	X86_SIM_X86_JMP(0xef9, 0xd2a, x86_l_d2a);
x86_l_efe:
	/* 0xefe: mov    ebp,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 9ULL);
x86_l_f03:
	/* 0xf03: jmp    e11 <generic_sleepable_preload+0xe11> */
	X86_SIM_X86_JMP(0xf03, 0xe11, x86_l_e11);
x86_l_f08:
	/* 0xf08: mov    eax,DWORD PTR [r12+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f0d:
	/* 0xf0d: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_f12:
	/* 0xf12: je     1e74 <generic_sleepable_preload+0x1e74> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf12, 0x1e74, x86_l_1e74);
x86_l_f18:
	/* 0xf18: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_f1a:
	/* 0xf1a: js     f4f <generic_sleepable_preload+0xf4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf1a, 0xf4f, x86_l_f4f);
x86_l_f1c:
	/* 0xf1c: mov    eax,DWORD PTR [r12+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f21:
	/* 0xf21: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_f24:
	/* 0xf24: jle    fd7 <generic_sleepable_preload+0xfd7> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xf24, 0xfd7, x86_l_fd7);
x86_l_f2a:
	/* 0xf2a: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_f2d:
	/* 0xf2d: je     1041 <generic_sleepable_preload+0x1041> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf2d, 0x1041, x86_l_1041);
x86_l_f33:
	/* 0xf33: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_f36:
	/* 0xf36: je     1048 <generic_sleepable_preload+0x1048> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf36, 0x1048, x86_l_1048);
x86_l_f3c:
	/* 0xf3c: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_f3f:
	/* 0xf3f: jne    105b <generic_sleepable_preload+0x105b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf3f, 0x105b, x86_l_105b);
x86_l_f45:
	/* 0xf45: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_f4a:
	/* 0xf4a: jmp    1054 <generic_sleepable_preload+0x1054> */
	X86_SIM_X86_JMP(0xf4a, 0x1054, x86_l_1054);
x86_l_f4f:
	/* 0xf4f: movzx  eax,BYTE PTR [r12+0x2c2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 706ULL);
x86_l_f58:
	/* 0xf58: movzx  ecx,WORD PTR [r12+0x2c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 704ULL);
x86_l_f61:
	/* 0xf61: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_f67:
	/* 0xf67: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_f69:
	/* 0xf69: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_f6c:
	/* 0xf6c: jle    fab <generic_sleepable_preload+0xfab> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xf6c, 0xfab, x86_l_fab);
x86_l_f6e:
	/* 0xf6e: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_f71:
	/* 0xf71: jle    fe7 <generic_sleepable_preload+0xfe7> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xf71, 0xfe7, x86_l_fe7);
x86_l_f73:
	/* 0xf73: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_f76:
	/* 0xf76: jle    168f <generic_sleepable_preload+0x168f> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xf76, 0x168f, x86_l_168f);
x86_l_f7c:
	/* 0xf7c: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f81:
	/* 0xf81: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_f84:
	/* 0xf84: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf84, 0x16a3, x86_l_16a3);
x86_l_f8a:
	/* 0xf8a: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_f8f:
	/* 0xf8f: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_f92:
	/* 0xf92: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf92, 0x16a3, x86_l_16a3);
x86_l_f98:
	/* 0xf98: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_f9b:
	/* 0xf9b: jne    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf9b, 0x16b6, x86_l_16b6);
x86_l_fa1:
	/* 0xfa1: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_fa6:
	/* 0xfa6: jmp    16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JMP(0xfa6, 0x16a3, x86_l_16a3);
x86_l_fab:
	/* 0xfab: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_fae:
	/* 0xfae: jg     1014 <generic_sleepable_preload+0x1014> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfae, 0x1014, x86_l_1014);
x86_l_fb0:
	/* 0xfb0: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_fb3:
	/* 0xfb3: jg     1660 <generic_sleepable_preload+0x1660> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfb3, 0x1660, x86_l_1660);
x86_l_fb9:
	/* 0xfb9: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_fbe:
	/* 0xfbe: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_fc0:
	/* 0xfc0: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc0, 0x16a3, x86_l_16a3);
x86_l_fc6:
	/* 0xfc6: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_fc9:
	/* 0xfc9: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_fcc:
	/* 0xfcc: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfcc, 0x16a3, x86_l_16a3);
x86_l_fd2:
	/* 0xfd2: jmp    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JMP(0xfd2, 0x16b6, x86_l_16b6);
x86_l_fd7:
	/* 0xfd7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_fd9:
	/* 0xfd9: je     104f <generic_sleepable_preload+0x104f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfd9, 0x104f, x86_l_104f);
x86_l_fdb:
	/* 0xfdb: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_fde:
	/* 0xfde: jne    105b <generic_sleepable_preload+0x105b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfde, 0x105b, x86_l_105b);
x86_l_fe0:
	/* 0xfe0: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_fe5:
	/* 0xfe5: jmp    1054 <generic_sleepable_preload+0x1054> */
	X86_SIM_X86_JMP(0xfe5, 0x1054, x86_l_1054);
x86_l_fe7:
	/* 0xfe7: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_fea:
	/* 0xfea: jg     1647 <generic_sleepable_preload+0x1647> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfea, 0x1647, x86_l_1647);
x86_l_ff0:
	/* 0xff0: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_ff8:
	/* 0xff8: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_ffb:
	/* 0xffb: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xffb, 0x16a3, x86_l_16a3);
x86_l_1001:
	/* 0x1001: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1006:
	/* 0x1006: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_1009:
	/* 0x1009: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1009, 0x16a3, x86_l_16a3);
x86_l_100f:
	/* 0x100f: jmp    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JMP(0x100f, 0x16b6, x86_l_16b6);
x86_l_1014:
	/* 0x1014: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_1017:
	/* 0x1017: jg     1676 <generic_sleepable_preload+0x1676> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1017, 0x1676, x86_l_1676);
x86_l_101d:
	/* 0x101d: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1025:
	/* 0x1025: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_1028:
	/* 0x1028: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1028, 0x16a3, x86_l_16a3);
x86_l_102e:
	/* 0x102e: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1033:
	/* 0x1033: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_1036:
	/* 0x1036: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1036, 0x16a3, x86_l_16a3);
x86_l_103c:
	/* 0x103c: jmp    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JMP(0x103c, 0x16b6, x86_l_16b6);
x86_l_1041:
	/* 0x1041: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1046:
	/* 0x1046: jmp    1054 <generic_sleepable_preload+0x1054> */
	X86_SIM_X86_JMP(0x1046, 0x1054, x86_l_1054);
x86_l_1048:
	/* 0x1048: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_104d:
	/* 0x104d: jmp    1054 <generic_sleepable_preload+0x1054> */
	X86_SIM_X86_JMP(0x104d, 0x1054, x86_l_1054);
x86_l_104f:
	/* 0x104f: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1054:
	/* 0x1054: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1057:
	/* 0x1057: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_105b:
	/* 0x105b: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_105d:
	/* 0x105d: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_1060:
	/* 0x1060: cmp    WORD PTR [r12+0x76],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 506806140928ULL);
x86_l_1067:
	/* 0x1067: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1067, 0x1d08, x86_l_1d08);
x86_l_106d:
	/* 0x106d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_1074:
	/* 0x1074: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1077:
	/* 0x1077: mov    eax,DWORD PTR [r12+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_107c:
	/* 0x107c: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_107f:
	/* 0x107f: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1083:
	/* 0x1083: movzx  eax,WORD PTR [r12+0x74] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 116ULL);
x86_l_1089:
	/* 0x1089: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_108b:
	/* 0x108b: je     1354 <generic_sleepable_preload+0x1354> */
	X86_SIM_X86_JCC(X86_CC_E, 0x108b, 0x1354, x86_l_1354);
x86_l_1091:
	/* 0x1091: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_1094:
	/* 0x1094: je     10b6 <generic_sleepable_preload+0x10b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1094, 0x10b6, x86_l_10b6);
x86_l_1096:
	/* 0x1096: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1099:
	/* 0x1099: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_109e:
	/* 0x109e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_10a3:
	/* 0x10a3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10a7:
	/* 0x10a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_10ac:
	/* 0x10ac: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_10ae:
	/* 0x10ae: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_10b0:
	/* 0x10b0: js     163d <generic_sleepable_preload+0x163d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10b0, 0x163d, x86_l_163d);
x86_l_10b6:
	/* 0x10b6: cmp    WORD PTR [r12+0x7e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 541165879296ULL);
x86_l_10bd:
	/* 0x10bd: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10bd, 0x1d08, x86_l_1d08);
x86_l_10c3:
	/* 0x10c3: mov    ecx,DWORD PTR [r12+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_10c8:
	/* 0x10c8: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_10cc:
	/* 0x10cc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10d0:
	/* 0x10d0: cmp    WORD PTR [r12+0x7c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_10d7:
	/* 0x10d7: je     10f9 <generic_sleepable_preload+0x10f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10d7, 0x10f9, x86_l_10f9);
x86_l_10d9:
	/* 0x10d9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_10dc:
	/* 0x10dc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_10e1:
	/* 0x10e1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_10e6:
	/* 0x10e6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10ea:
	/* 0x10ea: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_10ef:
	/* 0x10ef: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_10f1:
	/* 0x10f1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_10f3:
	/* 0x10f3: js     1cab <generic_sleepable_preload+0x1cab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10f3, 0x1cab, x86_l_1cab);
x86_l_10f9:
	/* 0x10f9: cmp    WORD PTR [r12+0x86],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 575525617664ULL);
x86_l_1103:
	/* 0x1103: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1103, 0x1d08, x86_l_1d08);
x86_l_1109:
	/* 0x1109: mov    ecx,DWORD PTR [r12+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1111:
	/* 0x1111: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1115:
	/* 0x1115: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1119:
	/* 0x1119: cmp    WORD PTR [r12+0x84],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_1123:
	/* 0x1123: je     1145 <generic_sleepable_preload+0x1145> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1123, 0x1145, x86_l_1145);
x86_l_1125:
	/* 0x1125: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1128:
	/* 0x1128: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_112d:
	/* 0x112d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1132:
	/* 0x1132: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1136:
	/* 0x1136: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_113b:
	/* 0x113b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_113d:
	/* 0x113d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_113f:
	/* 0x113f: js     1cbc <generic_sleepable_preload+0x1cbc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x113f, 0x1cbc, x86_l_1cbc);
x86_l_1145:
	/* 0x1145: cmp    WORD PTR [r12+0x8e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 609885356032ULL);
x86_l_114f:
	/* 0x114f: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x114f, 0x1d08, x86_l_1d08);
x86_l_1155:
	/* 0x1155: mov    ecx,DWORD PTR [r12+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_115d:
	/* 0x115d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1161:
	/* 0x1161: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1165:
	/* 0x1165: cmp    WORD PTR [r12+0x8c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_116f:
	/* 0x116f: je     1191 <generic_sleepable_preload+0x1191> */
	X86_SIM_X86_JCC(X86_CC_E, 0x116f, 0x1191, x86_l_1191);
x86_l_1171:
	/* 0x1171: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1174:
	/* 0x1174: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1179:
	/* 0x1179: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_117e:
	/* 0x117e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1182:
	/* 0x1182: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1187:
	/* 0x1187: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1189:
	/* 0x1189: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_118b:
	/* 0x118b: js     1ccd <generic_sleepable_preload+0x1ccd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x118b, 0x1ccd, x86_l_1ccd);
x86_l_1191:
	/* 0x1191: cmp    WORD PTR [r12+0x96],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 644245094400ULL);
x86_l_119b:
	/* 0x119b: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x119b, 0x1d08, x86_l_1d08);
x86_l_11a1:
	/* 0x11a1: mov    ecx,DWORD PTR [r12+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_11a9:
	/* 0x11a9: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_11ad:
	/* 0x11ad: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11b1:
	/* 0x11b1: cmp    WORD PTR [r12+0x94],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_11bb:
	/* 0x11bb: je     11dd <generic_sleepable_preload+0x11dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11bb, 0x11dd, x86_l_11dd);
x86_l_11bd:
	/* 0x11bd: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_11c0:
	/* 0x11c0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_11c5:
	/* 0x11c5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_11ca:
	/* 0x11ca: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ce:
	/* 0x11ce: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_11d3:
	/* 0x11d3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_11d5:
	/* 0x11d5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_11d7:
	/* 0x11d7: js     1cde <generic_sleepable_preload+0x1cde> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11d7, 0x1cde, x86_l_1cde);
x86_l_11dd:
	/* 0x11dd: cmp    WORD PTR [r12+0x9e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 678604832768ULL);
x86_l_11e7:
	/* 0x11e7: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11e7, 0x1d08, x86_l_1d08);
x86_l_11ed:
	/* 0x11ed: mov    ecx,DWORD PTR [r12+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_11f5:
	/* 0x11f5: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_11f9:
	/* 0x11f9: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11fd:
	/* 0x11fd: cmp    WORD PTR [r12+0x9c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_1207:
	/* 0x1207: je     1229 <generic_sleepable_preload+0x1229> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1207, 0x1229, x86_l_1229);
x86_l_1209:
	/* 0x1209: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_120c:
	/* 0x120c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1211:
	/* 0x1211: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1216:
	/* 0x1216: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_121a:
	/* 0x121a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_121f:
	/* 0x121f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1221:
	/* 0x1221: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1223:
	/* 0x1223: js     1cef <generic_sleepable_preload+0x1cef> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1223, 0x1cef, x86_l_1cef);
x86_l_1229:
	/* 0x1229: cmp    WORD PTR [r12+0xa6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 712964571136ULL);
x86_l_1233:
	/* 0x1233: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1233, 0x1d08, x86_l_1d08);
x86_l_1239:
	/* 0x1239: mov    ecx,DWORD PTR [r12+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1241:
	/* 0x1241: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1245:
	/* 0x1245: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1249:
	/* 0x1249: cmp    WORD PTR [r12+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_1253:
	/* 0x1253: je     1275 <generic_sleepable_preload+0x1275> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1253, 0x1275, x86_l_1275);
x86_l_1255:
	/* 0x1255: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1258:
	/* 0x1258: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_125d:
	/* 0x125d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1262:
	/* 0x1262: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1266:
	/* 0x1266: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_126b:
	/* 0x126b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_126d:
	/* 0x126d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_126f:
	/* 0x126f: js     1d00 <generic_sleepable_preload+0x1d00> */
	X86_SIM_X86_JCC(X86_CC_S, 0x126f, 0x1d00, x86_l_1d00);
x86_l_1275:
	/* 0x1275: cmp    WORD PTR [r12+0xae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 747324309504ULL);
x86_l_127f:
	/* 0x127f: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x127f, 0x1d08, x86_l_1d08);
x86_l_1285:
	/* 0x1285: mov    ecx,DWORD PTR [r12+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_128d:
	/* 0x128d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1291:
	/* 0x1291: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1295:
	/* 0x1295: cmp    WORD PTR [r12+0xac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_129f:
	/* 0x129f: je     12c1 <generic_sleepable_preload+0x12c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x129f, 0x12c1, x86_l_12c1);
x86_l_12a1:
	/* 0x12a1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_12a4:
	/* 0x12a4: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_12a9:
	/* 0x12a9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_12ae:
	/* 0x12ae: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12b2:
	/* 0x12b2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_12b7:
	/* 0x12b7: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_12b9:
	/* 0x12b9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_12bb:
	/* 0x12bb: js     5d06 <generic_sleepable_preload+0x5d06> */
	X86_SIM_X86_JCC(X86_CC_S, 0x12bb, 0x5d06, x86_l_5d06);
x86_l_12c1:
	/* 0x12c1: cmp    WORD PTR [r12+0xb6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 781684047872ULL);
x86_l_12cb:
	/* 0x12cb: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12cb, 0x1d08, x86_l_1d08);
x86_l_12d1:
	/* 0x12d1: mov    ecx,DWORD PTR [r12+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_12d9:
	/* 0x12d9: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_12dd:
	/* 0x12dd: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12e1:
	/* 0x12e1: cmp    WORD PTR [r12+0xb4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113280ULL);
x86_l_12eb:
	/* 0x12eb: je     130d <generic_sleepable_preload+0x130d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12eb, 0x130d, x86_l_130d);
x86_l_12ed:
	/* 0x12ed: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_12f0:
	/* 0x12f0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_12f5:
	/* 0x12f5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_12fa:
	/* 0x12fa: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12fe:
	/* 0x12fe: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1303:
	/* 0x1303: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1305:
	/* 0x1305: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1307:
	/* 0x1307: js     5dec <generic_sleepable_preload+0x5dec> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1307, 0x5dec, x86_l_5dec);
x86_l_130d:
	/* 0x130d: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1312:
	/* 0x1312: cmp    WORD PTR [r12+0xbe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 816043786240ULL);
x86_l_131c:
	/* 0x131c: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x131c, 0x1d08, x86_l_1d08);
x86_l_1322:
	/* 0x1322: mov    ecx,DWORD PTR [r12+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_132a:
	/* 0x132a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_132e:
	/* 0x132e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1332:
	/* 0x1332: cmp    WORD PTR [r12+0xbc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_133c:
	/* 0x133c: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x133c, 0x1d08, x86_l_1d08);
x86_l_1342:
	/* 0x1342: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1345:
	/* 0x1345: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_134a:
	/* 0x134a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_134f:
	/* 0x134f: jmp    1620 <generic_sleepable_preload+0x1620> */
	X86_SIM_X86_JMP(0x134f, 0x1620, x86_l_1620);
x86_l_1354:
	/* 0x1354: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_1357:
	/* 0x1357: je     1379 <generic_sleepable_preload+0x1379> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1357, 0x1379, x86_l_1379);
x86_l_1359:
	/* 0x1359: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_135c:
	/* 0x135c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1361:
	/* 0x1361: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1366:
	/* 0x1366: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_136a:
	/* 0x136a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_136f:
	/* 0x136f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1371:
	/* 0x1371: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1373:
	/* 0x1373: js     163d <generic_sleepable_preload+0x163d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1373, 0x163d, x86_l_163d);
x86_l_1379:
	/* 0x1379: cmp    WORD PTR [r12+0x7e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 541165879296ULL);
x86_l_1380:
	/* 0x1380: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1380, 0x1d08, x86_l_1d08);
x86_l_1386:
	/* 0x1386: mov    ecx,DWORD PTR [r12+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_138b:
	/* 0x138b: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_138f:
	/* 0x138f: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1393:
	/* 0x1393: cmp    WORD PTR [r12+0x7c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_139a:
	/* 0x139a: je     13bc <generic_sleepable_preload+0x13bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x139a, 0x13bc, x86_l_13bc);
x86_l_139c:
	/* 0x139c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_139f:
	/* 0x139f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_13a4:
	/* 0x13a4: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_13a9:
	/* 0x13a9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13ad:
	/* 0x13ad: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13b2:
	/* 0x13b2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_13b4:
	/* 0x13b4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_13b6:
	/* 0x13b6: js     1cab <generic_sleepable_preload+0x1cab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13b6, 0x1cab, x86_l_1cab);
x86_l_13bc:
	/* 0x13bc: cmp    WORD PTR [r12+0x86],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 575525617664ULL);
x86_l_13c6:
	/* 0x13c6: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13c6, 0x1d08, x86_l_1d08);
x86_l_13cc:
	/* 0x13cc: mov    ecx,DWORD PTR [r12+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_13d4:
	/* 0x13d4: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_13d8:
	/* 0x13d8: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13dc:
	/* 0x13dc: cmp    WORD PTR [r12+0x84],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_13e6:
	/* 0x13e6: je     1408 <generic_sleepable_preload+0x1408> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13e6, 0x1408, x86_l_1408);
x86_l_13e8:
	/* 0x13e8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_13eb:
	/* 0x13eb: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_13f0:
	/* 0x13f0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_13f5:
	/* 0x13f5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13f9:
	/* 0x13f9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13fe:
	/* 0x13fe: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1400:
	/* 0x1400: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1402:
	/* 0x1402: js     1cbc <generic_sleepable_preload+0x1cbc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1402, 0x1cbc, x86_l_1cbc);
x86_l_1408:
	/* 0x1408: cmp    WORD PTR [r12+0x8e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 609885356032ULL);
x86_l_1412:
	/* 0x1412: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1412, 0x1d08, x86_l_1d08);
x86_l_1418:
	/* 0x1418: mov    ecx,DWORD PTR [r12+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1420:
	/* 0x1420: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1424:
	/* 0x1424: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1428:
	/* 0x1428: cmp    WORD PTR [r12+0x8c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_1432:
	/* 0x1432: je     1454 <generic_sleepable_preload+0x1454> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1432, 0x1454, x86_l_1454);
x86_l_1434:
	/* 0x1434: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1437:
	/* 0x1437: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_143c:
	/* 0x143c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1441:
	/* 0x1441: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1445:
	/* 0x1445: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_144a:
	/* 0x144a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_144c:
	/* 0x144c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_144e:
	/* 0x144e: js     1ccd <generic_sleepable_preload+0x1ccd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x144e, 0x1ccd, x86_l_1ccd);
x86_l_1454:
	/* 0x1454: cmp    WORD PTR [r12+0x96],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 644245094400ULL);
x86_l_145e:
	/* 0x145e: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x145e, 0x1d08, x86_l_1d08);
x86_l_1464:
	/* 0x1464: mov    ecx,DWORD PTR [r12+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_146c:
	/* 0x146c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1470:
	/* 0x1470: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1474:
	/* 0x1474: cmp    WORD PTR [r12+0x94],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_147e:
	/* 0x147e: je     14a0 <generic_sleepable_preload+0x14a0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x147e, 0x14a0, x86_l_14a0);
x86_l_1480:
	/* 0x1480: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1483:
	/* 0x1483: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1488:
	/* 0x1488: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_148d:
	/* 0x148d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1491:
	/* 0x1491: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1496:
	/* 0x1496: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1498:
	/* 0x1498: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_149a:
	/* 0x149a: js     1cde <generic_sleepable_preload+0x1cde> */
	X86_SIM_X86_JCC(X86_CC_S, 0x149a, 0x1cde, x86_l_1cde);
x86_l_14a0:
	/* 0x14a0: cmp    WORD PTR [r12+0x9e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 678604832768ULL);
x86_l_14aa:
	/* 0x14aa: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14aa, 0x1d08, x86_l_1d08);
x86_l_14b0:
	/* 0x14b0: mov    ecx,DWORD PTR [r12+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_14b8:
	/* 0x14b8: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_14bc:
	/* 0x14bc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14c0:
	/* 0x14c0: cmp    WORD PTR [r12+0x9c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_14ca:
	/* 0x14ca: je     14ec <generic_sleepable_preload+0x14ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14ca, 0x14ec, x86_l_14ec);
x86_l_14cc:
	/* 0x14cc: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_14cf:
	/* 0x14cf: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_14d4:
	/* 0x14d4: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_14d9:
	/* 0x14d9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14dd:
	/* 0x14dd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_14e2:
	/* 0x14e2: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_14e4:
	/* 0x14e4: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_14e6:
	/* 0x14e6: js     1cef <generic_sleepable_preload+0x1cef> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14e6, 0x1cef, x86_l_1cef);
x86_l_14ec:
	/* 0x14ec: cmp    WORD PTR [r12+0xa6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 712964571136ULL);
x86_l_14f6:
	/* 0x14f6: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14f6, 0x1d08, x86_l_1d08);
x86_l_14fc:
	/* 0x14fc: mov    ecx,DWORD PTR [r12+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1504:
	/* 0x1504: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1508:
	/* 0x1508: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_150c:
	/* 0x150c: cmp    WORD PTR [r12+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_1516:
	/* 0x1516: je     1538 <generic_sleepable_preload+0x1538> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1516, 0x1538, x86_l_1538);
x86_l_1518:
	/* 0x1518: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_151b:
	/* 0x151b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1520:
	/* 0x1520: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1525:
	/* 0x1525: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1529:
	/* 0x1529: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_152e:
	/* 0x152e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1530:
	/* 0x1530: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1532:
	/* 0x1532: js     1d00 <generic_sleepable_preload+0x1d00> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1532, 0x1d00, x86_l_1d00);
x86_l_1538:
	/* 0x1538: cmp    WORD PTR [r12+0xae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 747324309504ULL);
x86_l_1542:
	/* 0x1542: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1542, 0x1d08, x86_l_1d08);
x86_l_1548:
	/* 0x1548: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_154b:
	/* 0x154b: mov    ecx,DWORD PTR [r12+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1553:
	/* 0x1553: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1557:
	/* 0x1557: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_155b:
	/* 0x155b: cmp    WORD PTR [r12+0xac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1565:
	/* 0x1565: je     1587 <generic_sleepable_preload+0x1587> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1565, 0x1587, x86_l_1587);
x86_l_1567:
	/* 0x1567: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_156a:
	/* 0x156a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_156f:
	/* 0x156f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1574:
	/* 0x1574: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1578:
	/* 0x1578: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_157d:
	/* 0x157d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_157f:
	/* 0x157f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1581:
	/* 0x1581: js     5d84 <generic_sleepable_preload+0x5d84> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1581, 0x5d84, x86_l_5d84);
x86_l_1587:
	/* 0x1587: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_158c:
	/* 0x158c: cmp    WORD PTR [r12+0xb6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 781684047872ULL);
x86_l_1596:
	/* 0x1596: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_1599:
	/* 0x1599: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1599, 0x1d08, x86_l_1d08);
x86_l_159f:
	/* 0x159f: mov    ecx,DWORD PTR [r12+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_15a7:
	/* 0x15a7: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_15ab:
	/* 0x15ab: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15af:
	/* 0x15af: cmp    WORD PTR [r12+0xb4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113280ULL);
x86_l_15b9:
	/* 0x15b9: je     15db <generic_sleepable_preload+0x15db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15b9, 0x15db, x86_l_15db);
x86_l_15bb:
	/* 0x15bb: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_15be:
	/* 0x15be: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_15c3:
	/* 0x15c3: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_15c8:
	/* 0x15c8: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15cc:
	/* 0x15cc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_15d1:
	/* 0x15d1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_15d3:
	/* 0x15d3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_15d5:
	/* 0x15d5: js     5e7c <generic_sleepable_preload+0x5e7c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15d5, 0x5e7c, x86_l_5e7c);
x86_l_15db:
	/* 0x15db: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15e0:
	/* 0x15e0: cmp    WORD PTR [r12+0xbe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 816043786240ULL);
x86_l_15ea:
	/* 0x15ea: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_15ed:
	/* 0x15ed: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15ed, 0x1d08, x86_l_1d08);
x86_l_15f3:
	/* 0x15f3: mov    ecx,DWORD PTR [r12+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_15fb:
	/* 0x15fb: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_15ff:
	/* 0x15ff: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1603:
	/* 0x1603: cmp    WORD PTR [r12+0xbc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_160d:
	/* 0x160d: je     1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x160d, 0x1d08, x86_l_1d08);
x86_l_1613:
	/* 0x1613: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1616:
	/* 0x1616: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_161b:
	/* 0x161b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1620:
	/* 0x1620: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1624:
	/* 0x1624: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1629:
	/* 0x1629: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_162b:
	/* 0x162b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_162d:
	/* 0x162d: jns    1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x162d, 0x1d08, x86_l_1d08);
x86_l_1633:
	/* 0x1633: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_1638:
	/* 0x1638: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1638, 0x1d05, x86_l_1d05);
x86_l_163d:
	/* 0x163d: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_1642:
	/* 0x1642: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1642, 0x1d05, x86_l_1d05);
x86_l_1647:
	/* 0x1647: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_164f:
	/* 0x164f: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_1652:
	/* 0x1652: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1652, 0x16a3, x86_l_16a3);
x86_l_1654:
	/* 0x1654: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1659:
	/* 0x1659: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_165c:
	/* 0x165c: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x165c, 0x16a3, x86_l_16a3);
x86_l_165e:
	/* 0x165e: jmp    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JMP(0x165e, 0x16b6, x86_l_16b6);
x86_l_1660:
	/* 0x1660: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1665:
	/* 0x1665: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_1668:
	/* 0x1668: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1668, 0x16a3, x86_l_16a3);
x86_l_166a:
	/* 0x166a: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_166f:
	/* 0x166f: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1672:
	/* 0x1672: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1672, 0x16a3, x86_l_16a3);
x86_l_1674:
	/* 0x1674: jmp    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JMP(0x1674, 0x16b6, x86_l_16b6);
x86_l_1676:
	/* 0x1676: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_167e:
	/* 0x167e: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_1681:
	/* 0x1681: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1681, 0x16a3, x86_l_16a3);
x86_l_1683:
	/* 0x1683: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1688:
	/* 0x1688: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_168b:
	/* 0x168b: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x168b, 0x16a3, x86_l_16a3);
x86_l_168d:
	/* 0x168d: jmp    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JMP(0x168d, 0x16b6, x86_l_16b6);
x86_l_168f:
	/* 0x168f: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1694:
	/* 0x1694: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_1697:
	/* 0x1697: je     16a3 <generic_sleepable_preload+0x16a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1697, 0x16a3, x86_l_16a3);
x86_l_1699:
	/* 0x1699: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_169e:
	/* 0x169e: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_16a1:
	/* 0x16a1: jne    16b6 <generic_sleepable_preload+0x16b6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16a1, 0x16b6, x86_l_16b6);
x86_l_16a3:
	/* 0x16a3: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_16a6:
	/* 0x16a6: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_16a8:
	/* 0x16a8: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_16aa:
	/* 0x16aa: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_16af:
	/* 0x16af: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_16b1:
	/* 0x16b1: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_16b6:
	/* 0x16b6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16ba:
	/* 0x16ba: mov    ebp,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16bf:
	/* 0x16bf: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16c1:
	/* 0x16c1: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_16c4:
	/* 0x16c4: cmp    WORD PTR [r12+0x76],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 506806140928ULL);
x86_l_16cb:
	/* 0x16cb: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16cb, 0x1dc9, x86_l_1dc9);
x86_l_16d1:
	/* 0x16d1: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_16d8:
	/* 0x16d8: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_16db:
	/* 0x16db: mov    eax,DWORD PTR [r12+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_16e0:
	/* 0x16e0: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_16e3:
	/* 0x16e3: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e7:
	/* 0x16e7: movzx  eax,WORD PTR [r12+0x74] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 116ULL);
x86_l_16ed:
	/* 0x16ed: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_16ef:
	/* 0x16ef: je     19b8 <generic_sleepable_preload+0x19b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16ef, 0x19b8, x86_l_19b8);
x86_l_16f5:
	/* 0x16f5: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_16f8:
	/* 0x16f8: je     171a <generic_sleepable_preload+0x171a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16f8, 0x171a, x86_l_171a);
x86_l_16fa:
	/* 0x16fa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_16fd:
	/* 0x16fd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1702:
	/* 0x1702: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1707:
	/* 0x1707: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_170b:
	/* 0x170b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1710:
	/* 0x1710: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1712:
	/* 0x1712: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1714:
	/* 0x1714: js     1ca1 <generic_sleepable_preload+0x1ca1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1714, 0x1ca1, x86_l_1ca1);
x86_l_171a:
	/* 0x171a: cmp    WORD PTR [r12+0x7e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 541165879296ULL);
x86_l_1721:
	/* 0x1721: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1721, 0x1dc9, x86_l_1dc9);
x86_l_1727:
	/* 0x1727: mov    ecx,DWORD PTR [r12+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_172c:
	/* 0x172c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1730:
	/* 0x1730: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1734:
	/* 0x1734: cmp    WORD PTR [r12+0x7c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_173b:
	/* 0x173b: je     175d <generic_sleepable_preload+0x175d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x173b, 0x175d, x86_l_175d);
x86_l_173d:
	/* 0x173d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1740:
	/* 0x1740: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1745:
	/* 0x1745: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_174a:
	/* 0x174a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_174e:
	/* 0x174e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1753:
	/* 0x1753: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1755:
	/* 0x1755: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1757:
	/* 0x1757: js     1cb2 <generic_sleepable_preload+0x1cb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1757, 0x1cb2, x86_l_1cb2);
x86_l_175d:
	/* 0x175d: cmp    WORD PTR [r12+0x86],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 575525617664ULL);
x86_l_1767:
	/* 0x1767: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1767, 0x1dc9, x86_l_1dc9);
x86_l_176d:
	/* 0x176d: mov    ecx,DWORD PTR [r12+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1775:
	/* 0x1775: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1779:
	/* 0x1779: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_177d:
	/* 0x177d: cmp    WORD PTR [r12+0x84],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_1787:
	/* 0x1787: je     17a9 <generic_sleepable_preload+0x17a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1787, 0x17a9, x86_l_17a9);
x86_l_1789:
	/* 0x1789: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_178c:
	/* 0x178c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1791:
	/* 0x1791: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1796:
	/* 0x1796: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179a:
	/* 0x179a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_179f:
	/* 0x179f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_17a1:
	/* 0x17a1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_17a3:
	/* 0x17a3: js     1cc3 <generic_sleepable_preload+0x1cc3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x17a3, 0x1cc3, x86_l_1cc3);
x86_l_17a9:
	/* 0x17a9: cmp    WORD PTR [r12+0x8e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 609885356032ULL);
x86_l_17b3:
	/* 0x17b3: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b3, 0x1dc9, x86_l_1dc9);
x86_l_17b9:
	/* 0x17b9: mov    ecx,DWORD PTR [r12+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_17c1:
	/* 0x17c1: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_17c5:
	/* 0x17c5: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c9:
	/* 0x17c9: cmp    WORD PTR [r12+0x8c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_17d3:
	/* 0x17d3: je     17f5 <generic_sleepable_preload+0x17f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17d3, 0x17f5, x86_l_17f5);
x86_l_17d5:
	/* 0x17d5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_17d8:
	/* 0x17d8: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_17dd:
	/* 0x17dd: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_17e2:
	/* 0x17e2: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17e6:
	/* 0x17e6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_17eb:
	/* 0x17eb: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_17ed:
	/* 0x17ed: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_17ef:
	/* 0x17ef: js     1cd4 <generic_sleepable_preload+0x1cd4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x17ef, 0x1cd4, x86_l_1cd4);
x86_l_17f5:
	/* 0x17f5: cmp    WORD PTR [r12+0x96],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 644245094400ULL);
x86_l_17ff:
	/* 0x17ff: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17ff, 0x1dc9, x86_l_1dc9);
x86_l_1805:
	/* 0x1805: mov    ecx,DWORD PTR [r12+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_180d:
	/* 0x180d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1811:
	/* 0x1811: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1815:
	/* 0x1815: cmp    WORD PTR [r12+0x94],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_181f:
	/* 0x181f: je     1841 <generic_sleepable_preload+0x1841> */
	X86_SIM_X86_JCC(X86_CC_E, 0x181f, 0x1841, x86_l_1841);
x86_l_1821:
	/* 0x1821: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1824:
	/* 0x1824: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1829:
	/* 0x1829: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_182e:
	/* 0x182e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1832:
	/* 0x1832: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1837:
	/* 0x1837: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1839:
	/* 0x1839: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_183b:
	/* 0x183b: js     1ce5 <generic_sleepable_preload+0x1ce5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x183b, 0x1ce5, x86_l_1ce5);
x86_l_1841:
	/* 0x1841: cmp    WORD PTR [r12+0x9e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 678604832768ULL);
x86_l_184b:
	/* 0x184b: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184b, 0x1dc9, x86_l_1dc9);
x86_l_1851:
	/* 0x1851: mov    ecx,DWORD PTR [r12+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1859:
	/* 0x1859: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_185d:
	/* 0x185d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1861:
	/* 0x1861: cmp    WORD PTR [r12+0x9c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_186b:
	/* 0x186b: je     188d <generic_sleepable_preload+0x188d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x186b, 0x188d, x86_l_188d);
x86_l_186d:
	/* 0x186d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1870:
	/* 0x1870: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1875:
	/* 0x1875: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_187a:
	/* 0x187a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_187e:
	/* 0x187e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1883:
	/* 0x1883: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1885:
	/* 0x1885: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1887:
	/* 0x1887: js     1cf6 <generic_sleepable_preload+0x1cf6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1887, 0x1cf6, x86_l_1cf6);
x86_l_188d:
	/* 0x188d: cmp    WORD PTR [r12+0xa6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 712964571136ULL);
x86_l_1897:
	/* 0x1897: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1897, 0x1dc9, x86_l_1dc9);
x86_l_189d:
	/* 0x189d: mov    ecx,DWORD PTR [r12+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_18a5:
	/* 0x18a5: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_18a9:
	/* 0x18a9: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ad:
	/* 0x18ad: cmp    WORD PTR [r12+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_18b7:
	/* 0x18b7: je     18d9 <generic_sleepable_preload+0x18d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b7, 0x18d9, x86_l_18d9);
x86_l_18b9:
	/* 0x18b9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_18bc:
	/* 0x18bc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_18c1:
	/* 0x18c1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_18c6:
	/* 0x18c6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ca:
	/* 0x18ca: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_18cf:
	/* 0x18cf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_18d1:
	/* 0x18d1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_18d3:
	/* 0x18d3: js     1dc1 <generic_sleepable_preload+0x1dc1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x18d3, 0x1dc1, x86_l_1dc1);
x86_l_18d9:
	/* 0x18d9: cmp    WORD PTR [r12+0xae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 747324309504ULL);
x86_l_18e3:
	/* 0x18e3: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18e3, 0x1dc9, x86_l_1dc9);
x86_l_18e9:
	/* 0x18e9: mov    ecx,DWORD PTR [r12+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_18f1:
	/* 0x18f1: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_18f5:
	/* 0x18f5: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18f9:
	/* 0x18f9: cmp    WORD PTR [r12+0xac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1903:
	/* 0x1903: je     1925 <generic_sleepable_preload+0x1925> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1903, 0x1925, x86_l_1925);
x86_l_1905:
	/* 0x1905: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1908:
	/* 0x1908: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_190d:
	/* 0x190d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1912:
	/* 0x1912: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1916:
	/* 0x1916: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_191b:
	/* 0x191b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_191d:
	/* 0x191d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_191f:
	/* 0x191f: js     5d13 <generic_sleepable_preload+0x5d13> */
	X86_SIM_X86_JCC(X86_CC_S, 0x191f, 0x5d13, x86_l_5d13);
x86_l_1925:
	/* 0x1925: cmp    WORD PTR [r12+0xb6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 781684047872ULL);
x86_l_192f:
	/* 0x192f: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x192f, 0x1dc9, x86_l_1dc9);
x86_l_1935:
	/* 0x1935: mov    ecx,DWORD PTR [r12+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_193d:
	/* 0x193d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1941:
	/* 0x1941: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1945:
	/* 0x1945: cmp    WORD PTR [r12+0xb4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113280ULL);
x86_l_194f:
	/* 0x194f: je     1971 <generic_sleepable_preload+0x1971> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194f, 0x1971, x86_l_1971);
x86_l_1951:
	/* 0x1951: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1954:
	/* 0x1954: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1959:
	/* 0x1959: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_195e:
	/* 0x195e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1962:
	/* 0x1962: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1967:
	/* 0x1967: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1969:
	/* 0x1969: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_196b:
	/* 0x196b: js     5dfe <generic_sleepable_preload+0x5dfe> */
	X86_SIM_X86_JCC(X86_CC_S, 0x196b, 0x5dfe, x86_l_5dfe);
x86_l_1971:
	/* 0x1971: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1976:
	/* 0x1976: cmp    WORD PTR [r12+0xbe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 816043786240ULL);
x86_l_1980:
	/* 0x1980: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1980, 0x1dc9, x86_l_1dc9);
x86_l_1986:
	/* 0x1986: mov    ecx,DWORD PTR [r12+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_198e:
	/* 0x198e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1992:
	/* 0x1992: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1996:
	/* 0x1996: cmp    WORD PTR [r12+0xbc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_19a0:
	/* 0x19a0: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a0, 0x1dc9, x86_l_1dc9);
x86_l_19a6:
	/* 0x19a6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_19a9:
	/* 0x19a9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_19ae:
	/* 0x19ae: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_19b3:
	/* 0x19b3: jmp    1c84 <generic_sleepable_preload+0x1c84> */
	X86_SIM_X86_JMP(0x19b3, 0x1c84, x86_l_1c84);
x86_l_19b8:
	/* 0x19b8: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_19bb:
	/* 0x19bb: je     19dd <generic_sleepable_preload+0x19dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19bb, 0x19dd, x86_l_19dd);
x86_l_19bd:
	/* 0x19bd: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_19c0:
	/* 0x19c0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_19c5:
	/* 0x19c5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_19ca:
	/* 0x19ca: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19ce:
	/* 0x19ce: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_19d3:
	/* 0x19d3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_19d5:
	/* 0x19d5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_19d7:
	/* 0x19d7: js     1ca1 <generic_sleepable_preload+0x1ca1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19d7, 0x1ca1, x86_l_1ca1);
x86_l_19dd:
	/* 0x19dd: cmp    WORD PTR [r12+0x7e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 541165879296ULL);
x86_l_19e4:
	/* 0x19e4: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19e4, 0x1dc9, x86_l_1dc9);
x86_l_19ea:
	/* 0x19ea: mov    ecx,DWORD PTR [r12+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_19ef:
	/* 0x19ef: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_19f3:
	/* 0x19f3: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f7:
	/* 0x19f7: cmp    WORD PTR [r12+0x7c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_19fe:
	/* 0x19fe: je     1a20 <generic_sleepable_preload+0x1a20> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19fe, 0x1a20, x86_l_1a20);
x86_l_1a00:
	/* 0x1a00: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1a03:
	/* 0x1a03: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1a08:
	/* 0x1a08: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1a0d:
	/* 0x1a0d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a11:
	/* 0x1a11: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a16:
	/* 0x1a16: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1a18:
	/* 0x1a18: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1a1a:
	/* 0x1a1a: js     1cb2 <generic_sleepable_preload+0x1cb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a1a, 0x1cb2, x86_l_1cb2);
x86_l_1a20:
	/* 0x1a20: cmp    WORD PTR [r12+0x86],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 575525617664ULL);
x86_l_1a2a:
	/* 0x1a2a: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a2a, 0x1dc9, x86_l_1dc9);
x86_l_1a30:
	/* 0x1a30: mov    ecx,DWORD PTR [r12+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1a38:
	/* 0x1a38: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1a3c:
	/* 0x1a3c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a40:
	/* 0x1a40: cmp    WORD PTR [r12+0x84],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_1a4a:
	/* 0x1a4a: je     1a6c <generic_sleepable_preload+0x1a6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a4a, 0x1a6c, x86_l_1a6c);
x86_l_1a4c:
	/* 0x1a4c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1a4f:
	/* 0x1a4f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1a54:
	/* 0x1a54: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1a59:
	/* 0x1a59: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a5d:
	/* 0x1a5d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a62:
	/* 0x1a62: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1a64:
	/* 0x1a64: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1a66:
	/* 0x1a66: js     1cc3 <generic_sleepable_preload+0x1cc3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a66, 0x1cc3, x86_l_1cc3);
x86_l_1a6c:
	/* 0x1a6c: cmp    WORD PTR [r12+0x8e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 609885356032ULL);
x86_l_1a76:
	/* 0x1a76: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a76, 0x1dc9, x86_l_1dc9);
x86_l_1a7c:
	/* 0x1a7c: mov    ecx,DWORD PTR [r12+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1a84:
	/* 0x1a84: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1a88:
	/* 0x1a88: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a8c:
	/* 0x1a8c: cmp    WORD PTR [r12+0x8c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_1a96:
	/* 0x1a96: je     1ab8 <generic_sleepable_preload+0x1ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a96, 0x1ab8, x86_l_1ab8);
x86_l_1a98:
	/* 0x1a98: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1a9b:
	/* 0x1a9b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1aa0:
	/* 0x1aa0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1aa5:
	/* 0x1aa5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aa9:
	/* 0x1aa9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1aae:
	/* 0x1aae: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1ab0:
	/* 0x1ab0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1ab2:
	/* 0x1ab2: js     1cd4 <generic_sleepable_preload+0x1cd4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ab2, 0x1cd4, x86_l_1cd4);
x86_l_1ab8:
	/* 0x1ab8: cmp    WORD PTR [r12+0x96],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 644245094400ULL);
x86_l_1ac2:
	/* 0x1ac2: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ac2, 0x1dc9, x86_l_1dc9);
x86_l_1ac8:
	/* 0x1ac8: mov    ecx,DWORD PTR [r12+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1ad0:
	/* 0x1ad0: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1ad4:
	/* 0x1ad4: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ad8:
	/* 0x1ad8: cmp    WORD PTR [r12+0x94],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_1ae2:
	/* 0x1ae2: je     1b04 <generic_sleepable_preload+0x1b04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ae2, 0x1b04, x86_l_1b04);
x86_l_1ae4:
	/* 0x1ae4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1ae7:
	/* 0x1ae7: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1aec:
	/* 0x1aec: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1af1:
	/* 0x1af1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1af5:
	/* 0x1af5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1afa:
	/* 0x1afa: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1afc:
	/* 0x1afc: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1afe:
	/* 0x1afe: js     1ce5 <generic_sleepable_preload+0x1ce5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1afe, 0x1ce5, x86_l_1ce5);
x86_l_1b04:
	/* 0x1b04: cmp    WORD PTR [r12+0x9e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 678604832768ULL);
x86_l_1b0e:
	/* 0x1b0e: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b0e, 0x1dc9, x86_l_1dc9);
x86_l_1b14:
	/* 0x1b14: mov    ecx,DWORD PTR [r12+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1b1c:
	/* 0x1b1c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1b20:
	/* 0x1b20: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b24:
	/* 0x1b24: cmp    WORD PTR [r12+0x9c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_1b2e:
	/* 0x1b2e: je     1b50 <generic_sleepable_preload+0x1b50> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b2e, 0x1b50, x86_l_1b50);
x86_l_1b30:
	/* 0x1b30: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1b33:
	/* 0x1b33: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1b38:
	/* 0x1b38: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1b3d:
	/* 0x1b3d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b41:
	/* 0x1b41: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1b46:
	/* 0x1b46: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1b48:
	/* 0x1b48: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1b4a:
	/* 0x1b4a: js     1cf6 <generic_sleepable_preload+0x1cf6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b4a, 0x1cf6, x86_l_1cf6);
x86_l_1b50:
	/* 0x1b50: cmp    WORD PTR [r12+0xa6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 712964571136ULL);
x86_l_1b5a:
	/* 0x1b5a: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5a, 0x1dc9, x86_l_1dc9);
x86_l_1b60:
	/* 0x1b60: mov    ecx,DWORD PTR [r12+0xa0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1b68:
	/* 0x1b68: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1b6c:
	/* 0x1b6c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b70:
	/* 0x1b70: cmp    WORD PTR [r12+0xa4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_1b7a:
	/* 0x1b7a: je     1b9c <generic_sleepable_preload+0x1b9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b7a, 0x1b9c, x86_l_1b9c);
x86_l_1b7c:
	/* 0x1b7c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1b7f:
	/* 0x1b7f: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1b84:
	/* 0x1b84: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1b89:
	/* 0x1b89: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b8d:
	/* 0x1b8d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1b92:
	/* 0x1b92: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1b94:
	/* 0x1b94: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1b96:
	/* 0x1b96: js     1dc1 <generic_sleepable_preload+0x1dc1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b96, 0x1dc1, x86_l_1dc1);
x86_l_1b9c:
	/* 0x1b9c: cmp    WORD PTR [r12+0xae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 747324309504ULL);
x86_l_1ba6:
	/* 0x1ba6: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ba6, 0x1dc9, x86_l_1dc9);
x86_l_1bac:
	/* 0x1bac: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_1baf:
	/* 0x1baf: mov    ecx,DWORD PTR [r12+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1bb7:
	/* 0x1bb7: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1bbb:
	/* 0x1bbb: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bbf:
	/* 0x1bbf: cmp    WORD PTR [r12+0xac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1bc9:
	/* 0x1bc9: je     1beb <generic_sleepable_preload+0x1beb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bc9, 0x1beb, x86_l_1beb);
x86_l_1bcb:
	/* 0x1bcb: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1bce:
	/* 0x1bce: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1bd3:
	/* 0x1bd3: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1bd8:
	/* 0x1bd8: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bdc:
	/* 0x1bdc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1be1:
	/* 0x1be1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1be3:
	/* 0x1be3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1be5:
	/* 0x1be5: js     5d91 <generic_sleepable_preload+0x5d91> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1be5, 0x5d91, x86_l_5d91);
x86_l_1beb:
	/* 0x1beb: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bf0:
	/* 0x1bf0: cmp    WORD PTR [r12+0xb6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 781684047872ULL);
x86_l_1bfa:
	/* 0x1bfa: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_1bfd:
	/* 0x1bfd: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bfd, 0x1dc9, x86_l_1dc9);
x86_l_1c03:
	/* 0x1c03: mov    ecx,DWORD PTR [r12+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1c0b:
	/* 0x1c0b: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1c0f:
	/* 0x1c0f: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c13:
	/* 0x1c13: cmp    WORD PTR [r12+0xb4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113280ULL);
x86_l_1c1d:
	/* 0x1c1d: je     1c3f <generic_sleepable_preload+0x1c3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c1d, 0x1c3f, x86_l_1c3f);
x86_l_1c1f:
	/* 0x1c1f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1c22:
	/* 0x1c22: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1c27:
	/* 0x1c27: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1c2c:
	/* 0x1c2c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c30:
	/* 0x1c30: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1c35:
	/* 0x1c35: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1c37:
	/* 0x1c37: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1c39:
	/* 0x1c39: js     5e91 <generic_sleepable_preload+0x5e91> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c39, 0x5e91, x86_l_5e91);
x86_l_1c3f:
	/* 0x1c3f: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c44:
	/* 0x1c44: cmp    WORD PTR [r12+0xbe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 816043786240ULL);
x86_l_1c4e:
	/* 0x1c4e: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_1c51:
	/* 0x1c51: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c51, 0x1dc9, x86_l_1dc9);
x86_l_1c57:
	/* 0x1c57: mov    ecx,DWORD PTR [r12+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1c5f:
	/* 0x1c5f: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1c63:
	/* 0x1c63: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c67:
	/* 0x1c67: cmp    WORD PTR [r12+0xbc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_1c71:
	/* 0x1c71: je     1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c71, 0x1dc9, x86_l_1dc9);
x86_l_1c77:
	/* 0x1c77: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1c7a:
	/* 0x1c7a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1c7f:
	/* 0x1c7f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_1c84:
	/* 0x1c84: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c88:
	/* 0x1c88: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1c8d:
	/* 0x1c8d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1c8f:
	/* 0x1c8f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1c91:
	/* 0x1c91: jns    1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c91, 0x1dc9, x86_l_1dc9);
x86_l_1c97:
	/* 0x1c97: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_1c9c:
	/* 0x1c9c: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1c9c, 0x1dc6, x86_l_1dc6);
x86_l_1ca1:
	/* 0x1ca1: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_1ca6:
	/* 0x1ca6: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1ca6, 0x1dc6, x86_l_1dc6);
x86_l_1cab:
	/* 0x1cab: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_1cb0:
	/* 0x1cb0: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1cb0, 0x1d05, x86_l_1d05);
x86_l_1cb2:
	/* 0x1cb2: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_1cb7:
	/* 0x1cb7: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1cb7, 0x1dc6, x86_l_1dc6);
x86_l_1cbc:
	/* 0x1cbc: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_1cc1:
	/* 0x1cc1: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1cc1, 0x1d05, x86_l_1d05);
x86_l_1cc3:
	/* 0x1cc3: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_1cc8:
	/* 0x1cc8: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1cc8, 0x1dc6, x86_l_1dc6);
x86_l_1ccd:
	/* 0x1ccd: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_1cd2:
	/* 0x1cd2: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1cd2, 0x1d05, x86_l_1d05);
x86_l_1cd4:
	/* 0x1cd4: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_1cd9:
	/* 0x1cd9: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1cd9, 0x1dc6, x86_l_1dc6);
x86_l_1cde:
	/* 0x1cde: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_1ce3:
	/* 0x1ce3: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1ce3, 0x1d05, x86_l_1d05);
x86_l_1ce5:
	/* 0x1ce5: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_1cea:
	/* 0x1cea: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1cea, 0x1dc6, x86_l_1dc6);
x86_l_1cef:
	/* 0x1cef: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_1cf4:
	/* 0x1cf4: jmp    1d05 <generic_sleepable_preload+0x1d05> */
	X86_SIM_X86_JMP(0x1cf4, 0x1d05, x86_l_1d05);
x86_l_1cf6:
	/* 0x1cf6: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_1cfb:
	/* 0x1cfb: jmp    1dc6 <generic_sleepable_preload+0x1dc6> */
	X86_SIM_X86_JMP(0x1cfb, 0x1dc6, x86_l_1dc6);
x86_l_1d00:
	/* 0x1d00: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_1d05:
	/* 0x1d05: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1d08:
	/* 0x1d08: mov    ebp,DWORD PTR [r12+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d0d:
	/* 0x1d0d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1d10:
	/* 0x1d10: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1d15:
	/* 0x1d15: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1d1a:
	/* 0x1d1a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1d1f:
	/* 0x1d1f: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_1d22:
	/* 0x1d22: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1d24:
	/* 0x1d24: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_1d27:
	/* 0x1d27: jne    1e74 <generic_sleepable_preload+0x1e74> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d27, 0x1e74, x86_l_1e74);
x86_l_1d2d:
	/* 0x1d2d: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_1d30:
	/* 0x1d30: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d34:
	/* 0x1d34: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_1d39:
	/* 0x1d39: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1d3b:
	/* 0x1d3b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d40:
	/* 0x1d40: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1d48:
	/* 0x1d48: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_1d4f:
	/* 0x1d4f: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1d54:
	/* 0x1d54: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1d59:
	/* 0x1d59: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1d5b:
	/* 0x1d5b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1d5e:
	/* 0x1d5e: je     1e71 <generic_sleepable_preload+0x1e71> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d5e, 0x1e71, x86_l_1e71);
x86_l_1d64:
	/* 0x1d64: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_1d67:
	/* 0x1d67: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_1d6e:
	/* 0x1d6e: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1d70:
	/* 0x1d70: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d75:
	/* 0x1d75: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1d7a:
	/* 0x1d7a: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1d7d:
	/* 0x1d7d: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_1d80:
	/* 0x1d80: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1d82:
	/* 0x1d82: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1d84:
	/* 0x1d84: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1d89:
	/* 0x1d89: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1d8c:
	/* 0x1d8c: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_1d8f:
	/* 0x1d8f: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d94:
	/* 0x1d94: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1d96:
	/* 0x1d96: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1d99:
	/* 0x1d99: je     1e71 <generic_sleepable_preload+0x1e71> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d99, 0x1e71, x86_l_1e71);
x86_l_1d9f:
	/* 0x1d9f: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_1da2:
	/* 0x1da2: je     1e6f <generic_sleepable_preload+0x1e6f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1da2, 0x1e6f, x86_l_1e6f);
x86_l_1da8:
	/* 0x1da8: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1dab:
	/* 0x1dab: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1daf:
	/* 0x1daf: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_1db4:
	/* 0x1db4: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1db7:
	/* 0x1db7: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_1dbc:
	/* 0x1dbc: jmp    1e55 <generic_sleepable_preload+0x1e55> */
	X86_SIM_X86_JMP(0x1dbc, 0x1e55, x86_l_1e55);
x86_l_1dc1:
	/* 0x1dc1: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_1dc6:
	/* 0x1dc6: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1dc9:
	/* 0x1dc9: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_1dcc:
	/* 0x1dcc: jne    1e74 <generic_sleepable_preload+0x1e74> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dcc, 0x1e74, x86_l_1e74);
x86_l_1dd2:
	/* 0x1dd2: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_1dd5:
	/* 0x1dd5: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd9:
	/* 0x1dd9: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_1dde:
	/* 0x1dde: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1de0:
	/* 0x1de0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1de5:
	/* 0x1de5: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1ded:
	/* 0x1ded: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_1df4:
	/* 0x1df4: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1df9:
	/* 0x1df9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1dfe:
	/* 0x1dfe: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1e00:
	/* 0x1e00: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1e03:
	/* 0x1e03: je     1e71 <generic_sleepable_preload+0x1e71> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e03, 0x1e71, x86_l_1e71);
x86_l_1e05:
	/* 0x1e05: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_1e08:
	/* 0x1e08: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_1e0f:
	/* 0x1e0f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1e11:
	/* 0x1e11: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e16:
	/* 0x1e16: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1e1b:
	/* 0x1e1b: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1e1e:
	/* 0x1e1e: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_1e21:
	/* 0x1e21: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1e23:
	/* 0x1e23: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1e25:
	/* 0x1e25: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1e2a:
	/* 0x1e2a: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1e2d:
	/* 0x1e2d: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_1e30:
	/* 0x1e30: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e35:
	/* 0x1e35: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1e37:
	/* 0x1e37: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1e3a:
	/* 0x1e3a: je     1e71 <generic_sleepable_preload+0x1e71> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e3a, 0x1e71, x86_l_1e71);
x86_l_1e3c:
	/* 0x1e3c: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_1e3f:
	/* 0x1e3f: je     1e6f <generic_sleepable_preload+0x1e6f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e3f, 0x1e6f, x86_l_1e6f);
x86_l_1e41:
	/* 0x1e41: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1e44:
	/* 0x1e44: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1e48:
	/* 0x1e48: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_1e4d:
	/* 0x1e4d: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_1e50:
	/* 0x1e50: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_1e55:
	/* 0x1e55: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_1e5a:
	/* 0x1e5a: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_1e5d:
	/* 0x1e5d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_1e5f:
	/* 0x1e5f: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1e62:
	/* 0x1e62: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_1e65:
	/* 0x1e65: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_1e68:
	/* 0x1e68: jns    1e6f <generic_sleepable_preload+0x1e6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e68, 0x1e6f, x86_l_1e6f);
x86_l_1e6a:
	/* 0x1e6a: mov    ebx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4294967295ULL);
x86_l_1e6f:
	/* 0x1e6f: mov    DWORD PTR [rax],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e71:
	/* 0x1e71: mov    r14,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBP, X86_WIDTH_64);
x86_l_1e74:
	/* 0x1e74: mov    eax,DWORD PTR [r12+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1e79:
	/* 0x1e79: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_1e7e:
	/* 0x1e7e: je     2e1c <generic_sleepable_preload+0x2e1c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e7e, 0x2e1c, x86_l_2e1c);
x86_l_1e84:
	/* 0x1e84: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_1e86:
	/* 0x1e86: js     1ebb <generic_sleepable_preload+0x1ebb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e86, 0x1ebb, x86_l_1ebb);
x86_l_1e88:
	/* 0x1e88: mov    eax,DWORD PTR [r12+0x44] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1e8d:
	/* 0x1e8d: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1e90:
	/* 0x1e90: jle    1f3e <generic_sleepable_preload+0x1f3e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1e90, 0x1f3e, x86_l_1f3e);
x86_l_1e96:
	/* 0x1e96: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1e99:
	/* 0x1e99: je     1fa8 <generic_sleepable_preload+0x1fa8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e99, 0x1fa8, x86_l_1fa8);
x86_l_1e9f:
	/* 0x1e9f: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_1ea2:
	/* 0x1ea2: je     1faf <generic_sleepable_preload+0x1faf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea2, 0x1faf, x86_l_1faf);
x86_l_1ea8:
	/* 0x1ea8: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1eab:
	/* 0x1eab: jne    1fc2 <generic_sleepable_preload+0x1fc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eab, 0x1fc2, x86_l_1fc2);
x86_l_1eb1:
	/* 0x1eb1: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1eb6:
	/* 0x1eb6: jmp    1fbb <generic_sleepable_preload+0x1fbb> */
	X86_SIM_X86_JMP(0x1eb6, 0x1fbb, x86_l_1fbb);
x86_l_1ebb:
	/* 0x1ebb: movzx  eax,BYTE PTR [r12+0x2c6] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 710ULL);
x86_l_1ec4:
	/* 0x1ec4: movzx  ecx,WORD PTR [r12+0x2c4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 708ULL);
x86_l_1ecd:
	/* 0x1ecd: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_1ed3:
	/* 0x1ed3: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1ed5:
	/* 0x1ed5: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_1ed8:
	/* 0x1ed8: jle    1f17 <generic_sleepable_preload+0x1f17> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1ed8, 0x1f17, x86_l_1f17);
x86_l_1eda:
	/* 0x1eda: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_1edd:
	/* 0x1edd: jle    1f4e <generic_sleepable_preload+0x1f4e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1edd, 0x1f4e, x86_l_1f4e);
x86_l_1edf:
	/* 0x1edf: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1ee2:
	/* 0x1ee2: jle    2611 <generic_sleepable_preload+0x2611> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1ee2, 0x2611, x86_l_2611);
x86_l_1ee8:
	/* 0x1ee8: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1eed:
	/* 0x1eed: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_1ef0:
	/* 0x1ef0: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef0, 0x2636, x86_l_2636);
x86_l_1ef6:
	/* 0x1ef6: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1efb:
	/* 0x1efb: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_1efe:
	/* 0x1efe: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1efe, 0x2636, x86_l_2636);
x86_l_1f04:
	/* 0x1f04: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1f09:
	/* 0x1f09: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_1f0c:
	/* 0x1f0c: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f0c, 0x2636, x86_l_2636);
x86_l_1f12:
	/* 0x1f12: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x1f12, 0x2649, x86_l_2649);
x86_l_1f17:
	/* 0x1f17: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1f1a:
	/* 0x1f1a: jg     1f7b <generic_sleepable_preload+0x1f7b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1f1a, 0x1f7b, x86_l_1f7b);
x86_l_1f1c:
	/* 0x1f1c: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_1f1f:
	/* 0x1f1f: jg     25e2 <generic_sleepable_preload+0x25e2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1f1f, 0x25e2, x86_l_25e2);
x86_l_1f25:
	/* 0x1f25: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_1f27:
	/* 0x1f27: je     2631 <generic_sleepable_preload+0x2631> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f27, 0x2631, x86_l_2631);
x86_l_1f2d:
	/* 0x1f2d: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_1f30:
	/* 0x1f30: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_1f33:
	/* 0x1f33: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f33, 0x2636, x86_l_2636);
x86_l_1f39:
	/* 0x1f39: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x1f39, 0x2649, x86_l_2649);
x86_l_1f3e:
	/* 0x1f3e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1f40:
	/* 0x1f40: je     1fb6 <generic_sleepable_preload+0x1fb6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f40, 0x1fb6, x86_l_1fb6);
x86_l_1f42:
	/* 0x1f42: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1f45:
	/* 0x1f45: jne    1fc2 <generic_sleepable_preload+0x1fc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f45, 0x1fc2, x86_l_1fc2);
x86_l_1f47:
	/* 0x1f47: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f4c:
	/* 0x1f4c: jmp    1fbb <generic_sleepable_preload+0x1fbb> */
	X86_SIM_X86_JMP(0x1f4c, 0x1fbb, x86_l_1fbb);
x86_l_1f4e:
	/* 0x1f4e: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_1f51:
	/* 0x1f51: jg     25c9 <generic_sleepable_preload+0x25c9> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1f51, 0x25c9, x86_l_25c9);
x86_l_1f57:
	/* 0x1f57: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1f5f:
	/* 0x1f5f: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1f62:
	/* 0x1f62: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f62, 0x2636, x86_l_2636);
x86_l_1f68:
	/* 0x1f68: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f6d:
	/* 0x1f6d: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_1f70:
	/* 0x1f70: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f70, 0x2636, x86_l_2636);
x86_l_1f76:
	/* 0x1f76: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x1f76, 0x2649, x86_l_2649);
x86_l_1f7b:
	/* 0x1f7b: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_1f7e:
	/* 0x1f7e: jg     25f8 <generic_sleepable_preload+0x25f8> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1f7e, 0x25f8, x86_l_25f8);
x86_l_1f84:
	/* 0x1f84: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1f8c:
	/* 0x1f8c: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_1f8f:
	/* 0x1f8f: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f8f, 0x2636, x86_l_2636);
x86_l_1f95:
	/* 0x1f95: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1f9a:
	/* 0x1f9a: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_1f9d:
	/* 0x1f9d: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f9d, 0x2636, x86_l_2636);
x86_l_1fa3:
	/* 0x1fa3: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x1fa3, 0x2649, x86_l_2649);
x86_l_1fa8:
	/* 0x1fa8: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1fad:
	/* 0x1fad: jmp    1fbb <generic_sleepable_preload+0x1fbb> */
	X86_SIM_X86_JMP(0x1fad, 0x1fbb, x86_l_1fbb);
x86_l_1faf:
	/* 0x1faf: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1fb4:
	/* 0x1fb4: jmp    1fbb <generic_sleepable_preload+0x1fbb> */
	X86_SIM_X86_JMP(0x1fb4, 0x1fbb, x86_l_1fbb);
x86_l_1fb6:
	/* 0x1fb6: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1fbb:
	/* 0x1fbb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fbe:
	/* 0x1fbe: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc2:
	/* 0x1fc2: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fc4:
	/* 0x1fc4: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_1fc7:
	/* 0x1fc7: cmp    WORD PTR [r12+0xc6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 850403524608ULL);
x86_l_1fd1:
	/* 0x1fd1: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd1, 0x2caf, x86_l_2caf);
x86_l_1fd7:
	/* 0x1fd7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_1fde:
	/* 0x1fde: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1fe1:
	/* 0x1fe1: mov    eax,DWORD PTR [r12+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1fe9:
	/* 0x1fe9: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1fec:
	/* 0x1fec: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff0:
	/* 0x1ff0: movzx  eax,WORD PTR [r12+0xc4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 196ULL);
x86_l_1ff9:
	/* 0x1ff9: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_1ffb:
	/* 0x1ffb: je     22cd <generic_sleepable_preload+0x22cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ffb, 0x22cd, x86_l_22cd);
x86_l_2001:
	/* 0x2001: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_2004:
	/* 0x2004: je     2026 <generic_sleepable_preload+0x2026> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2004, 0x2026, x86_l_2026);
x86_l_2006:
	/* 0x2006: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2009:
	/* 0x2009: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_200e:
	/* 0x200e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2013:
	/* 0x2013: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2017:
	/* 0x2017: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_201c:
	/* 0x201c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_201e:
	/* 0x201e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2020:
	/* 0x2020: js     25bf <generic_sleepable_preload+0x25bf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2020, 0x25bf, x86_l_25bf);
x86_l_2026:
	/* 0x2026: cmp    WORD PTR [r12+0xce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 884763262976ULL);
x86_l_2030:
	/* 0x2030: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2030, 0x2caf, x86_l_2caf);
x86_l_2036:
	/* 0x2036: mov    ecx,DWORD PTR [r12+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_203e:
	/* 0x203e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2042:
	/* 0x2042: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2046:
	/* 0x2046: cmp    WORD PTR [r12+0xcc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_2050:
	/* 0x2050: je     2072 <generic_sleepable_preload+0x2072> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2050, 0x2072, x86_l_2072);
x86_l_2052:
	/* 0x2052: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2055:
	/* 0x2055: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_205a:
	/* 0x205a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_205f:
	/* 0x205f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2063:
	/* 0x2063: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2068:
	/* 0x2068: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_206a:
	/* 0x206a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_206c:
	/* 0x206c: js     2627 <generic_sleepable_preload+0x2627> */
	X86_SIM_X86_JCC(X86_CC_S, 0x206c, 0x2627, x86_l_2627);
x86_l_2072:
	/* 0x2072: cmp    WORD PTR [r12+0xd6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 919123001344ULL);
x86_l_207c:
	/* 0x207c: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207c, 0x2caf, x86_l_2caf);
x86_l_2082:
	/* 0x2082: mov    ecx,DWORD PTR [r12+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_208a:
	/* 0x208a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_208e:
	/* 0x208e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2092:
	/* 0x2092: cmp    WORD PTR [r12+0xd4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_209c:
	/* 0x209c: je     20be <generic_sleepable_preload+0x20be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x209c, 0x20be, x86_l_20be);
x86_l_209e:
	/* 0x209e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_20a1:
	/* 0x20a1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_20a6:
	/* 0x20a6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_20ab:
	/* 0x20ab: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20af:
	/* 0x20af: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_20b4:
	/* 0x20b4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_20b6:
	/* 0x20b6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_20b8:
	/* 0x20b8: js     2c63 <generic_sleepable_preload+0x2c63> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20b8, 0x2c63, x86_l_2c63);
x86_l_20be:
	/* 0x20be: cmp    WORD PTR [r12+0xde],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 953482739712ULL);
x86_l_20c8:
	/* 0x20c8: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20c8, 0x2caf, x86_l_2caf);
x86_l_20ce:
	/* 0x20ce: mov    ecx,DWORD PTR [r12+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_20d6:
	/* 0x20d6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_20da:
	/* 0x20da: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20de:
	/* 0x20de: cmp    WORD PTR [r12+0xdc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 944892805120ULL);
x86_l_20e8:
	/* 0x20e8: je     210a <generic_sleepable_preload+0x210a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e8, 0x210a, x86_l_210a);
x86_l_20ea:
	/* 0x20ea: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_20ed:
	/* 0x20ed: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_20f2:
	/* 0x20f2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_20f7:
	/* 0x20f7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20fb:
	/* 0x20fb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2100:
	/* 0x2100: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2102:
	/* 0x2102: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2104:
	/* 0x2104: js     2c74 <generic_sleepable_preload+0x2c74> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2104, 0x2c74, x86_l_2c74);
x86_l_210a:
	/* 0x210a: cmp    WORD PTR [r12+0xe6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 987842478080ULL);
x86_l_2114:
	/* 0x2114: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2114, 0x2caf, x86_l_2caf);
x86_l_211a:
	/* 0x211a: mov    ecx,DWORD PTR [r12+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2122:
	/* 0x2122: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2126:
	/* 0x2126: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_212a:
	/* 0x212a: cmp    WORD PTR [r12+0xe4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 979252543488ULL);
x86_l_2134:
	/* 0x2134: je     2156 <generic_sleepable_preload+0x2156> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2134, 0x2156, x86_l_2156);
x86_l_2136:
	/* 0x2136: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2139:
	/* 0x2139: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_213e:
	/* 0x213e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2143:
	/* 0x2143: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2147:
	/* 0x2147: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_214c:
	/* 0x214c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_214e:
	/* 0x214e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2150:
	/* 0x2150: js     2c85 <generic_sleepable_preload+0x2c85> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2150, 0x2c85, x86_l_2c85);
x86_l_2156:
	/* 0x2156: cmp    WORD PTR [r12+0xee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1022202216448ULL);
x86_l_2160:
	/* 0x2160: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2160, 0x2caf, x86_l_2caf);
x86_l_2166:
	/* 0x2166: mov    ecx,DWORD PTR [r12+0xe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_216e:
	/* 0x216e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2172:
	/* 0x2172: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2176:
	/* 0x2176: cmp    WORD PTR [r12+0xec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_2180:
	/* 0x2180: je     21a2 <generic_sleepable_preload+0x21a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2180, 0x21a2, x86_l_21a2);
x86_l_2182:
	/* 0x2182: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2185:
	/* 0x2185: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_218a:
	/* 0x218a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_218f:
	/* 0x218f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2193:
	/* 0x2193: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2198:
	/* 0x2198: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_219a:
	/* 0x219a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_219c:
	/* 0x219c: js     2c96 <generic_sleepable_preload+0x2c96> */
	X86_SIM_X86_JCC(X86_CC_S, 0x219c, 0x2c96, x86_l_2c96);
x86_l_21a2:
	/* 0x21a2: cmp    WORD PTR [r12+0xf6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1056561954816ULL);
x86_l_21ac:
	/* 0x21ac: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ac, 0x2caf, x86_l_2caf);
x86_l_21b2:
	/* 0x21b2: mov    ecx,DWORD PTR [r12+0xf0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_21ba:
	/* 0x21ba: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_21be:
	/* 0x21be: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21c2:
	/* 0x21c2: cmp    WORD PTR [r12+0xf4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_21cc:
	/* 0x21cc: je     21ee <generic_sleepable_preload+0x21ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21cc, 0x21ee, x86_l_21ee);
x86_l_21ce:
	/* 0x21ce: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_21d1:
	/* 0x21d1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_21d6:
	/* 0x21d6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_21db:
	/* 0x21db: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21df:
	/* 0x21df: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21e4:
	/* 0x21e4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_21e6:
	/* 0x21e6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_21e8:
	/* 0x21e8: js     2ca7 <generic_sleepable_preload+0x2ca7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21e8, 0x2ca7, x86_l_2ca7);
x86_l_21ee:
	/* 0x21ee: cmp    WORD PTR [r12+0xfe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1090921693184ULL);
x86_l_21f8:
	/* 0x21f8: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21f8, 0x2caf, x86_l_2caf);
x86_l_21fe:
	/* 0x21fe: mov    ecx,DWORD PTR [r12+0xf8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2206:
	/* 0x2206: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_220a:
	/* 0x220a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_220e:
	/* 0x220e: cmp    WORD PTR [r12+0xfc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_2218:
	/* 0x2218: je     223a <generic_sleepable_preload+0x223a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2218, 0x223a, x86_l_223a);
x86_l_221a:
	/* 0x221a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_221d:
	/* 0x221d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2222:
	/* 0x2222: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2227:
	/* 0x2227: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_222b:
	/* 0x222b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2230:
	/* 0x2230: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2232:
	/* 0x2232: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2234:
	/* 0x2234: js     5d20 <generic_sleepable_preload+0x5d20> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2234, 0x5d20, x86_l_5d20);
x86_l_223a:
	/* 0x223a: cmp    WORD PTR [r12+0x106],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1125281431552ULL);
x86_l_2244:
	/* 0x2244: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2244, 0x2caf, x86_l_2caf);
x86_l_224a:
	/* 0x224a: mov    ecx,DWORD PTR [r12+0x100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_2252:
	/* 0x2252: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2256:
	/* 0x2256: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_225a:
	/* 0x225a: cmp    WORD PTR [r12+0x104],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1116691496960ULL);
x86_l_2264:
	/* 0x2264: je     2286 <generic_sleepable_preload+0x2286> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2264, 0x2286, x86_l_2286);
x86_l_2266:
	/* 0x2266: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2269:
	/* 0x2269: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_226e:
	/* 0x226e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2273:
	/* 0x2273: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2277:
	/* 0x2277: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_227c:
	/* 0x227c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_227e:
	/* 0x227e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2280:
	/* 0x2280: js     5e10 <generic_sleepable_preload+0x5e10> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2280, 0x5e10, x86_l_5e10);
x86_l_2286:
	/* 0x2286: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_228b:
	/* 0x228b: cmp    WORD PTR [r12+0x10e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1159641169920ULL);
x86_l_2295:
	/* 0x2295: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2295, 0x2caf, x86_l_2caf);
x86_l_229b:
	/* 0x229b: mov    ecx,DWORD PTR [r12+0x108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_22a3:
	/* 0x22a3: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_22a7:
	/* 0x22a7: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ab:
	/* 0x22ab: cmp    WORD PTR [r12+0x10c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1151051235328ULL);
x86_l_22b5:
	/* 0x22b5: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b5, 0x2caf, x86_l_2caf);
x86_l_22bb:
	/* 0x22bb: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_22be:
	/* 0x22be: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_22c3:
	/* 0x22c3: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_22c8:
	/* 0x22c8: jmp    25a2 <generic_sleepable_preload+0x25a2> */
	X86_SIM_X86_JMP(0x22c8, 0x25a2, x86_l_25a2);
x86_l_22cd:
	/* 0x22cd: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_22d0:
	/* 0x22d0: je     22f2 <generic_sleepable_preload+0x22f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22d0, 0x22f2, x86_l_22f2);
x86_l_22d2:
	/* 0x22d2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_22d5:
	/* 0x22d5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_22da:
	/* 0x22da: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_22df:
	/* 0x22df: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22e3:
	/* 0x22e3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_22e8:
	/* 0x22e8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_22ea:
	/* 0x22ea: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_22ec:
	/* 0x22ec: js     25bf <generic_sleepable_preload+0x25bf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22ec, 0x25bf, x86_l_25bf);
x86_l_22f2:
	/* 0x22f2: cmp    WORD PTR [r12+0xce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 884763262976ULL);
x86_l_22fc:
	/* 0x22fc: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22fc, 0x2caf, x86_l_2caf);
x86_l_2302:
	/* 0x2302: mov    ecx,DWORD PTR [r12+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_230a:
	/* 0x230a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_230e:
	/* 0x230e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2312:
	/* 0x2312: cmp    WORD PTR [r12+0xcc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_231c:
	/* 0x231c: je     233e <generic_sleepable_preload+0x233e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x231c, 0x233e, x86_l_233e);
x86_l_231e:
	/* 0x231e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2321:
	/* 0x2321: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2326:
	/* 0x2326: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_232b:
	/* 0x232b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_232f:
	/* 0x232f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2334:
	/* 0x2334: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2336:
	/* 0x2336: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2338:
	/* 0x2338: js     2627 <generic_sleepable_preload+0x2627> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2338, 0x2627, x86_l_2627);
x86_l_233e:
	/* 0x233e: cmp    WORD PTR [r12+0xd6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 919123001344ULL);
x86_l_2348:
	/* 0x2348: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2348, 0x2caf, x86_l_2caf);
x86_l_234e:
	/* 0x234e: mov    ecx,DWORD PTR [r12+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2356:
	/* 0x2356: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_235a:
	/* 0x235a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_235e:
	/* 0x235e: cmp    WORD PTR [r12+0xd4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_2368:
	/* 0x2368: je     238a <generic_sleepable_preload+0x238a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2368, 0x238a, x86_l_238a);
x86_l_236a:
	/* 0x236a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_236d:
	/* 0x236d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2372:
	/* 0x2372: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2377:
	/* 0x2377: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_237b:
	/* 0x237b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2380:
	/* 0x2380: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2382:
	/* 0x2382: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2384:
	/* 0x2384: js     2c63 <generic_sleepable_preload+0x2c63> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2384, 0x2c63, x86_l_2c63);
x86_l_238a:
	/* 0x238a: cmp    WORD PTR [r12+0xde],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 953482739712ULL);
x86_l_2394:
	/* 0x2394: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2394, 0x2caf, x86_l_2caf);
x86_l_239a:
	/* 0x239a: mov    ecx,DWORD PTR [r12+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_23a2:
	/* 0x23a2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_23a6:
	/* 0x23a6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23aa:
	/* 0x23aa: cmp    WORD PTR [r12+0xdc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 944892805120ULL);
x86_l_23b4:
	/* 0x23b4: je     23d6 <generic_sleepable_preload+0x23d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23b4, 0x23d6, x86_l_23d6);
x86_l_23b6:
	/* 0x23b6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_23b9:
	/* 0x23b9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_23be:
	/* 0x23be: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_23c3:
	/* 0x23c3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23c7:
	/* 0x23c7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_23cc:
	/* 0x23cc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_23ce:
	/* 0x23ce: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_23d0:
	/* 0x23d0: js     2c74 <generic_sleepable_preload+0x2c74> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23d0, 0x2c74, x86_l_2c74);
x86_l_23d6:
	/* 0x23d6: cmp    WORD PTR [r12+0xe6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 987842478080ULL);
x86_l_23e0:
	/* 0x23e0: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23e0, 0x2caf, x86_l_2caf);
x86_l_23e6:
	/* 0x23e6: mov    ecx,DWORD PTR [r12+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_23ee:
	/* 0x23ee: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_23f2:
	/* 0x23f2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f6:
	/* 0x23f6: cmp    WORD PTR [r12+0xe4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 979252543488ULL);
x86_l_2400:
	/* 0x2400: je     2422 <generic_sleepable_preload+0x2422> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2400, 0x2422, x86_l_2422);
x86_l_2402:
	/* 0x2402: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2405:
	/* 0x2405: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_240a:
	/* 0x240a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_240f:
	/* 0x240f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2413:
	/* 0x2413: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2418:
	/* 0x2418: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_241a:
	/* 0x241a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_241c:
	/* 0x241c: js     2c85 <generic_sleepable_preload+0x2c85> */
	X86_SIM_X86_JCC(X86_CC_S, 0x241c, 0x2c85, x86_l_2c85);
x86_l_2422:
	/* 0x2422: cmp    WORD PTR [r12+0xee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1022202216448ULL);
x86_l_242c:
	/* 0x242c: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x242c, 0x2caf, x86_l_2caf);
x86_l_2432:
	/* 0x2432: mov    ecx,DWORD PTR [r12+0xe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_243a:
	/* 0x243a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_243e:
	/* 0x243e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2442:
	/* 0x2442: cmp    WORD PTR [r12+0xec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_244c:
	/* 0x244c: je     246e <generic_sleepable_preload+0x246e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244c, 0x246e, x86_l_246e);
x86_l_244e:
	/* 0x244e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2451:
	/* 0x2451: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2456:
	/* 0x2456: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_245b:
	/* 0x245b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_245f:
	/* 0x245f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2464:
	/* 0x2464: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2466:
	/* 0x2466: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2468:
	/* 0x2468: js     2c96 <generic_sleepable_preload+0x2c96> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2468, 0x2c96, x86_l_2c96);
x86_l_246e:
	/* 0x246e: cmp    WORD PTR [r12+0xf6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1056561954816ULL);
x86_l_2478:
	/* 0x2478: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2478, 0x2caf, x86_l_2caf);
x86_l_247e:
	/* 0x247e: mov    ecx,DWORD PTR [r12+0xf0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_2486:
	/* 0x2486: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_248a:
	/* 0x248a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248e:
	/* 0x248e: cmp    WORD PTR [r12+0xf4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_2498:
	/* 0x2498: je     24ba <generic_sleepable_preload+0x24ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2498, 0x24ba, x86_l_24ba);
x86_l_249a:
	/* 0x249a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_249d:
	/* 0x249d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_24a2:
	/* 0x24a2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_24a7:
	/* 0x24a7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24ab:
	/* 0x24ab: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_24b0:
	/* 0x24b0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_24b2:
	/* 0x24b2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_24b4:
	/* 0x24b4: js     2ca7 <generic_sleepable_preload+0x2ca7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24b4, 0x2ca7, x86_l_2ca7);
x86_l_24ba:
	/* 0x24ba: cmp    WORD PTR [r12+0xfe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1090921693184ULL);
x86_l_24c4:
	/* 0x24c4: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c4, 0x2caf, x86_l_2caf);
x86_l_24ca:
	/* 0x24ca: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_24cd:
	/* 0x24cd: mov    ecx,DWORD PTR [r12+0xf8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_24d5:
	/* 0x24d5: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_24d9:
	/* 0x24d9: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24dd:
	/* 0x24dd: cmp    WORD PTR [r12+0xfc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_24e7:
	/* 0x24e7: je     2509 <generic_sleepable_preload+0x2509> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24e7, 0x2509, x86_l_2509);
x86_l_24e9:
	/* 0x24e9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_24ec:
	/* 0x24ec: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_24f1:
	/* 0x24f1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_24f6:
	/* 0x24f6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24fa:
	/* 0x24fa: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_24ff:
	/* 0x24ff: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2501:
	/* 0x2501: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2503:
	/* 0x2503: js     5d9e <generic_sleepable_preload+0x5d9e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2503, 0x5d9e, x86_l_5d9e);
x86_l_2509:
	/* 0x2509: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_250e:
	/* 0x250e: cmp    WORD PTR [r12+0x106],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1125281431552ULL);
x86_l_2518:
	/* 0x2518: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_251b:
	/* 0x251b: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x251b, 0x2caf, x86_l_2caf);
x86_l_2521:
	/* 0x2521: mov    ecx,DWORD PTR [r12+0x100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_2529:
	/* 0x2529: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_252d:
	/* 0x252d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2531:
	/* 0x2531: cmp    WORD PTR [r12+0x104],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1116691496960ULL);
x86_l_253b:
	/* 0x253b: je     255d <generic_sleepable_preload+0x255d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x253b, 0x255d, x86_l_255d);
x86_l_253d:
	/* 0x253d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2540:
	/* 0x2540: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2545:
	/* 0x2545: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_254a:
	/* 0x254a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_254e:
	/* 0x254e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2553:
	/* 0x2553: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2555:
	/* 0x2555: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2557:
	/* 0x2557: js     5ea6 <generic_sleepable_preload+0x5ea6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2557, 0x5ea6, x86_l_5ea6);
x86_l_255d:
	/* 0x255d: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2562:
	/* 0x2562: cmp    WORD PTR [r12+0x10e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1159641169920ULL);
x86_l_256c:
	/* 0x256c: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_256f:
	/* 0x256f: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x256f, 0x2caf, x86_l_2caf);
x86_l_2575:
	/* 0x2575: mov    ecx,DWORD PTR [r12+0x108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_257d:
	/* 0x257d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2581:
	/* 0x2581: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2585:
	/* 0x2585: cmp    WORD PTR [r12+0x10c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1151051235328ULL);
x86_l_258f:
	/* 0x258f: je     2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x258f, 0x2caf, x86_l_2caf);
x86_l_2595:
	/* 0x2595: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2598:
	/* 0x2598: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_259d:
	/* 0x259d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_25a2:
	/* 0x25a2: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25a6:
	/* 0x25a6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_25ab:
	/* 0x25ab: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_25ad:
	/* 0x25ad: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_25af:
	/* 0x25af: jns    2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25af, 0x2caf, x86_l_2caf);
x86_l_25b5:
	/* 0x25b5: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_25ba:
	/* 0x25ba: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x25ba, 0x2cac, x86_l_2cac);
x86_l_25bf:
	/* 0x25bf: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_25c4:
	/* 0x25c4: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x25c4, 0x2cac, x86_l_2cac);
x86_l_25c9:
	/* 0x25c9: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_25d1:
	/* 0x25d1: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_25d4:
	/* 0x25d4: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25d4, 0x2636, x86_l_2636);
x86_l_25d6:
	/* 0x25d6: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25db:
	/* 0x25db: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_25de:
	/* 0x25de: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25de, 0x2636, x86_l_2636);
x86_l_25e0:
	/* 0x25e0: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x25e0, 0x2649, x86_l_2649);
x86_l_25e2:
	/* 0x25e2: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_25e7:
	/* 0x25e7: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_25ea:
	/* 0x25ea: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ea, 0x2636, x86_l_2636);
x86_l_25ec:
	/* 0x25ec: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_25f1:
	/* 0x25f1: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_25f4:
	/* 0x25f4: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f4, 0x2636, x86_l_2636);
x86_l_25f6:
	/* 0x25f6: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x25f6, 0x2649, x86_l_2649);
x86_l_25f8:
	/* 0x25f8: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2600:
	/* 0x2600: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_2603:
	/* 0x2603: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2603, 0x2636, x86_l_2636);
x86_l_2605:
	/* 0x2605: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_260a:
	/* 0x260a: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_260d:
	/* 0x260d: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x260d, 0x2636, x86_l_2636);
x86_l_260f:
	/* 0x260f: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x260f, 0x2649, x86_l_2649);
x86_l_2611:
	/* 0x2611: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2616:
	/* 0x2616: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_2619:
	/* 0x2619: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2619, 0x2636, x86_l_2636);
x86_l_261b:
	/* 0x261b: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2620:
	/* 0x2620: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2623:
	/* 0x2623: je     2636 <generic_sleepable_preload+0x2636> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2623, 0x2636, x86_l_2636);
x86_l_2625:
	/* 0x2625: jmp    2649 <generic_sleepable_preload+0x2649> */
	X86_SIM_X86_JMP(0x2625, 0x2649, x86_l_2649);
x86_l_2627:
	/* 0x2627: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_262c:
	/* 0x262c: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x262c, 0x2cac, x86_l_2cac);
x86_l_2631:
	/* 0x2631: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2636:
	/* 0x2636: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_2639:
	/* 0x2639: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_263b:
	/* 0x263b: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_263d:
	/* 0x263d: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_2642:
	/* 0x2642: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2644:
	/* 0x2644: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_2649:
	/* 0x2649: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_264d:
	/* 0x264d: mov    ebp,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2652:
	/* 0x2652: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2654:
	/* 0x2654: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_2657:
	/* 0x2657: cmp    WORD PTR [r12+0xc6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 850403524608ULL);
x86_l_2661:
	/* 0x2661: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2661, 0x2d70, x86_l_2d70);
x86_l_2667:
	/* 0x2667: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_266e:
	/* 0x266e: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2671:
	/* 0x2671: mov    eax,DWORD PTR [r12+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2679:
	/* 0x2679: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_267c:
	/* 0x267c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2680:
	/* 0x2680: movzx  eax,WORD PTR [r12+0xc4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 196ULL);
x86_l_2689:
	/* 0x2689: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_268b:
	/* 0x268b: je     295d <generic_sleepable_preload+0x295d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x268b, 0x295d, x86_l_295d);
x86_l_2691:
	/* 0x2691: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_2694:
	/* 0x2694: je     26b6 <generic_sleepable_preload+0x26b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2694, 0x26b6, x86_l_26b6);
x86_l_2696:
	/* 0x2696: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2699:
	/* 0x2699: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_269e:
	/* 0x269e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_26a3:
	/* 0x26a3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26a7:
	/* 0x26a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_26ac:
	/* 0x26ac: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_26ae:
	/* 0x26ae: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_26b0:
	/* 0x26b0: js     2c4f <generic_sleepable_preload+0x2c4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26b0, 0x2c4f, x86_l_2c4f);
x86_l_26b6:
	/* 0x26b6: cmp    WORD PTR [r12+0xce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 884763262976ULL);
x86_l_26c0:
	/* 0x26c0: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26c0, 0x2d70, x86_l_2d70);
x86_l_26c6:
	/* 0x26c6: mov    ecx,DWORD PTR [r12+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_26ce:
	/* 0x26ce: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_26d2:
	/* 0x26d2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26d6:
	/* 0x26d6: cmp    WORD PTR [r12+0xcc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_26e0:
	/* 0x26e0: je     2702 <generic_sleepable_preload+0x2702> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e0, 0x2702, x86_l_2702);
x86_l_26e2:
	/* 0x26e2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_26e5:
	/* 0x26e5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_26ea:
	/* 0x26ea: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_26ef:
	/* 0x26ef: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f3:
	/* 0x26f3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_26f8:
	/* 0x26f8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_26fa:
	/* 0x26fa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_26fc:
	/* 0x26fc: js     2c59 <generic_sleepable_preload+0x2c59> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26fc, 0x2c59, x86_l_2c59);
x86_l_2702:
	/* 0x2702: cmp    WORD PTR [r12+0xd6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 919123001344ULL);
x86_l_270c:
	/* 0x270c: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x270c, 0x2d70, x86_l_2d70);
x86_l_2712:
	/* 0x2712: mov    ecx,DWORD PTR [r12+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_271a:
	/* 0x271a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_271e:
	/* 0x271e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2722:
	/* 0x2722: cmp    WORD PTR [r12+0xd4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_272c:
	/* 0x272c: je     274e <generic_sleepable_preload+0x274e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x272c, 0x274e, x86_l_274e);
x86_l_272e:
	/* 0x272e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2731:
	/* 0x2731: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2736:
	/* 0x2736: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_273b:
	/* 0x273b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_273f:
	/* 0x273f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2744:
	/* 0x2744: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2746:
	/* 0x2746: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2748:
	/* 0x2748: js     2c6a <generic_sleepable_preload+0x2c6a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2748, 0x2c6a, x86_l_2c6a);
x86_l_274e:
	/* 0x274e: cmp    WORD PTR [r12+0xde],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 953482739712ULL);
x86_l_2758:
	/* 0x2758: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2758, 0x2d70, x86_l_2d70);
x86_l_275e:
	/* 0x275e: mov    ecx,DWORD PTR [r12+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2766:
	/* 0x2766: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_276a:
	/* 0x276a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_276e:
	/* 0x276e: cmp    WORD PTR [r12+0xdc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 944892805120ULL);
x86_l_2778:
	/* 0x2778: je     279a <generic_sleepable_preload+0x279a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2778, 0x279a, x86_l_279a);
x86_l_277a:
	/* 0x277a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_277d:
	/* 0x277d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2782:
	/* 0x2782: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2787:
	/* 0x2787: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_278b:
	/* 0x278b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2790:
	/* 0x2790: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2792:
	/* 0x2792: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2794:
	/* 0x2794: js     2c7b <generic_sleepable_preload+0x2c7b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2794, 0x2c7b, x86_l_2c7b);
x86_l_279a:
	/* 0x279a: cmp    WORD PTR [r12+0xe6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 987842478080ULL);
x86_l_27a4:
	/* 0x27a4: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a4, 0x2d70, x86_l_2d70);
x86_l_27aa:
	/* 0x27aa: mov    ecx,DWORD PTR [r12+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_27b2:
	/* 0x27b2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_27b6:
	/* 0x27b6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ba:
	/* 0x27ba: cmp    WORD PTR [r12+0xe4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 979252543488ULL);
x86_l_27c4:
	/* 0x27c4: je     27e6 <generic_sleepable_preload+0x27e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c4, 0x27e6, x86_l_27e6);
x86_l_27c6:
	/* 0x27c6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_27c9:
	/* 0x27c9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_27ce:
	/* 0x27ce: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_27d3:
	/* 0x27d3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d7:
	/* 0x27d7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_27dc:
	/* 0x27dc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_27de:
	/* 0x27de: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_27e0:
	/* 0x27e0: js     2c8c <generic_sleepable_preload+0x2c8c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27e0, 0x2c8c, x86_l_2c8c);
x86_l_27e6:
	/* 0x27e6: cmp    WORD PTR [r12+0xee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1022202216448ULL);
x86_l_27f0:
	/* 0x27f0: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f0, 0x2d70, x86_l_2d70);
x86_l_27f6:
	/* 0x27f6: mov    ecx,DWORD PTR [r12+0xe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_27fe:
	/* 0x27fe: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2802:
	/* 0x2802: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2806:
	/* 0x2806: cmp    WORD PTR [r12+0xec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_2810:
	/* 0x2810: je     2832 <generic_sleepable_preload+0x2832> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2810, 0x2832, x86_l_2832);
x86_l_2812:
	/* 0x2812: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2815:
	/* 0x2815: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_281a:
	/* 0x281a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_281f:
	/* 0x281f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2823:
	/* 0x2823: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2828:
	/* 0x2828: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_282a:
	/* 0x282a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_282c:
	/* 0x282c: js     2c9d <generic_sleepable_preload+0x2c9d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x282c, 0x2c9d, x86_l_2c9d);
x86_l_2832:
	/* 0x2832: cmp    WORD PTR [r12+0xf6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1056561954816ULL);
x86_l_283c:
	/* 0x283c: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x283c, 0x2d70, x86_l_2d70);
x86_l_2842:
	/* 0x2842: mov    ecx,DWORD PTR [r12+0xf0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_284a:
	/* 0x284a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_284e:
	/* 0x284e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2852:
	/* 0x2852: cmp    WORD PTR [r12+0xf4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_285c:
	/* 0x285c: je     287e <generic_sleepable_preload+0x287e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x285c, 0x287e, x86_l_287e);
x86_l_285e:
	/* 0x285e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2861:
	/* 0x2861: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2866:
	/* 0x2866: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_286b:
	/* 0x286b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_286f:
	/* 0x286f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2874:
	/* 0x2874: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2876:
	/* 0x2876: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2878:
	/* 0x2878: js     2d68 <generic_sleepable_preload+0x2d68> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2878, 0x2d68, x86_l_2d68);
x86_l_287e:
	/* 0x287e: cmp    WORD PTR [r12+0xfe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1090921693184ULL);
x86_l_2888:
	/* 0x2888: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2888, 0x2d70, x86_l_2d70);
x86_l_288e:
	/* 0x288e: mov    ecx,DWORD PTR [r12+0xf8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2896:
	/* 0x2896: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_289a:
	/* 0x289a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_289e:
	/* 0x289e: cmp    WORD PTR [r12+0xfc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_28a8:
	/* 0x28a8: je     28ca <generic_sleepable_preload+0x28ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a8, 0x28ca, x86_l_28ca);
x86_l_28aa:
	/* 0x28aa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_28ad:
	/* 0x28ad: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_28b2:
	/* 0x28b2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_28b7:
	/* 0x28b7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28bb:
	/* 0x28bb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_28c0:
	/* 0x28c0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_28c2:
	/* 0x28c2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_28c4:
	/* 0x28c4: js     5d2d <generic_sleepable_preload+0x5d2d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28c4, 0x5d2d, x86_l_5d2d);
x86_l_28ca:
	/* 0x28ca: cmp    WORD PTR [r12+0x106],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1125281431552ULL);
x86_l_28d4:
	/* 0x28d4: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28d4, 0x2d70, x86_l_2d70);
x86_l_28da:
	/* 0x28da: mov    ecx,DWORD PTR [r12+0x100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_28e2:
	/* 0x28e2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_28e6:
	/* 0x28e6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ea:
	/* 0x28ea: cmp    WORD PTR [r12+0x104],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1116691496960ULL);
x86_l_28f4:
	/* 0x28f4: je     2916 <generic_sleepable_preload+0x2916> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28f4, 0x2916, x86_l_2916);
x86_l_28f6:
	/* 0x28f6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_28f9:
	/* 0x28f9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_28fe:
	/* 0x28fe: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2903:
	/* 0x2903: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2907:
	/* 0x2907: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_290c:
	/* 0x290c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_290e:
	/* 0x290e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2910:
	/* 0x2910: js     5e22 <generic_sleepable_preload+0x5e22> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2910, 0x5e22, x86_l_5e22);
x86_l_2916:
	/* 0x2916: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_291b:
	/* 0x291b: cmp    WORD PTR [r12+0x10e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1159641169920ULL);
x86_l_2925:
	/* 0x2925: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2925, 0x2d70, x86_l_2d70);
x86_l_292b:
	/* 0x292b: mov    ecx,DWORD PTR [r12+0x108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_2933:
	/* 0x2933: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2937:
	/* 0x2937: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_293b:
	/* 0x293b: cmp    WORD PTR [r12+0x10c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1151051235328ULL);
x86_l_2945:
	/* 0x2945: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2945, 0x2d70, x86_l_2d70);
x86_l_294b:
	/* 0x294b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_294e:
	/* 0x294e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2953:
	/* 0x2953: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2958:
	/* 0x2958: jmp    2c32 <generic_sleepable_preload+0x2c32> */
	X86_SIM_X86_JMP(0x2958, 0x2c32, x86_l_2c32);
x86_l_295d:
	/* 0x295d: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_2960:
	/* 0x2960: je     2982 <generic_sleepable_preload+0x2982> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2960, 0x2982, x86_l_2982);
x86_l_2962:
	/* 0x2962: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2965:
	/* 0x2965: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_296a:
	/* 0x296a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_296f:
	/* 0x296f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2973:
	/* 0x2973: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2978:
	/* 0x2978: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_297a:
	/* 0x297a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_297c:
	/* 0x297c: js     2c4f <generic_sleepable_preload+0x2c4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x297c, 0x2c4f, x86_l_2c4f);
x86_l_2982:
	/* 0x2982: cmp    WORD PTR [r12+0xce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 884763262976ULL);
x86_l_298c:
	/* 0x298c: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x298c, 0x2d70, x86_l_2d70);
x86_l_2992:
	/* 0x2992: mov    ecx,DWORD PTR [r12+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_299a:
	/* 0x299a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_299e:
	/* 0x299e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29a2:
	/* 0x29a2: cmp    WORD PTR [r12+0xcc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_29ac:
	/* 0x29ac: je     29ce <generic_sleepable_preload+0x29ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29ac, 0x29ce, x86_l_29ce);
x86_l_29ae:
	/* 0x29ae: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_29b1:
	/* 0x29b1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_29b6:
	/* 0x29b6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_29bb:
	/* 0x29bb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29bf:
	/* 0x29bf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_29c4:
	/* 0x29c4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_29c6:
	/* 0x29c6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_29c8:
	/* 0x29c8: js     2c59 <generic_sleepable_preload+0x2c59> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29c8, 0x2c59, x86_l_2c59);
x86_l_29ce:
	/* 0x29ce: cmp    WORD PTR [r12+0xd6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 919123001344ULL);
x86_l_29d8:
	/* 0x29d8: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29d8, 0x2d70, x86_l_2d70);
x86_l_29de:
	/* 0x29de: mov    ecx,DWORD PTR [r12+0xd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_29e6:
	/* 0x29e6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_29ea:
	/* 0x29ea: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ee:
	/* 0x29ee: cmp    WORD PTR [r12+0xd4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_29f8:
	/* 0x29f8: je     2a1a <generic_sleepable_preload+0x2a1a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29f8, 0x2a1a, x86_l_2a1a);
x86_l_29fa:
	/* 0x29fa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_29fd:
	/* 0x29fd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2a02:
	/* 0x2a02: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2a07:
	/* 0x2a07: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a0b:
	/* 0x2a0b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2a10:
	/* 0x2a10: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2a12:
	/* 0x2a12: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2a14:
	/* 0x2a14: js     2c6a <generic_sleepable_preload+0x2c6a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a14, 0x2c6a, x86_l_2c6a);
x86_l_2a1a:
	/* 0x2a1a: cmp    WORD PTR [r12+0xde],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 953482739712ULL);
x86_l_2a24:
	/* 0x2a24: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a24, 0x2d70, x86_l_2d70);
x86_l_2a2a:
	/* 0x2a2a: mov    ecx,DWORD PTR [r12+0xd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2a32:
	/* 0x2a32: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2a36:
	/* 0x2a36: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a3a:
	/* 0x2a3a: cmp    WORD PTR [r12+0xdc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 944892805120ULL);
x86_l_2a44:
	/* 0x2a44: je     2a66 <generic_sleepable_preload+0x2a66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a44, 0x2a66, x86_l_2a66);
x86_l_2a46:
	/* 0x2a46: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2a49:
	/* 0x2a49: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2a4e:
	/* 0x2a4e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2a53:
	/* 0x2a53: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a57:
	/* 0x2a57: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2a5c:
	/* 0x2a5c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2a5e:
	/* 0x2a5e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2a60:
	/* 0x2a60: js     2c7b <generic_sleepable_preload+0x2c7b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a60, 0x2c7b, x86_l_2c7b);
x86_l_2a66:
	/* 0x2a66: cmp    WORD PTR [r12+0xe6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 987842478080ULL);
x86_l_2a70:
	/* 0x2a70: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a70, 0x2d70, x86_l_2d70);
x86_l_2a76:
	/* 0x2a76: mov    ecx,DWORD PTR [r12+0xe0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2a7e:
	/* 0x2a7e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2a82:
	/* 0x2a82: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a86:
	/* 0x2a86: cmp    WORD PTR [r12+0xe4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 979252543488ULL);
x86_l_2a90:
	/* 0x2a90: je     2ab2 <generic_sleepable_preload+0x2ab2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a90, 0x2ab2, x86_l_2ab2);
x86_l_2a92:
	/* 0x2a92: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2a95:
	/* 0x2a95: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2a9a:
	/* 0x2a9a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2a9f:
	/* 0x2a9f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aa3:
	/* 0x2aa3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2aa8:
	/* 0x2aa8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2aaa:
	/* 0x2aaa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2aac:
	/* 0x2aac: js     2c8c <generic_sleepable_preload+0x2c8c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2aac, 0x2c8c, x86_l_2c8c);
x86_l_2ab2:
	/* 0x2ab2: cmp    WORD PTR [r12+0xee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1022202216448ULL);
x86_l_2abc:
	/* 0x2abc: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2abc, 0x2d70, x86_l_2d70);
x86_l_2ac2:
	/* 0x2ac2: mov    ecx,DWORD PTR [r12+0xe8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_2aca:
	/* 0x2aca: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2ace:
	/* 0x2ace: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ad2:
	/* 0x2ad2: cmp    WORD PTR [r12+0xec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281856ULL);
x86_l_2adc:
	/* 0x2adc: je     2afe <generic_sleepable_preload+0x2afe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2adc, 0x2afe, x86_l_2afe);
x86_l_2ade:
	/* 0x2ade: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ae1:
	/* 0x2ae1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2ae6:
	/* 0x2ae6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2aeb:
	/* 0x2aeb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aef:
	/* 0x2aef: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2af4:
	/* 0x2af4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2af6:
	/* 0x2af6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2af8:
	/* 0x2af8: js     2c9d <generic_sleepable_preload+0x2c9d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2af8, 0x2c9d, x86_l_2c9d);
x86_l_2afe:
	/* 0x2afe: cmp    WORD PTR [r12+0xf6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1056561954816ULL);
x86_l_2b08:
	/* 0x2b08: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b08, 0x2d70, x86_l_2d70);
x86_l_2b0e:
	/* 0x2b0e: mov    ecx,DWORD PTR [r12+0xf0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_2b16:
	/* 0x2b16: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2b1a:
	/* 0x2b1a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b1e:
	/* 0x2b1e: cmp    WORD PTR [r12+0xf4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_2b28:
	/* 0x2b28: je     2b4a <generic_sleepable_preload+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b28, 0x2b4a, x86_l_2b4a);
x86_l_2b2a:
	/* 0x2b2a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2b2d:
	/* 0x2b2d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2b32:
	/* 0x2b32: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2b37:
	/* 0x2b37: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3b:
	/* 0x2b3b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b40:
	/* 0x2b40: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2b42:
	/* 0x2b42: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b44:
	/* 0x2b44: js     2d68 <generic_sleepable_preload+0x2d68> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b44, 0x2d68, x86_l_2d68);
x86_l_2b4a:
	/* 0x2b4a: cmp    WORD PTR [r12+0xfe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1090921693184ULL);
x86_l_2b54:
	/* 0x2b54: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b54, 0x2d70, x86_l_2d70);
x86_l_2b5a:
	/* 0x2b5a: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_2b5d:
	/* 0x2b5d: mov    ecx,DWORD PTR [r12+0xf8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2b65:
	/* 0x2b65: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2b69:
	/* 0x2b69: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b6d:
	/* 0x2b6d: cmp    WORD PTR [r12+0xfc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_2b77:
	/* 0x2b77: je     2b99 <generic_sleepable_preload+0x2b99> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b77, 0x2b99, x86_l_2b99);
x86_l_2b79:
	/* 0x2b79: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2b7c:
	/* 0x2b7c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2b81:
	/* 0x2b81: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2b86:
	/* 0x2b86: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b8a:
	/* 0x2b8a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b8f:
	/* 0x2b8f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2b91:
	/* 0x2b91: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2b93:
	/* 0x2b93: js     5dab <generic_sleepable_preload+0x5dab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b93, 0x5dab, x86_l_5dab);
x86_l_2b99:
	/* 0x2b99: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b9e:
	/* 0x2b9e: cmp    WORD PTR [r12+0x106],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1125281431552ULL);
x86_l_2ba8:
	/* 0x2ba8: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_2bab:
	/* 0x2bab: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bab, 0x2d70, x86_l_2d70);
x86_l_2bb1:
	/* 0x2bb1: mov    ecx,DWORD PTR [r12+0x100] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_2bb9:
	/* 0x2bb9: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2bbd:
	/* 0x2bbd: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bc1:
	/* 0x2bc1: cmp    WORD PTR [r12+0x104],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1116691496960ULL);
x86_l_2bcb:
	/* 0x2bcb: je     2bed <generic_sleepable_preload+0x2bed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bcb, 0x2bed, x86_l_2bed);
x86_l_2bcd:
	/* 0x2bcd: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2bd0:
	/* 0x2bd0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2bd5:
	/* 0x2bd5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2bda:
	/* 0x2bda: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bde:
	/* 0x2bde: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2be3:
	/* 0x2be3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2be5:
	/* 0x2be5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2be7:
	/* 0x2be7: js     5ebb <generic_sleepable_preload+0x5ebb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2be7, 0x5ebb, x86_l_5ebb);
x86_l_2bed:
	/* 0x2bed: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bf2:
	/* 0x2bf2: cmp    WORD PTR [r12+0x10e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1159641169920ULL);
x86_l_2bfc:
	/* 0x2bfc: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_2bff:
	/* 0x2bff: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bff, 0x2d70, x86_l_2d70);
x86_l_2c05:
	/* 0x2c05: mov    ecx,DWORD PTR [r12+0x108] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_2c0d:
	/* 0x2c0d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2c11:
	/* 0x2c11: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c15:
	/* 0x2c15: cmp    WORD PTR [r12+0x10c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1151051235328ULL);
x86_l_2c1f:
	/* 0x2c1f: je     2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c1f, 0x2d70, x86_l_2d70);
x86_l_2c25:
	/* 0x2c25: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2c28:
	/* 0x2c28: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2c2d:
	/* 0x2c2d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2c32:
	/* 0x2c32: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c36:
	/* 0x2c36: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2c3b:
	/* 0x2c3b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2c3d:
	/* 0x2c3d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2c3f:
	/* 0x2c3f: jns    2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c3f, 0x2d70, x86_l_2d70);
x86_l_2c45:
	/* 0x2c45: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_2c4a:
	/* 0x2c4a: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2c4a, 0x2d6d, x86_l_2d6d);
x86_l_2c4f:
	/* 0x2c4f: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_2c54:
	/* 0x2c54: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2c54, 0x2d6d, x86_l_2d6d);
x86_l_2c59:
	/* 0x2c59: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_2c5e:
	/* 0x2c5e: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2c5e, 0x2d6d, x86_l_2d6d);
x86_l_2c63:
	/* 0x2c63: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_2c68:
	/* 0x2c68: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x2c68, 0x2cac, x86_l_2cac);
x86_l_2c6a:
	/* 0x2c6a: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_2c6f:
	/* 0x2c6f: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2c6f, 0x2d6d, x86_l_2d6d);
x86_l_2c74:
	/* 0x2c74: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_2c79:
	/* 0x2c79: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x2c79, 0x2cac, x86_l_2cac);
x86_l_2c7b:
	/* 0x2c7b: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_2c80:
	/* 0x2c80: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2c80, 0x2d6d, x86_l_2d6d);
x86_l_2c85:
	/* 0x2c85: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_2c8a:
	/* 0x2c8a: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x2c8a, 0x2cac, x86_l_2cac);
x86_l_2c8c:
	/* 0x2c8c: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_2c91:
	/* 0x2c91: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2c91, 0x2d6d, x86_l_2d6d);
x86_l_2c96:
	/* 0x2c96: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_2c9b:
	/* 0x2c9b: jmp    2cac <generic_sleepable_preload+0x2cac> */
	X86_SIM_X86_JMP(0x2c9b, 0x2cac, x86_l_2cac);
x86_l_2c9d:
	/* 0x2c9d: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_2ca2:
	/* 0x2ca2: jmp    2d6d <generic_sleepable_preload+0x2d6d> */
	X86_SIM_X86_JMP(0x2ca2, 0x2d6d, x86_l_2d6d);
x86_l_2ca7:
	/* 0x2ca7: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_2cac:
	/* 0x2cac: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2caf:
	/* 0x2caf: mov    ebp,DWORD PTR [r12+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cb4:
	/* 0x2cb4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2cb7:
	/* 0x2cb7: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2cbc:
	/* 0x2cbc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2cc1:
	/* 0x2cc1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2cc6:
	/* 0x2cc6: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_2cc9:
	/* 0x2cc9: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2ccb:
	/* 0x2ccb: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_2cce:
	/* 0x2cce: jne    2e1c <generic_sleepable_preload+0x2e1c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cce, 0x2e1c, x86_l_2e1c);
x86_l_2cd4:
	/* 0x2cd4: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_2cd7:
	/* 0x2cd7: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cdb:
	/* 0x2cdb: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_2ce0:
	/* 0x2ce0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2ce2:
	/* 0x2ce2: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ce7:
	/* 0x2ce7: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2cef:
	/* 0x2cef: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_2cf6:
	/* 0x2cf6: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2cfb:
	/* 0x2cfb: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2d00:
	/* 0x2d00: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2d02:
	/* 0x2d02: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d05:
	/* 0x2d05: je     2e19 <generic_sleepable_preload+0x2e19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d05, 0x2e19, x86_l_2e19);
x86_l_2d0b:
	/* 0x2d0b: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_2d0e:
	/* 0x2d0e: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_2d15:
	/* 0x2d15: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d17:
	/* 0x2d17: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2d1c:
	/* 0x2d1c: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2d21:
	/* 0x2d21: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2d24:
	/* 0x2d24: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_2d27:
	/* 0x2d27: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d29:
	/* 0x2d29: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2d2b:
	/* 0x2d2b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2d30:
	/* 0x2d30: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2d33:
	/* 0x2d33: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_2d36:
	/* 0x2d36: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d3b:
	/* 0x2d3b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2d3d:
	/* 0x2d3d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2d40:
	/* 0x2d40: je     2e19 <generic_sleepable_preload+0x2e19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d40, 0x2e19, x86_l_2e19);
x86_l_2d46:
	/* 0x2d46: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_2d49:
	/* 0x2d49: je     2e17 <generic_sleepable_preload+0x2e17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d49, 0x2e17, x86_l_2e17);
x86_l_2d4f:
	/* 0x2d4f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2d52:
	/* 0x2d52: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2d56:
	/* 0x2d56: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_2d5b:
	/* 0x2d5b: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_2d5e:
	/* 0x2d5e: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_2d63:
	/* 0x2d63: jmp    2dfc <generic_sleepable_preload+0x2dfc> */
	X86_SIM_X86_JMP(0x2d63, 0x2dfc, x86_l_2dfc);
x86_l_2d68:
	/* 0x2d68: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_2d6d:
	/* 0x2d6d: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d70:
	/* 0x2d70: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_2d73:
	/* 0x2d73: jne    2e1c <generic_sleepable_preload+0x2e1c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d73, 0x2e1c, x86_l_2e1c);
x86_l_2d79:
	/* 0x2d79: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_2d7c:
	/* 0x2d7c: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d80:
	/* 0x2d80: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_2d85:
	/* 0x2d85: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2d87:
	/* 0x2d87: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2d8c:
	/* 0x2d8c: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2d94:
	/* 0x2d94: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_2d9b:
	/* 0x2d9b: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2da0:
	/* 0x2da0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2da5:
	/* 0x2da5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2da7:
	/* 0x2da7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2daa:
	/* 0x2daa: je     2e19 <generic_sleepable_preload+0x2e19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2daa, 0x2e19, x86_l_2e19);
x86_l_2dac:
	/* 0x2dac: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_2daf:
	/* 0x2daf: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_2db6:
	/* 0x2db6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2db8:
	/* 0x2db8: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2dbd:
	/* 0x2dbd: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2dc2:
	/* 0x2dc2: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2dc5:
	/* 0x2dc5: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_2dc8:
	/* 0x2dc8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2dca:
	/* 0x2dca: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2dcc:
	/* 0x2dcc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2dd1:
	/* 0x2dd1: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_2dd4:
	/* 0x2dd4: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_2dd7:
	/* 0x2dd7: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ddc:
	/* 0x2ddc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2dde:
	/* 0x2dde: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2de1:
	/* 0x2de1: je     2e19 <generic_sleepable_preload+0x2e19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2de1, 0x2e19, x86_l_2e19);
x86_l_2de3:
	/* 0x2de3: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_2de6:
	/* 0x2de6: je     2e17 <generic_sleepable_preload+0x2e17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2de6, 0x2e17, x86_l_2e17);
x86_l_2de8:
	/* 0x2de8: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_2deb:
	/* 0x2deb: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2def:
	/* 0x2def: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_2df4:
	/* 0x2df4: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_2df7:
	/* 0x2df7: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_2dfc:
	/* 0x2dfc: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_2e01:
	/* 0x2e01: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_2e04:
	/* 0x2e04: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2e06:
	/* 0x2e06: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_2e09:
	/* 0x2e09: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_2e0c:
	/* 0x2e0c: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_2e0f:
	/* 0x2e0f: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_2e14:
	/* 0x2e14: cmovs  ebx,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_2e17:
	/* 0x2e17: mov    DWORD PTR [rax],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e19:
	/* 0x2e19: mov    r14,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBP, X86_WIDTH_64);
x86_l_2e1c:
	/* 0x2e1c: mov    eax,DWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e21:
	/* 0x2e21: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_2e26:
	/* 0x2e26: je     3dc4 <generic_sleepable_preload+0x3dc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e26, 0x3dc4, x86_l_3dc4);
x86_l_2e2c:
	/* 0x2e2c: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_2e2e:
	/* 0x2e2e: js     2e63 <generic_sleepable_preload+0x2e63> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e2e, 0x2e63, x86_l_2e63);
x86_l_2e30:
	/* 0x2e30: mov    eax,DWORD PTR [r12+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2e35:
	/* 0x2e35: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2e38:
	/* 0x2e38: jle    2ee6 <generic_sleepable_preload+0x2ee6> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2e38, 0x2ee6, x86_l_2ee6);
x86_l_2e3e:
	/* 0x2e3e: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2e41:
	/* 0x2e41: je     2f50 <generic_sleepable_preload+0x2f50> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e41, 0x2f50, x86_l_2f50);
x86_l_2e47:
	/* 0x2e47: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_2e4a:
	/* 0x2e4a: je     2f57 <generic_sleepable_preload+0x2f57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e4a, 0x2f57, x86_l_2f57);
x86_l_2e50:
	/* 0x2e50: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_2e53:
	/* 0x2e53: jne    2f6a <generic_sleepable_preload+0x2f6a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e53, 0x2f6a, x86_l_2f6a);
x86_l_2e59:
	/* 0x2e59: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2e5e:
	/* 0x2e5e: jmp    2f63 <generic_sleepable_preload+0x2f63> */
	X86_SIM_X86_JMP(0x2e5e, 0x2f63, x86_l_2f63);
x86_l_2e63:
	/* 0x2e63: movzx  eax,BYTE PTR [r12+0x2ca] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 714ULL);
x86_l_2e6c:
	/* 0x2e6c: movzx  ecx,WORD PTR [r12+0x2c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 712ULL);
x86_l_2e75:
	/* 0x2e75: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_2e7b:
	/* 0x2e7b: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2e7d:
	/* 0x2e7d: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_2e80:
	/* 0x2e80: jle    2ebf <generic_sleepable_preload+0x2ebf> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2e80, 0x2ebf, x86_l_2ebf);
x86_l_2e82:
	/* 0x2e82: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_2e85:
	/* 0x2e85: jle    2ef6 <generic_sleepable_preload+0x2ef6> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2e85, 0x2ef6, x86_l_2ef6);
x86_l_2e87:
	/* 0x2e87: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2e8a:
	/* 0x2e8a: jle    35b9 <generic_sleepable_preload+0x35b9> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2e8a, 0x35b9, x86_l_35b9);
x86_l_2e90:
	/* 0x2e90: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2e95:
	/* 0x2e95: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_2e98:
	/* 0x2e98: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e98, 0x35de, x86_l_35de);
x86_l_2e9e:
	/* 0x2e9e: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ea3:
	/* 0x2ea3: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_2ea6:
	/* 0x2ea6: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ea6, 0x35de, x86_l_35de);
x86_l_2eac:
	/* 0x2eac: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2eb1:
	/* 0x2eb1: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_2eb4:
	/* 0x2eb4: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2eb4, 0x35de, x86_l_35de);
x86_l_2eba:
	/* 0x2eba: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x2eba, 0x35f1, x86_l_35f1);
x86_l_2ebf:
	/* 0x2ebf: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_2ec2:
	/* 0x2ec2: jg     2f23 <generic_sleepable_preload+0x2f23> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2ec2, 0x2f23, x86_l_2f23);
x86_l_2ec4:
	/* 0x2ec4: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_2ec7:
	/* 0x2ec7: jg     358a <generic_sleepable_preload+0x358a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2ec7, 0x358a, x86_l_358a);
x86_l_2ecd:
	/* 0x2ecd: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_2ecf:
	/* 0x2ecf: je     35d9 <generic_sleepable_preload+0x35d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ecf, 0x35d9, x86_l_35d9);
x86_l_2ed5:
	/* 0x2ed5: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_2ed8:
	/* 0x2ed8: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_2edb:
	/* 0x2edb: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2edb, 0x35de, x86_l_35de);
x86_l_2ee1:
	/* 0x2ee1: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x2ee1, 0x35f1, x86_l_35f1);
x86_l_2ee6:
	/* 0x2ee6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2ee8:
	/* 0x2ee8: je     2f5e <generic_sleepable_preload+0x2f5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ee8, 0x2f5e, x86_l_2f5e);
x86_l_2eea:
	/* 0x2eea: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2eed:
	/* 0x2eed: jne    2f6a <generic_sleepable_preload+0x2f6a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2eed, 0x2f6a, x86_l_2f6a);
x86_l_2eef:
	/* 0x2eef: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ef4:
	/* 0x2ef4: jmp    2f63 <generic_sleepable_preload+0x2f63> */
	X86_SIM_X86_JMP(0x2ef4, 0x2f63, x86_l_2f63);
x86_l_2ef6:
	/* 0x2ef6: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_2ef9:
	/* 0x2ef9: jg     3571 <generic_sleepable_preload+0x3571> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2ef9, 0x3571, x86_l_3571);
x86_l_2eff:
	/* 0x2eff: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2f07:
	/* 0x2f07: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2f0a:
	/* 0x2f0a: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f0a, 0x35de, x86_l_35de);
x86_l_2f10:
	/* 0x2f10: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2f15:
	/* 0x2f15: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_2f18:
	/* 0x2f18: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f18, 0x35de, x86_l_35de);
x86_l_2f1e:
	/* 0x2f1e: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x2f1e, 0x35f1, x86_l_35f1);
x86_l_2f23:
	/* 0x2f23: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_2f26:
	/* 0x2f26: jg     35a0 <generic_sleepable_preload+0x35a0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2f26, 0x35a0, x86_l_35a0);
x86_l_2f2c:
	/* 0x2f2c: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2f34:
	/* 0x2f34: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_2f37:
	/* 0x2f37: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f37, 0x35de, x86_l_35de);
x86_l_2f3d:
	/* 0x2f3d: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2f42:
	/* 0x2f42: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_2f45:
	/* 0x2f45: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f45, 0x35de, x86_l_35de);
x86_l_2f4b:
	/* 0x2f4b: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x2f4b, 0x35f1, x86_l_35f1);
x86_l_2f50:
	/* 0x2f50: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f55:
	/* 0x2f55: jmp    2f63 <generic_sleepable_preload+0x2f63> */
	X86_SIM_X86_JMP(0x2f55, 0x2f63, x86_l_2f63);
x86_l_2f57:
	/* 0x2f57: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f5c:
	/* 0x2f5c: jmp    2f63 <generic_sleepable_preload+0x2f63> */
	X86_SIM_X86_JMP(0x2f5c, 0x2f63, x86_l_2f63);
x86_l_2f5e:
	/* 0x2f5e: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2f63:
	/* 0x2f63: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f66:
	/* 0x2f66: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f6a:
	/* 0x2f6a: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2f6c:
	/* 0x2f6c: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_2f6f:
	/* 0x2f6f: cmp    WORD PTR [r12+0x116],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1194000908288ULL);
x86_l_2f79:
	/* 0x2f79: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f79, 0x3c57, x86_l_3c57);
x86_l_2f7f:
	/* 0x2f7f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_2f86:
	/* 0x2f86: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2f89:
	/* 0x2f89: mov    eax,DWORD PTR [r12+0x110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_2f91:
	/* 0x2f91: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2f94:
	/* 0x2f94: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f98:
	/* 0x2f98: movzx  eax,WORD PTR [r12+0x114] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 276ULL);
x86_l_2fa1:
	/* 0x2fa1: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_2fa3:
	/* 0x2fa3: je     3275 <generic_sleepable_preload+0x3275> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fa3, 0x3275, x86_l_3275);
x86_l_2fa9:
	/* 0x2fa9: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_2fac:
	/* 0x2fac: je     2fce <generic_sleepable_preload+0x2fce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fac, 0x2fce, x86_l_2fce);
x86_l_2fae:
	/* 0x2fae: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2fb1:
	/* 0x2fb1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_2fb6:
	/* 0x2fb6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_2fbb:
	/* 0x2fbb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fbf:
	/* 0x2fbf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2fc4:
	/* 0x2fc4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_2fc6:
	/* 0x2fc6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_2fc8:
	/* 0x2fc8: js     3567 <generic_sleepable_preload+0x3567> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2fc8, 0x3567, x86_l_3567);
x86_l_2fce:
	/* 0x2fce: cmp    WORD PTR [r12+0x11e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1228360646656ULL);
x86_l_2fd8:
	/* 0x2fd8: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fd8, 0x3c57, x86_l_3c57);
x86_l_2fde:
	/* 0x2fde: mov    ecx,DWORD PTR [r12+0x118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_2fe6:
	/* 0x2fe6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2fea:
	/* 0x2fea: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fee:
	/* 0x2fee: cmp    WORD PTR [r12+0x11c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1219770712064ULL);
x86_l_2ff8:
	/* 0x2ff8: je     301a <generic_sleepable_preload+0x301a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ff8, 0x301a, x86_l_301a);
x86_l_2ffa:
	/* 0x2ffa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ffd:
	/* 0x2ffd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3002:
	/* 0x3002: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3007:
	/* 0x3007: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_300b:
	/* 0x300b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3010:
	/* 0x3010: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3012:
	/* 0x3012: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3014:
	/* 0x3014: js     35cf <generic_sleepable_preload+0x35cf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3014, 0x35cf, x86_l_35cf);
x86_l_301a:
	/* 0x301a: cmp    WORD PTR [r12+0x126],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1262720385024ULL);
x86_l_3024:
	/* 0x3024: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3024, 0x3c57, x86_l_3c57);
x86_l_302a:
	/* 0x302a: mov    ecx,DWORD PTR [r12+0x120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_3032:
	/* 0x3032: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3036:
	/* 0x3036: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_303a:
	/* 0x303a: cmp    WORD PTR [r12+0x124],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1254130450432ULL);
x86_l_3044:
	/* 0x3044: je     3066 <generic_sleepable_preload+0x3066> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3044, 0x3066, x86_l_3066);
x86_l_3046:
	/* 0x3046: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3049:
	/* 0x3049: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_304e:
	/* 0x304e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3053:
	/* 0x3053: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3057:
	/* 0x3057: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_305c:
	/* 0x305c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_305e:
	/* 0x305e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3060:
	/* 0x3060: js     3c0b <generic_sleepable_preload+0x3c0b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3060, 0x3c0b, x86_l_3c0b);
x86_l_3066:
	/* 0x3066: cmp    WORD PTR [r12+0x12e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1297080123392ULL);
x86_l_3070:
	/* 0x3070: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3070, 0x3c57, x86_l_3c57);
x86_l_3076:
	/* 0x3076: mov    ecx,DWORD PTR [r12+0x128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_307e:
	/* 0x307e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3082:
	/* 0x3082: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3086:
	/* 0x3086: cmp    WORD PTR [r12+0x12c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1288490188800ULL);
x86_l_3090:
	/* 0x3090: je     30b2 <generic_sleepable_preload+0x30b2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3090, 0x30b2, x86_l_30b2);
x86_l_3092:
	/* 0x3092: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3095:
	/* 0x3095: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_309a:
	/* 0x309a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_309f:
	/* 0x309f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30a3:
	/* 0x30a3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_30a8:
	/* 0x30a8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_30aa:
	/* 0x30aa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_30ac:
	/* 0x30ac: js     3c1c <generic_sleepable_preload+0x3c1c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30ac, 0x3c1c, x86_l_3c1c);
x86_l_30b2:
	/* 0x30b2: cmp    WORD PTR [r12+0x136],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1331439861760ULL);
x86_l_30bc:
	/* 0x30bc: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30bc, 0x3c57, x86_l_3c57);
x86_l_30c2:
	/* 0x30c2: mov    ecx,DWORD PTR [r12+0x130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_30ca:
	/* 0x30ca: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_30ce:
	/* 0x30ce: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30d2:
	/* 0x30d2: cmp    WORD PTR [r12+0x134],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1322849927168ULL);
x86_l_30dc:
	/* 0x30dc: je     30fe <generic_sleepable_preload+0x30fe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30dc, 0x30fe, x86_l_30fe);
x86_l_30de:
	/* 0x30de: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_30e1:
	/* 0x30e1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_30e6:
	/* 0x30e6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_30eb:
	/* 0x30eb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30ef:
	/* 0x30ef: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_30f4:
	/* 0x30f4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_30f6:
	/* 0x30f6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_30f8:
	/* 0x30f8: js     3c2d <generic_sleepable_preload+0x3c2d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30f8, 0x3c2d, x86_l_3c2d);
x86_l_30fe:
	/* 0x30fe: cmp    WORD PTR [r12+0x13e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1365799600128ULL);
x86_l_3108:
	/* 0x3108: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3108, 0x3c57, x86_l_3c57);
x86_l_310e:
	/* 0x310e: mov    ecx,DWORD PTR [r12+0x138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_3116:
	/* 0x3116: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_311a:
	/* 0x311a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_311e:
	/* 0x311e: cmp    WORD PTR [r12+0x13c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1357209665536ULL);
x86_l_3128:
	/* 0x3128: je     314a <generic_sleepable_preload+0x314a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3128, 0x314a, x86_l_314a);
x86_l_312a:
	/* 0x312a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_312d:
	/* 0x312d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3132:
	/* 0x3132: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3137:
	/* 0x3137: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_313b:
	/* 0x313b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3140:
	/* 0x3140: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3142:
	/* 0x3142: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3144:
	/* 0x3144: js     3c3e <generic_sleepable_preload+0x3c3e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3144, 0x3c3e, x86_l_3c3e);
x86_l_314a:
	/* 0x314a: cmp    WORD PTR [r12+0x146],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1400159338496ULL);
x86_l_3154:
	/* 0x3154: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3154, 0x3c57, x86_l_3c57);
x86_l_315a:
	/* 0x315a: mov    ecx,DWORD PTR [r12+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_3162:
	/* 0x3162: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3166:
	/* 0x3166: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_316a:
	/* 0x316a: cmp    WORD PTR [r12+0x144],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1391569403904ULL);
x86_l_3174:
	/* 0x3174: je     3196 <generic_sleepable_preload+0x3196> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3174, 0x3196, x86_l_3196);
x86_l_3176:
	/* 0x3176: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3179:
	/* 0x3179: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_317e:
	/* 0x317e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3183:
	/* 0x3183: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3187:
	/* 0x3187: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_318c:
	/* 0x318c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_318e:
	/* 0x318e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3190:
	/* 0x3190: js     3c4f <generic_sleepable_preload+0x3c4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3190, 0x3c4f, x86_l_3c4f);
x86_l_3196:
	/* 0x3196: cmp    WORD PTR [r12+0x14e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1434519076864ULL);
x86_l_31a0:
	/* 0x31a0: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31a0, 0x3c57, x86_l_3c57);
x86_l_31a6:
	/* 0x31a6: mov    ecx,DWORD PTR [r12+0x148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_31ae:
	/* 0x31ae: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_31b2:
	/* 0x31b2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31b6:
	/* 0x31b6: cmp    WORD PTR [r12+0x14c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1425929142272ULL);
x86_l_31c0:
	/* 0x31c0: je     31e2 <generic_sleepable_preload+0x31e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c0, 0x31e2, x86_l_31e2);
x86_l_31c2:
	/* 0x31c2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_31c5:
	/* 0x31c5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_31ca:
	/* 0x31ca: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_31cf:
	/* 0x31cf: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31d3:
	/* 0x31d3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_31d8:
	/* 0x31d8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_31da:
	/* 0x31da: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_31dc:
	/* 0x31dc: js     5d3a <generic_sleepable_preload+0x5d3a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x31dc, 0x5d3a, x86_l_5d3a);
x86_l_31e2:
	/* 0x31e2: cmp    WORD PTR [r12+0x156],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1468878815232ULL);
x86_l_31ec:
	/* 0x31ec: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31ec, 0x3c57, x86_l_3c57);
x86_l_31f2:
	/* 0x31f2: mov    ecx,DWORD PTR [r12+0x150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_31fa:
	/* 0x31fa: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_31fe:
	/* 0x31fe: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3202:
	/* 0x3202: cmp    WORD PTR [r12+0x154],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1460288880640ULL);
x86_l_320c:
	/* 0x320c: je     322e <generic_sleepable_preload+0x322e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x320c, 0x322e, x86_l_322e);
x86_l_320e:
	/* 0x320e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3211:
	/* 0x3211: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3216:
	/* 0x3216: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_321b:
	/* 0x321b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_321f:
	/* 0x321f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3224:
	/* 0x3224: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3226:
	/* 0x3226: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3228:
	/* 0x3228: js     5e34 <generic_sleepable_preload+0x5e34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3228, 0x5e34, x86_l_5e34);
x86_l_322e:
	/* 0x322e: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3233:
	/* 0x3233: cmp    WORD PTR [r12+0x15e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1503238553600ULL);
x86_l_323d:
	/* 0x323d: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x323d, 0x3c57, x86_l_3c57);
x86_l_3243:
	/* 0x3243: mov    ecx,DWORD PTR [r12+0x158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_324b:
	/* 0x324b: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_324f:
	/* 0x324f: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3253:
	/* 0x3253: cmp    WORD PTR [r12+0x15c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619008ULL);
x86_l_325d:
	/* 0x325d: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x325d, 0x3c57, x86_l_3c57);
x86_l_3263:
	/* 0x3263: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3266:
	/* 0x3266: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_326b:
	/* 0x326b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3270:
	/* 0x3270: jmp    354a <generic_sleepable_preload+0x354a> */
	X86_SIM_X86_JMP(0x3270, 0x354a, x86_l_354a);
x86_l_3275:
	/* 0x3275: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_3278:
	/* 0x3278: je     329a <generic_sleepable_preload+0x329a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3278, 0x329a, x86_l_329a);
x86_l_327a:
	/* 0x327a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_327d:
	/* 0x327d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3282:
	/* 0x3282: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3287:
	/* 0x3287: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_328b:
	/* 0x328b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3290:
	/* 0x3290: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3292:
	/* 0x3292: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3294:
	/* 0x3294: js     3567 <generic_sleepable_preload+0x3567> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3294, 0x3567, x86_l_3567);
x86_l_329a:
	/* 0x329a: cmp    WORD PTR [r12+0x11e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1228360646656ULL);
x86_l_32a4:
	/* 0x32a4: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32a4, 0x3c57, x86_l_3c57);
x86_l_32aa:
	/* 0x32aa: mov    ecx,DWORD PTR [r12+0x118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_32b2:
	/* 0x32b2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_32b6:
	/* 0x32b6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32ba:
	/* 0x32ba: cmp    WORD PTR [r12+0x11c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1219770712064ULL);
x86_l_32c4:
	/* 0x32c4: je     32e6 <generic_sleepable_preload+0x32e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32c4, 0x32e6, x86_l_32e6);
x86_l_32c6:
	/* 0x32c6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_32c9:
	/* 0x32c9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_32ce:
	/* 0x32ce: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_32d3:
	/* 0x32d3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32d7:
	/* 0x32d7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_32dc:
	/* 0x32dc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_32de:
	/* 0x32de: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_32e0:
	/* 0x32e0: js     35cf <generic_sleepable_preload+0x35cf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x32e0, 0x35cf, x86_l_35cf);
x86_l_32e6:
	/* 0x32e6: cmp    WORD PTR [r12+0x126],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1262720385024ULL);
x86_l_32f0:
	/* 0x32f0: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f0, 0x3c57, x86_l_3c57);
x86_l_32f6:
	/* 0x32f6: mov    ecx,DWORD PTR [r12+0x120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_32fe:
	/* 0x32fe: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3302:
	/* 0x3302: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3306:
	/* 0x3306: cmp    WORD PTR [r12+0x124],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1254130450432ULL);
x86_l_3310:
	/* 0x3310: je     3332 <generic_sleepable_preload+0x3332> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3310, 0x3332, x86_l_3332);
x86_l_3312:
	/* 0x3312: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3315:
	/* 0x3315: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_331a:
	/* 0x331a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_331f:
	/* 0x331f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3323:
	/* 0x3323: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3328:
	/* 0x3328: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_332a:
	/* 0x332a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_332c:
	/* 0x332c: js     3c0b <generic_sleepable_preload+0x3c0b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x332c, 0x3c0b, x86_l_3c0b);
x86_l_3332:
	/* 0x3332: cmp    WORD PTR [r12+0x12e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1297080123392ULL);
x86_l_333c:
	/* 0x333c: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x333c, 0x3c57, x86_l_3c57);
x86_l_3342:
	/* 0x3342: mov    ecx,DWORD PTR [r12+0x128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_334a:
	/* 0x334a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_334e:
	/* 0x334e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3352:
	/* 0x3352: cmp    WORD PTR [r12+0x12c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1288490188800ULL);
x86_l_335c:
	/* 0x335c: je     337e <generic_sleepable_preload+0x337e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x335c, 0x337e, x86_l_337e);
x86_l_335e:
	/* 0x335e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3361:
	/* 0x3361: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3366:
	/* 0x3366: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_336b:
	/* 0x336b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_336f:
	/* 0x336f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3374:
	/* 0x3374: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3376:
	/* 0x3376: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3378:
	/* 0x3378: js     3c1c <generic_sleepable_preload+0x3c1c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3378, 0x3c1c, x86_l_3c1c);
x86_l_337e:
	/* 0x337e: cmp    WORD PTR [r12+0x136],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1331439861760ULL);
x86_l_3388:
	/* 0x3388: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3388, 0x3c57, x86_l_3c57);
x86_l_338e:
	/* 0x338e: mov    ecx,DWORD PTR [r12+0x130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_3396:
	/* 0x3396: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_339a:
	/* 0x339a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_339e:
	/* 0x339e: cmp    WORD PTR [r12+0x134],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1322849927168ULL);
x86_l_33a8:
	/* 0x33a8: je     33ca <generic_sleepable_preload+0x33ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33a8, 0x33ca, x86_l_33ca);
x86_l_33aa:
	/* 0x33aa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_33ad:
	/* 0x33ad: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_33b2:
	/* 0x33b2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_33b7:
	/* 0x33b7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33bb:
	/* 0x33bb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_33c0:
	/* 0x33c0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_33c2:
	/* 0x33c2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_33c4:
	/* 0x33c4: js     3c2d <generic_sleepable_preload+0x3c2d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x33c4, 0x3c2d, x86_l_3c2d);
x86_l_33ca:
	/* 0x33ca: cmp    WORD PTR [r12+0x13e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1365799600128ULL);
x86_l_33d4:
	/* 0x33d4: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33d4, 0x3c57, x86_l_3c57);
x86_l_33da:
	/* 0x33da: mov    ecx,DWORD PTR [r12+0x138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_33e2:
	/* 0x33e2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_33e6:
	/* 0x33e6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33ea:
	/* 0x33ea: cmp    WORD PTR [r12+0x13c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1357209665536ULL);
x86_l_33f4:
	/* 0x33f4: je     3416 <generic_sleepable_preload+0x3416> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33f4, 0x3416, x86_l_3416);
x86_l_33f6:
	/* 0x33f6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_33f9:
	/* 0x33f9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_33fe:
	/* 0x33fe: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3403:
	/* 0x3403: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3407:
	/* 0x3407: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_340c:
	/* 0x340c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_340e:
	/* 0x340e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3410:
	/* 0x3410: js     3c3e <generic_sleepable_preload+0x3c3e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3410, 0x3c3e, x86_l_3c3e);
x86_l_3416:
	/* 0x3416: cmp    WORD PTR [r12+0x146],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1400159338496ULL);
x86_l_3420:
	/* 0x3420: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3420, 0x3c57, x86_l_3c57);
x86_l_3426:
	/* 0x3426: mov    ecx,DWORD PTR [r12+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_342e:
	/* 0x342e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3432:
	/* 0x3432: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3436:
	/* 0x3436: cmp    WORD PTR [r12+0x144],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1391569403904ULL);
x86_l_3440:
	/* 0x3440: je     3462 <generic_sleepable_preload+0x3462> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3440, 0x3462, x86_l_3462);
x86_l_3442:
	/* 0x3442: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3445:
	/* 0x3445: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_344a:
	/* 0x344a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_344f:
	/* 0x344f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3453:
	/* 0x3453: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3458:
	/* 0x3458: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_345a:
	/* 0x345a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_345c:
	/* 0x345c: js     3c4f <generic_sleepable_preload+0x3c4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x345c, 0x3c4f, x86_l_3c4f);
x86_l_3462:
	/* 0x3462: cmp    WORD PTR [r12+0x14e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1434519076864ULL);
x86_l_346c:
	/* 0x346c: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x346c, 0x3c57, x86_l_3c57);
x86_l_3472:
	/* 0x3472: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_3475:
	/* 0x3475: mov    ecx,DWORD PTR [r12+0x148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_347d:
	/* 0x347d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3481:
	/* 0x3481: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3485:
	/* 0x3485: cmp    WORD PTR [r12+0x14c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1425929142272ULL);
x86_l_348f:
	/* 0x348f: je     34b1 <generic_sleepable_preload+0x34b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x348f, 0x34b1, x86_l_34b1);
x86_l_3491:
	/* 0x3491: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3494:
	/* 0x3494: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3499:
	/* 0x3499: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_349e:
	/* 0x349e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34a2:
	/* 0x34a2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_34a7:
	/* 0x34a7: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_34a9:
	/* 0x34a9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_34ab:
	/* 0x34ab: js     5db8 <generic_sleepable_preload+0x5db8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x34ab, 0x5db8, x86_l_5db8);
x86_l_34b1:
	/* 0x34b1: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34b6:
	/* 0x34b6: cmp    WORD PTR [r12+0x156],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1468878815232ULL);
x86_l_34c0:
	/* 0x34c0: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_34c3:
	/* 0x34c3: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34c3, 0x3c57, x86_l_3c57);
x86_l_34c9:
	/* 0x34c9: mov    ecx,DWORD PTR [r12+0x150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_34d1:
	/* 0x34d1: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_34d5:
	/* 0x34d5: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34d9:
	/* 0x34d9: cmp    WORD PTR [r12+0x154],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1460288880640ULL);
x86_l_34e3:
	/* 0x34e3: je     3505 <generic_sleepable_preload+0x3505> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34e3, 0x3505, x86_l_3505);
x86_l_34e5:
	/* 0x34e5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_34e8:
	/* 0x34e8: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_34ed:
	/* 0x34ed: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_34f2:
	/* 0x34f2: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34f6:
	/* 0x34f6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_34fb:
	/* 0x34fb: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_34fd:
	/* 0x34fd: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_34ff:
	/* 0x34ff: js     5ed0 <generic_sleepable_preload+0x5ed0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x34ff, 0x5ed0, x86_l_5ed0);
x86_l_3505:
	/* 0x3505: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_350a:
	/* 0x350a: cmp    WORD PTR [r12+0x15e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1503238553600ULL);
x86_l_3514:
	/* 0x3514: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_3517:
	/* 0x3517: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3517, 0x3c57, x86_l_3c57);
x86_l_351d:
	/* 0x351d: mov    ecx,DWORD PTR [r12+0x158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_3525:
	/* 0x3525: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3529:
	/* 0x3529: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_352d:
	/* 0x352d: cmp    WORD PTR [r12+0x15c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619008ULL);
x86_l_3537:
	/* 0x3537: je     3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3537, 0x3c57, x86_l_3c57);
x86_l_353d:
	/* 0x353d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3540:
	/* 0x3540: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3545:
	/* 0x3545: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_354a:
	/* 0x354a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_354e:
	/* 0x354e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3553:
	/* 0x3553: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3555:
	/* 0x3555: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3557:
	/* 0x3557: jns    3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3557, 0x3c57, x86_l_3c57);
x86_l_355d:
	/* 0x355d: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_3562:
	/* 0x3562: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x3562, 0x3c54, x86_l_3c54);
x86_l_3567:
	/* 0x3567: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_356c:
	/* 0x356c: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x356c, 0x3c54, x86_l_3c54);
x86_l_3571:
	/* 0x3571: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3579:
	/* 0x3579: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_357c:
	/* 0x357c: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x357c, 0x35de, x86_l_35de);
x86_l_357e:
	/* 0x357e: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3583:
	/* 0x3583: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_3586:
	/* 0x3586: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3586, 0x35de, x86_l_35de);
x86_l_3588:
	/* 0x3588: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x3588, 0x35f1, x86_l_35f1);
x86_l_358a:
	/* 0x358a: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_358f:
	/* 0x358f: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_3592:
	/* 0x3592: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3592, 0x35de, x86_l_35de);
x86_l_3594:
	/* 0x3594: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3599:
	/* 0x3599: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_359c:
	/* 0x359c: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x359c, 0x35de, x86_l_35de);
x86_l_359e:
	/* 0x359e: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x359e, 0x35f1, x86_l_35f1);
x86_l_35a0:
	/* 0x35a0: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_35a8:
	/* 0x35a8: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_35ab:
	/* 0x35ab: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35ab, 0x35de, x86_l_35de);
x86_l_35ad:
	/* 0x35ad: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_35b2:
	/* 0x35b2: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_35b5:
	/* 0x35b5: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35b5, 0x35de, x86_l_35de);
x86_l_35b7:
	/* 0x35b7: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x35b7, 0x35f1, x86_l_35f1);
x86_l_35b9:
	/* 0x35b9: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_35be:
	/* 0x35be: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_35c1:
	/* 0x35c1: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35c1, 0x35de, x86_l_35de);
x86_l_35c3:
	/* 0x35c3: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_35c8:
	/* 0x35c8: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_35cb:
	/* 0x35cb: je     35de <generic_sleepable_preload+0x35de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35cb, 0x35de, x86_l_35de);
x86_l_35cd:
	/* 0x35cd: jmp    35f1 <generic_sleepable_preload+0x35f1> */
	X86_SIM_X86_JMP(0x35cd, 0x35f1, x86_l_35f1);
x86_l_35cf:
	/* 0x35cf: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_35d4:
	/* 0x35d4: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x35d4, 0x3c54, x86_l_3c54);
x86_l_35d9:
	/* 0x35d9: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_35de:
	/* 0x35de: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_35e1:
	/* 0x35e1: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_35e3:
	/* 0x35e3: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_35e5:
	/* 0x35e5: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_35ea:
	/* 0x35ea: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_35ec:
	/* 0x35ec: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_35f1:
	/* 0x35f1: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35f5:
	/* 0x35f5: mov    ebp,DWORD PTR [r12+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_35fa:
	/* 0x35fa: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_35fc:
	/* 0x35fc: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_35ff:
	/* 0x35ff: cmp    WORD PTR [r12+0x116],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1194000908288ULL);
x86_l_3609:
	/* 0x3609: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3609, 0x3d18, x86_l_3d18);
x86_l_360f:
	/* 0x360f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_3616:
	/* 0x3616: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_3619:
	/* 0x3619: mov    eax,DWORD PTR [r12+0x110] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_3621:
	/* 0x3621: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3624:
	/* 0x3624: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3628:
	/* 0x3628: movzx  eax,WORD PTR [r12+0x114] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 276ULL);
x86_l_3631:
	/* 0x3631: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_3633:
	/* 0x3633: je     3905 <generic_sleepable_preload+0x3905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3633, 0x3905, x86_l_3905);
x86_l_3639:
	/* 0x3639: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_363c:
	/* 0x363c: je     365e <generic_sleepable_preload+0x365e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x363c, 0x365e, x86_l_365e);
x86_l_363e:
	/* 0x363e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3641:
	/* 0x3641: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3646:
	/* 0x3646: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_364b:
	/* 0x364b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_364f:
	/* 0x364f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3654:
	/* 0x3654: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3656:
	/* 0x3656: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3658:
	/* 0x3658: js     3bf7 <generic_sleepable_preload+0x3bf7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3658, 0x3bf7, x86_l_3bf7);
x86_l_365e:
	/* 0x365e: cmp    WORD PTR [r12+0x11e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1228360646656ULL);
x86_l_3668:
	/* 0x3668: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3668, 0x3d18, x86_l_3d18);
x86_l_366e:
	/* 0x366e: mov    ecx,DWORD PTR [r12+0x118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_3676:
	/* 0x3676: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_367a:
	/* 0x367a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_367e:
	/* 0x367e: cmp    WORD PTR [r12+0x11c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1219770712064ULL);
x86_l_3688:
	/* 0x3688: je     36aa <generic_sleepable_preload+0x36aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3688, 0x36aa, x86_l_36aa);
x86_l_368a:
	/* 0x368a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_368d:
	/* 0x368d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3692:
	/* 0x3692: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3697:
	/* 0x3697: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_369b:
	/* 0x369b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_36a0:
	/* 0x36a0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_36a2:
	/* 0x36a2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_36a4:
	/* 0x36a4: js     3c01 <generic_sleepable_preload+0x3c01> */
	X86_SIM_X86_JCC(X86_CC_S, 0x36a4, 0x3c01, x86_l_3c01);
x86_l_36aa:
	/* 0x36aa: cmp    WORD PTR [r12+0x126],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1262720385024ULL);
x86_l_36b4:
	/* 0x36b4: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36b4, 0x3d18, x86_l_3d18);
x86_l_36ba:
	/* 0x36ba: mov    ecx,DWORD PTR [r12+0x120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_36c2:
	/* 0x36c2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_36c6:
	/* 0x36c6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36ca:
	/* 0x36ca: cmp    WORD PTR [r12+0x124],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1254130450432ULL);
x86_l_36d4:
	/* 0x36d4: je     36f6 <generic_sleepable_preload+0x36f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36d4, 0x36f6, x86_l_36f6);
x86_l_36d6:
	/* 0x36d6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_36d9:
	/* 0x36d9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_36de:
	/* 0x36de: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_36e3:
	/* 0x36e3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36e7:
	/* 0x36e7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_36ec:
	/* 0x36ec: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_36ee:
	/* 0x36ee: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_36f0:
	/* 0x36f0: js     3c12 <generic_sleepable_preload+0x3c12> */
	X86_SIM_X86_JCC(X86_CC_S, 0x36f0, 0x3c12, x86_l_3c12);
x86_l_36f6:
	/* 0x36f6: cmp    WORD PTR [r12+0x12e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1297080123392ULL);
x86_l_3700:
	/* 0x3700: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3700, 0x3d18, x86_l_3d18);
x86_l_3706:
	/* 0x3706: mov    ecx,DWORD PTR [r12+0x128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_370e:
	/* 0x370e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3712:
	/* 0x3712: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3716:
	/* 0x3716: cmp    WORD PTR [r12+0x12c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1288490188800ULL);
x86_l_3720:
	/* 0x3720: je     3742 <generic_sleepable_preload+0x3742> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3720, 0x3742, x86_l_3742);
x86_l_3722:
	/* 0x3722: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3725:
	/* 0x3725: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_372a:
	/* 0x372a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_372f:
	/* 0x372f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3733:
	/* 0x3733: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3738:
	/* 0x3738: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_373a:
	/* 0x373a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_373c:
	/* 0x373c: js     3c23 <generic_sleepable_preload+0x3c23> */
	X86_SIM_X86_JCC(X86_CC_S, 0x373c, 0x3c23, x86_l_3c23);
x86_l_3742:
	/* 0x3742: cmp    WORD PTR [r12+0x136],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1331439861760ULL);
x86_l_374c:
	/* 0x374c: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x374c, 0x3d18, x86_l_3d18);
x86_l_3752:
	/* 0x3752: mov    ecx,DWORD PTR [r12+0x130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_375a:
	/* 0x375a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_375e:
	/* 0x375e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3762:
	/* 0x3762: cmp    WORD PTR [r12+0x134],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1322849927168ULL);
x86_l_376c:
	/* 0x376c: je     378e <generic_sleepable_preload+0x378e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x376c, 0x378e, x86_l_378e);
x86_l_376e:
	/* 0x376e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3771:
	/* 0x3771: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3776:
	/* 0x3776: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_377b:
	/* 0x377b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_377f:
	/* 0x377f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3784:
	/* 0x3784: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3786:
	/* 0x3786: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3788:
	/* 0x3788: js     3c34 <generic_sleepable_preload+0x3c34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3788, 0x3c34, x86_l_3c34);
x86_l_378e:
	/* 0x378e: cmp    WORD PTR [r12+0x13e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1365799600128ULL);
x86_l_3798:
	/* 0x3798: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3798, 0x3d18, x86_l_3d18);
x86_l_379e:
	/* 0x379e: mov    ecx,DWORD PTR [r12+0x138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_37a6:
	/* 0x37a6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_37aa:
	/* 0x37aa: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37ae:
	/* 0x37ae: cmp    WORD PTR [r12+0x13c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1357209665536ULL);
x86_l_37b8:
	/* 0x37b8: je     37da <generic_sleepable_preload+0x37da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37b8, 0x37da, x86_l_37da);
x86_l_37ba:
	/* 0x37ba: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_37bd:
	/* 0x37bd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_37c2:
	/* 0x37c2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_37c7:
	/* 0x37c7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37cb:
	/* 0x37cb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_37d0:
	/* 0x37d0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_37d2:
	/* 0x37d2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_37d4:
	/* 0x37d4: js     3c45 <generic_sleepable_preload+0x3c45> */
	X86_SIM_X86_JCC(X86_CC_S, 0x37d4, 0x3c45, x86_l_3c45);
x86_l_37da:
	/* 0x37da: cmp    WORD PTR [r12+0x146],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1400159338496ULL);
x86_l_37e4:
	/* 0x37e4: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37e4, 0x3d18, x86_l_3d18);
x86_l_37ea:
	/* 0x37ea: mov    ecx,DWORD PTR [r12+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_37f2:
	/* 0x37f2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_37f6:
	/* 0x37f6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37fa:
	/* 0x37fa: cmp    WORD PTR [r12+0x144],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1391569403904ULL);
x86_l_3804:
	/* 0x3804: je     3826 <generic_sleepable_preload+0x3826> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3804, 0x3826, x86_l_3826);
x86_l_3806:
	/* 0x3806: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3809:
	/* 0x3809: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_380e:
	/* 0x380e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3813:
	/* 0x3813: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3817:
	/* 0x3817: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_381c:
	/* 0x381c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_381e:
	/* 0x381e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3820:
	/* 0x3820: js     3d10 <generic_sleepable_preload+0x3d10> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3820, 0x3d10, x86_l_3d10);
x86_l_3826:
	/* 0x3826: cmp    WORD PTR [r12+0x14e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1434519076864ULL);
x86_l_3830:
	/* 0x3830: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3830, 0x3d18, x86_l_3d18);
x86_l_3836:
	/* 0x3836: mov    ecx,DWORD PTR [r12+0x148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_383e:
	/* 0x383e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3842:
	/* 0x3842: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3846:
	/* 0x3846: cmp    WORD PTR [r12+0x14c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1425929142272ULL);
x86_l_3850:
	/* 0x3850: je     3872 <generic_sleepable_preload+0x3872> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3850, 0x3872, x86_l_3872);
x86_l_3852:
	/* 0x3852: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3855:
	/* 0x3855: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_385a:
	/* 0x385a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_385f:
	/* 0x385f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3863:
	/* 0x3863: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3868:
	/* 0x3868: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_386a:
	/* 0x386a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_386c:
	/* 0x386c: js     5d47 <generic_sleepable_preload+0x5d47> */
	X86_SIM_X86_JCC(X86_CC_S, 0x386c, 0x5d47, x86_l_5d47);
x86_l_3872:
	/* 0x3872: cmp    WORD PTR [r12+0x156],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1468878815232ULL);
x86_l_387c:
	/* 0x387c: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x387c, 0x3d18, x86_l_3d18);
x86_l_3882:
	/* 0x3882: mov    ecx,DWORD PTR [r12+0x150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_388a:
	/* 0x388a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_388e:
	/* 0x388e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3892:
	/* 0x3892: cmp    WORD PTR [r12+0x154],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1460288880640ULL);
x86_l_389c:
	/* 0x389c: je     38be <generic_sleepable_preload+0x38be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x389c, 0x38be, x86_l_38be);
x86_l_389e:
	/* 0x389e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_38a1:
	/* 0x38a1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_38a6:
	/* 0x38a6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_38ab:
	/* 0x38ab: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38af:
	/* 0x38af: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_38b4:
	/* 0x38b4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_38b6:
	/* 0x38b6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_38b8:
	/* 0x38b8: js     5e46 <generic_sleepable_preload+0x5e46> */
	X86_SIM_X86_JCC(X86_CC_S, 0x38b8, 0x5e46, x86_l_5e46);
x86_l_38be:
	/* 0x38be: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38c3:
	/* 0x38c3: cmp    WORD PTR [r12+0x15e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1503238553600ULL);
x86_l_38cd:
	/* 0x38cd: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38cd, 0x3d18, x86_l_3d18);
x86_l_38d3:
	/* 0x38d3: mov    ecx,DWORD PTR [r12+0x158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_38db:
	/* 0x38db: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_38df:
	/* 0x38df: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38e3:
	/* 0x38e3: cmp    WORD PTR [r12+0x15c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619008ULL);
x86_l_38ed:
	/* 0x38ed: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38ed, 0x3d18, x86_l_3d18);
x86_l_38f3:
	/* 0x38f3: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_38f6:
	/* 0x38f6: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_38fb:
	/* 0x38fb: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3900:
	/* 0x3900: jmp    3bda <generic_sleepable_preload+0x3bda> */
	X86_SIM_X86_JMP(0x3900, 0x3bda, x86_l_3bda);
x86_l_3905:
	/* 0x3905: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_3908:
	/* 0x3908: je     392a <generic_sleepable_preload+0x392a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3908, 0x392a, x86_l_392a);
x86_l_390a:
	/* 0x390a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_390d:
	/* 0x390d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3912:
	/* 0x3912: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3917:
	/* 0x3917: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_391b:
	/* 0x391b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3920:
	/* 0x3920: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3922:
	/* 0x3922: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3924:
	/* 0x3924: js     3bf7 <generic_sleepable_preload+0x3bf7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3924, 0x3bf7, x86_l_3bf7);
x86_l_392a:
	/* 0x392a: cmp    WORD PTR [r12+0x11e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1228360646656ULL);
x86_l_3934:
	/* 0x3934: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3934, 0x3d18, x86_l_3d18);
x86_l_393a:
	/* 0x393a: mov    ecx,DWORD PTR [r12+0x118] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_3942:
	/* 0x3942: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3946:
	/* 0x3946: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_394a:
	/* 0x394a: cmp    WORD PTR [r12+0x11c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1219770712064ULL);
x86_l_3954:
	/* 0x3954: je     3976 <generic_sleepable_preload+0x3976> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3954, 0x3976, x86_l_3976);
x86_l_3956:
	/* 0x3956: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3959:
	/* 0x3959: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_395e:
	/* 0x395e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3963:
	/* 0x3963: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3967:
	/* 0x3967: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_396c:
	/* 0x396c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_396e:
	/* 0x396e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3970:
	/* 0x3970: js     3c01 <generic_sleepable_preload+0x3c01> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3970, 0x3c01, x86_l_3c01);
x86_l_3976:
	/* 0x3976: cmp    WORD PTR [r12+0x126],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1262720385024ULL);
x86_l_3980:
	/* 0x3980: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3980, 0x3d18, x86_l_3d18);
x86_l_3986:
	/* 0x3986: mov    ecx,DWORD PTR [r12+0x120] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_398e:
	/* 0x398e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3992:
	/* 0x3992: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3996:
	/* 0x3996: cmp    WORD PTR [r12+0x124],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1254130450432ULL);
x86_l_39a0:
	/* 0x39a0: je     39c2 <generic_sleepable_preload+0x39c2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39a0, 0x39c2, x86_l_39c2);
x86_l_39a2:
	/* 0x39a2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_39a5:
	/* 0x39a5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_39aa:
	/* 0x39aa: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_39af:
	/* 0x39af: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39b3:
	/* 0x39b3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_39b8:
	/* 0x39b8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_39ba:
	/* 0x39ba: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_39bc:
	/* 0x39bc: js     3c12 <generic_sleepable_preload+0x3c12> */
	X86_SIM_X86_JCC(X86_CC_S, 0x39bc, 0x3c12, x86_l_3c12);
x86_l_39c2:
	/* 0x39c2: cmp    WORD PTR [r12+0x12e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1297080123392ULL);
x86_l_39cc:
	/* 0x39cc: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39cc, 0x3d18, x86_l_3d18);
x86_l_39d2:
	/* 0x39d2: mov    ecx,DWORD PTR [r12+0x128] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_39da:
	/* 0x39da: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_39de:
	/* 0x39de: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39e2:
	/* 0x39e2: cmp    WORD PTR [r12+0x12c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1288490188800ULL);
x86_l_39ec:
	/* 0x39ec: je     3a0e <generic_sleepable_preload+0x3a0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39ec, 0x3a0e, x86_l_3a0e);
x86_l_39ee:
	/* 0x39ee: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_39f1:
	/* 0x39f1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_39f6:
	/* 0x39f6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_39fb:
	/* 0x39fb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39ff:
	/* 0x39ff: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3a04:
	/* 0x3a04: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3a06:
	/* 0x3a06: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3a08:
	/* 0x3a08: js     3c23 <generic_sleepable_preload+0x3c23> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3a08, 0x3c23, x86_l_3c23);
x86_l_3a0e:
	/* 0x3a0e: cmp    WORD PTR [r12+0x136],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1331439861760ULL);
x86_l_3a18:
	/* 0x3a18: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a18, 0x3d18, x86_l_3d18);
x86_l_3a1e:
	/* 0x3a1e: mov    ecx,DWORD PTR [r12+0x130] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_3a26:
	/* 0x3a26: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3a2a:
	/* 0x3a2a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a2e:
	/* 0x3a2e: cmp    WORD PTR [r12+0x134],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1322849927168ULL);
x86_l_3a38:
	/* 0x3a38: je     3a5a <generic_sleepable_preload+0x3a5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a38, 0x3a5a, x86_l_3a5a);
x86_l_3a3a:
	/* 0x3a3a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3a3d:
	/* 0x3a3d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3a42:
	/* 0x3a42: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3a47:
	/* 0x3a47: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a4b:
	/* 0x3a4b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3a50:
	/* 0x3a50: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3a52:
	/* 0x3a52: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3a54:
	/* 0x3a54: js     3c34 <generic_sleepable_preload+0x3c34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3a54, 0x3c34, x86_l_3c34);
x86_l_3a5a:
	/* 0x3a5a: cmp    WORD PTR [r12+0x13e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1365799600128ULL);
x86_l_3a64:
	/* 0x3a64: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a64, 0x3d18, x86_l_3d18);
x86_l_3a6a:
	/* 0x3a6a: mov    ecx,DWORD PTR [r12+0x138] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_3a72:
	/* 0x3a72: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3a76:
	/* 0x3a76: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a7a:
	/* 0x3a7a: cmp    WORD PTR [r12+0x13c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1357209665536ULL);
x86_l_3a84:
	/* 0x3a84: je     3aa6 <generic_sleepable_preload+0x3aa6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a84, 0x3aa6, x86_l_3aa6);
x86_l_3a86:
	/* 0x3a86: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3a89:
	/* 0x3a89: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3a8e:
	/* 0x3a8e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3a93:
	/* 0x3a93: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a97:
	/* 0x3a97: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3a9c:
	/* 0x3a9c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3a9e:
	/* 0x3a9e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3aa0:
	/* 0x3aa0: js     3c45 <generic_sleepable_preload+0x3c45> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3aa0, 0x3c45, x86_l_3c45);
x86_l_3aa6:
	/* 0x3aa6: cmp    WORD PTR [r12+0x146],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1400159338496ULL);
x86_l_3ab0:
	/* 0x3ab0: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ab0, 0x3d18, x86_l_3d18);
x86_l_3ab6:
	/* 0x3ab6: mov    ecx,DWORD PTR [r12+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_3abe:
	/* 0x3abe: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3ac2:
	/* 0x3ac2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ac6:
	/* 0x3ac6: cmp    WORD PTR [r12+0x144],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1391569403904ULL);
x86_l_3ad0:
	/* 0x3ad0: je     3af2 <generic_sleepable_preload+0x3af2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ad0, 0x3af2, x86_l_3af2);
x86_l_3ad2:
	/* 0x3ad2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3ad5:
	/* 0x3ad5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3ada:
	/* 0x3ada: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3adf:
	/* 0x3adf: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ae3:
	/* 0x3ae3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3ae8:
	/* 0x3ae8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3aea:
	/* 0x3aea: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3aec:
	/* 0x3aec: js     3d10 <generic_sleepable_preload+0x3d10> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3aec, 0x3d10, x86_l_3d10);
x86_l_3af2:
	/* 0x3af2: cmp    WORD PTR [r12+0x14e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1434519076864ULL);
x86_l_3afc:
	/* 0x3afc: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3afc, 0x3d18, x86_l_3d18);
x86_l_3b02:
	/* 0x3b02: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_3b05:
	/* 0x3b05: mov    ecx,DWORD PTR [r12+0x148] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_3b0d:
	/* 0x3b0d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3b11:
	/* 0x3b11: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b15:
	/* 0x3b15: cmp    WORD PTR [r12+0x14c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1425929142272ULL);
x86_l_3b1f:
	/* 0x3b1f: je     3b41 <generic_sleepable_preload+0x3b41> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b1f, 0x3b41, x86_l_3b41);
x86_l_3b21:
	/* 0x3b21: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3b24:
	/* 0x3b24: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3b29:
	/* 0x3b29: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3b2e:
	/* 0x3b2e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b32:
	/* 0x3b32: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3b37:
	/* 0x3b37: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3b39:
	/* 0x3b39: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3b3b:
	/* 0x3b3b: js     5dc5 <generic_sleepable_preload+0x5dc5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3b3b, 0x5dc5, x86_l_5dc5);
x86_l_3b41:
	/* 0x3b41: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3b46:
	/* 0x3b46: cmp    WORD PTR [r12+0x156],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1468878815232ULL);
x86_l_3b50:
	/* 0x3b50: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_3b53:
	/* 0x3b53: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b53, 0x3d18, x86_l_3d18);
x86_l_3b59:
	/* 0x3b59: mov    ecx,DWORD PTR [r12+0x150] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_3b61:
	/* 0x3b61: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3b65:
	/* 0x3b65: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b69:
	/* 0x3b69: cmp    WORD PTR [r12+0x154],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1460288880640ULL);
x86_l_3b73:
	/* 0x3b73: je     3b95 <generic_sleepable_preload+0x3b95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b73, 0x3b95, x86_l_3b95);
x86_l_3b75:
	/* 0x3b75: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3b78:
	/* 0x3b78: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3b7d:
	/* 0x3b7d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3b82:
	/* 0x3b82: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b86:
	/* 0x3b86: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3b8b:
	/* 0x3b8b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3b8d:
	/* 0x3b8d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3b8f:
	/* 0x3b8f: js     5ee5 <generic_sleepable_preload+0x5ee5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3b8f, 0x5ee5, x86_l_5ee5);
x86_l_3b95:
	/* 0x3b95: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3b9a:
	/* 0x3b9a: cmp    WORD PTR [r12+0x15e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1503238553600ULL);
x86_l_3ba4:
	/* 0x3ba4: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_3ba7:
	/* 0x3ba7: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ba7, 0x3d18, x86_l_3d18);
x86_l_3bad:
	/* 0x3bad: mov    ecx,DWORD PTR [r12+0x158] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_3bb5:
	/* 0x3bb5: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3bb9:
	/* 0x3bb9: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bbd:
	/* 0x3bbd: cmp    WORD PTR [r12+0x15c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619008ULL);
x86_l_3bc7:
	/* 0x3bc7: je     3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3bc7, 0x3d18, x86_l_3d18);
x86_l_3bcd:
	/* 0x3bcd: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3bd0:
	/* 0x3bd0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3bd5:
	/* 0x3bd5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3bda:
	/* 0x3bda: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bde:
	/* 0x3bde: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3be3:
	/* 0x3be3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3be5:
	/* 0x3be5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3be7:
	/* 0x3be7: jns    3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3be7, 0x3d18, x86_l_3d18);
x86_l_3bed:
	/* 0x3bed: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_3bf2:
	/* 0x3bf2: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3bf2, 0x3d15, x86_l_3d15);
x86_l_3bf7:
	/* 0x3bf7: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_3bfc:
	/* 0x3bfc: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3bfc, 0x3d15, x86_l_3d15);
x86_l_3c01:
	/* 0x3c01: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_3c06:
	/* 0x3c06: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3c06, 0x3d15, x86_l_3d15);
x86_l_3c0b:
	/* 0x3c0b: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_3c10:
	/* 0x3c10: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x3c10, 0x3c54, x86_l_3c54);
x86_l_3c12:
	/* 0x3c12: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_3c17:
	/* 0x3c17: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3c17, 0x3d15, x86_l_3d15);
x86_l_3c1c:
	/* 0x3c1c: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_3c21:
	/* 0x3c21: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x3c21, 0x3c54, x86_l_3c54);
x86_l_3c23:
	/* 0x3c23: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_3c28:
	/* 0x3c28: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3c28, 0x3d15, x86_l_3d15);
x86_l_3c2d:
	/* 0x3c2d: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_3c32:
	/* 0x3c32: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x3c32, 0x3c54, x86_l_3c54);
x86_l_3c34:
	/* 0x3c34: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_3c39:
	/* 0x3c39: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3c39, 0x3d15, x86_l_3d15);
x86_l_3c3e:
	/* 0x3c3e: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_3c43:
	/* 0x3c43: jmp    3c54 <generic_sleepable_preload+0x3c54> */
	X86_SIM_X86_JMP(0x3c43, 0x3c54, x86_l_3c54);
x86_l_3c45:
	/* 0x3c45: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_3c4a:
	/* 0x3c4a: jmp    3d15 <generic_sleepable_preload+0x3d15> */
	X86_SIM_X86_JMP(0x3c4a, 0x3d15, x86_l_3d15);
x86_l_3c4f:
	/* 0x3c4f: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_3c54:
	/* 0x3c54: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3c57:
	/* 0x3c57: mov    ebp,DWORD PTR [r12+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3c5c:
	/* 0x3c5c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3c5f:
	/* 0x3c5f: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3c64:
	/* 0x3c64: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3c69:
	/* 0x3c69: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3c6e:
	/* 0x3c6e: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_3c71:
	/* 0x3c71: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3c73:
	/* 0x3c73: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_3c76:
	/* 0x3c76: jne    3dc4 <generic_sleepable_preload+0x3dc4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c76, 0x3dc4, x86_l_3dc4);
x86_l_3c7c:
	/* 0x3c7c: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_3c7f:
	/* 0x3c7f: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c83:
	/* 0x3c83: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_3c88:
	/* 0x3c88: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3c8a:
	/* 0x3c8a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3c8f:
	/* 0x3c8f: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_3c97:
	/* 0x3c97: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_3c9e:
	/* 0x3c9e: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3ca3:
	/* 0x3ca3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3ca8:
	/* 0x3ca8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3caa:
	/* 0x3caa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3cad:
	/* 0x3cad: je     3dc1 <generic_sleepable_preload+0x3dc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3cad, 0x3dc1, x86_l_3dc1);
x86_l_3cb3:
	/* 0x3cb3: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3cb6:
	/* 0x3cb6: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_3cbd:
	/* 0x3cbd: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3cbf:
	/* 0x3cbf: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3cc4:
	/* 0x3cc4: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3cc9:
	/* 0x3cc9: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_3ccc:
	/* 0x3ccc: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_3ccf:
	/* 0x3ccf: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3cd1:
	/* 0x3cd1: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3cd3:
	/* 0x3cd3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3cd8:
	/* 0x3cd8: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_3cdb:
	/* 0x3cdb: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_3cde:
	/* 0x3cde: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3ce3:
	/* 0x3ce3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3ce5:
	/* 0x3ce5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3ce8:
	/* 0x3ce8: je     3dc1 <generic_sleepable_preload+0x3dc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ce8, 0x3dc1, x86_l_3dc1);
x86_l_3cee:
	/* 0x3cee: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_3cf1:
	/* 0x3cf1: je     3dbf <generic_sleepable_preload+0x3dbf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3cf1, 0x3dbf, x86_l_3dbf);
x86_l_3cf7:
	/* 0x3cf7: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3cfa:
	/* 0x3cfa: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3cfe:
	/* 0x3cfe: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_3d03:
	/* 0x3d03: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_3d06:
	/* 0x3d06: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3d0b:
	/* 0x3d0b: jmp    3da4 <generic_sleepable_preload+0x3da4> */
	X86_SIM_X86_JMP(0x3d0b, 0x3da4, x86_l_3da4);
x86_l_3d10:
	/* 0x3d10: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_3d15:
	/* 0x3d15: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3d18:
	/* 0x3d18: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_3d1b:
	/* 0x3d1b: jne    3dc4 <generic_sleepable_preload+0x3dc4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d1b, 0x3dc4, x86_l_3dc4);
x86_l_3d21:
	/* 0x3d21: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_3d24:
	/* 0x3d24: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d28:
	/* 0x3d28: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_3d2d:
	/* 0x3d2d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3d2f:
	/* 0x3d2f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d34:
	/* 0x3d34: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_3d3c:
	/* 0x3d3c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_3d43:
	/* 0x3d43: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3d48:
	/* 0x3d48: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3d4d:
	/* 0x3d4d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3d4f:
	/* 0x3d4f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3d52:
	/* 0x3d52: je     3dc1 <generic_sleepable_preload+0x3dc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d52, 0x3dc1, x86_l_3dc1);
x86_l_3d54:
	/* 0x3d54: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_3d57:
	/* 0x3d57: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_3d5e:
	/* 0x3d5e: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3d60:
	/* 0x3d60: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d65:
	/* 0x3d65: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3d6a:
	/* 0x3d6a: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_3d6d:
	/* 0x3d6d: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_3d70:
	/* 0x3d70: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3d72:
	/* 0x3d72: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3d74:
	/* 0x3d74: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3d79:
	/* 0x3d79: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_3d7c:
	/* 0x3d7c: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_3d7f:
	/* 0x3d7f: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3d84:
	/* 0x3d84: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3d86:
	/* 0x3d86: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3d89:
	/* 0x3d89: je     3dc1 <generic_sleepable_preload+0x3dc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d89, 0x3dc1, x86_l_3dc1);
x86_l_3d8b:
	/* 0x3d8b: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_3d8e:
	/* 0x3d8e: je     3dbf <generic_sleepable_preload+0x3dbf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d8e, 0x3dbf, x86_l_3dbf);
x86_l_3d90:
	/* 0x3d90: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_3d93:
	/* 0x3d93: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3d97:
	/* 0x3d97: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_3d9c:
	/* 0x3d9c: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_3d9f:
	/* 0x3d9f: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_3da4:
	/* 0x3da4: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_3da9:
	/* 0x3da9: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_3dac:
	/* 0x3dac: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3dae:
	/* 0x3dae: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_3db1:
	/* 0x3db1: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_3db4:
	/* 0x3db4: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_3db7:
	/* 0x3db7: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_3dbc:
	/* 0x3dbc: cmovs  ebx,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_3dbf:
	/* 0x3dbf: mov    DWORD PTR [rax],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3dc1:
	/* 0x3dc1: mov    r14,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBP, X86_WIDTH_64);
x86_l_3dc4:
	/* 0x3dc4: mov    eax,DWORD PTR [r12+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_3dc9:
	/* 0x3dc9: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_3dce:
	/* 0x3dce: je     4d6c <generic_sleepable_preload+0x4d6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3dce, 0x4d6c, x86_l_4d6c);
x86_l_3dd4:
	/* 0x3dd4: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_3dd6:
	/* 0x3dd6: js     3e0b <generic_sleepable_preload+0x3e0b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3dd6, 0x3e0b, x86_l_3e0b);
x86_l_3dd8:
	/* 0x3dd8: mov    eax,DWORD PTR [r12+0x4c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_3ddd:
	/* 0x3ddd: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3de0:
	/* 0x3de0: jle    3e8e <generic_sleepable_preload+0x3e8e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3de0, 0x3e8e, x86_l_3e8e);
x86_l_3de6:
	/* 0x3de6: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3de9:
	/* 0x3de9: je     3ef8 <generic_sleepable_preload+0x3ef8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3de9, 0x3ef8, x86_l_3ef8);
x86_l_3def:
	/* 0x3def: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_3df2:
	/* 0x3df2: je     3eff <generic_sleepable_preload+0x3eff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3df2, 0x3eff, x86_l_3eff);
x86_l_3df8:
	/* 0x3df8: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_3dfb:
	/* 0x3dfb: jne    3f12 <generic_sleepable_preload+0x3f12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3dfb, 0x3f12, x86_l_3f12);
x86_l_3e01:
	/* 0x3e01: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3e06:
	/* 0x3e06: jmp    3f0b <generic_sleepable_preload+0x3f0b> */
	X86_SIM_X86_JMP(0x3e06, 0x3f0b, x86_l_3f0b);
x86_l_3e0b:
	/* 0x3e0b: movzx  eax,BYTE PTR [r12+0x2ce] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 718ULL);
x86_l_3e14:
	/* 0x3e14: movzx  ecx,WORD PTR [r12+0x2cc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 716ULL);
x86_l_3e1d:
	/* 0x3e1d: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_3e23:
	/* 0x3e23: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3e25:
	/* 0x3e25: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_3e28:
	/* 0x3e28: jle    3e67 <generic_sleepable_preload+0x3e67> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3e28, 0x3e67, x86_l_3e67);
x86_l_3e2a:
	/* 0x3e2a: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_3e2d:
	/* 0x3e2d: jle    3e9e <generic_sleepable_preload+0x3e9e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3e2d, 0x3e9e, x86_l_3e9e);
x86_l_3e2f:
	/* 0x3e2f: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_3e32:
	/* 0x3e32: jle    4561 <generic_sleepable_preload+0x4561> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x3e32, 0x4561, x86_l_4561);
x86_l_3e38:
	/* 0x3e38: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3e3d:
	/* 0x3e3d: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_3e40:
	/* 0x3e40: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e40, 0x4586, x86_l_4586);
x86_l_3e46:
	/* 0x3e46: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3e4b:
	/* 0x3e4b: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_3e4e:
	/* 0x3e4e: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e4e, 0x4586, x86_l_4586);
x86_l_3e54:
	/* 0x3e54: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3e59:
	/* 0x3e59: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_3e5c:
	/* 0x3e5c: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e5c, 0x4586, x86_l_4586);
x86_l_3e62:
	/* 0x3e62: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x3e62, 0x4599, x86_l_4599);
x86_l_3e67:
	/* 0x3e67: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_3e6a:
	/* 0x3e6a: jg     3ecb <generic_sleepable_preload+0x3ecb> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3e6a, 0x3ecb, x86_l_3ecb);
x86_l_3e6c:
	/* 0x3e6c: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_3e6f:
	/* 0x3e6f: jg     4532 <generic_sleepable_preload+0x4532> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3e6f, 0x4532, x86_l_4532);
x86_l_3e75:
	/* 0x3e75: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_3e77:
	/* 0x3e77: je     4581 <generic_sleepable_preload+0x4581> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e77, 0x4581, x86_l_4581);
x86_l_3e7d:
	/* 0x3e7d: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_3e80:
	/* 0x3e80: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_3e83:
	/* 0x3e83: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e83, 0x4586, x86_l_4586);
x86_l_3e89:
	/* 0x3e89: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x3e89, 0x4599, x86_l_4599);
x86_l_3e8e:
	/* 0x3e8e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3e90:
	/* 0x3e90: je     3f06 <generic_sleepable_preload+0x3f06> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e90, 0x3f06, x86_l_3f06);
x86_l_3e92:
	/* 0x3e92: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3e95:
	/* 0x3e95: jne    3f12 <generic_sleepable_preload+0x3f12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e95, 0x3f12, x86_l_3f12);
x86_l_3e97:
	/* 0x3e97: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3e9c:
	/* 0x3e9c: jmp    3f0b <generic_sleepable_preload+0x3f0b> */
	X86_SIM_X86_JMP(0x3e9c, 0x3f0b, x86_l_3f0b);
x86_l_3e9e:
	/* 0x3e9e: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_3ea1:
	/* 0x3ea1: jg     4519 <generic_sleepable_preload+0x4519> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3ea1, 0x4519, x86_l_4519);
x86_l_3ea7:
	/* 0x3ea7: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3eaf:
	/* 0x3eaf: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3eb2:
	/* 0x3eb2: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3eb2, 0x4586, x86_l_4586);
x86_l_3eb8:
	/* 0x3eb8: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3ebd:
	/* 0x3ebd: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_3ec0:
	/* 0x3ec0: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ec0, 0x4586, x86_l_4586);
x86_l_3ec6:
	/* 0x3ec6: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x3ec6, 0x4599, x86_l_4599);
x86_l_3ecb:
	/* 0x3ecb: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_3ece:
	/* 0x3ece: jg     4548 <generic_sleepable_preload+0x4548> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3ece, 0x4548, x86_l_4548);
x86_l_3ed4:
	/* 0x3ed4: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3edc:
	/* 0x3edc: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_3edf:
	/* 0x3edf: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3edf, 0x4586, x86_l_4586);
x86_l_3ee5:
	/* 0x3ee5: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3eea:
	/* 0x3eea: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_3eed:
	/* 0x3eed: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3eed, 0x4586, x86_l_4586);
x86_l_3ef3:
	/* 0x3ef3: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x3ef3, 0x4599, x86_l_4599);
x86_l_3ef8:
	/* 0x3ef8: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3efd:
	/* 0x3efd: jmp    3f0b <generic_sleepable_preload+0x3f0b> */
	X86_SIM_X86_JMP(0x3efd, 0x3f0b, x86_l_3f0b);
x86_l_3eff:
	/* 0x3eff: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f04:
	/* 0x3f04: jmp    3f0b <generic_sleepable_preload+0x3f0b> */
	X86_SIM_X86_JMP(0x3f04, 0x3f0b, x86_l_3f0b);
x86_l_3f06:
	/* 0x3f06: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3f0b:
	/* 0x3f0b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f0e:
	/* 0x3f0e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f12:
	/* 0x3f12: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3f14:
	/* 0x3f14: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_3f17:
	/* 0x3f17: cmp    WORD PTR [r12+0x166],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1537598291968ULL);
x86_l_3f21:
	/* 0x3f21: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f21, 0x4bff, x86_l_4bff);
x86_l_3f27:
	/* 0x3f27: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_3f2e:
	/* 0x3f2e: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_3f31:
	/* 0x3f31: mov    eax,DWORD PTR [r12+0x160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_3f39:
	/* 0x3f39: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3f3c:
	/* 0x3f3c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f40:
	/* 0x3f40: movzx  eax,WORD PTR [r12+0x164] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 356ULL);
x86_l_3f49:
	/* 0x3f49: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_3f4b:
	/* 0x3f4b: je     421d <generic_sleepable_preload+0x421d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f4b, 0x421d, x86_l_421d);
x86_l_3f51:
	/* 0x3f51: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_3f54:
	/* 0x3f54: je     3f76 <generic_sleepable_preload+0x3f76> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f54, 0x3f76, x86_l_3f76);
x86_l_3f56:
	/* 0x3f56: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3f59:
	/* 0x3f59: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3f5e:
	/* 0x3f5e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3f63:
	/* 0x3f63: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f67:
	/* 0x3f67: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3f6c:
	/* 0x3f6c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3f6e:
	/* 0x3f6e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3f70:
	/* 0x3f70: js     450f <generic_sleepable_preload+0x450f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3f70, 0x450f, x86_l_450f);
x86_l_3f76:
	/* 0x3f76: cmp    WORD PTR [r12+0x16e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1571958030336ULL);
x86_l_3f80:
	/* 0x3f80: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f80, 0x4bff, x86_l_4bff);
x86_l_3f86:
	/* 0x3f86: mov    ecx,DWORD PTR [r12+0x168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_3f8e:
	/* 0x3f8e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3f92:
	/* 0x3f92: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f96:
	/* 0x3f96: cmp    WORD PTR [r12+0x16c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1563368095744ULL);
x86_l_3fa0:
	/* 0x3fa0: je     3fc2 <generic_sleepable_preload+0x3fc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fa0, 0x3fc2, x86_l_3fc2);
x86_l_3fa2:
	/* 0x3fa2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3fa5:
	/* 0x3fa5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3faa:
	/* 0x3faa: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3faf:
	/* 0x3faf: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fb3:
	/* 0x3fb3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3fb8:
	/* 0x3fb8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_3fba:
	/* 0x3fba: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_3fbc:
	/* 0x3fbc: js     4577 <generic_sleepable_preload+0x4577> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3fbc, 0x4577, x86_l_4577);
x86_l_3fc2:
	/* 0x3fc2: cmp    WORD PTR [r12+0x176],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1606317768704ULL);
x86_l_3fcc:
	/* 0x3fcc: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fcc, 0x4bff, x86_l_4bff);
x86_l_3fd2:
	/* 0x3fd2: mov    ecx,DWORD PTR [r12+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_3fda:
	/* 0x3fda: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_3fde:
	/* 0x3fde: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fe2:
	/* 0x3fe2: cmp    WORD PTR [r12+0x174],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1597727834112ULL);
x86_l_3fec:
	/* 0x3fec: je     400e <generic_sleepable_preload+0x400e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fec, 0x400e, x86_l_400e);
x86_l_3fee:
	/* 0x3fee: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3ff1:
	/* 0x3ff1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_3ff6:
	/* 0x3ff6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_3ffb:
	/* 0x3ffb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fff:
	/* 0x3fff: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4004:
	/* 0x4004: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4006:
	/* 0x4006: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4008:
	/* 0x4008: js     4bb3 <generic_sleepable_preload+0x4bb3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4008, 0x4bb3, x86_l_4bb3);
x86_l_400e:
	/* 0x400e: cmp    WORD PTR [r12+0x17e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1640677507072ULL);
x86_l_4018:
	/* 0x4018: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4018, 0x4bff, x86_l_4bff);
x86_l_401e:
	/* 0x401e: mov    ecx,DWORD PTR [r12+0x178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_4026:
	/* 0x4026: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_402a:
	/* 0x402a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_402e:
	/* 0x402e: cmp    WORD PTR [r12+0x17c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1632087572480ULL);
x86_l_4038:
	/* 0x4038: je     405a <generic_sleepable_preload+0x405a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4038, 0x405a, x86_l_405a);
x86_l_403a:
	/* 0x403a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_403d:
	/* 0x403d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4042:
	/* 0x4042: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4047:
	/* 0x4047: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_404b:
	/* 0x404b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4050:
	/* 0x4050: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4052:
	/* 0x4052: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4054:
	/* 0x4054: js     4bc4 <generic_sleepable_preload+0x4bc4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4054, 0x4bc4, x86_l_4bc4);
x86_l_405a:
	/* 0x405a: cmp    WORD PTR [r12+0x186],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1675037245440ULL);
x86_l_4064:
	/* 0x4064: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4064, 0x4bff, x86_l_4bff);
x86_l_406a:
	/* 0x406a: mov    ecx,DWORD PTR [r12+0x180] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_4072:
	/* 0x4072: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4076:
	/* 0x4076: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_407a:
	/* 0x407a: cmp    WORD PTR [r12+0x184],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1666447310848ULL);
x86_l_4084:
	/* 0x4084: je     40a6 <generic_sleepable_preload+0x40a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4084, 0x40a6, x86_l_40a6);
x86_l_4086:
	/* 0x4086: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4089:
	/* 0x4089: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_408e:
	/* 0x408e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4093:
	/* 0x4093: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4097:
	/* 0x4097: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_409c:
	/* 0x409c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_409e:
	/* 0x409e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_40a0:
	/* 0x40a0: js     4bd5 <generic_sleepable_preload+0x4bd5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x40a0, 0x4bd5, x86_l_4bd5);
x86_l_40a6:
	/* 0x40a6: cmp    WORD PTR [r12+0x18e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1709396983808ULL);
x86_l_40b0:
	/* 0x40b0: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40b0, 0x4bff, x86_l_4bff);
x86_l_40b6:
	/* 0x40b6: mov    ecx,DWORD PTR [r12+0x188] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 392ULL);
x86_l_40be:
	/* 0x40be: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_40c2:
	/* 0x40c2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40c6:
	/* 0x40c6: cmp    WORD PTR [r12+0x18c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1700807049216ULL);
x86_l_40d0:
	/* 0x40d0: je     40f2 <generic_sleepable_preload+0x40f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40d0, 0x40f2, x86_l_40f2);
x86_l_40d2:
	/* 0x40d2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_40d5:
	/* 0x40d5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_40da:
	/* 0x40da: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_40df:
	/* 0x40df: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40e3:
	/* 0x40e3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_40e8:
	/* 0x40e8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_40ea:
	/* 0x40ea: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_40ec:
	/* 0x40ec: js     4be6 <generic_sleepable_preload+0x4be6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x40ec, 0x4be6, x86_l_4be6);
x86_l_40f2:
	/* 0x40f2: cmp    WORD PTR [r12+0x196],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1743756722176ULL);
x86_l_40fc:
	/* 0x40fc: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40fc, 0x4bff, x86_l_4bff);
x86_l_4102:
	/* 0x4102: mov    ecx,DWORD PTR [r12+0x190] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 400ULL);
x86_l_410a:
	/* 0x410a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_410e:
	/* 0x410e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4112:
	/* 0x4112: cmp    WORD PTR [r12+0x194],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1735166787584ULL);
x86_l_411c:
	/* 0x411c: je     413e <generic_sleepable_preload+0x413e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x411c, 0x413e, x86_l_413e);
x86_l_411e:
	/* 0x411e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4121:
	/* 0x4121: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4126:
	/* 0x4126: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_412b:
	/* 0x412b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_412f:
	/* 0x412f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4134:
	/* 0x4134: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4136:
	/* 0x4136: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4138:
	/* 0x4138: js     4bf7 <generic_sleepable_preload+0x4bf7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4138, 0x4bf7, x86_l_4bf7);
x86_l_413e:
	/* 0x413e: cmp    WORD PTR [r12+0x19e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1778116460544ULL);
x86_l_4148:
	/* 0x4148: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4148, 0x4bff, x86_l_4bff);
x86_l_414e:
	/* 0x414e: mov    ecx,DWORD PTR [r12+0x198] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 408ULL);
x86_l_4156:
	/* 0x4156: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_415a:
	/* 0x415a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_415e:
	/* 0x415e: cmp    WORD PTR [r12+0x19c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1769526525952ULL);
x86_l_4168:
	/* 0x4168: je     418a <generic_sleepable_preload+0x418a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4168, 0x418a, x86_l_418a);
x86_l_416a:
	/* 0x416a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_416d:
	/* 0x416d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4172:
	/* 0x4172: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4177:
	/* 0x4177: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_417b:
	/* 0x417b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4180:
	/* 0x4180: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4182:
	/* 0x4182: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4184:
	/* 0x4184: js     5d54 <generic_sleepable_preload+0x5d54> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4184, 0x5d54, x86_l_5d54);
x86_l_418a:
	/* 0x418a: cmp    WORD PTR [r12+0x1a6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1812476198912ULL);
x86_l_4194:
	/* 0x4194: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4194, 0x4bff, x86_l_4bff);
x86_l_419a:
	/* 0x419a: mov    ecx,DWORD PTR [r12+0x1a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 416ULL);
x86_l_41a2:
	/* 0x41a2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_41a6:
	/* 0x41a6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41aa:
	/* 0x41aa: cmp    WORD PTR [r12+0x1a4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1803886264320ULL);
x86_l_41b4:
	/* 0x41b4: je     41d6 <generic_sleepable_preload+0x41d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41b4, 0x41d6, x86_l_41d6);
x86_l_41b6:
	/* 0x41b6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_41b9:
	/* 0x41b9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_41be:
	/* 0x41be: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_41c3:
	/* 0x41c3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41c7:
	/* 0x41c7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_41cc:
	/* 0x41cc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_41ce:
	/* 0x41ce: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_41d0:
	/* 0x41d0: js     5e58 <generic_sleepable_preload+0x5e58> */
	X86_SIM_X86_JCC(X86_CC_S, 0x41d0, 0x5e58, x86_l_5e58);
x86_l_41d6:
	/* 0x41d6: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_41db:
	/* 0x41db: cmp    WORD PTR [r12+0x1ae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1846835937280ULL);
x86_l_41e5:
	/* 0x41e5: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41e5, 0x4bff, x86_l_4bff);
x86_l_41eb:
	/* 0x41eb: mov    ecx,DWORD PTR [r12+0x1a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 424ULL);
x86_l_41f3:
	/* 0x41f3: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_41f7:
	/* 0x41f7: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41fb:
	/* 0x41fb: cmp    WORD PTR [r12+0x1ac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1838246002688ULL);
x86_l_4205:
	/* 0x4205: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4205, 0x4bff, x86_l_4bff);
x86_l_420b:
	/* 0x420b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_420e:
	/* 0x420e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4213:
	/* 0x4213: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4218:
	/* 0x4218: jmp    44f2 <generic_sleepable_preload+0x44f2> */
	X86_SIM_X86_JMP(0x4218, 0x44f2, x86_l_44f2);
x86_l_421d:
	/* 0x421d: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_4220:
	/* 0x4220: je     4242 <generic_sleepable_preload+0x4242> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4220, 0x4242, x86_l_4242);
x86_l_4222:
	/* 0x4222: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4225:
	/* 0x4225: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_422a:
	/* 0x422a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_422f:
	/* 0x422f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4233:
	/* 0x4233: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4238:
	/* 0x4238: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_423a:
	/* 0x423a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_423c:
	/* 0x423c: js     450f <generic_sleepable_preload+0x450f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x423c, 0x450f, x86_l_450f);
x86_l_4242:
	/* 0x4242: cmp    WORD PTR [r12+0x16e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1571958030336ULL);
x86_l_424c:
	/* 0x424c: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x424c, 0x4bff, x86_l_4bff);
x86_l_4252:
	/* 0x4252: mov    ecx,DWORD PTR [r12+0x168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_425a:
	/* 0x425a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_425e:
	/* 0x425e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4262:
	/* 0x4262: cmp    WORD PTR [r12+0x16c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1563368095744ULL);
x86_l_426c:
	/* 0x426c: je     428e <generic_sleepable_preload+0x428e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x426c, 0x428e, x86_l_428e);
x86_l_426e:
	/* 0x426e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4271:
	/* 0x4271: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4276:
	/* 0x4276: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_427b:
	/* 0x427b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_427f:
	/* 0x427f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4284:
	/* 0x4284: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4286:
	/* 0x4286: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4288:
	/* 0x4288: js     4577 <generic_sleepable_preload+0x4577> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4288, 0x4577, x86_l_4577);
x86_l_428e:
	/* 0x428e: cmp    WORD PTR [r12+0x176],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1606317768704ULL);
x86_l_4298:
	/* 0x4298: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4298, 0x4bff, x86_l_4bff);
x86_l_429e:
	/* 0x429e: mov    ecx,DWORD PTR [r12+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_42a6:
	/* 0x42a6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_42aa:
	/* 0x42aa: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_42ae:
	/* 0x42ae: cmp    WORD PTR [r12+0x174],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1597727834112ULL);
x86_l_42b8:
	/* 0x42b8: je     42da <generic_sleepable_preload+0x42da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42b8, 0x42da, x86_l_42da);
x86_l_42ba:
	/* 0x42ba: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_42bd:
	/* 0x42bd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_42c2:
	/* 0x42c2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_42c7:
	/* 0x42c7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_42cb:
	/* 0x42cb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_42d0:
	/* 0x42d0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_42d2:
	/* 0x42d2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_42d4:
	/* 0x42d4: js     4bb3 <generic_sleepable_preload+0x4bb3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x42d4, 0x4bb3, x86_l_4bb3);
x86_l_42da:
	/* 0x42da: cmp    WORD PTR [r12+0x17e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1640677507072ULL);
x86_l_42e4:
	/* 0x42e4: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42e4, 0x4bff, x86_l_4bff);
x86_l_42ea:
	/* 0x42ea: mov    ecx,DWORD PTR [r12+0x178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_42f2:
	/* 0x42f2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_42f6:
	/* 0x42f6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_42fa:
	/* 0x42fa: cmp    WORD PTR [r12+0x17c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1632087572480ULL);
x86_l_4304:
	/* 0x4304: je     4326 <generic_sleepable_preload+0x4326> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4304, 0x4326, x86_l_4326);
x86_l_4306:
	/* 0x4306: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4309:
	/* 0x4309: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_430e:
	/* 0x430e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4313:
	/* 0x4313: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4317:
	/* 0x4317: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_431c:
	/* 0x431c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_431e:
	/* 0x431e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4320:
	/* 0x4320: js     4bc4 <generic_sleepable_preload+0x4bc4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4320, 0x4bc4, x86_l_4bc4);
x86_l_4326:
	/* 0x4326: cmp    WORD PTR [r12+0x186],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1675037245440ULL);
x86_l_4330:
	/* 0x4330: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4330, 0x4bff, x86_l_4bff);
x86_l_4336:
	/* 0x4336: mov    ecx,DWORD PTR [r12+0x180] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_433e:
	/* 0x433e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4342:
	/* 0x4342: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4346:
	/* 0x4346: cmp    WORD PTR [r12+0x184],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1666447310848ULL);
x86_l_4350:
	/* 0x4350: je     4372 <generic_sleepable_preload+0x4372> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4350, 0x4372, x86_l_4372);
x86_l_4352:
	/* 0x4352: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4355:
	/* 0x4355: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_435a:
	/* 0x435a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_435f:
	/* 0x435f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4363:
	/* 0x4363: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4368:
	/* 0x4368: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_436a:
	/* 0x436a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_436c:
	/* 0x436c: js     4bd5 <generic_sleepable_preload+0x4bd5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x436c, 0x4bd5, x86_l_4bd5);
x86_l_4372:
	/* 0x4372: cmp    WORD PTR [r12+0x18e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1709396983808ULL);
x86_l_437c:
	/* 0x437c: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x437c, 0x4bff, x86_l_4bff);
x86_l_4382:
	/* 0x4382: mov    ecx,DWORD PTR [r12+0x188] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 392ULL);
x86_l_438a:
	/* 0x438a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_438e:
	/* 0x438e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4392:
	/* 0x4392: cmp    WORD PTR [r12+0x18c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1700807049216ULL);
x86_l_439c:
	/* 0x439c: je     43be <generic_sleepable_preload+0x43be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x439c, 0x43be, x86_l_43be);
x86_l_439e:
	/* 0x439e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_43a1:
	/* 0x43a1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_43a6:
	/* 0x43a6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_43ab:
	/* 0x43ab: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43af:
	/* 0x43af: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_43b4:
	/* 0x43b4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_43b6:
	/* 0x43b6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_43b8:
	/* 0x43b8: js     4be6 <generic_sleepable_preload+0x4be6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x43b8, 0x4be6, x86_l_4be6);
x86_l_43be:
	/* 0x43be: cmp    WORD PTR [r12+0x196],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1743756722176ULL);
x86_l_43c8:
	/* 0x43c8: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43c8, 0x4bff, x86_l_4bff);
x86_l_43ce:
	/* 0x43ce: mov    ecx,DWORD PTR [r12+0x190] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 400ULL);
x86_l_43d6:
	/* 0x43d6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_43da:
	/* 0x43da: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43de:
	/* 0x43de: cmp    WORD PTR [r12+0x194],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1735166787584ULL);
x86_l_43e8:
	/* 0x43e8: je     440a <generic_sleepable_preload+0x440a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43e8, 0x440a, x86_l_440a);
x86_l_43ea:
	/* 0x43ea: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_43ed:
	/* 0x43ed: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_43f2:
	/* 0x43f2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_43f7:
	/* 0x43f7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43fb:
	/* 0x43fb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4400:
	/* 0x4400: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4402:
	/* 0x4402: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4404:
	/* 0x4404: js     4bf7 <generic_sleepable_preload+0x4bf7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4404, 0x4bf7, x86_l_4bf7);
x86_l_440a:
	/* 0x440a: cmp    WORD PTR [r12+0x19e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1778116460544ULL);
x86_l_4414:
	/* 0x4414: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4414, 0x4bff, x86_l_4bff);
x86_l_441a:
	/* 0x441a: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_441d:
	/* 0x441d: mov    ecx,DWORD PTR [r12+0x198] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 408ULL);
x86_l_4425:
	/* 0x4425: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4429:
	/* 0x4429: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_442d:
	/* 0x442d: cmp    WORD PTR [r12+0x19c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1769526525952ULL);
x86_l_4437:
	/* 0x4437: je     4459 <generic_sleepable_preload+0x4459> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4437, 0x4459, x86_l_4459);
x86_l_4439:
	/* 0x4439: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_443c:
	/* 0x443c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4441:
	/* 0x4441: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4446:
	/* 0x4446: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_444a:
	/* 0x444a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_444f:
	/* 0x444f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4451:
	/* 0x4451: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4453:
	/* 0x4453: js     5dd2 <generic_sleepable_preload+0x5dd2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4453, 0x5dd2, x86_l_5dd2);
x86_l_4459:
	/* 0x4459: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_445e:
	/* 0x445e: cmp    WORD PTR [r12+0x1a6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1812476198912ULL);
x86_l_4468:
	/* 0x4468: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_446b:
	/* 0x446b: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x446b, 0x4bff, x86_l_4bff);
x86_l_4471:
	/* 0x4471: mov    ecx,DWORD PTR [r12+0x1a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 416ULL);
x86_l_4479:
	/* 0x4479: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_447d:
	/* 0x447d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4481:
	/* 0x4481: cmp    WORD PTR [r12+0x1a4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1803886264320ULL);
x86_l_448b:
	/* 0x448b: je     44ad <generic_sleepable_preload+0x44ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x448b, 0x44ad, x86_l_44ad);
x86_l_448d:
	/* 0x448d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4490:
	/* 0x4490: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4495:
	/* 0x4495: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_449a:
	/* 0x449a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_449e:
	/* 0x449e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_44a3:
	/* 0x44a3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_44a5:
	/* 0x44a5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_44a7:
	/* 0x44a7: js     5efa <generic_sleepable_preload+0x5efa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x44a7, 0x5efa, x86_l_5efa);
x86_l_44ad:
	/* 0x44ad: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_44b2:
	/* 0x44b2: cmp    WORD PTR [r12+0x1ae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1846835937280ULL);
x86_l_44bc:
	/* 0x44bc: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_44bf:
	/* 0x44bf: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x44bf, 0x4bff, x86_l_4bff);
x86_l_44c5:
	/* 0x44c5: mov    ecx,DWORD PTR [r12+0x1a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 424ULL);
x86_l_44cd:
	/* 0x44cd: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_44d1:
	/* 0x44d1: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_44d5:
	/* 0x44d5: cmp    WORD PTR [r12+0x1ac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1838246002688ULL);
x86_l_44df:
	/* 0x44df: je     4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x44df, 0x4bff, x86_l_4bff);
x86_l_44e5:
	/* 0x44e5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_44e8:
	/* 0x44e8: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_44ed:
	/* 0x44ed: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_44f2:
	/* 0x44f2: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_44f6:
	/* 0x44f6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_44fb:
	/* 0x44fb: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_44fd:
	/* 0x44fd: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_44ff:
	/* 0x44ff: jns    4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x44ff, 0x4bff, x86_l_4bff);
x86_l_4505:
	/* 0x4505: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_450a:
	/* 0x450a: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x450a, 0x4bfc, x86_l_4bfc);
x86_l_450f:
	/* 0x450f: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_4514:
	/* 0x4514: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x4514, 0x4bfc, x86_l_4bfc);
x86_l_4519:
	/* 0x4519: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4521:
	/* 0x4521: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_4524:
	/* 0x4524: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4524, 0x4586, x86_l_4586);
x86_l_4526:
	/* 0x4526: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_452b:
	/* 0x452b: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_452e:
	/* 0x452e: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x452e, 0x4586, x86_l_4586);
x86_l_4530:
	/* 0x4530: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x4530, 0x4599, x86_l_4599);
x86_l_4532:
	/* 0x4532: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_4537:
	/* 0x4537: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_453a:
	/* 0x453a: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x453a, 0x4586, x86_l_4586);
x86_l_453c:
	/* 0x453c: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_4541:
	/* 0x4541: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_4544:
	/* 0x4544: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4544, 0x4586, x86_l_4586);
x86_l_4546:
	/* 0x4546: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x4546, 0x4599, x86_l_4599);
x86_l_4548:
	/* 0x4548: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4550:
	/* 0x4550: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_4553:
	/* 0x4553: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4553, 0x4586, x86_l_4586);
x86_l_4555:
	/* 0x4555: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_455a:
	/* 0x455a: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_455d:
	/* 0x455d: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x455d, 0x4586, x86_l_4586);
x86_l_455f:
	/* 0x455f: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x455f, 0x4599, x86_l_4599);
x86_l_4561:
	/* 0x4561: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4566:
	/* 0x4566: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_4569:
	/* 0x4569: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4569, 0x4586, x86_l_4586);
x86_l_456b:
	/* 0x456b: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4570:
	/* 0x4570: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_4573:
	/* 0x4573: je     4586 <generic_sleepable_preload+0x4586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4573, 0x4586, x86_l_4586);
x86_l_4575:
	/* 0x4575: jmp    4599 <generic_sleepable_preload+0x4599> */
	X86_SIM_X86_JMP(0x4575, 0x4599, x86_l_4599);
x86_l_4577:
	/* 0x4577: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_457c:
	/* 0x457c: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x457c, 0x4bfc, x86_l_4bfc);
x86_l_4581:
	/* 0x4581: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_4586:
	/* 0x4586: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_4589:
	/* 0x4589: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_458b:
	/* 0x458b: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_458d:
	/* 0x458d: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_4592:
	/* 0x4592: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_4594:
	/* 0x4594: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_4599:
	/* 0x4599: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_459d:
	/* 0x459d: mov    ebp,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_45a2:
	/* 0x45a2: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_45a4:
	/* 0x45a4: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_45a7:
	/* 0x45a7: cmp    WORD PTR [r12+0x166],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1537598291968ULL);
x86_l_45b1:
	/* 0x45b1: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x45b1, 0x4cc0, x86_l_4cc0);
x86_l_45b7:
	/* 0x45b7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_45be:
	/* 0x45be: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_45c1:
	/* 0x45c1: mov    eax,DWORD PTR [r12+0x160] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_45c9:
	/* 0x45c9: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_45cc:
	/* 0x45cc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45d0:
	/* 0x45d0: movzx  eax,WORD PTR [r12+0x164] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 356ULL);
x86_l_45d9:
	/* 0x45d9: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_45db:
	/* 0x45db: je     48ad <generic_sleepable_preload+0x48ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x45db, 0x48ad, x86_l_48ad);
x86_l_45e1:
	/* 0x45e1: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_45e4:
	/* 0x45e4: je     4606 <generic_sleepable_preload+0x4606> */
	X86_SIM_X86_JCC(X86_CC_E, 0x45e4, 0x4606, x86_l_4606);
x86_l_45e6:
	/* 0x45e6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_45e9:
	/* 0x45e9: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_45ee:
	/* 0x45ee: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_45f3:
	/* 0x45f3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45f7:
	/* 0x45f7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_45fc:
	/* 0x45fc: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_45fe:
	/* 0x45fe: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4600:
	/* 0x4600: js     4b9f <generic_sleepable_preload+0x4b9f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4600, 0x4b9f, x86_l_4b9f);
x86_l_4606:
	/* 0x4606: cmp    WORD PTR [r12+0x16e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1571958030336ULL);
x86_l_4610:
	/* 0x4610: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4610, 0x4cc0, x86_l_4cc0);
x86_l_4616:
	/* 0x4616: mov    ecx,DWORD PTR [r12+0x168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_461e:
	/* 0x461e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4622:
	/* 0x4622: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4626:
	/* 0x4626: cmp    WORD PTR [r12+0x16c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1563368095744ULL);
x86_l_4630:
	/* 0x4630: je     4652 <generic_sleepable_preload+0x4652> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4630, 0x4652, x86_l_4652);
x86_l_4632:
	/* 0x4632: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4635:
	/* 0x4635: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_463a:
	/* 0x463a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_463f:
	/* 0x463f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4643:
	/* 0x4643: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4648:
	/* 0x4648: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_464a:
	/* 0x464a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_464c:
	/* 0x464c: js     4ba9 <generic_sleepable_preload+0x4ba9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x464c, 0x4ba9, x86_l_4ba9);
x86_l_4652:
	/* 0x4652: cmp    WORD PTR [r12+0x176],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1606317768704ULL);
x86_l_465c:
	/* 0x465c: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x465c, 0x4cc0, x86_l_4cc0);
x86_l_4662:
	/* 0x4662: mov    ecx,DWORD PTR [r12+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_466a:
	/* 0x466a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_466e:
	/* 0x466e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4672:
	/* 0x4672: cmp    WORD PTR [r12+0x174],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1597727834112ULL);
x86_l_467c:
	/* 0x467c: je     469e <generic_sleepable_preload+0x469e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x467c, 0x469e, x86_l_469e);
x86_l_467e:
	/* 0x467e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4681:
	/* 0x4681: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4686:
	/* 0x4686: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_468b:
	/* 0x468b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_468f:
	/* 0x468f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4694:
	/* 0x4694: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4696:
	/* 0x4696: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4698:
	/* 0x4698: js     4bba <generic_sleepable_preload+0x4bba> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4698, 0x4bba, x86_l_4bba);
x86_l_469e:
	/* 0x469e: cmp    WORD PTR [r12+0x17e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1640677507072ULL);
x86_l_46a8:
	/* 0x46a8: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46a8, 0x4cc0, x86_l_4cc0);
x86_l_46ae:
	/* 0x46ae: mov    ecx,DWORD PTR [r12+0x178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_46b6:
	/* 0x46b6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_46ba:
	/* 0x46ba: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_46be:
	/* 0x46be: cmp    WORD PTR [r12+0x17c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1632087572480ULL);
x86_l_46c8:
	/* 0x46c8: je     46ea <generic_sleepable_preload+0x46ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46c8, 0x46ea, x86_l_46ea);
x86_l_46ca:
	/* 0x46ca: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_46cd:
	/* 0x46cd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_46d2:
	/* 0x46d2: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_46d7:
	/* 0x46d7: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_46db:
	/* 0x46db: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_46e0:
	/* 0x46e0: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_46e2:
	/* 0x46e2: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_46e4:
	/* 0x46e4: js     4bcb <generic_sleepable_preload+0x4bcb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x46e4, 0x4bcb, x86_l_4bcb);
x86_l_46ea:
	/* 0x46ea: cmp    WORD PTR [r12+0x186],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1675037245440ULL);
x86_l_46f4:
	/* 0x46f4: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46f4, 0x4cc0, x86_l_4cc0);
x86_l_46fa:
	/* 0x46fa: mov    ecx,DWORD PTR [r12+0x180] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_4702:
	/* 0x4702: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4706:
	/* 0x4706: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_470a:
	/* 0x470a: cmp    WORD PTR [r12+0x184],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1666447310848ULL);
x86_l_4714:
	/* 0x4714: je     4736 <generic_sleepable_preload+0x4736> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4714, 0x4736, x86_l_4736);
x86_l_4716:
	/* 0x4716: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4719:
	/* 0x4719: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_471e:
	/* 0x471e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4723:
	/* 0x4723: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4727:
	/* 0x4727: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_472c:
	/* 0x472c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_472e:
	/* 0x472e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4730:
	/* 0x4730: js     4bdc <generic_sleepable_preload+0x4bdc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4730, 0x4bdc, x86_l_4bdc);
x86_l_4736:
	/* 0x4736: cmp    WORD PTR [r12+0x18e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1709396983808ULL);
x86_l_4740:
	/* 0x4740: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4740, 0x4cc0, x86_l_4cc0);
x86_l_4746:
	/* 0x4746: mov    ecx,DWORD PTR [r12+0x188] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 392ULL);
x86_l_474e:
	/* 0x474e: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4752:
	/* 0x4752: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4756:
	/* 0x4756: cmp    WORD PTR [r12+0x18c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1700807049216ULL);
x86_l_4760:
	/* 0x4760: je     4782 <generic_sleepable_preload+0x4782> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4760, 0x4782, x86_l_4782);
x86_l_4762:
	/* 0x4762: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4765:
	/* 0x4765: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_476a:
	/* 0x476a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_476f:
	/* 0x476f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4773:
	/* 0x4773: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4778:
	/* 0x4778: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_477a:
	/* 0x477a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_477c:
	/* 0x477c: js     4bed <generic_sleepable_preload+0x4bed> */
	X86_SIM_X86_JCC(X86_CC_S, 0x477c, 0x4bed, x86_l_4bed);
x86_l_4782:
	/* 0x4782: cmp    WORD PTR [r12+0x196],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1743756722176ULL);
x86_l_478c:
	/* 0x478c: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x478c, 0x4cc0, x86_l_4cc0);
x86_l_4792:
	/* 0x4792: mov    ecx,DWORD PTR [r12+0x190] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 400ULL);
x86_l_479a:
	/* 0x479a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_479e:
	/* 0x479e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47a2:
	/* 0x47a2: cmp    WORD PTR [r12+0x194],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1735166787584ULL);
x86_l_47ac:
	/* 0x47ac: je     47ce <generic_sleepable_preload+0x47ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47ac, 0x47ce, x86_l_47ce);
x86_l_47ae:
	/* 0x47ae: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_47b1:
	/* 0x47b1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_47b6:
	/* 0x47b6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_47bb:
	/* 0x47bb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47bf:
	/* 0x47bf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_47c4:
	/* 0x47c4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_47c6:
	/* 0x47c6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_47c8:
	/* 0x47c8: js     4cb8 <generic_sleepable_preload+0x4cb8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x47c8, 0x4cb8, x86_l_4cb8);
x86_l_47ce:
	/* 0x47ce: cmp    WORD PTR [r12+0x19e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1778116460544ULL);
x86_l_47d8:
	/* 0x47d8: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47d8, 0x4cc0, x86_l_4cc0);
x86_l_47de:
	/* 0x47de: mov    ecx,DWORD PTR [r12+0x198] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 408ULL);
x86_l_47e6:
	/* 0x47e6: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_47ea:
	/* 0x47ea: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47ee:
	/* 0x47ee: cmp    WORD PTR [r12+0x19c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1769526525952ULL);
x86_l_47f8:
	/* 0x47f8: je     481a <generic_sleepable_preload+0x481a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47f8, 0x481a, x86_l_481a);
x86_l_47fa:
	/* 0x47fa: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_47fd:
	/* 0x47fd: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4802:
	/* 0x4802: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4807:
	/* 0x4807: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_480b:
	/* 0x480b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4810:
	/* 0x4810: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4812:
	/* 0x4812: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4814:
	/* 0x4814: js     5d61 <generic_sleepable_preload+0x5d61> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4814, 0x5d61, x86_l_5d61);
x86_l_481a:
	/* 0x481a: cmp    WORD PTR [r12+0x1a6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1812476198912ULL);
x86_l_4824:
	/* 0x4824: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4824, 0x4cc0, x86_l_4cc0);
x86_l_482a:
	/* 0x482a: mov    ecx,DWORD PTR [r12+0x1a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 416ULL);
x86_l_4832:
	/* 0x4832: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4836:
	/* 0x4836: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_483a:
	/* 0x483a: cmp    WORD PTR [r12+0x1a4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1803886264320ULL);
x86_l_4844:
	/* 0x4844: je     4866 <generic_sleepable_preload+0x4866> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4844, 0x4866, x86_l_4866);
x86_l_4846:
	/* 0x4846: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4849:
	/* 0x4849: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_484e:
	/* 0x484e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4853:
	/* 0x4853: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4857:
	/* 0x4857: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_485c:
	/* 0x485c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_485e:
	/* 0x485e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4860:
	/* 0x4860: js     5e6a <generic_sleepable_preload+0x5e6a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4860, 0x5e6a, x86_l_5e6a);
x86_l_4866:
	/* 0x4866: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_486b:
	/* 0x486b: cmp    WORD PTR [r12+0x1ae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1846835937280ULL);
x86_l_4875:
	/* 0x4875: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4875, 0x4cc0, x86_l_4cc0);
x86_l_487b:
	/* 0x487b: mov    ecx,DWORD PTR [r12+0x1a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 424ULL);
x86_l_4883:
	/* 0x4883: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4887:
	/* 0x4887: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_488b:
	/* 0x488b: cmp    WORD PTR [r12+0x1ac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1838246002688ULL);
x86_l_4895:
	/* 0x4895: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4895, 0x4cc0, x86_l_4cc0);
x86_l_489b:
	/* 0x489b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_489e:
	/* 0x489e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_48a3:
	/* 0x48a3: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_48a8:
	/* 0x48a8: jmp    4b82 <generic_sleepable_preload+0x4b82> */
	X86_SIM_X86_JMP(0x48a8, 0x4b82, x86_l_4b82);
x86_l_48ad:
	/* 0x48ad: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_48b0:
	/* 0x48b0: je     48d2 <generic_sleepable_preload+0x48d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48b0, 0x48d2, x86_l_48d2);
x86_l_48b2:
	/* 0x48b2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_48b5:
	/* 0x48b5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_48ba:
	/* 0x48ba: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_48bf:
	/* 0x48bf: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48c3:
	/* 0x48c3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_48c8:
	/* 0x48c8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_48ca:
	/* 0x48ca: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_48cc:
	/* 0x48cc: js     4b9f <generic_sleepable_preload+0x4b9f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x48cc, 0x4b9f, x86_l_4b9f);
x86_l_48d2:
	/* 0x48d2: cmp    WORD PTR [r12+0x16e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1571958030336ULL);
x86_l_48dc:
	/* 0x48dc: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48dc, 0x4cc0, x86_l_4cc0);
x86_l_48e2:
	/* 0x48e2: mov    ecx,DWORD PTR [r12+0x168] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_48ea:
	/* 0x48ea: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_48ee:
	/* 0x48ee: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48f2:
	/* 0x48f2: cmp    WORD PTR [r12+0x16c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1563368095744ULL);
x86_l_48fc:
	/* 0x48fc: je     491e <generic_sleepable_preload+0x491e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48fc, 0x491e, x86_l_491e);
x86_l_48fe:
	/* 0x48fe: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4901:
	/* 0x4901: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4906:
	/* 0x4906: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_490b:
	/* 0x490b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_490f:
	/* 0x490f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4914:
	/* 0x4914: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4916:
	/* 0x4916: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4918:
	/* 0x4918: js     4ba9 <generic_sleepable_preload+0x4ba9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4918, 0x4ba9, x86_l_4ba9);
x86_l_491e:
	/* 0x491e: cmp    WORD PTR [r12+0x176],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1606317768704ULL);
x86_l_4928:
	/* 0x4928: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4928, 0x4cc0, x86_l_4cc0);
x86_l_492e:
	/* 0x492e: mov    ecx,DWORD PTR [r12+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_4936:
	/* 0x4936: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_493a:
	/* 0x493a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_493e:
	/* 0x493e: cmp    WORD PTR [r12+0x174],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1597727834112ULL);
x86_l_4948:
	/* 0x4948: je     496a <generic_sleepable_preload+0x496a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4948, 0x496a, x86_l_496a);
x86_l_494a:
	/* 0x494a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_494d:
	/* 0x494d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4952:
	/* 0x4952: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4957:
	/* 0x4957: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_495b:
	/* 0x495b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4960:
	/* 0x4960: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4962:
	/* 0x4962: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4964:
	/* 0x4964: js     4bba <generic_sleepable_preload+0x4bba> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4964, 0x4bba, x86_l_4bba);
x86_l_496a:
	/* 0x496a: cmp    WORD PTR [r12+0x17e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1640677507072ULL);
x86_l_4974:
	/* 0x4974: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4974, 0x4cc0, x86_l_4cc0);
x86_l_497a:
	/* 0x497a: mov    ecx,DWORD PTR [r12+0x178] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_4982:
	/* 0x4982: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4986:
	/* 0x4986: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_498a:
	/* 0x498a: cmp    WORD PTR [r12+0x17c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1632087572480ULL);
x86_l_4994:
	/* 0x4994: je     49b6 <generic_sleepable_preload+0x49b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4994, 0x49b6, x86_l_49b6);
x86_l_4996:
	/* 0x4996: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4999:
	/* 0x4999: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_499e:
	/* 0x499e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_49a3:
	/* 0x49a3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49a7:
	/* 0x49a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_49ac:
	/* 0x49ac: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_49ae:
	/* 0x49ae: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_49b0:
	/* 0x49b0: js     4bcb <generic_sleepable_preload+0x4bcb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x49b0, 0x4bcb, x86_l_4bcb);
x86_l_49b6:
	/* 0x49b6: cmp    WORD PTR [r12+0x186],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1675037245440ULL);
x86_l_49c0:
	/* 0x49c0: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49c0, 0x4cc0, x86_l_4cc0);
x86_l_49c6:
	/* 0x49c6: mov    ecx,DWORD PTR [r12+0x180] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_49ce:
	/* 0x49ce: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_49d2:
	/* 0x49d2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49d6:
	/* 0x49d6: cmp    WORD PTR [r12+0x184],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1666447310848ULL);
x86_l_49e0:
	/* 0x49e0: je     4a02 <generic_sleepable_preload+0x4a02> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49e0, 0x4a02, x86_l_4a02);
x86_l_49e2:
	/* 0x49e2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_49e5:
	/* 0x49e5: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_49ea:
	/* 0x49ea: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_49ef:
	/* 0x49ef: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49f3:
	/* 0x49f3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_49f8:
	/* 0x49f8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_49fa:
	/* 0x49fa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_49fc:
	/* 0x49fc: js     4bdc <generic_sleepable_preload+0x4bdc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x49fc, 0x4bdc, x86_l_4bdc);
x86_l_4a02:
	/* 0x4a02: cmp    WORD PTR [r12+0x18e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1709396983808ULL);
x86_l_4a0c:
	/* 0x4a0c: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a0c, 0x4cc0, x86_l_4cc0);
x86_l_4a12:
	/* 0x4a12: mov    ecx,DWORD PTR [r12+0x188] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 392ULL);
x86_l_4a1a:
	/* 0x4a1a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4a1e:
	/* 0x4a1e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a22:
	/* 0x4a22: cmp    WORD PTR [r12+0x18c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1700807049216ULL);
x86_l_4a2c:
	/* 0x4a2c: je     4a4e <generic_sleepable_preload+0x4a4e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a2c, 0x4a4e, x86_l_4a4e);
x86_l_4a2e:
	/* 0x4a2e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4a31:
	/* 0x4a31: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4a36:
	/* 0x4a36: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4a3b:
	/* 0x4a3b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a3f:
	/* 0x4a3f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4a44:
	/* 0x4a44: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4a46:
	/* 0x4a46: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4a48:
	/* 0x4a48: js     4bed <generic_sleepable_preload+0x4bed> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4a48, 0x4bed, x86_l_4bed);
x86_l_4a4e:
	/* 0x4a4e: cmp    WORD PTR [r12+0x196],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1743756722176ULL);
x86_l_4a58:
	/* 0x4a58: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a58, 0x4cc0, x86_l_4cc0);
x86_l_4a5e:
	/* 0x4a5e: mov    ecx,DWORD PTR [r12+0x190] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 400ULL);
x86_l_4a66:
	/* 0x4a66: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4a6a:
	/* 0x4a6a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a6e:
	/* 0x4a6e: cmp    WORD PTR [r12+0x194],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1735166787584ULL);
x86_l_4a78:
	/* 0x4a78: je     4a9a <generic_sleepable_preload+0x4a9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a78, 0x4a9a, x86_l_4a9a);
x86_l_4a7a:
	/* 0x4a7a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4a7d:
	/* 0x4a7d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4a82:
	/* 0x4a82: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4a87:
	/* 0x4a87: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a8b:
	/* 0x4a8b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4a90:
	/* 0x4a90: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4a92:
	/* 0x4a92: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4a94:
	/* 0x4a94: js     4cb8 <generic_sleepable_preload+0x4cb8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4a94, 0x4cb8, x86_l_4cb8);
x86_l_4a9a:
	/* 0x4a9a: cmp    WORD PTR [r12+0x19e],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1778116460544ULL);
x86_l_4aa4:
	/* 0x4aa4: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4aa4, 0x4cc0, x86_l_4cc0);
x86_l_4aaa:
	/* 0x4aaa: mov    r15,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R14, X86_WIDTH_64);
x86_l_4aad:
	/* 0x4aad: mov    ecx,DWORD PTR [r12+0x198] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 408ULL);
x86_l_4ab5:
	/* 0x4ab5: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4ab9:
	/* 0x4ab9: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4abd:
	/* 0x4abd: cmp    WORD PTR [r12+0x19c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1769526525952ULL);
x86_l_4ac7:
	/* 0x4ac7: je     4ae9 <generic_sleepable_preload+0x4ae9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ac7, 0x4ae9, x86_l_4ae9);
x86_l_4ac9:
	/* 0x4ac9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4acc:
	/* 0x4acc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4ad1:
	/* 0x4ad1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4ad6:
	/* 0x4ad6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ada:
	/* 0x4ada: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4adf:
	/* 0x4adf: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4ae1:
	/* 0x4ae1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4ae3:
	/* 0x4ae3: js     5ddf <generic_sleepable_preload+0x5ddf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4ae3, 0x5ddf, x86_l_5ddf);
x86_l_4ae9:
	/* 0x4ae9: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4aee:
	/* 0x4aee: cmp    WORD PTR [r12+0x1a6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1812476198912ULL);
x86_l_4af8:
	/* 0x4af8: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_4afb:
	/* 0x4afb: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4afb, 0x4cc0, x86_l_4cc0);
x86_l_4b01:
	/* 0x4b01: mov    ecx,DWORD PTR [r12+0x1a0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 416ULL);
x86_l_4b09:
	/* 0x4b09: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4b0d:
	/* 0x4b0d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b11:
	/* 0x4b11: cmp    WORD PTR [r12+0x1a4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1803886264320ULL);
x86_l_4b1b:
	/* 0x4b1b: je     4b3d <generic_sleepable_preload+0x4b3d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b1b, 0x4b3d, x86_l_4b3d);
x86_l_4b1d:
	/* 0x4b1d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4b20:
	/* 0x4b20: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4b25:
	/* 0x4b25: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4b2a:
	/* 0x4b2a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b2e:
	/* 0x4b2e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4b33:
	/* 0x4b33: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4b35:
	/* 0x4b35: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4b37:
	/* 0x4b37: js     5f0f <generic_sleepable_preload+0x5f0f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4b37, 0x5f0f, x86_l_5f0f);
x86_l_4b3d:
	/* 0x4b3d: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b42:
	/* 0x4b42: cmp    WORD PTR [r12+0x1ae],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1846835937280ULL);
x86_l_4b4c:
	/* 0x4b4c: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_4b4f:
	/* 0x4b4f: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b4f, 0x4cc0, x86_l_4cc0);
x86_l_4b55:
	/* 0x4b55: mov    ecx,DWORD PTR [r12+0x1a8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 424ULL);
x86_l_4b5d:
	/* 0x4b5d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4b61:
	/* 0x4b61: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b65:
	/* 0x4b65: cmp    WORD PTR [r12+0x1ac],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1838246002688ULL);
x86_l_4b6f:
	/* 0x4b6f: je     4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b6f, 0x4cc0, x86_l_4cc0);
x86_l_4b75:
	/* 0x4b75: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4b78:
	/* 0x4b78: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4b7d:
	/* 0x4b7d: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4b82:
	/* 0x4b82: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b86:
	/* 0x4b86: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4b8b:
	/* 0x4b8b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4b8d:
	/* 0x4b8d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4b8f:
	/* 0x4b8f: jns    4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4b8f, 0x4cc0, x86_l_4cc0);
x86_l_4b95:
	/* 0x4b95: mov    ebx,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 10ULL);
x86_l_4b9a:
	/* 0x4b9a: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4b9a, 0x4cbd, x86_l_4cbd);
x86_l_4b9f:
	/* 0x4b9f: mov    ebx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_4ba4:
	/* 0x4ba4: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4ba4, 0x4cbd, x86_l_4cbd);
x86_l_4ba9:
	/* 0x4ba9: mov    ebx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2ULL);
x86_l_4bae:
	/* 0x4bae: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4bae, 0x4cbd, x86_l_4cbd);
x86_l_4bb3:
	/* 0x4bb3: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_4bb8:
	/* 0x4bb8: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x4bb8, 0x4bfc, x86_l_4bfc);
x86_l_4bba:
	/* 0x4bba: mov    ebx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 3ULL);
x86_l_4bbf:
	/* 0x4bbf: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4bbf, 0x4cbd, x86_l_4cbd);
x86_l_4bc4:
	/* 0x4bc4: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_4bc9:
	/* 0x4bc9: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x4bc9, 0x4bfc, x86_l_4bfc);
x86_l_4bcb:
	/* 0x4bcb: mov    ebx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4ULL);
x86_l_4bd0:
	/* 0x4bd0: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4bd0, 0x4cbd, x86_l_4cbd);
x86_l_4bd5:
	/* 0x4bd5: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_4bda:
	/* 0x4bda: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x4bda, 0x4bfc, x86_l_4bfc);
x86_l_4bdc:
	/* 0x4bdc: mov    ebx,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 5ULL);
x86_l_4be1:
	/* 0x4be1: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4be1, 0x4cbd, x86_l_4cbd);
x86_l_4be6:
	/* 0x4be6: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_4beb:
	/* 0x4beb: jmp    4bfc <generic_sleepable_preload+0x4bfc> */
	X86_SIM_X86_JMP(0x4beb, 0x4bfc, x86_l_4bfc);
x86_l_4bed:
	/* 0x4bed: mov    ebx,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_4bf2:
	/* 0x4bf2: jmp    4cbd <generic_sleepable_preload+0x4cbd> */
	X86_SIM_X86_JMP(0x4bf2, 0x4cbd, x86_l_4cbd);
x86_l_4bf7:
	/* 0x4bf7: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_4bfc:
	/* 0x4bfc: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4bff:
	/* 0x4bff: mov    ebp,DWORD PTR [r12+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c04:
	/* 0x4c04: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4c07:
	/* 0x4c07: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_4c0c:
	/* 0x4c0c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_4c11:
	/* 0x4c11: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4c16:
	/* 0x4c16: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_4c19:
	/* 0x4c19: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4c1b:
	/* 0x4c1b: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_4c1e:
	/* 0x4c1e: jne    4d6c <generic_sleepable_preload+0x4d6c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4c1e, 0x4d6c, x86_l_4d6c);
x86_l_4c24:
	/* 0x4c24: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_4c27:
	/* 0x4c27: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c2b:
	/* 0x4c2b: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_4c30:
	/* 0x4c30: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4c32:
	/* 0x4c32: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c37:
	/* 0x4c37: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_4c3f:
	/* 0x4c3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_4c46:
	/* 0x4c46: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_4c4b:
	/* 0x4c4b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4c50:
	/* 0x4c50: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4c52:
	/* 0x4c52: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4c55:
	/* 0x4c55: je     4d69 <generic_sleepable_preload+0x4d69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c55, 0x4d69, x86_l_4d69);
x86_l_4c5b:
	/* 0x4c5b: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_4c5e:
	/* 0x4c5e: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_4c65:
	/* 0x4c65: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4c67:
	/* 0x4c67: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c6c:
	/* 0x4c6c: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_4c71:
	/* 0x4c71: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_4c74:
	/* 0x4c74: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_4c77:
	/* 0x4c77: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4c79:
	/* 0x4c79: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4c7b:
	/* 0x4c7b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4c80:
	/* 0x4c80: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_4c83:
	/* 0x4c83: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_4c86:
	/* 0x4c86: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4c8b:
	/* 0x4c8b: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4c8d:
	/* 0x4c8d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4c90:
	/* 0x4c90: je     4d69 <generic_sleepable_preload+0x4d69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c90, 0x4d69, x86_l_4d69);
x86_l_4c96:
	/* 0x4c96: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_4c99:
	/* 0x4c99: je     4d67 <generic_sleepable_preload+0x4d67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c99, 0x4d67, x86_l_4d67);
x86_l_4c9f:
	/* 0x4c9f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4ca2:
	/* 0x4ca2: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4ca6:
	/* 0x4ca6: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_4cab:
	/* 0x4cab: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_4cae:
	/* 0x4cae: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_4cb3:
	/* 0x4cb3: jmp    4d4c <generic_sleepable_preload+0x4d4c> */
	X86_SIM_X86_JMP(0x4cb3, 0x4d4c, x86_l_4d4c);
x86_l_4cb8:
	/* 0x4cb8: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_4cbd:
	/* 0x4cbd: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4cc0:
	/* 0x4cc0: cmp    ebp,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBP, X86_WIDTH_32, 6ULL);
x86_l_4cc3:
	/* 0x4cc3: jne    4d6c <generic_sleepable_preload+0x4d6c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4cc3, 0x4d6c, x86_l_4d6c);
x86_l_4cc9:
	/* 0x4cc9: mov    rbp,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R14, X86_WIDTH_64);
x86_l_4ccc:
	/* 0x4ccc: mov    r14,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4cd0:
	/* 0x4cd0: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_4cd5:
	/* 0x4cd5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4cd7:
	/* 0x4cd7: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4cdc:
	/* 0x4cdc: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_4ce4:
	/* 0x4ce4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_4ceb:
	/* 0x4ceb: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_4cf0:
	/* 0x4cf0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4cf5:
	/* 0x4cf5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4cf7:
	/* 0x4cf7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4cfa:
	/* 0x4cfa: je     4d69 <generic_sleepable_preload+0x4d69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4cfa, 0x4d69, x86_l_4d69);
x86_l_4cfc:
	/* 0x4cfc: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_4cff:
	/* 0x4cff: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_4d06:
	/* 0x4d06: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4d08:
	/* 0x4d08: lea    r12,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d0d:
	/* 0x4d0d: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_4d12:
	/* 0x4d12: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_4d15:
	/* 0x4d15: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_4d18:
	/* 0x4d18: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4d1a:
	/* 0x4d1a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4d1c:
	/* 0x4d1c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4d21:
	/* 0x4d21: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_4d24:
	/* 0x4d24: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_4d27:
	/* 0x4d27: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4d2c:
	/* 0x4d2c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4d2e:
	/* 0x4d2e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_4d31:
	/* 0x4d31: je     4d69 <generic_sleepable_preload+0x4d69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d31, 0x4d69, x86_l_4d69);
x86_l_4d33:
	/* 0x4d33: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_4d36:
	/* 0x4d36: je     4d67 <generic_sleepable_preload+0x4d67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d36, 0x4d67, x86_l_4d67);
x86_l_4d38:
	/* 0x4d38: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_4d3b:
	/* 0x4d3b: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4d3f:
	/* 0x4d3f: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_4d44:
	/* 0x4d44: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_4d47:
	/* 0x4d47: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_4d4c:
	/* 0x4d4c: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_4d51:
	/* 0x4d51: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
x86_l_4d54:
	/* 0x4d54: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4d56:
	/* 0x4d56: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_4d59:
	/* 0x4d59: mov    rax,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_64);
x86_l_4d5c:
	/* 0x4d5c: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_4d5f:
	/* 0x4d5f: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_4d64:
	/* 0x4d64: cmovs  ebx,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_4d67:
	/* 0x4d67: mov    DWORD PTR [rax],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4d69:
	/* 0x4d69: mov    r14,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBP, X86_WIDTH_64);
x86_l_4d6c:
	/* 0x4d6c: mov    eax,DWORD PTR [r12+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4d71:
	/* 0x4d71: test   eax,0x100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_4d76:
	/* 0x4d76: jne    4d90 <generic_sleepable_preload+0x4d90> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4d76, 0x4d90, x86_l_4d90);
x86_l_4d78:
	/* 0x4d78: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4d7a:
	/* 0x4d7a: add    rsp,0xb8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_4d81:
	/* 0x4d81: pop    rbx */
	X86_SIM_L_EXEC_POP(X86_RBX, X86_WIDTH_64);
x86_l_4d82:
	/* 0x4d82: pop    r12 */
	X86_SIM_L_EXEC_POP(X86_R12, X86_WIDTH_64);
x86_l_4d84:
	/* 0x4d84: pop    r13 */
	X86_SIM_L_EXEC_POP(X86_R13, X86_WIDTH_64);
x86_l_4d86:
	/* 0x4d86: pop    r14 */
	X86_SIM_L_EXEC_POP(X86_R14, X86_WIDTH_64);
x86_l_4d88:
	/* 0x4d88: pop    r15 */
	X86_SIM_L_EXEC_POP(X86_R15, X86_WIDTH_64);
x86_l_4d8a:
	/* 0x4d8a: pop    rbp */
	X86_SIM_L_EXEC_POP(X86_RBP, X86_WIDTH_64);
x86_l_4d8b:
	/* 0x4d8b: jmp    5f24 <generic_sleepable_preload+0x5f24> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_4d90:
	/* 0x4d90: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
x86_l_4d92:
	/* 0x4d92: js     4dc7 <generic_sleepable_preload+0x4dc7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4d92, 0x4dc7, x86_l_4dc7);
x86_l_4d94:
	/* 0x4d94: mov    eax,DWORD PTR [r12+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4d99:
	/* 0x4d99: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4d9c:
	/* 0x4d9c: jle    4e4a <generic_sleepable_preload+0x4e4a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4d9c, 0x4e4a, x86_l_4e4a);
x86_l_4da2:
	/* 0x4da2: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_4da5:
	/* 0x4da5: je     4eb4 <generic_sleepable_preload+0x4eb4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4da5, 0x4eb4, x86_l_4eb4);
x86_l_4dab:
	/* 0x4dab: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_4dae:
	/* 0x4dae: je     4ebb <generic_sleepable_preload+0x4ebb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dae, 0x4ebb, x86_l_4ebb);
x86_l_4db4:
	/* 0x4db4: cmp    eax,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_4db7:
	/* 0x4db7: jne    4ece <generic_sleepable_preload+0x4ece> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4db7, 0x4ece, x86_l_4ece);
x86_l_4dbd:
	/* 0x4dbd: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4dc2:
	/* 0x4dc2: jmp    4ec7 <generic_sleepable_preload+0x4ec7> */
	X86_SIM_X86_JMP(0x4dc2, 0x4ec7, x86_l_4ec7);
x86_l_4dc7:
	/* 0x4dc7: movzx  eax,BYTE PTR [r12+0x2d2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 722ULL);
x86_l_4dd0:
	/* 0x4dd0: movzx  ecx,WORD PTR [r12+0x2d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 720ULL);
x86_l_4dd9:
	/* 0x4dd9: rorx   edx,ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 3ULL);
x86_l_4ddf:
	/* 0x4ddf: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4de1:
	/* 0x4de1: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_4de4:
	/* 0x4de4: jle    4e23 <generic_sleepable_preload+0x4e23> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4de4, 0x4e23, x86_l_4e23);
x86_l_4de6:
	/* 0x4de6: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_4de9:
	/* 0x4de9: jle    4e5a <generic_sleepable_preload+0x4e5a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4de9, 0x4e5a, x86_l_4e5a);
x86_l_4deb:
	/* 0x4deb: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_4dee:
	/* 0x4dee: jle    54f5 <generic_sleepable_preload+0x54f5> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4dee, 0x54f5, x86_l_54f5);
x86_l_4df4:
	/* 0x4df4: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4df9:
	/* 0x4df9: cmp    edx,0xe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 14ULL);
x86_l_4dfc:
	/* 0x4dfc: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dfc, 0x551b, x86_l_551b);
x86_l_4e02:
	/* 0x4e02: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4e07:
	/* 0x4e07: cmp    edx,0x13 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 19ULL);
x86_l_4e0a:
	/* 0x4e0a: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e0a, 0x551b, x86_l_551b);
x86_l_4e10:
	/* 0x4e10: mov    rsi,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4e15:
	/* 0x4e15: cmp    edx,0x10 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 16ULL);
x86_l_4e18:
	/* 0x4e18: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e18, 0x551b, x86_l_551b);
x86_l_4e1e:
	/* 0x4e1e: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x4e1e, 0x552e, x86_l_552e);
x86_l_4e23:
	/* 0x4e23: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_4e26:
	/* 0x4e26: jg     4e87 <generic_sleepable_preload+0x4e87> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4e26, 0x4e87, x86_l_4e87);
x86_l_4e28:
	/* 0x4e28: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_4e2b:
	/* 0x4e2b: jg     54c6 <generic_sleepable_preload+0x54c6> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4e2b, 0x54c6, x86_l_54c6);
x86_l_4e31:
	/* 0x4e31: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_4e33:
	/* 0x4e33: je     5516 <generic_sleepable_preload+0x5516> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e33, 0x5516, x86_l_5516);
x86_l_4e39:
	/* 0x4e39: cmp    edx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_4e3c:
	/* 0x4e3c: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
x86_l_4e3f:
	/* 0x4e3f: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e3f, 0x551b, x86_l_551b);
x86_l_4e45:
	/* 0x4e45: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x4e45, 0x552e, x86_l_552e);
x86_l_4e4a:
	/* 0x4e4a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4e4c:
	/* 0x4e4c: je     4ec2 <generic_sleepable_preload+0x4ec2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e4c, 0x4ec2, x86_l_4ec2);
x86_l_4e4e:
	/* 0x4e4e: cmp    eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_4e51:
	/* 0x4e51: jne    4ece <generic_sleepable_preload+0x4ece> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4e51, 0x4ece, x86_l_4ece);
x86_l_4e53:
	/* 0x4e53: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4e58:
	/* 0x4e58: jmp    4ec7 <generic_sleepable_preload+0x4ec7> */
	X86_SIM_X86_JMP(0x4e58, 0x4ec7, x86_l_4ec7);
x86_l_4e5a:
	/* 0x4e5a: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_4e5d:
	/* 0x4e5d: jg     54ad <generic_sleepable_preload+0x54ad> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4e5d, 0x54ad, x86_l_54ad);
x86_l_4e63:
	/* 0x4e63: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4e6b:
	/* 0x4e6b: cmp    edx,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4e6e:
	/* 0x4e6e: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e6e, 0x551b, x86_l_551b);
x86_l_4e74:
	/* 0x4e74: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4e79:
	/* 0x4e79: cmp    edx,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 9ULL);
x86_l_4e7c:
	/* 0x4e7c: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e7c, 0x551b, x86_l_551b);
x86_l_4e82:
	/* 0x4e82: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x4e82, 0x552e, x86_l_552e);
x86_l_4e87:
	/* 0x4e87: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_4e8a:
	/* 0x4e8a: jg     54dc <generic_sleepable_preload+0x54dc> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4e8a, 0x54dc, x86_l_54dc);
x86_l_4e90:
	/* 0x4e90: mov    rsi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_4e98:
	/* 0x4e98: cmp    edx,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 4ULL);
x86_l_4e9b:
	/* 0x4e9b: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e9b, 0x551b, x86_l_551b);
x86_l_4ea1:
	/* 0x4ea1: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4ea6:
	/* 0x4ea6: cmp    edx,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 5ULL);
x86_l_4ea9:
	/* 0x4ea9: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ea9, 0x551b, x86_l_551b);
x86_l_4eaf:
	/* 0x4eaf: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x4eaf, 0x552e, x86_l_552e);
x86_l_4eb4:
	/* 0x4eb4: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4eb9:
	/* 0x4eb9: jmp    4ec7 <generic_sleepable_preload+0x4ec7> */
	X86_SIM_X86_JMP(0x4eb9, 0x4ec7, x86_l_4ec7);
x86_l_4ebb:
	/* 0x4ebb: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4ec0:
	/* 0x4ec0: jmp    4ec7 <generic_sleepable_preload+0x4ec7> */
	X86_SIM_X86_JMP(0x4ec0, 0x4ec7, x86_l_4ec7);
x86_l_4ec2:
	/* 0x4ec2: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4ec7:
	/* 0x4ec7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4eca:
	/* 0x4eca: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ece:
	/* 0x4ece: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_4ed1:
	/* 0x4ed1: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_4ed4:
	/* 0x4ed4: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4ed9:
	/* 0x4ed9: cmp    WORD PTR [rsi+0x1b6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1881195675648ULL);
x86_l_4ee1:
	/* 0x4ee1: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ee1, 0x5b74, x86_l_5b74);
x86_l_4ee7:
	/* 0x4ee7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_4eee:
	/* 0x4eee: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4ef1:
	/* 0x4ef1: mov    eax,DWORD PTR [rsi+0x1b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 432ULL);
x86_l_4ef7:
	/* 0x4ef7: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4efa:
	/* 0x4efa: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4efe:
	/* 0x4efe: movzx  eax,WORD PTR [rsi+0x1b4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 436ULL);
x86_l_4f05:
	/* 0x4f05: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_4f07:
	/* 0x4f07: je     51cb <generic_sleepable_preload+0x51cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f07, 0x51cb, x86_l_51cb);
x86_l_4f0d:
	/* 0x4f0d: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_4f10:
	/* 0x4f10: je     4f32 <generic_sleepable_preload+0x4f32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f10, 0x4f32, x86_l_4f32);
x86_l_4f12:
	/* 0x4f12: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4f15:
	/* 0x4f15: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4f1a:
	/* 0x4f1a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4f1f:
	/* 0x4f1f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f23:
	/* 0x4f23: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4f28:
	/* 0x4f28: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4f2a:
	/* 0x4f2a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4f2c:
	/* 0x4f2c: js     54a2 <generic_sleepable_preload+0x54a2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4f2c, 0x54a2, x86_l_54a2);
x86_l_4f32:
	/* 0x4f32: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4f37:
	/* 0x4f37: cmp    WORD PTR [rax+0x1be],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1915555414016ULL);
x86_l_4f3f:
	/* 0x4f3f: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f3f, 0x5b74, x86_l_5b74);
x86_l_4f45:
	/* 0x4f45: mov    ecx,DWORD PTR [rax+0x1b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 440ULL);
x86_l_4f4b:
	/* 0x4f4b: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4f4f:
	/* 0x4f4f: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f53:
	/* 0x4f53: cmp    WORD PTR [rax+0x1bc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1906965479424ULL);
x86_l_4f5b:
	/* 0x4f5b: je     4f7d <generic_sleepable_preload+0x4f7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f5b, 0x4f7d, x86_l_4f7d);
x86_l_4f5d:
	/* 0x4f5d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4f60:
	/* 0x4f60: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4f65:
	/* 0x4f65: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4f6a:
	/* 0x4f6a: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f6e:
	/* 0x4f6e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4f73:
	/* 0x4f73: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4f75:
	/* 0x4f75: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4f77:
	/* 0x4f77: js     550b <generic_sleepable_preload+0x550b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4f77, 0x550b, x86_l_550b);
x86_l_4f7d:
	/* 0x4f7d: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4f82:
	/* 0x4f82: cmp    WORD PTR [rax+0x1c6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1949915152384ULL);
x86_l_4f8a:
	/* 0x4f8a: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f8a, 0x5b74, x86_l_5b74);
x86_l_4f90:
	/* 0x4f90: mov    ecx,DWORD PTR [rax+0x1c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 448ULL);
x86_l_4f96:
	/* 0x4f96: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4f9a:
	/* 0x4f9a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f9e:
	/* 0x4f9e: cmp    WORD PTR [rax+0x1c4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1941325217792ULL);
x86_l_4fa6:
	/* 0x4fa6: je     4fc8 <generic_sleepable_preload+0x4fc8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4fa6, 0x4fc8, x86_l_4fc8);
x86_l_4fa8:
	/* 0x4fa8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4fab:
	/* 0x4fab: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4fb0:
	/* 0x4fb0: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_4fb5:
	/* 0x4fb5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fb9:
	/* 0x4fb9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4fbe:
	/* 0x4fbe: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_4fc0:
	/* 0x4fc0: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_4fc2:
	/* 0x4fc2: js     5b1f <generic_sleepable_preload+0x5b1f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4fc2, 0x5b1f, x86_l_5b1f);
x86_l_4fc8:
	/* 0x4fc8: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4fcd:
	/* 0x4fcd: cmp    WORD PTR [rax+0x1ce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1984274890752ULL);
x86_l_4fd5:
	/* 0x4fd5: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4fd5, 0x5b74, x86_l_5b74);
x86_l_4fdb:
	/* 0x4fdb: mov    ecx,DWORD PTR [rax+0x1c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 456ULL);
x86_l_4fe1:
	/* 0x4fe1: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_4fe5:
	/* 0x4fe5: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fe9:
	/* 0x4fe9: cmp    WORD PTR [rax+0x1cc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1975684956160ULL);
x86_l_4ff1:
	/* 0x4ff1: je     5013 <generic_sleepable_preload+0x5013> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ff1, 0x5013, x86_l_5013);
x86_l_4ff3:
	/* 0x4ff3: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4ff6:
	/* 0x4ff6: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_4ffb:
	/* 0x4ffb: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5000:
	/* 0x5000: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5004:
	/* 0x5004: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5009:
	/* 0x5009: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_500b:
	/* 0x500b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_500d:
	/* 0x500d: js     5b32 <generic_sleepable_preload+0x5b32> */
	X86_SIM_X86_JCC(X86_CC_S, 0x500d, 0x5b32, x86_l_5b32);
x86_l_5013:
	/* 0x5013: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5018:
	/* 0x5018: cmp    WORD PTR [rax+0x1d6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2018634629120ULL);
x86_l_5020:
	/* 0x5020: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5020, 0x5b74, x86_l_5b74);
x86_l_5026:
	/* 0x5026: mov    ecx,DWORD PTR [rax+0x1d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 464ULL);
x86_l_502c:
	/* 0x502c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5030:
	/* 0x5030: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5034:
	/* 0x5034: cmp    WORD PTR [rax+0x1d4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2010044694528ULL);
x86_l_503c:
	/* 0x503c: je     505e <generic_sleepable_preload+0x505e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x503c, 0x505e, x86_l_505e);
x86_l_503e:
	/* 0x503e: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5041:
	/* 0x5041: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5046:
	/* 0x5046: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_504b:
	/* 0x504b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_504f:
	/* 0x504f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5054:
	/* 0x5054: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5056:
	/* 0x5056: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5058:
	/* 0x5058: js     5b45 <generic_sleepable_preload+0x5b45> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5058, 0x5b45, x86_l_5b45);
x86_l_505e:
	/* 0x505e: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5063:
	/* 0x5063: cmp    WORD PTR [rax+0x1de],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2052994367488ULL);
x86_l_506b:
	/* 0x506b: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x506b, 0x5b74, x86_l_5b74);
x86_l_5071:
	/* 0x5071: mov    ecx,DWORD PTR [rax+0x1d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 472ULL);
x86_l_5077:
	/* 0x5077: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_507b:
	/* 0x507b: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_507f:
	/* 0x507f: cmp    WORD PTR [rax+0x1dc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2044404432896ULL);
x86_l_5087:
	/* 0x5087: je     50a9 <generic_sleepable_preload+0x50a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5087, 0x50a9, x86_l_50a9);
x86_l_5089:
	/* 0x5089: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_508c:
	/* 0x508c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5091:
	/* 0x5091: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5096:
	/* 0x5096: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_509a:
	/* 0x509a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_509f:
	/* 0x509f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_50a1:
	/* 0x50a1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_50a3:
	/* 0x50a3: js     5b58 <generic_sleepable_preload+0x5b58> */
	X86_SIM_X86_JCC(X86_CC_S, 0x50a3, 0x5b58, x86_l_5b58);
x86_l_50a9:
	/* 0x50a9: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_50ae:
	/* 0x50ae: cmp    WORD PTR [rax+0x1e6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2087354105856ULL);
x86_l_50b6:
	/* 0x50b6: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x50b6, 0x5b74, x86_l_5b74);
x86_l_50bc:
	/* 0x50bc: mov    ecx,DWORD PTR [rax+0x1e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 480ULL);
x86_l_50c2:
	/* 0x50c2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_50c6:
	/* 0x50c6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50ca:
	/* 0x50ca: cmp    WORD PTR [rax+0x1e4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2078764171264ULL);
x86_l_50d2:
	/* 0x50d2: je     50f4 <generic_sleepable_preload+0x50f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x50d2, 0x50f4, x86_l_50f4);
x86_l_50d4:
	/* 0x50d4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_50d7:
	/* 0x50d7: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_50dc:
	/* 0x50dc: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_50e1:
	/* 0x50e1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50e5:
	/* 0x50e5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_50ea:
	/* 0x50ea: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_50ec:
	/* 0x50ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_50ee:
	/* 0x50ee: js     5b6b <generic_sleepable_preload+0x5b6b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x50ee, 0x5b6b, x86_l_5b6b);
x86_l_50f4:
	/* 0x50f4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_50f9:
	/* 0x50f9: cmp    WORD PTR [rax+0x1ee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2121713844224ULL);
x86_l_5101:
	/* 0x5101: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5101, 0x5b74, x86_l_5b74);
x86_l_5107:
	/* 0x5107: mov    ecx,DWORD PTR [rax+0x1e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 488ULL);
x86_l_510d:
	/* 0x510d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5111:
	/* 0x5111: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5115:
	/* 0x5115: cmp    WORD PTR [rax+0x1ec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2113123909632ULL);
x86_l_511d:
	/* 0x511d: je     513f <generic_sleepable_preload+0x513f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x511d, 0x513f, x86_l_513f);
x86_l_511f:
	/* 0x511f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5122:
	/* 0x5122: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5127:
	/* 0x5127: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_512c:
	/* 0x512c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5130:
	/* 0x5130: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5135:
	/* 0x5135: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5137:
	/* 0x5137: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5139:
	/* 0x5139: js     5ce1 <generic_sleepable_preload+0x5ce1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5139, 0x5ce1, x86_l_5ce1);
x86_l_513f:
	/* 0x513f: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5144:
	/* 0x5144: cmp    WORD PTR [rax+0x1f6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2156073582592ULL);
x86_l_514c:
	/* 0x514c: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x514c, 0x5b74, x86_l_5b74);
x86_l_5152:
	/* 0x5152: mov    ecx,DWORD PTR [rax+0x1f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 496ULL);
x86_l_5158:
	/* 0x5158: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_515c:
	/* 0x515c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5160:
	/* 0x5160: cmp    WORD PTR [rax+0x1f4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2147483648000ULL);
x86_l_5168:
	/* 0x5168: je     518a <generic_sleepable_preload+0x518a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5168, 0x518a, x86_l_518a);
x86_l_516a:
	/* 0x516a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_516d:
	/* 0x516d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5172:
	/* 0x5172: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5177:
	/* 0x5177: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_517b:
	/* 0x517b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5180:
	/* 0x5180: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5182:
	/* 0x5182: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5184:
	/* 0x5184: js     5d6e <generic_sleepable_preload+0x5d6e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5184, 0x5d6e, x86_l_5d6e);
x86_l_518a:
	/* 0x518a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_518f:
	/* 0x518f: cmp    WORD PTR [rax+0x1fe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2190433320960ULL);
x86_l_5197:
	/* 0x5197: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5197, 0x5b74, x86_l_5b74);
x86_l_519d:
	/* 0x519d: mov    ecx,DWORD PTR [rax+0x1f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 504ULL);
x86_l_51a3:
	/* 0x51a3: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_51a7:
	/* 0x51a7: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51ab:
	/* 0x51ab: cmp    WORD PTR [rax+0x1fc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2181843386368ULL);
x86_l_51b3:
	/* 0x51b3: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51b3, 0x5b74, x86_l_5b74);
x86_l_51b9:
	/* 0x51b9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_51bc:
	/* 0x51bc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_51c1:
	/* 0x51c1: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_51c6:
	/* 0x51c6: jmp    5484 <generic_sleepable_preload+0x5484> */
	X86_SIM_X86_JMP(0x51c6, 0x5484, x86_l_5484);
x86_l_51cb:
	/* 0x51cb: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_51ce:
	/* 0x51ce: je     51f0 <generic_sleepable_preload+0x51f0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51ce, 0x51f0, x86_l_51f0);
x86_l_51d0:
	/* 0x51d0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_51d3:
	/* 0x51d3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_51d8:
	/* 0x51d8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_51dd:
	/* 0x51dd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51e1:
	/* 0x51e1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_51e6:
	/* 0x51e6: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_51e8:
	/* 0x51e8: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_51ea:
	/* 0x51ea: js     54a2 <generic_sleepable_preload+0x54a2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x51ea, 0x54a2, x86_l_54a2);
x86_l_51f0:
	/* 0x51f0: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_51f5:
	/* 0x51f5: cmp    WORD PTR [rax+0x1be],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1915555414016ULL);
x86_l_51fd:
	/* 0x51fd: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51fd, 0x5b74, x86_l_5b74);
x86_l_5203:
	/* 0x5203: mov    ecx,DWORD PTR [rax+0x1b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 440ULL);
x86_l_5209:
	/* 0x5209: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_520d:
	/* 0x520d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5211:
	/* 0x5211: cmp    WORD PTR [rax+0x1bc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1906965479424ULL);
x86_l_5219:
	/* 0x5219: je     523b <generic_sleepable_preload+0x523b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5219, 0x523b, x86_l_523b);
x86_l_521b:
	/* 0x521b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_521e:
	/* 0x521e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5223:
	/* 0x5223: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5228:
	/* 0x5228: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_522c:
	/* 0x522c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5231:
	/* 0x5231: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5233:
	/* 0x5233: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5235:
	/* 0x5235: js     550b <generic_sleepable_preload+0x550b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5235, 0x550b, x86_l_550b);
x86_l_523b:
	/* 0x523b: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5240:
	/* 0x5240: cmp    WORD PTR [rax+0x1c6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1949915152384ULL);
x86_l_5248:
	/* 0x5248: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5248, 0x5b74, x86_l_5b74);
x86_l_524e:
	/* 0x524e: mov    ecx,DWORD PTR [rax+0x1c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 448ULL);
x86_l_5254:
	/* 0x5254: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5258:
	/* 0x5258: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_525c:
	/* 0x525c: cmp    WORD PTR [rax+0x1c4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1941325217792ULL);
x86_l_5264:
	/* 0x5264: je     5286 <generic_sleepable_preload+0x5286> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5264, 0x5286, x86_l_5286);
x86_l_5266:
	/* 0x5266: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5269:
	/* 0x5269: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_526e:
	/* 0x526e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5273:
	/* 0x5273: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5277:
	/* 0x5277: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_527c:
	/* 0x527c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_527e:
	/* 0x527e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5280:
	/* 0x5280: js     5b1f <generic_sleepable_preload+0x5b1f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5280, 0x5b1f, x86_l_5b1f);
x86_l_5286:
	/* 0x5286: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_528b:
	/* 0x528b: cmp    WORD PTR [rax+0x1ce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1984274890752ULL);
x86_l_5293:
	/* 0x5293: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5293, 0x5b74, x86_l_5b74);
x86_l_5299:
	/* 0x5299: mov    ecx,DWORD PTR [rax+0x1c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 456ULL);
x86_l_529f:
	/* 0x529f: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_52a3:
	/* 0x52a3: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_52a7:
	/* 0x52a7: cmp    WORD PTR [rax+0x1cc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1975684956160ULL);
x86_l_52af:
	/* 0x52af: je     52d1 <generic_sleepable_preload+0x52d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52af, 0x52d1, x86_l_52d1);
x86_l_52b1:
	/* 0x52b1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_52b4:
	/* 0x52b4: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_52b9:
	/* 0x52b9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_52be:
	/* 0x52be: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_52c2:
	/* 0x52c2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_52c7:
	/* 0x52c7: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_52c9:
	/* 0x52c9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_52cb:
	/* 0x52cb: js     5b32 <generic_sleepable_preload+0x5b32> */
	X86_SIM_X86_JCC(X86_CC_S, 0x52cb, 0x5b32, x86_l_5b32);
x86_l_52d1:
	/* 0x52d1: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_52d6:
	/* 0x52d6: cmp    WORD PTR [rax+0x1d6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2018634629120ULL);
x86_l_52de:
	/* 0x52de: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52de, 0x5b74, x86_l_5b74);
x86_l_52e4:
	/* 0x52e4: mov    ecx,DWORD PTR [rax+0x1d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 464ULL);
x86_l_52ea:
	/* 0x52ea: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_52ee:
	/* 0x52ee: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_52f2:
	/* 0x52f2: cmp    WORD PTR [rax+0x1d4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2010044694528ULL);
x86_l_52fa:
	/* 0x52fa: je     531c <generic_sleepable_preload+0x531c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52fa, 0x531c, x86_l_531c);
x86_l_52fc:
	/* 0x52fc: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_52ff:
	/* 0x52ff: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5304:
	/* 0x5304: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5309:
	/* 0x5309: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_530d:
	/* 0x530d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5312:
	/* 0x5312: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5314:
	/* 0x5314: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5316:
	/* 0x5316: js     5b45 <generic_sleepable_preload+0x5b45> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5316, 0x5b45, x86_l_5b45);
x86_l_531c:
	/* 0x531c: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5321:
	/* 0x5321: cmp    WORD PTR [rax+0x1de],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2052994367488ULL);
x86_l_5329:
	/* 0x5329: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5329, 0x5b74, x86_l_5b74);
x86_l_532f:
	/* 0x532f: mov    ecx,DWORD PTR [rax+0x1d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 472ULL);
x86_l_5335:
	/* 0x5335: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5339:
	/* 0x5339: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_533d:
	/* 0x533d: cmp    WORD PTR [rax+0x1dc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2044404432896ULL);
x86_l_5345:
	/* 0x5345: je     5367 <generic_sleepable_preload+0x5367> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5345, 0x5367, x86_l_5367);
x86_l_5347:
	/* 0x5347: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_534a:
	/* 0x534a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_534f:
	/* 0x534f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5354:
	/* 0x5354: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5358:
	/* 0x5358: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_535d:
	/* 0x535d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_535f:
	/* 0x535f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5361:
	/* 0x5361: js     5b58 <generic_sleepable_preload+0x5b58> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5361, 0x5b58, x86_l_5b58);
x86_l_5367:
	/* 0x5367: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_536c:
	/* 0x536c: cmp    WORD PTR [rax+0x1e6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2087354105856ULL);
x86_l_5374:
	/* 0x5374: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5374, 0x5b74, x86_l_5b74);
x86_l_537a:
	/* 0x537a: mov    ecx,DWORD PTR [rax+0x1e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 480ULL);
x86_l_5380:
	/* 0x5380: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5384:
	/* 0x5384: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5388:
	/* 0x5388: cmp    WORD PTR [rax+0x1e4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2078764171264ULL);
x86_l_5390:
	/* 0x5390: je     53b2 <generic_sleepable_preload+0x53b2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5390, 0x53b2, x86_l_53b2);
x86_l_5392:
	/* 0x5392: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5395:
	/* 0x5395: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_539a:
	/* 0x539a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_539f:
	/* 0x539f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53a3:
	/* 0x53a3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_53a8:
	/* 0x53a8: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_53aa:
	/* 0x53aa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_53ac:
	/* 0x53ac: js     5b6b <generic_sleepable_preload+0x5b6b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x53ac, 0x5b6b, x86_l_5b6b);
x86_l_53b2:
	/* 0x53b2: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_53b7:
	/* 0x53b7: cmp    WORD PTR [rax+0x1ee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2121713844224ULL);
x86_l_53bf:
	/* 0x53bf: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53bf, 0x5b74, x86_l_5b74);
x86_l_53c5:
	/* 0x53c5: mov    ecx,DWORD PTR [rax+0x1e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 488ULL);
x86_l_53cb:
	/* 0x53cb: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_53cf:
	/* 0x53cf: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53d3:
	/* 0x53d3: cmp    WORD PTR [rax+0x1ec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2113123909632ULL);
x86_l_53db:
	/* 0x53db: je     53fd <generic_sleepable_preload+0x53fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53db, 0x53fd, x86_l_53fd);
x86_l_53dd:
	/* 0x53dd: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_53e0:
	/* 0x53e0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_53e5:
	/* 0x53e5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_53ea:
	/* 0x53ea: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53ee:
	/* 0x53ee: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_53f3:
	/* 0x53f3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_53f5:
	/* 0x53f5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_53f7:
	/* 0x53f7: js     5ce1 <generic_sleepable_preload+0x5ce1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x53f7, 0x5ce1, x86_l_5ce1);
x86_l_53fd:
	/* 0x53fd: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5402:
	/* 0x5402: cmp    WORD PTR [rax+0x1f6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2156073582592ULL);
x86_l_540a:
	/* 0x540a: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x540a, 0x5b74, x86_l_5b74);
x86_l_5410:
	/* 0x5410: mov    ecx,DWORD PTR [rax+0x1f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 496ULL);
x86_l_5416:
	/* 0x5416: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_541a:
	/* 0x541a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_541e:
	/* 0x541e: cmp    WORD PTR [rax+0x1f4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2147483648000ULL);
x86_l_5426:
	/* 0x5426: je     5448 <generic_sleepable_preload+0x5448> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5426, 0x5448, x86_l_5448);
x86_l_5428:
	/* 0x5428: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_542b:
	/* 0x542b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5430:
	/* 0x5430: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5435:
	/* 0x5435: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5439:
	/* 0x5439: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_543e:
	/* 0x543e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5440:
	/* 0x5440: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5442:
	/* 0x5442: js     5d6e <generic_sleepable_preload+0x5d6e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5442, 0x5d6e, x86_l_5d6e);
x86_l_5448:
	/* 0x5448: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_544d:
	/* 0x544d: cmp    WORD PTR [rax+0x1fe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2190433320960ULL);
x86_l_5455:
	/* 0x5455: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5455, 0x5b74, x86_l_5b74);
x86_l_545b:
	/* 0x545b: mov    ecx,DWORD PTR [rax+0x1f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 504ULL);
x86_l_5461:
	/* 0x5461: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5465:
	/* 0x5465: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5469:
	/* 0x5469: cmp    WORD PTR [rax+0x1fc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2181843386368ULL);
x86_l_5471:
	/* 0x5471: je     5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5471, 0x5b74, x86_l_5b74);
x86_l_5477:
	/* 0x5477: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_547a:
	/* 0x547a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_547f:
	/* 0x547f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5484:
	/* 0x5484: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5488:
	/* 0x5488: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_548d:
	/* 0x548d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_548f:
	/* 0x548f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5491:
	/* 0x5491: jns    5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5491, 0x5b74, x86_l_5b74);
x86_l_5497:
	/* 0x5497: mov    r12d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 10ULL);
x86_l_549d:
	/* 0x549d: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x549d, 0x5b71, x86_l_5b71);
x86_l_54a2:
	/* 0x54a2: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_54a8:
	/* 0x54a8: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x54a8, 0x5b71, x86_l_5b71);
x86_l_54ad:
	/* 0x54ad: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_54b5:
	/* 0x54b5: cmp    edx,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 10ULL);
x86_l_54b8:
	/* 0x54b8: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54b8, 0x551b, x86_l_551b);
x86_l_54ba:
	/* 0x54ba: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_54bf:
	/* 0x54bf: cmp    edx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 11ULL);
x86_l_54c2:
	/* 0x54c2: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54c2, 0x551b, x86_l_551b);
x86_l_54c4:
	/* 0x54c4: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x54c4, 0x552e, x86_l_552e);
x86_l_54c6:
	/* 0x54c6: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_54cb:
	/* 0x54cb: cmp    edx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 2ULL);
x86_l_54ce:
	/* 0x54ce: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54ce, 0x551b, x86_l_551b);
x86_l_54d0:
	/* 0x54d0: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_54d5:
	/* 0x54d5: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_54d8:
	/* 0x54d8: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54d8, 0x551b, x86_l_551b);
x86_l_54da:
	/* 0x54da: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x54da, 0x552e, x86_l_552e);
x86_l_54dc:
	/* 0x54dc: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_54e4:
	/* 0x54e4: cmp    edx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 6ULL);
x86_l_54e7:
	/* 0x54e7: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54e7, 0x551b, x86_l_551b);
x86_l_54e9:
	/* 0x54e9: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_54ee:
	/* 0x54ee: cmp    edx,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 7ULL);
x86_l_54f1:
	/* 0x54f1: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54f1, 0x551b, x86_l_551b);
x86_l_54f3:
	/* 0x54f3: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x54f3, 0x552e, x86_l_552e);
x86_l_54f5:
	/* 0x54f5: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_54fa:
	/* 0x54fa: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_54fd:
	/* 0x54fd: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54fd, 0x551b, x86_l_551b);
x86_l_54ff:
	/* 0x54ff: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5504:
	/* 0x5504: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_5507:
	/* 0x5507: je     551b <generic_sleepable_preload+0x551b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5507, 0x551b, x86_l_551b);
x86_l_5509:
	/* 0x5509: jmp    552e <generic_sleepable_preload+0x552e> */
	X86_SIM_X86_JMP(0x5509, 0x552e, x86_l_552e);
x86_l_550b:
	/* 0x550b: mov    r12d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 2ULL);
x86_l_5511:
	/* 0x5511: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x5511, 0x5b71, x86_l_5b71);
x86_l_5516:
	/* 0x5516: mov    rsi,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_551b:
	/* 0x551b: shl    al,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_SHL, 3ULL);
x86_l_551e:
	/* 0x551e: mov    cl,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_8, 64ULL);
x86_l_5520:
	/* 0x5520: sub    cl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_8, X86_ALU_SUB);
x86_l_5522:
	/* 0x5522: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
x86_l_5527:
	/* 0x5527: sub    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5529:
	/* 0x5529: bzhi   rcx,QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_552e:
	/* 0x552e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5532:
	/* 0x5532: mov    ebx,DWORD PTR [r12+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_5537:
	/* 0x5537: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
x86_l_553a:
	/* 0x553a: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_553d:
	/* 0x553d: mov    r13b,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_8, 1ULL);
x86_l_5540:
	/* 0x5540: cmp    WORD PTR [rsi+0x1b6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1881195675648ULL);
x86_l_5548:
	/* 0x5548: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5548, 0x5c31, x86_l_5c31);
x86_l_554e:
	/* 0x554e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_5555:
	/* 0x5555: movzx  edx,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_5558:
	/* 0x5558: mov    eax,DWORD PTR [rsi+0x1b0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 432ULL);
x86_l_555e:
	/* 0x555e: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5561:
	/* 0x5561: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5565:
	/* 0x5565: movzx  eax,WORD PTR [rsi+0x1b4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 436ULL);
x86_l_556c:
	/* 0x556c: test   dl,dl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8);
x86_l_556e:
	/* 0x556e: je     5832 <generic_sleepable_preload+0x5832> */
	X86_SIM_X86_JCC(X86_CC_E, 0x556e, 0x5832, x86_l_5832);
x86_l_5574:
	/* 0x5574: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_5577:
	/* 0x5577: je     5599 <generic_sleepable_preload+0x5599> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5577, 0x5599, x86_l_5599);
x86_l_5579:
	/* 0x5579: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_557c:
	/* 0x557c: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5581:
	/* 0x5581: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5586:
	/* 0x5586: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_558a:
	/* 0x558a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_558f:
	/* 0x558f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5591:
	/* 0x5591: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5593:
	/* 0x5593: js     5b09 <generic_sleepable_preload+0x5b09> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5593, 0x5b09, x86_l_5b09);
x86_l_5599:
	/* 0x5599: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_559e:
	/* 0x559e: cmp    WORD PTR [rax+0x1be],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1915555414016ULL);
x86_l_55a6:
	/* 0x55a6: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x55a6, 0x5c31, x86_l_5c31);
x86_l_55ac:
	/* 0x55ac: mov    ecx,DWORD PTR [rax+0x1b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 440ULL);
x86_l_55b2:
	/* 0x55b2: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_55b6:
	/* 0x55b6: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55ba:
	/* 0x55ba: cmp    WORD PTR [rax+0x1bc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1906965479424ULL);
x86_l_55c2:
	/* 0x55c2: je     55e4 <generic_sleepable_preload+0x55e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x55c2, 0x55e4, x86_l_55e4);
x86_l_55c4:
	/* 0x55c4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_55c7:
	/* 0x55c7: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_55cc:
	/* 0x55cc: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_55d1:
	/* 0x55d1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55d5:
	/* 0x55d5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_55da:
	/* 0x55da: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_55dc:
	/* 0x55dc: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_55de:
	/* 0x55de: js     5b14 <generic_sleepable_preload+0x5b14> */
	X86_SIM_X86_JCC(X86_CC_S, 0x55de, 0x5b14, x86_l_5b14);
x86_l_55e4:
	/* 0x55e4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_55e9:
	/* 0x55e9: cmp    WORD PTR [rax+0x1c6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1949915152384ULL);
x86_l_55f1:
	/* 0x55f1: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x55f1, 0x5c31, x86_l_5c31);
x86_l_55f7:
	/* 0x55f7: mov    ecx,DWORD PTR [rax+0x1c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 448ULL);
x86_l_55fd:
	/* 0x55fd: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5601:
	/* 0x5601: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5605:
	/* 0x5605: cmp    WORD PTR [rax+0x1c4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1941325217792ULL);
x86_l_560d:
	/* 0x560d: je     562f <generic_sleepable_preload+0x562f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x560d, 0x562f, x86_l_562f);
x86_l_560f:
	/* 0x560f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5612:
	/* 0x5612: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5617:
	/* 0x5617: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_561c:
	/* 0x561c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5620:
	/* 0x5620: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5625:
	/* 0x5625: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5627:
	/* 0x5627: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5629:
	/* 0x5629: js     5b27 <generic_sleepable_preload+0x5b27> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5629, 0x5b27, x86_l_5b27);
x86_l_562f:
	/* 0x562f: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5634:
	/* 0x5634: cmp    WORD PTR [rax+0x1ce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1984274890752ULL);
x86_l_563c:
	/* 0x563c: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x563c, 0x5c31, x86_l_5c31);
x86_l_5642:
	/* 0x5642: mov    ecx,DWORD PTR [rax+0x1c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 456ULL);
x86_l_5648:
	/* 0x5648: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_564c:
	/* 0x564c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5650:
	/* 0x5650: cmp    WORD PTR [rax+0x1cc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1975684956160ULL);
x86_l_5658:
	/* 0x5658: je     567a <generic_sleepable_preload+0x567a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5658, 0x567a, x86_l_567a);
x86_l_565a:
	/* 0x565a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_565d:
	/* 0x565d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5662:
	/* 0x5662: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5667:
	/* 0x5667: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_566b:
	/* 0x566b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5670:
	/* 0x5670: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5672:
	/* 0x5672: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5674:
	/* 0x5674: js     5b3a <generic_sleepable_preload+0x5b3a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5674, 0x5b3a, x86_l_5b3a);
x86_l_567a:
	/* 0x567a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_567f:
	/* 0x567f: cmp    WORD PTR [rax+0x1d6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2018634629120ULL);
x86_l_5687:
	/* 0x5687: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5687, 0x5c31, x86_l_5c31);
x86_l_568d:
	/* 0x568d: mov    ecx,DWORD PTR [rax+0x1d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 464ULL);
x86_l_5693:
	/* 0x5693: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5697:
	/* 0x5697: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_569b:
	/* 0x569b: cmp    WORD PTR [rax+0x1d4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2010044694528ULL);
x86_l_56a3:
	/* 0x56a3: je     56c5 <generic_sleepable_preload+0x56c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56a3, 0x56c5, x86_l_56c5);
x86_l_56a5:
	/* 0x56a5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_56a8:
	/* 0x56a8: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_56ad:
	/* 0x56ad: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_56b2:
	/* 0x56b2: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56b6:
	/* 0x56b6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_56bb:
	/* 0x56bb: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_56bd:
	/* 0x56bd: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_56bf:
	/* 0x56bf: js     5b4d <generic_sleepable_preload+0x5b4d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x56bf, 0x5b4d, x86_l_5b4d);
x86_l_56c5:
	/* 0x56c5: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_56ca:
	/* 0x56ca: cmp    WORD PTR [rax+0x1de],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2052994367488ULL);
x86_l_56d2:
	/* 0x56d2: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56d2, 0x5c31, x86_l_5c31);
x86_l_56d8:
	/* 0x56d8: mov    ecx,DWORD PTR [rax+0x1d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 472ULL);
x86_l_56de:
	/* 0x56de: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_56e2:
	/* 0x56e2: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56e6:
	/* 0x56e6: cmp    WORD PTR [rax+0x1dc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2044404432896ULL);
x86_l_56ee:
	/* 0x56ee: je     5710 <generic_sleepable_preload+0x5710> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56ee, 0x5710, x86_l_5710);
x86_l_56f0:
	/* 0x56f0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_56f3:
	/* 0x56f3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_56f8:
	/* 0x56f8: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_56fd:
	/* 0x56fd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5701:
	/* 0x5701: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5706:
	/* 0x5706: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5708:
	/* 0x5708: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_570a:
	/* 0x570a: js     5b60 <generic_sleepable_preload+0x5b60> */
	X86_SIM_X86_JCC(X86_CC_S, 0x570a, 0x5b60, x86_l_5b60);
x86_l_5710:
	/* 0x5710: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5715:
	/* 0x5715: cmp    WORD PTR [rax+0x1e6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2087354105856ULL);
x86_l_571d:
	/* 0x571d: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x571d, 0x5c31, x86_l_5c31);
x86_l_5723:
	/* 0x5723: mov    ecx,DWORD PTR [rax+0x1e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 480ULL);
x86_l_5729:
	/* 0x5729: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_572d:
	/* 0x572d: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5731:
	/* 0x5731: cmp    WORD PTR [rax+0x1e4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2078764171264ULL);
x86_l_5739:
	/* 0x5739: je     575b <generic_sleepable_preload+0x575b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5739, 0x575b, x86_l_575b);
x86_l_573b:
	/* 0x573b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_573e:
	/* 0x573e: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5743:
	/* 0x5743: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5748:
	/* 0x5748: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_574c:
	/* 0x574c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5751:
	/* 0x5751: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5753:
	/* 0x5753: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5755:
	/* 0x5755: js     5c28 <generic_sleepable_preload+0x5c28> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5755, 0x5c28, x86_l_5c28);
x86_l_575b:
	/* 0x575b: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5760:
	/* 0x5760: cmp    WORD PTR [rax+0x1ee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2121713844224ULL);
x86_l_5768:
	/* 0x5768: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5768, 0x5c31, x86_l_5c31);
x86_l_576e:
	/* 0x576e: mov    ecx,DWORD PTR [rax+0x1e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 488ULL);
x86_l_5774:
	/* 0x5774: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5778:
	/* 0x5778: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_577c:
	/* 0x577c: cmp    WORD PTR [rax+0x1ec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2113123909632ULL);
x86_l_5784:
	/* 0x5784: je     57a6 <generic_sleepable_preload+0x57a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5784, 0x57a6, x86_l_57a6);
x86_l_5786:
	/* 0x5786: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5789:
	/* 0x5789: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_578e:
	/* 0x578e: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5793:
	/* 0x5793: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5797:
	/* 0x5797: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_579c:
	/* 0x579c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_579e:
	/* 0x579e: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_57a0:
	/* 0x57a0: js     5cef <generic_sleepable_preload+0x5cef> */
	X86_SIM_X86_JCC(X86_CC_S, 0x57a0, 0x5cef, x86_l_5cef);
x86_l_57a6:
	/* 0x57a6: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_57ab:
	/* 0x57ab: cmp    WORD PTR [rax+0x1f6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2156073582592ULL);
x86_l_57b3:
	/* 0x57b3: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x57b3, 0x5c31, x86_l_5c31);
x86_l_57b9:
	/* 0x57b9: mov    ecx,DWORD PTR [rax+0x1f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 496ULL);
x86_l_57bf:
	/* 0x57bf: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_57c3:
	/* 0x57c3: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_57c7:
	/* 0x57c7: cmp    WORD PTR [rax+0x1f4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2147483648000ULL);
x86_l_57cf:
	/* 0x57cf: je     57f1 <generic_sleepable_preload+0x57f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x57cf, 0x57f1, x86_l_57f1);
x86_l_57d1:
	/* 0x57d1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_57d4:
	/* 0x57d4: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_57d9:
	/* 0x57d9: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_57de:
	/* 0x57de: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_57e2:
	/* 0x57e2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_57e7:
	/* 0x57e7: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_57e9:
	/* 0x57e9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_57eb:
	/* 0x57eb: js     5d79 <generic_sleepable_preload+0x5d79> */
	X86_SIM_X86_JCC(X86_CC_S, 0x57eb, 0x5d79, x86_l_5d79);
x86_l_57f1:
	/* 0x57f1: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_57f6:
	/* 0x57f6: cmp    WORD PTR [rax+0x1fe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2190433320960ULL);
x86_l_57fe:
	/* 0x57fe: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x57fe, 0x5c31, x86_l_5c31);
x86_l_5804:
	/* 0x5804: mov    ecx,DWORD PTR [rax+0x1f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 504ULL);
x86_l_580a:
	/* 0x580a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_580e:
	/* 0x580e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5812:
	/* 0x5812: cmp    WORD PTR [rax+0x1fc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2181843386368ULL);
x86_l_581a:
	/* 0x581a: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x581a, 0x5c31, x86_l_5c31);
x86_l_5820:
	/* 0x5820: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5823:
	/* 0x5823: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5828:
	/* 0x5828: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_582d:
	/* 0x582d: jmp    5aeb <generic_sleepable_preload+0x5aeb> */
	X86_SIM_X86_JMP(0x582d, 0x5aeb, x86_l_5aeb);
x86_l_5832:
	/* 0x5832: test   ax,ax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16);
x86_l_5835:
	/* 0x5835: je     5857 <generic_sleepable_preload+0x5857> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5835, 0x5857, x86_l_5857);
x86_l_5837:
	/* 0x5837: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_583a:
	/* 0x583a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_583f:
	/* 0x583f: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5844:
	/* 0x5844: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5848:
	/* 0x5848: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_584d:
	/* 0x584d: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_584f:
	/* 0x584f: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5851:
	/* 0x5851: js     5b09 <generic_sleepable_preload+0x5b09> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5851, 0x5b09, x86_l_5b09);
x86_l_5857:
	/* 0x5857: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_585c:
	/* 0x585c: cmp    WORD PTR [rax+0x1be],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1915555414016ULL);
x86_l_5864:
	/* 0x5864: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5864, 0x5c31, x86_l_5c31);
x86_l_586a:
	/* 0x586a: mov    ecx,DWORD PTR [rax+0x1b8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 440ULL);
x86_l_5870:
	/* 0x5870: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5874:
	/* 0x5874: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5878:
	/* 0x5878: cmp    WORD PTR [rax+0x1bc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1906965479424ULL);
x86_l_5880:
	/* 0x5880: je     58a2 <generic_sleepable_preload+0x58a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5880, 0x58a2, x86_l_58a2);
x86_l_5882:
	/* 0x5882: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5885:
	/* 0x5885: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_588a:
	/* 0x588a: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_588f:
	/* 0x588f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5893:
	/* 0x5893: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5898:
	/* 0x5898: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_589a:
	/* 0x589a: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_589c:
	/* 0x589c: js     5b14 <generic_sleepable_preload+0x5b14> */
	X86_SIM_X86_JCC(X86_CC_S, 0x589c, 0x5b14, x86_l_5b14);
x86_l_58a2:
	/* 0x58a2: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_58a7:
	/* 0x58a7: cmp    WORD PTR [rax+0x1c6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1949915152384ULL);
x86_l_58af:
	/* 0x58af: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x58af, 0x5c31, x86_l_5c31);
x86_l_58b5:
	/* 0x58b5: mov    ecx,DWORD PTR [rax+0x1c0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 448ULL);
x86_l_58bb:
	/* 0x58bb: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_58bf:
	/* 0x58bf: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_58c3:
	/* 0x58c3: cmp    WORD PTR [rax+0x1c4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1941325217792ULL);
x86_l_58cb:
	/* 0x58cb: je     58ed <generic_sleepable_preload+0x58ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x58cb, 0x58ed, x86_l_58ed);
x86_l_58cd:
	/* 0x58cd: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_58d0:
	/* 0x58d0: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_58d5:
	/* 0x58d5: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_58da:
	/* 0x58da: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_58de:
	/* 0x58de: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_58e3:
	/* 0x58e3: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_58e5:
	/* 0x58e5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_58e7:
	/* 0x58e7: js     5b27 <generic_sleepable_preload+0x5b27> */
	X86_SIM_X86_JCC(X86_CC_S, 0x58e7, 0x5b27, x86_l_5b27);
x86_l_58ed:
	/* 0x58ed: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_58f2:
	/* 0x58f2: cmp    WORD PTR [rax+0x1ce],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1984274890752ULL);
x86_l_58fa:
	/* 0x58fa: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x58fa, 0x5c31, x86_l_5c31);
x86_l_5900:
	/* 0x5900: mov    ecx,DWORD PTR [rax+0x1c8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 456ULL);
x86_l_5906:
	/* 0x5906: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_590a:
	/* 0x590a: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_590e:
	/* 0x590e: cmp    WORD PTR [rax+0x1cc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 1975684956160ULL);
x86_l_5916:
	/* 0x5916: je     5938 <generic_sleepable_preload+0x5938> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5916, 0x5938, x86_l_5938);
x86_l_5918:
	/* 0x5918: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_591b:
	/* 0x591b: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5920:
	/* 0x5920: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5925:
	/* 0x5925: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5929:
	/* 0x5929: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_592e:
	/* 0x592e: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5930:
	/* 0x5930: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5932:
	/* 0x5932: js     5b3a <generic_sleepable_preload+0x5b3a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5932, 0x5b3a, x86_l_5b3a);
x86_l_5938:
	/* 0x5938: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_593d:
	/* 0x593d: cmp    WORD PTR [rax+0x1d6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2018634629120ULL);
x86_l_5945:
	/* 0x5945: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5945, 0x5c31, x86_l_5c31);
x86_l_594b:
	/* 0x594b: mov    ecx,DWORD PTR [rax+0x1d0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 464ULL);
x86_l_5951:
	/* 0x5951: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5955:
	/* 0x5955: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5959:
	/* 0x5959: cmp    WORD PTR [rax+0x1d4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2010044694528ULL);
x86_l_5961:
	/* 0x5961: je     5983 <generic_sleepable_preload+0x5983> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5961, 0x5983, x86_l_5983);
x86_l_5963:
	/* 0x5963: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5966:
	/* 0x5966: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_596b:
	/* 0x596b: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5970:
	/* 0x5970: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5974:
	/* 0x5974: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5979:
	/* 0x5979: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_597b:
	/* 0x597b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_597d:
	/* 0x597d: js     5b4d <generic_sleepable_preload+0x5b4d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x597d, 0x5b4d, x86_l_5b4d);
x86_l_5983:
	/* 0x5983: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5988:
	/* 0x5988: cmp    WORD PTR [rax+0x1de],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2052994367488ULL);
x86_l_5990:
	/* 0x5990: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5990, 0x5c31, x86_l_5c31);
x86_l_5996:
	/* 0x5996: mov    ecx,DWORD PTR [rax+0x1d8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 472ULL);
x86_l_599c:
	/* 0x599c: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_59a0:
	/* 0x59a0: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59a4:
	/* 0x59a4: cmp    WORD PTR [rax+0x1dc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2044404432896ULL);
x86_l_59ac:
	/* 0x59ac: je     59ce <generic_sleepable_preload+0x59ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59ac, 0x59ce, x86_l_59ce);
x86_l_59ae:
	/* 0x59ae: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_59b1:
	/* 0x59b1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_59b6:
	/* 0x59b6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_59bb:
	/* 0x59bb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59bf:
	/* 0x59bf: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_59c4:
	/* 0x59c4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_59c6:
	/* 0x59c6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_59c8:
	/* 0x59c8: js     5b60 <generic_sleepable_preload+0x5b60> */
	X86_SIM_X86_JCC(X86_CC_S, 0x59c8, 0x5b60, x86_l_5b60);
x86_l_59ce:
	/* 0x59ce: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_59d3:
	/* 0x59d3: cmp    WORD PTR [rax+0x1e6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2087354105856ULL);
x86_l_59db:
	/* 0x59db: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59db, 0x5c31, x86_l_5c31);
x86_l_59e1:
	/* 0x59e1: mov    ecx,DWORD PTR [rax+0x1e0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 480ULL);
x86_l_59e7:
	/* 0x59e7: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_59eb:
	/* 0x59eb: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59ef:
	/* 0x59ef: cmp    WORD PTR [rax+0x1e4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2078764171264ULL);
x86_l_59f7:
	/* 0x59f7: je     5a19 <generic_sleepable_preload+0x5a19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59f7, 0x5a19, x86_l_5a19);
x86_l_59f9:
	/* 0x59f9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_59fc:
	/* 0x59fc: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5a01:
	/* 0x5a01: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5a06:
	/* 0x5a06: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a0a:
	/* 0x5a0a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5a0f:
	/* 0x5a0f: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5a11:
	/* 0x5a11: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5a13:
	/* 0x5a13: js     5c28 <generic_sleepable_preload+0x5c28> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5a13, 0x5c28, x86_l_5c28);
x86_l_5a19:
	/* 0x5a19: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5a1e:
	/* 0x5a1e: cmp    WORD PTR [rax+0x1ee],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2121713844224ULL);
x86_l_5a26:
	/* 0x5a26: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a26, 0x5c31, x86_l_5c31);
x86_l_5a2c:
	/* 0x5a2c: mov    ecx,DWORD PTR [rax+0x1e8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 488ULL);
x86_l_5a32:
	/* 0x5a32: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5a36:
	/* 0x5a36: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a3a:
	/* 0x5a3a: cmp    WORD PTR [rax+0x1ec],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2113123909632ULL);
x86_l_5a42:
	/* 0x5a42: je     5a64 <generic_sleepable_preload+0x5a64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a42, 0x5a64, x86_l_5a64);
x86_l_5a44:
	/* 0x5a44: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5a47:
	/* 0x5a47: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5a4c:
	/* 0x5a4c: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5a51:
	/* 0x5a51: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a55:
	/* 0x5a55: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5a5a:
	/* 0x5a5a: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5a5c:
	/* 0x5a5c: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5a5e:
	/* 0x5a5e: js     5cef <generic_sleepable_preload+0x5cef> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5a5e, 0x5cef, x86_l_5cef);
x86_l_5a64:
	/* 0x5a64: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5a69:
	/* 0x5a69: cmp    WORD PTR [rax+0x1f6],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2156073582592ULL);
x86_l_5a71:
	/* 0x5a71: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a71, 0x5c31, x86_l_5c31);
x86_l_5a77:
	/* 0x5a77: mov    ecx,DWORD PTR [rax+0x1f0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 496ULL);
x86_l_5a7d:
	/* 0x5a7d: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5a81:
	/* 0x5a81: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a85:
	/* 0x5a85: cmp    WORD PTR [rax+0x1f4],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2147483648000ULL);
x86_l_5a8d:
	/* 0x5a8d: je     5aaf <generic_sleepable_preload+0x5aaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a8d, 0x5aaf, x86_l_5aaf);
x86_l_5a8f:
	/* 0x5a8f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5a92:
	/* 0x5a92: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5a97:
	/* 0x5a97: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5a9c:
	/* 0x5a9c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5aa0:
	/* 0x5aa0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5aa5:
	/* 0x5aa5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5aa7:
	/* 0x5aa7: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5aa9:
	/* 0x5aa9: js     5d79 <generic_sleepable_preload+0x5d79> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5aa9, 0x5d79, x86_l_5d79);
x86_l_5aaf:
	/* 0x5aaf: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5ab4:
	/* 0x5ab4: cmp    WORD PTR [rax+0x1fe],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2190433320960ULL);
x86_l_5abc:
	/* 0x5abc: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5abc, 0x5c31, x86_l_5c31);
x86_l_5ac2:
	/* 0x5ac2: mov    ecx,DWORD PTR [rax+0x1f8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 504ULL);
x86_l_5ac8:
	/* 0x5ac8: add    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_5acc:
	/* 0x5acc: mov    QWORD PTR [rsp],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ad0:
	/* 0x5ad0: cmp    WORD PTR [rax+0x1fc],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2181843386368ULL);
x86_l_5ad8:
	/* 0x5ad8: je     5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ad8, 0x5c31, x86_l_5c31);
x86_l_5ade:
	/* 0x5ade: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5ae1:
	/* 0x5ae1: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_5ae6:
	/* 0x5ae6: mov    eax,0x94 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 148ULL);
x86_l_5aeb:
	/* 0x5aeb: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5aef:
	/* 0x5aef: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5af4:
	/* 0x5af4: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5af6:
	/* 0x5af6: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_5af8:
	/* 0x5af8: jns    5c31 <generic_sleepable_preload+0x5c31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5af8, 0x5c31, x86_l_5c31);
x86_l_5afe:
	/* 0x5afe: mov    r12d,0xa */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 10ULL);
x86_l_5b04:
	/* 0x5b04: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b04, 0x5c2e, x86_l_5c2e);
x86_l_5b09:
	/* 0x5b09: mov    r12d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 1ULL);
x86_l_5b0f:
	/* 0x5b0f: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b0f, 0x5c2e, x86_l_5c2e);
x86_l_5b14:
	/* 0x5b14: mov    r12d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 2ULL);
x86_l_5b1a:
	/* 0x5b1a: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b1a, 0x5c2e, x86_l_5c2e);
x86_l_5b1f:
	/* 0x5b1f: mov    r12d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 3ULL);
x86_l_5b25:
	/* 0x5b25: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x5b25, 0x5b71, x86_l_5b71);
x86_l_5b27:
	/* 0x5b27: mov    r12d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 3ULL);
x86_l_5b2d:
	/* 0x5b2d: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b2d, 0x5c2e, x86_l_5c2e);
x86_l_5b32:
	/* 0x5b32: mov    r12d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4ULL);
x86_l_5b38:
	/* 0x5b38: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x5b38, 0x5b71, x86_l_5b71);
x86_l_5b3a:
	/* 0x5b3a: mov    r12d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4ULL);
x86_l_5b40:
	/* 0x5b40: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b40, 0x5c2e, x86_l_5c2e);
x86_l_5b45:
	/* 0x5b45: mov    r12d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 5ULL);
x86_l_5b4b:
	/* 0x5b4b: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x5b4b, 0x5b71, x86_l_5b71);
x86_l_5b4d:
	/* 0x5b4d: mov    r12d,0x5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 5ULL);
x86_l_5b53:
	/* 0x5b53: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b53, 0x5c2e, x86_l_5c2e);
x86_l_5b58:
	/* 0x5b58: mov    r12d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 6ULL);
x86_l_5b5e:
	/* 0x5b5e: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x5b5e, 0x5b71, x86_l_5b71);
x86_l_5b60:
	/* 0x5b60: mov    r12d,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 6ULL);
x86_l_5b66:
	/* 0x5b66: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5b66, 0x5c2e, x86_l_5c2e);
x86_l_5b6b:
	/* 0x5b6b: mov    r12d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 7ULL);
x86_l_5b71:
	/* 0x5b71: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5b74:
	/* 0x5b74: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5b79:
	/* 0x5b79: mov    ebx,DWORD PTR [rax+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_5b7c:
	/* 0x5b7c: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_5b7f:
	/* 0x5b7f: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_5b84:
	/* 0x5b84: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_5b89:
	/* 0x5b89: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5b8e:
	/* 0x5b8e: mov    rdx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RDI, X86_WIDTH_64);
x86_l_5b91:
	/* 0x5b91: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5b93:
	/* 0x5b93: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_5b96:
	/* 0x5b96: jne    4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b96, 0x4d78, x86_l_4d78);
x86_l_5b9c:
	/* 0x5b9c: mov    rbx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ba0:
	/* 0x5ba0: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_5ba5:
	/* 0x5ba5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5ba7:
	/* 0x5ba7: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5bac:
	/* 0x5bac: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_5bb4:
	/* 0x5bb4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_5bbb:
	/* 0x5bbb: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_5bc0:
	/* 0x5bc0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5bc5:
	/* 0x5bc5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5bc7:
	/* 0x5bc7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5bca:
	/* 0x5bca: je     4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5bca, 0x4d78, x86_l_4d78);
x86_l_5bd0:
	/* 0x5bd0: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_5bd3:
	/* 0x5bd3: mov    r14,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_5bda:
	/* 0x5bda: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5bdc:
	/* 0x5bdc: lea    r15,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5be1:
	/* 0x5be1: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_5be6:
	/* 0x5be6: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_5be9:
	/* 0x5be9: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_5bec:
	/* 0x5bec: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5bee:
	/* 0x5bee: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5bf0:
	/* 0x5bf0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5bf5:
	/* 0x5bf5: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_5bf8:
	/* 0x5bf8: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_5bfb:
	/* 0x5bfb: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5bfd:
	/* 0x5bfd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5c00:
	/* 0x5c00: je     4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c00, 0x4d78, x86_l_4d78);
x86_l_5c06:
	/* 0x5c06: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_5c09:
	/* 0x5c09: je     5cd9 <generic_sleepable_preload+0x5cd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c09, 0x5cd9, x86_l_5cd9);
x86_l_5c0f:
	/* 0x5c0f: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_5c12:
	/* 0x5c12: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_5c16:
	/* 0x5c16: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_5c1b:
	/* 0x5c1b: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_5c1e:
	/* 0x5c1e: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_5c23:
	/* 0x5c23: jmp    5cbd <generic_sleepable_preload+0x5cbd> */
	X86_SIM_X86_JMP(0x5c23, 0x5cbd, x86_l_5cbd);
x86_l_5c28:
	/* 0x5c28: mov    r12d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 7ULL);
x86_l_5c2e:
	/* 0x5c2e: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c31:
	/* 0x5c31: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_5c34:
	/* 0x5c34: jne    4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c34, 0x4d78, x86_l_4d78);
x86_l_5c3a:
	/* 0x5c3a: mov    rbx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c3e:
	/* 0x5c3e: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_5c43:
	/* 0x5c43: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5c45:
	/* 0x5c45: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5c4a:
	/* 0x5c4a: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_5c52:
	/* 0x5c52: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero));
x86_l_5c59:
	/* 0x5c59: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_5c5e:
	/* 0x5c5e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5c63:
	/* 0x5c63: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5c65:
	/* 0x5c65: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5c68:
	/* 0x5c68: je     4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c68, 0x4d78, x86_l_4d78);
x86_l_5c6e:
	/* 0x5c6e: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
x86_l_5c71:
	/* 0x5c71: mov    r14,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&sleepable_preload));
x86_l_5c78:
	/* 0x5c78: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c7a:
	/* 0x5c7a: lea    r15,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5c7f:
	/* 0x5c7f: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_5c84:
	/* 0x5c84: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_5c87:
	/* 0x5c87: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_5c8a:
	/* 0x5c8a: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c8c:
	/* 0x5c8c: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5c8e:
	/* 0x5c8e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_5c93:
	/* 0x5c93: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_5c96:
	/* 0x5c96: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
x86_l_5c99:
	/* 0x5c99: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5c9b:
	/* 0x5c9b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_5c9e:
	/* 0x5c9e: je     4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c9e, 0x4d78, x86_l_4d78);
x86_l_5ca4:
	/* 0x5ca4: test   r13b,r13b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8);
x86_l_5ca7:
	/* 0x5ca7: je     5cd9 <generic_sleepable_preload+0x5cd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ca7, 0x5cd9, x86_l_5cd9);
x86_l_5ca9:
	/* 0x5ca9: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_5cac:
	/* 0x5cac: add    rdi,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_5cb0:
	/* 0x5cb0: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_5cb5:
	/* 0x5cb5: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_5cb8:
	/* 0x5cb8: mov    eax,0x72 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 114ULL);
x86_l_5cbd:
	/* 0x5cbd: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_5cc2:
	/* 0x5cc2: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_5cc5:
	/* 0x5cc5: call   rax */
	X86_SIM_BPF_CALL_REG(X86_RAX);
x86_l_5cc7:
	/* 0x5cc7: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_5cca:
	/* 0x5cca: mov    rax,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R14, X86_WIDTH_64);
x86_l_5ccd:
	/* 0x5ccd: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_5cd0:
	/* 0x5cd0: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
x86_l_5cd5:
	/* 0x5cd5: cmovs  r12d,ecx */
	X86_SIM_L_EXEC_CMOV(X86_R12, X86_RCX, X86_WIDTH_32, X86_CC_S);
x86_l_5cd9:
	/* 0x5cd9: mov    DWORD PTR [rax],r12d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5cdc:
	/* 0x5cdc: jmp    4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JMP(0x5cdc, 0x4d78, x86_l_4d78);
x86_l_5ce1:
	/* 0x5ce1: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5ce4:
	/* 0x5ce4: mov    r12d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 8ULL);
x86_l_5cea:
	/* 0x5cea: jmp    5b74 <generic_sleepable_preload+0x5b74> */
	X86_SIM_X86_JMP(0x5cea, 0x5b74, x86_l_5b74);
x86_l_5cef:
	/* 0x5cef: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5cf2:
	/* 0x5cf2: mov    r12d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 8ULL);
x86_l_5cf8:
	/* 0x5cf8: cmp    ebx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 6ULL);
x86_l_5cfb:
	/* 0x5cfb: jne    4d78 <generic_sleepable_preload+0x4d78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5cfb, 0x4d78, x86_l_4d78);
x86_l_5d01:
	/* 0x5d01: jmp    5c3a <generic_sleepable_preload+0x5c3a> */
	X86_SIM_X86_JMP(0x5d01, 0x5c3a, x86_l_5c3a);
x86_l_5d06:
	/* 0x5d06: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d09:
	/* 0x5d09: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d0e:
	/* 0x5d0e: jmp    1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JMP(0x5d0e, 0x1d08, x86_l_1d08);
x86_l_5d13:
	/* 0x5d13: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d16:
	/* 0x5d16: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d1b:
	/* 0x5d1b: jmp    1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JMP(0x5d1b, 0x1dc9, x86_l_1dc9);
x86_l_5d20:
	/* 0x5d20: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d23:
	/* 0x5d23: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d28:
	/* 0x5d28: jmp    2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JMP(0x5d28, 0x2caf, x86_l_2caf);
x86_l_5d2d:
	/* 0x5d2d: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d30:
	/* 0x5d30: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d35:
	/* 0x5d35: jmp    2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JMP(0x5d35, 0x2d70, x86_l_2d70);
x86_l_5d3a:
	/* 0x5d3a: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d3d:
	/* 0x5d3d: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d42:
	/* 0x5d42: jmp    3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JMP(0x5d42, 0x3c57, x86_l_3c57);
x86_l_5d47:
	/* 0x5d47: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d4a:
	/* 0x5d4a: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d4f:
	/* 0x5d4f: jmp    3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JMP(0x5d4f, 0x3d18, x86_l_3d18);
x86_l_5d54:
	/* 0x5d54: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d57:
	/* 0x5d57: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d5c:
	/* 0x5d5c: jmp    4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JMP(0x5d5c, 0x4bff, x86_l_4bff);
x86_l_5d61:
	/* 0x5d61: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d64:
	/* 0x5d64: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d69:
	/* 0x5d69: jmp    4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JMP(0x5d69, 0x4cc0, x86_l_4cc0);
x86_l_5d6e:
	/* 0x5d6e: mov    r12d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 9ULL);
x86_l_5d74:
	/* 0x5d74: jmp    5b71 <generic_sleepable_preload+0x5b71> */
	X86_SIM_X86_JMP(0x5d74, 0x5b71, x86_l_5b71);
x86_l_5d79:
	/* 0x5d79: mov    r12d,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 9ULL);
x86_l_5d7f:
	/* 0x5d7f: jmp    5c2e <generic_sleepable_preload+0x5c2e> */
	X86_SIM_X86_JMP(0x5d7f, 0x5c2e, x86_l_5c2e);
x86_l_5d84:
	/* 0x5d84: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d87:
	/* 0x5d87: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d8c:
	/* 0x5d8c: jmp    5e84 <generic_sleepable_preload+0x5e84> */
	X86_SIM_X86_JMP(0x5d8c, 0x5e84, x86_l_5e84);
x86_l_5d91:
	/* 0x5d91: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d94:
	/* 0x5d94: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5d99:
	/* 0x5d99: jmp    5e99 <generic_sleepable_preload+0x5e99> */
	X86_SIM_X86_JMP(0x5d99, 0x5e99, x86_l_5e99);
x86_l_5d9e:
	/* 0x5d9e: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5da1:
	/* 0x5da1: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5da6:
	/* 0x5da6: jmp    5eae <generic_sleepable_preload+0x5eae> */
	X86_SIM_X86_JMP(0x5da6, 0x5eae, x86_l_5eae);
x86_l_5dab:
	/* 0x5dab: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5dae:
	/* 0x5dae: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5db3:
	/* 0x5db3: jmp    5ec3 <generic_sleepable_preload+0x5ec3> */
	X86_SIM_X86_JMP(0x5db3, 0x5ec3, x86_l_5ec3);
x86_l_5db8:
	/* 0x5db8: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5dbb:
	/* 0x5dbb: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5dc0:
	/* 0x5dc0: jmp    5ed8 <generic_sleepable_preload+0x5ed8> */
	X86_SIM_X86_JMP(0x5dc0, 0x5ed8, x86_l_5ed8);
x86_l_5dc5:
	/* 0x5dc5: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5dc8:
	/* 0x5dc8: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5dcd:
	/* 0x5dcd: jmp    5eed <generic_sleepable_preload+0x5eed> */
	X86_SIM_X86_JMP(0x5dcd, 0x5eed, x86_l_5eed);
x86_l_5dd2:
	/* 0x5dd2: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5dd5:
	/* 0x5dd5: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5dda:
	/* 0x5dda: jmp    5f02 <generic_sleepable_preload+0x5f02> */
	X86_SIM_X86_JMP(0x5dda, 0x5f02, x86_l_5f02);
x86_l_5ddf:
	/* 0x5ddf: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5de2:
	/* 0x5de2: mov    ebx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 8ULL);
x86_l_5de7:
	/* 0x5de7: jmp    5f17 <generic_sleepable_preload+0x5f17> */
	X86_SIM_X86_JMP(0x5de7, 0x5f17, x86_l_5f17);
x86_l_5dec:
	/* 0x5dec: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5df1:
	/* 0x5df1: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5df4:
	/* 0x5df4: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5df9:
	/* 0x5df9: jmp    1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JMP(0x5df9, 0x1d08, x86_l_1d08);
x86_l_5dfe:
	/* 0x5dfe: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e03:
	/* 0x5e03: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e06:
	/* 0x5e06: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e0b:
	/* 0x5e0b: jmp    1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JMP(0x5e0b, 0x1dc9, x86_l_1dc9);
x86_l_5e10:
	/* 0x5e10: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e15:
	/* 0x5e15: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e18:
	/* 0x5e18: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e1d:
	/* 0x5e1d: jmp    2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JMP(0x5e1d, 0x2caf, x86_l_2caf);
x86_l_5e22:
	/* 0x5e22: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e27:
	/* 0x5e27: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e2a:
	/* 0x5e2a: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e2f:
	/* 0x5e2f: jmp    2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JMP(0x5e2f, 0x2d70, x86_l_2d70);
x86_l_5e34:
	/* 0x5e34: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e39:
	/* 0x5e39: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e3c:
	/* 0x5e3c: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e41:
	/* 0x5e41: jmp    3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JMP(0x5e41, 0x3c57, x86_l_3c57);
x86_l_5e46:
	/* 0x5e46: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e4b:
	/* 0x5e4b: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e4e:
	/* 0x5e4e: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e53:
	/* 0x5e53: jmp    3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JMP(0x5e53, 0x3d18, x86_l_3d18);
x86_l_5e58:
	/* 0x5e58: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e5d:
	/* 0x5e5d: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e60:
	/* 0x5e60: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e65:
	/* 0x5e65: jmp    4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JMP(0x5e65, 0x4bff, x86_l_4bff);
x86_l_5e6a:
	/* 0x5e6a: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e6f:
	/* 0x5e6f: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e72:
	/* 0x5e72: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e77:
	/* 0x5e77: jmp    4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JMP(0x5e77, 0x4cc0, x86_l_4cc0);
x86_l_5e7c:
	/* 0x5e7c: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e81:
	/* 0x5e81: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e84:
	/* 0x5e84: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e89:
	/* 0x5e89: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5e8c:
	/* 0x5e8c: jmp    1d08 <generic_sleepable_preload+0x1d08> */
	X86_SIM_X86_JMP(0x5e8c, 0x1d08, x86_l_1d08);
x86_l_5e91:
	/* 0x5e91: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5e96:
	/* 0x5e96: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5e99:
	/* 0x5e99: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e9e:
	/* 0x5e9e: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5ea1:
	/* 0x5ea1: jmp    1dc9 <generic_sleepable_preload+0x1dc9> */
	X86_SIM_X86_JMP(0x5ea1, 0x1dc9, x86_l_1dc9);
x86_l_5ea6:
	/* 0x5ea6: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5eab:
	/* 0x5eab: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5eae:
	/* 0x5eae: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5eb3:
	/* 0x5eb3: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5eb6:
	/* 0x5eb6: jmp    2caf <generic_sleepable_preload+0x2caf> */
	X86_SIM_X86_JMP(0x5eb6, 0x2caf, x86_l_2caf);
x86_l_5ebb:
	/* 0x5ebb: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5ec0:
	/* 0x5ec0: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5ec3:
	/* 0x5ec3: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5ec8:
	/* 0x5ec8: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5ecb:
	/* 0x5ecb: jmp    2d70 <generic_sleepable_preload+0x2d70> */
	X86_SIM_X86_JMP(0x5ecb, 0x2d70, x86_l_2d70);
x86_l_5ed0:
	/* 0x5ed0: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5ed5:
	/* 0x5ed5: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5ed8:
	/* 0x5ed8: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5edd:
	/* 0x5edd: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5ee0:
	/* 0x5ee0: jmp    3c57 <generic_sleepable_preload+0x3c57> */
	X86_SIM_X86_JMP(0x5ee0, 0x3c57, x86_l_3c57);
x86_l_5ee5:
	/* 0x5ee5: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5eea:
	/* 0x5eea: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5eed:
	/* 0x5eed: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5ef2:
	/* 0x5ef2: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5ef5:
	/* 0x5ef5: jmp    3d18 <generic_sleepable_preload+0x3d18> */
	X86_SIM_X86_JMP(0x5ef5, 0x3d18, x86_l_3d18);
x86_l_5efa:
	/* 0x5efa: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5eff:
	/* 0x5eff: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5f02:
	/* 0x5f02: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5f07:
	/* 0x5f07: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5f0a:
	/* 0x5f0a: jmp    4bff <generic_sleepable_preload+0x4bff> */
	X86_SIM_X86_JMP(0x5f0a, 0x4bff, x86_l_4bff);
x86_l_5f0f:
	/* 0x5f0f: mov    ebx,0x9 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 9ULL);
x86_l_5f14:
	/* 0x5f14: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5f17:
	/* 0x5f17: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5f1c:
	/* 0x5f1c: mov    r14,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R15, X86_WIDTH_64);
x86_l_5f1f:
	/* 0x5f1f: jmp    4cc0 <generic_sleepable_preload+0x4cc0> */
	X86_SIM_X86_JMP(0x5f1f, 0x4cc0, x86_l_4cc0);
x86_l_5f24:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
