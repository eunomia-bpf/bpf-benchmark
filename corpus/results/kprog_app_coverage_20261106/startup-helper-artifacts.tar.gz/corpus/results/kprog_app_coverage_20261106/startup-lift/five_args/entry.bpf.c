#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("socket")
int five_args_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: mov    eax,0xa5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 165ULL);
x86_l_5:
	/* 0x5: jmp    a <bpf_main+0xa> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_a:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
