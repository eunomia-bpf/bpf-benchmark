; ModuleID = '/workspaces/repository/corpus/results/kprog_app_coverage_20261106/startup-lift/object_coarse/native.ll'
source_filename = "bpf-source"

define i64 @bpf_main(ptr %0) local_unnamed_addr {
setupBlock:
  %1 = ptrtoint ptr %0 to i64
  %2 = tail call i64 @bpf_ktime_get_coarse_ns(i64 %1, i64 0, i64 0, i64 0, i64 0)
  ret i64 %2
}

declare i64 @bpf_ktime_get_coarse_ns(i64, i64, i64, i64, i64) local_unnamed_addr
