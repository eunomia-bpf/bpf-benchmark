#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("socket")
int coarse_call_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_3:
	/* 0x3: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5:
	/* 0x5: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_7:
	/* 0x7: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a:
	/* 0xa: call   f <bpf_main+0xf> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_coarse_ns);
x86_l_f:
	/* 0xf: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: jmp    15 <bpf_main+0x15> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_15:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
