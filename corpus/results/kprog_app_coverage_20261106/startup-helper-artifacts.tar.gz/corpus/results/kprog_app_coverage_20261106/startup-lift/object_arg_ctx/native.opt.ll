; ModuleID = '/workspaces/repository/corpus/results/kprog_app_coverage_20261106/startup-lift/object_arg_ctx/native.ll'
source_filename = "bpf-source"

define i64 @bpf_main(ptr %0) local_unnamed_addr {
setupBlock:
  %1 = ptrtoint ptr %0 to i64
  %2 = tail call i64 @bpf_get_func_ip(i64 %1, i64 0, i64 0, i64 0, i64 0)
  ret i64 %2
}

define i64 @__llvmbpf_pseudo_call_pc_00000002(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4) local_unnamed_addr {
setupBlock:
  %5 = tail call i64 @bpf_get_func_ip(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4)
  ret i64 %5
}

declare i64 @bpf_get_func_ip(i64, i64, i64, i64, i64) local_unnamed_addr
