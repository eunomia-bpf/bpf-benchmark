; ModuleID = '/workspaces/repository/corpus/results/kprog_app_coverage_20261106/bpf-lift/clock.ll'
source_filename = "bpf-jit"

declare i64 @bpf_ktime_get_ns() local_unnamed_addr

define i64 @bpf_main(ptr nocapture readnone %0) local_unnamed_addr {
setupBlock:
  %1 = tail call i64 @bpf_ktime_get_ns()
  %.not = icmp ne i64 %1, 0
  %spec.store.select = zext i1 %.not to i64
  ret i64 %spec.store.select
}
