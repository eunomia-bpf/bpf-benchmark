#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int runtime_probe(struct xdp_md *ctx) {
#ifdef CLOCK
    return bpf_ktime_get_ns()!=0;
#else
    return VALUE;
#endif
}
char LICENSE[] SEC("license")="GPL";
