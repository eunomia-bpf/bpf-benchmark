; ModuleID = 'bpf-jit'
source_filename = "bpf-jit"

declare i64 @bpf_ktime_get_ns()

define i64 @bpf_main(ptr %0) {
setupBlock:
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 0, ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  store i64 0, ptr %r4, align 4
  store i64 0, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 1
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %0, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  %1 = call i64 @bpf_ktime_get_ns()
  store i64 %1, ptr %r0, align 4
  br label %bb_inst_1

bb_inst_1:                                        ; preds = %bb_inst_0
  %2 = load i64, ptr %r0, align 4
  store i64 %2, ptr %r1, align 4
  store i64 1, ptr %r0, align 4
  %3 = load i64, ptr %r1, align 4
  %4 = icmp ne i64 %3, 0
  br i1 %4, label %bb_inst_5, label %bb_inst_4

bb_inst_4:                                        ; preds = %bb_inst_1
  store i64 0, ptr %r0, align 4
  br label %bb_inst_5

bb_inst_5:                                        ; preds = %bb_inst_4, %bb_inst_1
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_5
  %5 = load i64, ptr %r0, align 4
  ret i64 %5
}
