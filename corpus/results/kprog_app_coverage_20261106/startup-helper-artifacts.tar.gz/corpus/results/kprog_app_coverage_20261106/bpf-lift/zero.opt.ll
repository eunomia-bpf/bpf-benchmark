; ModuleID = '/workspaces/repository/corpus/results/kprog_app_coverage_20261106/bpf-lift/zero.ll'
source_filename = "bpf-jit"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @bpf_main(ptr nocapture readnone %0) local_unnamed_addr #0 {
setupBlock:
  ret i64 0
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
