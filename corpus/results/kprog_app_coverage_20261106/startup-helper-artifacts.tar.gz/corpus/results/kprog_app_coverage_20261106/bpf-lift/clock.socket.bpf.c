#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("socket")
int clock_socket_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: call   6 <bpf_main+0x6> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_6:
	/* 0x6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_8:
	/* 0x8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b:
	/* 0xb: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_e:
	/* 0xe: mov    rax,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_11:
	/* 0x11: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_12:
	/* 0x12: jmp    17 <bpf_main+0x17> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_17:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
