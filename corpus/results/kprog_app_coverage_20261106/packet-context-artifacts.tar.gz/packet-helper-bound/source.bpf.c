#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int packet_ctx(struct xdp_md *ctx) {
 if (bpf_xdp_adjust_head(ctx,0)) return 0;
 unsigned long long *data=(void *)(long)ctx->data;
 if ((void *)(data+1)>(void *)(long)ctx->data_end) return 0;
 *data=42;return XDP_PASS;
}
char LICENSE[] SEC("license")="GPL";
