#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int packet_ctx_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_4:
	/* 0x4: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6:
	/* 0x6: call   b <packet_ctx+0xb> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_xdp_adjust_head);
x86_l_b:
	/* 0xb: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_e:
	/* 0xe: jne    2b <packet_ctx+0x2b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe, 0x2b, x86_l_2b);
x86_l_10:
	/* 0x10: mov    rdi,QWORD PTR [rbx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13:
	/* 0x13: lea    rcx,[rdi+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17:
	/* 0x17: cmp    rcx,QWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_1b:
	/* 0x1b: ja     2b <packet_ctx+0x2b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1b, 0x2b, x86_l_2b);
x86_l_1d:
	/* 0x1d: mov    QWORD PTR [rdi],0x2a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 42ULL);
x86_l_24:
	/* 0x24: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_29:
	/* 0x29: jmp    2d <packet_ctx+0x2d> */
	X86_SIM_X86_JMP(0x29, 0x2d, x86_l_2d);
x86_l_2b:
	/* 0x2b: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d:
	/* 0x2d: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2e:
	/* 0x2e: jmp    33 <packet_ctx+0x33> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_33:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
