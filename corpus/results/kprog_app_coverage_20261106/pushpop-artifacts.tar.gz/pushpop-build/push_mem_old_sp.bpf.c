#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_ENABLE_STACK_DEEP 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int push_mem_old_sp_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_4:
	/* 0x4: mov    QWORD PTR [rsp],0x23 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 35ULL);
x86_l_c:
	/* 0xc: mov    QWORD PTR [rsp+0x8],0x99 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738521ULL);
x86_l_15:
	/* 0x15: push   QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_PUSHPOP_AUX_MEM), 8ULL);
x86_l_19:
	/* 0x19: pop    rax */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a:
	/* 0x1a: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1e:
	/* 0x1e: ret */
	X86_SIM_X86_RET();
x86_l_1f:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
