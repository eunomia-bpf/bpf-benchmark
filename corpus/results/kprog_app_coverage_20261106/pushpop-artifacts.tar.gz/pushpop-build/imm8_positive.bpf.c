#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int imm8_positive_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   0x7f */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, X86_PUSHPOP_AUX_IMM, 127ULL);
x86_l_2:
	/* 0x2: pop    rax */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: ret */
	X86_SIM_X86_RET();
x86_l_4:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
