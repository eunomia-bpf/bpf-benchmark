#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int imm16_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_5:
	/* 0x5: pushw  0xffff */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_16, X86_PUSHPOP_AUX_IMM, 65535ULL);
x86_l_8:
	/* 0x8: pop    ax */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 0);
x86_l_a:
	/* 0xa: ret */
	X86_SIM_X86_RET();
x86_l_b:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
