#include <linux/bpf.h>
#include <stdint.h>
#include <stdio.h>
uint64_t imm8_negative_native(void);
int imm8_negative_x86_sim_xdp(struct xdp_md *);
uint64_t imm8_positive_native(void);
int imm8_positive_x86_sim_xdp(struct xdp_md *);
uint64_t imm32_negative_native(void);
int imm32_negative_x86_sim_xdp(struct xdp_md *);
uint64_t imm32_positive_native(void);
int imm32_positive_x86_sim_xdp(struct xdp_md *);
uint64_t imm16_native(void);
int imm16_x86_sim_xdp(struct xdp_md *);
uint64_t push_mem_old_sp_native(void);
int push_mem_old_sp_x86_sim_xdp(struct xdp_md *);
uint64_t pop_mem_new_sp_native(void);
int pop_mem_new_sp_x86_sim_xdp(struct xdp_md *);
uint64_t pop_mem16_native(void);
int pop_mem16_x86_sim_xdp(struct xdp_md *);
uint64_t pop_mem_index_native(void);
int pop_mem_index_x86_sim_xdp(struct xdp_md *);
int main(void) { struct xdp_md ctx={0};unsigned failures=0;
{ uint32_t n=imm8_negative_native(),s=imm8_negative_x86_sim_xdp(&ctx);
printf("imm8_negative native=%u simulator=%u expected=%u\n",n,s,4294967295U);
failures += n!=4294967295U || s!=n; }
{ uint32_t n=imm8_positive_native(),s=imm8_positive_x86_sim_xdp(&ctx);
printf("imm8_positive native=%u simulator=%u expected=%u\n",n,s,127U);
failures += n!=127U || s!=n; }
{ uint32_t n=imm32_negative_native(),s=imm32_negative_x86_sim_xdp(&ctx);
printf("imm32_negative native=%u simulator=%u expected=%u\n",n,s,4294967295U);
failures += n!=4294967295U || s!=n; }
{ uint32_t n=imm32_positive_native(),s=imm32_positive_x86_sim_xdp(&ctx);
printf("imm32_positive native=%u simulator=%u expected=%u\n",n,s,305419896U);
failures += n!=305419896U || s!=n; }
{ uint32_t n=imm16_native(),s=imm16_x86_sim_xdp(&ctx);
printf("imm16 native=%u simulator=%u expected=%u\n",n,s,65535U);
failures += n!=65535U || s!=n; }
{ uint32_t n=push_mem_old_sp_native(),s=push_mem_old_sp_x86_sim_xdp(&ctx);
printf("push_mem_old_sp native=%u simulator=%u expected=%u\n",n,s,153U);
failures += n!=153U || s!=n; }
{ uint32_t n=pop_mem_new_sp_native(),s=pop_mem_new_sp_x86_sim_xdp(&ctx);
printf("pop_mem_new_sp native=%u simulator=%u expected=%u\n",n,s,68U);
failures += n!=68U || s!=n; }
{ uint32_t n=pop_mem16_native(),s=pop_mem16_x86_sim_xdp(&ctx);
printf("pop_mem16 native=%u simulator=%u expected=%u\n",n,s,4660U);
failures += n!=4660U || s!=n; }
{ uint32_t n=pop_mem_index_native(),s=pop_mem_index_x86_sim_xdp(&ctx);
printf("pop_mem_index native=%u simulator=%u expected=%u\n",n,s,85U);
failures += n!=85U || s!=n; }
return failures!=0;}
