#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/corpus/results/kprog_app_coverage_20261106/pushpop-before/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int push_immediate_unsafe_arm_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   0x1 */
	X86_SIM_L_EXEC_PUSH(X86_REG_NONE, X86_WIDTH_64);
x86_l_2:
	/* 0x2: pop    rax */
	X86_SIM_L_EXEC_POP(X86_RAX, X86_WIDTH_64);
x86_l_3:
	/* 0x3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_6:
	/* 0x6: je     10 <entry+0x10> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6, 0x10, x86_l_10);
x86_l_8:
	/* 0x8: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c:
	/* 0xc: movzx  eax,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_f:
	/* 0xf: ret */
	X86_SIM_X86_RET();
x86_l_10:
	/* 0x10: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_15:
	/* 0x15: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
