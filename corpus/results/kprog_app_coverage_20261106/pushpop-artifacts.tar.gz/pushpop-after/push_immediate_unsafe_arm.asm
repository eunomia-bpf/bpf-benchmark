
/workspaces/repository/corpus/results/kprog_app_coverage_20261106/pushpop-after/push_immediate_unsafe_arm.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	6a 01                                           	push   0x1
   2:	58                                              	pop    rax
   3:	48 85 c0                                        	test   rax,rax
   6:	74 08                                           	je     10 <entry+0x10>
   8:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
   c:	0f b6 00                                        	movzx  eax,BYTE PTR [rax]
   f:	c3                                              	ret
  10:	b8 02 00 00 00                                  	mov    eax,0x2
  15:	c3                                              	ret
