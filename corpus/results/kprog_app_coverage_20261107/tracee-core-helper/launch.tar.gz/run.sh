set -eu
D=/workspaces/.agent-state/kprog-lanes/C/native-core-helper-candidate
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/C/native-core-helper-candidate/Makefile corpus IMAGE=bpf-benchmark/kprog-native-core:c-20261107 STATE="$D" CPUS=20-23 VM_CPUS=8 VM_MEM=12G APPS=tracee/monitor SAMPLES=1 WORKLOAD_DURATION=2
