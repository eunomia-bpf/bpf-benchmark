set -eu
D=/workspaces/.agent-state/kprog-lanes/C/tracee-verified-startup
trap 'echo $? > "$D/check.exit"' EXIT
make -f "$D/Makefile" check
