set -eu
D=/workspaces/.agent-state/kprog-lanes/C/lea-production-integration
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
python3 kprog/formal/tools/generate_x86_mem_offset_spec.py --check
cc -O2 -g -fsanitize=undefined -fno-sanitize-recover=undefined -Ikprog/formal -Ikprog/x86 -Ivendor/repos/bcc/src/cc/libbpf/src kprog/formal/oracles/test_x86_mem_offset_route_host.c -o "$D/mem-offset"
"$D/mem-offset"
python3 kprog/formal/tools/check_x86_flag_definedness.py
