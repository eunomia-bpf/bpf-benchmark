from pathlib import Path
import hashlib, shutil, subprocess, traceback, json
lane=Path('/workspaces/.agent-state/kprog-lanes/C')
root=Path('/workspaces/repository')
sha=(lane/'sp-entry-source/base-head.txt').read_text().strip()
out=lane/'source-check-sp-entry-v2'
assert not out.exists(),out
rc=1
try:
    tree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',sha],cwd=root)
    chosen=[]
    for entry in tree.split(b'\0'):
        if not entry: continue
        meta,name=entry.split(b'\t',1)
        mode,kind,obj=meta.decode().split()
        n=name.decode(); path=Path(n); parts=path.parts
        needed=(parts[:2]==('kprog','formal') or parts[:3]==('kinsn','module','include') or n=='kprog/helper_abi.py' or parts[:3]==('kprog','test','include') or (len(parts)==3 and parts[0]=='kprog' and parts[1] in {'x86','arm64'} and path.suffix in {'.h','.py','.json'}) or (len(parts)==4 and parts[0]=='kprog' and parts[1] in {'x86','arm64'} and parts[2]=='micro-prog' and path.suffix=='.py') or parts[:4]==('kprog','x86','native_lab','native_link'))
        if not needed or kind!='blob' or any(p in {'build','target','results','.lake','__pycache__'} or p.startswith('build-') for p in parts): continue
        chosen.append((n,obj))
    objects=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join(obj+'\n' for _,obj in chosen).encode(),stdout=subprocess.PIPE,check=True).stdout
    pos=0;manifest=[]
    for n,obj in chosen:
        end=objects.index(b'\n',pos); header=objects[pos:end].decode().split(); assert header[:2]==[obj,'blob']
        size=int(header[2]);data=objects[end+1:end+1+size];assert len(data)==size
        if (lane/'sp-entry-source'/n).is_file():data=(lane/'sp-entry-source'/n).read_bytes()
        pos=end+size+2
        target=out/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        manifest.append(hashlib.sha256(data).hexdigest()+'  '+n+'\n')
    assert pos==len(objects)
    (out/'vendor').mkdir(parents=True)
    for name in ('libbpf','linux-framework'): (out/'vendor'/name).symlink_to(root/'vendor'/name,target_is_directory=True)
    shutil.copytree(root/'kprog/formal/.lake',out/'kprog/formal/.lake')
    shutil.copytree(root/'kprog/formal/build/native-link',out/'kprog/formal/build/native-link')
    (lane/'sp-entry-v2-full.sources').write_text(''.join(manifest))
    (lane/'sp-entry-v2-full.head').write_text(sha+'\n')
    (lane/'sp-entry-v2-full.state').write_text('running '+sha+'\n')
    print('Frozen',len(chosen),'candidate files at',sha,flush=True)
    with (lane/'sp-entry-v2-full.log').open('w') as log:
        rc=subprocess.run(['taskset','-c','12-15','make','-C',str(out/'kprog/formal'),'check'],cwd=out,stdout=log,stderr=subprocess.STDOUT).returncode
except Exception:
    traceback.print_exc()
finally:
    if out.exists():
        assert out.resolve().parent==lane.resolve() and out.name=='source-check-sp-entry-v2'
        shutil.rmtree(out)
    (lane/'sp-entry-v2-full.exit').write_text(str(rc)+'\n')
    (lane/'sp-entry-v2-full.state').write_text('finished '+str(rc)+' '+sha+'\n')
    with (lane.parent/'COORDINATION.md').open('a') as f:
        f.write('\n- C private direct-SP numeric candidate FULL ended rc='+str(rc)+' at '+sha[:9]+'. Sole FULL slot RELEASED; temporary source/cache export deleted immediately, hashes/log/exit retained at V/sp-entry-v2-full.*. No ROOT/source/sharedindex writes.\n')
    print('Full finished',rc,'temporary export deleted',flush=True)
