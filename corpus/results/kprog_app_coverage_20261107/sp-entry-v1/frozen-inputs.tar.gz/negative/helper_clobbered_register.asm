
/workspaces/.agent-state/kprog-lanes/C/sp-entry-source/negative/helper_clobbered_register.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	53                                              	push   rbx
   1:	48 89 fb                                        	mov    rbx,rdi
   4:	31 f6                                           	xor    esi,esi
   6:	e8 00 00 00 00                                  	call   b <entry+0xb>
			7: R_X86_64_PLT32	bpf_get_current_uid_gid-0x4
   b:	48 85 f6                                        	test   rsi,rsi
   e:	74 09                                           	je     19 <entry+0x19>
  10:	48 8b 43 08                                     	mov    rax,QWORD PTR [rbx+0x8]
  14:	0f b6 00                                        	movzx  eax,BYTE PTR [rax]
  17:	eb 05                                           	jmp    1e <entry+0x1e>
  19:	b8 02 00 00 00                                  	mov    eax,0x2
  1e:	5b                                              	pop    rbx
  1f:	c3                                              	ret
