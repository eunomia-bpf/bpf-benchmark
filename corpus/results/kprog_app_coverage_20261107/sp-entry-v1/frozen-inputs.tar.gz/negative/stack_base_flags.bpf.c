#include "/workspaces/.agent-state/kprog-lanes/C/sp-entry-source/negative/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int stack_base_flags_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_5:
	/* 0x5: sub    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 8ULL);
x86_l_9:
	/* 0x9: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_d:
	/* 0xd: je     13 <entry+0x13> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd, 0x13, x86_l_13);
x86_l_f:
	/* 0xf: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11:
	/* 0x11: mov    eax,DWORD PTR [rcx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13:
	/* 0x13: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
