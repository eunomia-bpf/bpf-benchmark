set -eu
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/micro-load-width
cleanup() {
 rc=$?
 for path in "$D/var-tmp/bpf-benchmark-docker.img" "$D/runtime.image.tar"; do
  if test -f "$path"; then if fuser -s "$path"; then echo "retaining open: $path"; else rm -f -- "$path"; fi; fi
 done
 echo "$rc" > "$D/run.exit"
}
trap cleanup EXIT
install -d "$D/var-tmp"
docker save -o "$D/runtime.image.tar" bpf-benchmark/kprog-micro-trusted:c-20261107
vng --run /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir "$D" --rwdir /var/tmp="$D/var-tmp" --overlay-rwdir /tmp --overlay-rwdir /run --overlay-rwdir /usr/local --disable-monitor --cpus 4 --memory 8G --append 'loglevel=4 panic=30 oops=panic' --exec 'set +e; PATH=/usr/lib/llvm-18/bin:$PATH make __runtime-vm-micro PLATFORM=kvm ARCH=x86 HOST_KINSN_DIR_X86=/workspaces/repository/kprog/tv/build-x86/corpus-modules RUNTIME_CONTAINER_IMAGE=bpf-benchmark/kprog-micro-trusted:c-20261107 RUNTIME_IMAGE_TAR=/workspaces/.agent-state/kprog-lanes/C/micro-load-width/runtime.image.tar RUN_TOKEN=c-load-width-pure-20261107 RUNTIMES="kernel native_proof" SUITE=micro/config/micro_pure_jit.yaml SAMPLES=1 WARMUPS=0 INNER_REPEAT=1; rc=$?; dmesg > /workspaces/.agent-state/kprog-lanes/C/micro-load-width/kernel.log; cat /proc/meminfo > /workspaces/.agent-state/kprog-lanes/C/micro-load-width/meminfo.txt; exit "$rc"'
