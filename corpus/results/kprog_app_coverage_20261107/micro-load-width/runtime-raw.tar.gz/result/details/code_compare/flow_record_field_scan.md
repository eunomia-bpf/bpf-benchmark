# flow_record_field_scan

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <flow_record_field_scan_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <flow_record_field_scan_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <flow_record_field_scan_xdp+0x11>
    111b:	4c 8d 82 10 04 00 00 	lea    r8,[rdx+0x410]
    1122:	49 39 f0             	cmp    r8,rsi
    1125:	77 ea                	ja     1111 <flow_record_field_scan_xdp+0x11>
    1127:	83 3f 20             	cmp    DWORD PTR [rdi],0x20
    112a:	75 e5                	jne    1111 <flow_record_field_scan_xdp+0x11>
    112c:	83 7a 0c 20          	cmp    DWORD PTR [rdx+0xc],0x20
    1130:	75 df                	jne    1111 <flow_record_field_scan_xdp+0x11>
    1132:	41 56                	push   r14
    1134:	53                   	push   rbx
    1135:	49 b8 15 7c 4a 7f b9 	movabs r8,0x9e3779b97f4a7c15
    113c:	79 37 9e 
    113f:	31 c0                	xor    eax,eax
    1141:	31 f6                	xor    esi,esi
    1143:	eb 51                	jmp    1196 <flow_record_field_scan_xdp+0x96>
    1145:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    114c:	00 00 00 00 
    1150:	41 89 f0             	mov    r8d,esi
    1153:	41 80 e0 07          	and    r8b,0x7
    1157:	c4 42 bb f7 c2       	shrx   r8,r10,r8
    115c:	4d 31 c1             	xor    r9,r8
    115f:	4d 01 d9             	add    r9,r11
    1162:	41 89 c0             	mov    r8d,eax
    1165:	41 80 e0 18          	and    r8b,0x18
    1169:	c4 62 b9 f7 c7       	shlx   r8,rdi,r8
    116e:	4d 31 c8             	xor    r8,r9
    1171:	40 80 e7 07          	and    dil,0x7
    1175:	44 8d 4f 01          	lea    r9d,[rdi+0x1]
    1179:	c4 c2 b1 f7 d8       	shlx   rbx,r8,r9
    117e:	40 f6 d7             	not    dil
    1181:	c4 42 c3 f7 c0       	shrx   r8,r8,rdi
    1186:	49 09 d8             	or     r8,rbx
    1189:	48 ff c6             	inc    rsi
    118c:	48 83 c0 08          	add    rax,0x8
    1190:	48 83 fe 20          	cmp    rsi,0x20
    1194:	74 52                	je     11e8 <flow_record_field_scan_xdp+0xe8>
    1196:	4c 8b 54 82 20       	mov    r10,QWORD PTR [rdx+rax*4+0x20]
    119b:	48 8b 5c 82 18       	mov    rbx,QWORD PTR [rdx+rax*4+0x18]
    11a0:	4c 01 d3             	add    rbx,r10
    11a3:	8b 7c 82 28          	mov    edi,DWORD PTR [rdx+rax*4+0x28]
    11a7:	48 c1 e7 20          	shl    rdi,0x20
    11ab:	44 8b 4c 82 2c       	mov    r9d,DWORD PTR [rdx+rax*4+0x2c]
    11b0:	49 09 f9             	or     r9,rdi
    11b3:	8b 7c 82 10          	mov    edi,DWORD PTR [rdx+rax*4+0x10]
    11b7:	49 89 fb             	mov    r11,rdi
    11ba:	49 c1 e3 10          	shl    r11,0x10
    11be:	44 0f b7 74 82 14    	movzx  r14d,WORD PTR [rdx+rax*4+0x14]
    11c4:	4d 09 f3             	or     r11,r14
    11c7:	49 31 db             	xor    r11,rbx
    11ca:	4d 01 c3             	add    r11,r8
    11cd:	41 f6 c6 01          	test   r14b,0x1
    11d1:	0f 84 79 ff ff ff    	je     1150 <flow_record_field_scan_xdp+0x50>
    11d7:	44 0f b7 44 82 16    	movzx  r8d,WORD PTR [rdx+rax*4+0x16]
    11dd:	4d 01 c1             	add    r9,r8
    11e0:	4d 31 d9             	xor    r9,r11
    11e3:	e9 7a ff ff ff       	jmp    1162 <flow_record_field_scan_xdp+0x62>
    11e8:	44 88 01             	mov    BYTE PTR [rcx],r8b
    11eb:	88 79 01             	mov    BYTE PTR [rcx+0x1],bh
    11ee:	89 d8                	mov    eax,ebx
    11f0:	c1 e8 10             	shr    eax,0x10
    11f3:	88 41 02             	mov    BYTE PTR [rcx+0x2],al
    11f6:	89 d8                	mov    eax,ebx
    11f8:	c1 e8 18             	shr    eax,0x18
    11fb:	88 41 03             	mov    BYTE PTR [rcx+0x3],al
    11fe:	48 89 d8             	mov    rax,rbx
    1201:	48 c1 e8 20          	shr    rax,0x20
    1205:	88 41 04             	mov    BYTE PTR [rcx+0x4],al
    1208:	48 89 d8             	mov    rax,rbx
    120b:	48 c1 e8 28          	shr    rax,0x28
    120f:	88 41 05             	mov    BYTE PTR [rcx+0x5],al
    1212:	48 89 d8             	mov    rax,rbx
    1215:	48 c1 e8 30          	shr    rax,0x30
    1219:	88 41 06             	mov    BYTE PTR [rcx+0x6],al
    121c:	48 c1 eb 38          	shr    rbx,0x38
    1220:	88 59 07             	mov    BYTE PTR [rcx+0x7],bl
    1223:	b8 02 00 00 00       	mov    eax,0x2
    1228:	5b                   	pop    rbx
    1229:	41 5e                	pop    r14
    122b:	c3                   	ret

Disassembly of section .fini:

000000000000122c <_fini>:
    122c:	f3 0f 1e fa          	endbr64
    1230:	48 83 ec 08          	sub    rsp,0x8
    1234:	48 83 c4 08          	add    rsp,0x8
    1238:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 10 00 00 00 	sub    rsp,0x10
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	4c 8b 7f 00          	mov    r15,QWORD PTR [rdi+0x0]
  24:	49 39 f7             	cmp    r15,rsi
  27:	0f 87 64 01 00 00    	ja     0x191
  2d:	4c 89 fa             	mov    rdx,r15
  30:	48 83 c2 08          	add    rdx,0x8
  34:	48 39 f2             	cmp    rdx,rsi
  37:	0f 87 54 01 00 00    	ja     0x191
  3d:	4c 89 f9             	mov    rcx,r15
  40:	48 81 c1 10 04 00 00 	add    rcx,0x410
  47:	48 39 f1             	cmp    rcx,rsi
  4a:	0f 87 41 01 00 00    	ja     0x191
  50:	8b 72 00             	mov    esi,DWORD PTR [rdx+0x0]
  53:	48 83 fe 20          	cmp    rsi,0x20
  57:	0f 85 34 01 00 00    	jne    0x191
  5d:	41 8b 77 0c          	mov    esi,DWORD PTR [r15+0xc]
  61:	48 83 fe 20          	cmp    rsi,0x20
  65:	0f 85 26 01 00 00    	jne    0x191
  6b:	48 bb 15 7c 4a 7f b9 	movabs rbx,0x9e3779b97f4a7c15
  72:	79 37 9e 
  75:	31 ff                	xor    edi,edi
  77:	31 d2                	xor    edx,edx
  79:	31 c9                	xor    ecx,ecx
  7b:	4c 89 7d f0          	mov    QWORD PTR [rbp-0x10],r15
  7f:	eb 63                	jmp    0xe4
  81:	48 89 ce             	mov    rsi,rcx
  84:	48 83 e6 07          	and    rsi,0x7
  88:	c4 e2 cb f7 ff       	shrx   rdi,rdi,rsi
  8d:	49 31 f8             	xor    r8,rdi
  90:	4d 01 c5             	add    r13,r8
  93:	4d 89 e8             	mov    r8,r13
  96:	48 89 d7             	mov    rdi,rdx
  99:	48 83 e7 18          	and    rdi,0x18
  9d:	48 89 c6             	mov    rsi,rax
  a0:	c4 e2 c1 f7 f6       	shlx   rsi,rsi,rdi
  a5:	49 31 f0             	xor    r8,rsi
  a8:	48 83 e0 07          	and    rax,0x7
  ac:	48 89 c7             	mov    rdi,rax
  af:	48 83 f7 3f          	xor    rdi,0x3f
  b3:	4c 89 c6             	mov    rsi,r8
  b6:	c4 e2 c3 f7 f6       	shrx   rsi,rsi,rdi
  bb:	48 83 c0 01          	add    rax,0x1
  bf:	c4 42 f9 f7 c0       	shlx   r8,r8,rax
  c4:	48 8b 7d f8          	mov    rdi,QWORD PTR [rbp-0x8]
  c8:	48 83 c7 20          	add    rdi,0x20
  cc:	48 83 c2 08          	add    rdx,0x8
  d0:	4c 89 c3             	mov    rbx,r8
  d3:	48 09 f3             	or     rbx,rsi
  d6:	48 83 c1 01          	add    rcx,0x1
  da:	4c 8b 7d f0          	mov    r15,QWORD PTR [rbp-0x10]
  de:	48 83 f9 20          	cmp    rcx,0x20
  e2:	74 5a                	je     0x13e
  e4:	48 89 7d f8          	mov    QWORD PTR [rbp-0x8],rdi
  e8:	49 01 ff             	add    r15,rdi
  eb:	4d 8b 47 18          	mov    r8,QWORD PTR [r15+0x18]
  ef:	49 8b 7f 20          	mov    rdi,QWORD PTR [r15+0x20]
  f3:	49 89 fe             	mov    r14,rdi
  f6:	4d 01 c6             	add    r14,r8
  f9:	49 0f b7 77 14       	movzx  rsi,WORD PTR [r15+0x14]
  fe:	41 8b 47 10          	mov    eax,DWORD PTR [r15+0x10]
 102:	49 89 c5             	mov    r13,rax
 105:	49 c1 e5 10          	shl    r13,0x10
 109:	49 09 f5             	or     r13,rsi
 10c:	4d 31 f5             	xor    r13,r14
 10f:	49 01 dd             	add    r13,rbx
 112:	41 8b 5f 2c          	mov    ebx,DWORD PTR [r15+0x2c]
 116:	45 8b 47 28          	mov    r8d,DWORD PTR [r15+0x28]
 11a:	49 c1 e0 20          	shl    r8,0x20
 11e:	49 09 d8             	or     r8,rbx
 121:	48 83 e6 01          	and    rsi,0x1
 125:	48 85 f6             	test   rsi,rsi
 128:	0f 84 53 ff ff ff    	je     0x81
 12e:	49 0f b7 7f 16       	movzx  rdi,WORD PTR [r15+0x16]
 133:	49 01 f8             	add    r8,rdi
 136:	4d 31 e8             	xor    r8,r13
 139:	e9 58 ff ff ff       	jmp    0x96
 13e:	41 88 5f 00          	mov    BYTE PTR [r15+0x0],bl
 142:	4c 89 c6             	mov    rsi,r8
 145:	48 c1 ee 38          	shr    rsi,0x38
 149:	41 88 77 07          	mov    BYTE PTR [r15+0x7],sil
 14d:	4c 89 c6             	mov    rsi,r8
 150:	48 c1 ee 30          	shr    rsi,0x30
 154:	41 88 77 06          	mov    BYTE PTR [r15+0x6],sil
 158:	4c 89 c6             	mov    rsi,r8
 15b:	48 c1 ee 28          	shr    rsi,0x28
 15f:	41 88 77 05          	mov    BYTE PTR [r15+0x5],sil
 163:	4c 89 c6             	mov    rsi,r8
 166:	48 c1 ee 20          	shr    rsi,0x20
 16a:	41 88 77 04          	mov    BYTE PTR [r15+0x4],sil
 16e:	4c 89 c6             	mov    rsi,r8
 171:	48 c1 ee 18          	shr    rsi,0x18
 175:	41 88 77 03          	mov    BYTE PTR [r15+0x3],sil
 179:	4c 89 c6             	mov    rsi,r8
 17c:	48 c1 ee 10          	shr    rsi,0x10
 180:	41 88 77 02          	mov    BYTE PTR [r15+0x2],sil
 184:	49 c1 e8 08          	shr    r8,0x8
 188:	45 88 47 01          	mov    BYTE PTR [r15+0x1],r8b
 18c:	b8 02 00 00 00       	mov    eax,0x2
 191:	41 5f                	pop    r15
 193:	41 5e                	pop    r14
 195:	41 5d                	pop    r13
 197:	5b                   	pop    rbx
 198:	c9                   	leave
 199:	e9 b2 2e c1 ce       	jmp    0xffffffffcec13050
```

## llvmbpf JIT ASM
```asm
not captured
```
