#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 256
#include <stdint.h>
#include <stdio.h>
#include "x86_sim_local_bpf.h"
int main(void){
 const uint64_t bases[]={0,0x7ffe42c11950ULL,0xffff888000100000ULL,0x80000000fffffff0ULL};unsigned long total=0,bad=0;
 for(unsigned k=0;k<4;k++)for(unsigned b=0;b<4;b++)for(unsigned i=0;i<1024;i++){
  int64_t offset=-(int64_t)(16+(i%8)*16);uint64_t source=bases[b]+offset,native;
  if(k==0)__asm__ volatile("movq %1,%0":"=r"(native):"r"(source));
  if(k==1)__asm__ volatile("movl %k1,%k0":"=r"(native):"r"(source));
  if(k==2)__asm__ volatile("leaq 16(%1),%0":"=r"(native):"r"(source));
  if(k==3)__asm__ volatile("leal 16(%1),%k0":"=r"(native):"r"(source));
  X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__x86_native_stack_base=bases[b];__x86_rsp.ptr=(void *)(long)offset;
  if(k==0)X86_SIM_L_EXEC_MOV_REG_AUX(X86_RAX,X86_RSP,X86_WIDTH_64,0);
  if(k==1)X86_SIM_L_EXEC_MOV_REG_AUX(X86_RAX,X86_RSP,X86_WIDTH_32,0);
  if(k==2)X86_SIM_L_EXEC_LEA(X86_RAX,X86_RSP,X86_WIDTH_64,KPROG_X86_MEM_AUX(X86_REG_NONE,0,X86_WIDTH_64,0),16);
  if(k==3)X86_SIM_L_EXEC_LEA(X86_RAX,X86_RSP,X86_WIDTH_32,KPROG_X86_MEM_AUX(X86_REG_NONE,0,X86_WIDTH_64,0),16);
  uint64_t got=X86_SIM_L_READ_REG(X86_RAX);if(got!=native){if(bad<3)printf("alias difference k%u base%llx got%llx native%llx\n",k,(unsigned long long)bases[b],(unsigned long long)got,(unsigned long long)native);bad++;}total++;
 }
 printf("actual CPU MOV/LEA stack alias observations cases=%lu differences=%lu\n",total,bad);return !!bad;
}
