from pathlib import Path
import os,select,json,tarfile,io,re,hashlib,gzip
R=Path('/workspaces/repository');D=Path('/workspaces/.agent-state/kprog-lanes/C/micro-rorx-runtime');O=R/'corpus/results/kprog_app_coverage_20261107/micro-rorx-runtime';O.mkdir(exist_ok=True);inputs=json.loads((D/'running-inputs.json').read_text())
try:
 fd=os.pidfd_open(inputs['driver_pid']);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
log=(D/'run.log').read_text();matches=re.findall(r'\[done\] wrote (\S+)/metadata.json',log)
if not matches:
 matches=sorted(set(re.findall(r'(/workspaces/repository/micro/results/x86_kvm_micro_[0-9_]+)/',log)))
r=dict(driver_exit=int((D/'run.exit').read_text()),launch_inputs=inputs,source_drift=[n for n,h in inputs['sha256'].items() if hashlib.sha256((R/n).read_bytes()).hexdigest()!=h],temporary_files_remaining=[str(p) for p in [D/'runtime.image.tar',D/'var-tmp/bpf-benchmark-docker.img'] if p.exists()])
(O/'runtime-driver.log.gz').write_bytes(gzip.compress(log.encode(),mtime=0))
if len(matches)!=1:
 r['error']='No unique completed micro metadata path';(O/'runtime.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(1)
root=Path(matches[0]);data=json.loads((root/'details/result.json').read_text());r['result']=str(root);r['benchmarks']=[]
for b in data['benchmarks']:
 samples={row['runtime']:row['samples'] for row in b['runs']};r['benchmarks'].append(dict(name=b['name'],expected_result=b.get('expected_result'),expected_retval=b.get('expected_retval'),error=b.get('error'),samples=samples))
r['programs_total']=len(r['benchmarks']);r['benchmarks_failed']=sum(bool(b.get('error')) for b in r['benchmarks']);r['requests']=[]
service=R/'micro/results/trusted-service-c-rorx-standard-20261107.tar.gz'
if service.exists():
 with tarfile.open(service) as t:
  try:rows=[json.loads(l) for l in t.extractfile('service/requests/requests.jsonl').read().splitlines()]
  except KeyError:rows=[]
  for row in rows:
   archive='service/requests/'+str(row['request_id'])+('.success.tar.gz' if row['status']==0 else '.failure.tar.gz')
   with tarfile.open(fileobj=io.BytesIO(t.extractfile(archive).read())) as q:
    names=set(q.getnames());entry=q.extractfile('request/kernel.entry').read().decode();failtext=q.extractfile('request/load.stderr').read().decode(errors='replace') if 'request/load.stderr' in names else ''
    r['requests'].append({**row,'entry':entry,'generated_source':'request/generated/trusted_x86.bpf.c' in names,'compiled_object':'request/generated/trusted_x86.bpf.o' in names,'load_error_tail':failtext[-3000:]})
 with tarfile.open(O/'runtime-service.tar.gz','x:gz') as out:out.add(service,arcname=service.name)
r['native_requests']=len(r['requests']);r['generated']=sum(q['generated_source'] for q in r['requests']);r['compiled']=sum(q['compiled_object'] for q in r['requests']);r['accepted_bound']=sum(q['status']==0 for q in r['requests']);r['failed']=sum(q['status']!=0 for q in r['requests'])
with tarfile.open(O/'runtime-raw.tar.gz','x:gz') as t:
 t.add(root,arcname='result')
 for n in ['kernel.log','meminfo.txt','collect.py','run.sh','run.log','run.exit','running-inputs.json','image-inputs.json','image.json','refresh-image.sh','image.log','image.exit','image-context/Dockerfile','image-context/runner/build-llvmbpf/micro_exec','image-context/micro/driver.py','image-context/runner/suites/micro.py']:t.add(D/n,arcname='driver/'+n)
r['raw_sha256']=hashlib.sha256((O/'runtime-raw.tar.gz').read_bytes()).hexdigest();(O/'runtime.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['benchmarks','requests','launch_inputs']},indent=2),flush=True)
assert r['driver_exit']==0 and r['benchmarks_failed']==0 and r['native_requests']==1 and r['accepted_bound']==1,r['accepted_bound']
