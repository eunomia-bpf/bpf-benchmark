from pathlib import Path
import os,select,json,tarfile,io,hashlib,gzip
R=Path('/workspaces/repository');D=Path('/workspaces/.agent-state/kprog-lanes/C/tetragon-manifest-replay');O=R/'corpus/results/kprog_app_coverage_20261107/tetragon-manifest-replay';H=Path('/workspaces/.agent-state/kprog-lanes/C/tetragon-manifest-replay');pins=json.loads((D/'running-inputs.json').read_text())
try:
 fd=os.pidfd_open(pins['driver_pid']);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
log=(D/'run.log').read_text();reports=[]
for line in log.splitlines():
 try:x=json.loads(line)
 except json.JSONDecodeError:continue
 if isinstance(x,dict) and 'corpus_metadata' in x and 'archive' in x:reports.append(x)
r={'driver_exit':int((D/'run.exit').read_text()),'launch_inputs':pins,'source_drift':[n for n,h in pins['sha256'].items() if hashlib.sha256((R/n).read_bytes()).hexdigest()!=h],'temporary_files_remaining':[str(p) for p in [D/'runtime.image.tar',D/'var-tmp/bpf-benchmark-docker.img'] if p.exists()]}
(O/'driver.log.gz').write_bytes(gzip.compress(log.encode(),mtime=0))
if len(reports)!=1:
 r['error']='No unique own guest archive receipt';(O/'coverage.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(1)
archive=H/reports[0]['archive'];programs=[]
with tarfile.open(archive) as tar:
 summary=json.loads(tar.extractfile('corpus/summary.json').read());assert summary['apps']==pins['app'] and summary['service_state_directory'].startswith(str(D)+'/trusted-')
 service=[json.loads(l) for l in tar.extractfile('corpus/requests/requests.jsonl').read().splitlines()] if 'corpus/requests/requests.jsonl' in tar.getnames() else []
 r['service_log']=tar.extractfile('corpus/service.log').read().decode(errors='replace')
 for row in service:
  name=Path(row.get('artifact_archive',row.get('failure_archive'))).name
  with tarfile.open(fileobj=io.BytesIO(tar.extractfile('corpus/requests/'+name).read())) as q:
   names=set(q.getnames());sha=hashlib.sha256(q.extractfile('request/kernel.native.o').read()).hexdigest();assert sha==row['native_sha256']
   programs.append({**row,'entry':q.extractfile('request/kernel.entry').read().decode(),'generated_source':'request/generated/trusted_x86.bpf.c' in names,'compiled_object':'request/generated/trusted_x86.bpf.o' in names,'native_sha256_verified':True,'load_error_tail':q.extractfile('request/load.stderr').read().decode(errors='replace')[-5000:] if 'request/load.stderr' in names else ''})
 r.update(programs=programs,native_requests=len(programs),generated=sum(p['generated_source'] for p in programs),compiled=sum(p['compiled_object'] for p in programs),accepted_bound=sum(p['status']==0 for p in programs),failed=sum(p['status']!=0 for p in programs),corpus_metadata=summary['corpus_metadata'],terminal_archives_verified=len(programs),service_archive=archive.name,service_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
with tarfile.open(O/'service.tar.gz','x:gz') as t:t.add(archive,arcname=archive.name)
with tarfile.open(O/'result.tar.gz','x:gz') as t:
 for meta in r['corpus_metadata']:
  root=Path(meta['path']).parent;app=json.loads((root/'details/apps/tetragon__observer.json').read_text());r.update(result=str(root),metadata_status=meta['status'],app_status=app.get('status'),app_error=app.get('error'),rejit_result=app.get('rejit_result'),baseline=app.get('baseline'),post_rejit=app.get('post_rejit'));t.add(root,arcname='result')
  shim=root/'details/shim-logs/tetragon__observer.post_rejit.log'
  if shim.exists():
   s=shim.read_text();r.update(native_replaced=s.count('native-loader replaced prog='),native_failed=s.count('native-loader failed prog='))
with tarfile.open(O/'launch.tar.gz','x:gz') as t:
 for n in ['run.sh','run.log','run.exit','collect.py','running-inputs.json','guest-before.py','source-pins','package-inputs.json','guest.py','Makefile','Dockerfile','base-image.json','image.json','module.ko','native-link-readonly-c','private-inputs.json','build.log','manifest.json']:t.add(D/n,arcname=n)
r['artifact_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()};(O/'coverage.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['programs','baseline','post_rejit','launch_inputs']},indent=2),flush=True)
assert r.get('app_status')=='ok' and r['failed']==0,{k:r.get(k) for k in ['app_status','accepted_bound','failed','native_replaced','native_failed','source_drift']}
