# map_array_index_packet

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb1]        # 3fc0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 56 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f56]        # 3fb0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 35 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f35]        # 3fd0 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <map_array_index_packet>:
    1100:	41 57                	push   r15
    1102:	41 56                	push   r14
    1104:	53                   	push   rbx
    1105:	48 83 ec 10          	sub    rsp,0x10
    1109:	4c 8b 37             	mov    r14,QWORD PTR [rdi]
    110c:	49 8d 4e 20          	lea    rcx,[r14+0x20]
    1110:	31 c0                	xor    eax,eax
    1112:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1116:	77 5d                	ja     1175 <map_array_index_packet+0x75>
    1118:	c7 44 24 04 00 00 00 	mov    DWORD PTR [rsp+0x4],0x0
    111f:	00 
    1120:	48 b8 be ba fe ca ef 	movabs rax,0xdeadbeefcafebabe
    1127:	be ad de 
    112a:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
    112f:	48 8b 1d a2 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2ea2]        # 3fd8 <idx_array@@Base-0x40>
    1136:	45 31 ff             	xor    r15d,r15d
    1139:	48 8d 74 24 04       	lea    rsi,[rsp+0x4]
    113e:	48 8d 54 24 08       	lea    rdx,[rsp+0x8]
    1143:	48 89 df             	mov    rdi,rbx
    1146:	31 c9                	xor    ecx,ecx
    1148:	ff 15 7a 2e 00 00    	call   QWORD PTR [rip+0x2e7a]        # 3fc8 <micro_native_bpf_map_update_elem@Base>
    114e:	41 0f b6 46 10       	movzx  eax,BYTE PTR [r14+0x10]
    1153:	83 e0 0f             	and    eax,0xf
    1156:	89 04 24             	mov    DWORD PTR [rsp],eax
    1159:	48 89 e6             	mov    rsi,rsp
    115c:	48 89 df             	mov    rdi,rbx
    115f:	ff 15 53 2e 00 00    	call   QWORD PTR [rip+0x2e53]        # 3fb8 <micro_native_bpf_map_lookup_elem@Base>
    1165:	48 85 c0             	test   rax,rax
    1168:	74 03                	je     116d <map_array_index_packet+0x6d>
    116a:	4c 8b 38             	mov    r15,QWORD PTR [rax]
    116d:	4d 89 3e             	mov    QWORD PTR [r14],r15
    1170:	b8 02 00 00 00       	mov    eax,0x2
    1175:	48 83 c4 10          	add    rsp,0x10
    1179:	5b                   	pop    rbx
    117a:	41 5e                	pop    r14
    117c:	41 5f                	pop    r15
    117e:	c3                   	ret

Disassembly of section .fini:

0000000000001180 <_fini>:
    1180:	f3 0f 1e fa          	endbr64
    1184:	48 83 ec 08          	sub    rsp,0x8
    1188:	48 83 c4 08          	add    rsp,0x8
    118c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	31 c0                	xor    eax,eax
  18:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  1c:	48 8b 5f 00          	mov    rbx,QWORD PTR [rdi+0x0]
  20:	48 89 df             	mov    rdi,rbx
  23:	48 83 c7 20          	add    rdi,0x20
  27:	48 39 f7             	cmp    rdi,rsi
  2a:	0f 87 c8 00 00 00    	ja     0xf8
  30:	45 31 ed             	xor    r13d,r13d
  33:	44 89 6d fc          	mov    DWORD PTR [rbp-0x4],r13d
  37:	48 bf be ba fe ca ef 	movabs rdi,0xdeadbeefcafebabe
  3e:	be ad de 
  41:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
  45:	48 89 ee             	mov    rsi,rbp
  48:	48 83 c6 fc          	add    rsi,0xfffffffffffffffc
  4c:	48 89 ea             	mov    rdx,rbp
  4f:	48 83 c2 f0          	add    rdx,0xfffffffffffffff0
  53:	48 bf 00 b4 fb 44 84 	movabs rdi,0xffff8c8444fbb400
  5a:	8c ff ff 
  5d:	31 c9                	xor    ecx,ecx
  5f:	e8 78 b0 ec f9       	call   0xfffffffff9ecb0dc
  64:	48 0f b6 7b 10       	movzx  rdi,BYTE PTR [rbx+0x10]
  69:	48 83 e7 0f          	and    rdi,0xf
  6d:	89 7d ec             	mov    DWORD PTR [rbp-0x14],edi
  70:	48 89 ee             	mov    rsi,rbp
  73:	48 83 c6 ec          	add    rsi,0xffffffffffffffec
  77:	48 bf 00 b4 fb 44 84 	movabs rdi,0xffff8c8444fbb400
  7e:	8c ff ff 
  81:	48 81 c7 30 01 00 00 	add    rdi,0x130
  88:	8b 46 00             	mov    eax,DWORD PTR [rsi+0x0]
  8b:	48 83 f8 10          	cmp    rax,0x10
  8f:	73 09                	jae    0x9a
  91:	48 c1 e0 03          	shl    rax,0x3
  95:	48 01 f8             	add    rax,rdi
  98:	eb 02                	jmp    0x9c
  9a:	31 c0                	xor    eax,eax
  9c:	48 85 c0             	test   rax,rax
  9f:	74 04                	je     0xa5
  a1:	4c 8b 68 00          	mov    r13,QWORD PTR [rax+0x0]
  a5:	4c 89 ef             	mov    rdi,r13
  a8:	48 c1 ef 38          	shr    rdi,0x38
  ac:	40 88 7b 07          	mov    BYTE PTR [rbx+0x7],dil
  b0:	4c 89 ef             	mov    rdi,r13
  b3:	48 c1 ef 30          	shr    rdi,0x30
  b7:	40 88 7b 06          	mov    BYTE PTR [rbx+0x6],dil
  bb:	4c 89 ef             	mov    rdi,r13
  be:	48 c1 ef 28          	shr    rdi,0x28
  c2:	40 88 7b 05          	mov    BYTE PTR [rbx+0x5],dil
  c6:	4c 89 ef             	mov    rdi,r13
  c9:	48 c1 ef 20          	shr    rdi,0x20
  cd:	40 88 7b 04          	mov    BYTE PTR [rbx+0x4],dil
  d1:	4c 89 ef             	mov    rdi,r13
  d4:	48 c1 ef 18          	shr    rdi,0x18
  d8:	40 88 7b 03          	mov    BYTE PTR [rbx+0x3],dil
  dc:	4c 89 ef             	mov    rdi,r13
  df:	48 c1 ef 10          	shr    rdi,0x10
  e3:	40 88 7b 02          	mov    BYTE PTR [rbx+0x2],dil
  e7:	44 88 6b 00          	mov    BYTE PTR [rbx+0x0],r13b
  eb:	49 c1 ed 08          	shr    r13,0x8
  ef:	44 88 6b 01          	mov    BYTE PTR [rbx+0x1],r13b
  f3:	b8 02 00 00 00       	mov    eax,0x2
  f8:	41 5d                	pop    r13
  fa:	5b                   	pop    rbx
  fb:	c9                   	leave
  fc:	e9 ab 2b a1 fa       	jmp    0xfffffffffaa12cac
```

## llvmbpf JIT ASM
```asm
not captured
```
