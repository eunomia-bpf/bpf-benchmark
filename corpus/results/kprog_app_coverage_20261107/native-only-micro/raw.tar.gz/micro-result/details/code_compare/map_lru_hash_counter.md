# map_lru_hash_counter

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 a9 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fa9]        # 3fb8 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 4e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f4e]        # 3fa8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <map_lru_hash_counter>:
    1100:	41 57                	push   r15
    1102:	41 56                	push   r14
    1104:	41 54                	push   r12
    1106:	53                   	push   rbx
    1107:	48 83 ec 18          	sub    rsp,0x18
    110b:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    110e:	49 8d 4f 08          	lea    rcx,[r15+0x8]
    1112:	31 c0                	xor    eax,eax
    1114:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1118:	77 61                	ja     117b <map_lru_hash_counter+0x7b>
    111a:	c7 44 24 0c 2a 00 00 	mov    DWORD PTR [rsp+0xc],0x2a
    1121:	00 
    1122:	48 8b 1d 97 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2e97]        # 3fc0 <cnt_lru@@Base-0x58>
    1129:	4c 8d 74 24 0c       	lea    r14,[rsp+0xc]
    112e:	48 89 df             	mov    rdi,rbx
    1131:	4c 89 f6             	mov    rsi,r14
    1134:	ff 15 96 2e 00 00    	call   QWORD PTR [rip+0x2e96]        # 3fd0 <micro_native_bpf_map_delete_elem@Base>
    113a:	48 c7 44 24 10 00 00 	mov    QWORD PTR [rsp+0x10],0x0
    1141:	00 00 
    1143:	45 31 e4             	xor    r12d,r12d
    1146:	48 8d 54 24 10       	lea    rdx,[rsp+0x10]
    114b:	48 89 df             	mov    rdi,rbx
    114e:	4c 89 f6             	mov    rsi,r14
    1151:	31 c9                	xor    ecx,ecx
    1153:	ff 15 6f 2e 00 00    	call   QWORD PTR [rip+0x2e6f]        # 3fc8 <micro_native_bpf_map_update_elem@Base>
    1159:	48 89 df             	mov    rdi,rbx
    115c:	4c 89 f6             	mov    rsi,r14
    115f:	ff 15 4b 2e 00 00    	call   QWORD PTR [rip+0x2e4b]        # 3fb0 <micro_native_bpf_map_lookup_elem@Base>
    1165:	48 85 c0             	test   rax,rax
    1168:	74 09                	je     1173 <map_lru_hash_counter+0x73>
    116a:	4c 8b 20             	mov    r12,QWORD PTR [rax]
    116d:	49 ff c4             	inc    r12
    1170:	4c 89 20             	mov    QWORD PTR [rax],r12
    1173:	4d 89 27             	mov    QWORD PTR [r15],r12
    1176:	b8 02 00 00 00       	mov    eax,0x2
    117b:	48 83 c4 18          	add    rsp,0x18
    117f:	5b                   	pop    rbx
    1180:	41 5c                	pop    r12
    1182:	41 5e                	pop    r14
    1184:	41 5f                	pop    r15
    1186:	c3                   	ret

Disassembly of section .fini:

0000000000001188 <_fini>:
    1188:	f3 0f 1e fa          	endbr64
    118c:	48 83 ec 08          	sub    rsp,0x8
    1190:	48 83 c4 08          	add    rsp,0x8
    1194:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 10 00 00 00 	sub    rsp,0x10
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	31 c0                	xor    eax,eax
  1a:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  1e:	4c 8b 6f 00          	mov    r13,QWORD PTR [rdi+0x0]
  22:	4c 89 ef             	mov    rdi,r13
  25:	48 83 c7 08          	add    rdi,0x8
  29:	48 39 f7             	cmp    rdi,rsi
  2c:	0f 87 d0 00 00 00    	ja     0x102
  32:	bf 2a 00 00 00       	mov    edi,0x2a
  37:	89 7d fc             	mov    DWORD PTR [rbp-0x4],edi
  3a:	48 89 eb             	mov    rbx,rbp
  3d:	48 83 c3 fc          	add    rbx,0xfffffffffffffffc
  41:	48 bf 00 ac 2e 47 84 	movabs rdi,0xffff8c84472eac00
  48:	8c ff ff 
  4b:	48 89 de             	mov    rsi,rbx
  4e:	e8 95 7b ec f9       	call   0xfffffffff9ec7be8
  53:	45 31 f6             	xor    r14d,r14d
  56:	4c 89 75 f0          	mov    QWORD PTR [rbp-0x10],r14
  5a:	48 89 ea             	mov    rdx,rbp
  5d:	48 83 c2 f0          	add    rdx,0xfffffffffffffff0
  61:	48 bf 00 ac 2e 47 84 	movabs rdi,0xffff8c84472eac00
  68:	8c ff ff 
  6b:	48 89 de             	mov    rsi,rbx
  6e:	31 c9                	xor    ecx,ecx
  70:	e8 73 7e ec f9       	call   0xfffffffff9ec7ee8
  75:	48 bf 00 ac 2e 47 84 	movabs rdi,0xffff8c84472eac00
  7c:	8c ff ff 
  7f:	48 89 de             	mov    rsi,rbx
  82:	e8 11 5b ec f9       	call   0xfffffffff9ec5b98
  87:	48 85 c0             	test   rax,rax
  8a:	74 12                	je     0x9e
  8c:	48 0f b6 78 23       	movzx  rdi,BYTE PTR [rax+0x23]
  91:	48 85 ff             	test   rdi,rdi
  94:	75 04                	jne    0x9a
  96:	c6 40 23 01          	mov    BYTE PTR [rax+0x23],0x1
  9a:	48 83 c0 38          	add    rax,0x38
  9e:	48 85 c0             	test   rax,rax
  a1:	74 0c                	je     0xaf
  a3:	4c 8b 70 00          	mov    r14,QWORD PTR [rax+0x0]
  a7:	49 83 c6 01          	add    r14,0x1
  ab:	4c 89 70 00          	mov    QWORD PTR [rax+0x0],r14
  af:	4c 89 f7             	mov    rdi,r14
  b2:	48 c1 ef 38          	shr    rdi,0x38
  b6:	41 88 7d 07          	mov    BYTE PTR [r13+0x7],dil
  ba:	4c 89 f7             	mov    rdi,r14
  bd:	48 c1 ef 30          	shr    rdi,0x30
  c1:	41 88 7d 06          	mov    BYTE PTR [r13+0x6],dil
  c5:	4c 89 f7             	mov    rdi,r14
  c8:	48 c1 ef 28          	shr    rdi,0x28
  cc:	41 88 7d 05          	mov    BYTE PTR [r13+0x5],dil
  d0:	4c 89 f7             	mov    rdi,r14
  d3:	48 c1 ef 20          	shr    rdi,0x20
  d7:	41 88 7d 04          	mov    BYTE PTR [r13+0x4],dil
  db:	4c 89 f7             	mov    rdi,r14
  de:	48 c1 ef 18          	shr    rdi,0x18
  e2:	41 88 7d 03          	mov    BYTE PTR [r13+0x3],dil
  e6:	4c 89 f7             	mov    rdi,r14
  e9:	48 c1 ef 10          	shr    rdi,0x10
  ed:	41 88 7d 02          	mov    BYTE PTR [r13+0x2],dil
  f1:	45 88 75 00          	mov    BYTE PTR [r13+0x0],r14b
  f5:	49 c1 ee 08          	shr    r14,0x8
  f9:	45 88 75 01          	mov    BYTE PTR [r13+0x1],r14b
  fd:	b8 02 00 00 00       	mov    eax,0x2
 102:	41 5e                	pop    r14
 104:	41 5d                	pop    r13
 106:	5b                   	pop    rbx
 107:	c9                   	leave
 108:	e9 bb 2b a1 fa       	jmp    0xfffffffffaa12cc8
```

## llvmbpf JIT ASM
```asm
not captured
```
