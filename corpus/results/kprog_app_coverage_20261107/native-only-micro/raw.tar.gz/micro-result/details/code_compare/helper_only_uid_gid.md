# helper_only_uid_gid

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b9 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb9]        # 3fc8 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 a2 2f 00 00    	jmp    QWORD PTR [rip+0x2fa2]        # 3fd8 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <__TMC_END__>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <__TMC_END__>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 66 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f66]        # 3fc0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <__TMC_END__>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <__TMC_END__>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 35 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f35]        # 3fd0 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 51 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f51],0x0        # 400c <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 12 2f 00 00 	cmp    QWORD PTR [rip+0x2f12],0x0        # 3fd8 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 29 2f 00 00 01 	mov    BYTE PTR [rip+0x2f29],0x1        # 400c <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <helper_only_uid_gid>:
    1100:	53                   	push   rbx
    1101:	48 8b 1f             	mov    rbx,QWORD PTR [rdi]
    1104:	48 8d 4b 08          	lea    rcx,[rbx+0x8]
    1108:	31 c0                	xor    eax,eax
    110a:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    110e:	77 0e                	ja     111e <helper_only_uid_gid+0x1e>
    1110:	ff 15 ca 2e 00 00    	call   QWORD PTR [rip+0x2eca]        # 3fe0 <micro_native_bpf_get_current_uid_gid@Base>
    1116:	48 89 03             	mov    QWORD PTR [rbx],rax
    1119:	b8 02 00 00 00       	mov    eax,0x2
    111e:	5b                   	pop    rbx
    111f:	c3                   	ret

Disassembly of section .fini:

0000000000001120 <_fini>:
    1120:	f3 0f 1e fa          	endbr64
    1124:	48 83 ec 08          	sub    rsp,0x8
    1128:	48 83 c4 08          	add    rsp,0x8
    112c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	53                   	push   rbx
   d:	31 c0                	xor    eax,eax
   f:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  13:	48 8b 5f 00          	mov    rbx,QWORD PTR [rdi+0x0]
  17:	48 89 df             	mov    rdi,rbx
  1a:	48 83 c7 08          	add    rdi,0x8
  1e:	48 39 f7             	cmp    rdi,rsi
  21:	77 56                	ja     0x79
  23:	e8 f4 80 eb f9       	call   0xfffffffff9eb811c
  28:	48 89 c7             	mov    rdi,rax
  2b:	48 c1 ef 38          	shr    rdi,0x38
  2f:	40 88 7b 07          	mov    BYTE PTR [rbx+0x7],dil
  33:	48 89 c7             	mov    rdi,rax
  36:	48 c1 ef 30          	shr    rdi,0x30
  3a:	40 88 7b 06          	mov    BYTE PTR [rbx+0x6],dil
  3e:	48 89 c7             	mov    rdi,rax
  41:	48 c1 ef 28          	shr    rdi,0x28
  45:	40 88 7b 05          	mov    BYTE PTR [rbx+0x5],dil
  49:	48 89 c7             	mov    rdi,rax
  4c:	48 c1 ef 20          	shr    rdi,0x20
  50:	40 88 7b 04          	mov    BYTE PTR [rbx+0x4],dil
  54:	48 89 c7             	mov    rdi,rax
  57:	48 c1 ef 18          	shr    rdi,0x18
  5b:	40 88 7b 03          	mov    BYTE PTR [rbx+0x3],dil
  5f:	48 89 c7             	mov    rdi,rax
  62:	48 c1 ef 10          	shr    rdi,0x10
  66:	40 88 7b 02          	mov    BYTE PTR [rbx+0x2],dil
  6a:	88 43 00             	mov    BYTE PTR [rbx+0x0],al
  6d:	48 c1 e8 08          	shr    rax,0x8
  71:	88 43 01             	mov    BYTE PTR [rbx+0x1],al
  74:	b8 02 00 00 00       	mov    eax,0x2
  79:	5b                   	pop    rbx
  7a:	c9                   	leave
  7b:	e9 8c 2c a1 fa       	jmp    0xfffffffffaa12d0c
```

## llvmbpf JIT ASM
```asm
not captured
```
