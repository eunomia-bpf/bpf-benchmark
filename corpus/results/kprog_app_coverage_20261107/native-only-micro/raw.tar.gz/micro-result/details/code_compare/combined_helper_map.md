# combined_helper_map

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb1]        # 3fc0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 a2 2f 00 00    	jmp    QWORD PTR [rip+0x2fa2]        # 3fd8 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 46 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f46]        # 3fa0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 35 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f35]        # 3fd0 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 12 2f 00 00 	cmp    QWORD PTR [rip+0x2f12],0x0        # 3fd8 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <combined_helper_map>:
    1100:	41 57                	push   r15
    1102:	41 56                	push   r14
    1104:	41 54                	push   r12
    1106:	53                   	push   rbx
    1107:	48 83 ec 18          	sub    rsp,0x18
    110b:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    110e:	49 8d 4f 08          	lea    rcx,[r15+0x8]
    1112:	31 c0                	xor    eax,eax
    1114:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1118:	77 53                	ja     116d <combined_helper_map+0x6d>
    111a:	ff 15 90 2e 00 00    	call   QWORD PTR [rip+0x2e90]        # 3fb0 <micro_native_bpf_get_smp_processor_id@Base>
    1120:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    1124:	ff 15 b6 2e 00 00    	call   QWORD PTR [rip+0x2eb6]        # 3fe0 <micro_native_bpf_get_current_uid_gid@Base>
    112a:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    112f:	48 8b 1d 72 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2e72]        # 3fa8 <cpu_ts@@Base-0x70>
    1136:	45 31 e4             	xor    r12d,r12d
    1139:	4c 8d 74 24 0c       	lea    r14,[rsp+0xc]
    113e:	48 8d 54 24 10       	lea    rdx,[rsp+0x10]
    1143:	48 89 df             	mov    rdi,rbx
    1146:	4c 89 f6             	mov    rsi,r14
    1149:	31 c9                	xor    ecx,ecx
    114b:	ff 15 77 2e 00 00    	call   QWORD PTR [rip+0x2e77]        # 3fc8 <micro_native_bpf_map_update_elem@Base>
    1151:	48 89 df             	mov    rdi,rbx
    1154:	4c 89 f6             	mov    rsi,r14
    1157:	ff 15 5b 2e 00 00    	call   QWORD PTR [rip+0x2e5b]        # 3fb8 <micro_native_bpf_map_lookup_elem@Base>
    115d:	48 85 c0             	test   rax,rax
    1160:	74 03                	je     1165 <combined_helper_map+0x65>
    1162:	4c 8b 20             	mov    r12,QWORD PTR [rax]
    1165:	4d 89 27             	mov    QWORD PTR [r15],r12
    1168:	b8 02 00 00 00       	mov    eax,0x2
    116d:	48 83 c4 18          	add    rsp,0x18
    1171:	5b                   	pop    rbx
    1172:	41 5c                	pop    r12
    1174:	41 5e                	pop    r14
    1176:	41 5f                	pop    r15
    1178:	c3                   	ret

Disassembly of section .fini:

000000000000117c <_fini>:
    117c:	f3 0f 1e fa          	endbr64
    1180:	48 83 ec 08          	sub    rsp,0x8
    1184:	48 83 c4 08          	add    rsp,0x8
    1188:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 10 00 00 00 	sub    rsp,0x10
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	31 c0                	xor    eax,eax
  1a:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  1e:	4c 8b 6f 00          	mov    r13,QWORD PTR [rdi+0x0]
  22:	4c 89 ef             	mov    rdi,r13
  25:	48 83 c7 08          	add    rdi,0x8
  29:	48 39 f7             	cmp    rdi,rsi
  2c:	0f 87 d5 00 00 00    	ja     0x107
  32:	48 c7 c0 34 10 2b bd 	mov    rax,0xffffffffbd2b1034
  39:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
  40:	2b bd 
  42:	8b 40 00             	mov    eax,DWORD PTR [rax+0x0]
  45:	89 45 fc             	mov    DWORD PTR [rbp-0x4],eax
  48:	e8 8b 80 eb f9       	call   0xfffffffff9eb80d8
  4d:	48 89 45 f0          	mov    QWORD PTR [rbp-0x10],rax
  51:	48 89 eb             	mov    rbx,rbp
  54:	48 83 c3 fc          	add    rbx,0xfffffffffffffffc
  58:	48 89 ea             	mov    rdx,rbp
  5b:	48 83 c2 f0          	add    rdx,0xfffffffffffffff0
  5f:	45 31 f6             	xor    r14d,r14d
  62:	48 bf 00 58 e3 43 84 	movabs rdi,0xffff8c8443e35800
  69:	8c ff ff 
  6c:	48 89 de             	mov    rsi,rbx
  6f:	31 c9                	xor    ecx,ecx
  71:	e8 82 b0 ec f9       	call   0xfffffffff9ecb0f8
  76:	48 bf 00 58 e3 43 84 	movabs rdi,0xffff8c8443e35800
  7d:	8c ff ff 
  80:	48 89 de             	mov    rsi,rbx
  83:	48 81 c7 30 01 00 00 	add    rdi,0x130
  8a:	8b 46 00             	mov    eax,DWORD PTR [rsi+0x0]
  8d:	48 83 f8 40          	cmp    rax,0x40
  91:	73 16                	jae    0xa9
  93:	48 c1 e0 03          	shl    rax,0x3
  97:	48 01 f8             	add    rax,rdi
  9a:	48 8b 40 00          	mov    rax,QWORD PTR [rax+0x0]
  9e:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
  a5:	2b bd 
  a7:	eb 02                	jmp    0xab
  a9:	31 c0                	xor    eax,eax
  ab:	48 85 c0             	test   rax,rax
  ae:	74 04                	je     0xb4
  b0:	4c 8b 70 00          	mov    r14,QWORD PTR [rax+0x0]
  b4:	4c 89 f7             	mov    rdi,r14
  b7:	48 c1 ef 38          	shr    rdi,0x38
  bb:	41 88 7d 07          	mov    BYTE PTR [r13+0x7],dil
  bf:	4c 89 f7             	mov    rdi,r14
  c2:	48 c1 ef 30          	shr    rdi,0x30
  c6:	41 88 7d 06          	mov    BYTE PTR [r13+0x6],dil
  ca:	4c 89 f7             	mov    rdi,r14
  cd:	48 c1 ef 28          	shr    rdi,0x28
  d1:	41 88 7d 05          	mov    BYTE PTR [r13+0x5],dil
  d5:	4c 89 f7             	mov    rdi,r14
  d8:	48 c1 ef 20          	shr    rdi,0x20
  dc:	41 88 7d 04          	mov    BYTE PTR [r13+0x4],dil
  e0:	4c 89 f7             	mov    rdi,r14
  e3:	48 c1 ef 18          	shr    rdi,0x18
  e7:	41 88 7d 03          	mov    BYTE PTR [r13+0x3],dil
  eb:	4c 89 f7             	mov    rdi,r14
  ee:	48 c1 ef 10          	shr    rdi,0x10
  f2:	41 88 7d 02          	mov    BYTE PTR [r13+0x2],dil
  f6:	45 88 75 00          	mov    BYTE PTR [r13+0x0],r14b
  fa:	49 c1 ee 08          	shr    r14,0x8
  fe:	45 88 75 01          	mov    BYTE PTR [r13+0x1],r14b
 102:	b8 02 00 00 00       	mov    eax,0x2
 107:	41 5e                	pop    r14
 109:	41 5d                	pop    r13
 10b:	5b                   	pop    rbx
 10c:	c9                   	leave
 10d:	e9 b6 2b a1 fa       	jmp    0xfffffffffaa12cc8
```

## llvmbpf JIT ASM
```asm
not captured
```
