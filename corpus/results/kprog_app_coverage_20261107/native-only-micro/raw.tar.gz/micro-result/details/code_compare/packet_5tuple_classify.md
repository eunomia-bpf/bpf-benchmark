# packet_5tuple_classify

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b9 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb9]        # 3fc8 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 56 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f56]        # 3fb0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <packet_5tuple_classify>:
    1100:	55                   	push   rbp
    1101:	41 57                	push   r15
    1103:	41 56                	push   r14
    1105:	53                   	push   rbx
    1106:	48 83 ec 18          	sub    rsp,0x18
    110a:	48 8b 2f             	mov    rbp,QWORD PTR [rdi]
    110d:	48 8d 4d 20          	lea    rcx,[rbp+0x20]
    1111:	31 c0                	xor    eax,eax
    1113:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1117:	0f 87 8c 00 00 00    	ja     11a9 <packet_5tuple_classify+0xa9>
    111d:	c7 44 24 14 00 00 00 	mov    DWORD PTR [rsp+0x14],0x0
    1124:	00 
    1125:	8b 45 10             	mov    eax,DWORD PTR [rbp+0x10]
    1128:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    112c:	8b 45 14             	mov    eax,DWORD PTR [rbp+0x14]
    112f:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    1133:	0f b7 45 18          	movzx  eax,WORD PTR [rbp+0x18]
    1137:	66 89 44 24 10       	mov    WORD PTR [rsp+0x10],ax
    113c:	0f b7 45 1a          	movzx  eax,WORD PTR [rbp+0x1a]
    1140:	66 89 44 24 12       	mov    WORD PTR [rsp+0x12],ax
    1145:	0f b6 45 1c          	movzx  eax,BYTE PTR [rbp+0x1c]
    1149:	88 44 24 14          	mov    BYTE PTR [rsp+0x14],al
    114d:	c7 44 24 04 be ba fe 	mov    DWORD PTR [rsp+0x4],0xcafebabe
    1154:	ca 
    1155:	4c 8b 3d 5c 2e 00 00 	mov    r15,QWORD PTR [rip+0x2e5c]        # 3fb8 <flow_table@@Base-0x60>
    115c:	31 db                	xor    ebx,ebx
    115e:	4c 8d 74 24 08       	lea    r14,[rsp+0x8]
    1163:	48 8d 54 24 04       	lea    rdx,[rsp+0x4]
    1168:	4c 89 ff             	mov    rdi,r15
    116b:	4c 89 f6             	mov    rsi,r14
    116e:	31 c9                	xor    ecx,ecx
    1170:	ff 15 5a 2e 00 00    	call   QWORD PTR [rip+0x2e5a]        # 3fd0 <micro_native_bpf_map_update_elem@Base>
    1176:	4c 89 ff             	mov    rdi,r15
    1179:	4c 89 f6             	mov    rsi,r14
    117c:	ff 15 3e 2e 00 00    	call   QWORD PTR [rip+0x2e3e]        # 3fc0 <micro_native_bpf_map_lookup_elem@Base>
    1182:	48 85 c0             	test   rax,rax
    1185:	74 02                	je     1189 <packet_5tuple_classify+0x89>
    1187:	8b 18                	mov    ebx,DWORD PTR [rax]
    1189:	88 5d 00             	mov    BYTE PTR [rbp+0x0],bl
    118c:	88 7d 01             	mov    BYTE PTR [rbp+0x1],bh
    118f:	89 d8                	mov    eax,ebx
    1191:	c1 e8 10             	shr    eax,0x10
    1194:	88 45 02             	mov    BYTE PTR [rbp+0x2],al
    1197:	c1 eb 18             	shr    ebx,0x18
    119a:	88 5d 03             	mov    BYTE PTR [rbp+0x3],bl
    119d:	c7 45 04 00 00 00 00 	mov    DWORD PTR [rbp+0x4],0x0
    11a4:	b8 02 00 00 00       	mov    eax,0x2
    11a9:	48 83 c4 18          	add    rsp,0x18
    11ad:	5b                   	pop    rbx
    11ae:	41 5e                	pop    r14
    11b0:	41 5f                	pop    r15
    11b2:	5d                   	pop    rbp
    11b3:	c3                   	ret

Disassembly of section .fini:

00000000000011b4 <_fini>:
    11b4:	f3 0f 1e fa          	endbr64
    11b8:	48 83 ec 08          	sub    rsp,0x8
    11bc:	48 83 c4 08          	add    rsp,0x8
    11c0:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	31 c0                	xor    eax,eax
  1a:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  1e:	4c 8b 6f 00          	mov    r13,QWORD PTR [rdi+0x0]
  22:	4c 89 ef             	mov    rdi,r13
  25:	48 83 c7 20          	add    rdi,0x20
  29:	48 39 f7             	cmp    rdi,rsi
  2c:	0f 87 b6 00 00 00    	ja     0xe8
  32:	45 31 f6             	xor    r14d,r14d
  35:	44 89 75 fc          	mov    DWORD PTR [rbp-0x4],r14d
  39:	41 8b 7d 10          	mov    edi,DWORD PTR [r13+0x10]
  3d:	89 7d f0             	mov    DWORD PTR [rbp-0x10],edi
  40:	41 8b 7d 14          	mov    edi,DWORD PTR [r13+0x14]
  44:	89 7d f4             	mov    DWORD PTR [rbp-0xc],edi
  47:	49 0f b7 7d 18       	movzx  rdi,WORD PTR [r13+0x18]
  4c:	66 89 7d f8          	mov    WORD PTR [rbp-0x8],di
  50:	49 0f b7 7d 1a       	movzx  rdi,WORD PTR [r13+0x1a]
  55:	66 89 7d fa          	mov    WORD PTR [rbp-0x6],di
  59:	49 0f b6 7d 1c       	movzx  rdi,BYTE PTR [r13+0x1c]
  5e:	40 88 7d fc          	mov    BYTE PTR [rbp-0x4],dil
  62:	bf be ba fe ca       	mov    edi,0xcafebabe
  67:	89 7d ec             	mov    DWORD PTR [rbp-0x14],edi
  6a:	48 89 eb             	mov    rbx,rbp
  6d:	48 83 c3 f0          	add    rbx,0xfffffffffffffff0
  71:	48 89 ea             	mov    rdx,rbp
  74:	48 83 c2 ec          	add    rdx,0xffffffffffffffec
  78:	48 bf 00 c4 9c 4e 84 	movabs rdi,0xffff8c844e9cc400
  7f:	8c ff ff 
  82:	48 89 de             	mov    rsi,rbx
  85:	31 c9                	xor    ecx,ecx
  87:	e8 18 82 ec f9       	call   0xfffffffff9ec82a4
  8c:	48 bf 00 c4 9c 4e 84 	movabs rdi,0xffff8c844e9cc400
  93:	8c ff ff 
  96:	48 89 de             	mov    rsi,rbx
  99:	e8 06 59 ec f9       	call   0xfffffffff9ec59a4
  9e:	48 85 c0             	test   rax,rax
  a1:	74 04                	je     0xa7
  a3:	48 83 c0 40          	add    rax,0x40
  a7:	31 ff                	xor    edi,edi
  a9:	48 85 c0             	test   rax,rax
  ac:	74 03                	je     0xb1
  ae:	8b 78 00             	mov    edi,DWORD PTR [rax+0x0]
  b1:	45 88 75 07          	mov    BYTE PTR [r13+0x7],r14b
  b5:	45 88 75 06          	mov    BYTE PTR [r13+0x6],r14b
  b9:	45 88 75 05          	mov    BYTE PTR [r13+0x5],r14b
  bd:	45 88 75 04          	mov    BYTE PTR [r13+0x4],r14b
  c1:	48 89 fe             	mov    rsi,rdi
  c4:	48 c1 ee 18          	shr    rsi,0x18
  c8:	41 88 75 03          	mov    BYTE PTR [r13+0x3],sil
  cc:	48 89 fe             	mov    rsi,rdi
  cf:	48 c1 ee 10          	shr    rsi,0x10
  d3:	41 88 75 02          	mov    BYTE PTR [r13+0x2],sil
  d7:	41 88 7d 00          	mov    BYTE PTR [r13+0x0],dil
  db:	48 c1 ef 08          	shr    rdi,0x8
  df:	41 88 7d 01          	mov    BYTE PTR [r13+0x1],dil
  e3:	b8 02 00 00 00       	mov    eax,0x2
  e8:	41 5e                	pop    r14
  ea:	41 5d                	pop    r13
  ec:	5b                   	pop    rbx
  ed:	c9                   	leave
  ee:	e9 e1 29 a1 fa       	jmp    0xfffffffffaa12ad4
```

## llvmbpf JIT ASM
```asm
not captured
```
