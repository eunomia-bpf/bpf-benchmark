# map_percpu_hash_counter

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b9 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb9]        # 3fc8 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 56 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f56]        # 3fb0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <map_percpu_hash_counter>:
    1100:	41 57                	push   r15
    1102:	41 56                	push   r14
    1104:	41 54                	push   r12
    1106:	53                   	push   rbx
    1107:	48 83 ec 18          	sub    rsp,0x18
    110b:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    110e:	49 8d 4f 08          	lea    rcx,[r15+0x8]
    1112:	31 c0                	xor    eax,eax
    1114:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1118:	77 55                	ja     116f <map_percpu_hash_counter+0x6f>
    111a:	c7 44 24 0c 07 00 00 	mov    DWORD PTR [rsp+0xc],0x7
    1121:	00 
    1122:	48 c7 44 24 10 00 00 	mov    QWORD PTR [rsp+0x10],0x0
    1129:	00 00 
    112b:	48 8b 1d 8e 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2e8e]        # 3fc0 <cnt_pcpu@@Base-0x58>
    1132:	45 31 e4             	xor    r12d,r12d
    1135:	4c 8d 74 24 0c       	lea    r14,[rsp+0xc]
    113a:	48 8d 54 24 10       	lea    rdx,[rsp+0x10]
    113f:	48 89 df             	mov    rdi,rbx
    1142:	4c 89 f6             	mov    rsi,r14
    1145:	31 c9                	xor    ecx,ecx
    1147:	ff 15 83 2e 00 00    	call   QWORD PTR [rip+0x2e83]        # 3fd0 <micro_native_bpf_map_update_elem@Base>
    114d:	48 89 df             	mov    rdi,rbx
    1150:	4c 89 f6             	mov    rsi,r14
    1153:	ff 15 5f 2e 00 00    	call   QWORD PTR [rip+0x2e5f]        # 3fb8 <micro_native_bpf_map_lookup_elem@Base>
    1159:	48 85 c0             	test   rax,rax
    115c:	74 09                	je     1167 <map_percpu_hash_counter+0x67>
    115e:	4c 8b 20             	mov    r12,QWORD PTR [rax]
    1161:	49 ff c4             	inc    r12
    1164:	4c 89 20             	mov    QWORD PTR [rax],r12
    1167:	4d 89 27             	mov    QWORD PTR [r15],r12
    116a:	b8 02 00 00 00       	mov    eax,0x2
    116f:	48 83 c4 18          	add    rsp,0x18
    1173:	5b                   	pop    rbx
    1174:	41 5c                	pop    r12
    1176:	41 5e                	pop    r14
    1178:	41 5f                	pop    r15
    117a:	c3                   	ret

Disassembly of section .fini:

000000000000117c <_fini>:
    117c:	f3 0f 1e fa          	endbr64
    1180:	48 83 ec 08          	sub    rsp,0x8
    1184:	48 83 c4 08          	add    rsp,0x8
    1188:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 10 00 00 00 	sub    rsp,0x10
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	31 c0                	xor    eax,eax
  1a:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  1e:	4c 8b 6f 00          	mov    r13,QWORD PTR [rdi+0x0]
  22:	4c 89 ef             	mov    rdi,r13
  25:	48 83 c7 08          	add    rdi,0x8
  29:	48 39 f7             	cmp    rdi,rsi
  2c:	0f 87 bd 00 00 00    	ja     0xef
  32:	bf 07 00 00 00       	mov    edi,0x7
  37:	89 7d fc             	mov    DWORD PTR [rbp-0x4],edi
  3a:	45 31 f6             	xor    r14d,r14d
  3d:	4c 89 75 f0          	mov    QWORD PTR [rbp-0x10],r14
  41:	48 89 eb             	mov    rbx,rbp
  44:	48 83 c3 fc          	add    rbx,0xfffffffffffffffc
  48:	48 89 ea             	mov    rdx,rbp
  4b:	48 83 c2 f0          	add    rdx,0xfffffffffffffff0
  4f:	48 bf 00 7c 27 47 84 	movabs rdi,0xffff8c8447277c00
  56:	8c ff ff 
  59:	48 89 de             	mov    rsi,rbx
  5c:	31 c9                	xor    ecx,ecx
  5e:	e8 49 85 ec f9       	call   0xfffffffff9ec85ac
  63:	48 bf 00 7c 27 47 84 	movabs rdi,0xffff8c8447277c00
  6a:	8c ff ff 
  6d:	48 89 de             	mov    rsi,rbx
  70:	e8 67 5c ec f9       	call   0xfffffffff9ec5cdc
  75:	48 85 c0             	test   rax,rax
  78:	74 11                	je     0x8b
  7a:	48 83 c0 38          	add    rax,0x38
  7e:	48 8b 40 00          	mov    rax,QWORD PTR [rax+0x0]
  82:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
  89:	2b bd 
  8b:	48 85 c0             	test   rax,rax
  8e:	74 0c                	je     0x9c
  90:	4c 8b 70 00          	mov    r14,QWORD PTR [rax+0x0]
  94:	49 83 c6 01          	add    r14,0x1
  98:	4c 89 70 00          	mov    QWORD PTR [rax+0x0],r14
  9c:	4c 89 f7             	mov    rdi,r14
  9f:	48 c1 ef 38          	shr    rdi,0x38
  a3:	41 88 7d 07          	mov    BYTE PTR [r13+0x7],dil
  a7:	4c 89 f7             	mov    rdi,r14
  aa:	48 c1 ef 30          	shr    rdi,0x30
  ae:	41 88 7d 06          	mov    BYTE PTR [r13+0x6],dil
  b2:	4c 89 f7             	mov    rdi,r14
  b5:	48 c1 ef 28          	shr    rdi,0x28
  b9:	41 88 7d 05          	mov    BYTE PTR [r13+0x5],dil
  bd:	4c 89 f7             	mov    rdi,r14
  c0:	48 c1 ef 20          	shr    rdi,0x20
  c4:	41 88 7d 04          	mov    BYTE PTR [r13+0x4],dil
  c8:	4c 89 f7             	mov    rdi,r14
  cb:	48 c1 ef 18          	shr    rdi,0x18
  cf:	41 88 7d 03          	mov    BYTE PTR [r13+0x3],dil
  d3:	4c 89 f7             	mov    rdi,r14
  d6:	48 c1 ef 10          	shr    rdi,0x10
  da:	41 88 7d 02          	mov    BYTE PTR [r13+0x2],dil
  de:	45 88 75 00          	mov    BYTE PTR [r13+0x0],r14b
  e2:	49 c1 ee 08          	shr    r14,0x8
  e6:	45 88 75 01          	mov    BYTE PTR [r13+0x1],r14b
  ea:	b8 02 00 00 00       	mov    eax,0x2
  ef:	41 5e                	pop    r14
  f1:	41 5d                	pop    r13
  f3:	5b                   	pop    rbx
  f4:	c9                   	leave
  f5:	e9 12 2d a1 fa       	jmp    0xfffffffffaa12e0c
```

## llvmbpf JIT ASM
```asm
not captured
```
