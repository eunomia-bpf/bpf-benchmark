# multi_map_policy

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 a9 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fa9]        # 3fb8 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 46 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f46]        # 3fa0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <multi_map_policy>:
    1100:	55                   	push   rbp
    1101:	41 57                	push   r15
    1103:	41 56                	push   r14
    1105:	41 55                	push   r13
    1107:	41 54                	push   r12
    1109:	53                   	push   rbx
    110a:	48 83 ec 28          	sub    rsp,0x28
    110e:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    1111:	49 8d 4d 08          	lea    rcx,[r13+0x8]
    1115:	31 c0                	xor    eax,eax
    1117:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    111b:	0f 87 e3 00 00 00    	ja     1204 <multi_map_policy+0x104>
    1121:	c7 44 24 0c 03 00 00 	mov    DWORD PTR [rsp+0xc],0x3
    1128:	00 
    1129:	48 b8 11 00 ff ee dd 	movabs rax,0xaabbccddeeff0011
    1130:	cc bb aa 
    1133:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    1138:	4c 8b 35 89 2e 00 00 	mov    r14,QWORD PTR [rip+0x2e89]        # 3fc8 <policy_array@@Base-0x50>
    113f:	48 8b 2d 7a 2e 00 00 	mov    rbp,QWORD PTR [rip+0x2e7a]        # 3fc0 <micro_native_bpf_map_update_elem@Base>
    1146:	31 db                	xor    ebx,ebx
    1148:	4c 8d 7c 24 0c       	lea    r15,[rsp+0xc]
    114d:	4c 8d 64 24 20       	lea    r12,[rsp+0x20]
    1152:	4c 89 f7             	mov    rdi,r14
    1155:	4c 89 fe             	mov    rsi,r15
    1158:	4c 89 e2             	mov    rdx,r12
    115b:	31 c9                	xor    ecx,ecx
    115d:	ff d5                	call   rbp
    115f:	48 b8 78 56 34 12 78 	movabs rax,0x1234567812345678
    1166:	56 34 12 
    1169:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    116e:	48 8b 3d 33 2e 00 00 	mov    rdi,QWORD PTR [rip+0x2e33]        # 3fa8 <meta_hash@@Base-0x90>
    1175:	48 8d 54 24 18       	lea    rdx,[rsp+0x18]
    117a:	4c 89 e6             	mov    rsi,r12
    117d:	31 c9                	xor    ecx,ecx
    117f:	ff d5                	call   rbp
    1181:	c7 44 24 08 00 00 00 	mov    DWORD PTR [rsp+0x8],0x0
    1188:	00 
    1189:	48 c7 44 24 10 00 00 	mov    QWORD PTR [rsp+0x10],0x0
    1190:	00 00 
    1192:	48 8b 3d 37 2e 00 00 	mov    rdi,QWORD PTR [rip+0x2e37]        # 3fd0 <counter_pcpu@@Base-0x88>
    1199:	48 8d 74 24 08       	lea    rsi,[rsp+0x8]
    119e:	48 8d 54 24 10       	lea    rdx,[rsp+0x10]
    11a3:	31 c9                	xor    ecx,ecx
    11a5:	ff d5                	call   rbp
    11a7:	4c 89 f7             	mov    rdi,r14
    11aa:	4c 89 fe             	mov    rsi,r15
    11ad:	ff 15 fd 2d 00 00    	call   QWORD PTR [rip+0x2dfd]        # 3fb0 <micro_native_bpf_map_lookup_elem@Base>
    11b3:	48 85 c0             	test   rax,rax
    11b6:	74 13                	je     11cb <multi_map_policy+0xcb>
    11b8:	48 8b 3d e9 2d 00 00 	mov    rdi,QWORD PTR [rip+0x2de9]        # 3fa8 <meta_hash@@Base-0x90>
    11bf:	48 89 c6             	mov    rsi,rax
    11c2:	ff 15 e8 2d 00 00    	call   QWORD PTR [rip+0x2de8]        # 3fb0 <micro_native_bpf_map_lookup_elem@Base>
    11c8:	48 89 c3             	mov    rbx,rax
    11cb:	48 8b 3d fe 2d 00 00 	mov    rdi,QWORD PTR [rip+0x2dfe]        # 3fd0 <counter_pcpu@@Base-0x88>
    11d2:	48 8d 74 24 08       	lea    rsi,[rsp+0x8]
    11d7:	ff 15 d3 2d 00 00    	call   QWORD PTR [rip+0x2dd3]        # 3fb0 <micro_native_bpf_map_lookup_elem@Base>
    11dd:	48 85 c0             	test   rax,rax
    11e0:	74 0d                	je     11ef <multi_map_policy+0xef>
    11e2:	48 85 db             	test   rbx,rbx
    11e5:	74 08                	je     11ef <multi_map_policy+0xef>
    11e7:	48 8b 0b             	mov    rcx,QWORD PTR [rbx]
    11ea:	48 89 08             	mov    QWORD PTR [rax],rcx
    11ed:	eb 0c                	jmp    11fb <multi_map_policy+0xfb>
    11ef:	48 85 c0             	test   rax,rax
    11f2:	74 05                	je     11f9 <multi_map_policy+0xf9>
    11f4:	48 8b 08             	mov    rcx,QWORD PTR [rax]
    11f7:	eb 02                	jmp    11fb <multi_map_policy+0xfb>
    11f9:	31 c9                	xor    ecx,ecx
    11fb:	49 89 4d 00          	mov    QWORD PTR [r13+0x0],rcx
    11ff:	b8 02 00 00 00       	mov    eax,0x2
    1204:	48 83 c4 28          	add    rsp,0x28
    1208:	5b                   	pop    rbx
    1209:	41 5c                	pop    r12
    120b:	41 5d                	pop    r13
    120d:	41 5e                	pop    r14
    120f:	41 5f                	pop    r15
    1211:	5d                   	pop    rbp
    1212:	c3                   	ret

Disassembly of section .fini:

0000000000001214 <_fini>:
    1214:	f3 0f 1e fa          	endbr64
    1218:	48 83 ec 08          	sub    rsp,0x8
    121c:	48 83 c4 08          	add    rsp,0x8
    1220:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 28 00 00 00 	sub    rsp,0x28
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	4c 8b 7f 00          	mov    r15,QWORD PTR [rdi+0x0]
  24:	4c 89 ff             	mov    rdi,r15
  27:	48 83 c7 08          	add    rdi,0x8
  2b:	48 39 f7             	cmp    rdi,rsi
  2e:	0f 87 82 01 00 00    	ja     0x1b6
  34:	bf 03 00 00 00       	mov    edi,0x3
  39:	89 7d fc             	mov    DWORD PTR [rbp-0x4],edi
  3c:	48 bf 11 00 ff ee dd 	movabs rdi,0xaabbccddeeff0011
  43:	cc bb aa 
  46:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
  4a:	49 89 ed             	mov    r13,rbp
  4d:	49 83 c5 fc          	add    r13,0xfffffffffffffffc
  51:	49 89 ee             	mov    r14,rbp
  54:	49 83 c6 f0          	add    r14,0xfffffffffffffff0
  58:	31 db                	xor    ebx,ebx
  5a:	48 bf 00 84 0a 45 84 	movabs rdi,0xffff8c84450a8400
  61:	8c ff ff 
  64:	4c 89 ee             	mov    rsi,r13
  67:	4c 89 f2             	mov    rdx,r14
  6a:	31 c9                	xor    ecx,ecx
  6c:	e8 33 ae ec f9       	call   0xfffffffff9ecaea4
  71:	48 bf 78 56 34 12 78 	movabs rdi,0x1234567812345678
  78:	56 34 12 
  7b:	48 89 7d e8          	mov    QWORD PTR [rbp-0x18],rdi
  7f:	48 89 ea             	mov    rdx,rbp
  82:	48 83 c2 e8          	add    rdx,0xffffffffffffffe8
  86:	48 bf 00 90 2e 47 84 	movabs rdi,0xffff8c84472e9000
  8d:	8c ff ff 
  90:	4c 89 f6             	mov    rsi,r14
  93:	31 c9                	xor    ecx,ecx
  95:	e8 aa 81 ec f9       	call   0xfffffffff9ec8244
  9a:	89 5d e4             	mov    DWORD PTR [rbp-0x1c],ebx
  9d:	48 89 5d d8          	mov    QWORD PTR [rbp-0x28],rbx
  a1:	48 89 ee             	mov    rsi,rbp
  a4:	48 83 c6 e4          	add    rsi,0xffffffffffffffe4
  a8:	48 89 ea             	mov    rdx,rbp
  ab:	48 83 c2 d8          	add    rdx,0xffffffffffffffd8
  af:	48 bf 00 3c 1a 41 84 	movabs rdi,0xffff8c84411a3c00
  b6:	8c ff ff 
  b9:	31 c9                	xor    ecx,ecx
  bb:	e8 e4 ad ec f9       	call   0xfffffffff9ecaea4
  c0:	48 bf 00 84 0a 45 84 	movabs rdi,0xffff8c84450a8400
  c7:	8c ff ff 
  ca:	4c 89 ee             	mov    rsi,r13
  cd:	48 81 c7 30 01 00 00 	add    rdi,0x130
  d4:	8b 46 00             	mov    eax,DWORD PTR [rsi+0x0]
  d7:	48 83 f8 10          	cmp    rax,0x10
  db:	73 09                	jae    0xe6
  dd:	48 c1 e0 03          	shl    rax,0x3
  e1:	48 01 f8             	add    rax,rdi
  e4:	eb 02                	jmp    0xe8
  e6:	31 c0                	xor    eax,eax
  e8:	48 85 c0             	test   rax,rax
  eb:	74 1e                	je     0x10b
  ed:	48 bf 00 90 2e 47 84 	movabs rdi,0xffff8c84472e9000
  f4:	8c ff ff 
  f7:	48 89 c6             	mov    rsi,rax
  fa:	e8 45 58 ec f9       	call   0xfffffffff9ec5944
  ff:	48 85 c0             	test   rax,rax
 102:	74 04                	je     0x108
 104:	48 83 c0 38          	add    rax,0x38
 108:	48 89 c3             	mov    rbx,rax
 10b:	48 89 ee             	mov    rsi,rbp
 10e:	48 83 c6 e4          	add    rsi,0xffffffffffffffe4
 112:	48 bf 00 3c 1a 41 84 	movabs rdi,0xffff8c84411a3c00
 119:	8c ff ff 
 11c:	48 81 c7 30 01 00 00 	add    rdi,0x130
 123:	8b 46 00             	mov    eax,DWORD PTR [rsi+0x0]
 126:	48 83 f8 08          	cmp    rax,0x8
 12a:	73 16                	jae    0x142
 12c:	48 c1 e0 03          	shl    rax,0x3
 130:	48 01 f8             	add    rax,rdi
 133:	48 8b 40 00          	mov    rax,QWORD PTR [rax+0x0]
 137:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
 13e:	2b bd 
 140:	eb 02                	jmp    0x144
 142:	31 c0                	xor    eax,eax
 144:	48 85 c0             	test   rax,rax
 147:	74 0f                	je     0x158
 149:	48 85 db             	test   rbx,rbx
 14c:	74 0a                	je     0x158
 14e:	48 8b 7b 00          	mov    rdi,QWORD PTR [rbx+0x0]
 152:	48 89 78 00          	mov    QWORD PTR [rax+0x0],rdi
 156:	eb 0b                	jmp    0x163
 158:	31 ff                	xor    edi,edi
 15a:	48 85 c0             	test   rax,rax
 15d:	74 04                	je     0x163
 15f:	48 8b 78 00          	mov    rdi,QWORD PTR [rax+0x0]
 163:	48 89 fe             	mov    rsi,rdi
 166:	48 c1 ee 38          	shr    rsi,0x38
 16a:	41 88 77 07          	mov    BYTE PTR [r15+0x7],sil
 16e:	48 89 fe             	mov    rsi,rdi
 171:	48 c1 ee 30          	shr    rsi,0x30
 175:	41 88 77 06          	mov    BYTE PTR [r15+0x6],sil
 179:	48 89 fe             	mov    rsi,rdi
 17c:	48 c1 ee 28          	shr    rsi,0x28
 180:	41 88 77 05          	mov    BYTE PTR [r15+0x5],sil
 184:	48 89 fe             	mov    rsi,rdi
 187:	48 c1 ee 20          	shr    rsi,0x20
 18b:	41 88 77 04          	mov    BYTE PTR [r15+0x4],sil
 18f:	48 89 fe             	mov    rsi,rdi
 192:	48 c1 ee 18          	shr    rsi,0x18
 196:	41 88 77 03          	mov    BYTE PTR [r15+0x3],sil
 19a:	48 89 fe             	mov    rsi,rdi
 19d:	48 c1 ee 10          	shr    rsi,0x10
 1a1:	41 88 77 02          	mov    BYTE PTR [r15+0x2],sil
 1a5:	41 88 7f 00          	mov    BYTE PTR [r15+0x0],dil
 1a9:	48 c1 ef 08          	shr    rdi,0x8
 1ad:	41 88 7f 01          	mov    BYTE PTR [r15+0x1],dil
 1b1:	b8 02 00 00 00       	mov    eax,0x2
 1b6:	41 5f                	pop    r15
 1b8:	41 5e                	pop    r14
 1ba:	41 5d                	pop    r13
 1bc:	5b                   	pop    rbx
 1bd:	c9                   	leave
 1be:	e9 b1 28 a1 fa       	jmp    0xfffffffffaa12a74
```

## llvmbpf JIT ASM
```asm
not captured
```
