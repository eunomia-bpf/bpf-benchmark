# map_hash_str_key

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb1]        # 3fc0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 56 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f56]        # 3fb0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <map_hash_str_key>:
    1100:	41 57                	push   r15
    1102:	41 56                	push   r14
    1104:	41 54                	push   r12
    1106:	53                   	push   rbx
    1107:	48 83 ec 18          	sub    rsp,0x18
    110b:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    110e:	49 8d 4f 08          	lea    rcx,[r15+0x8]
    1112:	31 c0                	xor    eax,eax
    1114:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1118:	77 68                	ja     1182 <map_hash_str_key+0x82>
    111a:	48 b8 68 2d 6b 65 79 	movabs rax,0x30302d79656b2d68
    1121:	2d 30 30 
    1124:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    1129:	48 b8 62 70 66 2d 62 	movabs rax,0x636e65622d667062
    1130:	65 6e 63 
    1133:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
    1138:	48 b8 ef be ad de ce 	movabs rax,0xfeedfacedeadbeef
    113f:	fa ed fe 
    1142:	48 89 04 24          	mov    QWORD PTR [rsp],rax
    1146:	48 8b 1d 83 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2e83]        # 3fd0 <str_hash@@Base-0x48>
    114d:	45 31 e4             	xor    r12d,r12d
    1150:	4c 8d 74 24 08       	lea    r14,[rsp+0x8]
    1155:	48 89 e2             	mov    rdx,rsp
    1158:	48 89 df             	mov    rdi,rbx
    115b:	4c 89 f6             	mov    rsi,r14
    115e:	31 c9                	xor    ecx,ecx
    1160:	ff 15 62 2e 00 00    	call   QWORD PTR [rip+0x2e62]        # 3fc8 <micro_native_bpf_map_update_elem@Base>
    1166:	48 89 df             	mov    rdi,rbx
    1169:	4c 89 f6             	mov    rsi,r14
    116c:	ff 15 46 2e 00 00    	call   QWORD PTR [rip+0x2e46]        # 3fb8 <micro_native_bpf_map_lookup_elem@Base>
    1172:	48 85 c0             	test   rax,rax
    1175:	74 03                	je     117a <map_hash_str_key+0x7a>
    1177:	4c 8b 20             	mov    r12,QWORD PTR [rax]
    117a:	4d 89 27             	mov    QWORD PTR [r15],r12
    117d:	b8 02 00 00 00       	mov    eax,0x2
    1182:	48 83 c4 18          	add    rsp,0x18
    1186:	5b                   	pop    rbx
    1187:	41 5c                	pop    r12
    1189:	41 5e                	pop    r14
    118b:	41 5f                	pop    r15
    118d:	c3                   	ret

Disassembly of section .fini:

0000000000001190 <_fini>:
    1190:	f3 0f 1e fa          	endbr64
    1194:	48 83 ec 08          	sub    rsp,0x8
    1198:	48 83 c4 08          	add    rsp,0x8
    119c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	31 c0                	xor    eax,eax
  1a:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  1e:	4c 8b 6f 00          	mov    r13,QWORD PTR [rdi+0x0]
  22:	4c 89 ef             	mov    rdi,r13
  25:	48 83 c7 08          	add    rdi,0x8
  29:	48 39 f7             	cmp    rdi,rsi
  2c:	0f 87 c6 00 00 00    	ja     0xf8
  32:	48 bf 68 2d 6b 65 79 	movabs rdi,0x30302d79656b2d68
  39:	2d 30 30 
  3c:	48 89 7d f8          	mov    QWORD PTR [rbp-0x8],rdi
  40:	48 bf 62 70 66 2d 62 	movabs rdi,0x636e65622d667062
  47:	65 6e 63 
  4a:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
  4e:	48 bf ef be ad de ce 	movabs rdi,0xfeedfacedeadbeef
  55:	fa ed fe 
  58:	48 89 7d e8          	mov    QWORD PTR [rbp-0x18],rdi
  5c:	48 89 eb             	mov    rbx,rbp
  5f:	48 83 c3 f0          	add    rbx,0xfffffffffffffff0
  63:	48 89 ea             	mov    rdx,rbp
  66:	48 83 c2 e8          	add    rdx,0xffffffffffffffe8
  6a:	45 31 f6             	xor    r14d,r14d
  6d:	48 bf 00 9c 2e 47 84 	movabs rdi,0xffff8c84472e9c00
  74:	8c ff ff 
  77:	48 89 de             	mov    rsi,rbx
  7a:	31 c9                	xor    ecx,ecx
  7c:	e8 17 85 ec f9       	call   0xfffffffff9ec8598
  81:	48 bf 00 9c 2e 47 84 	movabs rdi,0xffff8c84472e9c00
  88:	8c ff ff 
  8b:	48 89 de             	mov    rsi,rbx
  8e:	e8 05 5c ec f9       	call   0xfffffffff9ec5c98
  93:	48 85 c0             	test   rax,rax
  96:	74 04                	je     0x9c
  98:	48 83 c0 40          	add    rax,0x40
  9c:	48 85 c0             	test   rax,rax
  9f:	74 04                	je     0xa5
  a1:	4c 8b 70 00          	mov    r14,QWORD PTR [rax+0x0]
  a5:	4c 89 f7             	mov    rdi,r14
  a8:	48 c1 ef 38          	shr    rdi,0x38
  ac:	41 88 7d 07          	mov    BYTE PTR [r13+0x7],dil
  b0:	4c 89 f7             	mov    rdi,r14
  b3:	48 c1 ef 30          	shr    rdi,0x30
  b7:	41 88 7d 06          	mov    BYTE PTR [r13+0x6],dil
  bb:	4c 89 f7             	mov    rdi,r14
  be:	48 c1 ef 28          	shr    rdi,0x28
  c2:	41 88 7d 05          	mov    BYTE PTR [r13+0x5],dil
  c6:	4c 89 f7             	mov    rdi,r14
  c9:	48 c1 ef 20          	shr    rdi,0x20
  cd:	41 88 7d 04          	mov    BYTE PTR [r13+0x4],dil
  d1:	4c 89 f7             	mov    rdi,r14
  d4:	48 c1 ef 18          	shr    rdi,0x18
  d8:	41 88 7d 03          	mov    BYTE PTR [r13+0x3],dil
  dc:	4c 89 f7             	mov    rdi,r14
  df:	48 c1 ef 10          	shr    rdi,0x10
  e3:	41 88 7d 02          	mov    BYTE PTR [r13+0x2],dil
  e7:	45 88 75 00          	mov    BYTE PTR [r13+0x0],r14b
  eb:	49 c1 ee 08          	shr    r14,0x8
  ef:	45 88 75 01          	mov    BYTE PTR [r13+0x1],r14b
  f3:	b8 02 00 00 00       	mov    eax,0x2
  f8:	41 5e                	pop    r14
  fa:	41 5d                	pop    r13
  fc:	5b                   	pop    rbx
  fd:	c9                   	leave
  fe:	e9 c5 2c a1 fa       	jmp    0xfffffffffaa12dc8
```

## llvmbpf JIT ASM
```asm
not captured
```
