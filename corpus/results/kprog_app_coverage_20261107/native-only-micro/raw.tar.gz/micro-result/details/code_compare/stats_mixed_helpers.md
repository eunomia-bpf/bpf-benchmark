# stats_mixed_helpers

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 a1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fa1]        # 3fb0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 a2 2f 00 00    	jmp    QWORD PTR [rip+0x2fa2]        # 3fd8 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 36 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f36]        # 3f90 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 35 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f35]        # 3fd0 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 12 2f 00 00 	cmp    QWORD PTR [rip+0x2f12],0x0        # 3fd8 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <stats_mixed_helpers>:
    1100:	55                   	push   rbp
    1101:	41 57                	push   r15
    1103:	41 56                	push   r14
    1105:	41 55                	push   r13
    1107:	41 54                	push   r12
    1109:	53                   	push   rbx
    110a:	48 83 ec 18          	sub    rsp,0x18
    110e:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    1111:	49 8d 4d 08          	lea    rcx,[r13+0x8]
    1115:	31 c0                	xor    eax,eax
    1117:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    111b:	0f 87 a4 00 00 00    	ja     11c5 <stats_mixed_helpers+0xc5>
    1121:	ff 15 81 2e 00 00    	call   QWORD PTR [rip+0x2e81]        # 3fa8 <micro_native_bpf_get_current_pid_tgid@Base>
    1127:	83 e0 3f             	and    eax,0x3f
    112a:	89 04 24             	mov    DWORD PTR [rsp],eax
    112d:	ff 15 65 2e 00 00    	call   QWORD PTR [rip+0x2e65]        # 3f98 <micro_native_bpf_get_smp_processor_id@Base>
    1133:	83 e0 3f             	and    eax,0x3f
    1136:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    113a:	ff 15 a0 2e 00 00    	call   QWORD PTR [rip+0x2ea0]        # 3fe0 <micro_native_bpf_get_current_uid_gid@Base>
    1140:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    1145:	48 8b 3d 74 2e 00 00 	mov    rdi,QWORD PTR [rip+0x2e74]        # 3fc0 <stats_h@@Base-0x58>
    114c:	48 8b 1d 65 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2e65]        # 3fb8 <micro_native_bpf_map_update_elem@Base>
    1153:	31 ed                	xor    ebp,ebp
    1155:	48 89 e6             	mov    rsi,rsp
    1158:	48 8d 54 24 10       	lea    rdx,[rsp+0x10]
    115d:	31 c9                	xor    ecx,ecx
    115f:	ff d3                	call   rbx
    1161:	48 c7 44 24 08 01 00 	mov    QWORD PTR [rsp+0x8],0x1
    1168:	00 00 
    116a:	4c 8b 3d 57 2e 00 00 	mov    r15,QWORD PTR [rip+0x2e57]        # 3fc8 <rate_pcpu@@Base-0x70>
    1171:	4c 8d 64 24 04       	lea    r12,[rsp+0x4]
    1176:	48 8d 54 24 08       	lea    rdx,[rsp+0x8]
    117b:	4c 89 ff             	mov    rdi,r15
    117e:	4c 89 e6             	mov    rsi,r12
    1181:	31 c9                	xor    ecx,ecx
    1183:	ff d3                	call   rbx
    1185:	4c 8b 35 14 2e 00 00 	mov    r14,QWORD PTR [rip+0x2e14]        # 3fa0 <micro_native_bpf_map_lookup_elem@Base>
    118c:	48 8b 3d 2d 2e 00 00 	mov    rdi,QWORD PTR [rip+0x2e2d]        # 3fc0 <stats_h@@Base-0x58>
    1193:	48 89 e6             	mov    rsi,rsp
    1196:	41 ff d6             	call   r14
    1199:	48 89 c3             	mov    rbx,rax
    119c:	4c 89 ff             	mov    rdi,r15
    119f:	4c 89 e6             	mov    rsi,r12
    11a2:	41 ff d6             	call   r14
    11a5:	48 85 db             	test   rbx,rbx
    11a8:	74 03                	je     11ad <stats_mixed_helpers+0xad>
    11aa:	48 8b 2b             	mov    rbp,QWORD PTR [rbx]
    11ad:	48 85 c0             	test   rax,rax
    11b0:	74 05                	je     11b7 <stats_mixed_helpers+0xb7>
    11b2:	48 8b 00             	mov    rax,QWORD PTR [rax]
    11b5:	eb 02                	jmp    11b9 <stats_mixed_helpers+0xb9>
    11b7:	31 c0                	xor    eax,eax
    11b9:	48 31 e8             	xor    rax,rbp
    11bc:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
    11c0:	b8 02 00 00 00       	mov    eax,0x2
    11c5:	48 83 c4 18          	add    rsp,0x18
    11c9:	5b                   	pop    rbx
    11ca:	41 5c                	pop    r12
    11cc:	41 5d                	pop    r13
    11ce:	41 5e                	pop    r14
    11d0:	41 5f                	pop    r15
    11d2:	5d                   	pop    rbp
    11d3:	c3                   	ret

Disassembly of section .fini:

00000000000011d4 <_fini>:
    11d4:	f3 0f 1e fa          	endbr64
    11d8:	48 83 ec 08          	sub    rsp,0x8
    11dc:	48 83 c4 08          	add    rsp,0x8
    11e0:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	4c 8b 77 00          	mov    r14,QWORD PTR [rdi+0x0]
  24:	4c 89 f7             	mov    rdi,r14
  27:	48 83 c7 08          	add    rdi,0x8
  2b:	48 39 f7             	cmp    rdi,rsi
  2e:	0f 87 2f 01 00 00    	ja     0x163
  34:	e8 eb 7e eb f9       	call   0xfffffffff9eb7f24
  39:	48 83 e0 3f          	and    rax,0x3f
  3d:	89 45 fc             	mov    DWORD PTR [rbp-0x4],eax
  40:	48 c7 c0 34 10 2b bd 	mov    rax,0xffffffffbd2b1034
  47:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
  4e:	2b bd 
  50:	8b 40 00             	mov    eax,DWORD PTR [rax+0x0]
  53:	48 83 e0 3f          	and    rax,0x3f
  57:	89 45 f8             	mov    DWORD PTR [rbp-0x8],eax
  5a:	e8 95 80 eb f9       	call   0xfffffffff9eb80f4
  5f:	48 89 45 f0          	mov    QWORD PTR [rbp-0x10],rax
  63:	48 89 eb             	mov    rbx,rbp
  66:	48 83 c3 fc          	add    rbx,0xfffffffffffffffc
  6a:	48 89 ea             	mov    rdx,rbp
  6d:	48 83 c2 f0          	add    rdx,0xfffffffffffffff0
  71:	45 31 ff             	xor    r15d,r15d
  74:	48 bf 00 58 27 47 84 	movabs rdi,0xffff8c8447275800
  7b:	8c ff ff 
  7e:	48 89 de             	mov    rsi,rbx
  81:	31 c9                	xor    ecx,ecx
  83:	e8 2c 84 ec f9       	call   0xfffffffff9ec84b4
  88:	bf 01 00 00 00       	mov    edi,0x1
  8d:	48 89 7d e8          	mov    QWORD PTR [rbp-0x18],rdi
  91:	49 89 ed             	mov    r13,rbp
  94:	49 83 c5 f8          	add    r13,0xfffffffffffffff8
  98:	48 89 ea             	mov    rdx,rbp
  9b:	48 83 c2 e8          	add    rdx,0xffffffffffffffe8
  9f:	48 bf 00 54 27 47 84 	movabs rdi,0xffff8c8447275400
  a6:	8c ff ff 
  a9:	4c 89 ee             	mov    rsi,r13
  ac:	31 c9                	xor    ecx,ecx
  ae:	e8 d1 83 ec f9       	call   0xfffffffff9ec8484
  b3:	48 bf 00 58 27 47 84 	movabs rdi,0xffff8c8447275800
  ba:	8c ff ff 
  bd:	48 89 de             	mov    rsi,rbx
  c0:	e8 ef 5a ec f9       	call   0xfffffffff9ec5bb4
  c5:	48 85 c0             	test   rax,rax
  c8:	74 04                	je     0xce
  ca:	48 83 c0 38          	add    rax,0x38
  ce:	48 89 c3             	mov    rbx,rax
  d1:	48 bf 00 54 27 47 84 	movabs rdi,0xffff8c8447275400
  d8:	8c ff ff 
  db:	4c 89 ee             	mov    rsi,r13
  de:	e8 d1 5a ec f9       	call   0xfffffffff9ec5bb4
  e3:	48 85 c0             	test   rax,rax
  e6:	74 11                	je     0xf9
  e8:	48 83 c0 38          	add    rax,0x38
  ec:	48 8b 40 00          	mov    rax,QWORD PTR [rax+0x0]
  f0:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
  f7:	2b bd 
  f9:	31 ff                	xor    edi,edi
  fb:	48 85 db             	test   rbx,rbx
  fe:	74 04                	je     0x104
 100:	48 8b 7b 00          	mov    rdi,QWORD PTR [rbx+0x0]
 104:	48 85 c0             	test   rax,rax
 107:	74 04                	je     0x10d
 109:	4c 8b 78 00          	mov    r15,QWORD PTR [rax+0x0]
 10d:	49 31 ff             	xor    r15,rdi
 110:	4c 89 ff             	mov    rdi,r15
 113:	48 c1 ef 38          	shr    rdi,0x38
 117:	41 88 7e 07          	mov    BYTE PTR [r14+0x7],dil
 11b:	4c 89 ff             	mov    rdi,r15
 11e:	48 c1 ef 30          	shr    rdi,0x30
 122:	41 88 7e 06          	mov    BYTE PTR [r14+0x6],dil
 126:	4c 89 ff             	mov    rdi,r15
 129:	48 c1 ef 28          	shr    rdi,0x28
 12d:	41 88 7e 05          	mov    BYTE PTR [r14+0x5],dil
 131:	4c 89 ff             	mov    rdi,r15
 134:	48 c1 ef 20          	shr    rdi,0x20
 138:	41 88 7e 04          	mov    BYTE PTR [r14+0x4],dil
 13c:	4c 89 ff             	mov    rdi,r15
 13f:	48 c1 ef 18          	shr    rdi,0x18
 143:	41 88 7e 03          	mov    BYTE PTR [r14+0x3],dil
 147:	4c 89 ff             	mov    rdi,r15
 14a:	48 c1 ef 10          	shr    rdi,0x10
 14e:	41 88 7e 02          	mov    BYTE PTR [r14+0x2],dil
 152:	45 88 7e 00          	mov    BYTE PTR [r14+0x0],r15b
 156:	49 c1 ef 08          	shr    r15,0x8
 15a:	45 88 7e 01          	mov    BYTE PTR [r14+0x1],r15b
 15e:	b8 02 00 00 00       	mov    eax,0x2
 163:	41 5f                	pop    r15
 165:	41 5e                	pop    r14
 167:	41 5d                	pop    r13
 169:	5b                   	pop    rbx
 16a:	c9                   	leave
 16b:	e9 74 2b a1 fa       	jmp    0xfffffffffaa12ce4
```

## llvmbpf JIT ASM
```asm
not captured
```
