# map_percpu_array

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 b9 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fb9]        # 3fc8 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <completed.0>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 56 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f56]        # 3fb0 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <completed.0>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 55 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f55],0x0        # 4010 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 2d 2f 00 00 01 	mov    BYTE PTR [rip+0x2f2d],0x1        # 4010 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <map_percpu_array>:
    1100:	41 57                	push   r15
    1102:	41 56                	push   r14
    1104:	41 54                	push   r12
    1106:	53                   	push   rbx
    1107:	48 83 ec 18          	sub    rsp,0x18
    110b:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    110e:	49 8d 4f 08          	lea    rcx,[r15+0x8]
    1112:	31 c0                	xor    eax,eax
    1114:	48 3b 4f 08          	cmp    rcx,QWORD PTR [rdi+0x8]
    1118:	77 55                	ja     116f <map_percpu_array+0x6f>
    111a:	c7 44 24 0c 02 00 00 	mov    DWORD PTR [rsp+0xc],0x2
    1121:	00 
    1122:	48 b8 be ba fe ca ce 	movabs rax,0xfeedfacecafebabe
    1129:	fa ed fe 
    112c:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    1131:	48 8b 1d 88 2e 00 00 	mov    rbx,QWORD PTR [rip+0x2e88]        # 3fc0 <test_percpu@@Base-0x58>
    1138:	45 31 e4             	xor    r12d,r12d
    113b:	4c 8d 74 24 0c       	lea    r14,[rsp+0xc]
    1140:	48 8d 54 24 10       	lea    rdx,[rsp+0x10]
    1145:	48 89 df             	mov    rdi,rbx
    1148:	4c 89 f6             	mov    rsi,r14
    114b:	31 c9                	xor    ecx,ecx
    114d:	ff 15 7d 2e 00 00    	call   QWORD PTR [rip+0x2e7d]        # 3fd0 <micro_native_bpf_map_update_elem@Base>
    1153:	48 89 df             	mov    rdi,rbx
    1156:	4c 89 f6             	mov    rsi,r14
    1159:	ff 15 59 2e 00 00    	call   QWORD PTR [rip+0x2e59]        # 3fb8 <micro_native_bpf_map_lookup_elem@Base>
    115f:	48 85 c0             	test   rax,rax
    1162:	74 03                	je     1167 <map_percpu_array+0x67>
    1164:	4c 8b 20             	mov    r12,QWORD PTR [rax]
    1167:	4d 89 27             	mov    QWORD PTR [r15],r12
    116a:	b8 02 00 00 00       	mov    eax,0x2
    116f:	48 83 c4 18          	add    rsp,0x18
    1173:	5b                   	pop    rbx
    1174:	41 5c                	pop    r12
    1176:	41 5e                	pop    r14
    1178:	41 5f                	pop    r15
    117a:	c3                   	ret

Disassembly of section .fini:

000000000000117c <_fini>:
    117c:	f3 0f 1e fa          	endbr64
    1180:	48 83 ec 08          	sub    rsp,0x8
    1184:	48 83 c4 08          	add    rsp,0x8
    1188:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 10 00 00 00 	sub    rsp,0x10
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 db                	xor    ebx,ebx
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	4c 8b 77 00          	mov    r14,QWORD PTR [rdi+0x0]
  24:	4c 89 f7             	mov    rdi,r14
  27:	48 83 c7 08          	add    rdi,0x8
  2b:	48 39 f7             	cmp    rdi,rsi
  2e:	0f 87 c7 00 00 00    	ja     0xfb
  34:	bb 02 00 00 00       	mov    ebx,0x2
  39:	89 5d fc             	mov    DWORD PTR [rbp-0x4],ebx
  3c:	48 bf be ba fe ca ce 	movabs rdi,0xfeedfacecafebabe
  43:	fa ed fe 
  46:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
  4a:	49 89 ed             	mov    r13,rbp
  4d:	49 83 c5 fc          	add    r13,0xfffffffffffffffc
  51:	48 89 ea             	mov    rdx,rbp
  54:	48 83 c2 f0          	add    rdx,0xfffffffffffffff0
  58:	45 31 ff             	xor    r15d,r15d
  5b:	48 bf 00 e0 ab 40 84 	movabs rdi,0xffff8c8440abe000
  62:	8c ff ff 
  65:	4c 89 ee             	mov    rsi,r13
  68:	31 c9                	xor    ecx,ecx
  6a:	e8 8d b0 ec f9       	call   0xfffffffff9ecb0fc
  6f:	48 bf 00 e0 ab 40 84 	movabs rdi,0xffff8c8440abe000
  76:	8c ff ff 
  79:	4c 89 ee             	mov    rsi,r13
  7c:	48 81 c7 30 01 00 00 	add    rdi,0x130
  83:	8b 46 00             	mov    eax,DWORD PTR [rsi+0x0]
  86:	48 83 f8 04          	cmp    rax,0x4
  8a:	73 16                	jae    0xa2
  8c:	48 c1 e0 03          	shl    rax,0x3
  90:	48 01 f8             	add    rax,rdi
  93:	48 8b 40 00          	mov    rax,QWORD PTR [rax+0x0]
  97:	65 48 03 04 25 28 10 	add    rax,QWORD PTR gs:0xffffffffbd2b1028
  9e:	2b bd 
  a0:	eb 02                	jmp    0xa4
  a2:	31 c0                	xor    eax,eax
  a4:	48 85 c0             	test   rax,rax
  a7:	74 04                	je     0xad
  a9:	4c 8b 78 00          	mov    r15,QWORD PTR [rax+0x0]
  ad:	4c 89 ff             	mov    rdi,r15
  b0:	48 c1 ef 38          	shr    rdi,0x38
  b4:	41 88 7e 07          	mov    BYTE PTR [r14+0x7],dil
  b8:	4c 89 ff             	mov    rdi,r15
  bb:	48 c1 ef 30          	shr    rdi,0x30
  bf:	41 88 7e 06          	mov    BYTE PTR [r14+0x6],dil
  c3:	4c 89 ff             	mov    rdi,r15
  c6:	48 c1 ef 28          	shr    rdi,0x28
  ca:	41 88 7e 05          	mov    BYTE PTR [r14+0x5],dil
  ce:	4c 89 ff             	mov    rdi,r15
  d1:	48 c1 ef 20          	shr    rdi,0x20
  d5:	41 88 7e 04          	mov    BYTE PTR [r14+0x4],dil
  d9:	4c 89 ff             	mov    rdi,r15
  dc:	48 c1 ef 18          	shr    rdi,0x18
  e0:	41 88 7e 03          	mov    BYTE PTR [r14+0x3],dil
  e4:	4c 89 ff             	mov    rdi,r15
  e7:	48 c1 ef 10          	shr    rdi,0x10
  eb:	41 88 7e 02          	mov    BYTE PTR [r14+0x2],dil
  ef:	45 88 7e 00          	mov    BYTE PTR [r14+0x0],r15b
  f3:	49 c1 ef 08          	shr    r15,0x8
  f7:	45 88 7e 01          	mov    BYTE PTR [r14+0x1],r15b
  fb:	48 89 d8             	mov    rax,rbx
  fe:	41 5f                	pop    r15
 100:	41 5e                	pop    r14
 102:	41 5d                	pop    r13
 104:	5b                   	pop    rbx
 105:	c9                   	leave
 106:	e9 c1 2b a1 fa       	jmp    0xfffffffffaa12ccc
```

## llvmbpf JIT ASM
```asm
not captured
```
