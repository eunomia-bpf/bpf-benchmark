set -eu
D=/workspaces/.agent-state/kprog-lanes/C/micro-trusted-runtime
trap 'echo $? > "$D/build.exit"' EXIT
test "$(docker image inspect --format '{{.Id}}' bpf-benchmark/kprog-native-only:x86-current)" = sha256:a20b2981171de35a85d1827760701e157efa17347c8705374f146a5d7dbe1a90
docker build -t bpf-benchmark/kprog-micro-trusted:c-20261107 "$D/image-context"
docker image inspect bpf-benchmark/kprog-micro-trusted:c-20261107 > "$D/image.json"
