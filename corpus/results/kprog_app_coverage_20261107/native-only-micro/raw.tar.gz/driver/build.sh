set -eu
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/micro-trusted-runtime
trap 'echo $? > "$D/build.exit"' EXIT
cmake --build runner/build-llvmbpf --target trusted-native-loader -j4
python3 - <<'PY'
from pathlib import Path
import shutil,subprocess,json,hashlib
R=Path('/workspaces/repository');D=Path('/workspaces/.agent-state/kprog-lanes/C/micro-trusted-runtime');P=D/'image-context';P.mkdir(exist_ok=True)
pins={}
for name in ['runner/build-llvmbpf/micro_exec','micro/driver.py','runner/suites/micro.py']:
 src=R/name;dst=P/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);pins[name]=hashlib.sha256(src.read_bytes()).hexdigest()
base=json.loads(subprocess.check_output(['docker','image','inspect','bpf-benchmark/kprog-native-only:x86-current']))[0];assert base['Id']=='sha256:a20b2981171de35a85d1827760701e157efa17347c8705374f146a5d7dbe1a90'
(P/'Dockerfile').write_text('FROM '+base['Id']+'\n'+''.join('COPY '+n+' /workspaces/repository/'+n+'\n' for n in pins))
(D/'image-inputs.json').write_text(json.dumps(dict(base_id=base['Id'],files=pins),indent=2)+'\n')
PY
docker build -t bpf-benchmark/kprog-micro-trusted:c-20261107 "$D/image-context"
docker image inspect bpf-benchmark/kprog-micro-trusted:c-20261107 > "$D/image.json"
