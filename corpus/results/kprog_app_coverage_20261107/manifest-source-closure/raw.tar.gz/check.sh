set -eu
D=/workspaces/.agent-state/kprog-lanes/C/manifest-source-closure
trap 'echo $? > "$D/check.exit"' EXIT
cd /workspaces/repository
CLANG=/usr/lib/llvm-18/bin/clang python3 vendor/bpf/test_write_native_manifest.py -v
python3 - <<'Q'
from pathlib import Path
import json,hashlib
D=Path('/workspaces/.agent-state/kprog-lanes/C/manifest-source-closure');m=json.loads((D/'observations.json').read_text())
assert hashlib.sha256(Path('vendor/bpf/write_native_manifest.py').read_bytes()).hexdigest()==m['source_sha256']
for n,h in json.loads((D/'source-inputs.json').read_text()).items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
print('REUSED_CLOSED_SOURCE_SCAN',m['objects'],m['functions'],m['changed'],m['focus'])
Q
make -C kprog/tv manifest-check
