from pathlib import Path
import importlib.util,json,hashlib,subprocess,sys
R=Path('/workspaces/repository');D=Path(__file__).parent
sys.path.insert(0,str(R/'vendor/bpf'))
from write_native_manifest import scan_bpf_source_programs
spec=importlib.util.spec_from_file_location('prior_manifest',D/'before.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
rows=[];changed=[];errors=[]
for p in sorted((R/'vendor/build/x86/tetragon').glob('*.o')):
 try:
  old=prior.scan_bpf_source_programs(p);new=scan_bpf_source_programs(p)
 except SystemExit as exc:errors.append(dict(path=str(p),error=str(exc)));continue
 for name,item in new.items():
  before=old[name];row=dict(object=p.name,symbol=name,prior_bytes=before.bytecode_len,linked_bytes=item.bytecode_len,prior_helpers=sorted(before.helpers),linked_helpers=sorted(item.helpers));rows.append(row)
  if before!=item:changed.append(row)
assert not errors,errors
focus=[r for r in rows if r['object']=='bpf_execve_event_v61.o' and r['symbol']=='execve_send'];assert len(focus)==1 and focus[0]['prior_bytes']==10368 and focus[0]['linked_bytes']==11296,focus
args=['python3',str(R/'vendor/bpf/write_native_manifest.py'),'--app','tetragon','--llvm-nm','/usr/lib/llvm-18/bin/llvm-nm','--dedupe-program','last','--source-object-root',str(R/'vendor/build/x86/tetragon'),'--helper-disambiguate','174','--output',str(D/'manifest.json')]
for p in sorted((R/'vendor/build/native-bpf/x86/stage/tetragon').glob('*.native.o')):args+=['--object',str(p)]
# The generated manifest and native objects share their directory in the runtime package.
subprocess.run(args,check=True)
m=json.loads((D/'manifest.json').read_text())
for entry in m['objects']:entry['native_object']=Path(entry['native_object']).name
(D/'manifest.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
summary=dict(objects=len({r['object'] for r in rows}),functions=len(rows),changed=len(changed),focus=focus,changed_rows=changed,manifest_sha256=hashlib.sha256((D/'manifest.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((R/'vendor/bpf/write_native_manifest.py').read_bytes()).hexdigest())
(D/'observations.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'all-source-rows.json').write_text(json.dumps(rows,indent=2)+'\n');(D/'command.json').write_text(json.dumps(args,indent=2)+'\n')
print('SOURCE_CLOSURE',summary['objects'],summary['functions'],summary['changed'],focus,flush=True)
