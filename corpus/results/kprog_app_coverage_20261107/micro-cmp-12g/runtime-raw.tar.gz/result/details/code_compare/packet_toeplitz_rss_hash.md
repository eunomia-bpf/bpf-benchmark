# packet_toeplitz_rss_hash

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <packet_toeplitz_rss_hash_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <packet_toeplitz_rss_hash_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <packet_toeplitz_rss_hash_xdp+0x11>
    111b:	48 8d 7a 3e          	lea    rdi,[rdx+0x3e]
    111f:	48 39 f7             	cmp    rdi,rsi
    1122:	77 ed                	ja     1111 <packet_toeplitz_rss_hash_xdp+0x11>
    1124:	66 0f 38 f0 72 14    	movbe  si,WORD PTR [rdx+0x14]
    112a:	0f b7 f6             	movzx  esi,si
    112d:	81 fe 00 08 00 00    	cmp    esi,0x800
    1133:	75 dc                	jne    1111 <packet_toeplitz_rss_hash_xdp+0x11>
    1135:	0f b6 72 16          	movzx  esi,BYTE PTR [rdx+0x16]
    1139:	40 80 e6 0f          	and    sil,0xf
    113d:	40 80 fe 05          	cmp    sil,0x5
    1141:	75 ce                	jne    1111 <packet_toeplitz_rss_hash_xdp+0x11>
    1143:	80 7a 1f 06          	cmp    BYTE PTR [rdx+0x1f],0x6
    1147:	75 c8                	jne    1111 <packet_toeplitz_rss_hash_xdp+0x11>
    1149:	53                   	push   rbx
    114a:	48 8d 72 1f          	lea    rsi,[rdx+0x1f]
    114e:	48 89 d7             	mov    rdi,rdx
    1151:	48 83 c7 22          	add    rdi,0x22
    1155:	31 c0                	xor    eax,eax
    1157:	45 31 c0             	xor    r8d,r8d
    115a:	eb 37                	jmp    1193 <packet_toeplitz_rss_hash_xdp+0x93>
    115c:	bb c2 00 00 00       	mov    ebx,0xc2
    1161:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    1168:	0f 1f 84 00 00 00 00 
    116f:	00 
    1170:	c4 42 31 f7 d3       	shlx   r10d,r11d,r9d
    1175:	41 b3 08             	mov    r11b,0x8
    1178:	45 28 cb             	sub    r11b,r9b
    117b:	c4 62 23 f7 db       	shrx   r11d,ebx,r11d
    1180:	45 09 d3             	or     r11d,r10d
    1183:	44 31 d8             	xor    eax,r11d
    1186:	41 ff c0             	inc    r8d
    1189:	41 83 f8 68          	cmp    r8d,0x68
    118d:	0f 84 25 02 00 00    	je     13b8 <packet_toeplitz_rss_hash_xdp+0x2b8>
    1193:	45 89 c2             	mov    r10d,r8d
    1196:	41 c1 ea 03          	shr    r10d,0x3
    119a:	41 83 f8 1f          	cmp    r8d,0x1f
    119e:	76 20                	jbe    11c0 <packet_toeplitz_rss_hash_xdp+0xc0>
    11a0:	41 83 f8 3f          	cmp    r8d,0x3f
    11a4:	76 1a                	jbe    11c0 <packet_toeplitz_rss_hash_xdp+0xc0>
    11a6:	41 83 f8 4f          	cmp    r8d,0x4f
    11aa:	76 14                	jbe    11c0 <packet_toeplitz_rss_hash_xdp+0xc0>
    11ac:	49 89 f1             	mov    r9,rsi
    11af:	41 83 f8 5f          	cmp    r8d,0x5f
    11b3:	77 11                	ja     11c6 <packet_toeplitz_rss_hash_xdp+0xc6>
    11b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    11bc:	00 00 00 00 
    11c0:	45 89 d1             	mov    r9d,r10d
    11c3:	49 01 f9             	add    r9,rdi
    11c6:	45 0f b6 19          	movzx  r11d,BYTE PTR [r9]
    11ca:	45 89 c1             	mov    r9d,r8d
    11cd:	41 83 e1 07          	and    r9d,0x7
    11d1:	c4 42 31 f7 db       	shlx   r11d,r11d,r9d
    11d6:	45 84 db             	test   r11b,r11b
    11d9:	79 ab                	jns    1186 <packet_toeplitz_rss_hash_xdp+0x86>
    11db:	41 83 fa 05          	cmp    r10d,0x5
    11df:	7e 2f                	jle    1210 <packet_toeplitz_rss_hash_xdp+0x110>
    11e1:	41 83 fa 08          	cmp    r10d,0x8
    11e5:	7e 4e                	jle    1235 <packet_toeplitz_rss_hash_xdp+0x135>
    11e7:	41 83 fa 0a          	cmp    r10d,0xa
    11eb:	0f 8f 7c 00 00 00    	jg     126d <packet_toeplitz_rss_hash_xdp+0x16d>
    11f1:	41 83 fa 09          	cmp    r10d,0x9
    11f5:	0f 85 b9 00 00 00    	jne    12b4 <packet_toeplitz_rss_hash_xdp+0x1b4>
    11fb:	bb 43 00 00 00       	mov    ebx,0x43
    1200:	41 bb 00 3d 25 67    	mov    r11d,0x67253d00
    1206:	e9 e5 00 00 00       	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    120b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    1210:	41 83 fa 02          	cmp    r10d,0x2
    1214:	7f 3b                	jg     1251 <packet_toeplitz_rss_hash_xdp+0x151>
    1216:	45 85 d2             	test   r10d,r10d
    1219:	74 72                	je     128d <packet_toeplitz_rss_hash_xdp+0x18d>
    121b:	41 83 fa 01          	cmp    r10d,0x1
    121f:	0f 85 a9 00 00 00    	jne    12ce <packet_toeplitz_rss_hash_xdp+0x1ce>
    1225:	bb 25 00 00 00       	mov    ebx,0x25
    122a:	41 bb 00 da 56 5a    	mov    r11d,0x5a56da00
    1230:	e9 bb 00 00 00       	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    1235:	41 83 fa 06          	cmp    r10d,0x6
    1239:	74 45                	je     1280 <packet_toeplitz_rss_hash_xdp+0x180>
    123b:	41 83 fa 07          	cmp    r10d,0x7
    123f:	75 66                	jne    12a7 <packet_toeplitz_rss_hash_xdp+0x1a7>
    1241:	bb 25 00 00 00       	mov    ebx,0x25
    1246:	41 bb 00 67 41 c2    	mov    r11d,0xc2416700
    124c:	e9 9f 00 00 00       	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    1251:	41 83 fa 03          	cmp    r10d,0x3
    1255:	74 43                	je     129a <packet_toeplitz_rss_hash_xdp+0x19a>
    1257:	41 83 fa 04          	cmp    r10d,0x4
    125b:	75 7e                	jne    12db <packet_toeplitz_rss_hash_xdp+0x1db>
    125d:	bb c2 00 00 00       	mov    ebx,0xc2
    1262:	41 bb 00 0e 5b 25    	mov    r11d,0x255b0e00
    1268:	e9 83 00 00 00       	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    126d:	41 83 fa 0b          	cmp    r10d,0xb
    1271:	75 4e                	jne    12c1 <packet_toeplitz_rss_hash_xdp+0x1c1>
    1273:	bb 8f 00 00 00       	mov    ebx,0x8f
    1278:	41 bb 00 a3 43 3d    	mov    r11d,0x3d43a300
    127e:	eb 70                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    1280:	bb 67 00 00 00       	mov    ebx,0x67
    1285:	41 bb 00 41 c2 0e    	mov    r11d,0xec24100
    128b:	eb 63                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    128d:	bb da 00 00 00       	mov    ebx,0xda
    1292:	41 bb 00 56 5a 6d    	mov    r11d,0x6d5a5600
    1298:	eb 56                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    129a:	bb 0e 00 00 00       	mov    ebx,0xe
    129f:	41 bb 00 5b 25 da    	mov    r11d,0xda255b00
    12a5:	eb 49                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    12a7:	bb 3d 00 00 00       	mov    ebx,0x3d
    12ac:	41 bb 00 25 67 41    	mov    r11d,0x41672500
    12b2:	eb 3c                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    12b4:	bb a3 00 00 00       	mov    ebx,0xa3
    12b9:	41 bb 00 43 3d 25    	mov    r11d,0x253d4300
    12bf:	eb 2f                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    12c1:	bb b0 00 00 00       	mov    ebx,0xb0
    12c6:	41 bb 00 8f a3 43    	mov    r11d,0x43a38f00
    12cc:	eb 22                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    12ce:	bb 5b 00 00 00       	mov    ebx,0x5b
    12d3:	41 bb 00 25 da 56    	mov    r11d,0x56da2500
    12d9:	eb 15                	jmp    12f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
    12db:	bb 41 00 00 00       	mov    ebx,0x41
    12e0:	41 bb 00 c2 0e 5b    	mov    r11d,0x5b0ec200
    12e6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    12ed:	00 00 00 
    12f0:	41 09 db             	or     r11d,ebx
    12f3:	45 85 c9             	test   r9d,r9d
    12f6:	0f 84 87 fe ff ff    	je     1183 <packet_toeplitz_rss_hash_xdp+0x83>
    12fc:	bb 25 00 00 00       	mov    ebx,0x25
    1301:	41 83 fa 05          	cmp    r10d,0x5
    1305:	7e 1c                	jle    1323 <packet_toeplitz_rss_hash_xdp+0x223>
    1307:	41 83 fa 08          	cmp    r10d,0x8
    130b:	7e 35                	jle    1342 <packet_toeplitz_rss_hash_xdp+0x242>
    130d:	41 83 fa 0a          	cmp    r10d,0xa
    1311:	7f 63                	jg     1376 <packet_toeplitz_rss_hash_xdp+0x276>
    1313:	41 83 fa 09          	cmp    r10d,0x9
    1317:	75 77                	jne    1390 <packet_toeplitz_rss_hash_xdp+0x290>
    1319:	bb a3 00 00 00       	mov    ebx,0xa3
    131e:	e9 4d fe ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    1323:	41 83 fa 02          	cmp    r10d,0x2
    1327:	7f 33                	jg     135c <packet_toeplitz_rss_hash_xdp+0x25c>
    1329:	45 85 d2             	test   r10d,r10d
    132c:	0f 84 3e fe ff ff    	je     1170 <packet_toeplitz_rss_hash_xdp+0x70>
    1332:	41 83 fa 01          	cmp    r10d,0x1
    1336:	75 6c                	jne    13a4 <packet_toeplitz_rss_hash_xdp+0x2a4>
    1338:	bb 5b 00 00 00       	mov    ebx,0x5b
    133d:	e9 2e fe ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    1342:	41 83 fa 06          	cmp    r10d,0x6
    1346:	0f 84 24 fe ff ff    	je     1170 <packet_toeplitz_rss_hash_xdp+0x70>
    134c:	41 83 fa 07          	cmp    r10d,0x7
    1350:	75 34                	jne    1386 <packet_toeplitz_rss_hash_xdp+0x286>
    1352:	bb 3d 00 00 00       	mov    ebx,0x3d
    1357:	e9 14 fe ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    135c:	41 83 fa 03          	cmp    r10d,0x3
    1360:	0f 84 f6 fd ff ff    	je     115c <packet_toeplitz_rss_hash_xdp+0x5c>
    1366:	41 83 fa 04          	cmp    r10d,0x4
    136a:	75 42                	jne    13ae <packet_toeplitz_rss_hash_xdp+0x2ae>
    136c:	bb 41 00 00 00       	mov    ebx,0x41
    1371:	e9 fa fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    1376:	41 83 fa 0b          	cmp    r10d,0xb
    137a:	75 1e                	jne    139a <packet_toeplitz_rss_hash_xdp+0x29a>
    137c:	bb b0 00 00 00       	mov    ebx,0xb0
    1381:	e9 ea fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    1386:	bb 43 00 00 00       	mov    ebx,0x43
    138b:	e9 e0 fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    1390:	bb 8f 00 00 00       	mov    ebx,0x8f
    1395:	e9 d6 fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    139a:	bb d0 00 00 00       	mov    ebx,0xd0
    139f:	e9 cc fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    13a4:	bb 0e 00 00 00       	mov    ebx,0xe
    13a9:	e9 c2 fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    13ae:	bb 67 00 00 00       	mov    ebx,0x67
    13b3:	e9 b8 fd ff ff       	jmp    1170 <packet_toeplitz_rss_hash_xdp+0x70>
    13b8:	8b 72 26             	mov    esi,DWORD PTR [rdx+0x26]
    13bb:	0f b6 7a 2a          	movzx  edi,BYTE PTR [rdx+0x2a]
    13bf:	44 0f b6 42 2b       	movzx  r8d,BYTE PTR [rdx+0x2b]
    13c4:	44 0f b6 4a 2c       	movzx  r9d,BYTE PTR [rdx+0x2c]
    13c9:	44 0f b6 52 2d       	movzx  r10d,BYTE PTR [rdx+0x2d]
    13ce:	49 89 c3             	mov    r11,rax
    13d1:	49 c1 e3 20          	shl    r11,0x20
    13d5:	33 72 22             	xor    esi,DWORD PTR [rdx+0x22]
    13d8:	0f ce                	bswap  esi
    13da:	89 f2                	mov    edx,esi
    13dc:	31 c2                	xor    edx,eax
    13de:	4c 09 da             	or     rdx,r11
    13e1:	48 c1 e7 38          	shl    rdi,0x38
    13e5:	49 c1 e0 30          	shl    r8,0x30
    13e9:	49 09 f8             	or     r8,rdi
    13ec:	49 c1 e1 28          	shl    r9,0x28
    13f0:	4d 09 c1             	or     r9,r8
    13f3:	49 c1 e2 20          	shl    r10,0x20
    13f7:	4c 09 ce             	or     rsi,r9
    13fa:	4c 09 d6             	or     rsi,r10
    13fd:	83 e0 07             	and    eax,0x7
    1400:	8d 78 01             	lea    edi,[rax+0x1]
    1403:	c4 e2 c1 f7 fe       	shlx   rdi,rsi,rdi
    1408:	f6 d0                	not    al
    140a:	c4 e2 fb f7 c6       	shrx   rax,rsi,rax
    140f:	48 09 f8             	or     rax,rdi
    1412:	48 31 d0             	xor    rax,rdx
    1415:	48 89 01             	mov    QWORD PTR [rcx],rax
    1418:	b8 02 00 00 00       	mov    eax,0x2
    141d:	5b                   	pop    rbx
    141e:	c3                   	ret

Disassembly of section .fini:

0000000000001420 <_fini>:
    1420:	f3 0f 1e fa          	endbr64
    1424:	48 83 ec 08          	sub    rsp,0x8
    1428:	48 83 c4 08          	add    rsp,0x8
    142c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	53                   	push   rbx
   d:	41 55                	push   r13
   f:	41 56                	push   r14
  11:	31 c0                	xor    eax,eax
  13:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  17:	48 8b 7f 00          	mov    rdi,QWORD PTR [rdi+0x0]
  1b:	48 39 f7             	cmp    rdi,rsi
  1e:	0f 87 13 04 00 00    	ja     0x437
  24:	48 89 fa             	mov    rdx,rdi
  27:	48 83 c2 08          	add    rdx,0x8
  2b:	48 39 f2             	cmp    rdx,rsi
  2e:	0f 87 03 04 00 00    	ja     0x437
  34:	48 89 fa             	mov    rdx,rdi
  37:	48 83 c2 3e          	add    rdx,0x3e
  3b:	48 39 f2             	cmp    rdx,rsi
  3e:	0f 87 f3 03 00 00    	ja     0x437
  44:	48 0f b6 77 15       	movzx  rsi,BYTE PTR [rdi+0x15]
  49:	48 0f b6 57 14       	movzx  rdx,BYTE PTR [rdi+0x14]
  4e:	48 c1 e2 08          	shl    rdx,0x8
  52:	48 09 f2             	or     rdx,rsi
  55:	48 81 e2 ff ff 00 00 	and    rdx,0xffff
  5c:	48 81 fa 00 08 00 00 	cmp    rdx,0x800
  63:	0f 85 ce 03 00 00    	jne    0x437
  69:	48 0f b6 77 16       	movzx  rsi,BYTE PTR [rdi+0x16]
  6e:	48 83 e6 0f          	and    rsi,0xf
  72:	48 83 fe 05          	cmp    rsi,0x5
  76:	0f 85 bb 03 00 00    	jne    0x437
  7c:	48 0f b6 77 1f       	movzx  rsi,BYTE PTR [rdi+0x1f]
  81:	48 83 fe 06          	cmp    rsi,0x6
  85:	0f 85 ac 03 00 00    	jne    0x437
  8b:	48 89 fa             	mov    rdx,rdi
  8e:	48 83 c2 1f          	add    rdx,0x1f
  92:	31 f6                	xor    esi,esi
  94:	48 89 f9             	mov    rcx,rdi
  97:	48 83 c1 22          	add    rcx,0x22
  9b:	45 31 c0             	xor    r8d,r8d
  9e:	eb 35                	jmp    0xd5
  a0:	41 bd c2 00 00 00    	mov    r13d,0xc2
  a6:	bb 08 00 00 00       	mov    ebx,0x8
  ab:	48 29 c3             	sub    rbx,rax
  ae:	c4 42 e3 f7 ed       	shrx   r13,r13,rbx
  b3:	4d 09 f5             	or     r13,r14
  b6:	49 31 f5             	xor    r13,rsi
  b9:	4c 89 ee             	mov    rsi,r13
  bc:	49 83 c0 01          	add    r8,0x1
  c0:	4c 89 c0             	mov    rax,r8
  c3:	48 c1 e0 20          	shl    rax,0x20
  c7:	48 c1 e8 20          	shr    rax,0x20
  cb:	48 83 f8 68          	cmp    rax,0x68
  cf:	0f 84 4a 02 00 00    	je     0x31f
  d5:	4c 89 c0             	mov    rax,r8
  d8:	48 c1 e0 20          	shl    rax,0x20
  dc:	48 c1 e8 20          	shr    rax,0x20
  e0:	48 89 c3             	mov    rbx,rax
  e3:	48 c1 eb 03          	shr    rbx,0x3
  e7:	48 83 f8 1f          	cmp    rax,0x1f
  eb:	77 02                	ja     0xef
  ed:	eb 24                	jmp    0x113
  ef:	48 83 f8 3f          	cmp    rax,0x3f
  f3:	77 02                	ja     0xf7
  f5:	eb 1c                	jmp    0x113
  f7:	4c 89 c0             	mov    rax,r8
  fa:	48 c1 e0 20          	shl    rax,0x20
  fe:	48 c1 e8 20          	shr    rax,0x20
 102:	48 83 f8 4f          	cmp    rax,0x4f
 106:	77 02                	ja     0x10a
 108:	eb 09                	jmp    0x113
 10a:	49 89 d5             	mov    r13,rdx
 10d:	48 83 f8 5f          	cmp    rax,0x5f
 111:	77 06                	ja     0x119
 113:	49 89 cd             	mov    r13,rcx
 116:	49 01 dd             	add    r13,rbx
 119:	4c 89 c0             	mov    rax,r8
 11c:	48 83 e0 07          	and    rax,0x7
 120:	4d 0f b6 6d 00       	movzx  r13,BYTE PTR [r13+0x0]
 125:	c4 42 f9 f7 ed       	shlx   r13,r13,rax
 12a:	49 81 e5 80 00 00 00 	and    r13,0x80
 131:	4d 85 ed             	test   r13,r13
 134:	74 86                	je     0xbc
 136:	48 83 fb 05          	cmp    rbx,0x5
 13a:	7f 36                	jg     0x172
 13c:	48 83 fb 02          	cmp    rbx,0x2
 140:	7f 70                	jg     0x1b2
 142:	41 bd da 00 00 00    	mov    r13d,0xda
 148:	41 be 00 56 5a 6d    	mov    r14d,0x6d5a5600
 14e:	48 85 db             	test   rbx,rbx
 151:	0f 84 e9 00 00 00    	je     0x240
 157:	48 83 fb 01          	cmp    rbx,0x1
 15b:	0f 84 c5 00 00 00    	je     0x226
 161:	41 bd 5b 00 00 00    	mov    r13d,0x5b
 167:	41 be 00 25 da 56    	mov    r14d,0x56da2500
 16d:	e9 ce 00 00 00       	jmp    0x240
 172:	48 83 fb 08          	cmp    rbx,0x8
 176:	7f 1d                	jg     0x195
 178:	48 83 fb 06          	cmp    rbx,0x6
 17c:	74 62                	je     0x1e0
 17e:	48 83 fb 07          	cmp    rbx,0x7
 182:	74 78                	je     0x1fc
 184:	41 bd 3d 00 00 00    	mov    r13d,0x3d
 18a:	41 be 00 25 67 41    	mov    r14d,0x41672500
 190:	e9 ab 00 00 00       	jmp    0x240
 195:	48 83 fb 0a          	cmp    rbx,0xa
 199:	7f 31                	jg     0x1cc
 19b:	48 83 fb 09          	cmp    rbx,0x9
 19f:	74 69                	je     0x20a
 1a1:	41 bd a3 00 00 00    	mov    r13d,0xa3
 1a7:	41 be 00 43 3d 25    	mov    r14d,0x253d4300
 1ad:	e9 8e 00 00 00       	jmp    0x240
 1b2:	48 83 fb 03          	cmp    rbx,0x3
 1b6:	74 36                	je     0x1ee
 1b8:	48 83 fb 04          	cmp    rbx,0x4
 1bc:	74 76                	je     0x234
 1be:	41 bd 41 00 00 00    	mov    r13d,0x41
 1c4:	41 be 00 c2 0e 5b    	mov    r14d,0x5b0ec200
 1ca:	eb 74                	jmp    0x240
 1cc:	48 83 fb 0b          	cmp    rbx,0xb
 1d0:	74 46                	je     0x218
 1d2:	41 bd b0 00 00 00    	mov    r13d,0xb0
 1d8:	41 be 00 8f a3 43    	mov    r14d,0x43a38f00
 1de:	eb 60                	jmp    0x240
 1e0:	41 bd 67 00 00 00    	mov    r13d,0x67
 1e6:	41 be 00 41 c2 0e    	mov    r14d,0xec24100
 1ec:	eb 52                	jmp    0x240
 1ee:	41 bd 0e 00 00 00    	mov    r13d,0xe
 1f4:	41 be 00 5b 25 da    	mov    r14d,0xda255b00
 1fa:	eb 44                	jmp    0x240
 1fc:	41 bd 25 00 00 00    	mov    r13d,0x25
 202:	41 be 00 67 41 c2    	mov    r14d,0xc2416700
 208:	eb 36                	jmp    0x240
 20a:	41 bd 43 00 00 00    	mov    r13d,0x43
 210:	41 be 00 3d 25 67    	mov    r14d,0x67253d00
 216:	eb 28                	jmp    0x240
 218:	41 bd 8f 00 00 00    	mov    r13d,0x8f
 21e:	41 be 00 a3 43 3d    	mov    r14d,0x3d43a300
 224:	eb 1a                	jmp    0x240
 226:	41 bd 25 00 00 00    	mov    r13d,0x25
 22c:	41 be 00 da 56 5a    	mov    r14d,0x5a56da00
 232:	eb 0c                	jmp    0x240
 234:	41 bd c2 00 00 00    	mov    r13d,0xc2
 23a:	41 be 00 0e 5b 25    	mov    r14d,0x255b0e00
 240:	4d 09 f5             	or     r13,r14
 243:	48 85 c0             	test   rax,rax
 246:	0f 84 6a fe ff ff    	je     0xb6
 24c:	4d 89 ee             	mov    r14,r13
 24f:	c4 42 f9 f7 f6       	shlx   r14,r14,rax
 254:	41 bd 25 00 00 00    	mov    r13d,0x25
 25a:	48 83 fb 05          	cmp    rbx,0x5
 25e:	7f 24                	jg     0x284
 260:	48 83 fb 02          	cmp    rbx,0x2
 264:	7f 56                	jg     0x2bc
 266:	48 85 db             	test   rbx,rbx
 269:	0f 84 37 fe ff ff    	je     0xa6
 26f:	48 83 fb 01          	cmp    rbx,0x1
 273:	0f 84 90 00 00 00    	je     0x309
 279:	41 bd 0e 00 00 00    	mov    r13d,0xe
 27f:	e9 22 fe ff ff       	jmp    0xa6
 284:	48 83 fb 08          	cmp    rbx,0x8
 288:	7f 1b                	jg     0x2a5
 28a:	48 83 fb 06          	cmp    rbx,0x6
 28e:	0f 84 12 fe ff ff    	je     0xa6
 294:	48 83 fb 07          	cmp    rbx,0x7
 298:	74 4e                	je     0x2e8
 29a:	41 bd 43 00 00 00    	mov    r13d,0x43
 2a0:	e9 01 fe ff ff       	jmp    0xa6
 2a5:	48 83 fb 0a          	cmp    rbx,0xa
 2a9:	7f 2c                	jg     0x2d7
 2ab:	48 83 fb 09          	cmp    rbx,0x9
 2af:	74 42                	je     0x2f3
 2b1:	41 bd 8f 00 00 00    	mov    r13d,0x8f
 2b7:	e9 ea fd ff ff       	jmp    0xa6
 2bc:	48 83 fb 03          	cmp    rbx,0x3
 2c0:	0f 84 da fd ff ff    	je     0xa0
 2c6:	48 83 fb 04          	cmp    rbx,0x4
 2ca:	74 48                	je     0x314
 2cc:	41 bd 67 00 00 00    	mov    r13d,0x67
 2d2:	e9 cf fd ff ff       	jmp    0xa6
 2d7:	48 83 fb 0b          	cmp    rbx,0xb
 2db:	74 21                	je     0x2fe
 2dd:	41 bd d0 00 00 00    	mov    r13d,0xd0
 2e3:	e9 be fd ff ff       	jmp    0xa6
 2e8:	41 bd 3d 00 00 00    	mov    r13d,0x3d
 2ee:	e9 b3 fd ff ff       	jmp    0xa6
 2f3:	41 bd a3 00 00 00    	mov    r13d,0xa3
 2f9:	e9 a8 fd ff ff       	jmp    0xa6
 2fe:	41 bd b0 00 00 00    	mov    r13d,0xb0
 304:	e9 9d fd ff ff       	jmp    0xa6
 309:	41 bd 5b 00 00 00    	mov    r13d,0x5b
 30f:	e9 92 fd ff ff       	jmp    0xa6
 314:	41 bd 41 00 00 00    	mov    r13d,0x41
 31a:	e9 87 fd ff ff       	jmp    0xa6
 31f:	48 0f b6 4f 22       	movzx  rcx,BYTE PTR [rdi+0x22]
 324:	48 c1 e1 18          	shl    rcx,0x18
 328:	48 0f b6 57 23       	movzx  rdx,BYTE PTR [rdi+0x23]
 32d:	48 c1 e2 10          	shl    rdx,0x10
 331:	48 09 ca             	or     rdx,rcx
 334:	48 0f b6 4f 24       	movzx  rcx,BYTE PTR [rdi+0x24]
 339:	48 c1 e1 08          	shl    rcx,0x8
 33d:	48 09 ca             	or     rdx,rcx
 340:	48 0f b6 4f 25       	movzx  rcx,BYTE PTR [rdi+0x25]
 345:	48 09 ca             	or     rdx,rcx
 348:	4c 0f b6 47 26       	movzx  r8,BYTE PTR [rdi+0x26]
 34d:	49 c1 e0 18          	shl    r8,0x18
 351:	48 0f b6 4f 27       	movzx  rcx,BYTE PTR [rdi+0x27]
 356:	48 c1 e1 10          	shl    rcx,0x10
 35a:	4c 09 c1             	or     rcx,r8
 35d:	4c 0f b6 47 28       	movzx  r8,BYTE PTR [rdi+0x28]
 362:	49 c1 e0 08          	shl    r8,0x8
 366:	4c 09 c1             	or     rcx,r8
 369:	4c 0f b6 47 29       	movzx  r8,BYTE PTR [rdi+0x29]
 36e:	4c 09 c1             	or     rcx,r8
 371:	48 31 d1             	xor    rcx,rdx
 374:	4c 0f b6 47 2a       	movzx  r8,BYTE PTR [rdi+0x2a]
 379:	49 c1 e0 38          	shl    r8,0x38
 37d:	48 0f b6 57 2b       	movzx  rdx,BYTE PTR [rdi+0x2b]
 382:	48 c1 e2 30          	shl    rdx,0x30
 386:	4c 09 c2             	or     rdx,r8
 389:	4c 0f b6 47 2c       	movzx  r8,BYTE PTR [rdi+0x2c]
 38e:	49 c1 e0 28          	shl    r8,0x28
 392:	4c 09 c2             	or     rdx,r8
 395:	49 89 c8             	mov    r8,rcx
 398:	49 c1 e0 20          	shl    r8,0x20
 39c:	49 c1 e8 20          	shr    r8,0x20
 3a0:	4c 09 c2             	or     rdx,r8
 3a3:	4c 0f b6 47 2d       	movzx  r8,BYTE PTR [rdi+0x2d]
 3a8:	49 c1 e0 20          	shl    r8,0x20
 3ac:	4c 09 c2             	or     rdx,r8
 3af:	49 89 f0             	mov    r8,rsi
 3b2:	49 83 e0 07          	and    r8,0x7
 3b6:	4c 89 c0             	mov    rax,r8
 3b9:	48 83 c0 01          	add    rax,0x1
 3bd:	49 83 f0 3f          	xor    r8,0x3f
 3c1:	48 89 d3             	mov    rbx,rdx
 3c4:	c4 e2 bb f7 db       	shrx   rbx,rbx,r8
 3c9:	c4 e2 f9 f7 d2       	shlx   rdx,rdx,rax
 3ce:	48 09 da             	or     rdx,rbx
 3d1:	48 31 f1             	xor    rcx,rsi
 3d4:	48 c1 e6 20          	shl    rsi,0x20
 3d8:	48 c1 e1 20          	shl    rcx,0x20
 3dc:	48 c1 e9 20          	shr    rcx,0x20
 3e0:	48 09 ce             	or     rsi,rcx
 3e3:	48 31 f2             	xor    rdx,rsi
 3e6:	48 89 d6             	mov    rsi,rdx
 3e9:	48 c1 ee 38          	shr    rsi,0x38
 3ed:	40 88 77 07          	mov    BYTE PTR [rdi+0x7],sil
 3f1:	48 89 d6             	mov    rsi,rdx
 3f4:	48 c1 ee 30          	shr    rsi,0x30
 3f8:	40 88 77 06          	mov    BYTE PTR [rdi+0x6],sil
 3fc:	48 89 d6             	mov    rsi,rdx
 3ff:	48 c1 ee 28          	shr    rsi,0x28
 403:	40 88 77 05          	mov    BYTE PTR [rdi+0x5],sil
 407:	48 89 d6             	mov    rsi,rdx
 40a:	48 c1 ee 20          	shr    rsi,0x20
 40e:	40 88 77 04          	mov    BYTE PTR [rdi+0x4],sil
 412:	48 89 d6             	mov    rsi,rdx
 415:	48 c1 ee 18          	shr    rsi,0x18
 419:	40 88 77 03          	mov    BYTE PTR [rdi+0x3],sil
 41d:	48 89 d6             	mov    rsi,rdx
 420:	48 c1 ee 10          	shr    rsi,0x10
 424:	40 88 77 02          	mov    BYTE PTR [rdi+0x2],sil
 428:	88 57 00             	mov    BYTE PTR [rdi+0x0],dl
 42b:	48 c1 ea 08          	shr    rdx,0x8
 42f:	88 57 01             	mov    BYTE PTR [rdi+0x1],dl
 432:	b8 02 00 00 00       	mov    eax,0x2
 437:	41 5e                	pop    r14
 439:	41 5d                	pop    r13
 43b:	5b                   	pop    rbx
 43c:	c9                   	leave
 43d:	e9 12 2c c1 dc       	jmp    0xffffffffdcc13054
```

## llvmbpf JIT ASM
```asm
not captured
```
