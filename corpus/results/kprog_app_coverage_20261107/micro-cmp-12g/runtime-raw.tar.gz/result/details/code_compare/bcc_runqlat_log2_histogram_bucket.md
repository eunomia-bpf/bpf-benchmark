# bcc_runqlat_log2_histogram_bucket

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <bcc_runqlat_log2_histogram_bucket_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <bcc_runqlat_log2_histogram_bucket_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <bcc_runqlat_log2_histogram_bucket_xdp+0x11>
    111b:	4c 8d 82 10 04 00 00 	lea    r8,[rdx+0x410]
    1122:	49 39 f0             	cmp    r8,rsi
    1125:	77 ea                	ja     1111 <bcc_runqlat_log2_histogram_bucket_xdp+0x11>
    1127:	81 3f 80 00 00 00    	cmp    DWORD PTR [rdi],0x80
    112d:	75 e2                	jne    1111 <bcc_runqlat_log2_histogram_bucket_xdp+0x11>
    112f:	53                   	push   rbx
    1130:	8b 72 0c             	mov    esi,DWORD PTR [rdx+0xc]
    1133:	31 c0                	xor    eax,eax
    1135:	eb 2d                	jmp    1164 <bcc_runqlat_log2_histogram_bucket_xdp+0x64>
    1137:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    113e:	00 00 
    1140:	48 c1 e0 03          	shl    rax,0x3
    1144:	44 89 d6             	mov    esi,r10d
    1147:	24 38                	and    al,0x38
    1149:	c4 e2 f9 f7 c6       	shlx   rax,rsi,rax
    114e:	49 31 c3             	xor    r11,rax
    1151:	4c 89 de             	mov    rsi,r11
    1154:	4c 89 c0             	mov    rax,r8
    1157:	49 81 f8 80 00 00 00 	cmp    r8,0x80
    115e:	0f 84 e6 00 00 00    	je     124a <bcc_runqlat_log2_histogram_bucket_xdp+0x14a>
    1164:	0f b7 7c c2 10       	movzx  edi,WORD PTR [rdx+rax*8+0x10]
    1169:	44 0f b6 44 c2 12    	movzx  r8d,BYTE PTR [rdx+rax*8+0x12]
    116f:	41 c1 e0 10          	shl    r8d,0x10
    1173:	49 09 f8             	or     r8,rdi
    1176:	45 89 c1             	mov    r9d,r8d
    1179:	41 c1 e9 03          	shr    r9d,0x3
    117d:	bf 00 00 00 00       	mov    edi,0x0
    1182:	41 81 e1 ff ff 0f 00 	and    r9d,0xfffff
    1189:	74 21                	je     11ac <bcc_runqlat_log2_histogram_bucket_xdp+0xac>
    118b:	49 ff c1             	inc    r9
    118e:	31 ff                	xor    edi,edi
    1190:	41 89 fa             	mov    r10d,edi
    1193:	41 8d 7a 01          	lea    edi,[r10+0x1]
    1197:	41 83 fa 3d          	cmp    r10d,0x3d
    119b:	77 0f                	ja     11ac <bcc_runqlat_log2_histogram_bucket_xdp+0xac>
    119d:	4d 89 ca             	mov    r10,r9
    11a0:	49 d1 ea             	shr    r10,1
    11a3:	49 83 f9 03          	cmp    r9,0x3
    11a7:	4d 89 d1             	mov    r9,r10
    11aa:	77 e4                	ja     1190 <bcc_runqlat_log2_histogram_bucket_xdp+0x90>
    11ac:	44 0f b6 4c c2 13    	movzx  r9d,BYTE PTR [rdx+rax*8+0x13]
    11b2:	41 c1 e1 18          	shl    r9d,0x18
    11b6:	4d 09 c1             	or     r9,r8
    11b9:	44 0f b6 44 c2 14    	movzx  r8d,BYTE PTR [rdx+rax*8+0x14]
    11bf:	49 c1 e0 20          	shl    r8,0x20
    11c3:	44 0f b6 54 c2 15    	movzx  r10d,BYTE PTR [rdx+rax*8+0x15]
    11c9:	49 c1 e2 28          	shl    r10,0x28
    11cd:	4d 09 c2             	or     r10,r8
    11d0:	4d 09 ca             	or     r10,r9
    11d3:	44 0f b6 44 c2 16    	movzx  r8d,BYTE PTR [rdx+rax*8+0x16]
    11d9:	49 c1 e0 30          	shl    r8,0x30
    11dd:	44 0f b6 4c c2 17    	movzx  r9d,BYTE PTR [rdx+rax*8+0x17]
    11e3:	49 c1 e1 38          	shl    r9,0x38
    11e7:	4d 09 c1             	or     r9,r8
    11ea:	4d 09 d1             	or     r9,r10
    11ed:	83 ff 19             	cmp    edi,0x19
    11f0:	41 ba 19 00 00 00    	mov    r10d,0x19
    11f6:	44 0f 42 d7          	cmovb  r10d,edi
    11fa:	45 8d 5a 01          	lea    r11d,[r10+0x1]
    11fe:	4c 8d 40 01          	lea    r8,[rax+0x1]
    1202:	4d 0f af d8          	imul   r11,r8
    1206:	4c 01 de             	add    rsi,r11
    1209:	45 89 d3             	mov    r11d,r10d
    120c:	41 80 e3 07          	and    r11b,0x7
    1210:	41 8d 5b 01          	lea    ebx,[r11+0x1]
    1214:	c4 c2 e1 f7 d9       	shlx   rbx,r9,rbx
    1219:	41 f6 d3             	not    r11b
    121c:	c4 42 a3 f7 d9       	shrx   r11,r9,r11
    1221:	49 09 db             	or     r11,rbx
    1224:	49 31 f3             	xor    r11,rsi
    1227:	83 ff 19             	cmp    edi,0x19
    122a:	0f 82 10 ff ff ff    	jb     1140 <bcc_runqlat_log2_histogram_bucket_xdp+0x40>
    1230:	49 c1 e9 20          	shr    r9,0x20
    1234:	4d 01 cb             	add    r11,r9
    1237:	4c 89 de             	mov    rsi,r11
    123a:	4c 89 c0             	mov    rax,r8
    123d:	49 81 f8 80 00 00 00 	cmp    r8,0x80
    1244:	0f 85 1a ff ff ff    	jne    1164 <bcc_runqlat_log2_histogram_bucket_xdp+0x64>
    124a:	48 89 31             	mov    QWORD PTR [rcx],rsi
    124d:	b8 02 00 00 00       	mov    eax,0x2
    1252:	5b                   	pop    rbx
    1253:	c3                   	ret

Disassembly of section .fini:

0000000000001254 <_fini>:
    1254:	f3 0f 1e fa          	endbr64
    1258:	48 83 ec 08          	sub    rsp,0x8
    125c:	48 83 c4 08          	add    rsp,0x8
    1260:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 48 00 00 00 	sub    rsp,0x48
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 57 00          	mov    rdx,QWORD PTR [rdi+0x0]
  24:	48 39 f2             	cmp    rdx,rsi
  27:	0f 87 96 02 00 00    	ja     0x2c3
  2d:	48 89 d7             	mov    rdi,rdx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 86 02 00 00    	ja     0x2c3
  3d:	48 89 d7             	mov    rdi,rdx
  40:	48 81 c7 10 04 00 00 	add    rdi,0x410
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 73 02 00 00    	ja     0x2c3
  50:	48 0f b6 7a 09       	movzx  rdi,BYTE PTR [rdx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 72 08       	movzx  rsi,BYTE PTR [rdx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 72 0a       	movzx  rsi,BYTE PTR [rdx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 72 0b       	movzx  rsi,BYTE PTR [rdx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 81 ff 80 00 00 00 	cmp    rdi,0x80
  88:	0f 85 35 02 00 00    	jne    0x2c3
  8e:	4c 0f b6 72 0d       	movzx  r14,BYTE PTR [rdx+0xd]
  93:	49 c1 e6 08          	shl    r14,0x8
  97:	48 0f b6 7a 0c       	movzx  rdi,BYTE PTR [rdx+0xc]
  9c:	49 09 fe             	or     r14,rdi
  9f:	48 0f b6 7a 0e       	movzx  rdi,BYTE PTR [rdx+0xe]
  a4:	48 c1 e7 10          	shl    rdi,0x10
  a8:	49 09 fe             	or     r14,rdi
  ab:	48 0f b6 7a 0f       	movzx  rdi,BYTE PTR [rdx+0xf]
  b0:	48 c1 e7 18          	shl    rdi,0x18
  b4:	49 09 fe             	or     r14,rdi
  b7:	31 c9                	xor    ecx,ecx
  b9:	48 89 d7             	mov    rdi,rdx
  bc:	48 83 c7 17          	add    rdi,0x17
  c0:	48 89 7d f8          	mov    QWORD PTR [rbp-0x8],rdi
  c4:	48 89 d7             	mov    rdi,rdx
  c7:	48 83 c7 16          	add    rdi,0x16
  cb:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
  cf:	48 89 d7             	mov    rdi,rdx
  d2:	48 83 c7 15          	add    rdi,0x15
  d6:	48 89 7d e8          	mov    QWORD PTR [rbp-0x18],rdi
  da:	48 89 d7             	mov    rdi,rdx
  dd:	48 83 c7 14          	add    rdi,0x14
  e1:	48 89 7d e0          	mov    QWORD PTR [rbp-0x20],rdi
  e5:	48 89 d7             	mov    rdi,rdx
  e8:	48 83 c7 13          	add    rdi,0x13
  ec:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
  f0:	48 89 d7             	mov    rdi,rdx
  f3:	48 83 c7 12          	add    rdi,0x12
  f7:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
  fb:	48 89 d7             	mov    rdi,rdx
  fe:	48 83 c7 11          	add    rdi,0x11
 102:	48 89 7d c8          	mov    QWORD PTR [rbp-0x38],rdi
 106:	48 89 55 b8          	mov    QWORD PTR [rbp-0x48],rdx
 10a:	48 83 c2 10          	add    rdx,0x10
 10e:	48 89 55 c0          	mov    QWORD PTR [rbp-0x40],rdx
 112:	e9 a1 00 00 00       	jmp    0x1b8
 117:	48 8b 5d e8          	mov    rbx,QWORD PTR [rbp-0x18]
 11b:	48 01 f3             	add    rbx,rsi
 11e:	4c 0f b6 7b 00       	movzx  r15,BYTE PTR [rbx+0x0]
 123:	49 c1 e7 28          	shl    r15,0x28
 127:	48 8b 5d e0          	mov    rbx,QWORD PTR [rbp-0x20]
 12b:	48 01 f3             	add    rbx,rsi
 12e:	48 0f b6 5b 00       	movzx  rbx,BYTE PTR [rbx+0x0]
 133:	48 c1 e3 20          	shl    rbx,0x20
 137:	4c 09 fb             	or     rbx,r15
 13a:	4c 8b 7d d8          	mov    r15,QWORD PTR [rbp-0x28]
 13e:	49 01 f7             	add    r15,rsi
 141:	4d 0f b6 7f 00       	movzx  r15,BYTE PTR [r15+0x0]
 146:	49 c1 e7 18          	shl    r15,0x18
 14a:	49 09 c7             	or     r15,rax
 14d:	4c 09 fb             	or     rbx,r15
 150:	48 8b 45 f8          	mov    rax,QWORD PTR [rbp-0x8]
 154:	48 01 f0             	add    rax,rsi
 157:	4c 0f b6 78 00       	movzx  r15,BYTE PTR [rax+0x0]
 15c:	49 c1 e7 38          	shl    r15,0x38
 160:	48 8b 45 f0          	mov    rax,QWORD PTR [rbp-0x10]
 164:	48 01 f0             	add    rax,rsi
 167:	48 0f b6 40 00       	movzx  rax,BYTE PTR [rax+0x0]
 16c:	48 c1 e0 30          	shl    rax,0x30
 170:	4c 09 f8             	or     rax,r15
 173:	48 09 d8             	or     rax,rbx
 176:	4d 89 c7             	mov    r15,r8
 179:	49 83 e7 07          	and    r15,0x7
 17d:	4c 89 fb             	mov    rbx,r15
 180:	48 83 f3 3f          	xor    rbx,0x3f
 184:	48 89 c7             	mov    rdi,rax
 187:	c4 e2 e3 f7 ff       	shrx   rdi,rdi,rbx
 18c:	49 83 c7 01          	add    r15,0x1
 190:	48 89 c3             	mov    rbx,rax
 193:	c4 e2 81 f7 db       	shlx   rbx,rbx,r15
 198:	48 09 fb             	or     rbx,rdi
 19b:	48 83 c1 01          	add    rcx,0x1
 19f:	4c 89 c7             	mov    rdi,r8
 1a2:	48 83 c7 01          	add    rdi,0x1
 1a6:	49 89 cf             	mov    r15,rcx
 1a9:	4c 0f af ff          	imul   r15,rdi
 1ad:	4d 01 fe             	add    r14,r15
 1b0:	4c 31 f3             	xor    rbx,r14
 1b3:	e9 8e 00 00 00       	jmp    0x246
 1b8:	48 89 ce             	mov    rsi,rcx
 1bb:	48 c1 e6 03          	shl    rsi,0x3
 1bf:	48 8b 55 c0          	mov    rdx,QWORD PTR [rbp-0x40]
 1c3:	48 01 f2             	add    rdx,rsi
 1c6:	48 0f b6 52 00       	movzx  rdx,BYTE PTR [rdx+0x0]
 1cb:	4c 8b 45 c8          	mov    r8,QWORD PTR [rbp-0x38]
 1cf:	49 01 f0             	add    r8,rsi
 1d2:	4d 0f b6 40 00       	movzx  r8,BYTE PTR [r8+0x0]
 1d7:	49 c1 e0 08          	shl    r8,0x8
 1db:	49 09 d0             	or     r8,rdx
 1de:	48 8b 55 d0          	mov    rdx,QWORD PTR [rbp-0x30]
 1e2:	48 01 f2             	add    rdx,rsi
 1e5:	48 0f b6 42 00       	movzx  rax,BYTE PTR [rdx+0x0]
 1ea:	48 c1 e0 10          	shl    rax,0x10
 1ee:	4c 09 c0             	or     rax,r8
 1f1:	49 89 c0             	mov    r8,rax
 1f4:	49 c1 e8 03          	shr    r8,0x3
 1f8:	49 81 e0 ff ff 0f 00 	and    r8,0xfffff
 1ff:	31 d2                	xor    edx,edx
 201:	4d 85 c0             	test   r8,r8
 204:	74 2a                	je     0x230
 206:	31 db                	xor    ebx,ebx
 208:	49 83 c0 01          	add    r8,0x1
 20c:	4d 89 c5             	mov    r13,r8
 20f:	48 83 c2 01          	add    rdx,0x1
 213:	48 c1 e3 20          	shl    rbx,0x20
 217:	48 c1 eb 20          	shr    rbx,0x20
 21b:	48 83 fb 3d          	cmp    rbx,0x3d
 21f:	77 0f                	ja     0x230
 221:	4d 89 e8             	mov    r8,r13
 224:	49 d1 e8             	shr    r8,1
 227:	48 89 d3             	mov    rbx,rdx
 22a:	49 83 fd 03          	cmp    r13,0x3
 22e:	77 dc                	ja     0x20c
 230:	48 c1 e2 20          	shl    rdx,0x20
 234:	48 c1 ea 20          	shr    rdx,0x20
 238:	41 bd 19 00 00 00    	mov    r13d,0x19
 23e:	49 89 d0             	mov    r8,rdx
 241:	e9 d1 fe ff ff       	jmp    0x117
 246:	48 83 e6 38          	and    rsi,0x38
 24a:	49 c1 e0 20          	shl    r8,0x20
 24e:	49 c1 e8 20          	shr    r8,0x20
 252:	c4 42 c9 f7 c0       	shlx   r8,r8,rsi
 257:	49 31 d8             	xor    r8,rbx
 25a:	4c 89 c3             	mov    rbx,r8
 25d:	4d 89 c6             	mov    r14,r8
 260:	48 81 f9 80 00 00 00 	cmp    rcx,0x80
 267:	74 05                	je     0x26e
 269:	e9 4a ff ff ff       	jmp    0x1b8
 26e:	48 89 df             	mov    rdi,rbx
 271:	48 c1 ef 38          	shr    rdi,0x38
 275:	48 8b 75 b8          	mov    rsi,QWORD PTR [rbp-0x48]
 279:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 27d:	48 89 df             	mov    rdi,rbx
 280:	48 c1 ef 30          	shr    rdi,0x30
 284:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 288:	48 89 df             	mov    rdi,rbx
 28b:	48 c1 ef 28          	shr    rdi,0x28
 28f:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 293:	48 89 df             	mov    rdi,rbx
 296:	48 c1 ef 20          	shr    rdi,0x20
 29a:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 29e:	48 89 df             	mov    rdi,rbx
 2a1:	48 c1 ef 18          	shr    rdi,0x18
 2a5:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 2a9:	48 89 df             	mov    rdi,rbx
 2ac:	48 c1 ef 10          	shr    rdi,0x10
 2b0:	40 88 7e 02          	mov    BYTE PTR [rsi+0x2],dil
 2b4:	88 5e 00             	mov    BYTE PTR [rsi+0x0],bl
 2b7:	48 c1 eb 08          	shr    rbx,0x8
 2bb:	88 5e 01             	mov    BYTE PTR [rsi+0x1],bl
 2be:	b8 02 00 00 00       	mov    eax,0x2
 2c3:	41 5f                	pop    r15
 2c5:	41 5e                	pop    r14
 2c7:	41 5d                	pop    r13
 2c9:	5b                   	pop    rbx
 2ca:	c9                   	leave
 2cb:	e9 64 2d c1 dc       	jmp    0xffffffffdcc13034
```

## llvmbpf JIT ASM
```asm
not captured
```
