# katran_lb_consistent_hash_select

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <__TMC_END__>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <__TMC_END__>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <__TMC_END__>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <__TMC_END__>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 51 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f51],0x0        # 400c <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 29 2f 00 00 01 	mov    BYTE PTR [rip+0x2f29],0x1        # 400c <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <katran_lb_consistent_hash_select_xdp>:
    1100:	55                   	push   rbp
    1101:	41 57                	push   r15
    1103:	41 56                	push   r14
    1105:	41 55                	push   r13
    1107:	41 54                	push   r12
    1109:	53                   	push   rbx
    110a:	50                   	push   rax
    110b:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    110e:	48 8b 5f 08          	mov    rbx,QWORD PTR [rdi+0x8]
    1112:	31 c0                	xor    eax,eax
    1114:	48 39 d9             	cmp    rcx,rbx
    1117:	0f 87 f1 04 00 00    	ja     160e <katran_lb_consistent_hash_select_xdp+0x50e>
    111d:	48 8d 71 08          	lea    rsi,[rcx+0x8]
    1121:	48 39 de             	cmp    rsi,rbx
    1124:	0f 87 e4 04 00 00    	ja     160e <katran_lb_consistent_hash_select_xdp+0x50e>
    112a:	48 8d 51 16          	lea    rdx,[rcx+0x16]
    112e:	48 39 da             	cmp    rdx,rbx
    1131:	0f 87 d7 04 00 00    	ja     160e <katran_lb_consistent_hash_select_xdp+0x50e>
    1137:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
    113e:	79 37 9e 
    1141:	49 89 da             	mov    r10,rbx
    1144:	49 29 f2             	sub    r10,rsi
    1147:	0f b7 71 14          	movzx  esi,WORD PTR [rcx+0x14]
    114b:	81 fe 86 dd 00 00    	cmp    esi,0xdd86
    1151:	0f 84 91 00 00 00    	je     11e8 <katran_lb_consistent_hash_select_xdp+0xe8>
    1157:	83 fe 08             	cmp    esi,0x8
    115a:	0f 85 b7 00 00 00    	jne    1217 <katran_lb_consistent_hash_select_xdp+0x117>
    1160:	48 8d 71 2a          	lea    rsi,[rcx+0x2a]
    1164:	41 b9 01 00 00 00    	mov    r9d,0x1
    116a:	48 39 de             	cmp    rsi,rbx
    116d:	0f 87 74 04 00 00    	ja     15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    1173:	0f b6 12             	movzx  edx,BYTE PTR [rdx]
    1176:	80 e2 0f             	and    dl,0xf
    1179:	80 fa 05             	cmp    dl,0x5
    117c:	0f 85 65 04 00 00    	jne    15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    1182:	0f b6 51 1c          	movzx  edx,BYTE PTR [rcx+0x1c]
    1186:	0f b6 71 1d          	movzx  esi,BYTE PTR [rcx+0x1d]
    118a:	83 e2 3f             	and    edx,0x3f
    118d:	66 09 f2             	or     dx,si
    1190:	0f 85 51 04 00 00    	jne    15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    1196:	44 0f b6 71 1f       	movzx  r14d,BYTE PTR [rcx+0x1f]
    119b:	be 02 00 00 00       	mov    esi,0x2
    11a0:	41 83 fe 01          	cmp    r14d,0x1
    11a4:	0f 84 8b 00 00 00    	je     1235 <katran_lb_consistent_hash_select_xdp+0x135>
    11aa:	66 0f 38 f0 69 18    	movbe  bp,WORD PTR [rcx+0x18]
    11b0:	0f b6 79 17          	movzx  edi,BYTE PTR [rcx+0x17]
    11b4:	44 0f b7 59 22       	movzx  r11d,WORD PTR [rcx+0x22]
    11b9:	44 0f b6 41 24       	movzx  r8d,BYTE PTR [rcx+0x24]
    11be:	0f b6 51 25          	movzx  edx,BYTE PTR [rcx+0x25]
    11c2:	44 8b 79 26          	mov    r15d,DWORD PTR [rcx+0x26]
    11c6:	41 83 fe 11          	cmp    r14d,0x11
    11ca:	0f 84 0e 04 00 00    	je     15de <katran_lb_consistent_hash_select_xdp+0x4de>
    11d0:	41 83 fe 06          	cmp    r14d,0x6
    11d4:	75 5f                	jne    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    11d6:	4c 8d 61 3e          	lea    r12,[rcx+0x3e]
    11da:	49 39 dc             	cmp    r12,rbx
    11dd:	0f 87 04 04 00 00    	ja     15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    11e3:	e9 35 04 00 00       	jmp    161d <katran_lb_consistent_hash_select_xdp+0x51d>
    11e8:	48 8d 51 3e          	lea    rdx,[rcx+0x3e]
    11ec:	41 b9 01 00 00 00    	mov    r9d,0x1
    11f2:	48 39 da             	cmp    rdx,rbx
    11f5:	0f 87 ec 03 00 00    	ja     15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    11fb:	44 0f b6 61 1c       	movzx  r12d,BYTE PTR [rcx+0x1c]
    1200:	41 83 fc 2c          	cmp    r12d,0x2c
    1204:	0f 84 dd 03 00 00    	je     15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    120a:	41 83 fc 3a          	cmp    r12d,0x3a
    120e:	75 30                	jne    1240 <katran_lb_consistent_hash_select_xdp+0x140>
    1210:	be 02 00 00 00       	mov    esi,0x2
    1215:	eb 1e                	jmp    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    1217:	49 01 c2             	add    r10,rax
    121a:	4c 89 d2             	mov    rdx,r10
    121d:	48 c1 e2 06          	shl    rdx,0x6
    1221:	48 01 c2             	add    rdx,rax
    1224:	4c 89 d6             	mov    rsi,r10
    1227:	48 c1 ee 02          	shr    rsi,0x2
    122b:	48 01 d6             	add    rsi,rdx
    122e:	48 83 c6 02          	add    rsi,0x2
    1232:	4c 31 d6             	xor    rsi,r10
    1235:	41 b9 02 00 00 00    	mov    r9d,0x2
    123b:	e9 ac 03 00 00       	jmp    15ec <katran_lb_consistent_hash_select_xdp+0x4ec>
    1240:	0f b6 51 16          	movzx  edx,BYTE PTR [rcx+0x16]
    1244:	44 0f b6 79 17       	movzx  r15d,BYTE PTR [rcx+0x17]
    1249:	66 0f 38 f0 69 1a    	movbe  bp,WORD PTR [rcx+0x1a]
    124f:	8b 79 1e             	mov    edi,DWORD PTR [rcx+0x1e]
    1252:	44 8b 71 26          	mov    r14d,DWORD PTR [rcx+0x26]
    1256:	44 8b 41 2a          	mov    r8d,DWORD PTR [rcx+0x2a]
    125a:	44 8b 69 2e          	mov    r13d,DWORD PTR [rcx+0x2e]
    125e:	41 bb ff c0 ad de    	mov    r11d,0xdeadc0ff
    1264:	44 03 59 22          	add    r11d,DWORD PTR [rcx+0x22]
    1268:	be 02 00 00 00       	mov    esi,0x2
    126d:	41 83 fc 11          	cmp    r12d,0x11
    1271:	74 19                	je     128c <katran_lb_consistent_hash_select_xdp+0x18c>
    1273:	41 83 fc 06          	cmp    r12d,0x6
    1277:	75 bc                	jne    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    1279:	48 89 3c 24          	mov    QWORD PTR [rsp],rdi
    127d:	48 8d 79 52          	lea    rdi,[rcx+0x52]
    1281:	48 39 df             	cmp    rdi,rbx
    1284:	0f 87 5d 03 00 00    	ja     15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    128a:	eb 11                	jmp    129d <katran_lb_consistent_hash_select_xdp+0x19d>
    128c:	48 89 3c 24          	mov    QWORD PTR [rsp],rdi
    1290:	48 8d 79 46          	lea    rdi,[rcx+0x46]
    1294:	48 39 df             	cmp    rdi,rbx
    1297:	0f 87 4a 03 00 00    	ja     15e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
    129d:	41 83 fc 06          	cmp    r12d,0x6
    12a1:	75 92                	jne    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    12a3:	41 81 fd 0a 64 01 01 	cmp    r13d,0x101640a
    12aa:	75 89                	jne    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    12ac:	0f b7 79 40          	movzx  edi,WORD PTR [rcx+0x40]
    12b0:	41 b9 02 00 00 00    	mov    r9d,0x2
    12b6:	81 ff 1f 90 00 00    	cmp    edi,0x901f
    12bc:	0f 85 2a 03 00 00    	jne    15ec <katran_lb_consistent_hash_select_xdp+0x4ec>
    12c2:	be 01 00 00 00       	mov    esi,0x1
    12c7:	41 b9 01 00 00 00    	mov    r9d,0x1
    12cd:	49 81 fa ea 05 00 00 	cmp    r10,0x5ea
    12d4:	0f 8f 12 03 00 00    	jg     15ec <katran_lb_consistent_hash_select_xdp+0x4ec>
    12da:	41 c0 ef 04          	shr    r15b,0x4
    12de:	41 89 d4             	mov    r12d,edx
    12e1:	41 c0 e4 04          	shl    r12b,0x4
    12e5:	45 08 fc             	or     r12b,r15b
    12e8:	0f b7 f5             	movzx  esi,bp
    12eb:	44 89 c7             	mov    edi,r8d
    12ee:	81 e7 00 00 00 ff    	and    edi,0xff000000
    12f4:	45 8d 96 ff c0 ad de 	lea    r10d,[r14-0x21523f01]
    12fb:	45 89 c1             	mov    r9d,r8d
    12fe:	41 81 e1 00 00 ff 00 	and    r9d,0xff0000
    1305:	41 01 f9             	add    r9d,edi
    1308:	44 89 c7             	mov    edi,r8d
    130b:	81 e7 00 ff 00 00    	and    edi,0xff00
    1311:	44 01 cf             	add    edi,r9d
    1314:	45 0f b6 c8          	movzx  r9d,r8b
    1318:	41 01 f9             	add    r9d,edi
    131b:	44 0f b7 41 3e       	movzx  r8d,WORD PTR [rcx+0x3e]
    1320:	48 8b 14 24          	mov    rdx,QWORD PTR [rsp]
    1324:	89 d7                	mov    edi,edx
    1326:	44 29 f7             	sub    edi,r14d
    1329:	c4 c3 7b f0 da 1c    	rorx   ebx,r10d,0x1c
    132f:	31 fb                	xor    ebx,edi
    1331:	45 01 da             	add    r10d,r11d
    1334:	41 29 db             	sub    r11d,ebx
    1337:	c4 e3 7b f0 fb 1a    	rorx   edi,ebx,0x1a
    133d:	44 31 df             	xor    edi,r11d
    1340:	44 01 d3             	add    ebx,r10d
    1343:	8d 2c 1f             	lea    ebp,[rdi+rbx*1]
    1346:	41 29 fa             	sub    r10d,edi
    1349:	c4 e3 7b f0 ff 18    	rorx   edi,edi,0x18
    134f:	44 31 d7             	xor    edi,r10d
    1352:	29 fb                	sub    ebx,edi
    1354:	c4 63 7b f0 df 10    	rorx   r11d,edi,0x10
    135a:	41 31 db             	xor    r11d,ebx
    135d:	01 ef                	add    edi,ebp
    135f:	44 29 dd             	sub    ebp,r11d
    1362:	c4 c3 7b f0 db 0d    	rorx   ebx,r11d,0xd
    1368:	31 eb                	xor    ebx,ebp
    136a:	41 01 fb             	add    r11d,edi
    136d:	46 8d 14 1b          	lea    r10d,[rbx+r11*1]
    1371:	29 df                	sub    edi,ebx
    1373:	c4 e3 7b f0 db 1c    	rorx   ebx,ebx,0x1c
    1379:	31 fb                	xor    ebx,edi
    137b:	45 01 cb             	add    r11d,r9d
    137e:	44 31 d3             	xor    ebx,r10d
    1381:	c4 c3 7b f0 fa 12    	rorx   edi,r10d,0x12
    1387:	29 fb                	sub    ebx,edi
    1389:	41 31 db             	xor    r11d,ebx
    138c:	c4 e3 7b f0 fb 15    	rorx   edi,ebx,0x15
    1392:	41 29 fb             	sub    r11d,edi
    1395:	45 31 da             	xor    r10d,r11d
    1398:	c4 c3 7b f0 fb 07    	rorx   edi,r11d,0x7
    139e:	41 29 fa             	sub    r10d,edi
    13a1:	44 31 d3             	xor    ebx,r10d
    13a4:	c4 c3 7b f0 fa 10    	rorx   edi,r10d,0x10
    13aa:	29 fb                	sub    ebx,edi
    13ac:	41 31 db             	xor    r11d,ebx
    13af:	c4 e3 7b f0 fb 1c    	rorx   edi,ebx,0x1c
    13b5:	41 29 fb             	sub    r11d,edi
    13b8:	45 31 da             	xor    r10d,r11d
    13bb:	c4 c3 7b f0 fb 12    	rorx   edi,r11d,0x12
    13c1:	41 29 fa             	sub    r10d,edi
    13c4:	c4 c3 7b f0 fa 08    	rorx   edi,r10d,0x8
    13ca:	41 31 da             	xor    r10d,ebx
    13cd:	41 29 fa             	sub    r10d,edi
    13d0:	41 81 c2 f7 c0 ad e0 	add    r10d,0xe0adc0f7
    13d7:	45 89 c3             	mov    r11d,r8d
    13da:	41 81 c3 f7 c0 cc 70 	add    r11d,0x70ccc0f7
    13e1:	45 89 d9             	mov    r9d,r11d
    13e4:	41 81 f1 f7 c0 ad e0 	xor    r9d,0xe0adc0f7
    13eb:	bf 00 00 cc 70       	mov    edi,0x70cc0000
    13f0:	44 0f ac df 12       	shrd   edi,r11d,0x12
    13f5:	41 29 f9             	sub    r9d,edi
    13f8:	45 31 ca             	xor    r10d,r9d
    13fb:	c4 c3 7b f0 f9 15    	rorx   edi,r9d,0x15
    1401:	41 29 fa             	sub    r10d,edi
    1404:	45 31 d3             	xor    r11d,r10d
    1407:	c4 c3 7b f0 fa 07    	rorx   edi,r10d,0x7
    140d:	41 29 fb             	sub    r11d,edi
    1410:	45 31 d9             	xor    r9d,r11d
    1413:	c4 c3 7b f0 fb 10    	rorx   edi,r11d,0x10
    1419:	41 29 f9             	sub    r9d,edi
    141c:	45 31 ca             	xor    r10d,r9d
    141f:	c4 c3 7b f0 f9 1c    	rorx   edi,r9d,0x1c
    1425:	41 29 fa             	sub    r10d,edi
    1428:	45 31 d3             	xor    r11d,r10d
    142b:	c4 c3 7b f0 fa 12    	rorx   edi,r10d,0x12
    1431:	41 29 fb             	sub    r11d,edi
    1434:	45 31 d9             	xor    r9d,r11d
    1437:	c4 c3 7b f0 fb 08    	rorx   edi,r11d,0x8
    143d:	41 29 f9             	sub    r9d,edi
    1440:	bf 01 00 ff ff       	mov    edi,0xffff0001
    1445:	49 0f af f9          	imul   rdi,r9
    1449:	48 c1 ef 30          	shr    rdi,0x30
    144d:	41 89 fa             	mov    r10d,edi
    1450:	41 c1 e2 10          	shl    r10d,0x10
    1454:	41 09 fa             	or     r10d,edi
    1457:	45 29 d1             	sub    r9d,r10d
    145a:	48 89 d7             	mov    rdi,rdx
    145d:	48 01 c7             	add    rdi,rax
    1460:	49 89 fa             	mov    r10,rdi
    1463:	49 c1 e2 06          	shl    r10,0x6
    1467:	49 01 c2             	add    r10,rax
    146a:	49 89 fb             	mov    r11,rdi
    146d:	49 c1 eb 02          	shr    r11,0x2
    1471:	4d 01 da             	add    r10,r11
    1474:	49 81 c2 0a 64 01 01 	add    r10,0x101640a
    147b:	49 31 fa             	xor    r10,rdi
    147e:	4d 89 d3             	mov    r11,r10
    1481:	49 c1 e3 06          	shl    r11,0x6
    1485:	4d 01 c3             	add    r11,r8
    1488:	49 01 c3             	add    r11,rax
    148b:	4c 89 d7             	mov    rdi,r10
    148e:	48 c1 ef 02          	shr    rdi,0x2
    1492:	bb 00 00 1f 90       	mov    ebx,0x901f0000
    1497:	48 01 fb             	add    rbx,rdi
    149a:	4c 01 db             	add    rbx,r11
    149d:	4c 31 d3             	xor    rbx,r10
    14a0:	48 89 df             	mov    rdi,rbx
    14a3:	48 c1 e7 06          	shl    rdi,0x6
    14a7:	49 89 da             	mov    r10,rbx
    14aa:	49 c1 ea 02          	shr    r10,0x2
    14ae:	48 01 c7             	add    rdi,rax
    14b1:	4c 01 d7             	add    rdi,r10
    14b4:	4c 01 cf             	add    rdi,r9
    14b7:	48 31 df             	xor    rdi,rbx
    14ba:	49 89 f9             	mov    r9,rdi
    14bd:	49 c1 e1 06          	shl    r9,0x6
    14c1:	49 01 c1             	add    r9,rax
    14c4:	49 89 fa             	mov    r10,rdi
    14c7:	49 c1 ea 02          	shr    r10,0x2
    14cb:	4d 01 d1             	add    r9,r10
    14ce:	49 ff c1             	inc    r9
    14d1:	49 31 f9             	xor    r9,rdi
    14d4:	4c 89 cf             	mov    rdi,r9
    14d7:	48 c1 e7 06          	shl    rdi,0x6
    14db:	48 01 c7             	add    rdi,rax
    14de:	4d 89 ca             	mov    r10,r9
    14e1:	49 c1 ea 02          	shr    r10,0x2
    14e5:	49 01 fa             	add    r10,rdi
    14e8:	4d 31 ca             	xor    r10,r9
    14eb:	4d 89 d3             	mov    r11,r10
    14ee:	49 c1 e3 06          	shl    r11,0x6
    14f2:	49 01 f3             	add    r11,rsi
    14f5:	49 01 c3             	add    r11,rax
    14f8:	4d 89 d1             	mov    r9,r10
    14fb:	49 c1 e9 02          	shr    r9,0x2
    14ff:	4d 01 d9             	add    r9,r11
    1502:	66 41 c1 c0 08       	rol    r8w,0x8
    1507:	41 c1 e0 10          	shl    r8d,0x10
    150b:	81 e2 00 00 ff ff    	and    edx,0xffff0000
    1511:	44 31 c2             	xor    edx,r8d
    1514:	89 f7                	mov    edi,esi
    1516:	83 c7 14             	add    edi,0x14
    1519:	66 c1 c7 08          	rol    di,0x8
    151d:	45 0f b6 c4          	movzx  r8d,r12b
    1521:	0f b7 ff             	movzx  edi,di
    1524:	41 89 d3             	mov    r11d,edx
    1527:	41 c1 eb 10          	shr    r11d,0x10
    152b:	4c 01 c7             	add    rdi,r8
    152e:	4c 01 df             	add    rdi,r11
    1531:	48 81 c7 3b df 00 00 	add    rdi,0xdf3b
    1538:	41 89 f8             	mov    r8d,edi
    153b:	41 c1 e8 10          	shr    r8d,0x10
    153f:	44 0f b7 df          	movzx  r11d,di
    1543:	4d 01 c3             	add    r11,r8
    1546:	48 81 ff 00 00 01 00 	cmp    rdi,0x10000
    154d:	4c 0f 42 df          	cmovb  r11,rdi
    1551:	44 89 df             	mov    edi,r11d
    1554:	c1 ef 10             	shr    edi,0x10
    1557:	45 0f b7 c3          	movzx  r8d,r11w
    155b:	49 01 f8             	add    r8,rdi
    155e:	49 81 fb 00 00 01 00 	cmp    r11,0x10000
    1565:	4d 0f 42 c3          	cmovb  r8,r11
    1569:	44 89 c7             	mov    edi,r8d
    156c:	c1 ef 10             	shr    edi,0x10
    156f:	45 0f b7 d8          	movzx  r11d,r8w
    1573:	49 01 fb             	add    r11,rdi
    1576:	49 81 f8 00 00 01 00 	cmp    r8,0x10000
    157d:	4d 0f 42 d8          	cmovb  r11,r8
    1581:	44 89 df             	mov    edi,r11d
    1584:	c1 ef 10             	shr    edi,0x10
    1587:	44 01 df             	add    edi,r11d
    158a:	4d 31 d1             	xor    r9,r10
    158d:	81 ca ac 10 00 00    	or     edx,0x10ac
    1593:	48 c1 e2 20          	shl    rdx,0x20
    1597:	48 81 ca 0a c8 00 02 	or     rdx,0x200c80a
    159e:	49 81 fb 00 00 01 00 	cmp    r11,0x10000
    15a5:	41 0f 42 fb          	cmovb  edi,r11d
    15a9:	c1 e7 10             	shl    edi,0x10
    15ac:	48 31 f2             	xor    rdx,rsi
    15af:	48 be 0b 00 ff ff 00 	movabs rsi,0x200ffff000b
    15b6:	02 00 00 
    15b9:	48 31 d6             	xor    rsi,rdx
    15bc:	48 31 fe             	xor    rsi,rdi
    15bf:	4c 89 ca             	mov    rdx,r9
    15c2:	48 c1 e2 06          	shl    rdx,0x6
    15c6:	4c 89 cf             	mov    rdi,r9
    15c9:	48 c1 ef 02          	shr    rdi,0x2
    15cd:	48 01 f7             	add    rdi,rsi
    15d0:	48 01 c2             	add    rdx,rax
    15d3:	48 01 fa             	add    rdx,rdi
    15d6:	4c 31 ca             	xor    rdx,r9
    15d9:	e9 93 02 00 00       	jmp    1871 <katran_lb_consistent_hash_select_xdp+0x771>
    15de:	4c 8d 61 32          	lea    r12,[rcx+0x32]
    15e2:	49 39 dc             	cmp    r12,rbx
    15e5:	76 36                	jbe    161d <katran_lb_consistent_hash_select_xdp+0x51d>
    15e7:	be 01 00 00 00       	mov    esi,0x1
    15ec:	48 89 f2             	mov    rdx,rsi
    15ef:	48 c1 e2 06          	shl    rdx,0x6
    15f3:	48 89 f7             	mov    rdi,rsi
    15f6:	48 c1 ef 02          	shr    rdi,0x2
    15fa:	4c 01 cf             	add    rdi,r9
    15fd:	48 01 c2             	add    rdx,rax
    1600:	48 01 fa             	add    rdx,rdi
    1603:	48 31 f2             	xor    rdx,rsi
    1606:	48 89 11             	mov    QWORD PTR [rcx],rdx
    1609:	b8 02 00 00 00       	mov    eax,0x2
    160e:	48 83 c4 08          	add    rsp,0x8
    1612:	5b                   	pop    rbx
    1613:	41 5c                	pop    r12
    1615:	41 5d                	pop    r13
    1617:	41 5e                	pop    r14
    1619:	41 5f                	pop    r15
    161b:	5d                   	pop    rbp
    161c:	c3                   	ret
    161d:	41 81 ff 0a 64 01 01 	cmp    r15d,0x101640a
    1624:	0f 85 0b fc ff ff    	jne    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    162a:	44 0f b7 49 2c       	movzx  r9d,WORD PTR [rcx+0x2c]
    162f:	41 81 f9 1f 90 00 00 	cmp    r9d,0x901f
    1636:	0f 85 f9 fb ff ff    	jne    1235 <katran_lb_consistent_hash_select_xdp+0x135>
    163c:	41 b9 02 00 00 00    	mov    r9d,0x2
    1642:	41 80 fe 06          	cmp    r14b,0x6
    1646:	75 a4                	jne    15ec <katran_lb_consistent_hash_select_xdp+0x4ec>
    1648:	be 01 00 00 00       	mov    esi,0x1
    164d:	41 b9 01 00 00 00    	mov    r9d,0x1
    1653:	49 81 fa ea 05 00 00 	cmp    r10,0x5ea
    165a:	7f 90                	jg     15ec <katran_lb_consistent_hash_select_xdp+0x4ec>
    165c:	0f b7 f5             	movzx  esi,bp
    165f:	41 c1 e0 10          	shl    r8d,0x10
    1663:	c1 e2 18             	shl    edx,0x18
    1666:	45 09 c3             	or     r11d,r8d
    1669:	41 09 d3             	or     r11d,edx
    166c:	44 0f b7 49 2a       	movzx  r9d,WORD PTR [rcx+0x2a]
    1671:	44 89 cb             	mov    ebx,r9d
    1674:	81 c3 f7 c0 cc 70    	add    ebx,0x70ccc0f7
    167a:	41 89 da             	mov    r10d,ebx
    167d:	41 81 f2 f7 c0 ad e0 	xor    r10d,0xe0adc0f7
    1684:	bd 00 00 cc 70       	mov    ebp,0x70cc0000
    1689:	0f ac dd 12          	shrd   ebp,ebx,0x12
    168d:	41 29 ea             	sub    r10d,ebp
    1690:	41 8d ab f7 c0 ad e0 	lea    ebp,[r11-0x1f523f09]
    1697:	44 31 d5             	xor    ebp,r10d
    169a:	c4 43 7b f0 f2 15    	rorx   r14d,r10d,0x15
    16a0:	44 29 f5             	sub    ebp,r14d
    16a3:	31 eb                	xor    ebx,ebp
    16a5:	c4 63 7b f0 f5 07    	rorx   r14d,ebp,0x7
    16ab:	44 29 f3             	sub    ebx,r14d
    16ae:	41 31 da             	xor    r10d,ebx
    16b1:	c4 63 7b f0 f3 10    	rorx   r14d,ebx,0x10
    16b7:	45 29 f2             	sub    r10d,r14d
    16ba:	44 31 d5             	xor    ebp,r10d
    16bd:	c4 43 7b f0 f2 1c    	rorx   r14d,r10d,0x1c
    16c3:	44 29 f5             	sub    ebp,r14d
    16c6:	31 eb                	xor    ebx,ebp
    16c8:	c4 e3 7b f0 ed 12    	rorx   ebp,ebp,0x12
    16ce:	29 eb                	sub    ebx,ebp
    16d0:	41 31 da             	xor    r10d,ebx
    16d3:	c4 e3 7b f0 db 08    	rorx   ebx,ebx,0x8
    16d9:	41 29 da             	sub    r10d,ebx
    16dc:	bb 01 00 ff ff       	mov    ebx,0xffff0001
    16e1:	49 0f af da          	imul   rbx,r10
    16e5:	48 c1 eb 30          	shr    rbx,0x30
    16e9:	89 dd                	mov    ebp,ebx
    16eb:	c1 e5 10             	shl    ebp,0x10
    16ee:	09 dd                	or     ebp,ebx
    16f0:	41 29 ea             	sub    r10d,ebp
    16f3:	45 89 db             	mov    r11d,r11d
    16f6:	49 01 c3             	add    r11,rax
    16f9:	4c 89 db             	mov    rbx,r11
    16fc:	48 c1 e3 06          	shl    rbx,0x6
    1700:	4d 89 de             	mov    r14,r11
    1703:	49 c1 ee 02          	shr    r14,0x2
    1707:	48 01 c3             	add    rbx,rax
    170a:	4c 01 f3             	add    rbx,r14
    170d:	48 81 c3 0a 64 01 01 	add    rbx,0x101640a
    1714:	4c 31 db             	xor    rbx,r11
    1717:	49 89 db             	mov    r11,rbx
    171a:	49 c1 e3 06          	shl    r11,0x6
    171e:	49 89 de             	mov    r14,rbx
    1721:	49 c1 ee 02          	shr    r14,0x2
    1725:	4d 01 ce             	add    r14,r9
    1728:	49 01 c3             	add    r11,rax
    172b:	4d 01 f3             	add    r11,r14
    172e:	41 be 00 00 1f 90    	mov    r14d,0x901f0000
    1734:	4d 01 de             	add    r14,r11
    1737:	49 31 de             	xor    r14,rbx
    173a:	4d 89 f3             	mov    r11,r14
    173d:	49 c1 e3 06          	shl    r11,0x6
    1741:	4c 89 f3             	mov    rbx,r14
    1744:	48 c1 eb 02          	shr    rbx,0x2
    1748:	49 01 c3             	add    r11,rax
    174b:	49 01 db             	add    r11,rbx
    174e:	4d 01 d3             	add    r11,r10
    1751:	4d 31 f3             	xor    r11,r14
    1754:	4d 89 da             	mov    r10,r11
    1757:	49 c1 e2 06          	shl    r10,0x6
    175b:	49 01 c2             	add    r10,rax
    175e:	4c 89 db             	mov    rbx,r11
    1761:	48 c1 eb 02          	shr    rbx,0x2
    1765:	49 01 da             	add    r10,rbx
    1768:	49 ff c2             	inc    r10
    176b:	4d 31 da             	xor    r10,r11
    176e:	4c 89 d3             	mov    rbx,r10
    1771:	48 c1 e3 06          	shl    rbx,0x6
    1775:	48 01 c3             	add    rbx,rax
    1778:	4d 89 d3             	mov    r11,r10
    177b:	49 c1 eb 02          	shr    r11,0x2
    177f:	49 01 db             	add    r11,rbx
    1782:	4d 31 d3             	xor    r11,r10
    1785:	4c 89 db             	mov    rbx,r11
    1788:	48 c1 e3 06          	shl    rbx,0x6
    178c:	48 01 f3             	add    rbx,rsi
    178f:	48 01 c3             	add    rbx,rax
    1792:	4d 89 da             	mov    r10,r11
    1795:	49 c1 ea 02          	shr    r10,0x2
    1799:	49 01 da             	add    r10,rbx
    179c:	66 41 c1 c1 08       	rol    r9w,0x8
    17a1:	41 c1 e1 10          	shl    r9d,0x10
    17a5:	44 09 c2             	or     edx,r8d
    17a8:	44 31 ca             	xor    edx,r9d
    17ab:	41 89 f0             	mov    r8d,esi
    17ae:	41 83 c0 14          	add    r8d,0x14
    17b2:	66 41 c1 c0 08       	rol    r8w,0x8
    17b7:	45 0f b7 c0          	movzx  r8d,r8w
    17bb:	41 89 d1             	mov    r9d,edx
    17be:	41 c1 e9 10          	shr    r9d,0x10
    17c2:	49 01 f8             	add    r8,rdi
    17c5:	4b 8d 3c 01          	lea    rdi,[r9+r8*1]
    17c9:	48 81 c7 3b df 00 00 	add    rdi,0xdf3b
    17d0:	41 89 f8             	mov    r8d,edi
    17d3:	41 c1 e8 10          	shr    r8d,0x10
    17d7:	44 0f b7 cf          	movzx  r9d,di
    17db:	4d 01 c1             	add    r9,r8
    17de:	48 81 ff 00 00 01 00 	cmp    rdi,0x10000
    17e5:	4c 0f 42 cf          	cmovb  r9,rdi
    17e9:	44 89 cf             	mov    edi,r9d
    17ec:	c1 ef 10             	shr    edi,0x10
    17ef:	45 0f b7 c1          	movzx  r8d,r9w
    17f3:	49 01 f8             	add    r8,rdi
    17f6:	49 81 f9 00 00 01 00 	cmp    r9,0x10000
    17fd:	4d 0f 42 c1          	cmovb  r8,r9
    1801:	44 89 c7             	mov    edi,r8d
    1804:	c1 ef 10             	shr    edi,0x10
    1807:	45 0f b7 c8          	movzx  r9d,r8w
    180b:	49 01 f9             	add    r9,rdi
    180e:	49 81 f8 00 00 01 00 	cmp    r8,0x10000
    1815:	4d 0f 42 c8          	cmovb  r9,r8
    1819:	44 89 cf             	mov    edi,r9d
    181c:	c1 ef 10             	shr    edi,0x10
    181f:	44 01 cf             	add    edi,r9d
    1822:	4d 31 da             	xor    r10,r11
    1825:	81 ca ac 10 00 00    	or     edx,0x10ac
    182b:	48 c1 e2 20          	shl    rdx,0x20
    182f:	48 81 ca 0a c8 00 02 	or     rdx,0x200c80a
    1836:	49 81 f9 00 00 01 00 	cmp    r9,0x10000
    183d:	41 0f 42 f9          	cmovb  edi,r9d
    1841:	c1 e7 10             	shl    edi,0x10
    1844:	48 31 f2             	xor    rdx,rsi
    1847:	48 be 0b 00 ff ff 00 	movabs rsi,0x200ffff000b
    184e:	02 00 00 
    1851:	48 31 d6             	xor    rsi,rdx
    1854:	48 31 fe             	xor    rsi,rdi
    1857:	4c 89 d2             	mov    rdx,r10
    185a:	48 c1 e2 06          	shl    rdx,0x6
    185e:	4c 89 d7             	mov    rdi,r10
    1861:	48 c1 ef 02          	shr    rdi,0x2
    1865:	48 01 f7             	add    rdi,rsi
    1868:	48 01 c2             	add    rdx,rax
    186b:	48 01 fa             	add    rdx,rdi
    186e:	4c 31 d2             	xor    rdx,r10
    1871:	48 89 d6             	mov    rsi,rdx
    1874:	48 c1 e6 06          	shl    rsi,0x6
    1878:	48 01 c6             	add    rsi,rax
    187b:	48 89 d7             	mov    rdi,rdx
    187e:	48 c1 ef 02          	shr    rdi,0x2
    1882:	48 01 fe             	add    rsi,rdi
    1885:	48 83 c6 03          	add    rsi,0x3
    1889:	48 31 d6             	xor    rsi,rdx
    188c:	41 b9 03 00 00 00    	mov    r9d,0x3
    1892:	e9 55 fd ff ff       	jmp    15ec <katran_lb_consistent_hash_select_xdp+0x4ec>

Disassembly of section .fini:

0000000000001898 <_fini>:
    1898:	f3 0f 1e fa          	endbr64
    189c:	48 83 ec 08          	sub    rsp,0x8
    18a0:	48 83 c4 08          	add    rsp,0x8
    18a4:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec a8 00 00 00 	sub    rsp,0xa8
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 7f 00          	mov    rdi,QWORD PTR [rdi+0x0]
  24:	48 39 f7             	cmp    rdi,rsi
  27:	0f 87 79 05 00 00    	ja     0x5a6
  2d:	49 89 f8             	mov    r8,rdi
  30:	49 83 c0 08          	add    r8,0x8
  34:	49 39 f0             	cmp    r8,rsi
  37:	0f 87 69 05 00 00    	ja     0x5a6
  3d:	48 89 fa             	mov    rdx,rdi
  40:	48 83 c2 16          	add    rdx,0x16
  44:	48 39 f2             	cmp    rdx,rsi
  47:	0f 87 59 05 00 00    	ja     0x5a6
  4d:	48 89 f1             	mov    rcx,rsi
  50:	4c 29 c1             	sub    rcx,r8
  53:	48 0f b6 47 14       	movzx  rax,BYTE PTR [rdi+0x14]
  58:	4c 0f b6 47 15       	movzx  r8,BYTE PTR [rdi+0x15]
  5d:	49 c1 e0 08          	shl    r8,0x8
  61:	49 09 c0             	or     r8,rax
  64:	49 81 e0 ff ff 00 00 	and    r8,0xffff
  6b:	49 81 f8 86 dd 00 00 	cmp    r8,0xdd86
  72:	0f 84 4e 04 00 00    	je     0x4c6
  78:	49 83 f8 08          	cmp    r8,0x8
  7c:	0f 85 7f 04 00 00    	jne    0x501
  82:	49 89 f8             	mov    r8,rdi
  85:	49 83 c0 2a          	add    r8,0x2a
  89:	49 39 f0             	cmp    r8,rsi
  8c:	0f 87 61 04 00 00    	ja     0x4f3
  92:	48 0f b6 52 00       	movzx  rdx,BYTE PTR [rdx+0x0]
  97:	48 83 e2 0f          	and    rdx,0xf
  9b:	48 83 fa 05          	cmp    rdx,0x5
  9f:	0f 85 4e 04 00 00    	jne    0x4f3
  a5:	48 0f b6 57 1c       	movzx  rdx,BYTE PTR [rdi+0x1c]
  aa:	48 83 e2 3f          	and    rdx,0x3f
  ae:	4c 0f b6 47 1d       	movzx  r8,BYTE PTR [rdi+0x1d]
  b3:	4c 09 c2             	or     rdx,r8
  b6:	48 81 e2 ff 00 00 00 	and    rdx,0xff
  bd:	48 85 d2             	test   rdx,rdx
  c0:	0f 85 2d 04 00 00    	jne    0x4f3
  c6:	48 0f b6 57 1f       	movzx  rdx,BYTE PTR [rdi+0x1f]
  cb:	41 b8 02 00 00 00    	mov    r8d,0x2
  d1:	41 be 02 00 00 00    	mov    r14d,0x2
  d7:	48 83 fa 01          	cmp    rdx,0x1
  db:	0f 84 54 04 00 00    	je     0x535
  e1:	48 83 fa 11          	cmp    rdx,0x11
  e5:	0f 84 79 0c 00 00    	je     0xd64
  eb:	48 83 fa 06          	cmp    rdx,0x6
  ef:	0f 85 40 04 00 00    	jne    0x535
  f5:	48 89 fa             	mov    rdx,rdi
  f8:	48 83 c2 3e          	add    rdx,0x3e
  fc:	41 b8 01 00 00 00    	mov    r8d,0x1
 102:	41 be 01 00 00 00    	mov    r14d,0x1
 108:	48 39 f2             	cmp    rdx,rsi
 10b:	0f 87 24 04 00 00    	ja     0x535
 111:	48 0f b6 77 27       	movzx  rsi,BYTE PTR [rdi+0x27]
 116:	48 c1 e6 08          	shl    rsi,0x8
 11a:	48 0f b6 57 26       	movzx  rdx,BYTE PTR [rdi+0x26]
 11f:	48 09 d6             	or     rsi,rdx
 122:	48 0f b6 57 28       	movzx  rdx,BYTE PTR [rdi+0x28]
 127:	48 c1 e2 10          	shl    rdx,0x10
 12b:	48 09 d6             	or     rsi,rdx
 12e:	48 0f b6 57 29       	movzx  rdx,BYTE PTR [rdi+0x29]
 133:	48 c1 e2 18          	shl    rdx,0x18
 137:	48 09 d6             	or     rsi,rdx
 13a:	48 c1 e6 20          	shl    rsi,0x20
 13e:	48 c1 ee 20          	shr    rsi,0x20
 142:	41 b8 02 00 00 00    	mov    r8d,0x2
 148:	41 be 02 00 00 00    	mov    r14d,0x2
 14e:	48 81 fe 0a 64 01 01 	cmp    rsi,0x101640a
 155:	0f 85 da 03 00 00    	jne    0x535
 15b:	48 0f b6 77 2d       	movzx  rsi,BYTE PTR [rdi+0x2d]
 160:	48 c1 e6 08          	shl    rsi,0x8
 164:	48 0f b6 57 2c       	movzx  rdx,BYTE PTR [rdi+0x2c]
 169:	48 09 d6             	or     rsi,rdx
 16c:	48 81 e6 ff ff 00 00 	and    rsi,0xffff
 173:	48 81 fe 1f 90 00 00 	cmp    rsi,0x901f
 17a:	0f 85 b5 03 00 00    	jne    0x535
 180:	41 b8 01 00 00 00    	mov    r8d,0x1
 186:	41 be 01 00 00 00    	mov    r14d,0x1
 18c:	48 81 f9 ea 05 00 00 	cmp    rcx,0x5ea
 193:	0f 8f 9c 03 00 00    	jg     0x535
 199:	48 0f b6 5f 18       	movzx  rbx,BYTE PTR [rdi+0x18]
 19e:	48 c1 e3 08          	shl    rbx,0x8
 1a2:	48 0f b6 77 19       	movzx  rsi,BYTE PTR [rdi+0x19]
 1a7:	48 09 f3             	or     rbx,rsi
 1aa:	48 0f b6 4f 17       	movzx  rcx,BYTE PTR [rdi+0x17]
 1af:	4c 0f b6 6f 23       	movzx  r13,BYTE PTR [rdi+0x23]
 1b4:	49 c1 e5 08          	shl    r13,0x8
 1b8:	4c 0f b6 47 22       	movzx  r8,BYTE PTR [rdi+0x22]
 1bd:	4c 0f b6 77 24       	movzx  r14,BYTE PTR [rdi+0x24]
 1c2:	49 c1 e6 10          	shl    r14,0x10
 1c6:	48 0f b6 77 25       	movzx  rsi,BYTE PTR [rdi+0x25]
 1cb:	48 c1 e6 18          	shl    rsi,0x18
 1cf:	48 0f b6 57 2a       	movzx  rdx,BYTE PTR [rdi+0x2a]
 1d4:	4c 0f b6 7f 2b       	movzx  r15,BYTE PTR [rdi+0x2b]
 1d9:	49 c1 e7 08          	shl    r15,0x8
 1dd:	49 09 d7             	or     r15,rdx
 1e0:	48 89 f0             	mov    rax,rsi
 1e3:	4c 09 f0             	or     rax,r14
 1e6:	4c 89 7d e8          	mov    QWORD PTR [rbp-0x18],r15
 1ea:	4c 89 fa             	mov    rdx,r15
 1ed:	0f ca                	bswap  edx
 1ef:	41 bf 00 00 ff ff    	mov    r15d,0xffff0000
 1f5:	4c 21 fa             	and    rdx,r15
 1f8:	48 31 c2             	xor    rdx,rax
 1fb:	48 89 5d f0          	mov    QWORD PTR [rbp-0x10],rbx
 1ff:	48 89 d8             	mov    rax,rbx
 202:	48 83 c0 14          	add    rax,0x14
 206:	66 c1 c8 08          	ror    ax,0x8
 20a:	0f b7 c0             	movzx  eax,ax
 20d:	48 01 c1             	add    rcx,rax
 210:	48 89 55 f8          	mov    QWORD PTR [rbp-0x8],rdx
 214:	48 89 d0             	mov    rax,rdx
 217:	4c 21 f8             	and    rax,r15
 21a:	48 c1 e8 10          	shr    rax,0x10
 21e:	48 01 c1             	add    rcx,rax
 221:	48 81 c1 3b df 00 00 	add    rcx,0xdf3b
 228:	b8 00 00 01 00       	mov    eax,0x10000
 22d:	48 39 c8             	cmp    rax,rcx
 230:	77 11                	ja     0x243
 232:	49 89 cf             	mov    r15,rcx
 235:	49 c1 ef 10          	shr    r15,0x10
 239:	48 81 e1 ff ff 00 00 	and    rcx,0xffff
 240:	4c 01 f9             	add    rcx,r15
 243:	4d 09 c5             	or     r13,r8
 246:	48 39 c8             	cmp    rax,rcx
 249:	77 11                	ja     0x25c
 24b:	49 89 c8             	mov    r8,rcx
 24e:	49 c1 e8 10          	shr    r8,0x10
 252:	48 81 e1 ff ff 00 00 	and    rcx,0xffff
 259:	4c 01 c1             	add    rcx,r8
 25c:	4d 09 f5             	or     r13,r14
 25f:	49 09 f5             	or     r13,rsi
 262:	4c 89 ee             	mov    rsi,r13
 265:	48 c1 e6 20          	shl    rsi,0x20
 269:	48 c1 ee 20          	shr    rsi,0x20
 26d:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
 274:	79 37 9e 
 277:	48 01 d6             	add    rsi,rdx
 27a:	49 89 f0             	mov    r8,rsi
 27d:	49 c1 e0 06          	shl    r8,0x6
 281:	49 89 f7             	mov    r15,rsi
 284:	49 c1 ef 02          	shr    r15,0x2
 288:	4d 01 c7             	add    r15,r8
 28b:	49 b8 1f e0 4b 80 b9 	movabs r8,0x9e3779b9804be01f
 292:	79 37 9e 
 295:	4d 01 c7             	add    r15,r8
 298:	49 31 f7             	xor    r15,rsi
 29b:	48 8b 5d e8          	mov    rbx,QWORD PTR [rbp-0x18]
 29f:	48 81 e3 ff ff 00 00 	and    rbx,0xffff
 2a6:	48 89 da             	mov    rdx,rbx
 2a9:	48 81 c2 f7 c0 cc 70 	add    rdx,0x70ccc0f7
 2b0:	48 89 55 e8          	mov    QWORD PTR [rbp-0x18],rdx
 2b4:	49 89 d0             	mov    r8,rdx
 2b7:	49 c1 e0 0e          	shl    r8,0xe
 2bb:	49 81 c8 33 1c 00 00 	or     r8,0x1c33
 2c2:	48 81 f2 f7 c0 ad e0 	xor    rdx,0xffffffffe0adc0f7
 2c9:	4c 29 c2             	sub    rdx,r8
 2cc:	4d 89 f8             	mov    r8,r15
 2cf:	49 c1 e8 02          	shr    r8,0x2
 2d3:	4d 89 fe             	mov    r14,r15
 2d6:	49 c1 e6 06          	shl    r14,0x6
 2da:	4d 01 c6             	add    r14,r8
 2dd:	41 b8 00 00 e0 ff    	mov    r8d,0xffe00000
 2e3:	48 89 d6             	mov    rsi,rdx
 2e6:	4c 21 c6             	and    rsi,r8
 2e9:	48 c1 ee 15          	shr    rsi,0x15
 2ed:	48 89 d0             	mov    rax,rdx
 2f0:	48 c1 e0 0b          	shl    rax,0xb
 2f4:	48 09 f0             	or     rax,rsi
 2f7:	49 81 c5 f7 c0 ad e0 	add    r13,0xffffffffe0adc0f7
 2fe:	49 89 d0             	mov    r8,rdx
 301:	4d 31 e8             	xor    r8,r13
 304:	49 29 c0             	sub    r8,rax
 307:	49 01 de             	add    r14,rbx
 30a:	48 8b 45 f8          	mov    rax,QWORD PTR [rbp-0x8]
 30e:	48 c1 e0 20          	shl    rax,0x20
 312:	48 be 0a c8 00 02 ac 	movabs rsi,0x10ac0200c80a
 319:	10 00 00 
 31c:	48 09 f0             	or     rax,rsi
 31f:	48 89 45 f8          	mov    QWORD PTR [rbp-0x8],rax
 323:	be 80 ff ff ff       	mov    esi,0xffffff80
 328:	4c 89 c0             	mov    rax,r8
 32b:	48 21 f0             	and    rax,rsi
 32e:	48 c1 e8 07          	shr    rax,0x7
 332:	4c 89 c6             	mov    rsi,r8
 335:	48 c1 e6 19          	shl    rsi,0x19
 339:	48 09 c6             	or     rsi,rax
 33c:	4d 89 c5             	mov    r13,r8
 33f:	48 8b 45 e8          	mov    rax,QWORD PTR [rbp-0x18]
 343:	49 31 c5             	xor    r13,rax
 346:	49 29 f5             	sub    r13,rsi
 349:	4c 89 ee             	mov    rsi,r13
 34c:	b8 00 00 ff ff       	mov    eax,0xffff0000
 351:	48 21 c6             	and    rsi,rax
 354:	48 c1 ee 10          	shr    rsi,0x10
 358:	4c 89 e8             	mov    rax,r13
 35b:	48 c1 e0 10          	shl    rax,0x10
 35f:	48 09 f0             	or     rax,rsi
 362:	4c 89 eb             	mov    rbx,r13
 365:	48 31 d3             	xor    rbx,rdx
 368:	48 29 c3             	sub    rbx,rax
 36b:	48 be 15 7c 69 0f ba 	movabs rsi,0x9e3779ba0f697c15
 372:	79 37 9e 
 375:	49 01 f6             	add    r14,rsi
 378:	4d 31 fe             	xor    r14,r15
 37b:	be 00 00 00 f0       	mov    esi,0xf0000000
 380:	48 89 da             	mov    rdx,rbx
 383:	48 21 f2             	and    rdx,rsi
 386:	48 c1 ea 1c          	shr    rdx,0x1c
 38a:	49 89 df             	mov    r15,rbx
 38d:	49 c1 e7 04          	shl    r15,0x4
 391:	49 09 d7             	or     r15,rdx
 394:	4c 89 f6             	mov    rsi,r14
 397:	48 c1 ee 02          	shr    rsi,0x2
 39b:	4c 89 f0             	mov    rax,r14
 39e:	48 c1 e0 06          	shl    rax,0x6
 3a2:	48 01 f0             	add    rax,rsi
 3a5:	48 89 de             	mov    rsi,rbx
 3a8:	4c 31 c6             	xor    rsi,r8
 3ab:	4c 29 fe             	sub    rsi,r15
 3ae:	ba 00 00 fc ff       	mov    edx,0xfffc0000
 3b3:	49 89 f0             	mov    r8,rsi
 3b6:	49 21 d0             	and    r8,rdx
 3b9:	49 c1 e8 12          	shr    r8,0x12
 3bd:	48 89 f2             	mov    rdx,rsi
 3c0:	48 c1 e2 0e          	shl    rdx,0xe
 3c4:	4c 09 c2             	or     rdx,r8
 3c7:	4c 31 ee             	xor    rsi,r13
 3ca:	48 29 d6             	sub    rsi,rdx
 3cd:	ba 00 ff ff ff       	mov    edx,0xffffff00
 3d2:	49 89 f0             	mov    r8,rsi
 3d5:	49 21 d0             	and    r8,rdx
 3d8:	49 c1 e8 08          	shr    r8,0x8
 3dc:	48 89 f2             	mov    rdx,rsi
 3df:	48 c1 e2 18          	shl    rdx,0x18
 3e3:	4c 09 c2             	or     rdx,r8
 3e6:	48 31 de             	xor    rsi,rbx
 3e9:	48 29 d6             	sub    rsi,rdx
 3ec:	48 c1 e1 10          	shl    rcx,0x10
 3f0:	48 c1 e1 20          	shl    rcx,0x20
 3f4:	48 c1 e9 20          	shr    rcx,0x20
 3f8:	48 8b 5d f8          	mov    rbx,QWORD PTR [rbp-0x8]
 3fc:	48 31 cb             	xor    rbx,rcx
 3ff:	4c 8b 45 f0          	mov    r8,QWORD PTR [rbp-0x10]
 403:	49 81 e0 ff ff 00 00 	and    r8,0xffff
 40a:	4c 31 c3             	xor    rbx,r8
 40d:	48 ba 0b 00 ff ff 00 	movabs rdx,0x200ffff000b
 414:	02 00 00 
 417:	48 31 d3             	xor    rbx,rdx
 41a:	48 c1 e6 20          	shl    rsi,0x20
 41e:	48 c1 ee 20          	shr    rsi,0x20
 422:	50                   	push   rax
 423:	52                   	push   rdx
 424:	49 c7 c3 01 00 01 00 	mov    r11,0x10001
 42b:	48 89 f0             	mov    rax,rsi
 42e:	31 d2                	xor    edx,edx
 430:	49 f7 f3             	div    r11
 433:	48 89 d6             	mov    rsi,rdx
 436:	5a                   	pop    rdx
 437:	58                   	pop    rax
 438:	48 01 f0             	add    rax,rsi
 43b:	48 be 15 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c15
 442:	79 37 9e 
 445:	48 01 f0             	add    rax,rsi
 448:	4c 31 f0             	xor    rax,r14
 44b:	48 89 c6             	mov    rsi,rax
 44e:	48 c1 ee 02          	shr    rsi,0x2
 452:	48 89 c2             	mov    rdx,rax
 455:	48 c1 e2 06          	shl    rdx,0x6
 459:	48 01 f2             	add    rdx,rsi
 45c:	48 be 16 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c16
 463:	79 37 9e 
 466:	48 01 f2             	add    rdx,rsi
 469:	48 31 c2             	xor    rdx,rax
 46c:	48 89 d6             	mov    rsi,rdx
 46f:	48 c1 ee 02          	shr    rsi,0x2
 473:	48 89 d1             	mov    rcx,rdx
 476:	48 c1 e1 06          	shl    rcx,0x6
 47a:	48 01 f1             	add    rcx,rsi
 47d:	48 b8 15 7c 4a 7f b9 	movabs rax,0x9e3779b97f4a7c15
 484:	79 37 9e 
 487:	48 01 c1             	add    rcx,rax
 48a:	48 31 d1             	xor    rcx,rdx
 48d:	48 89 ce             	mov    rsi,rcx
 490:	48 c1 e6 06          	shl    rsi,0x6
 494:	49 01 f0             	add    r8,rsi
 497:	48 89 ce             	mov    rsi,rcx
 49a:	48 c1 ee 02          	shr    rsi,0x2
 49e:	49 01 f0             	add    r8,rsi
 4a1:	49 01 c0             	add    r8,rax
 4a4:	49 31 c8             	xor    r8,rcx
 4a7:	4c 89 c6             	mov    rsi,r8
 4aa:	48 c1 ee 02          	shr    rsi,0x2
 4ae:	4c 89 c2             	mov    rdx,r8
 4b1:	48 c1 e2 06          	shl    rdx,0x6
 4b5:	48 01 f2             	add    rdx,rsi
 4b8:	48 01 da             	add    rdx,rbx
 4bb:	48 01 c2             	add    rdx,rax
 4be:	4c 31 c2             	xor    rdx,r8
 4c1:	e9 72 08 00 00       	jmp    0xd38
 4c6:	48 89 fa             	mov    rdx,rdi
 4c9:	48 83 c2 3e          	add    rdx,0x3e
 4cd:	48 39 f2             	cmp    rdx,rsi
 4d0:	77 21                	ja     0x4f3
 4d2:	48 0f b6 5f 1c       	movzx  rbx,BYTE PTR [rdi+0x1c]
 4d7:	41 b8 02 00 00 00    	mov    r8d,0x2
 4dd:	41 be 02 00 00 00    	mov    r14d,0x2
 4e3:	48 83 fb 3a          	cmp    rbx,0x3a
 4e7:	74 4c                	je     0x535
 4e9:	48 83 fb 2c          	cmp    rbx,0x2c
 4ed:	0f 85 c0 00 00 00    	jne    0x5b3
 4f3:	41 b8 01 00 00 00    	mov    r8d,0x1
 4f9:	41 be 01 00 00 00    	mov    r14d,0x1
 4ff:	eb 34                	jmp    0x535
 501:	48 be 15 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c15
 508:	79 37 9e 
 50b:	48 01 f1             	add    rcx,rsi
 50e:	48 89 ce             	mov    rsi,rcx
 511:	48 c1 ee 02          	shr    rsi,0x2
 515:	49 89 c8             	mov    r8,rcx
 518:	49 c1 e0 06          	shl    r8,0x6
 51c:	49 01 f0             	add    r8,rsi
 51f:	48 be 17 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c17
 526:	79 37 9e 
 529:	49 01 f0             	add    r8,rsi
 52c:	49 31 c8             	xor    r8,rcx
 52f:	41 be 02 00 00 00    	mov    r14d,0x2
 535:	4c 89 c2             	mov    rdx,r8
 538:	48 c1 ea 02          	shr    rdx,0x2
 53c:	4c 89 c6             	mov    rsi,r8
 53f:	48 c1 e6 06          	shl    rsi,0x6
 543:	48 01 d6             	add    rsi,rdx
 546:	4c 01 f6             	add    rsi,r14
 549:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
 550:	79 37 9e 
 553:	48 01 d6             	add    rsi,rdx
 556:	4c 31 c6             	xor    rsi,r8
 559:	48 89 f2             	mov    rdx,rsi
 55c:	48 c1 ea 38          	shr    rdx,0x38
 560:	88 57 07             	mov    BYTE PTR [rdi+0x7],dl
 563:	48 89 f2             	mov    rdx,rsi
 566:	48 c1 ea 30          	shr    rdx,0x30
 56a:	88 57 06             	mov    BYTE PTR [rdi+0x6],dl
 56d:	48 89 f2             	mov    rdx,rsi
 570:	48 c1 ea 28          	shr    rdx,0x28
 574:	88 57 05             	mov    BYTE PTR [rdi+0x5],dl
 577:	48 89 f2             	mov    rdx,rsi
 57a:	48 c1 ea 20          	shr    rdx,0x20
 57e:	88 57 04             	mov    BYTE PTR [rdi+0x4],dl
 581:	48 89 f2             	mov    rdx,rsi
 584:	48 c1 ea 18          	shr    rdx,0x18
 588:	88 57 03             	mov    BYTE PTR [rdi+0x3],dl
 58b:	48 89 f2             	mov    rdx,rsi
 58e:	48 c1 ea 10          	shr    rdx,0x10
 592:	88 57 02             	mov    BYTE PTR [rdi+0x2],dl
 595:	40 88 77 00          	mov    BYTE PTR [rdi+0x0],sil
 599:	48 c1 ee 08          	shr    rsi,0x8
 59d:	40 88 77 01          	mov    BYTE PTR [rdi+0x1],sil
 5a1:	b8 02 00 00 00       	mov    eax,0x2
 5a6:	41 5f                	pop    r15
 5a8:	41 5e                	pop    r14
 5aa:	41 5d                	pop    r13
 5ac:	5b                   	pop    rbx
 5ad:	c9                   	leave
 5ae:	e9 01 08 c1 dc       	jmp    0xffffffffdcc10db4
 5b3:	48 0f b6 57 1a       	movzx  rdx,BYTE PTR [rdi+0x1a]
 5b8:	48 89 55 f0          	mov    QWORD PTR [rbp-0x10],rdx
 5bc:	48 0f b6 57 1b       	movzx  rdx,BYTE PTR [rdi+0x1b]
 5c1:	48 89 95 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rdx
 5c8:	48 0f b6 57 16       	movzx  rdx,BYTE PTR [rdi+0x16]
 5cd:	48 89 95 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rdx
 5d4:	48 0f b6 57 17       	movzx  rdx,BYTE PTR [rdi+0x17]
 5d9:	48 89 95 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rdx
 5e0:	48 0f b6 57 23       	movzx  rdx,BYTE PTR [rdi+0x23]
 5e5:	48 89 55 a8          	mov    QWORD PTR [rbp-0x58],rdx
 5e9:	48 0f b6 57 22       	movzx  rdx,BYTE PTR [rdi+0x22]
 5ee:	48 89 95 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdx
 5f5:	48 0f b6 57 27       	movzx  rdx,BYTE PTR [rdi+0x27]
 5fa:	48 89 55 98          	mov    QWORD PTR [rbp-0x68],rdx
 5fe:	48 0f b6 57 26       	movzx  rdx,BYTE PTR [rdi+0x26]
 603:	48 89 95 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rdx
 60a:	48 0f b6 57 28       	movzx  rdx,BYTE PTR [rdi+0x28]
 60f:	48 89 55 b8          	mov    QWORD PTR [rbp-0x48],rdx
 613:	48 0f b6 57 24       	movzx  rdx,BYTE PTR [rdi+0x24]
 618:	48 89 55 c0          	mov    QWORD PTR [rbp-0x40],rdx
 61c:	48 0f b6 57 1f       	movzx  rdx,BYTE PTR [rdi+0x1f]
 621:	48 89 55 a0          	mov    QWORD PTR [rbp-0x60],rdx
 625:	48 0f b6 57 1e       	movzx  rdx,BYTE PTR [rdi+0x1e]
 62a:	48 89 55 80          	mov    QWORD PTR [rbp-0x80],rdx
 62e:	48 0f b6 57 25       	movzx  rdx,BYTE PTR [rdi+0x25]
 633:	48 89 55 88          	mov    QWORD PTR [rbp-0x78],rdx
 637:	48 0f b6 57 29       	movzx  rdx,BYTE PTR [rdi+0x29]
 63c:	48 89 55 90          	mov    QWORD PTR [rbp-0x70],rdx
 640:	48 0f b6 57 2a       	movzx  rdx,BYTE PTR [rdi+0x2a]
 645:	48 89 55 b0          	mov    QWORD PTR [rbp-0x50],rdx
 649:	48 0f b6 57 2e       	movzx  rdx,BYTE PTR [rdi+0x2e]
 64e:	48 89 55 f8          	mov    QWORD PTR [rbp-0x8],rdx
 652:	48 0f b6 57 2b       	movzx  rdx,BYTE PTR [rdi+0x2b]
 657:	48 89 55 e0          	mov    QWORD PTR [rbp-0x20],rdx
 65b:	48 0f b6 57 2c       	movzx  rdx,BYTE PTR [rdi+0x2c]
 660:	48 89 55 d8          	mov    QWORD PTR [rbp-0x28],rdx
 664:	48 0f b6 57 2d       	movzx  rdx,BYTE PTR [rdi+0x2d]
 669:	48 89 55 e8          	mov    QWORD PTR [rbp-0x18],rdx
 66d:	48 0f b6 57 2f       	movzx  rdx,BYTE PTR [rdi+0x2f]
 672:	48 0f b6 47 30       	movzx  rax,BYTE PTR [rdi+0x30]
 677:	4c 0f b6 7f 31       	movzx  r15,BYTE PTR [rdi+0x31]
 67c:	4c 0f b6 47 20       	movzx  r8,BYTE PTR [rdi+0x20]
 681:	4c 89 45 c8          	mov    QWORD PTR [rbp-0x38],r8
 685:	4c 0f b6 47 21       	movzx  r8,BYTE PTR [rdi+0x21]
 68a:	4c 89 45 d0          	mov    QWORD PTR [rbp-0x30],r8
 68e:	48 83 fb 11          	cmp    rbx,0x11
 692:	74 2e                	je     0x6c2
 694:	41 b8 02 00 00 00    	mov    r8d,0x2
 69a:	48 83 fb 06          	cmp    rbx,0x6
 69e:	0f 85 91 fe ff ff    	jne    0x535
 6a4:	41 b8 01 00 00 00    	mov    r8d,0x1
 6aa:	49 89 fd             	mov    r13,rdi
 6ad:	49 83 c5 52          	add    r13,0x52
 6b1:	41 be 01 00 00 00    	mov    r14d,0x1
 6b7:	49 39 f5             	cmp    r13,rsi
 6ba:	0f 87 75 fe ff ff    	ja     0x535
 6c0:	eb 1c                	jmp    0x6de
 6c2:	41 b8 01 00 00 00    	mov    r8d,0x1
 6c8:	49 89 fd             	mov    r13,rdi
 6cb:	49 83 c5 46          	add    r13,0x46
 6cf:	41 be 01 00 00 00    	mov    r14d,0x1
 6d5:	49 39 f5             	cmp    r13,rsi
 6d8:	0f 87 57 fe ff ff    	ja     0x535
 6de:	41 b8 02 00 00 00    	mov    r8d,0x2
 6e4:	41 be 02 00 00 00    	mov    r14d,0x2
 6ea:	48 83 fb 06          	cmp    rbx,0x6
 6ee:	0f 85 41 fe ff ff    	jne    0x535
 6f4:	48 c1 e2 08          	shl    rdx,0x8
 6f8:	48 c1 e0 10          	shl    rax,0x10
 6fc:	49 c1 e7 18          	shl    r15,0x18
 700:	49 09 c7             	or     r15,rax
 703:	49 09 d7             	or     r15,rdx
 706:	48 8b 75 f8          	mov    rsi,QWORD PTR [rbp-0x8]
 70a:	49 09 f7             	or     r15,rsi
 70d:	49 c1 e7 20          	shl    r15,0x20
 711:	49 c1 ef 20          	shr    r15,0x20
 715:	49 81 ff 0a 64 01 01 	cmp    r15,0x101640a
 71c:	0f 85 13 fe ff ff    	jne    0x535
 722:	48 0f b6 77 41       	movzx  rsi,BYTE PTR [rdi+0x41]
 727:	48 c1 e6 08          	shl    rsi,0x8
 72b:	48 0f b6 57 40       	movzx  rdx,BYTE PTR [rdi+0x40]
 730:	48 09 d6             	or     rsi,rdx
 733:	48 81 e6 ff ff 00 00 	and    rsi,0xffff
 73a:	48 81 fe 1f 90 00 00 	cmp    rsi,0x901f
 741:	0f 85 ee fd ff ff    	jne    0x535
 747:	41 b8 01 00 00 00    	mov    r8d,0x1
 74d:	41 be 01 00 00 00    	mov    r14d,0x1
 753:	48 81 f9 ea 05 00 00 	cmp    rcx,0x5ea
 75a:	0f 8f d5 fd ff ff    	jg     0x535
 760:	48 8b 55 f0          	mov    rdx,QWORD PTR [rbp-0x10]
 764:	48 c1 e2 08          	shl    rdx,0x8
 768:	48 8b b5 58 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xa8]
 76f:	48 09 f2             	or     rdx,rsi
 772:	4c 8b b5 78 ff ff ff 	mov    r14,QWORD PTR [rbp-0x88]
 779:	49 c1 e6 04          	shl    r14,0x4
 77d:	48 8b b5 60 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xa0]
 784:	48 c1 ee 04          	shr    rsi,0x4
 788:	48 83 e6 0f          	and    rsi,0xf
 78c:	49 09 f6             	or     r14,rsi
 78f:	4c 8b 7d a8          	mov    r15,QWORD PTR [rbp-0x58]
 793:	49 c1 e7 08          	shl    r15,0x8
 797:	48 8b b5 68 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x98]
 79e:	49 09 f7             	or     r15,rsi
 7a1:	48 8b 5d 98          	mov    rbx,QWORD PTR [rbp-0x68]
 7a5:	48 c1 e3 08          	shl    rbx,0x8
 7a9:	48 8b b5 70 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x90]
 7b0:	48 09 f3             	or     rbx,rsi
 7b3:	48 8b 75 b8          	mov    rsi,QWORD PTR [rbp-0x48]
 7b7:	48 c1 e6 10          	shl    rsi,0x10
 7bb:	48 89 75 b8          	mov    QWORD PTR [rbp-0x48],rsi
 7bf:	48 8b 75 c0          	mov    rsi,QWORD PTR [rbp-0x40]
 7c3:	48 c1 e6 10          	shl    rsi,0x10
 7c7:	48 89 75 c0          	mov    QWORD PTR [rbp-0x40],rsi
 7cb:	4c 8b 45 a0          	mov    r8,QWORD PTR [rbp-0x60]
 7cf:	49 c1 e0 08          	shl    r8,0x8
 7d3:	48 8b 4d c8          	mov    rcx,QWORD PTR [rbp-0x38]
 7d7:	48 c1 e1 10          	shl    rcx,0x10
 7db:	48 8b 45 d0          	mov    rax,QWORD PTR [rbp-0x30]
 7df:	48 c1 e0 18          	shl    rax,0x18
 7e3:	48 0f b6 77 3e       	movzx  rsi,BYTE PTR [rdi+0x3e]
 7e8:	4c 0f b6 6f 3f       	movzx  r13,BYTE PTR [rdi+0x3f]
 7ed:	49 c1 e5 08          	shl    r13,0x8
 7f1:	49 09 f5             	or     r13,rsi
 7f4:	48 89 4d c8          	mov    QWORD PTR [rbp-0x38],rcx
 7f8:	48 89 ce             	mov    rsi,rcx
 7fb:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
 7ff:	48 09 c6             	or     rsi,rax
 802:	4c 89 6d a8          	mov    QWORD PTR [rbp-0x58],r13
 806:	41 0f cd             	bswap  r13d
 809:	b9 00 00 ff ff       	mov    ecx,0xffff0000
 80e:	49 21 cd             	and    r13,rcx
 811:	49 31 f5             	xor    r13,rsi
 814:	49 81 e6 ff 00 00 00 	and    r14,0xff
 81b:	48 89 55 f0          	mov    QWORD PTR [rbp-0x10],rdx
 81f:	48 89 d6             	mov    rsi,rdx
 822:	48 83 c6 14          	add    rsi,0x14
 826:	66 c1 ce 08          	ror    si,0x8
 82a:	0f b7 f6             	movzx  esi,si
 82d:	4c 01 f6             	add    rsi,r14
 830:	4c 89 6d f8          	mov    QWORD PTR [rbp-0x8],r13
 834:	4c 89 ea             	mov    rdx,r13
 837:	48 21 ca             	and    rdx,rcx
 83a:	48 c1 ea 10          	shr    rdx,0x10
 83e:	48 01 d6             	add    rsi,rdx
 841:	48 81 c6 3b df 00 00 	add    rsi,0xdf3b
 848:	41 be 00 00 01 00    	mov    r14d,0x10000
 84e:	49 39 f6             	cmp    r14,rsi
 851:	77 11                	ja     0x864
 853:	48 89 f1             	mov    rcx,rsi
 856:	48 c1 e9 10          	shr    rcx,0x10
 85a:	48 81 e6 ff ff 00 00 	and    rsi,0xffff
 861:	48 01 ce             	add    rsi,rcx
 864:	48 8b 55 b8          	mov    rdx,QWORD PTR [rbp-0x48]
 868:	48 09 d3             	or     rbx,rdx
 86b:	48 8b 55 c0          	mov    rdx,QWORD PTR [rbp-0x40]
 86f:	49 09 d7             	or     r15,rdx
 872:	48 8b 55 80          	mov    rdx,QWORD PTR [rbp-0x80]
 876:	49 09 d0             	or     r8,rdx
 879:	48 8b 55 88          	mov    rdx,QWORD PTR [rbp-0x78]
 87d:	48 c1 e2 18          	shl    rdx,0x18
 881:	4c 8b 6d 90          	mov    r13,QWORD PTR [rbp-0x70]
 885:	49 c1 e5 18          	shl    r13,0x18
 889:	48 8b 45 e8          	mov    rax,QWORD PTR [rbp-0x18]
 88d:	49 39 f6             	cmp    r14,rsi
 890:	77 11                	ja     0x8a3
 892:	48 89 f1             	mov    rcx,rsi
 895:	48 c1 e9 10          	shr    rcx,0x10
 899:	48 81 e6 ff ff 00 00 	and    rsi,0xffff
 8a0:	48 01 ce             	add    rsi,rcx
 8a3:	49 09 d7             	or     r15,rdx
 8a6:	4c 09 eb             	or     rbx,r13
 8a9:	48 8b 55 c8          	mov    rdx,QWORD PTR [rbp-0x38]
 8ad:	49 09 d0             	or     r8,rdx
 8b0:	41 bd 00 00 01 00    	mov    r13d,0x10000
 8b6:	48 8b 4d e0          	mov    rcx,QWORD PTR [rbp-0x20]
 8ba:	48 c1 e1 08          	shl    rcx,0x8
 8be:	48 89 4d e0          	mov    QWORD PTR [rbp-0x20],rcx
 8c2:	48 8b 4d d8          	mov    rcx,QWORD PTR [rbp-0x28]
 8c6:	48 c1 e1 10          	shl    rcx,0x10
 8ca:	48 89 4d d8          	mov    QWORD PTR [rbp-0x28],rcx
 8ce:	48 c1 e0 18          	shl    rax,0x18
 8d2:	48 89 45 e8          	mov    QWORD PTR [rbp-0x18],rax
 8d6:	48 8b 55 d0          	mov    rdx,QWORD PTR [rbp-0x30]
 8da:	49 09 d0             	or     r8,rdx
 8dd:	49 89 de             	mov    r14,rbx
 8e0:	49 81 c6 ff c0 ad de 	add    r14,0xffffffffdeadc0ff
 8e7:	49 81 c7 ff c0 ad de 	add    r15,0xffffffffdeadc0ff
 8ee:	4c 89 c1             	mov    rcx,r8
 8f1:	48 c1 e1 20          	shl    rcx,0x20
 8f5:	48 c1 e9 20          	shr    rcx,0x20
 8f9:	48 ba 15 7c 4a 7f b9 	movabs rdx,0x9e3779b97f4a7c15
 900:	79 37 9e 
 903:	48 01 d1             	add    rcx,rdx
 906:	48 89 c8             	mov    rax,rcx
 909:	48 c1 e8 02          	shr    rax,0x2
 90d:	48 89 ca             	mov    rdx,rcx
 910:	48 c1 e2 06          	shl    rdx,0x6
 914:	48 01 c2             	add    rdx,rax
 917:	48 b8 1f e0 4b 80 b9 	movabs rax,0x9e3779b9804be01f
 91e:	79 37 9e 
 921:	48 01 c2             	add    rdx,rax
 924:	49 29 d8             	sub    r8,rbx
 927:	bb 00 00 00 f0       	mov    ebx,0xf0000000
 92c:	4c 89 f0             	mov    rax,r14
 92f:	48 21 d8             	and    rax,rbx
 932:	48 c1 e8 1c          	shr    rax,0x1c
 936:	4c 89 f3             	mov    rbx,r14
 939:	48 c1 e3 04          	shl    rbx,0x4
 93d:	48 09 c3             	or     rbx,rax
 940:	48 31 ca             	xor    rdx,rcx
 943:	49 31 d8             	xor    r8,rbx
 946:	b9 00 00 00 fc       	mov    ecx,0xfc000000
 94b:	4c 89 c0             	mov    rax,r8
 94e:	48 21 c8             	and    rax,rcx
 951:	48 c1 e8 1a          	shr    rax,0x1a
 955:	4c 89 c1             	mov    rcx,r8
 958:	48 c1 e1 06          	shl    rcx,0x6
 95c:	48 09 c1             	or     rcx,rax
 95f:	48 8b 45 a8          	mov    rax,QWORD PTR [rbp-0x58]
 963:	48 25 ff ff 00 00    	and    rax,0xffff
 969:	48 89 d3             	mov    rbx,rdx
 96c:	48 c1 e3 06          	shl    rbx,0x6
 970:	48 01 c3             	add    rbx,rax
 973:	49 89 c5             	mov    r13,rax
 976:	48 89 d0             	mov    rax,rdx
 979:	48 c1 e8 02          	shr    rax,0x2
 97d:	48 01 c3             	add    rbx,rax
 980:	4d 01 fe             	add    r14,r15
 983:	4d 29 c7             	sub    r15,r8
 986:	49 31 cf             	xor    r15,rcx
 989:	b9 00 00 00 ff       	mov    ecx,0xff000000
 98e:	4c 89 f8             	mov    rax,r15
 991:	48 21 c8             	and    rax,rcx
 994:	48 c1 e8 18          	shr    rax,0x18
 998:	4c 89 f9             	mov    rcx,r15
 99b:	48 c1 e1 08          	shl    rcx,0x8
 99f:	48 09 c1             	or     rcx,rax
 9a2:	48 b8 15 7c 69 0f ba 	movabs rax,0x9e3779ba0f697c15
 9a9:	79 37 9e 
 9ac:	48 01 c3             	add    rbx,rax
 9af:	48 89 5d d0          	mov    QWORD PTR [rbp-0x30],rbx
 9b3:	4c 89 e8             	mov    rax,r13
 9b6:	48 05 f7 c0 cc 70    	add    rax,0x70ccc0f7
 9bc:	48 89 45 a8          	mov    QWORD PTR [rbp-0x58],rax
 9c0:	49 89 c5             	mov    r13,rax
 9c3:	49 c1 e5 0e          	shl    r13,0xe
 9c7:	49 81 cd 33 1c 00 00 	or     r13,0x1c33
 9ce:	48 35 f7 c0 ad e0    	xor    rax,0xffffffffe0adc0f7
 9d4:	4c 29 e8             	sub    rax,r13
 9d7:	48 89 c3             	mov    rbx,rax
 9da:	4c 8b 6d f8          	mov    r13,QWORD PTR [rbp-0x8]
 9de:	49 c1 e5 20          	shl    r13,0x20
 9e2:	48 b8 0a c8 00 02 ac 	movabs rax,0x10ac0200c80a
 9e9:	10 00 00 
 9ec:	49 09 c5             	or     r13,rax
 9ef:	4c 89 6d f8          	mov    QWORD PTR [rbp-0x8],r13
 9f3:	4d 01 f0             	add    r8,r14
 9f6:	4d 29 fe             	sub    r14,r15
 9f9:	49 31 ce             	xor    r14,rcx
 9fc:	4c 89 f1             	mov    rcx,r14
 9ff:	b8 00 00 ff ff       	mov    eax,0xffff0000
 a04:	48 21 c1             	and    rcx,rax
 a07:	48 c1 e9 10          	shr    rcx,0x10
 a0b:	4c 89 f0             	mov    rax,r14
 a0e:	48 c1 e0 10          	shl    rax,0x10
 a12:	48 09 c8             	or     rax,rcx
 a15:	48 8b 4d d0          	mov    rcx,QWORD PTR [rbp-0x30]
 a19:	48 31 d1             	xor    rcx,rdx
 a1c:	48 89 4d d0          	mov    QWORD PTR [rbp-0x30],rcx
 a20:	ba 00 00 e0 ff       	mov    edx,0xffe00000
 a25:	48 89 5d c8          	mov    QWORD PTR [rbp-0x38],rbx
 a29:	48 89 d9             	mov    rcx,rbx
 a2c:	48 21 d1             	and    rcx,rdx
 a2f:	48 c1 e9 15          	shr    rcx,0x15
 a33:	48 89 da             	mov    rdx,rbx
 a36:	48 c1 e2 0b          	shl    rdx,0xb
 a3a:	48 09 ca             	or     rdx,rcx
 a3d:	48 89 55 c0          	mov    QWORD PTR [rbp-0x40],rdx
 a41:	4d 01 c7             	add    r15,r8
 a44:	4d 29 f0             	sub    r8,r14
 a47:	49 31 c0             	xor    r8,rax
 a4a:	b9 00 e0 ff ff       	mov    ecx,0xffffe000
 a4f:	4c 89 c0             	mov    rax,r8
 a52:	48 21 c8             	and    rax,rcx
 a55:	48 c1 e8 0d          	shr    rax,0xd
 a59:	4c 89 c1             	mov    rcx,r8
 a5c:	48 c1 e1 13          	shl    rcx,0x13
 a60:	48 09 c1             	or     rcx,rax
 a63:	4d 01 fe             	add    r14,r15
 a66:	4d 29 c7             	sub    r15,r8
 a69:	49 31 cf             	xor    r15,rcx
 a6c:	48 8b 5d d0          	mov    rbx,QWORD PTR [rbp-0x30]
 a70:	48 89 d9             	mov    rcx,rbx
 a73:	48 c1 e9 02          	shr    rcx,0x2
 a77:	48 c1 e3 06          	shl    rbx,0x6
 a7b:	48 01 cb             	add    rbx,rcx
 a7e:	4d 01 f0             	add    r8,r14
 a81:	48 8b 45 e8          	mov    rax,QWORD PTR [rbp-0x18]
 a85:	4c 01 c0             	add    rax,r8
 a88:	4c 89 f9             	mov    rcx,r15
 a8b:	4c 01 c1             	add    rcx,r8
 a8e:	41 b8 00 00 fc ff    	mov    r8d,0xfffc0000
 a94:	49 89 cd             	mov    r13,rcx
 a97:	4d 21 c5             	and    r13,r8
 a9a:	49 c1 ed 12          	shr    r13,0x12
 a9e:	49 89 c0             	mov    r8,rax
 aa1:	4c 89 f8             	mov    rax,r15
 aa4:	49 89 cf             	mov    r15,rcx
 aa7:	49 c1 e7 0e          	shl    r15,0xe
 aab:	4d 09 ef             	or     r15,r13
 aae:	49 89 c5             	mov    r13,rax
 ab1:	ba 00 00 00 f0       	mov    edx,0xf0000000
 ab6:	49 21 d5             	and    r13,rdx
 ab9:	49 c1 ed 1c          	shr    r13,0x1c
 abd:	49 29 c6             	sub    r14,rax
 ac0:	48 c1 e0 04          	shl    rax,0x4
 ac4:	4c 09 e8             	or     rax,r13
 ac7:	49 31 c6             	xor    r14,rax
 aca:	49 31 ce             	xor    r14,rcx
 acd:	4d 29 fe             	sub    r14,r15
 ad0:	4d 89 f5             	mov    r13,r14
 ad3:	ba 00 00 e0 ff       	mov    edx,0xffe00000
 ad8:	49 21 d5             	and    r13,rdx
 adb:	49 c1 ed 15          	shr    r13,0x15
 adf:	4c 89 f2             	mov    rdx,r14
 ae2:	48 c1 e2 0b          	shl    rdx,0xb
 ae6:	4c 09 ea             	or     rdx,r13
 ae9:	48 c1 e6 10          	shl    rsi,0x10
 aed:	48 c1 e6 20          	shl    rsi,0x20
 af1:	48 c1 ee 20          	shr    rsi,0x20
 af5:	4c 8b 6d f8          	mov    r13,QWORD PTR [rbp-0x8]
 af9:	49 31 f5             	xor    r13,rsi
 afc:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
 b00:	49 01 f0             	add    r8,rsi
 b03:	48 8b 75 e0          	mov    rsi,QWORD PTR [rbp-0x20]
 b07:	49 01 f0             	add    r8,rsi
 b0a:	48 8b 75 b0          	mov    rsi,QWORD PTR [rbp-0x50]
 b0e:	49 01 f0             	add    r8,rsi
 b11:	4d 31 f0             	xor    r8,r14
 b14:	49 29 d0             	sub    r8,rdx
 b17:	48 8b 45 f0          	mov    rax,QWORD PTR [rbp-0x10]
 b1b:	48 25 ff ff 00 00    	and    rax,0xffff
 b21:	4c 89 ea             	mov    rdx,r13
 b24:	48 31 c2             	xor    rdx,rax
 b27:	48 be 0b 00 ff ff 00 	movabs rsi,0x200ffff000b
 b2e:	02 00 00 
 b31:	48 31 f2             	xor    rdx,rsi
 b34:	48 89 55 f8          	mov    QWORD PTR [rbp-0x8],rdx
 b38:	ba 80 ff ff ff       	mov    edx,0xffffff80
 b3d:	4c 89 c6             	mov    rsi,r8
 b40:	48 21 d6             	and    rsi,rdx
 b43:	48 c1 ee 07          	shr    rsi,0x7
 b47:	4c 89 c2             	mov    rdx,r8
 b4a:	48 c1 e2 19          	shl    rdx,0x19
 b4e:	48 09 f2             	or     rdx,rsi
 b51:	4d 89 c5             	mov    r13,r8
 b54:	49 31 cd             	xor    r13,rcx
 b57:	49 29 d5             	sub    r13,rdx
 b5a:	4c 89 ee             	mov    rsi,r13
 b5d:	41 bf 00 00 ff ff    	mov    r15d,0xffff0000
 b63:	4c 21 fe             	and    rsi,r15
 b66:	48 c1 ee 10          	shr    rsi,0x10
 b6a:	4c 89 ea             	mov    rdx,r13
 b6d:	48 c1 e2 10          	shl    rdx,0x10
 b71:	48 09 f2             	or     rdx,rsi
 b74:	4c 89 ee             	mov    rsi,r13
 b77:	4c 31 f6             	xor    rsi,r14
 b7a:	48 29 d6             	sub    rsi,rdx
 b7d:	48 89 f2             	mov    rdx,rsi
 b80:	41 be 00 00 00 f0    	mov    r14d,0xf0000000
 b86:	4c 21 f2             	and    rdx,r14
 b89:	48 c1 ea 1c          	shr    rdx,0x1c
 b8d:	48 89 f1             	mov    rcx,rsi
 b90:	48 c1 e1 04          	shl    rcx,0x4
 b94:	48 09 d1             	or     rcx,rdx
 b97:	48 89 f2             	mov    rdx,rsi
 b9a:	4c 31 c2             	xor    rdx,r8
 b9d:	48 29 ca             	sub    rdx,rcx
 ba0:	48 89 d1             	mov    rcx,rdx
 ba3:	41 b8 00 00 fc ff    	mov    r8d,0xfffc0000
 ba9:	4c 21 c1             	and    rcx,r8
 bac:	48 c1 e9 12          	shr    rcx,0x12
 bb0:	49 89 d0             	mov    r8,rdx
 bb3:	49 c1 e0 0e          	shl    r8,0xe
 bb7:	49 09 c8             	or     r8,rcx
 bba:	4c 31 ea             	xor    rdx,r13
 bbd:	4c 29 c2             	sub    rdx,r8
 bc0:	b9 00 ff ff ff       	mov    ecx,0xffffff00
 bc5:	49 89 d0             	mov    r8,rdx
 bc8:	49 21 c8             	and    r8,rcx
 bcb:	49 c1 e8 08          	shr    r8,0x8
 bcf:	49 89 d5             	mov    r13,rdx
 bd2:	49 c1 e5 18          	shl    r13,0x18
 bd6:	4d 09 c5             	or     r13,r8
 bd9:	48 31 f2             	xor    rdx,rsi
 bdc:	4c 29 ea             	sub    rdx,r13
 bdf:	48 81 c2 f7 c0 ad e0 	add    rdx,0xffffffffe0adc0f7
 be6:	48 8b 4d c8          	mov    rcx,QWORD PTR [rbp-0x38]
 bea:	48 31 ca             	xor    rdx,rcx
 bed:	48 8b 75 c0          	mov    rsi,QWORD PTR [rbp-0x40]
 bf1:	48 29 f2             	sub    rdx,rsi
 bf4:	48 89 d6             	mov    rsi,rdx
 bf7:	41 b8 80 ff ff ff    	mov    r8d,0xffffff80
 bfd:	4c 21 c6             	and    rsi,r8
 c00:	48 c1 ee 07          	shr    rsi,0x7
 c04:	49 89 d0             	mov    r8,rdx
 c07:	49 c1 e0 19          	shl    r8,0x19
 c0b:	49 09 f0             	or     r8,rsi
 c0e:	48 89 d6             	mov    rsi,rdx
 c11:	4c 8b 6d a8          	mov    r13,QWORD PTR [rbp-0x58]
 c15:	4c 31 ee             	xor    rsi,r13
 c18:	4c 29 c6             	sub    rsi,r8
 c1b:	49 89 f0             	mov    r8,rsi
 c1e:	4d 21 f8             	and    r8,r15
 c21:	49 c1 e8 10          	shr    r8,0x10
 c25:	49 89 f5             	mov    r13,rsi
 c28:	49 c1 e5 10          	shl    r13,0x10
 c2c:	4d 09 c5             	or     r13,r8
 c2f:	49 89 f0             	mov    r8,rsi
 c32:	49 31 c8             	xor    r8,rcx
 c35:	4d 29 e8             	sub    r8,r13
 c38:	4d 89 c5             	mov    r13,r8
 c3b:	4d 21 f5             	and    r13,r14
 c3e:	49 c1 ed 1c          	shr    r13,0x1c
 c42:	4d 89 c6             	mov    r14,r8
 c45:	49 c1 e6 04          	shl    r14,0x4
 c49:	4d 09 ee             	or     r14,r13
 c4c:	4d 89 c5             	mov    r13,r8
 c4f:	49 31 d5             	xor    r13,rdx
 c52:	4d 29 f5             	sub    r13,r14
 c55:	4c 89 ea             	mov    rdx,r13
 c58:	b9 00 00 fc ff       	mov    ecx,0xfffc0000
 c5d:	48 21 ca             	and    rdx,rcx
 c60:	48 c1 ea 12          	shr    rdx,0x12
 c64:	4d 89 ee             	mov    r14,r13
 c67:	49 c1 e6 0e          	shl    r14,0xe
 c6b:	49 09 d6             	or     r14,rdx
 c6e:	49 31 f5             	xor    r13,rsi
 c71:	4d 29 f5             	sub    r13,r14
 c74:	4c 89 ee             	mov    rsi,r13
 c77:	ba 00 ff ff ff       	mov    edx,0xffffff00
 c7c:	48 21 d6             	and    rsi,rdx
 c7f:	48 c1 ee 08          	shr    rsi,0x8
 c83:	4c 89 ea             	mov    rdx,r13
 c86:	48 c1 e2 18          	shl    rdx,0x18
 c8a:	48 09 f2             	or     rdx,rsi
 c8d:	4d 31 c5             	xor    r13,r8
 c90:	49 29 d5             	sub    r13,rdx
 c93:	49 c1 e5 20          	shl    r13,0x20
 c97:	49 c1 ed 20          	shr    r13,0x20
 c9b:	50                   	push   rax
 c9c:	52                   	push   rdx
 c9d:	49 c7 c3 01 00 01 00 	mov    r11,0x10001
 ca4:	4c 89 e8             	mov    rax,r13
 ca7:	31 d2                	xor    edx,edx
 ca9:	49 f7 f3             	div    r11
 cac:	49 89 d5             	mov    r13,rdx
 caf:	5a                   	pop    rdx
 cb0:	58                   	pop    rax
 cb1:	4c 01 eb             	add    rbx,r13
 cb4:	49 b8 15 7c 4a 7f b9 	movabs r8,0x9e3779b97f4a7c15
 cbb:	79 37 9e 
 cbe:	4c 01 c3             	add    rbx,r8
 cc1:	48 8b 75 d0          	mov    rsi,QWORD PTR [rbp-0x30]
 cc5:	48 31 f3             	xor    rbx,rsi
 cc8:	48 89 de             	mov    rsi,rbx
 ccb:	48 c1 ee 02          	shr    rsi,0x2
 ccf:	48 89 da             	mov    rdx,rbx
 cd2:	48 c1 e2 06          	shl    rdx,0x6
 cd6:	48 01 f2             	add    rdx,rsi
 cd9:	48 be 16 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c16
 ce0:	79 37 9e 
 ce3:	48 01 f2             	add    rdx,rsi
 ce6:	48 31 da             	xor    rdx,rbx
 ce9:	48 89 d6             	mov    rsi,rdx
 cec:	48 c1 ee 02          	shr    rsi,0x2
 cf0:	48 89 d1             	mov    rcx,rdx
 cf3:	48 c1 e1 06          	shl    rcx,0x6
 cf7:	48 01 f1             	add    rcx,rsi
 cfa:	4c 01 c1             	add    rcx,r8
 cfd:	48 31 d1             	xor    rcx,rdx
 d00:	48 89 ce             	mov    rsi,rcx
 d03:	48 c1 e6 06          	shl    rsi,0x6
 d07:	48 01 f0             	add    rax,rsi
 d0a:	48 89 ce             	mov    rsi,rcx
 d0d:	48 c1 ee 02          	shr    rsi,0x2
 d11:	48 01 f0             	add    rax,rsi
 d14:	4c 01 c0             	add    rax,r8
 d17:	48 31 c8             	xor    rax,rcx
 d1a:	48 89 c6             	mov    rsi,rax
 d1d:	48 c1 ee 02          	shr    rsi,0x2
 d21:	48 89 c2             	mov    rdx,rax
 d24:	48 c1 e2 06          	shl    rdx,0x6
 d28:	48 01 f2             	add    rdx,rsi
 d2b:	48 8b 75 f8          	mov    rsi,QWORD PTR [rbp-0x8]
 d2f:	48 01 f2             	add    rdx,rsi
 d32:	4c 01 c2             	add    rdx,r8
 d35:	48 31 c2             	xor    rdx,rax
 d38:	48 89 d6             	mov    rsi,rdx
 d3b:	48 c1 ee 02          	shr    rsi,0x2
 d3f:	49 89 d0             	mov    r8,rdx
 d42:	49 c1 e0 06          	shl    r8,0x6
 d46:	49 01 f0             	add    r8,rsi
 d49:	48 be 18 7c 4a 7f b9 	movabs rsi,0x9e3779b97f4a7c18
 d50:	79 37 9e 
 d53:	49 01 f0             	add    r8,rsi
 d56:	49 31 d0             	xor    r8,rdx
 d59:	41 be 03 00 00 00    	mov    r14d,0x3
 d5f:	e9 d1 f7 ff ff       	jmp    0x535
 d64:	41 b8 01 00 00 00    	mov    r8d,0x1
 d6a:	48 89 fa             	mov    rdx,rdi
 d6d:	48 83 c2 32          	add    rdx,0x32
 d71:	41 be 01 00 00 00    	mov    r14d,0x1
 d77:	48 39 f2             	cmp    rdx,rsi
 d7a:	0f 87 b5 f7 ff ff    	ja     0x535
 d80:	41 b8 02 00 00 00    	mov    r8d,0x2
 d86:	e9 a4 f7 ff ff       	jmp    0x52f
```

## llvmbpf JIT ASM
```asm
not captured
```
