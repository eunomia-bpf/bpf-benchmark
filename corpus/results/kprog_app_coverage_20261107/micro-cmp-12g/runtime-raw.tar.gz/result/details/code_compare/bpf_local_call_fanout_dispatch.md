# bpf_local_call_fanout_dispatch

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <bpf_local_call_fanout_dispatch_xdp>:
    1100:	55                   	push   rbp
    1101:	41 57                	push   r15
    1103:	41 56                	push   r14
    1105:	41 55                	push   r13
    1107:	41 54                	push   r12
    1109:	53                   	push   rbx
    110a:	48 83 ec 18          	sub    rsp,0x18
    110e:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    1111:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
    1115:	49 89 f7             	mov    r15,rsi
    1118:	31 c0                	xor    eax,eax
    111a:	49 39 cf             	cmp    r15,rcx
    111d:	76 0f                	jbe    112e <bpf_local_call_fanout_dispatch_xdp+0x2e>
    111f:	48 83 c4 18          	add    rsp,0x18
    1123:	5b                   	pop    rbx
    1124:	41 5c                	pop    r12
    1126:	41 5d                	pop    r13
    1128:	41 5e                	pop    r14
    112a:	41 5f                	pop    r15
    112c:	5d                   	pop    rbp
    112d:	c3                   	ret
    112e:	49 8d 57 08          	lea    rdx,[r15+0x8]
    1132:	48 89 54 24 08       	mov    QWORD PTR [rsp+0x8],rdx
    1137:	48 39 ca             	cmp    rdx,rcx
    113a:	77 e3                	ja     111f <bpf_local_call_fanout_dispatch_xdp+0x1f>
    113c:	49 8d 97 90 01 00 00 	lea    rdx,[r15+0x190]
    1143:	48 39 ca             	cmp    rdx,rcx
    1146:	77 d7                	ja     111f <bpf_local_call_fanout_dispatch_xdp+0x1f>
    1148:	41 83 7f 08 10       	cmp    DWORD PTR [r15+0x8],0x10
    114d:	75 d0                	jne    111f <bpf_local_call_fanout_dispatch_xdp+0x1f>
    114f:	41 83 7f 0c 18       	cmp    DWORD PTR [r15+0xc],0x18
    1154:	75 c9                	jne    111f <bpf_local_call_fanout_dispatch_xdp+0x1f>
    1156:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    115b:	48 bf d3 08 a3 85 88 	movabs rdi,0x243f6a8885a308d3
    1162:	6a 3f 24 
    1165:	45 31 e4             	xor    r12d,r12d
    1168:	41 bd 17 00 00 00    	mov    r13d,0x17
    116e:	45 31 f6             	xor    r14d,r14d
    1171:	eb 41                	jmp    11b4 <bpf_local_call_fanout_dispatch_xdp+0xb4>
    1173:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    117a:	84 00 00 00 00 00 
    1180:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    1185:	89 e9                	mov    ecx,ebp
    1187:	e8 e4 00 00 00       	call   1270 <local_call_pressure>
    118c:	44 89 f1             	mov    ecx,r14d
    118f:	80 e1 38             	and    cl,0x38
    1192:	c4 e2 f1 f7 cb       	shlx   rcx,rbx,rcx
    1197:	89 ef                	mov    edi,ebp
    1199:	48 01 cf             	add    rdi,rcx
    119c:	48 31 c7             	xor    rdi,rax
    119f:	49 83 c6 08          	add    r14,0x8
    11a3:	41 83 c4 10          	add    r12d,0x10
    11a7:	49 83 c5 18          	add    r13,0x18
    11ab:	49 81 fe 80 00 00 00 	cmp    r14,0x80
    11b2:	74 5d                	je     1211 <bpf_local_call_fanout_dispatch_xdp+0x111>
    11b4:	43 0f b6 5c 2f f9    	movzx  ebx,BYTE PTR [r15+r13*1-0x7]
    11ba:	83 e3 03             	and    ebx,0x3
    11bd:	43 8b 6c 2f fd       	mov    ebp,DWORD PTR [r15+r13*1-0x3]
    11c2:	44 31 e5             	xor    ebp,r12d
    11c5:	49 8d 55 f1          	lea    rdx,[r13-0xf]
    11c9:	48 83 fb 02          	cmp    rbx,0x2
    11cd:	74 21                	je     11f0 <bpf_local_call_fanout_dispatch_xdp+0xf0>
    11cf:	83 fb 01             	cmp    ebx,0x1
    11d2:	74 ac                	je     1180 <bpf_local_call_fanout_dispatch_xdp+0x80>
    11d4:	85 db                	test   ebx,ebx
    11d6:	75 28                	jne    1200 <bpf_local_call_fanout_dispatch_xdp+0x100>
    11d8:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    11dd:	89 e9                	mov    ecx,ebp
    11df:	e8 4c 00 00 00       	call   1230 <local_call_linear>
    11e4:	eb a6                	jmp    118c <bpf_local_call_fanout_dispatch_xdp+0x8c>
    11e6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
    11ed:	00 00 00 
    11f0:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    11f5:	89 e9                	mov    ecx,ebp
    11f7:	e8 c4 00 00 00       	call   12c0 <local_call_crossload>
    11fc:	eb 8e                	jmp    118c <bpf_local_call_fanout_dispatch_xdp+0x8c>
    11fe:	66 90                	xchg   ax,ax
    1200:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    1205:	89 e9                	mov    ecx,ebp
    1207:	e8 34 01 00 00       	call   1340 <local_call_bytes>
    120c:	e9 7b ff ff ff       	jmp    118c <bpf_local_call_fanout_dispatch_xdp+0x8c>
    1211:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    1216:	48 89 38             	mov    QWORD PTR [rax],rdi
    1219:	b8 02 00 00 00       	mov    eax,0x2
    121e:	e9 fc fe ff ff       	jmp    111f <bpf_local_call_fanout_dispatch_xdp+0x1f>
    1223:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    122a:	84 00 00 00 00 00 

0000000000001230 <local_call_linear>:
    1230:	89 d2                	mov    edx,edx
    1232:	48 8b 44 32 08       	mov    rax,QWORD PTR [rdx+rsi*1+0x8]
    1237:	4c 8d 04 40          	lea    r8,[rax+rax*2]
    123b:	41 89 c9             	mov    r9d,ecx
    123e:	4c 01 cf             	add    rdi,r9
    1241:	49 01 f8             	add    r8,rdi
    1244:	4c 03 44 32 10       	add    r8,QWORD PTR [rdx+rsi*1+0x10]
    1249:	49 c1 e1 0b          	shl    r9,0xb
    124d:	4d 01 c1             	add    r9,r8
    1250:	83 e1 07             	and    ecx,0x7
    1253:	8d 51 01             	lea    edx,[rcx+0x1]
    1256:	c4 c2 e9 f7 d1       	shlx   rdx,r9,rdx
    125b:	f6 d1                	not    cl
    125d:	c4 c2 f3 f7 c9       	shrx   rcx,r9,rcx
    1262:	48 09 d1             	or     rcx,rdx
    1265:	4c 31 c1             	xor    rcx,r8
    1268:	48 c1 e8 03          	shr    rax,0x3
    126c:	48 01 c8             	add    rax,rcx
    126f:	c3                   	ret

0000000000001270 <local_call_pressure>:
    1270:	89 d0                	mov    eax,edx
    1272:	48 8b 54 30 08       	mov    rdx,QWORD PTR [rax+rsi*1+0x8]
    1277:	48 8b 74 30 10       	mov    rsi,QWORD PTR [rax+rsi*1+0x10]
    127c:	48 31 d7             	xor    rdi,rdx
    127f:	89 c8                	mov    eax,ecx
    1281:	48 c1 e0 11          	shl    rax,0x11
    1285:	48 01 f0             	add    rax,rsi
    1288:	48 8d 0c fd 00 00 00 	lea    rcx,[rdi*8+0x0]
    128f:	00 
    1290:	48 c1 ee 02          	shr    rsi,0x2
    1294:	48 31 ce             	xor    rsi,rcx
    1297:	48 31 c2             	xor    rdx,rax
    129a:	c4 e3 fb f0 ca 3b    	rorx   rcx,rdx,0x3b
    12a0:	48 8d 14 3e          	lea    rdx,[rsi+rdi*1]
    12a4:	c4 e3 fb f0 d2 35    	rorx   rdx,rdx,0x35
    12aa:	48 01 ca             	add    rdx,rcx
    12ad:	48 31 c7             	xor    rdi,rax
    12b0:	48 c1 e8 07          	shr    rax,0x7
    12b4:	48 31 d0             	xor    rax,rdx
    12b7:	48 01 f0             	add    rax,rsi
    12ba:	48 31 f8             	xor    rax,rdi
    12bd:	c3                   	ret
    12be:	66 90                	xchg   ax,ax

00000000000012c0 <local_call_crossload>:
    12c0:	41 89 d3             	mov    r11d,edx
    12c3:	42 0f b6 04 1e       	movzx  eax,BYTE PTR [rsi+r11*1]
    12c8:	4d 8d 43 04          	lea    r8,[r11+0x4]
    12cc:	42 0f b6 54 1e 04    	movzx  edx,BYTE PTR [rsi+r11*1+0x4]
    12d2:	4d 63 d0             	movsxd r10,r8d
    12d5:	46 0f b6 4c 16 01    	movzx  r9d,BYTE PTR [rsi+r10*1+0x1]
    12db:	46 0f b6 44 16 02    	movzx  r8d,BYTE PTR [rsi+r10*1+0x2]
    12e1:	4a 03 7c 1e 08       	add    rdi,QWORD PTR [rsi+r11*1+0x8]
    12e6:	46 0f b6 54 16 03    	movzx  r10d,BYTE PTR [rsi+r10*1+0x3]
    12ec:	4a 8b 74 1e 10       	mov    rsi,QWORD PTR [rsi+r11*1+0x10]
    12f1:	48 31 fe             	xor    rsi,rdi
    12f4:	24 07                	and    al,0x7
    12f6:	44 8d 58 01          	lea    r11d,[rax+0x1]
    12fa:	c4 62 a1 f7 de       	shlx   r11,rsi,r11
    12ff:	89 c9                	mov    ecx,ecx
    1301:	c4 e2 f9 f7 c9       	shlx   rcx,rcx,rax
    1306:	f6 d0                	not    al
    1308:	c4 e2 fb f7 c6       	shrx   rax,rsi,rax
    130d:	4c 09 d8             	or     rax,r11
    1310:	49 c1 e2 21          	shl    r10,0x21
    1314:	49 c1 e0 19          	shl    r8,0x19
    1318:	41 c1 e1 11          	shl    r9d,0x11
    131c:	c1 e2 09             	shl    edx,0x9
    131f:	44 09 ca             	or     edx,r9d
    1322:	4c 09 c2             	or     rdx,r8
    1325:	4c 09 d2             	or     rdx,r10
    1328:	48 31 fa             	xor    rdx,rdi
    132b:	48 31 c2             	xor    rdx,rax
    132e:	48 01 d1             	add    rcx,rdx
    1331:	48 c1 e8 05          	shr    rax,0x5
    1335:	48 31 c8             	xor    rax,rcx
    1338:	48 01 f8             	add    rax,rdi
    133b:	c3                   	ret
    133c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

0000000000001340 <local_call_bytes>:
    1340:	89 c8                	mov    eax,ecx
    1342:	89 d1                	mov    ecx,edx
    1344:	0f b6 14 0e          	movzx  edx,BYTE PTR [rsi+rcx*1]
    1348:	49 b8 eb 11 31 13 bb 	movabs r8,0x94d049bb133111eb
    134f:	49 d0 94 
    1352:	49 31 f8             	xor    r8,rdi
    1355:	49 31 d0             	xor    r8,rdx
    1358:	49 01 c0             	add    r8,rax
    135b:	c4 c3 fb f0 d0 3f    	rorx   rdx,r8,0x3f
    1361:	0f b6 7c 0e 01       	movzx  edi,BYTE PTR [rsi+rcx*1+0x1]
    1366:	c1 e7 08             	shl    edi,0x8
    1369:	48 31 d7             	xor    rdi,rdx
    136c:	48 8d 14 38          	lea    rdx,[rax+rdi*1]
    1370:	48 ff c2             	inc    rdx
    1373:	c4 e3 fb f0 d2 3e    	rorx   rdx,rdx,0x3e
    1379:	0f b6 7c 0e 02       	movzx  edi,BYTE PTR [rsi+rcx*1+0x2]
    137e:	c1 e7 10             	shl    edi,0x10
    1381:	48 31 d7             	xor    rdi,rdx
    1384:	48 8d 14 38          	lea    rdx,[rax+rdi*1]
    1388:	48 83 c2 02          	add    rdx,0x2
    138c:	c4 e3 fb f0 d2 3d    	rorx   rdx,rdx,0x3d
    1392:	0f b6 7c 0e 03       	movzx  edi,BYTE PTR [rsi+rcx*1+0x3]
    1397:	c1 e7 18             	shl    edi,0x18
    139a:	48 31 d7             	xor    rdi,rdx
    139d:	48 8d 14 38          	lea    rdx,[rax+rdi*1]
    13a1:	48 83 c2 03          	add    rdx,0x3
    13a5:	c4 e3 fb f0 d2 3c    	rorx   rdx,rdx,0x3c
    13ab:	0f b6 7c 0e 04       	movzx  edi,BYTE PTR [rsi+rcx*1+0x4]
    13b0:	48 c1 e7 20          	shl    rdi,0x20
    13b4:	48 31 d7             	xor    rdi,rdx
    13b7:	48 8d 14 38          	lea    rdx,[rax+rdi*1]
    13bb:	48 83 c2 04          	add    rdx,0x4
    13bf:	c4 e3 fb f0 d2 3b    	rorx   rdx,rdx,0x3b
    13c5:	0f b6 7c 0e 05       	movzx  edi,BYTE PTR [rsi+rcx*1+0x5]
    13ca:	48 c1 e7 28          	shl    rdi,0x28
    13ce:	48 31 d7             	xor    rdi,rdx
    13d1:	48 8d 14 38          	lea    rdx,[rax+rdi*1]
    13d5:	48 83 c2 05          	add    rdx,0x5
    13d9:	c4 e3 fb f0 d2 3a    	rorx   rdx,rdx,0x3a
    13df:	0f b6 7c 0e 06       	movzx  edi,BYTE PTR [rsi+rcx*1+0x6]
    13e4:	48 c1 e7 30          	shl    rdi,0x30
    13e8:	48 31 d7             	xor    rdi,rdx
    13eb:	48 8d 14 38          	lea    rdx,[rax+rdi*1]
    13ef:	48 83 c2 06          	add    rdx,0x6
    13f3:	c4 e3 fb f0 d2 39    	rorx   rdx,rdx,0x39
    13f9:	0f b6 7c 0e 07       	movzx  edi,BYTE PTR [rsi+rcx*1+0x7]
    13fe:	48 c1 e7 38          	shl    rdi,0x38
    1402:	48 31 d7             	xor    rdi,rdx
    1405:	48 01 f8             	add    rax,rdi
    1408:	48 83 c0 07          	add    rax,0x7
    140c:	c4 e3 fb f0 c0 38    	rorx   rax,rax,0x38
    1412:	48 03 44 0e 08       	add    rax,QWORD PTR [rsi+rcx*1+0x8]
    1417:	48 33 44 0e 10       	xor    rax,QWORD PTR [rsi+rcx*1+0x10]
    141c:	c3                   	ret

Disassembly of section .fini:

0000000000001420 <_fini>:
    1420:	f3 0f 1e fa          	endbr64
    1424:	48 83 ec 08          	sub    rsp,0x8
    1428:	48 83 c4 08          	add    rsp,0x8
    142c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 57 00          	mov    rdx,QWORD PTR [rdi+0x0]
  24:	48 39 f2             	cmp    rdx,rsi
  27:	0f 87 e7 01 00 00    	ja     0x214
  2d:	48 89 d7             	mov    rdi,rdx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
  38:	48 39 f7             	cmp    rdi,rsi
  3b:	0f 87 d3 01 00 00    	ja     0x214
  41:	48 89 d7             	mov    rdi,rdx
  44:	48 81 c7 90 01 00 00 	add    rdi,0x190
  4b:	48 39 f7             	cmp    rdi,rsi
  4e:	0f 87 c0 01 00 00    	ja     0x214
  54:	48 0f b6 7a 09       	movzx  rdi,BYTE PTR [rdx+0x9]
  59:	48 c1 e7 08          	shl    rdi,0x8
  5d:	48 0f b6 72 08       	movzx  rsi,BYTE PTR [rdx+0x8]
  62:	48 09 f7             	or     rdi,rsi
  65:	48 0f b6 72 0a       	movzx  rsi,BYTE PTR [rdx+0xa]
  6a:	48 c1 e6 10          	shl    rsi,0x10
  6e:	48 09 f7             	or     rdi,rsi
  71:	48 0f b6 72 0b       	movzx  rsi,BYTE PTR [rdx+0xb]
  76:	48 c1 e6 18          	shl    rsi,0x18
  7a:	48 09 f7             	or     rdi,rsi
  7d:	48 c1 e7 20          	shl    rdi,0x20
  81:	48 c1 ef 20          	shr    rdi,0x20
  85:	48 83 ff 10          	cmp    rdi,0x10
  89:	0f 85 85 01 00 00    	jne    0x214
  8f:	48 0f b6 7a 0d       	movzx  rdi,BYTE PTR [rdx+0xd]
  94:	48 c1 e7 08          	shl    rdi,0x8
  98:	48 0f b6 72 0c       	movzx  rsi,BYTE PTR [rdx+0xc]
  9d:	48 09 f7             	or     rdi,rsi
  a0:	48 0f b6 72 0e       	movzx  rsi,BYTE PTR [rdx+0xe]
  a5:	48 c1 e6 10          	shl    rsi,0x10
  a9:	48 09 f7             	or     rdi,rsi
  ac:	48 0f b6 72 0f       	movzx  rsi,BYTE PTR [rdx+0xf]
  b1:	48 c1 e6 18          	shl    rsi,0x18
  b5:	48 09 f7             	or     rdi,rsi
  b8:	48 c1 e7 20          	shl    rdi,0x20
  bc:	48 c1 ef 20          	shr    rdi,0x20
  c0:	48 83 ff 18          	cmp    rdi,0x18
  c4:	0f 85 4a 01 00 00    	jne    0x214
  ca:	48 b8 d3 08 a3 85 88 	movabs rax,0x243f6a8885a308d3
  d1:	6a 3f 24 
  d4:	45 31 ff             	xor    r15d,r15d
  d7:	31 c9                	xor    ecx,ecx
  d9:	45 31 f6             	xor    r14d,r14d
  dc:	48 89 55 e8          	mov    QWORD PTR [rbp-0x18],rdx
  e0:	eb 4a                	jmp    0x12c
  e2:	48 89 c7             	mov    rdi,rax
  e5:	48 8b 75 f0          	mov    rsi,QWORD PTR [rbp-0x10]
  e9:	4c 89 e9             	mov    rcx,r13
  ec:	e8 a7 f3 ff ff       	call   0xfffffffffffff498
  f1:	4c 89 f7             	mov    rdi,r14
  f4:	48 83 e7 38          	and    rdi,0x38
  f8:	c4 e2 c1 f7 db       	shlx   rbx,rbx,rdi
  fd:	49 c1 e5 20          	shl    r13,0x20
 101:	49 c1 ed 20          	shr    r13,0x20
 105:	4c 01 eb             	add    rbx,r13
 108:	48 31 d8             	xor    rax,rbx
 10b:	49 83 c7 18          	add    r15,0x18
 10f:	48 8b 4d f8          	mov    rcx,QWORD PTR [rbp-0x8]
 113:	48 83 c1 10          	add    rcx,0x10
 117:	49 83 c6 08          	add    r14,0x8
 11b:	48 8b 55 e8          	mov    rdx,QWORD PTR [rbp-0x18]
 11f:	49 81 fe 80 00 00 00 	cmp    r14,0x80
 126:	0f 84 97 00 00 00    	je     0x1c3
 12c:	48 89 d7             	mov    rdi,rdx
 12f:	4c 01 ff             	add    rdi,r15
 132:	4c 0f b6 6f 15       	movzx  r13,BYTE PTR [rdi+0x15]
 137:	49 c1 e5 08          	shl    r13,0x8
 13b:	48 0f b6 77 14       	movzx  rsi,BYTE PTR [rdi+0x14]
 140:	49 09 f5             	or     r13,rsi
 143:	48 0f b6 77 16       	movzx  rsi,BYTE PTR [rdi+0x16]
 148:	48 c1 e6 10          	shl    rsi,0x10
 14c:	49 09 f5             	or     r13,rsi
 14f:	48 0f b6 77 17       	movzx  rsi,BYTE PTR [rdi+0x17]
 154:	48 c1 e6 18          	shl    rsi,0x18
 158:	49 09 f5             	or     r13,rsi
 15b:	49 31 cd             	xor    r13,rcx
 15e:	4c 89 fa             	mov    rdx,r15
 161:	48 83 c2 08          	add    rdx,0x8
 165:	48 0f b6 5f 10       	movzx  rbx,BYTE PTR [rdi+0x10]
 16a:	48 83 e3 03          	and    rbx,0x3
 16e:	48 89 4d f8          	mov    QWORD PTR [rbp-0x8],rcx
 172:	48 83 fb 02          	cmp    rbx,0x2
 176:	74 23                	je     0x19b
 178:	48 83 fb 01          	cmp    rbx,0x1
 17c:	0f 84 60 ff ff ff    	je     0xe2
 182:	48 85 db             	test   rbx,rbx
 185:	75 28                	jne    0x1af
 187:	48 89 c7             	mov    rdi,rax
 18a:	48 8b 75 f0          	mov    rsi,QWORD PTR [rbp-0x10]
 18e:	4c 89 e9             	mov    rcx,r13
 191:	e8 ca 00 00 00       	call   0x260
 196:	e9 56 ff ff ff       	jmp    0xf1
 19b:	48 89 c7             	mov    rdi,rax
 19e:	48 8b 75 f0          	mov    rsi,QWORD PTR [rbp-0x10]
 1a2:	4c 89 e9             	mov    rcx,r13
 1a5:	e8 22 02 00 00       	call   0x3cc
 1aa:	e9 42 ff ff ff       	jmp    0xf1
 1af:	48 89 c7             	mov    rdi,rax
 1b2:	48 8b 75 f0          	mov    rsi,QWORD PTR [rbp-0x10]
 1b6:	4c 89 e9             	mov    rcx,r13
 1b9:	e8 2e 04 00 00       	call   0x5ec
 1be:	e9 2e ff ff ff       	jmp    0xf1
 1c3:	48 89 c7             	mov    rdi,rax
 1c6:	48 c1 ef 38          	shr    rdi,0x38
 1ca:	40 88 7a 07          	mov    BYTE PTR [rdx+0x7],dil
 1ce:	48 89 c7             	mov    rdi,rax
 1d1:	48 c1 ef 30          	shr    rdi,0x30
 1d5:	40 88 7a 06          	mov    BYTE PTR [rdx+0x6],dil
 1d9:	48 89 c7             	mov    rdi,rax
 1dc:	48 c1 ef 28          	shr    rdi,0x28
 1e0:	40 88 7a 05          	mov    BYTE PTR [rdx+0x5],dil
 1e4:	48 89 c7             	mov    rdi,rax
 1e7:	48 c1 ef 20          	shr    rdi,0x20
 1eb:	40 88 7a 04          	mov    BYTE PTR [rdx+0x4],dil
 1ef:	48 89 c7             	mov    rdi,rax
 1f2:	48 c1 ef 18          	shr    rdi,0x18
 1f6:	40 88 7a 03          	mov    BYTE PTR [rdx+0x3],dil
 1fa:	48 89 c7             	mov    rdi,rax
 1fd:	48 c1 ef 10          	shr    rdi,0x10
 201:	40 88 7a 02          	mov    BYTE PTR [rdx+0x2],dil
 205:	88 42 00             	mov    BYTE PTR [rdx+0x0],al
 208:	48 c1 e8 08          	shr    rax,0x8
 20c:	88 42 01             	mov    BYTE PTR [rdx+0x1],al
 20f:	b8 02 00 00 00       	mov    eax,0x2
 214:	41 5f                	pop    r15
 216:	41 5e                	pop    r14
 218:	41 5d                	pop    r13
 21a:	5b                   	pop    rbx
 21b:	c9                   	leave
 21c:	e9 33 1e c1 dc       	jmp    0xffffffffdcc12054
 221:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
 226:	0f 1f 00             	nop    DWORD PTR [rax]
 229:	55                   	push   rbp
 22a:	48 89 e5             	mov    rbp,rsp
 22d:	53                   	push   rbx
 22e:	41 55                	push   r13
 230:	48 89 d0             	mov    rax,rdx
 233:	48 83 c0 08          	add    rax,0x8
 237:	48 83 c2 10          	add    rdx,0x10
 23b:	48 c1 e2 20          	shl    rdx,0x20
 23f:	48 c1 ea 20          	shr    rdx,0x20
 243:	49 89 f0             	mov    r8,rsi
 246:	49 01 d0             	add    r8,rdx
 249:	48 c1 e0 20          	shl    rax,0x20
 24d:	48 c1 e8 20          	shr    rax,0x20
 251:	48 01 c6             	add    rsi,rax
 254:	48 0f b6 46 01       	movzx  rax,BYTE PTR [rsi+0x1]
 259:	48 c1 e0 08          	shl    rax,0x8
 25d:	48 0f b6 56 00       	movzx  rdx,BYTE PTR [rsi+0x0]
 262:	48 09 d0             	or     rax,rdx
 265:	49 0f b6 58 01       	movzx  rbx,BYTE PTR [r8+0x1]
 26a:	48 c1 e3 08          	shl    rbx,0x8
 26e:	49 0f b6 50 00       	movzx  rdx,BYTE PTR [r8+0x0]
 273:	48 09 d3             	or     rbx,rdx
 276:	49 0f b6 50 02       	movzx  rdx,BYTE PTR [r8+0x2]
 27b:	48 c1 e2 10          	shl    rdx,0x10
 27f:	48 09 da             	or     rdx,rbx
 282:	48 0f b6 5e 02       	movzx  rbx,BYTE PTR [rsi+0x2]
 287:	48 c1 e3 10          	shl    rbx,0x10
 28b:	48 09 c3             	or     rbx,rax
 28e:	4c 0f b6 6e 03       	movzx  r13,BYTE PTR [rsi+0x3]
 293:	49 c1 e5 18          	shl    r13,0x18
 297:	49 09 dd             	or     r13,rbx
 29a:	48 0f b6 46 04       	movzx  rax,BYTE PTR [rsi+0x4]
 29f:	48 c1 e0 20          	shl    rax,0x20
 2a3:	4c 09 e8             	or     rax,r13
 2a6:	49 0f b6 58 03       	movzx  rbx,BYTE PTR [r8+0x3]
 2ab:	48 c1 e3 18          	shl    rbx,0x18
 2af:	48 09 d3             	or     rbx,rdx
 2b2:	4d 0f b6 68 04       	movzx  r13,BYTE PTR [r8+0x4]
 2b7:	49 c1 e5 20          	shl    r13,0x20
 2bb:	49 09 dd             	or     r13,rbx
 2be:	49 0f b6 50 05       	movzx  rdx,BYTE PTR [r8+0x5]
 2c3:	48 c1 e2 28          	shl    rdx,0x28
 2c7:	4c 09 ea             	or     rdx,r13
 2ca:	48 0f b6 5e 05       	movzx  rbx,BYTE PTR [rsi+0x5]
 2cf:	48 c1 e3 28          	shl    rbx,0x28
 2d3:	48 09 c3             	or     rbx,rax
 2d6:	4c 0f b6 6e 06       	movzx  r13,BYTE PTR [rsi+0x6]
 2db:	49 c1 e5 30          	shl    r13,0x30
 2df:	49 09 dd             	or     r13,rbx
 2e2:	48 0f b6 46 07       	movzx  rax,BYTE PTR [rsi+0x7]
 2e7:	48 c1 e0 38          	shl    rax,0x38
 2eb:	4c 09 e8             	or     rax,r13
 2ee:	49 0f b6 58 06       	movzx  rbx,BYTE PTR [r8+0x6]
 2f3:	48 c1 e3 30          	shl    rbx,0x30
 2f7:	48 09 d3             	or     rbx,rdx
 2fa:	49 0f b6 70 07       	movzx  rsi,BYTE PTR [r8+0x7]
 2ff:	48 c1 e6 38          	shl    rsi,0x38
 303:	48 09 de             	or     rsi,rbx
 306:	48 c1 e1 20          	shl    rcx,0x20
 30a:	48 c1 e9 20          	shr    rcx,0x20
 30e:	48 c1 e1 11          	shl    rcx,0x11
 312:	48 89 f2             	mov    rdx,rsi
 315:	48 01 ca             	add    rdx,rcx
 318:	48 89 d1             	mov    rcx,rdx
 31b:	48 31 c1             	xor    rcx,rax
 31e:	49 89 c8             	mov    r8,rcx
 321:	49 c1 e8 3b          	shr    r8,0x3b
 325:	48 c1 e1 05          	shl    rcx,0x5
 329:	4c 09 c1             	or     rcx,r8
 32c:	48 31 f8             	xor    rax,rdi
 32f:	48 c1 ee 02          	shr    rsi,0x2
 333:	48 89 c7             	mov    rdi,rax
 336:	48 c1 e7 03          	shl    rdi,0x3
 33a:	48 31 fe             	xor    rsi,rdi
 33d:	48 89 f7             	mov    rdi,rsi
 340:	48 01 c7             	add    rdi,rax
 343:	49 89 f8             	mov    r8,rdi
 346:	49 c1 e8 35          	shr    r8,0x35
 34a:	48 c1 e7 0b          	shl    rdi,0xb
 34e:	4c 09 c7             	or     rdi,r8
 351:	48 01 cf             	add    rdi,rcx
 354:	48 89 d1             	mov    rcx,rdx
 357:	48 c1 e9 07          	shr    rcx,0x7
 35b:	48 31 cf             	xor    rdi,rcx
 35e:	48 01 f7             	add    rdi,rsi
 361:	48 31 f8             	xor    rax,rdi
 364:	48 31 d0             	xor    rax,rdx
 367:	41 5d                	pop    r13
 369:	5b                   	pop    rbx
 36a:	c9                   	leave
 36b:	e9 6d 2a c1 dc       	jmp    0xffffffffdcc12ddd
 370:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
 375:	0f 1f 00             	nop    DWORD PTR [rax]
 378:	55                   	push   rbp
 379:	48 89 e5             	mov    rbp,rsp
 37c:	53                   	push   rbx
 37d:	41 55                	push   r13
 37f:	48 89 d0             	mov    rax,rdx
 382:	48 83 c0 10          	add    rax,0x10
 386:	48 83 c2 08          	add    rdx,0x8
 38a:	48 c1 e2 20          	shl    rdx,0x20
 38e:	48 c1 ea 20          	shr    rdx,0x20
 392:	49 89 f0             	mov    r8,rsi
 395:	49 01 d0             	add    r8,rdx
 398:	48 c1 e0 20          	shl    rax,0x20
 39c:	48 c1 e8 20          	shr    rax,0x20
 3a0:	48 01 c6             	add    rsi,rax
 3a3:	48 0f b6 56 01       	movzx  rdx,BYTE PTR [rsi+0x1]
 3a8:	48 c1 e2 08          	shl    rdx,0x8
 3ac:	48 0f b6 46 00       	movzx  rax,BYTE PTR [rsi+0x0]
 3b1:	48 09 c2             	or     rdx,rax
 3b4:	49 0f b6 40 01       	movzx  rax,BYTE PTR [r8+0x1]
 3b9:	48 c1 e0 08          	shl    rax,0x8
 3bd:	49 0f b6 58 00       	movzx  rbx,BYTE PTR [r8+0x0]
 3c2:	48 09 d8             	or     rax,rbx
 3c5:	49 0f b6 58 02       	movzx  rbx,BYTE PTR [r8+0x2]
 3ca:	48 c1 e3 10          	shl    rbx,0x10
 3ce:	48 09 c3             	or     rbx,rax
 3d1:	49 0f b6 40 03       	movzx  rax,BYTE PTR [r8+0x3]
 3d6:	48 c1 e0 18          	shl    rax,0x18
 3da:	48 09 d8             	or     rax,rbx
 3dd:	48 0f b6 5e 02       	movzx  rbx,BYTE PTR [rsi+0x2]
 3e2:	48 c1 e3 10          	shl    rbx,0x10
 3e6:	48 09 d3             	or     rbx,rdx
 3e9:	4c 0f b6 6e 03       	movzx  r13,BYTE PTR [rsi+0x3]
 3ee:	49 c1 e5 18          	shl    r13,0x18
 3f2:	49 09 dd             	or     r13,rbx
 3f5:	48 0f b6 56 04       	movzx  rdx,BYTE PTR [rsi+0x4]
 3fa:	48 c1 e2 20          	shl    rdx,0x20
 3fe:	4c 09 ea             	or     rdx,r13
 401:	49 0f b6 58 04       	movzx  rbx,BYTE PTR [r8+0x4]
 406:	48 c1 e3 20          	shl    rbx,0x20
 40a:	48 09 c3             	or     rbx,rax
 40d:	4d 0f b6 68 05       	movzx  r13,BYTE PTR [r8+0x5]
 412:	49 c1 e5 28          	shl    r13,0x28
 416:	49 09 dd             	or     r13,rbx
 419:	49 0f b6 40 06       	movzx  rax,BYTE PTR [r8+0x6]
 41e:	48 c1 e0 30          	shl    rax,0x30
 422:	4c 09 e8             	or     rax,r13
 425:	48 0f b6 5e 05       	movzx  rbx,BYTE PTR [rsi+0x5]
 42a:	48 c1 e3 28          	shl    rbx,0x28
 42e:	48 09 d3             	or     rbx,rdx
 431:	48 0f b6 56 06       	movzx  rdx,BYTE PTR [rsi+0x6]
 436:	48 c1 e2 30          	shl    rdx,0x30
 43a:	48 09 da             	or     rdx,rbx
 43d:	48 0f b6 5e 07       	movzx  rbx,BYTE PTR [rsi+0x7]
 442:	48 c1 e3 38          	shl    rbx,0x38
 446:	48 09 d3             	or     rbx,rdx
 449:	49 0f b6 70 07       	movzx  rsi,BYTE PTR [r8+0x7]
 44e:	48 c1 e6 38          	shl    rsi,0x38
 452:	48 09 c6             	or     rsi,rax
 455:	49 89 c8             	mov    r8,rcx
 458:	49 c1 e0 20          	shl    r8,0x20
 45c:	49 c1 e8 20          	shr    r8,0x20
 460:	4c 89 c2             	mov    rdx,r8
 463:	48 01 fa             	add    rdx,rdi
 466:	48 89 f7             	mov    rdi,rsi
 469:	48 6b ff 03          	imul   rdi,rdi,0x3
 46d:	48 01 fa             	add    rdx,rdi
 470:	48 01 da             	add    rdx,rbx
 473:	48 83 e1 07          	and    rcx,0x7
 477:	48 89 cf             	mov    rdi,rcx
 47a:	48 83 c7 01          	add    rdi,0x1
 47e:	48 83 f1 3f          	xor    rcx,0x3f
 482:	49 c1 e0 0b          	shl    r8,0xb
 486:	48 89 d0             	mov    rax,rdx
 489:	4c 01 c0             	add    rax,r8
 48c:	49 89 c0             	mov    r8,rax
 48f:	49 d3 e8             	shr    r8,cl
 492:	c4 e2 c1 f7 c0       	shlx   rax,rax,rdi
 497:	4c 09 c0             	or     rax,r8
 49a:	48 31 d0             	xor    rax,rdx
 49d:	48 c1 ee 03          	shr    rsi,0x3
 4a1:	48 01 f0             	add    rax,rsi
 4a4:	41 5d                	pop    r13
 4a6:	5b                   	pop    rbx
 4a7:	c9                   	leave
 4a8:	e9 b7 1c c1 dc       	jmp    0xffffffffdcc12164
 4ad:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
 4b2:	0f 1f 00             	nop    DWORD PTR [rax]
 4b5:	55                   	push   rbp
 4b6:	48 89 e5             	mov    rbp,rsp
 4b9:	48 81 ec 08 00 00 00 	sub    rsp,0x8
 4c0:	53                   	push   rbx
 4c1:	41 55                	push   r13
 4c3:	41 56                	push   r14
 4c5:	41 57                	push   r15
 4c7:	48 89 4d f8          	mov    QWORD PTR [rbp-0x8],rcx
 4cb:	48 89 d1             	mov    rcx,rdx
 4ce:	49 89 c8             	mov    r8,rcx
 4d1:	49 83 c0 08          	add    r8,0x8
 4d5:	49 c1 e0 20          	shl    r8,0x20
 4d9:	49 c1 e8 20          	shr    r8,0x20
 4dd:	48 89 f0             	mov    rax,rsi
 4e0:	4c 01 c0             	add    rax,r8
 4e3:	48 0f b6 58 01       	movzx  rbx,BYTE PTR [rax+0x1]
 4e8:	48 c1 e3 08          	shl    rbx,0x8
 4ec:	4c 0f b6 40 00       	movzx  r8,BYTE PTR [rax+0x0]
 4f1:	4c 09 c3             	or     rbx,r8
 4f4:	49 89 cd             	mov    r13,rcx
 4f7:	49 83 c5 10          	add    r13,0x10
 4fb:	49 c1 e5 20          	shl    r13,0x20
 4ff:	49 c1 ed 20          	shr    r13,0x20
 503:	49 89 f0             	mov    r8,rsi
 506:	4d 01 e8             	add    r8,r13
 509:	4d 0f b6 68 01       	movzx  r13,BYTE PTR [r8+0x1]
 50e:	49 c1 e5 08          	shl    r13,0x8
 512:	4d 0f b6 70 00       	movzx  r14,BYTE PTR [r8+0x0]
 517:	4d 09 f5             	or     r13,r14
 51a:	4d 0f b6 78 02       	movzx  r15,BYTE PTR [r8+0x2]
 51f:	49 c1 e7 10          	shl    r15,0x10
 523:	4d 09 ef             	or     r15,r13
 526:	4d 0f b6 70 03       	movzx  r14,BYTE PTR [r8+0x3]
 52b:	49 c1 e6 18          	shl    r14,0x18
 52f:	4d 09 fe             	or     r14,r15
 532:	4c 0f b6 68 02       	movzx  r13,BYTE PTR [rax+0x2]
 537:	49 c1 e5 10          	shl    r13,0x10
 53b:	49 09 dd             	or     r13,rbx
 53e:	48 0f b6 58 03       	movzx  rbx,BYTE PTR [rax+0x3]
 543:	48 c1 e3 18          	shl    rbx,0x18
 547:	4c 09 eb             	or     rbx,r13
 54a:	4c 0f b6 68 04       	movzx  r13,BYTE PTR [rax+0x4]
 54f:	49 c1 e5 20          	shl    r13,0x20
 553:	49 09 dd             	or     r13,rbx
 556:	4d 0f b6 78 04       	movzx  r15,BYTE PTR [r8+0x4]
 55b:	49 c1 e7 20          	shl    r15,0x20
 55f:	4d 09 f7             	or     r15,r14
 562:	48 c1 e2 20          	shl    rdx,0x20
 566:	48 c1 ea 20          	shr    rdx,0x20
 56a:	48 83 c1 04          	add    rcx,0x4
 56e:	48 c1 e1 20          	shl    rcx,0x20
 572:	48 89 cb             	mov    rbx,rcx
 575:	48 c1 fb 20          	sar    rbx,0x20
 579:	48 c1 e9 20          	shr    rcx,0x20
 57d:	49 89 f6             	mov    r14,rsi
 580:	49 01 ce             	add    r14,rcx
 583:	48 89 f1             	mov    rcx,rsi
 586:	48 01 d1             	add    rcx,rdx
 589:	48 01 de             	add    rsi,rbx
 58c:	49 0f b6 50 05       	movzx  rdx,BYTE PTR [r8+0x5]
 591:	48 c1 e2 28          	shl    rdx,0x28
 595:	4c 09 fa             	or     rdx,r15
 598:	48 0f b6 58 05       	movzx  rbx,BYTE PTR [rax+0x5]
 59d:	48 c1 e3 28          	shl    rbx,0x28
 5a1:	4c 09 eb             	or     rbx,r13
 5a4:	4c 0f b6 68 06       	movzx  r13,BYTE PTR [rax+0x6]
 5a9:	49 c1 e5 30          	shl    r13,0x30
 5ad:	49 09 dd             	or     r13,rbx
 5b0:	4c 0f b6 78 07       	movzx  r15,BYTE PTR [rax+0x7]
 5b5:	49 c1 e7 38          	shl    r15,0x38
 5b9:	4d 09 ef             	or     r15,r13
 5bc:	49 0f b6 40 06       	movzx  rax,BYTE PTR [r8+0x6]
 5c1:	48 c1 e0 30          	shl    rax,0x30
 5c5:	48 09 d0             	or     rax,rdx
 5c8:	49 0f b6 56 00       	movzx  rdx,BYTE PTR [r14+0x0]
 5cd:	48 c1 e2 09          	shl    rdx,0x9
 5d1:	4c 0f b6 6e 01       	movzx  r13,BYTE PTR [rsi+0x1]
 5d6:	49 c1 e5 11          	shl    r13,0x11
 5da:	49 09 d5             	or     r13,rdx
 5dd:	48 0f b6 56 02       	movzx  rdx,BYTE PTR [rsi+0x2]
 5e2:	48 c1 e2 19          	shl    rdx,0x19
 5e6:	49 09 d5             	or     r13,rdx
 5e9:	48 0f b6 76 03       	movzx  rsi,BYTE PTR [rsi+0x3]
 5ee:	48 c1 e6 21          	shl    rsi,0x21
 5f2:	49 09 f5             	or     r13,rsi
 5f5:	49 0f b6 70 07       	movzx  rsi,BYTE PTR [r8+0x7]
 5fa:	48 c1 e6 38          	shl    rsi,0x38
 5fe:	48 09 c6             	or     rsi,rax
 601:	49 01 ff             	add    r15,rdi
 604:	48 0f b6 79 00       	movzx  rdi,BYTE PTR [rcx+0x0]
 609:	48 83 e7 07          	and    rdi,0x7
 60d:	48 8b 55 f8          	mov    rdx,QWORD PTR [rbp-0x8]
 611:	48 c1 e2 20          	shl    rdx,0x20
 615:	48 c1 ea 20          	shr    rdx,0x20
 619:	c4 e2 c1 f7 d2       	shlx   rdx,rdx,rdi
 61e:	49 89 d0             	mov    r8,rdx
 621:	48 89 fa             	mov    rdx,rdi
 624:	48 83 c2 01          	add    rdx,0x1
 628:	48 83 f7 3f          	xor    rdi,0x3f
 62c:	4c 31 fe             	xor    rsi,r15
 62f:	48 89 f1             	mov    rcx,rsi
 632:	c4 e2 c3 f7 c9       	shrx   rcx,rcx,rdi
 637:	c4 e2 e9 f7 f6       	shlx   rsi,rsi,rdx
 63c:	48 09 ce             	or     rsi,rcx
 63f:	4c 89 f8             	mov    rax,r15
 642:	4c 31 e8             	xor    rax,r13
 645:	48 31 f0             	xor    rax,rsi
 648:	4c 01 c0             	add    rax,r8
 64b:	48 c1 ee 05          	shr    rsi,0x5
 64f:	48 31 f0             	xor    rax,rsi
 652:	4c 01 f8             	add    rax,r15
 655:	41 5f                	pop    r15
 657:	41 5e                	pop    r14
 659:	41 5d                	pop    r13
 65b:	5b                   	pop    rbx
 65c:	c9                   	leave
 65d:	e9 d3 1a c1 dc       	jmp    0xffffffffdcc12135
 662:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
 667:	0f 1f 00             	nop    DWORD PTR [rax]
 66a:	55                   	push   rbp
 66b:	48 89 e5             	mov    rbp,rsp
 66e:	53                   	push   rbx
 66f:	41 55                	push   r13
 671:	41 56                	push   r14
 673:	48 89 d0             	mov    rax,rdx
 676:	48 c1 e0 20          	shl    rax,0x20
 67a:	48 c1 e8 20          	shr    rax,0x20
 67e:	49 89 f0             	mov    r8,rsi
 681:	49 01 c0             	add    r8,rax
 684:	49 0f b6 58 00       	movzx  rbx,BYTE PTR [r8+0x0]
 689:	48 31 fb             	xor    rbx,rdi
 68c:	48 bf eb 11 31 13 bb 	movabs rdi,0x94d049bb133111eb
 693:	49 d0 94 
 696:	48 31 fb             	xor    rbx,rdi
 699:	48 c1 e1 20          	shl    rcx,0x20
 69d:	48 c1 e9 20          	shr    rcx,0x20
 6a1:	48 01 cb             	add    rbx,rcx
 6a4:	48 89 df             	mov    rdi,rbx
 6a7:	48 c1 ef 3f          	shr    rdi,0x3f
 6ab:	48 d1 e3             	shl    rbx,1
 6ae:	48 09 fb             	or     rbx,rdi
 6b1:	49 0f b6 40 01       	movzx  rax,BYTE PTR [r8+0x1]
 6b6:	48 c1 e0 08          	shl    rax,0x8
 6ba:	48 31 d8             	xor    rax,rbx
 6bd:	48 89 d3             	mov    rbx,rdx
 6c0:	48 83 c3 10          	add    rbx,0x10
 6c4:	48 c1 e3 20          	shl    rbx,0x20
 6c8:	48 c1 eb 20          	shr    rbx,0x20
 6cc:	48 89 f7             	mov    rdi,rsi
 6cf:	48 01 df             	add    rdi,rbx
 6d2:	4c 0f b6 6f 01       	movzx  r13,BYTE PTR [rdi+0x1]
 6d7:	49 c1 e5 08          	shl    r13,0x8
 6db:	48 0f b6 5f 00       	movzx  rbx,BYTE PTR [rdi+0x0]
 6e0:	49 09 dd             	or     r13,rbx
 6e3:	48 0f b6 5f 02       	movzx  rbx,BYTE PTR [rdi+0x2]
 6e8:	48 c1 e3 10          	shl    rbx,0x10
 6ec:	4c 09 eb             	or     rbx,r13
 6ef:	48 83 c2 08          	add    rdx,0x8
 6f3:	48 c1 e2 20          	shl    rdx,0x20
 6f7:	48 c1 ea 20          	shr    rdx,0x20
 6fb:	48 01 d6             	add    rsi,rdx
 6fe:	48 89 ca             	mov    rdx,rcx
 701:	48 01 c2             	add    rdx,rax
 704:	48 83 c2 01          	add    rdx,0x1
 708:	48 89 d0             	mov    rax,rdx
 70b:	48 c1 e8 3e          	shr    rax,0x3e
 70f:	48 c1 e2 02          	shl    rdx,0x2
 713:	48 09 c2             	or     rdx,rax
 716:	48 0f b6 47 03       	movzx  rax,BYTE PTR [rdi+0x3]
 71b:	48 c1 e0 18          	shl    rax,0x18
 71f:	48 09 d8             	or     rax,rbx
 722:	48 0f b6 5e 01       	movzx  rbx,BYTE PTR [rsi+0x1]
 727:	48 c1 e3 08          	shl    rbx,0x8
 72b:	4c 0f b6 6e 00       	movzx  r13,BYTE PTR [rsi+0x0]
 730:	4c 09 eb             	or     rbx,r13
 733:	4c 0f b6 6e 02       	movzx  r13,BYTE PTR [rsi+0x2]
 738:	49 c1 e5 10          	shl    r13,0x10
 73c:	49 09 dd             	or     r13,rbx
 73f:	48 0f b6 5e 03       	movzx  rbx,BYTE PTR [rsi+0x3]
 744:	48 c1 e3 18          	shl    rbx,0x18
 748:	4c 09 eb             	or     rbx,r13
 74b:	4c 0f b6 77 04       	movzx  r14,BYTE PTR [rdi+0x4]
 750:	49 c1 e6 20          	shl    r14,0x20
 754:	49 09 c6             	or     r14,rax
 757:	49 0f b6 40 02       	movzx  rax,BYTE PTR [r8+0x2]
 75c:	48 c1 e0 10          	shl    rax,0x10
 760:	48 31 d0             	xor    rax,rdx
 763:	4c 0f b6 6f 05       	movzx  r13,BYTE PTR [rdi+0x5]
 768:	49 c1 e5 28          	shl    r13,0x28
 76c:	4d 09 f5             	or     r13,r14
 76f:	48 0f b6 56 04       	movzx  rdx,BYTE PTR [rsi+0x4]
 774:	48 c1 e2 20          	shl    rdx,0x20
 778:	48 09 da             	or     rdx,rbx
 77b:	48 0f b6 5e 05       	movzx  rbx,BYTE PTR [rsi+0x5]
 780:	48 c1 e3 28          	shl    rbx,0x28
 784:	48 09 d3             	or     rbx,rdx
 787:	48 0f b6 56 06       	movzx  rdx,BYTE PTR [rsi+0x6]
 78c:	48 c1 e2 30          	shl    rdx,0x30
 790:	48 09 da             	or     rdx,rbx
 793:	4c 0f b6 77 06       	movzx  r14,BYTE PTR [rdi+0x6]
 798:	49 c1 e6 30          	shl    r14,0x30
 79c:	4d 09 ee             	or     r14,r13
 79f:	48 89 cb             	mov    rbx,rcx
 7a2:	48 01 c3             	add    rbx,rax
 7a5:	48 83 c3 02          	add    rbx,0x2
 7a9:	48 89 d8             	mov    rax,rbx
 7ac:	48 c1 e8 3d          	shr    rax,0x3d
 7b0:	48 c1 e3 03          	shl    rbx,0x3
 7b4:	48 09 c3             	or     rbx,rax
 7b7:	48 0f b6 47 07       	movzx  rax,BYTE PTR [rdi+0x7]
 7bc:	48 c1 e0 38          	shl    rax,0x38
 7c0:	4c 09 f0             	or     rax,r14
 7c3:	48 0f b6 7e 07       	movzx  rdi,BYTE PTR [rsi+0x7]
 7c8:	48 c1 e7 38          	shl    rdi,0x38
 7cc:	48 09 d7             	or     rdi,rdx
 7cf:	49 0f b6 70 03       	movzx  rsi,BYTE PTR [r8+0x3]
 7d4:	48 c1 e6 18          	shl    rsi,0x18
 7d8:	48 31 de             	xor    rsi,rbx
 7db:	48 89 ca             	mov    rdx,rcx
 7de:	48 01 f2             	add    rdx,rsi
 7e1:	48 83 c2 03          	add    rdx,0x3
 7e5:	48 89 d6             	mov    rsi,rdx
 7e8:	48 c1 ee 3c          	shr    rsi,0x3c
 7ec:	48 c1 e2 04          	shl    rdx,0x4
 7f0:	48 09 f2             	or     rdx,rsi
 7f3:	49 0f b6 70 04       	movzx  rsi,BYTE PTR [r8+0x4]
 7f8:	48 c1 e6 20          	shl    rsi,0x20
 7fc:	48 31 d6             	xor    rsi,rdx
 7ff:	48 89 ca             	mov    rdx,rcx
 802:	48 01 f2             	add    rdx,rsi
 805:	48 83 c2 04          	add    rdx,0x4
 809:	48 89 d6             	mov    rsi,rdx
 80c:	48 c1 ee 3b          	shr    rsi,0x3b
 810:	48 c1 e2 05          	shl    rdx,0x5
 814:	48 09 f2             	or     rdx,rsi
 817:	49 0f b6 70 05       	movzx  rsi,BYTE PTR [r8+0x5]
 81c:	48 c1 e6 28          	shl    rsi,0x28
 820:	48 31 d6             	xor    rsi,rdx
 823:	48 89 ca             	mov    rdx,rcx
 826:	48 01 f2             	add    rdx,rsi
 829:	48 83 c2 05          	add    rdx,0x5
 82d:	48 89 d6             	mov    rsi,rdx
 830:	48 c1 ee 3a          	shr    rsi,0x3a
 834:	48 c1 e2 06          	shl    rdx,0x6
 838:	48 09 f2             	or     rdx,rsi
 83b:	49 0f b6 70 06       	movzx  rsi,BYTE PTR [r8+0x6]
 840:	48 c1 e6 30          	shl    rsi,0x30
 844:	48 31 d6             	xor    rsi,rdx
 847:	48 89 ca             	mov    rdx,rcx
 84a:	48 01 f2             	add    rdx,rsi
 84d:	48 83 c2 06          	add    rdx,0x6
 851:	48 89 d6             	mov    rsi,rdx
 854:	48 c1 ee 39          	shr    rsi,0x39
 858:	48 c1 e2 07          	shl    rdx,0x7
 85c:	48 09 f2             	or     rdx,rsi
 85f:	49 0f b6 70 07       	movzx  rsi,BYTE PTR [r8+0x7]
 864:	48 c1 e6 38          	shl    rsi,0x38
 868:	48 31 d6             	xor    rsi,rdx
 86b:	48 01 f1             	add    rcx,rsi
 86e:	48 83 c1 07          	add    rcx,0x7
 872:	48 89 ce             	mov    rsi,rcx
 875:	48 c1 ee 38          	shr    rsi,0x38
 879:	48 c1 e1 08          	shl    rcx,0x8
 87d:	48 09 f1             	or     rcx,rsi
 880:	48 01 cf             	add    rdi,rcx
 883:	48 31 f8             	xor    rax,rdi
 886:	41 5e                	pop    r14
 888:	41 5d                	pop    r13
 88a:	5b                   	pop    rbx
 88b:	c9                   	leave
 88c:	e9 39 18 c1 dc       	jmp    0xffffffffdcc120ca
```

## llvmbpf JIT ASM
```asm
not captured
```
