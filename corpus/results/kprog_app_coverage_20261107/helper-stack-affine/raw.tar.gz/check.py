from pathlib import Path
import importlib.util,sys
R=Path('/workspaces/repository');D=Path(__file__).parent;sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/x86/micro-prog'))
# Execute the existing generic checker with its canonical relative include root.
namespace={'__name__':'private_affine_check','__file__':str(R/'kprog/formal/tools/check_x86_flag_definedness.py')}
exec(compile((D/'checker.candidate.py').read_text(),namespace['__file__'],'exec'),namespace)
spec=importlib.util.spec_from_file_location('candidate_abi',D/'candidate.py');abi=importlib.util.module_from_spec(spec);sys.modules[spec.name]=abi;spec.loader.exec_module(abi);namespace['g'].check_definedness=abi.check_definedness
namespace['main']()
