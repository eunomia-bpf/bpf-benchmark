set -eu
D=/workspaces/.agent-state/kprog-lanes/C/helper-stack-affine
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
python3 "$D/check.py"
