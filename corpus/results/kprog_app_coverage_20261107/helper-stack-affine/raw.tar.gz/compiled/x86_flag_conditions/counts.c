#define X86_SIM_USE_STATE_STRUCT
#include "../x86/x86_sim_local_bpf.h"
#include "oracles/x86_no_helpers_host.h"
static void shld_rax(struct x86_sim_state *state, unsigned width) {
X86_SIM_L_BIND_COMMON_STATE(state);
X86_SIM_L_EXEC(X86_OP_SHLD_IMM,X86_RAX,X86_RBX,width,0,X86_SIM_L_READ_REG_WIDTH_SHIFT(X86_RCX, X86_WIDTH_8, 0));
}
static void shld_rcx(struct x86_sim_state *state, unsigned width) {
X86_SIM_L_BIND_COMMON_STATE(state);
X86_SIM_L_EXEC(X86_OP_SHLD_IMM,X86_RCX,X86_RBX,width,0,X86_SIM_L_READ_REG_WIDTH_SHIFT(X86_RCX, X86_WIDTH_8, 0));
}
static void shrd_rax(struct x86_sim_state *state, unsigned width) {
X86_SIM_L_BIND_COMMON_STATE(state);
X86_SIM_L_EXEC(X86_OP_SHRD_IMM,X86_RAX,X86_RBX,width,0,X86_SIM_L_READ_REG_WIDTH_SHIFT(X86_RCX, X86_WIDTH_8, 0));
}
static void shrd_rcx(struct x86_sim_state *state, unsigned width) {
X86_SIM_L_BIND_COMMON_STATE(state);
X86_SIM_L_EXEC(X86_OP_SHRD_IMM,X86_RCX,X86_RBX,width,0,X86_SIM_L_READ_REG_WIDTH_SHIFT(X86_RCX, X86_WIDTH_8, 0));
}

#include <stdio.h>
int main(void) {
  unsigned cases = 0;
  for (unsigned width = 2; width <= 8; width *= 2)
  for (unsigned count = 0; count < 256; count++)
  for (unsigned right = 0; right < 2; right++)
  for (unsigned alias = 0; alias < 2; alias++) {
    struct x86_sim_state state = {0};
    state.rax.ptr = (void *)0xaabbccdd12348001UL;
    state.rbx.ptr = (void *)0x112233448765abcdUL;
    state.rcx.ptr = (void *)(0x5a5a5a5a7ff00000UL | count);
    state.cf = state.pf = state.af = state.of = 1;
    unsigned bits = width * 8, c = count & (bits == 64 ? 63 : 31);
    unsigned long long old = (unsigned long)(alias ? state.rcx.ptr : state.rax.ptr);
    unsigned long long mask = ~0ULL >> (64 - bits), a = old & mask;
    unsigned long long b = (unsigned long)state.rbx.ptr & mask;
    unsigned __int128 pair = right ? ((unsigned __int128)b << bits) | a : ((unsigned __int128)a << bits) | b;
    unsigned long long r = !c ? a : right ? (unsigned long long)(pair >> c) & mask :
        (unsigned long long)((pair << c) >> bits) & mask;
    if (right) { if (alias) shrd_rcx(&state,width); else shrd_rax(&state,width); }
    else { if (alias) shld_rcx(&state,width); else shld_rax(&state,width); }
    unsigned long long actual = (unsigned long)(alias ? state.rcx.ptr : state.rax.ptr);
    /* At16-bit counts17..31 the entire result/status is ISA-undefined;
     * the unmodified upper register bits remain an architectural obligation. */
    if (c > bits) { if ((actual & ~mask) != (old & ~mask)) return 1; }
    else {
      unsigned long long want = width == 4 ? r : (old & ~mask) | r;
      if (actual != want) return 1;
      if (!c) { if (!state.cf || !state.pf || !state.af || !state.of) return 1; }
      else {
        unsigned parity = 1;
        for (unsigned bit = 0; bit < 8; bit++) parity ^= (r >> bit) & 1;
        unsigned cf = right ? (a >> (c-1)) & 1 : (a >> (bits-c)) & 1;
        if (state.cf != cf || state.pf != parity || state.zf != (r==0) || state.sf != (r >> (bits-1))) return 1;
        if (c == 1 && state.of != ((a ^ r) >> (bits-1))) return 1;
      }
    }
    if ((unsigned long)state.rbx.ptr != 0x112233448765abcdUL) return 1;
    cases++;
  }
  printf("x86 encoded CL double shifts: %u width/count/destination-alias cases OK\n",cases);
  return 0;
}
