#include "../x86_sim_local_bpf.h"

SEC("xdp")
int shrd_conditions_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov rdi,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1:
	/* 0x1: mov ecx,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2:
	/* 0x2: mov ebx,1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1ULL);
x86_l_3:
	/* 0x3: cmp ecx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32);
x86_l_4:
	/* 0x4: shrd ecx,ebx,cl */
	X86_SIM_RUN_OP(X86_OP_SHRD_IMM, X86_RCX, X86_RBX, X86_WIDTH_32, 0, X86_SIM_L_READ_REG_WIDTH_SHIFT(X86_RCX, X86_WIDTH_8, 0));
x86_l_5:
	/* 0x5: cmovp ecx,ebx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RBX, X86_WIDTH_32, X86_CC_P);
x86_l_6:
	/* 0x6: setnp al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_NP);
x86_l_7:
	/* 0x7: jp 8 */
	X86_SIM_X86_JCC(X86_CC_P, 0x7, 0x8, x86_l_8);
x86_l_8:
	/* 0x8: mov eax,2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_9:
	/* 0x9: ret  */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
