#include "../x86_sim_local_bpf.h"

SEC("xdp")
int movx_encoding_12_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov rax,0xABCDEF012345805A */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 12379813738877124698ULL);
x86_l_1:
	/* 0x1: movsx eax,ah */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RAX, KPROG_X86_MOVX_HIGH_SOURCE(X86_RAX), X86_WIDTH_32, X86_WIDTH_8);
x86_l_2:
	/* 0x2: ret  */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
