#include "../x86_sim_local_bpf.h"

SEC("xdp")
int movx_encoding_16_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov rax,0x80 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 128ULL);
x86_l_1:
	/* 0x1: cbw  */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RAX, X86_RAX, X86_WIDTH_16, X86_WIDTH_8);
x86_l_2:
	/* 0x2: movzx eax,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_3:
	/* 0x3: ret  */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
