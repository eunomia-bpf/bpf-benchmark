#include "../x86_sim_local_bpf.h"

SEC("xdp")
int movx_encoding_17_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov rax,0x8000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 32768ULL);
x86_l_1:
	/* 0x1: cwde  */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_2:
	/* 0x2: ret  */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
