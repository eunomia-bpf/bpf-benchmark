set -eu
D=/workspaces/.agent-state/kprog-lanes/C/stack-native-width
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
for name in test_x86_stack_arm_route_host test_x86_stack_write_lanes_route_host; do
 cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -include "$D/read.h" -Ikprog/formal -Ikprog/formal/oracles -Ikprog/x86 -Ivendor/libbpf/src "$D/$name.c" -o "$D/$name"
 "$D/$name"
done
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/actual-tetragon.bpf.c" -o "$D/actual-tetragon.bpf.o"
