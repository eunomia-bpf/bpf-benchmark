set -eu
D=/workspaces/.agent-state/kprog-lanes/C/narrow-value-identity
trap 'echo $? > "$D/host.identity.exit"' EXIT
cd /workspaces/repository
for name in test_x86_cmpop_host test_x86_cmpop_route_host test_x86_cmp_mem_route_host; do
 cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -include "$D/identity-read.h" -Ikprog/formal -Ikprog/formal/oracles -Ikprog/x86 -Ivendor/libbpf/src "$D/$name.c" -o "$D/$name"
 "$D/$name"
done
