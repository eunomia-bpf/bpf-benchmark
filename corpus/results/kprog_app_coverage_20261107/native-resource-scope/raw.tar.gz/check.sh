#!/bin/sh
set +e
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/native-resource-scope
CARGO_TARGET_DIR=/workspaces/repository/kprog/x86/native_lab/native_link/target taskset -c 20-23 cargo test --offline --manifest-path "$D/crate/Cargo.toml" --bin native-link-resources-c >"$D/test.log" 2>&1
status=$?; echo "$status" >"$D/test.exit"
if [ "$status" = 0 ]; then
 CARGO_TARGET_DIR=/workspaces/repository/kprog/x86/native_lab/native_link/target taskset -c 20-23 cargo build --release --offline --manifest-path "$D/crate/Cargo.toml" --bin native-link-resources-c >"$D/build.log" 2>&1
 echo "$?" >"$D/build.exit"
fi
