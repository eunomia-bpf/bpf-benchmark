#!/bin/sh
set +e
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/native-resource-scope
taskset -c 20-23 make -f "$D/Makefile" -j2 check >"$D/caller-check.log" 2>&1
echo "$?" >"$D/caller-check.exit"
