set -eu
D=/workspaces/.agent-state/kprog-lanes/C/stack-narrow-candidate
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/C/stack-narrow-candidate/Makefile corpus STATE="$D" CPUS=20-23 VM_CPUS=4 VM_MEM=12G APPS=otelcol-ebpf-profiler/profiling SAMPLES=1 WORKLOAD_DURATION=2
