set -eu
D=/workspaces/.agent-state/kprog-lanes/C/load-width-candidate
trap 'echo $? > "$D/build.exit"' EXIT
cd /workspaces/repository
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -I vendor/libbpf/include/uapi -I vendor/libbpf/src -I /usr/include/x86_64-linux-gnu -c "$D/candidate.c" -o "$D/candidate.o" 2> "$D/build.stderr"
/usr/lib/llvm-18/bin/llvm-objdump -d "$D/candidate.o" > "$D/candidate.dis"
