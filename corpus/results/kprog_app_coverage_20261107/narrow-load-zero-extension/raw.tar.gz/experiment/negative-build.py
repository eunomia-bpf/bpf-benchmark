from pathlib import Path
import sys,hashlib,json
R=Path('/workspaces/repository');D=Path(__file__).parent
sys.path.insert(0,str(R/'kprog/fidelity'))
import negative
names=[f'div{width}_{cause}' for width in [8,16,32,64] for cause in ['zero','overflow']]
copy=negative.shutil.copyfile
mem=R/'kprog/formal/generated/x86_mem_access.h'
def candidate_copy(src,dst,*args,**kw):
 return copy(D/'candidate-mem-access.h' if Path(src).resolve()==mem else src,dst,*args,**kw)
negative.shutil.copyfile=candidate_copy
try:negative.build('x86',D/'negative-build',names=names)
finally:negative.shutil.copyfile=copy
r=json.loads((D/'negative-build/build.json').read_text());assert len(r['cases'])==8 and all(q['stage']=='generated' for q in r['cases']),r
assert (D/'negative-build/snapshot/kprog/formal/generated/x86_mem_access.h').read_bytes()==(D/'candidate-mem-access.h').read_bytes()
