set +e
D=/workspaces/.agent-state/kprog-lanes/C/load-width-candidate
/workspaces/repository/runner/build-llvmbpf/micro_exec run-native-kernel --program "$D/cilium_socket_lb_service_select.bpf.o" --native-program "$D/cilium_socket_lb_service_select.native.so" --memory "$D/cilium_socket_lb_service_select.mem" --io-mode staged --input-size 1544 --inner-repeat 1 > "$D/native.stdout" 2> "$D/native.stderr"
rc=$?
echo "$rc" > "$D/native.exit"
if test "$rc" -eq 0; then
 make -C /workspaces/repository/kprog/fidelity negative-guest ARCH=x86 NEGATIVE_BUILD="$D/negative-build" NEGATIVE_OUT="$D/negative-results" LOADER=/workspaces/repository/kprog/loader/target/debug/reversesim-loader > "$D/negative-run.log" 2>&1
 neg_rc=$?
 echo "$neg_rc" > "$D/negative-run.exit"
 if test "$neg_rc" -ne 0; then rc="$neg_rc"; fi
fi
dmesg > "$D/kernel.log"
cat /proc/meminfo > "$D/meminfo.txt"
exit "$rc"
