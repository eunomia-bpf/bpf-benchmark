set -eu
D=/workspaces/.agent-state/kprog-lanes/C/load-width-candidate
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
python3 - <<'WAIT_NEG'
import os,select
try:
 fd=os.pidfd_open(3430370);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
from pathlib import Path
assert Path('/workspaces/.agent-state/kprog-lanes/C/load-width-candidate/negative-build.exit').read_text().strip()=='0'
WAIT_NEG
sha256sum kprog/x86/x86_sim_local_bpf.h kprog/formal/generated/x86_mem_access.h > "$D/outside-before.sha256"
taskset -c 20-23 vng --run /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /workspaces/.agent-state/kprog-lanes/C --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 2 --memory 4G --append 'loglevel=4 panic=30 oops=panic' --exec 'unshare -m bash /workspaces/.agent-state/kprog-lanes/C/load-width-candidate/guest.sh'
sha256sum kprog/x86/x86_sim_local_bpf.h kprog/formal/generated/x86_mem_access.h > "$D/outside-after.sha256"
cmp "$D/outside-before.sha256" "$D/outside-after.sha256"
