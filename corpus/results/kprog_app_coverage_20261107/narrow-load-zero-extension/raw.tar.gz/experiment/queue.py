from pathlib import Path
import os,select,subprocess,json,hashlib
from datetime import datetime,timezone
D=Path(__file__).parent;R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(3352425);print('WAIT_FOR_EXISTING_OTEL_12G_3352425',flush=True);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
files=['kprog/x86/x86_sim_local_bpf.h','kprog/formal/generated/x86_mem_access.h','kprog/trusted_service.py','kprog/trusted_generation.py','kprog/x86/trusted_specializer.py','kprog/x86/micro-prog/generate_micro_sim_proofs.py','kprog/x86/micro-prog/generated_x86_specialization.py','kprog/x86/native_lab/native_link/target/release/native-link','runner/build-llvmbpf/native_loader/trusted-native-loader','kprog/tv/build-kernel-x86/arch/x86/boot/bzImage','kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko']
r={'started':datetime.now(timezone.utc).isoformat(),'sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files},'private_mem_header_sha256':hashlib.sha256((D/'candidate-mem-access.h').read_bytes()).hexdigest()}
with (D/'run.log').open('wb') as f:p=subprocess.Popen(['sh',str(D/'run.sh')],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
r['driver_pid']=p.pid;(D/'running-inputs.json').write_text(json.dumps(r,indent=2)+'\n');print('PRIVATE_WIDTH_GUEST_PID',p.pid,flush=True)
