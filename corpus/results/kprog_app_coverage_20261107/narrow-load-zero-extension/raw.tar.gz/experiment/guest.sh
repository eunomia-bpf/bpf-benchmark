set -eu
D=/workspaces/.agent-state/kprog-lanes/C/load-width-candidate
mount --make-rprivate /
mount --bind "$D/candidate-mem-access.h" /workspaces/repository/kprog/formal/generated/x86_mem_access.h
sha256sum /workspaces/repository/kprog/x86/x86_sim_local_bpf.h /workspaces/repository/kprog/formal/generated/x86_mem_access.h > "$D/inside-headers.sha256"
PATH=/usr/lib/llvm-18/bin:$PATH python3 kprog/trusted_service.py --arch 1 --endpoint /sys/kernel/debug/bpf_x86_native_lab/specializer --state /run/c-load-width-candidate --module /workspaces/repository/kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko --native-link /workspaces/repository/kprog/x86/native_lab/native_link/target/release/native-link --loader /workspaces/repository/runner/build-llvmbpf/native_loader/trusted-native-loader --results "$D/service.tar.gz" --run bash "$D/case.sh"
