set -eu
D=/workspaces/.agent-state/kprog-lanes/C/load-width-candidate
trap 'echo $? > "$D/host.exit"' EXIT
cd /workspaces/repository/kprog/formal
cc -O1 -g -fsanitize=undefined -fno-sanitize-recover=undefined -I. "$D/memory-host.c" -o "$D/memory-host"
"$D/memory-host"
