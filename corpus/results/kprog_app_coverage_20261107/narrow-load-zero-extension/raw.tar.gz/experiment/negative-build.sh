set -eu
D=/workspaces/.agent-state/kprog-lanes/C/load-width-candidate
trap 'echo $? > "$D/negative-build.exit"' EXIT
cd /workspaces/repository
PATH=/usr/lib/llvm-18/bin:$PATH python3 "$D/negative-build.py"
