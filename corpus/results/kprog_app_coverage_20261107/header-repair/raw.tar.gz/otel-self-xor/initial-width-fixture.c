#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "candidate.h"
unsigned long native_lab_entry_input(unsigned int kind) { if (kind != NATIVE_LAB_INPUT_SP) abort(); return 0; }
struct result { uint64_t bits, flags; unsigned tag, changed; };
static uint64_t cpu(uint64_t bits, unsigned form, uint64_t flags, uint64_t *outflags) {
 uint64_t out,f;
#define RUN(OP) asm volatile("movq %2,%%rax; pushq %3; popfq; " OP "; pushfq; popq %1; movq %%rax,%0" : "=r"(out),"=r"(f) : "r"(bits),"r"(flags) : "rax","cc","memory")
 switch(form) {
 case 0: RUN("xor %%al,%%al");break; case 1: RUN("xor %%ah,%%ah");break;
 case 2: RUN("xor %%ax,%%ax");break; case 3: RUN("xor %%eax,%%eax");break;
 case 4: RUN("xor %%rax,%%rax");break; case 5: RUN("xor %%ah,%%al");break;
 case 6: RUN("xor %%al,%%ah");break; default:abort();
 }
#undef RUN
 *outflags=f & 0x8c5ULL;return out;
}
static struct result model(uint64_t bits,unsigned form,uint64_t flags,unsigned tag) {
 static const unsigned widths[]={8,8,16,32,64,8,8}, dst[]={0,8,0,0,0,0,8}, src[]={0,8,0,0,0,8,0};
 X86_SIM_ENTRY_XDP((struct xdp_md *)0);
#define INIT(REG, NAME) __x86_##NAME.ptr=(void *)(uintptr_t)(bits ^ ((uint64_t)(REG)*0x123456789abcdefULL)); __x86_##NAME##_tag=X86_SIM_TAG_SCALAR;
 X86_SIM_L_FOR_EACH_GPR(INIT)
#undef INIT
 __x86_rdx.ptr=(void *)(uintptr_t)bits;__x86_rdx_tag=tag;
 __x86_cf=!!(flags&1);__x86_pf=!!(flags&4);__x86_af=!!(flags&16);__x86_zf=!!(flags&64);__x86_sf=!!(flags&128);__x86_of=!!(flags&2048);
 X86_SIM_L_EXEC_ALU_REG(X86_RDX,X86_RDX,widths[form],KPROG_X86_REG_LANE_AUX(X86_ALU_XOR,dst[form],src[form]));
 unsigned changed=0;
#define CHECK(REG, NAME) if ((REG)!=X86_RDX && ((uint64_t)(uintptr_t)__x86_##NAME.ptr!=(bits ^ ((uint64_t)(REG)*0x123456789abcdefULL)) || __x86_##NAME##_tag!=X86_SIM_TAG_SCALAR)) changed++;
 X86_SIM_L_FOR_EACH_GPR(CHECK)
#undef CHECK
 return (struct result){(uint64_t)(uintptr_t)__x86_rdx.ptr,(__x86_cf?1:0)|(__x86_pf?4:0)|(__x86_af?16:0)|(__x86_zf?64:0)|(__x86_sf?128:0)|(__x86_of?2048:0),__x86_rdx_tag,changed};
}
int main(void) {
 uint64_t words[64]={0,1,~0ULL,0xffffffffULL,0x100000000ULL,0x8000000000000000ULL,0x7fffffffffffffffULL,0xff00ff00ff00ff00ULL};
 words[8]=(uint64_t)(uintptr_t)words;words[9]=words[8]+3;
 for(unsigned i=10;i<64;i++){uint64_t x=words[i-1]^0x9e3779b97f4a7c15ULL;x^=x<<13;x^=x>>7;x^=x<<17;words[i]=x;}
 const unsigned positions[]={0,2,4,6,7,11};unsigned cases=0;
 for(unsigned wi=0;wi<64;wi++)for(unsigned seed=0;seed<64;seed++)for(unsigned form=0;form<7;form++) {
  uint64_t flags=0x202;for(unsigned k=0;k<6;k++)if(seed&(1U<<k))flags|=1ULL<<positions[k];
  uint64_t cf,cb=cpu(words[wi],form,flags,&cf);unsigned tags=(form==3||form==4)?9:1;
  for(unsigned tag=0;tag<tags;tag++) {
   struct result m=model(words[wi],form,flags,tag);cases++;
   if(m.bits!=cb||(m.flags&0x8c5ULL)!=cf||(m.flags&0x10ULL)!=(flags&0x10ULL)||m.tag!=X86_SIM_TAG_SCALAR||m.changed) {printf("FAIL form=%u tag=%u word=%llx model=%llx/%llx cpu=%llx/%llx changed=%u\n",form,tag,(unsigned long long)words[wi],(unsigned long long)m.bits,(unsigned long long)m.flags,(unsigned long long)cb,(unsigned long long)cf,m.changed);return 1;}
  }
 }
 printf("{\"cases\":%u,\"differences\":0,\"forms\":7,\"full_width_tags\":9,\"other_register_changes\":0,\"defined_native_flags_mask\":2245,\"model_af_preserved\":true}\n",cases);return 0;
}
