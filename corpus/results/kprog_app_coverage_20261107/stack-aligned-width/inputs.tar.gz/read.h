#ifndef KPROG_FORMAL_GENERATED_X86_REG_READ_H
#define KPROG_FORMAL_GENERATED_X86_REG_READ_H
#define KPROG_X86_READ_REG_AT(VALUE, WIDTH, BYTE_SHIFT) \
 ({ __u64 __kprog_x86_read = KPROG_X86_APPLY_WIDTH((VALUE) >> ((WIDTH) == X86_WIDTH_8 ? (BYTE_SHIFT) : 0U), (WIDTH)); \
    if ((WIDTH) != X86_WIDTH_64 && (WIDTH) != 0U) \
      __asm__("" : "+r"(__kprog_x86_read)); \
    __kprog_x86_read; })
#endif
