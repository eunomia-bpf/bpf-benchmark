#!/bin/bash
make -f /workspaces/.agent-state/kprog-lanes/C/stack-aligned-width/Makefile check >/workspaces/.agent-state/kprog-lanes/C/stack-aligned-width/checks.log 2>&1
rc=$?
printf "%s\n" "$rc" >/workspaces/.agent-state/kprog-lanes/C/stack-aligned-width/checks.exit
exit "$rc"
