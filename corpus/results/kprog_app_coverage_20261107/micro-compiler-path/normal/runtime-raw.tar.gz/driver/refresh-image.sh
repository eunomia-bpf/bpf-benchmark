set -eu
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/C/micro-shared-elf
trap 'echo $? > "$D/image.exit"' EXIT
python3 - <<'PY'
from pathlib import Path
import hashlib,shutil,json,subprocess
R=Path('/workspaces/repository');D=Path('/workspaces/.agent-state/kprog-lanes/C/micro-shared-elf');P=D/'image-context';P.mkdir(exist_ok=True)
base=json.loads(subprocess.check_output(['docker','image','inspect','bpf-benchmark/kprog-micro-trusted:c-20261107']))[0];pins={}
for n in ['runner/build-llvmbpf/micro_exec','micro/driver.py','runner/suites/micro.py']:
 src=R/n;dst=P/n;dst.parent.mkdir(parents=True,exist_ok=True);before=hashlib.sha256(src.read_bytes()).hexdigest();shutil.copy2(src,dst);assert hashlib.sha256(dst.read_bytes()).hexdigest()==before and hashlib.sha256(src.read_bytes()).hexdigest()==before;pins[n]=before
(P/'Dockerfile').write_text('FROM bpf-benchmark/kprog-micro-trusted:c-20261107\n'+''.join('COPY '+n+' /workspaces/repository/'+n+'\n' for n in pins))
(D/'image-inputs.json').write_text(json.dumps(dict(base_id=base['Id'],base_layers=base['RootFS']['Layers'],files=pins),indent=2)+'\n')
PY
docker build -t bpf-benchmark/kprog-micro-trusted:c-20261107 "$D/image-context"
docker image inspect bpf-benchmark/kprog-micro-trusted:c-20261107 > "$D/image.json"
