import json,sys,shutil
from pathlib import Path
sys.path.insert(0,'/workspaces/repository/kprog')
from trusted_service import adapter
src=Path('/workspaces/.agent-state/kprog-lanes/C/micro-shared-elf/request-1')
print(json.dumps({'clang':shutil.which('clang'),'llvm_objdump':shutil.which('llvm-objdump')}),flush=True)
result=adapter(1).specialize((src/'kernel.native.o').read_bytes(),(src/'kernel.entry').read_text(),json.loads((src/'generation.metadata.json').read_text()),Path(sys.argv[1]),Path('/workspaces/repository/kprog/x86/native_lab/native_link/target/release/native-link'))
print(json.dumps(result),flush=True)
