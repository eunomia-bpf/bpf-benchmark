set -eu
D=/workspaces/.agent-state/kprog-lanes/C/module-runtime-refresh
trap 'echo $? > "$D/refresh.exit"' EXIT
cd /workspaces/repository
make -j4 -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Makefile modules > "$D/modules.log" 2>&1
python3 - <<'WAIT'
import os,select
try:
 fd=os.pidfd_open(3542221);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
WAIT
make -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Makefile package > "$D/package.log" 2>&1
docker build -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Dockerfile -t bpf-benchmark/kprog-native-only:x86-current /workspaces/.agent-state/kprog-lanes/C/native-only-runtime/package > "$D/image.log" 2>&1
