set -eu
D=/workspaces/.agent-state/kprog-lanes/C/module-runtime-refresh
trap 'echo $? > "$D/image-refresh.exit"' EXIT
cd /workspaces/repository
make -C bpfopt/shim SHIM_SO=/workspaces/repository/bpfopt/shim/build-x86/libbpfrejit_shim.so /workspaces/repository/bpfopt/shim/build-x86/libbpfrejit_shim.so > "$D/shim.log" 2>&1
make -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Makefile package > "$D/package.log" 2>&1
docker build -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Dockerfile -t bpf-benchmark/kprog-native-only:x86-current /workspaces/.agent-state/kprog-lanes/C/native-only-runtime/package > "$D/image.log" 2>&1
