set -eu
D=/workspaces/.agent-state/kprog-lanes/C/stack-narrow-candidate
trap 'echo $? > "$D/host.exit"' EXIT
cd /workspaces/repository
cc -O2 -g -fsanitize=undefined -fno-sanitize-recover=undefined -I /usr/include/bpf -I /workspaces/repository/kprog/formal "$D/stack-memory.c" -o "$D/stack-memory"
"$D/stack-memory"
