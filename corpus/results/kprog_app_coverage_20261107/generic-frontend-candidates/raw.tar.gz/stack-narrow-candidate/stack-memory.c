#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define X86_SIM_ENABLE_STACK
#define X86_SIM_STACK_BYTES 128U
#include "host-candidate.h"
static uint64_t rng=0xc3284141a9b9dcf1ULL;
static uint64_t next(void) { rng^=rng<<13; rng^=rng>>7; rng^=rng<<17; return rng; }
int main(void) {
 const unsigned widths[]={0,1,2,4,8};unsigned long cases=0;
 for(unsigned k=0;k<5;k++) { unsigned w=widths[k]?widths[k]:8;
  for(unsigned index=0;index+w<=128;index++) for(unsigned seed=0;seed<1024;seed++) {
   union x86_sim_stack_mem __x86_stack_mem;unsigned char expected[128];
   for(unsigned b=0;b<128;b++) expected[b]=(unsigned char)next();
   memcpy(__x86_stack_mem.b,expected,128);uint64_t want=0;
   for(unsigned b=0;b<w;b++) want|=(uint64_t)expected[index+b]<<(8*b);
   uint64_t got=X86_SIM_L_STACK_READ((int64_t)index-128,widths[k]);
   if(got!=want) { printf("read difference width=%u index=%u\n",widths[k],index);return 1; }
   uint64_t value=next();X86_SIM_L_STACK_WRITE((int64_t)index-128,widths[k],value);
   for(unsigned b=0;b<w;b++) expected[index+b]=(unsigned char)(value>>(8*b));
   if(memcmp(__x86_stack_mem.b,expected,128)) { printf("write difference width=%u index=%u\n",widths[k],index);return 1; }
   cases++;
  }
 }
 printf("generic stack read/write byte oracle: %lu cases, differences=0\n",cases);return 0;
}
