from pathlib import Path
import importlib.util,sys,subprocess,json,hashlib,random
R=Path('/workspaces/repository');D=Path(__file__).parent;sys.path.insert(0,str(R/'kprog/x86/micro-prog'));sys.path.insert(0,str(R/'kprog'))
def load(name):
 spec=importlib.util.spec_from_file_location('reader_'+name,D/(name+'.py'));m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);m.REPO_ROOT=R;return m
old,new=load('before'),load('candidate');rng=random.Random(325061);out=[]
fixtures=D/'fixtures';fixtures.mkdir()
for size in [1,2,3,4,6,7,8,15,16,17,31,32,33,47,63,64,65,127,128,255,256,257]:
 for pattern in ['hex_ascii','random','paired','marker']:
  payload=(b'deadbeef00000000abcdefABCD'*((size+23)//24))[:size] if pattern=='hex_ascii' else bytes(rng.randrange(256) for _ in range(size))
  objects={'first':payload};expected=payload;lines=['.section .native_link_rodata,"a"','.global first','.type first,@object','first:','.byte '+','.join(str(b) for b in payload),'.size first,.-first']
  if pattern=='paired':
   padding=(-len(expected))%16;expected+=bytes(padding)+payload;objects['second']=payload;lines+=['.balign 16','.global second','.type second,@object','second:','.byte '+','.join(str(b) for b in payload),'.size second,.-second']
  if pattern=='marker':lines+=['.global anchor','anchor:']
  name=pattern+'-'+str(size);src=fixtures/(name+'.S');obj=fixtures/(name+'.o');src.write_text('\n'.join(lines)+'\n');subprocess.run(['cc','-c',str(src),'-o',str(obj)],check=True,capture_output=True)
  row={'name':name,'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'expected_size':len(expected),'expected_objects':list(objects)}
  for label,reader in [('before',old),('candidate',new)]:
   try:
    data=reader.rodata_bytes(obj);blobs=reader.load_rodata_blobs(obj);row[label]={'bytes':len(data),'byte_equal':data==expected,'objects_equal':blobs==objects}
   except Exception as error:row[label]={'error':str(error)}
  assert row['candidate'].get('byte_equal') and row['candidate'].get('objects_equal'),row
  out.append(row)
# A data object with an extent crossing its actual section exercises the bounds check.
src=fixtures/'extent.S';obj=fixtures/'extent.o';src.write_text('.section .native_link_rodata,"a"\n.global bad\n.type bad,@object\nbad: .byte 1\n.size bad,9\n');subprocess.run(['cc','-c',str(src),'-o',str(obj)],check=True)
try:new.load_rodata_blobs(obj)
except ValueError as error:extent={'rejected':True,'error':str(error)}
else:raise AssertionError('extent acceptance differs from the reader contract')
src=fixtures/'other-section.S';obj=fixtures/'other-section.o';src.write_text('.section .other,"a"\n.byte 1,2,3\n');subprocess.run(['cc','-c',str(src),'-o',str(obj)],check=True);assert new.rodata_bytes(obj)==b'' and new.load_rodata_blobs(obj)=={}
summary={'data_cases':len(out),'before_differences':sum(not r['before'].get('byte_equal',False) or not r['before'].get('objects_equal',False) for r in out),'candidate_differences':0,'extent':extent,'missing_section_empty':True,'rows':out};(D/'observations.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='rows'}),flush=True)
