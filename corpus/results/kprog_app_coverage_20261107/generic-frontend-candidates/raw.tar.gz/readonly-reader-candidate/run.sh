set -eu
D=/workspaces/.agent-state/kprog-lanes/C/readonly-reader-candidate
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
python3 "$D/matrix.py"
