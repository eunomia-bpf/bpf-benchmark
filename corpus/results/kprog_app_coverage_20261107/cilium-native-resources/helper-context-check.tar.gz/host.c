#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
struct xdp_md;
static long observed(struct xdp_md *, unsigned int, void *, unsigned int);
#define bpf_xdp_load_bytes(CTX, OFF, BUF, LEN) observed((CTX),(OFF),(BUF),(LEN))
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 64U
#include "/workspaces/.agent-state/kprog-lanes/C/xdp-load-helper/candidate.h"
#include "helper.h"
unsigned long native_lab_entry_input(unsigned int kind) { assert(kind==NATIVE_LAB_INPUT_SP); return 0x100000UL; }
static struct xdp_md *expected_ctx;
static unsigned calls;
static long observed(struct xdp_md *ctx, unsigned int offset, void *buf, unsigned int len) {
 assert(ctx==expected_ctx && len==8);++calls;
 if(offset==UINT32_MAX)return -14;
 assert(offset==4);memset(buf,0xa5,len);return 0;
}
static void check(uint64_t upper, int fail) {
 struct xdp_md ctx={0};unsigned char buf[24];memset(buf,0x5a,sizeof(buf));expected_ctx=&ctx;
 X86_SIM_ENTRY_XDP(&ctx);
 ctx.data_meta=0x3456;
 assert(X86_SIM_L_XDP_READ(&ctx,16,X86_WIDTH_64)==0x3456);
 assert(X86_SIM_L_XDP_READ((char *)&ctx+8,8,X86_WIDTH_64)==0x3456);
 assert(KPROG_ABI_LOAD_TAG(KPROG_ABI_KIND_XDP,16,X86_SIM_TAG_SCALAR,X86_SIM_TAG_PACKET,X86_SIM_TAG_PACKET_END)==X86_SIM_TAG_PACKET);
 X86_SIM_L_WRITE_REG_WIDTH(X86_RSI, upper|(fail?UINT32_MAX:4), X86_WIDTH_64);
 X86_SIM_L_WRITE_REG_PTR_TAG(X86_RDX,buf+8,X86_SIM_TAG_MAP_VALUE);
 X86_SIM_L_WRITE_REG_WIDTH(X86_RCX, upper|8, X86_WIDTH_64);
 X86_SIM_BPF_CALL_bpf_xdp_load_bytes();
 assert(X86_SIM_L_READ_REG(X86_RAX)==(uint64_t)(fail?-14LL:0LL));
 for(unsigned i=0;i<24;i++)assert(buf[i]==((!fail&&i>=8&&i<16)?0xa5:0x5a));
}
int main(void) {for(unsigned high=0;high<2;high++)for(unsigned fail=0;fail<2;fail++)check(high?0xa5a5a5a500000000ULL:0,fail);assert(calls==4);puts("XDP load helper ABI: 4 argument/result/memory controls PASS");}
