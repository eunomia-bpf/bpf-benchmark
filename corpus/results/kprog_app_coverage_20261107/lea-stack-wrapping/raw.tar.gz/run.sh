set -eu
D=/workspaces/.agent-state/kprog-lanes/C/lea-stack-wrapping
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
python3 kprog/formal/tools/generate_x86_mem_offset_spec.py --check
for name in test_x86_lea_route_host test_x86_lea_handler_host test_x86_mem_offset_route_host; do
 cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -Ikprog/formal -Ikprog/formal/oracles -Ikprog/x86 -Ivendor/libbpf/src kprog/formal/oracles/$name.c -o "$D/$name"
 "$D/$name"
done
