set -eu
D=/workspaces/.agent-state/kprog-lanes/C/skb-live-context
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/actual-cilium.bpf.c" -o "$D/actual-cilium.bpf.o"
/usr/lib/llvm-18/bin/llvm-objdump -dr "$D/actual-cilium.bpf.o" >"$D/disassembly.txt"
