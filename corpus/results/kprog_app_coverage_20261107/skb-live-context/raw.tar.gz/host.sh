set -eu
D=/workspaces/.agent-state/kprog-lanes/C/skb-live-context
trap 'echo $? > "$D/host.exit"' EXIT
cd /workspaces/repository
cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -Ikprog/x86 -Ivendor/libbpf/src -Ivendor/libbpf/include/uapi "$D/host.c" -o "$D/host"
"$D/host"
