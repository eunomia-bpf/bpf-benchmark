#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 64U
#include "candidate.h"
unsigned long native_lab_entry_input(unsigned int kind) {
 assert(kind==NATIVE_LAB_INPUT_SP); return 0x100000UL;
}
static uint64_t seed=0x19203a98721b45ULL;
static uint32_t rnd(void) { seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return (uint32_t)seed; }
#define LOAD(OFF,WIDTH) X86_SIM_L_READ_MEM_VALUE(X86_RDI,X86_MEM_AUX(X86_REG_NONE,0),OFF,WIDTH,0)
static void check(void) {
 struct __sk_buff ctx={0};
 uint32_t linear=rnd()&65535,fragment=rnd()&65535;
 ctx.data=0x100000;ctx.data_end=ctx.data+linear;ctx.len=linear+fragment;
 ctx.queue_mapping=rnd()&65535;ctx.tc_index=rnd()&65535;
 ctx.priority=rnd();ctx.ingress_ifindex=rnd();ctx.hash=rnd();ctx.mark=rnd();
 ctx.protocol=rnd()&65535;ctx.tstamp=((uint64_t)rnd()<<32)|rnd();
 for(unsigned i=0;i<5;++i)ctx.cb[i]=0x17701U*i+seed;
 X86_SIM_ENTRY_SKB(&ctx);
 assert(X86_SIM_L_READ_REG_PTR(X86_RDI)==&ctx);
 assert(X86_SIM_L_HELPER_CTX_PTR(X86_RDI)==&ctx);
 assert(LOAD(48,X86_WIDTH_32)==ctx.cb[0]);
 assert(LOAD(52,X86_WIDTH_32)==ctx.cb[1]);
 assert(LOAD(56,X86_WIDTH_32)==ctx.cb[2]);
 assert(LOAD(60,X86_WIDTH_32)==ctx.cb[3]);
 assert(LOAD(64,X86_WIDTH_32)==ctx.cb[4]);
 assert(LOAD(48,X86_WIDTH_64)==((uint64_t)ctx.cb[0]|((uint64_t)ctx.cb[1]<<32)));
 assert(LOAD(60,X86_WIDTH_64)==((uint64_t)ctx.cb[3]|((uint64_t)ctx.cb[4]<<32)));
 assert(LOAD(112,X86_WIDTH_32)==ctx.len);
 assert(LOAD(116,X86_WIDTH_32)==fragment);
 assert(LOAD(124,X86_WIDTH_16)==ctx.queue_mapping);
 assert(LOAD(134,X86_WIDTH_16)==ctx.tc_index);
 assert(LOAD(144,X86_WIDTH_32)==ctx.priority);
 assert(LOAD(148,X86_WIDTH_32)==ctx.ingress_ifindex);
 assert(LOAD(152,X86_WIDTH_32)==ctx.hash);
 assert(LOAD(168,X86_WIDTH_32)==ctx.mark);
 assert(LOAD(180,X86_WIDTH_16)==ctx.protocol);
 assert(LOAD(32,X86_WIDTH_64)==ctx.tstamp);
 assert(LOAD(208,X86_WIDTH_64)==ctx.data);
 assert(LOAD(80,X86_WIDTH_64)==ctx.data_end);
 X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RAX,X86_RDI,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),208ULL);
 assert(X86_SIM_L_READ_REG(X86_RAX)==ctx.data);
 assert(X86_SIM_L_REG_TAG(X86_RAX)==X86_SIM_TAG_PACKET);
 X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD,X86_RAX,X86_RDI,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),80ULL);
 assert(X86_SIM_L_READ_REG(X86_RAX)==ctx.data_end);
 assert(X86_SIM_L_REG_TAG(X86_RAX)==X86_SIM_TAG_PACKET_END);
 struct __sk_buff expected=ctx;
 uint64_t value=((uint64_t)rnd()<<32)|rnd();
 X86_SIM_L_WRITE_REG_WIDTH(X86_RAX,value,X86_WIDTH_64);
 X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_RDI,X86_RAX,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),52ULL);
 expected.cb[1]=(uint32_t)value;expected.cb[2]=value>>32;
 assert(memcmp(&ctx,&expected,sizeof(ctx))==0);
 X86_SIM_L_EXEC_LEA(X86_R8,X86_RDI,X86_WIDTH_64,X86_MEM_AUX(X86_REG_NONE,0),64ULL);
 assert(X86_SIM_L_READ_MEM_VALUE(X86_R8,X86_MEM_AUX(X86_REG_NONE,0),(uint64_t)-16LL,X86_WIDTH_32,0)==ctx.cb[0]);
 X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG,X86_R8,X86_RAX,X86_WIDTH_32,X86_MEM_AUX(X86_REG_NONE,0),(uint64_t)-12LL);
 expected.cb[1]=(uint32_t)value;
 assert(memcmp(&ctx,&expected,sizeof(ctx))==0);
}
int main(void) { for(unsigned i=0;i<65536;i++)check();puts("live skb ABI: 65536 context frames passed"); }
