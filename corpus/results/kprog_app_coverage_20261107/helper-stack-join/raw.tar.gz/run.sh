set -eu
D=/workspaces/.agent-state/kprog-lanes/C/helper-stack-join
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
python3 "$D/check.py" prior
python3 "$D/check.py"
