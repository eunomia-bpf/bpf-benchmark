from pathlib import Path
import importlib.util,sys,json
R=Path('/workspaces/repository');D=Path(__file__).parent;sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/x86/micro-prog'))
namespace={'__name__':'generic_join_check','__file__':str(R/'kprog/formal/tools/check_x86_flag_definedness.py')}
exec(compile((D/'checker.candidate.py').read_text(),str(D/'checker.candidate.py'),'exec'),namespace)
if len(sys.argv)>1:
 try:namespace['main']()
 except (AssertionError,ValueError) as e:
  assert 'native helper source stack relation unresolved' in str(e),str(e)
  (D/'prior-control.json').write_text(json.dumps({'detected':True,'error':str(e)},indent=2)+'\n');print('PRIOR_JOIN_CONTROL_DETECTED');sys.exit(0)
 raise AssertionError('Prior analysis control requires detection')
spec=importlib.util.spec_from_file_location('candidate_join_abi',D/'candidate.py');abi=importlib.util.module_from_spec(spec);sys.modules[spec.name]=abi;spec.loader.exec_module(abi);namespace['g'].check_definedness=abi.check_definedness
namespace['main']()
