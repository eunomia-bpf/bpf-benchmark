set +e
D=/workspaces/.agent-state/kprog-lanes/C/compare-flags-candidate
P=/workspaces/.agent-state/kprog-lanes/C/micro-admission-debug
/workspaces/repository/runner/build-llvmbpf/micro_exec run-native-kernel --program "$P/trace_event_type_switch_dispatch.bpf.o" --native-program "$P/trace_event_type_switch_dispatch.native.so" --memory "$P/trace_event_type_switch_dispatch.mem" --io-mode staged --input-size 1028 --inner-repeat 1 > "$D/trace.stdout" 2> "$D/trace.stderr"
rc=$?
echo "$rc" > "$D/trace.exit"
dmesg > "$D/kernel.log"
cat /proc/meminfo > "$D/meminfo.txt"
exit "$rc"
