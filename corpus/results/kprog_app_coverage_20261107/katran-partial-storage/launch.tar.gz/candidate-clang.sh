#!/bin/sh
exec /usr/lib/llvm-18/bin/clang -include /workspaces/.agent-state/kprog-lanes/C/partial-gpr-storage-candidate/include/generated/x86_reg_write.h "$@"
