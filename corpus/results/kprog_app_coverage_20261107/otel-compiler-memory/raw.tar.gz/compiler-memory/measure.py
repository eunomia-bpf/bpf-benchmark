import json,resource,subprocess,sys,time
from pathlib import Path
start=time.monotonic();done=subprocess.run(sys.argv[2:]);usage=resource.getrusage(resource.RUSAGE_CHILDREN)
Path(sys.argv[1]).write_text(json.dumps(dict(command=sys.argv[2:],returncode=done.returncode,elapsed_s=time.monotonic()-start,max_rss_kib=usage.ru_maxrss,user_s=usage.ru_utime,system_s=usage.ru_stime),indent=2)+"\n")
sys.exit(done.returncode if done.returncode>=0 else 128-done.returncode)
