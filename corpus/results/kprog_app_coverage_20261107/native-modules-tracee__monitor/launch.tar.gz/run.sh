set -eu
D=/workspaces/.agent-state/kprog-lanes/C/remaining-apps-modules/tracee__monitor
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
make -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Makefile corpus STATE="$D" CPUS=20-23 VM_CPUS=8 VM_MEM=12G APPS=tracee/monitor SAMPLES=1 WORKLOAD_DURATION=2
