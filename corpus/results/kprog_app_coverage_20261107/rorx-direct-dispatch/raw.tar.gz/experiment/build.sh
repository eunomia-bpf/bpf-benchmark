set -eu
D=/workspaces/.agent-state/kprog-lanes/C/siphash-oom
trap 'echo $? > "$D/build.exit"' EXIT
cd /workspaces/repository
python3 "$D/build.py"
