set +e
D=/workspaces/.agent-state/kprog-lanes/C/siphash-oom
P=/workspaces/.agent-state/kprog-lanes/C/micro-admission-debug
/workspaces/repository/runner/build-llvmbpf/micro_exec run-native-kernel --program "$P/siphash_rotate64_mixer.bpf.o" --native-program "$P/siphash_rotate64_mixer.native.so" --memory "$P/siphash_rotate64_mixer.mem" --io-mode staged --input-size 64 --inner-repeat 1 > "$D/native.stdout" 2> "$D/native.stderr"
rc=$?
echo "$rc" > "$D/native.exit"
dmesg > "$D/kernel.log"
cat /proc/meminfo > "$D/meminfo.txt"
exit "$rc"
