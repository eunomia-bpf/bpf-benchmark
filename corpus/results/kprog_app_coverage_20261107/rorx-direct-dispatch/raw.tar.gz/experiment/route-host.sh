set -eu
D=/workspaces/.agent-state/kprog-lanes/C/siphash-oom
trap 'echo $? > "$D/route-host.exit"' EXIT
cd /workspaces/repository/kprog/formal
cc -O1 -g -fsanitize=undefined -fno-sanitize-recover=undefined -I. -Ioracles -I/workspaces/repository/vendor/libbpf/src "$D/route-host.c" -o "$D/route-host"
"$D/route-host"
