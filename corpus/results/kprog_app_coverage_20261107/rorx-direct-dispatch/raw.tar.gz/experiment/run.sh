set -eu
D=/workspaces/.agent-state/kprog-lanes/C/siphash-oom
trap 'echo $? > "$D/run.exit"' EXIT
cd /workspaces/repository
sha256sum kprog/x86/x86_sim_local_bpf.h kprog/x86/micro-prog/generated_x86_specialization.py > "$D/outside-before.sha256"
vng --run /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /workspaces/.agent-state/kprog-lanes/C --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 2 --memory 8G --append 'loglevel=4 panic=30 oops=panic' --exec 'unshare -m bash /workspaces/.agent-state/kprog-lanes/C/siphash-oom/guest.sh'
sha256sum kprog/x86/x86_sim_local_bpf.h kprog/x86/micro-prog/generated_x86_specialization.py > "$D/outside-after.sha256"
cmp "$D/outside-before.sha256" "$D/outside-after.sha256"
