from pathlib import Path
import subprocess,json,time,resource,gzip
D=Path(__file__).parent;flags=['/usr/lib/llvm-18/bin/clang','-g','-O3','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_x86','-I','vendor/libbpf/include/uapi','-I','vendor/libbpf/src','-I','/usr/include/x86_64-linux-gnu'];out={}
for name,source in [('before','trusted_x86.bpf.c'),('candidate','candidate.c')]:
 start=time.monotonic();n=0
 with (D/(name+'.preprocess.stderr')).open('w') as err,gzip.open(D/(name+'.i.gz'),'wb') as dest:
  p=subprocess.Popen(flags+['-E',str(D/source)],stdout=subprocess.PIPE,stderr=err)
  while block:=p.stdout.read(1048576):n+=len(block);dest.write(block)
  p.stdout.close();rc=p.wait()
 out[name]={'preprocess_exit':rc,'preprocessed_bytes':n,'preprocess_seconds':time.monotonic()-start};assert rc==0
 print(name,out[name],flush=True)
start=time.monotonic()
with (D/'build.stderr').open('w') as f:r=subprocess.run(flags+['-c',str(D/'candidate.c'),'-o',str(D/'candidate.o')],stderr=f)
out['compile']={'returncode':r.returncode,'seconds':time.monotonic()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss};(D/'build.json').write_text(json.dumps(out,indent=2)+'\n');print(out['compile'],flush=True)
if r.returncode==0:
 with (D/'candidate.dis').open('w') as f:subprocess.run(['/usr/lib/llvm-18/bin/llvm-objdump','-d',str(D/'candidate.o')],stdout=f,check=True)
raise SystemExit(r.returncode)
