set -eu
D=/workspaces/.agent-state/kprog-lanes/C/siphash-oom
trap 'echo $? > "$D/checks.exit"' EXIT
cd /workspaces/repository
python3 kprog/formal/tools/generate_x86_specialization_spec.py --check
python3 kprog/formal/tools/check_macro_hygiene.py
cd kprog/formal
for name in specialization_chain specialization; do
 cc -O2 -Wall -Wextra -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src "oracles/test_x86_${name}_host.c" -o "$D/test_${name}"
 "$D/test_${name}"
done
# Private output prefix: use the existing cached dependencies, do not touch V's build.
install -d "$D/lean/KProgFormal/Generated"
lake env lean -o "$D/lean/KProgFormal/Generated/GeneratedX86Specialization.olean" KProgFormal/Generated/GeneratedX86Specialization.lean
LEAN_BIN=$(lake env which lean)
LEAN_IMPORTS=$(lake env printenv LEAN_PATH)
LEAN_PATH="$D/lean:$LEAN_IMPORTS" "$LEAN_BIN" KProgFormal/X86Specialization.lean
