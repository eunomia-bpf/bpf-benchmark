set -eu
D=/workspaces/.agent-state/kprog-lanes/C/module-runtime-refresh
trap 'echo $? > "$D/boot-btf.exit"' EXIT
cd /workspaces/repository
sh vendor/linux-framework/scripts/extract-vmlinux kprog/tv/build-kernel-x86/arch/x86/boot/bzImage > "$D/boot-vmlinux"
python3 - <<'PY2'
from pathlib import Path
from elftools.elf.elffile import ELFFile
import json,hashlib
D=Path('/workspaces/.agent-state/kprog-lanes/C/module-runtime-refresh');K=Path('kprog/tv/build-kernel-x86');rows={}
for name,p in [('boot',D/'boot-vmlinux'),('build',K/'vmlinux')]:
 with p.open('rb') as f:s=ELFFile(f).get_section_by_name('.BTF').data()
 rows[name]={'btf_sha256':hashlib.sha256(s).hexdigest(),'btf_bytes':len(s)}
assert rows['boot']==rows['build'],rows
rows['bzImage_sha256']=hashlib.sha256((K/'arch/x86/boot/bzImage').read_bytes()).hexdigest();(D/'boot-btf.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
PY2
