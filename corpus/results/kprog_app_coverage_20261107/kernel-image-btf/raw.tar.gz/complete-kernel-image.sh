set -eu
D=/workspaces/.agent-state/kprog-lanes/C/module-runtime-refresh
finish() { rc=$?; echo "$rc" > "$D/complete-kernel-image.exit"; kill -CONT 3653317; }
trap finish EXIT
cd /workspaces/repository
make -j4 -C kprog/tv/build-kernel-x86 ARCH=x86 bzImage > "$D/bzImage.log" 2>&1
make -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Makefile package > "$D/package-kernel-image.log" 2>&1
docker build -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Dockerfile -t bpf-benchmark/kprog-native-only:x86-current /workspaces/.agent-state/kprog-lanes/C/native-only-runtime/package > "$D/image-kernel-image.log" 2>&1
