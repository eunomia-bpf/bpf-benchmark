set -eu
D=/workspaces/.agent-state/kprog-lanes/C/compare-flags-candidate
trap 'echo $? > "$D/proof.exit"' EXIT
cd /workspaces/repository/kprog/formal
lake env lean "$D/CompareSubFlagIdentity.lean"
