set -eu
D=/workspaces/.agent-state/kprog-lanes/C/compare-flags-candidate
trap 'echo $? > "$D/build.exit"' EXIT
cd /workspaces/repository/kprog/formal
for stem in test_x86_cmpop_route_host test_x86_cmp_mem_route_host; do
 cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src "$D/$stem.c" -o "$D/$stem"
 "$D/$stem"
done
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -I /workspaces/repository/vendor/libbpf/include/uapi -I /workspaces/repository/vendor/libbpf/src -I /usr/include/x86_64-linux-gnu -c "$D/trace.c" -o "$D/trace.bpf.o"
