import Std.Tactic.BVDecide
namespace CompareSubFlagIdentity
theorem cmpOverflow8 (a b : BitVec 8) :
    (((a ^^^ b) &&& (a ^^^ (a - b))).msb) =
      Bool.xor (a - b).msb (a.slt b) := by
  bv_decide
#print axioms cmpOverflow8
theorem cmpOverflow16 (a b : BitVec 16) :
    (((a ^^^ b) &&& (a ^^^ (a - b))).msb) =
      Bool.xor (a - b).msb (a.slt b) := by
  bv_decide
#print axioms cmpOverflow16
theorem cmpOverflow32 (a b : BitVec 32) :
    (((a ^^^ b) &&& (a ^^^ (a - b))).msb) =
      Bool.xor (a - b).msb (a.slt b) := by
  bv_decide
#print axioms cmpOverflow32
theorem cmpOverflow64 (a b : BitVec 64) :
    (((a ^^^ b) &&& (a ^^^ (a - b))).msb) =
      Bool.xor (a - b).msb (a.slt b) := by
  bv_decide
#print axioms cmpOverflow64
end CompareSubFlagIdentity
