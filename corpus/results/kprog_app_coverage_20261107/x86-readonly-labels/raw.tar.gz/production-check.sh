set -eu
D=/workspaces/.agent-state/kprog-lanes/C/x86-zero-rodata-label
trap 'echo $? > "$D/production-check.exit"' EXIT
cd /workspaces/repository
cargo test --offline --manifest-path kprog/x86/native_lab/native_link/Cargo.toml --bin native-link
