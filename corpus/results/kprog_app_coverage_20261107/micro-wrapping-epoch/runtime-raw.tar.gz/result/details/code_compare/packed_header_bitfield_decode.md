# packed_header_bitfield_decode

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <packed_header_bitfield_decode_xdp>:
    1100:	4c 8b 07             	mov    r8,QWORD PTR [rdi]
    1103:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
    1107:	4c 89 c2             	mov    rdx,r8
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 ca             	cmp    rdx,rcx
    110f:	76 01                	jbe    1112 <packed_header_bitfield_decode_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 72 08          	lea    rsi,[rdx+0x8]
    1116:	48 39 ce             	cmp    rsi,rcx
    1119:	77 f6                	ja     1111 <packed_header_bitfield_decode_xdp+0x11>
    111b:	48 8d b2 10 02 00 00 	lea    rsi,[rdx+0x210]
    1122:	48 39 ce             	cmp    rsi,rcx
    1125:	77 ea                	ja     1111 <packed_header_bitfield_decode_xdp+0x11>
    1127:	83 7a 08 20          	cmp    DWORD PTR [rdx+0x8],0x20
    112b:	75 e4                	jne    1111 <packed_header_bitfield_decode_xdp+0x11>
    112d:	83 7a 0c 02          	cmp    DWORD PTR [rdx+0xc],0x2
    1131:	75 de                	jne    1111 <packed_header_bitfield_decode_xdp+0x11>
    1133:	55                   	push   rbp
    1134:	41 57                	push   r15
    1136:	41 56                	push   r14
    1138:	41 55                	push   r13
    113a:	41 54                	push   r12
    113c:	53                   	push   rbx
    113d:	48 83 ec 18          	sub    rsp,0x18
    1141:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    1146:	48 83 c2 1f          	add    rdx,0x1f
    114a:	48 b8 09 c9 bc f3 67 	movabs rax,0x6a09e667f3bcc909
    1151:	e6 09 6a 
    1154:	48 89 04 24          	mov    QWORD PTR [rsp],rax
    1158:	31 c0                	xor    eax,eax
    115a:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
    115f:	90                   	nop
    1160:	0f b6 7a f1          	movzx  edi,BYTE PTR [rdx-0xf]
    1164:	0f b6 72 f2          	movzx  esi,BYTE PTR [rdx-0xe]
    1168:	41 89 f5             	mov    r13d,esi
    116b:	41 c1 e5 08          	shl    r13d,0x8
    116f:	0f b6 42 f3          	movzx  eax,BYTE PTR [rdx-0xd]
    1173:	c1 e0 10             	shl    eax,0x10
    1176:	44 0f b6 62 f4       	movzx  r12d,BYTE PTR [rdx-0xc]
    117b:	41 c1 e4 18          	shl    r12d,0x18
    117f:	41 09 c4             	or     r12d,eax
    1182:	44 0f b6 42 f5       	movzx  r8d,BYTE PTR [rdx-0xb]
    1187:	49 c1 e0 20          	shl    r8,0x20
    118b:	0f b6 6a f6          	movzx  ebp,BYTE PTR [rdx-0xa]
    118f:	48 c1 e5 28          	shl    rbp,0x28
    1193:	44 0f b6 4a f7       	movzx  r9d,BYTE PTR [rdx-0x9]
    1198:	49 c1 e1 30          	shl    r9,0x30
    119c:	0f b6 42 fc          	movzx  eax,BYTE PTR [rdx-0x4]
    11a0:	c1 e0 18             	shl    eax,0x18
    11a3:	44 0f b6 7a fd       	movzx  r15d,BYTE PTR [rdx-0x3]
    11a8:	49 c1 e7 20          	shl    r15,0x20
    11ac:	0f b6 4a fe          	movzx  ecx,BYTE PTR [rdx-0x2]
    11b0:	48 c1 e1 28          	shl    rcx,0x28
    11b4:	4d 8d 34 0f          	lea    r14,[r15+rcx*1]
    11b8:	49 09 c7             	or     r15,rax
    11bb:	0f b6 42 ff          	movzx  eax,BYTE PTR [rdx-0x1]
    11bf:	48 c1 e0 30          	shl    rax,0x30
    11c3:	44 0f b6 12          	movzx  r10d,BYTE PTR [rdx]
    11c7:	49 c1 e2 38          	shl    r10,0x38
    11cb:	49 09 c2             	or     r10,rax
    11ce:	44 0f b6 5a f8       	movzx  r11d,BYTE PTR [rdx-0x8]
    11d3:	49 c1 e3 38          	shl    r11,0x38
    11d7:	41 09 fd             	or     r13d,edi
    11da:	49 09 e8             	or     r8,rbp
    11dd:	4d 09 cb             	or     r11,r9
    11e0:	49 09 e9             	or     r9,rbp
    11e3:	43 8d 2c 2c          	lea    ebp,[r12+r13*1]
    11e7:	49 09 ca             	or     r10,rcx
    11ea:	89 f9                	mov    ecx,edi
    11ec:	83 e1 3f             	and    ecx,0x3f
    11ef:	41 c1 ed 06          	shr    r13d,0x6
    11f3:	41 83 e5 1f          	and    r13d,0x1f
    11f7:	49 c1 eb 36          	shr    r11,0x36
    11fb:	4c 01 d9             	add    rcx,r11
    11fe:	4c 01 e9             	add    rcx,r13
    1201:	0f b6 42 f9          	movzx  eax,BYTE PTR [rdx-0x7]
    1205:	49 09 e8             	or     r8,rbp
    1208:	c1 ed 0b             	shr    ebp,0xb
    120b:	81 e5 ff 07 00 00    	and    ebp,0x7ff
    1211:	41 c1 ec 16          	shr    r12d,0x16
    1215:	45 0f b6 e4          	movzx  r12d,r12b
    1219:	48 01 e9             	add    rcx,rbp
    121c:	4c 01 e1             	add    rcx,r12
    121f:	44 0f b6 6a fa       	movzx  r13d,BYTE PTR [rdx-0x6]
    1224:	41 c1 e5 08          	shl    r13d,0x8
    1228:	49 c1 e8 1e          	shr    r8,0x1e
    122c:	41 81 e0 ff 3f 00 00 	and    r8d,0x3fff
    1233:	49 c1 e9 2c          	shr    r9,0x2c
    1237:	41 81 e1 ff 03 00 00 	and    r9d,0x3ff
    123e:	4d 01 c1             	add    r9,r8
    1241:	49 01 c9             	add    r9,rcx
    1244:	44 0f b6 62 fb       	movzx  r12d,BYTE PTR [rdx-0x5]
    1249:	41 c1 e4 10          	shl    r12d,0x10
    124d:	45 09 ec             	or     r12d,r13d
    1250:	41 09 c5             	or     r13d,eax
    1253:	83 e0 0f             	and    eax,0xf
    1256:	49 c1 ef 18          	shr    r15,0x18
    125a:	49 c1 ea 28          	shr    r10,0x28
    125e:	d1 ee                	shr    esi,1
    1260:	83 e6 1f             	and    esi,0x1f
    1263:	49 c1 ee 26          	shr    r14,0x26
    1267:	41 83 e6 7f          	and    r14d,0x7f
    126b:	4c 01 f8             	add    rax,r15
    126e:	4c 01 d0             	add    rax,r10
    1271:	41 c1 ec 0c          	shr    r12d,0xc
    1275:	49 01 c4             	add    r12,rax
    1278:	41 c1 ed 04          	shr    r13d,0x4
    127c:	41 0f b6 c5          	movzx  eax,r13b
    1280:	4d 01 f4             	add    r12,r14
    1283:	49 01 c4             	add    r12,rax
    1286:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    128b:	49 01 dc             	add    r12,rbx
    128e:	49 01 f4             	add    r12,rsi
    1291:	48 8d 0c 6d 00 00 00 	lea    rcx,[rbp*2+0x0]
    1298:	00 
    1299:	48 01 e9             	add    rcx,rbp
    129c:	4c 8d 2c c5 00 00 00 	lea    r13,[rax*8+0x0]
    12a3:	00 
    12a4:	49 29 c5             	sub    r13,rax
    12a7:	4b 8d 04 80          	lea    rax,[r8+r8*4]
    12ab:	49 31 cd             	xor    r13,rcx
    12ae:	49 31 c5             	xor    r13,rax
    12b1:	4b 8d 04 9b          	lea    rax,[r11+r11*4]
    12b5:	49 8d 04 43          	lea    rax,[r11+rax*2]
    12b9:	4b 8d 0c 7f          	lea    rcx,[r15+r15*2]
    12bd:	49 8d 0c 8f          	lea    rcx,[r15+rcx*4]
    12c1:	4f 8d 3c d2          	lea    r15,[r10+r10*8]
    12c5:	49 31 cf             	xor    r15,rcx
    12c8:	89 f1                	mov    ecx,esi
    12ca:	c1 e1 04             	shl    ecx,0x4
    12cd:	48 01 f1             	add    rcx,rsi
    12d0:	48 31 c1             	xor    rcx,rax
    12d3:	4c 31 f9             	xor    rcx,r15
    12d6:	4b 8d 04 f6          	lea    rax,[r14+r14*8]
    12da:	49 8d 04 46          	lea    rax,[r14+rax*2]
    12de:	48 31 c8             	xor    rax,rcx
    12e1:	4c 01 e8             	add    rax,r13
    12e4:	40 80 e7 07          	and    dil,0x7
    12e8:	8d 4f 01             	lea    ecx,[rdi+0x1]
    12eb:	c4 c2 f1 f7 cc       	shlx   rcx,r12,rcx
    12f0:	40 f6 d7             	not    dil
    12f3:	c4 c2 c3 f7 fc       	shrx   rdi,r12,rdi
    12f8:	48 09 cf             	or     rdi,rcx
    12fb:	4c 31 cf             	xor    rdi,r9
    12fe:	48 03 3c 24          	add    rdi,QWORD PTR [rsp]
    1302:	48 31 c7             	xor    rdi,rax
    1305:	49 8d 04 32          	lea    rax,[r10+rsi*1]
    1309:	4c 01 c0             	add    rax,r8
    130c:	48 01 f8             	add    rax,rdi
    130f:	45 31 da             	xor    r10d,r11d
    1312:	41 80 e2 0f          	and    r10b,0xf
    1316:	41 8d 4a 01          	lea    ecx,[r10+0x1]
    131a:	c4 e2 f1 f7 c8       	shlx   rcx,rax,rcx
    131f:	41 f6 d2             	not    r10b
    1322:	c4 e2 ab f7 c0       	shrx   rax,rax,r10
    1327:	48 09 c8             	or     rax,rcx
    132a:	48 89 04 24          	mov    QWORD PTR [rsp],rax
    132e:	48 ff c3             	inc    rbx
    1331:	48 83 c2 10          	add    rdx,0x10
    1335:	48 89 d8             	mov    rax,rbx
    1338:	48 89 5c 24 08       	mov    QWORD PTR [rsp+0x8],rbx
    133d:	48 83 fb 20          	cmp    rbx,0x20
    1341:	0f 85 19 fe ff ff    	jne    1160 <packed_header_bitfield_decode_xdp+0x60>
    1347:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    134c:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    1350:	88 02                	mov    BYTE PTR [rdx],al
    1352:	88 62 01             	mov    BYTE PTR [rdx+0x1],ah
    1355:	89 c8                	mov    eax,ecx
    1357:	c1 e8 10             	shr    eax,0x10
    135a:	88 42 02             	mov    BYTE PTR [rdx+0x2],al
    135d:	89 c8                	mov    eax,ecx
    135f:	c1 e8 18             	shr    eax,0x18
    1362:	88 42 03             	mov    BYTE PTR [rdx+0x3],al
    1365:	48 89 c8             	mov    rax,rcx
    1368:	48 c1 e8 20          	shr    rax,0x20
    136c:	88 42 04             	mov    BYTE PTR [rdx+0x4],al
    136f:	48 89 c8             	mov    rax,rcx
    1372:	48 c1 e8 28          	shr    rax,0x28
    1376:	88 42 05             	mov    BYTE PTR [rdx+0x5],al
    1379:	48 89 c8             	mov    rax,rcx
    137c:	48 c1 e8 30          	shr    rax,0x30
    1380:	88 42 06             	mov    BYTE PTR [rdx+0x6],al
    1383:	48 c1 e9 38          	shr    rcx,0x38
    1387:	88 4a 07             	mov    BYTE PTR [rdx+0x7],cl
    138a:	b8 02 00 00 00       	mov    eax,0x2
    138f:	48 83 c4 18          	add    rsp,0x18
    1393:	5b                   	pop    rbx
    1394:	41 5c                	pop    r12
    1396:	41 5d                	pop    r13
    1398:	41 5e                	pop    r14
    139a:	41 5f                	pop    r15
    139c:	5d                   	pop    rbp
    139d:	c3                   	ret

Disassembly of section .fini:

00000000000013a0 <_fini>:
    13a0:	f3 0f 1e fa          	endbr64
    13a4:	48 83 ec 08          	sub    rsp,0x8
    13a8:	48 83 c4 08          	add    rsp,0x8
    13ac:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 80 00 00 00 	sub    rsp,0x80
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 5f 00          	mov    rbx,QWORD PTR [rdi+0x0]
  24:	48 39 f3             	cmp    rbx,rsi
  27:	0f 87 be 03 00 00    	ja     0x3eb
  2d:	48 89 df             	mov    rdi,rbx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 ae 03 00 00    	ja     0x3eb
  3d:	48 89 df             	mov    rdi,rbx
  40:	48 81 c7 10 02 00 00 	add    rdi,0x210
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 9b 03 00 00    	ja     0x3eb
  50:	48 0f b6 7b 09       	movzx  rdi,BYTE PTR [rbx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 73 08       	movzx  rsi,BYTE PTR [rbx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 73 0a       	movzx  rsi,BYTE PTR [rbx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 73 0b       	movzx  rsi,BYTE PTR [rbx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 83 ff 20          	cmp    rdi,0x20
  85:	0f 85 60 03 00 00    	jne    0x3eb
  8b:	48 0f b6 7b 0d       	movzx  rdi,BYTE PTR [rbx+0xd]
  90:	48 c1 e7 08          	shl    rdi,0x8
  94:	48 0f b6 73 0c       	movzx  rsi,BYTE PTR [rbx+0xc]
  99:	48 09 f7             	or     rdi,rsi
  9c:	48 0f b6 73 0e       	movzx  rsi,BYTE PTR [rbx+0xe]
  a1:	48 c1 e6 10          	shl    rsi,0x10
  a5:	48 09 f7             	or     rdi,rsi
  a8:	48 0f b6 73 0f       	movzx  rsi,BYTE PTR [rbx+0xf]
  ad:	48 c1 e6 18          	shl    rsi,0x18
  b1:	48 09 f7             	or     rdi,rsi
  b4:	48 c1 e7 20          	shl    rdi,0x20
  b8:	48 c1 ef 20          	shr    rdi,0x20
  bc:	48 83 ff 02          	cmp    rdi,0x2
  c0:	0f 85 25 03 00 00    	jne    0x3eb
  c6:	48 b9 09 c9 bc f3 67 	movabs rcx,0x6a09e667f3bcc909
  cd:	e6 09 6a 
  d0:	45 31 f6             	xor    r14d,r14d
  d3:	48 89 5d 80          	mov    QWORD PTR [rbp-0x80],rbx
  d7:	48 83 c3 1f          	add    rbx,0x1f
  db:	48 89 4d b8          	mov    QWORD PTR [rbp-0x48],rcx
  df:	4c 89 75 d0          	mov    QWORD PTR [rbp-0x30],r14
  e3:	48 0f b6 7b f8       	movzx  rdi,BYTE PTR [rbx-0x8]
  e8:	48 c1 e7 38          	shl    rdi,0x38
  ec:	48 0f b6 73 f7       	movzx  rsi,BYTE PTR [rbx-0x9]
  f1:	48 c1 e6 30          	shl    rsi,0x30
  f5:	48 09 fe             	or     rsi,rdi
  f8:	49 89 f0             	mov    r8,rsi
  fb:	48 0f b6 7b f6       	movzx  rdi,BYTE PTR [rbx-0xa]
 100:	48 c1 e7 28          	shl    rdi,0x28
 104:	48 0f b6 43 f5       	movzx  rax,BYTE PTR [rbx-0xb]
 109:	48 c1 e0 20          	shl    rax,0x20
 10d:	48 09 f8             	or     rax,rdi
 110:	48 0f b6 7b f4       	movzx  rdi,BYTE PTR [rbx-0xc]
 115:	48 c1 e7 18          	shl    rdi,0x18
 119:	48 0f b6 53 f3       	movzx  rdx,BYTE PTR [rbx-0xd]
 11e:	48 c1 e2 10          	shl    rdx,0x10
 122:	48 09 fa             	or     rdx,rdi
 125:	48 89 55 b0          	mov    QWORD PTR [rbp-0x50],rdx
 129:	48 0f b6 7b f1       	movzx  rdi,BYTE PTR [rbx-0xf]
 12e:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
 132:	48 0f b6 73 f2       	movzx  rsi,BYTE PTR [rbx-0xe]
 137:	49 89 f6             	mov    r14,rsi
 13a:	49 c1 e6 08          	shl    r14,0x8
 13e:	49 09 fe             	or     r14,rdi
 141:	4c 09 f2             	or     rdx,r14
 144:	48 09 d0             	or     rax,rdx
 147:	48 89 45 f8          	mov    QWORD PTR [rbp-0x8],rax
 14b:	49 09 c0             	or     r8,rax
 14e:	4c 89 45 c0          	mov    QWORD PTR [rbp-0x40],r8
 152:	48 d1 ee             	shr    rsi,1
 155:	48 83 e6 1f          	and    rsi,0x1f
 159:	48 89 75 c8          	mov    QWORD PTR [rbp-0x38],rsi
 15d:	4c 89 c7             	mov    rdi,r8
 160:	48 c1 ef 36          	shr    rdi,0x36
 164:	48 89 7d e0          	mov    QWORD PTR [rbp-0x20],rdi
 168:	48 6b ff 0b          	imul   rdi,rdi,0xb
 16c:	49 89 f0             	mov    r8,rsi
 16f:	4d 6b c0 11          	imul   r8,r8,0x11
 173:	49 31 f8             	xor    r8,rdi
 176:	4d 89 c7             	mov    r15,r8
 179:	48 0f b6 73 00       	movzx  rsi,BYTE PTR [rbx+0x0]
 17e:	48 c1 e6 38          	shl    rsi,0x38
 182:	48 0f b6 7b ff       	movzx  rdi,BYTE PTR [rbx-0x1]
 187:	48 c1 e7 30          	shl    rdi,0x30
 18b:	48 09 f7             	or     rdi,rsi
 18e:	48 0f b6 73 fc       	movzx  rsi,BYTE PTR [rbx-0x4]
 193:	48 c1 e6 18          	shl    rsi,0x18
 197:	49 89 f0             	mov    r8,rsi
 19a:	4c 89 45 98          	mov    QWORD PTR [rbp-0x68],r8
 19e:	48 0f b6 4b fb       	movzx  rcx,BYTE PTR [rbx-0x5]
 1a3:	48 c1 e1 10          	shl    rcx,0x10
 1a7:	48 89 4d a0          	mov    QWORD PTR [rbp-0x60],rcx
 1ab:	48 0f b6 73 fa       	movzx  rsi,BYTE PTR [rbx-0x6]
 1b0:	48 c1 e6 08          	shl    rsi,0x8
 1b4:	48 89 75 a8          	mov    QWORD PTR [rbp-0x58],rsi
 1b8:	48 0f b6 43 f9       	movzx  rax,BYTE PTR [rbx-0x7]
 1bd:	48 89 45 90          	mov    QWORD PTR [rbp-0x70],rax
 1c1:	49 89 f5             	mov    r13,rsi
 1c4:	49 09 c5             	or     r13,rax
 1c7:	4c 89 6d f0          	mov    QWORD PTR [rbp-0x10],r13
 1cb:	48 89 ce             	mov    rsi,rcx
 1ce:	4c 09 c6             	or     rsi,r8
 1d1:	4c 09 ee             	or     rsi,r13
 1d4:	48 0f b6 4b fe       	movzx  rcx,BYTE PTR [rbx-0x2]
 1d9:	48 c1 e1 28          	shl    rcx,0x28
 1dd:	48 89 4d 88          	mov    QWORD PTR [rbp-0x78],rcx
 1e1:	48 0f b6 43 fd       	movzx  rax,BYTE PTR [rbx-0x3]
 1e6:	48 c1 e0 20          	shl    rax,0x20
 1ea:	49 89 c0             	mov    r8,rax
 1ed:	49 09 c8             	or     r8,rcx
 1f0:	4c 89 c1             	mov    rcx,r8
 1f3:	48 09 f1             	or     rcx,rsi
 1f6:	49 89 fd             	mov    r13,rdi
 1f9:	49 09 cd             	or     r13,rcx
 1fc:	49 c1 ed 28          	shr    r13,0x28
 200:	4c 89 ee             	mov    rsi,r13
 203:	48 6b f6 09          	imul   rsi,rsi,0x9
 207:	49 31 f7             	xor    r15,rsi
 20a:	4c 89 7d e8          	mov    QWORD PTR [rbp-0x18],r15
 20e:	4c 8b 7d d8          	mov    r15,QWORD PTR [rbp-0x28]
 212:	49 83 e7 3f          	and    r15,0x3f
 216:	48 8b 75 e0          	mov    rsi,QWORD PTR [rbp-0x20]
 21a:	4c 01 fe             	add    rsi,r15
 21d:	49 c1 ee 06          	shr    r14,0x6
 221:	49 83 e6 1f          	and    r14,0x1f
 225:	4c 01 f6             	add    rsi,r14
 228:	48 c1 e9 18          	shr    rcx,0x18
 22c:	48 81 e1 ff ff 00 00 	and    rcx,0xffff
 233:	48 6b c9 0d          	imul   rcx,rcx,0xd
 237:	4c 8b 7d e8          	mov    r15,QWORD PTR [rbp-0x18]
 23b:	49 31 cf             	xor    r15,rcx
 23e:	4c 8b 75 f8          	mov    r14,QWORD PTR [rbp-0x8]
 242:	49 c1 ee 1e          	shr    r14,0x1e
 246:	49 81 e6 ff 3f 00 00 	and    r14,0x3fff
 24d:	4c 89 f1             	mov    rcx,r14
 250:	48 89 4d f8          	mov    QWORD PTR [rbp-0x8],rcx
 254:	48 c1 ea 0b          	shr    rdx,0xb
 258:	48 81 e2 ff 07 00 00 	and    rdx,0x7ff
 25f:	48 01 d6             	add    rsi,rdx
 262:	48 6b d2 03          	imul   rdx,rdx,0x3
 266:	48 6b c9 05          	imul   rcx,rcx,0x5
 26a:	48 31 ca             	xor    rdx,rcx
 26d:	48 8b 4d 88          	mov    rcx,QWORD PTR [rbp-0x78]
 271:	48 09 cf             	or     rdi,rcx
 274:	48 8b 4d b0          	mov    rcx,QWORD PTR [rbp-0x50]
 278:	48 c1 e9 16          	shr    rcx,0x16
 27c:	48 81 e1 ff 00 00 00 	and    rcx,0xff
 283:	48 01 ce             	add    rsi,rcx
 286:	48 8b 4d f0          	mov    rcx,QWORD PTR [rbp-0x10]
 28a:	48 c1 e9 04          	shr    rcx,0x4
 28e:	48 81 e1 ff 00 00 00 	and    rcx,0xff
 295:	48 89 4d f0          	mov    QWORD PTR [rbp-0x10],rcx
 299:	48 6b c9 07          	imul   rcx,rcx,0x7
 29d:	48 31 ca             	xor    rdx,rcx
 2a0:	49 c1 e8 26          	shr    r8,0x26
 2a4:	49 83 e0 7f          	and    r8,0x7f
 2a8:	4c 89 c1             	mov    rcx,r8
 2ab:	48 6b c9 13          	imul   rcx,rcx,0x13
 2af:	49 31 cf             	xor    r15,rcx
 2b2:	48 c1 ef 28          	shr    rdi,0x28
 2b6:	48 8b 4d 90          	mov    rcx,QWORD PTR [rbp-0x70]
 2ba:	48 83 e1 0f          	and    rcx,0xf
 2be:	48 01 cf             	add    rdi,rcx
 2c1:	48 8b 4d 98          	mov    rcx,QWORD PTR [rbp-0x68]
 2c5:	48 09 c8             	or     rax,rcx
 2c8:	48 c1 e8 18          	shr    rax,0x18
 2cc:	48 01 c7             	add    rdi,rax
 2cf:	48 8b 4d a0          	mov    rcx,QWORD PTR [rbp-0x60]
 2d3:	48 8b 45 a8          	mov    rax,QWORD PTR [rbp-0x58]
 2d7:	48 09 c1             	or     rcx,rax
 2da:	48 c1 e9 0c          	shr    rcx,0xc
 2de:	48 01 cf             	add    rdi,rcx
 2e1:	4c 01 c7             	add    rdi,r8
 2e4:	4c 8b 75 d0          	mov    r14,QWORD PTR [rbp-0x30]
 2e8:	48 8b 4d f0          	mov    rcx,QWORD PTR [rbp-0x10]
 2ec:	48 01 cf             	add    rdi,rcx
 2ef:	49 01 d7             	add    r15,rdx
 2f2:	4c 89 7d e8          	mov    QWORD PTR [rbp-0x18],r15
 2f6:	4c 8b 7d f8          	mov    r15,QWORD PTR [rbp-0x8]
 2fa:	4c 01 fe             	add    rsi,r15
 2fd:	48 8b 55 c0          	mov    rdx,QWORD PTR [rbp-0x40]
 301:	48 c1 ea 2c          	shr    rdx,0x2c
 305:	48 81 e2 ff 03 00 00 	and    rdx,0x3ff
 30c:	48 01 d6             	add    rsi,rdx
 30f:	48 8b 55 d8          	mov    rdx,QWORD PTR [rbp-0x28]
 313:	48 83 e2 07          	and    rdx,0x7
 317:	48 89 d1             	mov    rcx,rdx
 31a:	48 83 c1 01          	add    rcx,0x1
 31e:	48 83 f2 3f          	xor    rdx,0x3f
 322:	48 89 d0             	mov    rax,rdx
 325:	4c 8b 45 c8          	mov    r8,QWORD PTR [rbp-0x38]
 329:	4c 01 c7             	add    rdi,r8
 32c:	4c 89 f2             	mov    rdx,r14
 32f:	48 01 fa             	add    rdx,rdi
 332:	48 89 d7             	mov    rdi,rdx
 335:	c4 e2 fb f7 ff       	shrx   rdi,rdi,rax
 33a:	48 d3 e2             	shl    rdx,cl
 33d:	48 09 fa             	or     rdx,rdi
 340:	4c 89 ef             	mov    rdi,r13
 343:	48 8b 4d e0          	mov    rcx,QWORD PTR [rbp-0x20]
 347:	48 31 cf             	xor    rdi,rcx
 34a:	4d 01 c5             	add    r13,r8
 34d:	48 31 f2             	xor    rdx,rsi
 350:	4d 01 fd             	add    r13,r15
 353:	48 8b 75 b8          	mov    rsi,QWORD PTR [rbp-0x48]
 357:	48 01 f2             	add    rdx,rsi
 35a:	48 8b 75 e8          	mov    rsi,QWORD PTR [rbp-0x18]
 35e:	48 31 f2             	xor    rdx,rsi
 361:	49 01 d5             	add    r13,rdx
 364:	48 83 e7 0f          	and    rdi,0xf
 368:	48 89 fe             	mov    rsi,rdi
 36b:	48 83 c6 01          	add    rsi,0x1
 36f:	48 83 f7 3f          	xor    rdi,0x3f
 373:	4c 89 ea             	mov    rdx,r13
 376:	c4 e2 c3 f7 d2       	shrx   rdx,rdx,rdi
 37b:	c4 42 c9 f7 ed       	shlx   r13,r13,rsi
 380:	48 83 c3 10          	add    rbx,0x10
 384:	4c 89 e9             	mov    rcx,r13
 387:	48 09 d1             	or     rcx,rdx
 38a:	49 83 c6 01          	add    r14,0x1
 38e:	49 83 fe 20          	cmp    r14,0x20
 392:	74 05                	je     0x399
 394:	e9 42 fd ff ff       	jmp    0xdb
 399:	4c 89 ef             	mov    rdi,r13
 39c:	48 c1 ef 38          	shr    rdi,0x38
 3a0:	48 8b 75 80          	mov    rsi,QWORD PTR [rbp-0x80]
 3a4:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 3a8:	4c 89 ef             	mov    rdi,r13
 3ab:	48 c1 ef 30          	shr    rdi,0x30
 3af:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 3b3:	4c 89 ef             	mov    rdi,r13
 3b6:	48 c1 ef 28          	shr    rdi,0x28
 3ba:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 3be:	4c 89 ef             	mov    rdi,r13
 3c1:	48 c1 ef 20          	shr    rdi,0x20
 3c5:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 3c9:	4c 89 ef             	mov    rdi,r13
 3cc:	48 c1 ef 18          	shr    rdi,0x18
 3d0:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 3d4:	49 c1 ed 10          	shr    r13,0x10
 3d8:	44 88 6e 02          	mov    BYTE PTR [rsi+0x2],r13b
 3dc:	88 4e 00             	mov    BYTE PTR [rsi+0x0],cl
 3df:	48 c1 e9 08          	shr    rcx,0x8
 3e3:	88 4e 01             	mov    BYTE PTR [rsi+0x1],cl
 3e6:	b8 02 00 00 00       	mov    eax,0x2
 3eb:	41 5f                	pop    r15
 3ed:	41 5e                	pop    r14
 3ef:	41 5d                	pop    r13
 3f1:	5b                   	pop    rbx
 3f2:	c9                   	leave
 3f3:	e9 54 2c a1 e1       	jmp    0xffffffffe1a1304c
```

## llvmbpf JIT ASM
```asm
not captured
```
