# otel_stack_frame_unwind_scan

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <otel_stack_frame_unwind_scan_xdp>:
    1100:	48 8b 17             	mov    rdx,QWORD PTR [rdi]
    1103:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
    1107:	48 89 d6             	mov    rsi,rdx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 ce             	cmp    rsi,rcx
    110f:	76 01                	jbe    1112 <otel_stack_frame_unwind_scan_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7e 08          	lea    rdi,[rsi+0x8]
    1116:	48 39 cf             	cmp    rdi,rcx
    1119:	77 f6                	ja     1111 <otel_stack_frame_unwind_scan_xdp+0x11>
    111b:	48 8d be 50 02 00 00 	lea    rdi,[rsi+0x250]
    1122:	48 39 cf             	cmp    rdi,rcx
    1125:	77 ea                	ja     1111 <otel_stack_frame_unwind_scan_xdp+0x11>
    1127:	83 7e 08 18          	cmp    DWORD PTR [rsi+0x8],0x18
    112b:	75 e4                	jne    1111 <otel_stack_frame_unwind_scan_xdp+0x11>
    112d:	83 7e 0c 18          	cmp    DWORD PTR [rsi+0xc],0x18
    1131:	75 de                	jne    1111 <otel_stack_frame_unwind_scan_xdp+0x11>
    1133:	55                   	push   rbp
    1134:	41 57                	push   r15
    1136:	41 56                	push   r14
    1138:	41 54                	push   r12
    113a:	53                   	push   rbx
    113b:	48 83 c6 27          	add    rsi,0x27
    113f:	48 b8 00 00 00 00 01 	movabs rax,0x100000000
    1146:	00 00 00 
    1149:	49 b9 c3 4c 37 75 cc 	movabs r9,0x589965cc75374cc3
    1150:	65 99 58 
    1153:	31 ff                	xor    edi,edi
    1155:	41 b8 08 00 00 00    	mov    r8d,0x8
    115b:	eb 1e                	jmp    117b <otel_stack_frame_unwind_scan_xdp+0x7b>
    115d:	0f 1f 00             	nop    DWORD PTR [rax]
    1160:	48 c1 e1 30          	shl    rcx,0x30
    1164:	48 09 d9             	or     rcx,rbx
    1167:	49 31 c9             	xor    r9,rcx
    116a:	48 ff c7             	inc    rdi
    116d:	48 83 c6 18          	add    rsi,0x18
    1171:	48 83 ff 18          	cmp    rdi,0x18
    1175:	0f 84 08 01 00 00    	je     1283 <otel_stack_frame_unwind_scan_xdp+0x183>
    117b:	48 8b 5e e9          	mov    rbx,QWORD PTR [rsi-0x17]
    117f:	8b 6e f1             	mov    ebp,DWORD PTR [rsi-0xf]
    1182:	44 8b 76 f5          	mov    r14d,DWORD PTR [rsi-0xb]
    1186:	44 0f b7 5e f9       	movzx  r11d,WORD PTR [rsi-0x7]
    118b:	0f b7 4e fb          	movzx  ecx,WORD PTR [rsi-0x5]
    118f:	44 8b 56 fd          	mov    r10d,DWORD PTR [rsi-0x3]
    1193:	83 f9 01             	cmp    ecx,0x1
    1196:	7f 28                	jg     11c0 <otel_stack_frame_unwind_scan_xdp+0xc0>
    1198:	85 c9                	test   ecx,ecx
    119a:	74 3e                	je     11da <otel_stack_frame_unwind_scan_xdp+0xda>
    119c:	83 f9 01             	cmp    ecx,0x1
    119f:	75 bf                	jne    1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    11a1:	41 bf 35 00 00 00    	mov    r15d,0x35
    11a7:	81 fd 00 10 00 00    	cmp    ebp,0x1000
    11ad:	76 50                	jbe    11ff <otel_stack_frame_unwind_scan_xdp+0xff>
    11af:	eb af                	jmp    1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    11b1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    11b8:	0f 1f 84 00 00 00 00 
    11bf:	00 
    11c0:	83 f9 02             	cmp    ecx,0x2
    11c3:	74 28                	je     11ed <otel_stack_frame_unwind_scan_xdp+0xed>
    11c5:	83 f9 03             	cmp    ecx,0x3
    11c8:	75 96                	jne    1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    11ca:	41 bf 89 00 00 00    	mov    r15d,0x89
    11d0:	81 fd 00 10 00 00    	cmp    ebp,0x1000
    11d6:	76 27                	jbe    11ff <otel_stack_frame_unwind_scan_xdp+0xff>
    11d8:	eb 86                	jmp    1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    11da:	41 bf 21 00 00 00    	mov    r15d,0x21
    11e0:	81 fd 00 10 00 00    	cmp    ebp,0x1000
    11e6:	76 17                	jbe    11ff <otel_stack_frame_unwind_scan_xdp+0xff>
    11e8:	e9 73 ff ff ff       	jmp    1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    11ed:	41 bf 55 00 00 00    	mov    r15d,0x55
    11f3:	81 fd 00 10 00 00    	cmp    ebp,0x1000
    11f9:	0f 87 61 ff ff ff    	ja     1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    11ff:	41 81 fe 01 20 00 00 	cmp    r14d,0x2001
    1206:	0f 83 54 ff ff ff    	jae    1160 <otel_stack_frame_unwind_scan_xdp+0x60>
    120c:	41 f6 c3 01          	test   r11b,0x1
    1210:	45 89 f4             	mov    r12d,r14d
    1213:	45 0f 44 e0          	cmove  r12d,r8d
    1217:	41 01 ec             	add    r12d,ebp
    121a:	4c 01 e0             	add    rax,r12
    121d:	4d 89 d4             	mov    r12,r10
    1220:	49 c1 e4 20          	shl    r12,0x20
    1224:	4d 09 e7             	or     r15,r12
    1227:	4c 31 fb             	xor    rbx,r15
    122a:	48 31 c3             	xor    rbx,rax
    122d:	41 f6 c3 02          	test   r11b,0x2
    1231:	74 05                	je     1238 <otel_stack_frame_unwind_scan_xdp+0x138>
    1233:	fe c1                	inc    cl
    1235:	48 d3 c3             	rol    rbx,cl
    1238:	44 89 f1             	mov    ecx,r14d
    123b:	48 c1 e1 18          	shl    rcx,0x18
    123f:	41 89 ee             	mov    r14d,ebp
    1242:	49 31 ce             	xor    r14,rcx
    1245:	41 f6 c3 04          	test   r11b,0x4
    1249:	b9 00 00 00 00       	mov    ecx,0x0
    124e:	49 0f 45 ce          	cmovne rcx,r14
    1252:	48 01 d9             	add    rcx,rbx
    1255:	89 fb                	mov    ebx,edi
    1257:	80 e3 07             	and    bl,0x7
    125a:	44 8d 73 01          	lea    r14d,[rbx+0x1]
    125e:	c4 62 89 f7 f1       	shlx   r14,rcx,r14
    1263:	f6 d3                	not    bl
    1265:	c4 e2 e3 f7 c9       	shrx   rcx,rcx,rbx
    126a:	4c 09 f1             	or     rcx,r14
    126d:	4c 01 c9             	add    rcx,r9
    1270:	45 0f b7 cb          	movzx  r9d,r11w
    1274:	49 c1 e1 28          	shl    r9,0x28
    1278:	4d 09 ca             	or     r10,r9
    127b:	4d 89 d1             	mov    r9,r10
    127e:	e9 e4 fe ff ff       	jmp    1167 <otel_stack_frame_unwind_scan_xdp+0x67>
    1283:	4c 89 0a             	mov    QWORD PTR [rdx],r9
    1286:	b8 02 00 00 00       	mov    eax,0x2
    128b:	5b                   	pop    rbx
    128c:	41 5c                	pop    r12
    128e:	41 5e                	pop    r14
    1290:	41 5f                	pop    r15
    1292:	5d                   	pop    rbp
    1293:	c3                   	ret

Disassembly of section .fini:

0000000000001294 <_fini>:
    1294:	f3 0f 1e fa          	endbr64
    1298:	48 83 ec 08          	sub    rsp,0x8
    129c:	48 83 c4 08          	add    rsp,0x8
    12a0:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 70 00 00 00 	sub    rsp,0x70
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 57 00          	mov    rdx,QWORD PTR [rdi+0x0]
  24:	48 39 f2             	cmp    rdx,rsi
  27:	0f 87 f3 03 00 00    	ja     0x420
  2d:	48 89 d7             	mov    rdi,rdx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 e3 03 00 00    	ja     0x420
  3d:	48 89 d7             	mov    rdi,rdx
  40:	48 81 c7 50 02 00 00 	add    rdi,0x250
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 d0 03 00 00    	ja     0x420
  50:	48 0f b6 7a 09       	movzx  rdi,BYTE PTR [rdx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 72 08       	movzx  rsi,BYTE PTR [rdx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 72 0a       	movzx  rsi,BYTE PTR [rdx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 72 0b       	movzx  rsi,BYTE PTR [rdx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 83 ff 18          	cmp    rdi,0x18
  85:	0f 85 95 03 00 00    	jne    0x420
  8b:	48 0f b6 7a 0d       	movzx  rdi,BYTE PTR [rdx+0xd]
  90:	48 c1 e7 08          	shl    rdi,0x8
  94:	48 0f b6 72 0c       	movzx  rsi,BYTE PTR [rdx+0xc]
  99:	48 09 f7             	or     rdi,rsi
  9c:	48 0f b6 72 0e       	movzx  rsi,BYTE PTR [rdx+0xe]
  a1:	48 c1 e6 10          	shl    rsi,0x10
  a5:	48 09 f7             	or     rdi,rsi
  a8:	48 0f b6 72 0f       	movzx  rsi,BYTE PTR [rdx+0xf]
  ad:	48 c1 e6 18          	shl    rsi,0x18
  b1:	48 09 f7             	or     rdi,rsi
  b4:	48 c1 e7 20          	shl    rdi,0x20
  b8:	48 c1 ef 20          	shr    rdi,0x20
  bc:	48 83 ff 18          	cmp    rdi,0x18
  c0:	0f 85 5a 03 00 00    	jne    0x420
  c6:	48 bf 00 00 00 00 01 	movabs rdi,0x100000000
  cd:	00 00 00 
  d0:	48 89 7d 98          	mov    QWORD PTR [rbp-0x68],rdi
  d4:	48 bf c3 4c 37 75 cc 	movabs rdi,0x589965cc75374cc3
  db:	65 99 58 
  de:	45 31 c0             	xor    r8d,r8d
  e1:	48 89 55 90          	mov    QWORD PTR [rbp-0x70],rdx
  e5:	48 89 d1             	mov    rcx,rdx
  e8:	48 83 c1 13          	add    rcx,0x13
  ec:	e9 8a 00 00 00       	jmp    0x17b
  f1:	48 c1 e7 08          	shl    rdi,0x8
  f5:	48 8b 75 e8          	mov    rsi,QWORD PTR [rbp-0x18]
  f9:	48 09 f7             	or     rdi,rsi
  fc:	48 c1 e2 10          	shl    rdx,0x10
 100:	48 09 d7             	or     rdi,rdx
 103:	48 c1 e3 18          	shl    rbx,0x18
 107:	48 09 df             	or     rdi,rbx
 10a:	48 89 fa             	mov    rdx,rdi
 10d:	48 c1 e2 20          	shl    rdx,0x20
 111:	48 c1 ea 20          	shr    rdx,0x20
 115:	48 81 fa 00 10 00 00 	cmp    rdx,0x1000
 11c:	77 36                	ja     0x154
 11e:	49 c1 e5 08          	shl    r13,0x8
 122:	48 8b 75 e0          	mov    rsi,QWORD PTR [rbp-0x20]
 126:	49 09 f5             	or     r13,rsi
 129:	49 c1 e0 10          	shl    r8,0x10
 12d:	4d 09 c5             	or     r13,r8
 130:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
 134:	48 c1 e6 18          	shl    rsi,0x18
 138:	49 09 f5             	or     r13,rsi
 13b:	4c 89 ee             	mov    rsi,r13
 13e:	48 c1 e6 20          	shl    rsi,0x20
 142:	48 c1 ee 20          	shr    rsi,0x20
 146:	ba 01 20 00 00       	mov    edx,0x2001
 14b:	48 39 f2             	cmp    rdx,rsi
 14e:	0f 87 4d 01 00 00    	ja     0x2a1
 154:	49 c1 e6 30          	shl    r14,0x30
 158:	4d 09 fe             	or     r14,r15
 15b:	4c 8b 45 f8          	mov    r8,QWORD PTR [rbp-0x8]
 15f:	48 8b 7d f0          	mov    rdi,QWORD PTR [rbp-0x10]
 163:	49 31 fe             	xor    r14,rdi
 166:	48 83 c1 18          	add    rcx,0x18
 16a:	49 83 c0 01          	add    r8,0x1
 16e:	4c 89 f7             	mov    rdi,r14
 171:	49 83 f8 18          	cmp    r8,0x18
 175:	0f 84 4e 02 00 00    	je     0x3c9
 17b:	48 89 7d f0          	mov    QWORD PTR [rbp-0x10],rdi
 17f:	4c 89 45 f8          	mov    QWORD PTR [rbp-0x8],r8
 183:	48 0f b6 79 fe       	movzx  rdi,BYTE PTR [rcx-0x2]
 188:	48 c1 e7 08          	shl    rdi,0x8
 18c:	48 0f b6 71 fd       	movzx  rsi,BYTE PTR [rcx-0x3]
 191:	48 09 f7             	or     rdi,rsi
 194:	48 0f b6 71 ff       	movzx  rsi,BYTE PTR [rcx-0x1]
 199:	48 c1 e6 10          	shl    rsi,0x10
 19d:	48 09 fe             	or     rsi,rdi
 1a0:	48 0f b6 79 00       	movzx  rdi,BYTE PTR [rcx+0x0]
 1a5:	48 c1 e7 18          	shl    rdi,0x18
 1a9:	48 09 f7             	or     rdi,rsi
 1ac:	48 0f b6 71 01       	movzx  rsi,BYTE PTR [rcx+0x1]
 1b1:	48 c1 e6 20          	shl    rsi,0x20
 1b5:	48 09 fe             	or     rsi,rdi
 1b8:	4c 0f b6 69 0a       	movzx  r13,BYTE PTR [rcx+0xa]
 1bd:	48 0f b6 79 09       	movzx  rdi,BYTE PTR [rcx+0x9]
 1c2:	48 89 7d e0          	mov    QWORD PTR [rbp-0x20],rdi
 1c6:	4c 0f b6 41 02       	movzx  r8,BYTE PTR [rcx+0x2]
 1cb:	49 c1 e0 28          	shl    r8,0x28
 1cf:	49 09 f0             	or     r8,rsi
 1d2:	48 0f b6 79 12       	movzx  rdi,BYTE PTR [rcx+0x12]
 1d7:	48 89 7d c8          	mov    QWORD PTR [rbp-0x38],rdi
 1db:	48 0f b6 79 11       	movzx  rdi,BYTE PTR [rcx+0x11]
 1e0:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
 1e4:	48 0f b6 79 06       	movzx  rdi,BYTE PTR [rcx+0x6]
 1e9:	48 0f b6 71 05       	movzx  rsi,BYTE PTR [rcx+0x5]
 1ee:	48 89 75 e8          	mov    QWORD PTR [rbp-0x18],rsi
 1f2:	48 0f b6 51 07       	movzx  rdx,BYTE PTR [rcx+0x7]
 1f7:	48 0f b6 71 13       	movzx  rsi,BYTE PTR [rcx+0x13]
 1fc:	48 89 75 b0          	mov    QWORD PTR [rbp-0x50],rsi
 200:	48 0f b6 41 03       	movzx  rax,BYTE PTR [rcx+0x3]
 205:	48 c1 e0 30          	shl    rax,0x30
 209:	4c 09 c0             	or     rax,r8
 20c:	4c 0f b6 41 0b       	movzx  r8,BYTE PTR [rcx+0xb]
 211:	48 0f b6 71 0e       	movzx  rsi,BYTE PTR [rcx+0xe]
 216:	48 89 75 c0          	mov    QWORD PTR [rbp-0x40],rsi
 21a:	48 0f b6 71 0d       	movzx  rsi,BYTE PTR [rcx+0xd]
 21f:	48 89 75 a0          	mov    QWORD PTR [rbp-0x60],rsi
 223:	48 0f b6 71 14       	movzx  rsi,BYTE PTR [rcx+0x14]
 228:	48 89 75 a8          	mov    QWORD PTR [rbp-0x58],rsi
 22c:	48 0f b6 71 0c       	movzx  rsi,BYTE PTR [rcx+0xc]
 231:	48 89 75 d8          	mov    QWORD PTR [rbp-0x28],rsi
 235:	48 0f b6 59 08       	movzx  rbx,BYTE PTR [rcx+0x8]
 23a:	4c 0f b6 79 04       	movzx  r15,BYTE PTR [rcx+0x4]
 23f:	49 c1 e7 38          	shl    r15,0x38
 243:	49 09 c7             	or     r15,rax
 246:	48 0f b6 41 0f       	movzx  rax,BYTE PTR [rcx+0xf]
 24b:	4c 0f b6 71 10       	movzx  r14,BYTE PTR [rcx+0x10]
 250:	49 c1 e6 08          	shl    r14,0x8
 254:	49 09 c6             	or     r14,rax
 257:	4c 89 f0             	mov    rax,r14
 25a:	48 25 ff ff 00 00    	and    rax,0xffff
 260:	48 83 f8 01          	cmp    rax,0x1
 264:	7f 1c                	jg     0x282
 266:	be 21 00 00 00       	mov    esi,0x21
 26b:	48 89 75 d0          	mov    QWORD PTR [rbp-0x30],rsi
 26f:	48 85 c0             	test   rax,rax
 272:	0f 84 79 fe ff ff    	je     0xf1
 278:	be 35 00 00 00       	mov    esi,0x35
 27d:	e9 3e 01 00 00       	jmp    0x3c0
 282:	48 83 f8 02          	cmp    rax,0x2
 286:	0f 84 2f 01 00 00    	je     0x3bb
 28c:	48 83 f8 03          	cmp    rax,0x3
 290:	74 05                	je     0x297
 292:	e9 bd fe ff ff       	jmp    0x154
 297:	be 89 00 00 00       	mov    esi,0x89
 29c:	e9 1f 01 00 00       	jmp    0x3c0
 2a1:	48 8b 5d c0          	mov    rbx,QWORD PTR [rbp-0x40]
 2a5:	48 c1 e3 08          	shl    rbx,0x8
 2a9:	48 8b 75 a0          	mov    rsi,QWORD PTR [rbp-0x60]
 2ad:	48 09 f3             	or     rbx,rsi
 2b0:	48 89 da             	mov    rdx,rbx
 2b3:	48 83 e2 01          	and    rdx,0x1
 2b7:	be 08 00 00 00       	mov    esi,0x8
 2bc:	48 85 d2             	test   rdx,rdx
 2bf:	74 03                	je     0x2c4
 2c1:	4c 89 ee             	mov    rsi,r13
 2c4:	48 8b 45 c8          	mov    rax,QWORD PTR [rbp-0x38]
 2c8:	48 c1 e0 08          	shl    rax,0x8
 2cc:	48 8b 55 b8          	mov    rdx,QWORD PTR [rbp-0x48]
 2d0:	48 09 d0             	or     rax,rdx
 2d3:	48 8b 55 b0          	mov    rdx,QWORD PTR [rbp-0x50]
 2d7:	48 c1 e2 10          	shl    rdx,0x10
 2db:	48 09 d0             	or     rax,rdx
 2de:	48 8b 55 a8          	mov    rdx,QWORD PTR [rbp-0x58]
 2e2:	48 c1 e2 18          	shl    rdx,0x18
 2e6:	48 09 d0             	or     rax,rdx
 2e9:	48 01 fe             	add    rsi,rdi
 2ec:	48 c1 e6 20          	shl    rsi,0x20
 2f0:	48 c1 ee 20          	shr    rsi,0x20
 2f4:	48 8b 55 98          	mov    rdx,QWORD PTR [rbp-0x68]
 2f8:	48 01 f2             	add    rdx,rsi
 2fb:	48 89 c6             	mov    rsi,rax
 2fe:	48 c1 e6 20          	shl    rsi,0x20
 302:	4c 8b 45 d0          	mov    r8,QWORD PTR [rbp-0x30]
 306:	49 09 f0             	or     r8,rsi
 309:	4d 31 c7             	xor    r15,r8
 30c:	48 89 55 98          	mov    QWORD PTR [rbp-0x68],rdx
 310:	49 31 d7             	xor    r15,rdx
 313:	48 89 de             	mov    rsi,rbx
 316:	48 83 e6 02          	and    rsi,0x2
 31a:	4c 8b 45 f8          	mov    r8,QWORD PTR [rbp-0x8]
 31e:	48 85 f6             	test   rsi,rsi
 321:	74 26                	je     0x349
 323:	49 83 c6 01          	add    r14,0x1
 327:	49 81 e6 ff ff 00 00 	and    r14,0xffff
 32e:	be 40 00 00 00       	mov    esi,0x40
 333:	4c 29 f6             	sub    rsi,r14
 336:	4c 89 fa             	mov    rdx,r15
 339:	c4 e2 89 f7 d2       	shlx   rdx,rdx,r14
 33e:	c4 42 cb f7 ff       	shrx   r15,r15,rsi
 343:	4c 09 fa             	or     rdx,r15
 346:	49 89 d7             	mov    r15,rdx
 349:	48 89 de             	mov    rsi,rbx
 34c:	48 81 e6 ff ff 00 00 	and    rsi,0xffff
 353:	48 83 e6 04          	and    rsi,0x4
 357:	48 85 f6             	test   rsi,rsi
 35a:	74 1d                	je     0x379
 35c:	48 c1 e7 20          	shl    rdi,0x20
 360:	48 c1 ef 20          	shr    rdi,0x20
 364:	49 c1 e5 20          	shl    r13,0x20
 368:	49 c1 ed 20          	shr    r13,0x20
 36c:	49 c1 e5 18          	shl    r13,0x18
 370:	49 31 fd             	xor    r13,rdi
 373:	4d 01 fd             	add    r13,r15
 376:	4d 89 ef             	mov    r15,r13
 379:	4c 89 c7             	mov    rdi,r8
 37c:	48 83 e7 07          	and    rdi,0x7
 380:	48 89 fe             	mov    rsi,rdi
 383:	48 83 f6 3f          	xor    rsi,0x3f
 387:	4c 89 fa             	mov    rdx,r15
 38a:	c4 e2 cb f7 d2       	shrx   rdx,rdx,rsi
 38f:	48 83 c7 01          	add    rdi,0x1
 393:	c4 42 c1 f7 ff       	shlx   r15,r15,rdi
 398:	49 09 d7             	or     r15,rdx
 39b:	48 8b 7d f0          	mov    rdi,QWORD PTR [rbp-0x10]
 39f:	49 01 ff             	add    r15,rdi
 3a2:	48 81 e3 ff ff 00 00 	and    rbx,0xffff
 3a9:	48 c1 e3 28          	shl    rbx,0x28
 3ad:	48 09 d8             	or     rax,rbx
 3b0:	48 89 c7             	mov    rdi,rax
 3b3:	4d 89 fe             	mov    r14,r15
 3b6:	e9 a8 fd ff ff       	jmp    0x163
 3bb:	be 55 00 00 00       	mov    esi,0x55
 3c0:	48 89 75 d0          	mov    QWORD PTR [rbp-0x30],rsi
 3c4:	e9 28 fd ff ff       	jmp    0xf1
 3c9:	4c 89 f7             	mov    rdi,r14
 3cc:	48 c1 ef 38          	shr    rdi,0x38
 3d0:	48 8b 75 90          	mov    rsi,QWORD PTR [rbp-0x70]
 3d4:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 3d8:	4c 89 f7             	mov    rdi,r14
 3db:	48 c1 ef 30          	shr    rdi,0x30
 3df:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 3e3:	4c 89 f7             	mov    rdi,r14
 3e6:	48 c1 ef 28          	shr    rdi,0x28
 3ea:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 3ee:	4c 89 f7             	mov    rdi,r14
 3f1:	48 c1 ef 20          	shr    rdi,0x20
 3f5:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 3f9:	4c 89 f7             	mov    rdi,r14
 3fc:	48 c1 ef 18          	shr    rdi,0x18
 400:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 404:	4c 89 f7             	mov    rdi,r14
 407:	48 c1 ef 10          	shr    rdi,0x10
 40b:	40 88 7e 02          	mov    BYTE PTR [rsi+0x2],dil
 40f:	44 88 76 00          	mov    BYTE PTR [rsi+0x0],r14b
 413:	49 c1 ee 08          	shr    r14,0x8
 417:	44 88 76 01          	mov    BYTE PTR [rsi+0x1],r14b
 41b:	b8 02 00 00 00       	mov    eax,0x2
 420:	41 5f                	pop    r15
 422:	41 5e                	pop    r14
 424:	41 5d                	pop    r13
 426:	5b                   	pop    rbx
 427:	c9                   	leave
 428:	e9 2b 2c a1 e1       	jmp    0xffffffffe1a13058
```

## llvmbpf JIT ASM
```asm
not captured
```
