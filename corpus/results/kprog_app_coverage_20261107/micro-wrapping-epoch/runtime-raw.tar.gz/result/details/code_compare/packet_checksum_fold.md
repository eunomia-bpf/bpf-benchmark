# packet_checksum_fold

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <packet_checksum_fold_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <packet_checksum_fold_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <packet_checksum_fold_xdp+0x11>
    111b:	48 8d ba 10 04 00 00 	lea    rdi,[rdx+0x410]
    1122:	48 39 f7             	cmp    rdi,rsi
    1125:	77 ea                	ja     1111 <packet_checksum_fold_xdp+0x11>
    1127:	83 7a 08 20          	cmp    DWORD PTR [rdx+0x8],0x20
    112b:	75 e4                	jne    1111 <packet_checksum_fold_xdp+0x11>
    112d:	81 7a 0c 00 02 00 00 	cmp    DWORD PTR [rdx+0xc],0x200
    1134:	75 db                	jne    1111 <packet_checksum_fold_xdp+0x11>
    1136:	31 c0                	xor    eax,eax
    1138:	31 f6                	xor    esi,esi
    113a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    1140:	31 ff                	xor    edi,edi
    1142:	45 31 c0             	xor    r8d,r8d
    1145:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    114c:	00 00 00 00 
    1150:	44 0f b7 4c 7a 10    	movzx  r9d,WORD PTR [rdx+rdi*2+0x10]
    1156:	45 01 c1             	add    r9d,r8d
    1159:	45 0f b7 c1          	movzx  r8d,r9w
    115d:	41 c1 e9 10          	shr    r9d,0x10
    1161:	45 01 c1             	add    r9d,r8d
    1164:	44 0f b7 44 7a 12    	movzx  r8d,WORD PTR [rdx+rdi*2+0x12]
    116a:	45 01 c8             	add    r8d,r9d
    116d:	45 0f b7 c8          	movzx  r9d,r8w
    1171:	41 c1 e8 10          	shr    r8d,0x10
    1175:	45 01 c8             	add    r8d,r9d
    1178:	44 0f b7 4c 7a 14    	movzx  r9d,WORD PTR [rdx+rdi*2+0x14]
    117e:	45 01 c1             	add    r9d,r8d
    1181:	45 0f b7 c1          	movzx  r8d,r9w
    1185:	41 c1 e9 10          	shr    r9d,0x10
    1189:	45 01 c1             	add    r9d,r8d
    118c:	44 0f b7 44 7a 16    	movzx  r8d,WORD PTR [rdx+rdi*2+0x16]
    1192:	45 01 c8             	add    r8d,r9d
    1195:	45 0f b7 c8          	movzx  r9d,r8w
    1199:	41 c1 e8 10          	shr    r8d,0x10
    119d:	45 01 c8             	add    r8d,r9d
    11a0:	48 83 c7 04          	add    rdi,0x4
    11a4:	48 81 ff 00 02 00 00 	cmp    rdi,0x200
    11ab:	75 a3                	jne    1150 <packet_checksum_fold_xdp+0x50>
    11ad:	44 89 c7             	mov    edi,r8d
    11b0:	c1 ef 10             	shr    edi,0x10
    11b3:	44 01 c7             	add    edi,r8d
    11b6:	f7 d7                	not    edi
    11b8:	0f b7 ff             	movzx  edi,di
    11bb:	41 89 c0             	mov    r8d,eax
    11be:	41 c1 e0 04          	shl    r8d,0x4
    11c2:	c4 e2 b9 f7 ff       	shlx   rdi,rdi,r8
    11c7:	48 31 fe             	xor    rsi,rdi
    11ca:	ff c0                	inc    eax
    11cc:	83 f8 20             	cmp    eax,0x20
    11cf:	0f 85 6b ff ff ff    	jne    1140 <packet_checksum_fold_xdp+0x40>
    11d5:	48 89 31             	mov    QWORD PTR [rcx],rsi
    11d8:	b8 02 00 00 00       	mov    eax,0x2
    11dd:	c3                   	ret

Disassembly of section .fini:

00000000000011e0 <_fini>:
    11e0:	f3 0f 1e fa          	endbr64
    11e4:	48 83 ec 08          	sub    rsp,0x8
    11e8:	48 83 c4 08          	add    rsp,0x8
    11ec:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	53                   	push   rbx
   d:	41 55                	push   r13
   f:	31 c0                	xor    eax,eax
  11:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  15:	48 8b 7f 00          	mov    rdi,QWORD PTR [rdi+0x0]
  19:	48 39 f7             	cmp    rdi,rsi
  1c:	0f 87 81 01 00 00    	ja     0x1a3
  22:	48 89 fa             	mov    rdx,rdi
  25:	48 83 c2 08          	add    rdx,0x8
  29:	48 39 f2             	cmp    rdx,rsi
  2c:	0f 87 71 01 00 00    	ja     0x1a3
  32:	48 89 fa             	mov    rdx,rdi
  35:	48 81 c2 10 04 00 00 	add    rdx,0x410
  3c:	48 39 f2             	cmp    rdx,rsi
  3f:	0f 87 5e 01 00 00    	ja     0x1a3
  45:	48 0f b6 77 09       	movzx  rsi,BYTE PTR [rdi+0x9]
  4a:	48 c1 e6 08          	shl    rsi,0x8
  4e:	48 0f b6 57 08       	movzx  rdx,BYTE PTR [rdi+0x8]
  53:	48 09 d6             	or     rsi,rdx
  56:	48 0f b6 57 0a       	movzx  rdx,BYTE PTR [rdi+0xa]
  5b:	48 c1 e2 10          	shl    rdx,0x10
  5f:	48 09 d6             	or     rsi,rdx
  62:	48 0f b6 57 0b       	movzx  rdx,BYTE PTR [rdi+0xb]
  67:	48 c1 e2 18          	shl    rdx,0x18
  6b:	48 09 d6             	or     rsi,rdx
  6e:	48 c1 e6 20          	shl    rsi,0x20
  72:	48 c1 ee 20          	shr    rsi,0x20
  76:	48 83 fe 20          	cmp    rsi,0x20
  7a:	0f 85 23 01 00 00    	jne    0x1a3
  80:	48 0f b6 77 0d       	movzx  rsi,BYTE PTR [rdi+0xd]
  85:	48 c1 e6 08          	shl    rsi,0x8
  89:	48 0f b6 57 0c       	movzx  rdx,BYTE PTR [rdi+0xc]
  8e:	48 09 d6             	or     rsi,rdx
  91:	48 0f b6 57 0e       	movzx  rdx,BYTE PTR [rdi+0xe]
  96:	48 c1 e2 10          	shl    rdx,0x10
  9a:	48 09 d6             	or     rsi,rdx
  9d:	48 0f b6 57 0f       	movzx  rdx,BYTE PTR [rdi+0xf]
  a2:	48 c1 e2 18          	shl    rdx,0x18
  a6:	48 09 d6             	or     rsi,rdx
  a9:	48 c1 e6 20          	shl    rsi,0x20
  ad:	48 c1 ee 20          	shr    rsi,0x20
  b1:	48 81 fe 00 02 00 00 	cmp    rsi,0x200
  b8:	0f 85 e5 00 00 00    	jne    0x1a3
  be:	31 f6                	xor    esi,esi
  c0:	ba 00 00 ff ff       	mov    edx,0xffff0000
  c5:	31 c9                	xor    ecx,ecx
  c7:	45 31 c0             	xor    r8d,r8d
  ca:	31 db                	xor    ebx,ebx
  cc:	48 89 f8             	mov    rax,rdi
  cf:	4c 01 c0             	add    rax,r8
  d2:	4c 0f b6 68 10       	movzx  r13,BYTE PTR [rax+0x10]
  d7:	48 0f b6 40 11       	movzx  rax,BYTE PTR [rax+0x11]
  dc:	48 c1 e0 08          	shl    rax,0x8
  e0:	4c 09 e8             	or     rax,r13
  e3:	48 01 d8             	add    rax,rbx
  e6:	48 89 c3             	mov    rbx,rax
  e9:	48 21 d3             	and    rbx,rdx
  ec:	48 25 ff ff 00 00    	and    rax,0xffff
  f2:	48 c1 eb 10          	shr    rbx,0x10
  f6:	48 01 d8             	add    rax,rbx
  f9:	49 83 c0 02          	add    r8,0x2
  fd:	48 89 c3             	mov    rbx,rax
 100:	49 81 f8 00 04 00 00 	cmp    r8,0x400
 107:	74 02                	je     0x10b
 109:	eb c1                	jmp    0xcc
 10b:	49 89 c0             	mov    r8,rax
 10e:	49 c1 e8 10          	shr    r8,0x10
 112:	49 01 c0             	add    r8,rax
 115:	49 83 f0 ff          	xor    r8,0xffffffffffffffff
 119:	49 81 e0 ff ff 00 00 	and    r8,0xffff
 120:	48 89 f0             	mov    rax,rsi
 123:	48 c1 e0 04          	shl    rax,0x4
 127:	48 83 e0 30          	and    rax,0x30
 12b:	c4 42 f9 f7 c0       	shlx   r8,r8,rax
 130:	49 31 c8             	xor    r8,rcx
 133:	48 83 c6 01          	add    rsi,0x1
 137:	48 89 f0             	mov    rax,rsi
 13a:	48 c1 e0 20          	shl    rax,0x20
 13e:	48 c1 e8 20          	shr    rax,0x20
 142:	4c 89 c1             	mov    rcx,r8
 145:	48 83 f8 20          	cmp    rax,0x20
 149:	74 05                	je     0x150
 14b:	e9 77 ff ff ff       	jmp    0xc7
 150:	4c 89 c6             	mov    rsi,r8
 153:	48 c1 ee 38          	shr    rsi,0x38
 157:	40 88 77 07          	mov    BYTE PTR [rdi+0x7],sil
 15b:	4c 89 c6             	mov    rsi,r8
 15e:	48 c1 ee 30          	shr    rsi,0x30
 162:	40 88 77 06          	mov    BYTE PTR [rdi+0x6],sil
 166:	4c 89 c6             	mov    rsi,r8
 169:	48 c1 ee 28          	shr    rsi,0x28
 16d:	40 88 77 05          	mov    BYTE PTR [rdi+0x5],sil
 171:	4c 89 c6             	mov    rsi,r8
 174:	48 c1 ee 20          	shr    rsi,0x20
 178:	40 88 77 04          	mov    BYTE PTR [rdi+0x4],sil
 17c:	4c 89 c6             	mov    rsi,r8
 17f:	48 c1 ee 18          	shr    rsi,0x18
 183:	40 88 77 03          	mov    BYTE PTR [rdi+0x3],sil
 187:	4c 89 c6             	mov    rsi,r8
 18a:	48 c1 ee 10          	shr    rsi,0x10
 18e:	40 88 77 02          	mov    BYTE PTR [rdi+0x2],sil
 192:	44 88 47 00          	mov    BYTE PTR [rdi+0x0],r8b
 196:	49 c1 e8 08          	shr    r8,0x8
 19a:	44 88 47 01          	mov    BYTE PTR [rdi+0x1],r8b
 19e:	b8 02 00 00 00       	mov    eax,0x2
 1a3:	41 5d                	pop    r13
 1a5:	5b                   	pop    rbx
 1a6:	c9                   	leave
 1a7:	e9 88 2e a1 e1       	jmp    0xffffffffe1a13034
```

## llvmbpf JIT ASM
```asm
not captured
```
