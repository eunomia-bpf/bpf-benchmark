# bcc_tcpconnect_ipv4_tuple_filter

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <bcc_tcpconnect_ipv4_tuple_filter_xdp>:
    1100:	48 8b 17             	mov    rdx,QWORD PTR [rdi]
    1103:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
    1107:	48 89 d6             	mov    rsi,rdx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 ce             	cmp    rsi,rcx
    110f:	76 01                	jbe    1112 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7e 08          	lea    rdi,[rsi+0x8]
    1116:	48 39 cf             	cmp    rdi,rcx
    1119:	77 f6                	ja     1111 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
    111b:	48 8d be 10 03 00 00 	lea    rdi,[rsi+0x310]
    1122:	48 39 cf             	cmp    rdi,rcx
    1125:	77 ea                	ja     1111 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
    1127:	83 7e 08 20          	cmp    DWORD PTR [rsi+0x8],0x20
    112b:	75 e4                	jne    1111 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
    112d:	83 7e 0c 18          	cmp    DWORD PTR [rsi+0xc],0x18
    1131:	75 de                	jne    1111 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
    1133:	55                   	push   rbp
    1134:	41 57                	push   r15
    1136:	41 56                	push   r14
    1138:	53                   	push   rbx
    1139:	48 83 c6 27          	add    rsi,0x27
    113d:	48 bf 2f 64 bd 78 64 	movabs rdi,0xa0761d6478bd642f
    1144:	1d 76 a0 
    1147:	31 c0                	xor    eax,eax
    1149:	eb 23                	jmp    116e <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x6e>
    114b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    1150:	49 c1 e1 30          	shl    r9,0x30
    1154:	44 89 d9             	mov    ecx,r11d
    1157:	4c 09 c9             	or     rcx,r9
    115a:	48 31 cf             	xor    rdi,rcx
    115d:	48 ff c0             	inc    rax
    1160:	48 83 c6 18          	add    rsi,0x18
    1164:	48 83 f8 20          	cmp    rax,0x20
    1168:	0f 84 61 01 00 00    	je     12cf <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1cf>
    116e:	0f b7 4e fb          	movzx  ecx,WORD PTR [rsi-0x5]
    1172:	81 f9 8f 1f 00 00    	cmp    ecx,0x1f8f
    1178:	7f 26                	jg     11a0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xa0>
    117a:	83 f9 50             	cmp    ecx,0x50
    117d:	74 73                	je     11f2 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xf2>
    117f:	81 f9 bb 01 00 00    	cmp    ecx,0x1bb
    1185:	75 40                	jne    11c7 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xc7>
    1187:	41 b8 02 00 00 00    	mov    r8d,0x2
    118d:	44 8b 5e e9          	mov    r11d,DWORD PTR [rsi-0x17]
    1191:	44 0f b6 4e fd       	movzx  r9d,BYTE PTR [rsi-0x3]
    1196:	41 83 f9 02          	cmp    r9d,0x2
    119a:	75 b4                	jne    1150 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
    119c:	eb 72                	jmp    1210 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x110>
    119e:	66 90                	xchg   ax,ax
    11a0:	81 f9 90 1f 00 00    	cmp    ecx,0x1f90
    11a6:	74 08                	je     11b0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xb0>
    11a8:	81 f9 fb 20 00 00    	cmp    ecx,0x20fb
    11ae:	75 17                	jne    11c7 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xc7>
    11b0:	41 b8 03 00 00 00    	mov    r8d,0x3
    11b6:	44 8b 5e e9          	mov    r11d,DWORD PTR [rsi-0x17]
    11ba:	44 0f b6 4e fd       	movzx  r9d,BYTE PTR [rsi-0x3]
    11bf:	41 83 f9 02          	cmp    r9d,0x2
    11c3:	75 8b                	jne    1150 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
    11c5:	eb 49                	jmp    1210 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x110>
    11c7:	44 0f bf c9          	movsx  r9d,cx
    11cb:	45 31 c0             	xor    r8d,r8d
    11ce:	41 81 f9 30 75 00 00 	cmp    r9d,0x7530
    11d5:	41 0f 9d c0          	setge  r8b
    11d9:	41 c1 e0 02          	shl    r8d,0x2
    11dd:	44 8b 5e e9          	mov    r11d,DWORD PTR [rsi-0x17]
    11e1:	44 0f b6 4e fd       	movzx  r9d,BYTE PTR [rsi-0x3]
    11e6:	41 83 f9 02          	cmp    r9d,0x2
    11ea:	0f 85 60 ff ff ff    	jne    1150 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
    11f0:	eb 1e                	jmp    1210 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x110>
    11f2:	41 b8 01 00 00 00    	mov    r8d,0x1
    11f8:	44 8b 5e e9          	mov    r11d,DWORD PTR [rsi-0x17]
    11fc:	44 0f b6 4e fd       	movzx  r9d,BYTE PTR [rsi-0x3]
    1201:	41 83 f9 02          	cmp    r9d,0x2
    1205:	0f 85 45 ff ff ff    	jne    1150 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
    120b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
    1210:	44 8b 4e ed          	mov    r9d,DWORD PTR [rsi-0x13]
    1214:	0f b6 5e fe          	movzx  ebx,BYTE PTR [rsi-0x2]
    1218:	f6 c3 01             	test   bl,0x1
    121b:	0f 84 9f 00 00 00    	je     12c0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1c0>
    1221:	45 85 c0             	test   r8d,r8d
    1224:	0f 84 96 00 00 00    	je     12c0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1c0>
    122a:	0f b6 6e f9          	movzx  ebp,BYTE PTR [rsi-0x7]
    122e:	44 0f b6 76 fa       	movzx  r14d,BYTE PTR [rsi-0x6]
    1233:	c4 63 7b f0 7e f5 19 	rorx   r15d,DWORD PTR [rsi-0xb],0x19
    123a:	44 0f b7 56 ff       	movzx  r10d,WORD PTR [rsi-0x1]
    123f:	44 33 7e f1          	xor    r15d,DWORD PTR [rsi-0xf]
    1243:	41 c1 e6 18          	shl    r14d,0x18
    1247:	c1 e5 10             	shl    ebp,0x10
    124a:	44 09 f5             	or     ebp,r14d
    124d:	0f b7 c9             	movzx  ecx,cx
    1250:	31 e9                	xor    ecx,ebp
    1252:	44 31 f9             	xor    ecx,r15d
    1255:	89 dd                	mov    ebp,ebx
    1257:	c1 e5 1e             	shl    ebp,0x1e
    125a:	c1 fd 1f             	sar    ebp,0x1f
    125d:	47 8d 34 19          	lea    r14d,[r9+r11*1]
    1261:	41 21 ee             	and    r14d,ebp
    1264:	45 31 d6             	xor    r14d,r10d
    1267:	41 31 ce             	xor    r14d,ecx
    126a:	41 8d 48 03          	lea    ecx,[r8+0x3]
    126e:	45 89 f7             	mov    r15d,r14d
    1271:	41 d3 c7             	rol    r15d,cl
    1274:	f6 c3 04             	test   bl,0x4
    1277:	45 0f 44 fe          	cmove  r15d,r14d
    127b:	49 c1 e7 20          	shl    r15,0x20
    127f:	44 89 d9             	mov    ecx,r11d
    1282:	4c 09 f9             	or     rcx,r15
    1285:	41 89 c3             	mov    r11d,eax
    1288:	41 80 e3 07          	and    r11b,0x7
    128c:	41 8d 5b 01          	lea    ebx,[r11+0x1]
    1290:	c4 e2 e1 f7 d9       	shlx   rbx,rcx,rbx
    1295:	41 f6 d3             	not    r11b
    1298:	c4 e2 a3 f7 c9       	shrx   rcx,rcx,r11
    129d:	48 09 d9             	or     rcx,rbx
    12a0:	48 31 f9             	xor    rcx,rdi
    12a3:	49 c1 e0 38          	shl    r8,0x38
    12a7:	41 c1 e2 10          	shl    r10d,0x10
    12ab:	4d 09 c2             	or     r10,r8
    12ae:	44 89 cf             	mov    edi,r9d
    12b1:	4c 31 d7             	xor    rdi,r10
    12b4:	48 01 cf             	add    rdi,rcx
    12b7:	e9 a1 fe ff ff       	jmp    115d <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x5d>
    12bc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    12c0:	49 c1 e1 20          	shl    r9,0x20
    12c4:	49 09 c9             	or     r9,rcx
    12c7:	4c 01 cf             	add    rdi,r9
    12ca:	e9 8e fe ff ff       	jmp    115d <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x5d>
    12cf:	48 89 3a             	mov    QWORD PTR [rdx],rdi
    12d2:	b8 02 00 00 00       	mov    eax,0x2
    12d7:	5b                   	pop    rbx
    12d8:	41 5e                	pop    r14
    12da:	41 5f                	pop    r15
    12dc:	5d                   	pop    rbp
    12dd:	c3                   	ret

Disassembly of section .fini:

00000000000012e0 <_fini>:
    12e0:	f3 0f 1e fa          	endbr64
    12e4:	48 83 ec 08          	sub    rsp,0x8
    12e8:	48 83 c4 08          	add    rsp,0x8
    12ec:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 28 00 00 00 	sub    rsp,0x28
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 4f 00          	mov    rcx,QWORD PTR [rdi+0x0]
  24:	48 39 f1             	cmp    rcx,rsi
  27:	0f 87 b5 03 00 00    	ja     0x3e2
  2d:	48 89 cf             	mov    rdi,rcx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 a5 03 00 00    	ja     0x3e2
  3d:	48 89 cf             	mov    rdi,rcx
  40:	48 81 c7 10 03 00 00 	add    rdi,0x310
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 92 03 00 00    	ja     0x3e2
  50:	48 0f b6 79 09       	movzx  rdi,BYTE PTR [rcx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 71 08       	movzx  rsi,BYTE PTR [rcx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 71 0a       	movzx  rsi,BYTE PTR [rcx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 71 0b       	movzx  rsi,BYTE PTR [rcx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 83 ff 20          	cmp    rdi,0x20
  85:	0f 85 57 03 00 00    	jne    0x3e2
  8b:	48 0f b6 79 0d       	movzx  rdi,BYTE PTR [rcx+0xd]
  90:	48 c1 e7 08          	shl    rdi,0x8
  94:	48 0f b6 71 0c       	movzx  rsi,BYTE PTR [rcx+0xc]
  99:	48 09 f7             	or     rdi,rsi
  9c:	48 0f b6 71 0e       	movzx  rsi,BYTE PTR [rcx+0xe]
  a1:	48 c1 e6 10          	shl    rsi,0x10
  a5:	48 09 f7             	or     rdi,rsi
  a8:	48 0f b6 71 0f       	movzx  rsi,BYTE PTR [rcx+0xf]
  ad:	48 c1 e6 18          	shl    rsi,0x18
  b1:	48 09 f7             	or     rdi,rsi
  b4:	48 c1 e7 20          	shl    rdi,0x20
  b8:	48 c1 ef 20          	shr    rdi,0x20
  bc:	48 83 ff 18          	cmp    rdi,0x18
  c0:	0f 85 1c 03 00 00    	jne    0x3e2
  c6:	49 bf 2f 64 bd 78 64 	movabs r15,0xa0761d6478bd642f
  cd:	1d 76 a0 
  d0:	31 d2                	xor    edx,edx
  d2:	48 89 4d d8          	mov    QWORD PTR [rbp-0x28],rcx
  d6:	48 83 c1 13          	add    rcx,0x13
  da:	eb 5b                	jmp    0x137
  dc:	4c 0f b6 69 fe       	movzx  r13,BYTE PTR [rcx-0x2]
  e1:	49 c1 e5 08          	shl    r13,0x8
  e5:	48 0f b6 79 fd       	movzx  rdi,BYTE PTR [rcx-0x3]
  ea:	49 09 fd             	or     r13,rdi
  ed:	48 0f b6 79 ff       	movzx  rdi,BYTE PTR [rcx-0x1]
  f2:	48 c1 e7 10          	shl    rdi,0x10
  f6:	49 09 fd             	or     r13,rdi
  f9:	48 0f b6 79 00       	movzx  rdi,BYTE PTR [rcx+0x0]
  fe:	48 c1 e7 18          	shl    rdi,0x18
 102:	49 09 fd             	or     r13,rdi
 105:	48 0f b6 79 11       	movzx  rdi,BYTE PTR [rcx+0x11]
 10a:	48 83 ff 02          	cmp    rdi,0x2
 10e:	74 6e                	je     0x17e
 110:	48 c1 e7 30          	shl    rdi,0x30
 114:	49 c1 e5 20          	shl    r13,0x20
 118:	49 c1 ed 20          	shr    r13,0x20
 11c:	4c 09 ef             	or     rdi,r13
 11f:	4c 31 ff             	xor    rdi,r15
 122:	49 89 ff             	mov    r15,rdi
 125:	48 83 c1 18          	add    rcx,0x18
 129:	48 83 c2 01          	add    rdx,0x1
 12d:	48 83 fa 20          	cmp    rdx,0x20
 131:	0f 84 54 02 00 00    	je     0x38b
 137:	48 0f b6 79 10       	movzx  rdi,BYTE PTR [rcx+0x10]
 13c:	48 c1 e7 08          	shl    rdi,0x8
 140:	48 0f b6 71 0f       	movzx  rsi,BYTE PTR [rcx+0xf]
 145:	48 09 f7             	or     rdi,rsi
 148:	41 b8 01 00 00 00    	mov    r8d,0x1
 14e:	49 89 fe             	mov    r14,rdi
 151:	49 c1 e6 30          	shl    r14,0x30
 155:	49 c1 fe 30          	sar    r14,0x30
 159:	48 81 e7 ff ff 00 00 	and    rdi,0xffff
 160:	48 83 ff 50          	cmp    rdi,0x50
 164:	0f 84 72 ff ff ff    	je     0xdc
 16a:	48 81 ff bb 01 00 00 	cmp    rdi,0x1bb
 171:	75 6e                	jne    0x1e1
 173:	41 b8 02 00 00 00    	mov    r8d,0x2
 179:	e9 5e ff ff ff       	jmp    0xdc
 17e:	48 0f b6 59 02       	movzx  rbx,BYTE PTR [rcx+0x2]
 183:	48 c1 e3 08          	shl    rbx,0x8
 187:	48 0f b6 79 01       	movzx  rdi,BYTE PTR [rcx+0x1]
 18c:	48 09 fb             	or     rbx,rdi
 18f:	48 0f b6 79 03       	movzx  rdi,BYTE PTR [rcx+0x3]
 194:	48 c1 e7 10          	shl    rdi,0x10
 198:	48 09 fb             	or     rbx,rdi
 19b:	48 0f b6 79 04       	movzx  rdi,BYTE PTR [rcx+0x4]
 1a0:	48 c1 e7 18          	shl    rdi,0x18
 1a4:	48 09 fb             	or     rbx,rdi
 1a7:	48 0f b6 79 12       	movzx  rdi,BYTE PTR [rcx+0x12]
 1ac:	48 89 fe             	mov    rsi,rdi
 1af:	48 83 e6 01          	and    rsi,0x1
 1b3:	48 85 f6             	test   rsi,rsi
 1b6:	74 10                	je     0x1c8
 1b8:	4c 89 c6             	mov    rsi,r8
 1bb:	48 c1 e6 20          	shl    rsi,0x20
 1bf:	48 c1 ee 20          	shr    rsi,0x20
 1c3:	48 85 f6             	test   rsi,rsi
 1c6:	75 54                	jne    0x21c
 1c8:	49 81 e6 ff ff 00 00 	and    r14,0xffff
 1cf:	48 c1 e3 20          	shl    rbx,0x20
 1d3:	4c 09 f3             	or     rbx,r14
 1d6:	4c 01 fb             	add    rbx,r15
 1d9:	49 89 df             	mov    r15,rbx
 1dc:	e9 44 ff ff ff       	jmp    0x125
 1e1:	41 b8 03 00 00 00    	mov    r8d,0x3
 1e7:	49 81 fe fb 20 00 00 	cmp    r14,0x20fb
 1ee:	0f 84 e8 fe ff ff    	je     0xdc
 1f4:	49 81 fe 90 1f 00 00 	cmp    r14,0x1f90
 1fb:	0f 84 db fe ff ff    	je     0xdc
 201:	41 b8 01 00 00 00    	mov    r8d,0x1
 207:	49 81 fe 2f 75 00 00 	cmp    r14,0x752f
 20e:	7f 03                	jg     0x213
 210:	45 31 c0             	xor    r8d,r8d
 213:	49 c1 e0 02          	shl    r8,0x2
 217:	e9 c0 fe ff ff       	jmp    0xdc
 21c:	4c 89 7d f8          	mov    QWORD PTR [rbp-0x8],r15
 220:	4c 0f b6 79 0a       	movzx  r15,BYTE PTR [rcx+0xa]
 225:	49 c1 e7 08          	shl    r15,0x8
 229:	48 0f b6 71 09       	movzx  rsi,BYTE PTR [rcx+0x9]
 22e:	49 09 f7             	or     r15,rsi
 231:	48 0f b6 71 06       	movzx  rsi,BYTE PTR [rcx+0x6]
 236:	48 c1 e6 08          	shl    rsi,0x8
 23a:	4c 89 45 f0          	mov    QWORD PTR [rbp-0x10],r8
 23e:	4c 0f b6 41 05       	movzx  r8,BYTE PTR [rcx+0x5]
 243:	4c 09 c6             	or     rsi,r8
 246:	4c 0f b6 41 07       	movzx  r8,BYTE PTR [rcx+0x7]
 24b:	49 c1 e0 10          	shl    r8,0x10
 24f:	4c 09 c6             	or     rsi,r8
 252:	4c 0f b6 41 0b       	movzx  r8,BYTE PTR [rcx+0xb]
 257:	49 c1 e0 10          	shl    r8,0x10
 25b:	4d 09 c7             	or     r15,r8
 25e:	4c 0f b6 41 14       	movzx  r8,BYTE PTR [rcx+0x14]
 263:	49 c1 e0 08          	shl    r8,0x8
 267:	48 89 7d e8          	mov    QWORD PTR [rbp-0x18],rdi
 26b:	48 0f b6 79 13       	movzx  rdi,BYTE PTR [rcx+0x13]
 270:	49 09 f8             	or     r8,rdi
 273:	4c 89 45 e0          	mov    QWORD PTR [rbp-0x20],r8
 277:	48 0f b6 79 0c       	movzx  rdi,BYTE PTR [rcx+0xc]
 27c:	48 c1 e7 18          	shl    rdi,0x18
 280:	49 09 ff             	or     r15,rdi
 283:	48 0f b6 79 08       	movzx  rdi,BYTE PTR [rcx+0x8]
 288:	48 c1 e7 18          	shl    rdi,0x18
 28c:	48 09 fe             	or     rsi,rdi
 28f:	48 0f b6 79 0e       	movzx  rdi,BYTE PTR [rcx+0xe]
 294:	48 0f b6 41 0d       	movzx  rax,BYTE PTR [rcx+0xd]
 299:	48 c1 e0 10          	shl    rax,0x10
 29d:	48 c1 e7 18          	shl    rdi,0x18
 2a1:	48 09 c7             	or     rdi,rax
 2a4:	4c 89 f8             	mov    rax,r15
 2a7:	41 b8 00 00 00 fe    	mov    r8d,0xfe000000
 2ad:	4c 21 c0             	and    rax,r8
 2b0:	4c 8b 45 f0          	mov    r8,QWORD PTR [rbp-0x10]
 2b4:	48 c1 e8 19          	shr    rax,0x19
 2b8:	49 c1 e7 07          	shl    r15,0x7
 2bc:	49 09 c7             	or     r15,rax
 2bf:	49 31 f7             	xor    r15,rsi
 2c2:	49 31 ff             	xor    r15,rdi
 2c5:	49 81 e6 ff ff 00 00 	and    r14,0xffff
 2cc:	4d 31 f7             	xor    r15,r14
 2cf:	4c 8b 75 e0          	mov    r14,QWORD PTR [rbp-0x20]
 2d3:	48 89 df             	mov    rdi,rbx
 2d6:	4c 01 ef             	add    rdi,r13
 2d9:	48 8b 45 e8          	mov    rax,QWORD PTR [rbp-0x18]
 2dd:	48 89 c6             	mov    rsi,rax
 2e0:	48 c1 e6 3e          	shl    rsi,0x3e
 2e4:	48 c1 fe 3f          	sar    rsi,0x3f
 2e8:	48 21 fe             	and    rsi,rdi
 2eb:	49 31 f7             	xor    r15,rsi
 2ee:	49 81 e6 ff ff 00 00 	and    r14,0xffff
 2f5:	4d 31 f7             	xor    r15,r14
 2f8:	48 89 c7             	mov    rdi,rax
 2fb:	48 83 e7 04          	and    rdi,0x4
 2ff:	48 85 ff             	test   rdi,rdi
 302:	74 31                	je     0x335
 304:	48 c7 c7 fd ff ff ff 	mov    rdi,0xfffffffffffffffd
 30b:	4c 29 c7             	sub    rdi,r8
 30e:	48 83 e7 1f          	and    rdi,0x1f
 312:	4c 89 fe             	mov    rsi,r15
 315:	48 c1 e6 20          	shl    rsi,0x20
 319:	48 c1 ee 20          	shr    rsi,0x20
 31d:	c4 e2 c3 f7 f6       	shrx   rsi,rsi,rdi
 322:	4c 89 c7             	mov    rdi,r8
 325:	48 83 c7 03          	add    rdi,0x3
 329:	48 83 e7 1f          	and    rdi,0x1f
 32d:	c4 42 c1 f7 ff       	shlx   r15,r15,rdi
 332:	49 09 f7             	or     r15,rsi
 335:	49 c1 e7 20          	shl    r15,0x20
 339:	49 c1 e5 20          	shl    r13,0x20
 33d:	49 c1 ed 20          	shr    r13,0x20
 341:	4d 09 ef             	or     r15,r13
 344:	48 89 d7             	mov    rdi,rdx
 347:	48 83 e7 07          	and    rdi,0x7
 34b:	48 89 fe             	mov    rsi,rdi
 34e:	48 83 f6 3f          	xor    rsi,0x3f
 352:	4c 89 f8             	mov    rax,r15
 355:	c4 e2 cb f7 c0       	shrx   rax,rax,rsi
 35a:	48 83 c7 01          	add    rdi,0x1
 35e:	c4 42 c1 f7 ff       	shlx   r15,r15,rdi
 363:	49 09 c7             	or     r15,rax
 366:	48 8b 7d f8          	mov    rdi,QWORD PTR [rbp-0x8]
 36a:	49 31 ff             	xor    r15,rdi
 36d:	49 c1 e0 38          	shl    r8,0x38
 371:	49 c1 e6 10          	shl    r14,0x10
 375:	4d 09 f0             	or     r8,r14
 378:	48 c1 e3 20          	shl    rbx,0x20
 37c:	48 c1 eb 20          	shr    rbx,0x20
 380:	49 31 d8             	xor    r8,rbx
 383:	4d 01 c7             	add    r15,r8
 386:	e9 9a fd ff ff       	jmp    0x125
 38b:	4c 89 ff             	mov    rdi,r15
 38e:	48 c1 ef 38          	shr    rdi,0x38
 392:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
 396:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 39a:	4c 89 ff             	mov    rdi,r15
 39d:	48 c1 ef 30          	shr    rdi,0x30
 3a1:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 3a5:	4c 89 ff             	mov    rdi,r15
 3a8:	48 c1 ef 28          	shr    rdi,0x28
 3ac:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 3b0:	4c 89 ff             	mov    rdi,r15
 3b3:	48 c1 ef 20          	shr    rdi,0x20
 3b7:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 3bb:	4c 89 ff             	mov    rdi,r15
 3be:	48 c1 ef 18          	shr    rdi,0x18
 3c2:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 3c6:	4c 89 ff             	mov    rdi,r15
 3c9:	48 c1 ef 10          	shr    rdi,0x10
 3cd:	40 88 7e 02          	mov    BYTE PTR [rsi+0x2],dil
 3d1:	44 88 7e 00          	mov    BYTE PTR [rsi+0x0],r15b
 3d5:	49 c1 ef 08          	shr    r15,0x8
 3d9:	44 88 7e 01          	mov    BYTE PTR [rsi+0x1],r15b
 3dd:	b8 02 00 00 00       	mov    eax,0x2
 3e2:	41 5f                	pop    r15
 3e4:	41 5e                	pop    r14
 3e6:	41 5d                	pop    r13
 3e8:	5b                   	pop    rbx
 3e9:	c9                   	leave
 3ea:	e9 bd 24 a1 e1       	jmp    0xffffffffe1a128ac
```

## llvmbpf JIT ASM
```asm
not captured
```
