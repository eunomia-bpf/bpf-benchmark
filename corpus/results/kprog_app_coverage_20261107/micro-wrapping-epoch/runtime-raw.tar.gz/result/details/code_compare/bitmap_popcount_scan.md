# bitmap_popcount_scan

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <bitmap_popcount_scan_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <bitmap_popcount_scan_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <bitmap_popcount_scan_xdp+0x11>
    111b:	4c 8d 82 10 08 00 00 	lea    r8,[rdx+0x810]
    1122:	49 39 f0             	cmp    r8,rsi
    1125:	77 ea                	ja     1111 <bitmap_popcount_scan_xdp+0x11>
    1127:	81 3f 00 01 00 00    	cmp    DWORD PTR [rdi],0x100
    112d:	75 e2                	jne    1111 <bitmap_popcount_scan_xdp+0x11>
    112f:	8b 72 0c             	mov    esi,DWORD PTR [rdx+0xc]
    1132:	31 c0                	xor    eax,eax
    1134:	66 66 66 2e 0f 1f 84 	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    113b:	00 00 00 00 00 
    1140:	48 8b 7c c2 10       	mov    rdi,QWORD PTR [rdx+rax*8+0x10]
    1145:	4c 8b 44 c2 18       	mov    r8,QWORD PTR [rdx+rax*8+0x18]
    114a:	41 89 c1             	mov    r9d,eax
    114d:	41 80 e1 06          	and    r9b,0x6
    1151:	c4 62 b3 f7 cf       	shrx   r9,rdi,r9
    1156:	48 31 f7             	xor    rdi,rsi
    1159:	f3 48 0f b8 ff       	popcnt rdi,rdi
    115e:	48 01 f7             	add    rdi,rsi
    1161:	49 31 f9             	xor    r9,rdi
    1164:	8d 70 01             	lea    esi,[rax+0x1]
    1167:	40 80 e6 07          	and    sil,0x7
    116b:	c4 c2 cb f7 f0       	shrx   rsi,r8,rsi
    1170:	4d 31 c8             	xor    r8,r9
    1173:	31 ff                	xor    edi,edi
    1175:	f3 49 0f b8 f8       	popcnt rdi,r8
    117a:	4c 01 cf             	add    rdi,r9
    117d:	48 31 fe             	xor    rsi,rdi
    1180:	48 83 c0 02          	add    rax,0x2
    1184:	48 3d 00 01 00 00    	cmp    rax,0x100
    118a:	75 b4                	jne    1140 <bitmap_popcount_scan_xdp+0x40>
    118c:	48 89 31             	mov    QWORD PTR [rcx],rsi
    118f:	b8 02 00 00 00       	mov    eax,0x2
    1194:	c3                   	ret

Disassembly of section .fini:

0000000000001198 <_fini>:
    1198:	f3 0f 1e fa          	endbr64
    119c:	48 83 ec 08          	sub    rsp,0x8
    11a0:	48 83 c4 08          	add    rsp,0x8
    11a4:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	53                   	push   rbx
   d:	41 55                	push   r13
   f:	41 56                	push   r14
  11:	41 57                	push   r15
  13:	31 c0                	xor    eax,eax
  15:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  19:	48 8b 7f 00          	mov    rdi,QWORD PTR [rdi+0x0]
  1d:	48 39 f7             	cmp    rdi,rsi
  20:	0f 87 c9 01 00 00    	ja     0x1ef
  26:	48 89 fa             	mov    rdx,rdi
  29:	48 83 c2 08          	add    rdx,0x8
  2d:	48 39 f2             	cmp    rdx,rsi
  30:	0f 87 b9 01 00 00    	ja     0x1ef
  36:	48 89 fa             	mov    rdx,rdi
  39:	48 81 c2 10 08 00 00 	add    rdx,0x810
  40:	48 39 f2             	cmp    rdx,rsi
  43:	0f 87 a6 01 00 00    	ja     0x1ef
  49:	48 0f b6 77 09       	movzx  rsi,BYTE PTR [rdi+0x9]
  4e:	48 c1 e6 08          	shl    rsi,0x8
  52:	48 0f b6 57 08       	movzx  rdx,BYTE PTR [rdi+0x8]
  57:	48 09 d6             	or     rsi,rdx
  5a:	48 0f b6 57 0a       	movzx  rdx,BYTE PTR [rdi+0xa]
  5f:	48 c1 e2 10          	shl    rdx,0x10
  63:	48 09 d6             	or     rsi,rdx
  66:	48 0f b6 57 0b       	movzx  rdx,BYTE PTR [rdi+0xb]
  6b:	48 c1 e2 18          	shl    rdx,0x18
  6f:	48 09 d6             	or     rsi,rdx
  72:	48 c1 e6 20          	shl    rsi,0x20
  76:	48 c1 ee 20          	shr    rsi,0x20
  7a:	48 81 fe 00 01 00 00 	cmp    rsi,0x100
  81:	0f 85 68 01 00 00    	jne    0x1ef
  87:	48 0f b6 77 0d       	movzx  rsi,BYTE PTR [rdi+0xd]
  8c:	48 c1 e6 08          	shl    rsi,0x8
  90:	48 0f b6 57 0c       	movzx  rdx,BYTE PTR [rdi+0xc]
  95:	48 09 d6             	or     rsi,rdx
  98:	48 0f b6 57 0e       	movzx  rdx,BYTE PTR [rdi+0xe]
  9d:	48 c1 e2 10          	shl    rdx,0x10
  a1:	48 09 d6             	or     rsi,rdx
  a4:	48 0f b6 57 0f       	movzx  rdx,BYTE PTR [rdi+0xf]
  a9:	48 c1 e2 18          	shl    rdx,0x18
  ad:	48 09 d6             	or     rsi,rdx
  b0:	31 d2                	xor    edx,edx
  b2:	48 89 f9             	mov    rcx,rdi
  b5:	48 83 c1 17          	add    rcx,0x17
  b9:	48 b8 33 33 33 33 33 	movabs rax,0x3333333333333333
  c0:	33 33 33 
  c3:	49 bd 01 01 01 01 01 	movabs r13,0x101010101010101
  ca:	01 01 01 
  cd:	48 bb 55 55 55 55 55 	movabs rbx,0x5555555555555555
  d4:	55 55 55 
  d7:	4c 0f b6 71 fd       	movzx  r14,BYTE PTR [rcx-0x3]
  dc:	49 c1 e6 20          	shl    r14,0x20
  e0:	4c 0f b6 79 fb       	movzx  r15,BYTE PTR [rcx-0x5]
  e5:	49 c1 e7 10          	shl    r15,0x10
  e9:	4d 09 f7             	or     r15,r14
  ec:	4c 0f b6 41 fc       	movzx  r8,BYTE PTR [rcx-0x4]
  f1:	49 c1 e0 18          	shl    r8,0x18
  f5:	4c 0f b6 71 fa       	movzx  r14,BYTE PTR [rcx-0x6]
  fa:	49 c1 e6 08          	shl    r14,0x8
  fe:	4d 09 c6             	or     r14,r8
 101:	4d 09 fe             	or     r14,r15
 104:	4c 0f b6 41 fe       	movzx  r8,BYTE PTR [rcx-0x2]
 109:	49 c1 e0 28          	shl    r8,0x28
 10d:	4d 09 c6             	or     r14,r8
 110:	4c 0f b6 41 00       	movzx  r8,BYTE PTR [rcx+0x0]
 115:	49 c1 e0 38          	shl    r8,0x38
 119:	4c 0f b6 79 ff       	movzx  r15,BYTE PTR [rcx-0x1]
 11e:	49 c1 e7 30          	shl    r15,0x30
 122:	4d 09 c7             	or     r15,r8
 125:	4d 09 fe             	or     r14,r15
 128:	4c 0f b6 41 f9       	movzx  r8,BYTE PTR [rcx-0x7]
 12d:	4d 09 c6             	or     r14,r8
 130:	4d 89 f0             	mov    r8,r14
 133:	49 31 f0             	xor    r8,rsi
 136:	4d 89 c7             	mov    r15,r8
 139:	49 d1 ef             	shr    r15,1
 13c:	49 21 df             	and    r15,rbx
 13f:	4d 29 f8             	sub    r8,r15
 142:	4d 89 c7             	mov    r15,r8
 145:	49 21 c7             	and    r15,rax
 148:	49 c1 e8 02          	shr    r8,0x2
 14c:	49 21 c0             	and    r8,rax
 14f:	4d 01 c7             	add    r15,r8
 152:	49 89 d0             	mov    r8,rdx
 155:	49 83 e0 07          	and    r8,0x7
 159:	c4 42 bb f7 f6       	shrx   r14,r14,r8
 15e:	4d 89 f8             	mov    r8,r15
 161:	49 c1 e8 04          	shr    r8,0x4
 165:	4d 01 c7             	add    r15,r8
 168:	49 b8 0f 0f 0f 0f 0f 	movabs r8,0xf0f0f0f0f0f0f0f
 16f:	0f 0f 0f 
 172:	4d 21 c7             	and    r15,r8
 175:	4d 0f af fd          	imul   r15,r13
 179:	49 c1 ef 38          	shr    r15,0x38
 17d:	49 01 f7             	add    r15,rsi
 180:	4d 31 f7             	xor    r15,r14
 183:	48 83 c1 08          	add    rcx,0x8
 187:	48 83 c2 01          	add    rdx,0x1
 18b:	4c 89 fe             	mov    rsi,r15
 18e:	48 81 fa 00 01 00 00 	cmp    rdx,0x100
 195:	74 05                	je     0x19c
 197:	e9 3b ff ff ff       	jmp    0xd7
 19c:	4c 89 fe             	mov    rsi,r15
 19f:	48 c1 ee 38          	shr    rsi,0x38
 1a3:	40 88 77 07          	mov    BYTE PTR [rdi+0x7],sil
 1a7:	4c 89 fe             	mov    rsi,r15
 1aa:	48 c1 ee 30          	shr    rsi,0x30
 1ae:	40 88 77 06          	mov    BYTE PTR [rdi+0x6],sil
 1b2:	4c 89 fe             	mov    rsi,r15
 1b5:	48 c1 ee 28          	shr    rsi,0x28
 1b9:	40 88 77 05          	mov    BYTE PTR [rdi+0x5],sil
 1bd:	4c 89 fe             	mov    rsi,r15
 1c0:	48 c1 ee 20          	shr    rsi,0x20
 1c4:	40 88 77 04          	mov    BYTE PTR [rdi+0x4],sil
 1c8:	4c 89 fe             	mov    rsi,r15
 1cb:	48 c1 ee 18          	shr    rsi,0x18
 1cf:	40 88 77 03          	mov    BYTE PTR [rdi+0x3],sil
 1d3:	4c 89 fe             	mov    rsi,r15
 1d6:	48 c1 ee 10          	shr    rsi,0x10
 1da:	40 88 77 02          	mov    BYTE PTR [rdi+0x2],sil
 1de:	44 88 7f 00          	mov    BYTE PTR [rdi+0x0],r15b
 1e2:	49 c1 ef 08          	shr    r15,0x8
 1e6:	44 88 7f 01          	mov    BYTE PTR [rdi+0x1],r15b
 1ea:	b8 02 00 00 00       	mov    eax,0x2
 1ef:	41 5f                	pop    r15
 1f1:	41 5e                	pop    r14
 1f3:	41 5d                	pop    r13
 1f5:	5b                   	pop    rbx
 1f6:	c9                   	leave
 1f7:	e9 3c 2e a1 e1       	jmp    0xffffffffe1a13038
```

## llvmbpf JIT ASM
```asm
not captured
```
