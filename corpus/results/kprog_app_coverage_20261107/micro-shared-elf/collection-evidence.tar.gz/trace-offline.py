from pathlib import Path
import json,sys,traceback
R=Path('/workspaces/repository');D=Path('/workspaces/.agent-state/kprog-lanes/C/micro-shared-elf');sys.path.insert(0,str(R/'kprog'))
from trusted_service import adapter
r=next(r for r in json.loads((D/'kernel-requests.json').read_text()) if r['entry']=='trace_event_type_switch_dispatch_xdp');src=D/('request-'+str(r['request_id']));metadata=json.loads((src/'generation.metadata.json').read_text());out=D/'trace-offline'
try:
 result=adapter(1).specialize((D/'actual-image-trace.native.so').read_bytes(),r['entry'],metadata,out,R/'kprog/x86/native_lab/native_link/target/release/native-link');print(json.dumps(result,indent=2),flush=True)
except Exception:
 traceback.print_exc();raise
