set -eu
D=/workspaces/.agent-state/kprog-lanes/C/micro-shared-elf
trap 'echo $? > "$D/trace-offline.exit"' EXIT
PATH=/usr/lib/llvm-18/bin:$PATH PYTHONDONTWRITEBYTECODE=1 python3 "$D/trace-offline.py"
