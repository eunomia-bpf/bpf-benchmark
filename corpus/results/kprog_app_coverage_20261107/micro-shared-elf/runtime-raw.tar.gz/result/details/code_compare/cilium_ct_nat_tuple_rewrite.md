# cilium_ct_nat_tuple_rewrite

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <cilium_ct_nat_tuple_rewrite_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <cilium_ct_nat_tuple_rewrite_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
    111b:	48 8d ba 10 04 00 00 	lea    rdi,[rdx+0x410]
    1122:	48 39 f7             	cmp    rdi,rsi
    1125:	77 ea                	ja     1111 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
    1127:	83 7a 08 20          	cmp    DWORD PTR [rdx+0x8],0x20
    112b:	75 e4                	jne    1111 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
    112d:	83 7a 0c 20          	cmp    DWORD PTR [rdx+0xc],0x20
    1131:	75 de                	jne    1111 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
    1133:	55                   	push   rbp
    1134:	41 57                	push   r15
    1136:	41 56                	push   r14
    1138:	41 54                	push   r12
    113a:	53                   	push   rbx
    113b:	48 83 c2 2f          	add    rdx,0x2f
    113f:	48 b8 e3 c6 88 9c f0 	movabs rax,0x8ebc6af09c88c6e3
    1146:	6a bc 8e 
    1149:	31 f6                	xor    esi,esi
    114b:	e9 80 00 00 00       	jmp    11d0 <cilium_ct_nat_tuple_rewrite_xdp+0xd0>
    1150:	41 89 ec             	mov    r12d,ebp
    1153:	44 89 fd             	mov    ebp,r15d
    1156:	c4 63 7b f0 fd 15    	rorx   r15d,ebp,0x15
    115c:	41 c1 e6 10          	shl    r14d,0x10
    1160:	45 31 fe             	xor    r14d,r15d
    1163:	45 0f b7 fc          	movzx  r15d,r12w
    1167:	41 c1 e2 18          	shl    r10d,0x18
    116b:	45 09 d1             	or     r9d,r10d
    116e:	45 31 f9             	xor    r9d,r15d
    1171:	45 31 f1             	xor    r9d,r14d
    1174:	41 31 d9             	xor    r9d,ebx
    1177:	41 c1 e3 1d          	shl    r11d,0x1d
    117b:	41 c1 fb 1f          	sar    r11d,0x1f
    117f:	c1 e7 08             	shl    edi,0x8
    1182:	44 31 c7             	xor    edi,r8d
    1185:	44 21 df             	and    edi,r11d
    1188:	44 01 cf             	add    edi,r9d
    118b:	48 c1 e7 20          	shl    rdi,0x20
    118f:	45 89 c0             	mov    r8d,r8d
    1192:	4c 01 c0             	add    rax,r8
    1195:	48 01 f8             	add    rax,rdi
    1198:	48 c1 e3 20          	shl    rbx,0x20
    119c:	89 ef                	mov    edi,ebp
    119e:	48 09 df             	or     rdi,rbx
    11a1:	41 89 f0             	mov    r8d,esi
    11a4:	41 83 e0 07          	and    r8d,0x7
    11a8:	45 8d 48 01          	lea    r9d,[r8+0x1]
    11ac:	c4 62 b1 f7 cf       	shlx   r9,rdi,r9
    11b1:	41 f6 d0             	not    r8b
    11b4:	c4 e2 bb f7 ff       	shrx   rdi,rdi,r8
    11b9:	4c 09 cf             	or     rdi,r9
    11bc:	48 31 f8             	xor    rax,rdi
    11bf:	48 ff c6             	inc    rsi
    11c2:	48 83 c2 20          	add    rdx,0x20
    11c6:	48 83 fe 20          	cmp    rsi,0x20
    11ca:	0f 84 8f 00 00 00    	je     125f <cilium_ct_nat_tuple_rewrite_xdp+0x15f>
    11d0:	44 0f b6 52 ed       	movzx  r10d,BYTE PTR [rdx-0x13]
    11d5:	0f b7 7a f9          	movzx  edi,WORD PTR [rdx-0x7]
    11d9:	44 0f b7 4a fb       	movzx  r9d,WORD PTR [rdx-0x5]
    11de:	44 8b 42 fd          	mov    r8d,DWORD PTR [rdx-0x3]
    11e2:	41 83 fa 06          	cmp    r10d,0x6
    11e6:	74 06                	je     11ee <cilium_ct_nat_tuple_rewrite_xdp+0xee>
    11e8:	41 83 fa 11          	cmp    r10d,0x11
    11ec:	75 62                	jne    1250 <cilium_ct_nat_tuple_rewrite_xdp+0x150>
    11ee:	48 8d 5a f5          	lea    rbx,[rdx-0xb]
    11f2:	4c 8d 72 f1          	lea    r14,[rdx-0xf]
    11f6:	44 0f b6 5a ef       	movzx  r11d,BYTE PTR [rdx-0x11]
    11fb:	4c 8d 62 e5          	lea    r12,[rdx-0x1b]
    11ff:	4c 8d 7a e1          	lea    r15,[rdx-0x1f]
    1203:	44 89 dd             	mov    ebp,r11d
    1206:	83 e5 01             	and    ebp,0x1
    1209:	0f 45 ef             	cmovne ebp,edi
    120c:	4d 0f 45 fe          	cmovne r15,r14
    1210:	66 33 6a e9          	xor    bp,WORD PTR [rdx-0x17]
    1214:	45 8b 3f             	mov    r15d,DWORD PTR [r15]
    1217:	45 89 de             	mov    r14d,r11d
    121a:	41 83 e6 02          	and    r14d,0x2
    121e:	44 0f 45 f7          	cmovne r14d,edi
    1222:	4c 0f 45 e3          	cmovne r12,rbx
    1226:	66 44 33 72 eb       	xor    r14w,WORD PTR [rdx-0x15]
    122b:	41 8b 1c 24          	mov    ebx,DWORD PTR [r12]
    122f:	f6 42 ee 01          	test   BYTE PTR [rdx-0x12],0x1
    1233:	0f 85 17 ff ff ff    	jne    1150 <cilium_ct_nat_tuple_rewrite_xdp+0x50>
    1239:	45 89 f4             	mov    r12d,r14d
    123c:	41 89 ee             	mov    r14d,ebp
    123f:	89 dd                	mov    ebp,ebx
    1241:	44 89 fb             	mov    ebx,r15d
    1244:	e9 0d ff ff ff       	jmp    1156 <cilium_ct_nat_tuple_rewrite_xdp+0x56>
    1249:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1250:	49 c1 e2 38          	shl    r10,0x38
    1254:	44 89 c7             	mov    edi,r8d
    1257:	4c 09 d7             	or     rdi,r10
    125a:	e9 5d ff ff ff       	jmp    11bc <cilium_ct_nat_tuple_rewrite_xdp+0xbc>
    125f:	48 89 01             	mov    QWORD PTR [rcx],rax
    1262:	b8 02 00 00 00       	mov    eax,0x2
    1267:	5b                   	pop    rbx
    1268:	41 5c                	pop    r12
    126a:	41 5e                	pop    r14
    126c:	41 5f                	pop    r15
    126e:	5d                   	pop    rbp
    126f:	c3                   	ret

Disassembly of section .fini:

0000000000001270 <_fini>:
    1270:	f3 0f 1e fa          	endbr64
    1274:	48 83 ec 08          	sub    rsp,0x8
    1278:	48 83 c4 08          	add    rsp,0x8
    127c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 38 00 00 00 	sub    rsp,0x38
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 57 00          	mov    rdx,QWORD PTR [rdi+0x0]
  24:	48 39 f2             	cmp    rdx,rsi
  27:	0f 87 88 03 00 00    	ja     0x3b5
  2d:	48 89 d7             	mov    rdi,rdx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 78 03 00 00    	ja     0x3b5
  3d:	48 89 d7             	mov    rdi,rdx
  40:	48 81 c7 10 04 00 00 	add    rdi,0x410
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 65 03 00 00    	ja     0x3b5
  50:	48 0f b6 7a 09       	movzx  rdi,BYTE PTR [rdx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 72 08       	movzx  rsi,BYTE PTR [rdx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 72 0a       	movzx  rsi,BYTE PTR [rdx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 72 0b       	movzx  rsi,BYTE PTR [rdx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 83 ff 20          	cmp    rdi,0x20
  85:	0f 85 2a 03 00 00    	jne    0x3b5
  8b:	48 0f b6 7a 0d       	movzx  rdi,BYTE PTR [rdx+0xd]
  90:	48 c1 e7 08          	shl    rdi,0x8
  94:	48 0f b6 72 0c       	movzx  rsi,BYTE PTR [rdx+0xc]
  99:	48 09 f7             	or     rdi,rsi
  9c:	48 0f b6 72 0e       	movzx  rsi,BYTE PTR [rdx+0xe]
  a1:	48 c1 e6 10          	shl    rsi,0x10
  a5:	48 09 f7             	or     rdi,rsi
  a8:	48 0f b6 72 0f       	movzx  rsi,BYTE PTR [rdx+0xf]
  ad:	48 c1 e6 18          	shl    rsi,0x18
  b1:	48 09 f7             	or     rdi,rsi
  b4:	48 c1 e7 20          	shl    rdi,0x20
  b8:	48 c1 ef 20          	shr    rdi,0x20
  bc:	48 83 ff 20          	cmp    rdi,0x20
  c0:	0f 85 ef 02 00 00    	jne    0x3b5
  c6:	48 bb e3 c6 88 9c f0 	movabs rbx,0x8ebc6af09c88c6e3
  cd:	6a bc 8e 
  d0:	45 31 ed             	xor    r13d,r13d
  d3:	48 89 55 c8          	mov    QWORD PTR [rbp-0x38],rdx
  d7:	48 89 d1             	mov    rcx,rdx
  da:	48 83 c1 17          	add    rcx,0x17
  de:	e9 be 00 00 00       	jmp    0x1a1
  e3:	4c 89 ef             	mov    rdi,r13
  e6:	48 c1 e7 0b          	shl    rdi,0xb
  ea:	49 c1 e5 20          	shl    r13,0x20
  ee:	49 c1 ed 20          	shr    r13,0x20
  f2:	4c 89 ee             	mov    rsi,r13
  f5:	48 c1 ee 15          	shr    rsi,0x15
  f9:	48 09 f7             	or     rdi,rsi
  fc:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
 100:	48 c1 e6 18          	shl    rsi,0x18
 104:	48 09 f0             	or     rax,rsi
 107:	48 81 e3 ff ff 00 00 	and    rbx,0xffff
 10e:	48 31 d8             	xor    rax,rbx
 111:	48 c1 e2 10          	shl    rdx,0x10
 115:	48 31 d0             	xor    rax,rdx
 118:	48 31 f8             	xor    rax,rdi
 11b:	48 8b 75 e0          	mov    rsi,QWORD PTR [rbp-0x20]
 11f:	48 81 e6 ff ff 00 00 	and    rsi,0xffff
 126:	48 c1 e6 08          	shl    rsi,0x8
 12a:	4c 89 c7             	mov    rdi,r8
 12d:	48 31 f7             	xor    rdi,rsi
 130:	48 8b 5d f8          	mov    rbx,QWORD PTR [rbp-0x8]
 134:	48 c1 e3 3d          	shl    rbx,0x3d
 138:	48 c1 fb 20          	sar    rbx,0x20
 13c:	48 c1 eb 1f          	shr    rbx,0x1f
 140:	48 21 fb             	and    rbx,rdi
 143:	4c 31 f8             	xor    rax,r15
 146:	49 c1 e7 20          	shl    r15,0x20
 14a:	4d 09 ef             	or     r15,r13
 14d:	4c 8b 6d e8          	mov    r13,QWORD PTR [rbp-0x18]
 151:	4c 89 ef             	mov    rdi,r13
 154:	48 83 e7 07          	and    rdi,0x7
 158:	48 89 fe             	mov    rsi,rdi
 15b:	48 83 f6 3f          	xor    rsi,0x3f
 15f:	4c 89 fa             	mov    rdx,r15
 162:	c4 e2 cb f7 d2       	shrx   rdx,rdx,rsi
 167:	48 83 c7 01          	add    rdi,0x1
 16b:	c4 42 c1 f7 ff       	shlx   r15,r15,rdi
 170:	49 09 d7             	or     r15,rdx
 173:	48 01 d8             	add    rax,rbx
 176:	49 c1 e0 20          	shl    r8,0x20
 17a:	49 c1 e8 20          	shr    r8,0x20
 17e:	48 8b 5d f0          	mov    rbx,QWORD PTR [rbp-0x10]
 182:	4c 01 c3             	add    rbx,r8
 185:	48 c1 e0 20          	shl    rax,0x20
 189:	48 01 c3             	add    rbx,rax
 18c:	4c 31 fb             	xor    rbx,r15
 18f:	48 83 c1 20          	add    rcx,0x20
 193:	49 83 c5 01          	add    r13,0x1
 197:	49 83 fd 20          	cmp    r13,0x20
 19b:	0f 84 bf 01 00 00    	je     0x360
 1a1:	48 0f b6 41 14       	movzx  rax,BYTE PTR [rcx+0x14]
 1a6:	48 0f b6 51 13       	movzx  rdx,BYTE PTR [rcx+0x13]
 1ab:	4c 0f b6 71 12       	movzx  r14,BYTE PTR [rcx+0x12]
 1b0:	48 0f b6 71 11       	movzx  rsi,BYTE PTR [rcx+0x11]
 1b5:	4c 0f b6 41 16       	movzx  r8,BYTE PTR [rcx+0x16]
 1ba:	49 c1 e0 08          	shl    r8,0x8
 1be:	48 0f b6 79 15       	movzx  rdi,BYTE PTR [rcx+0x15]
 1c3:	49 09 f8             	or     r8,rdi
 1c6:	48 0f b6 79 17       	movzx  rdi,BYTE PTR [rcx+0x17]
 1cb:	48 c1 e7 10          	shl    rdi,0x10
 1cf:	49 09 f8             	or     r8,rdi
 1d2:	48 0f b6 79 18       	movzx  rdi,BYTE PTR [rcx+0x18]
 1d7:	48 c1 e7 18          	shl    rdi,0x18
 1db:	49 09 f8             	or     r8,rdi
 1de:	48 0f b6 79 05       	movzx  rdi,BYTE PTR [rcx+0x5]
 1e3:	48 83 ff 06          	cmp    rdi,0x6
 1e7:	74 1d                	je     0x206
 1e9:	48 83 ff 11          	cmp    rdi,0x11
 1ed:	74 17                	je     0x206
 1ef:	48 c1 e7 38          	shl    rdi,0x38
 1f3:	49 c1 e0 20          	shl    r8,0x20
 1f7:	49 c1 e8 20          	shr    r8,0x20
 1fb:	4c 09 c7             	or     rdi,r8
 1fe:	48 31 df             	xor    rdi,rbx
 201:	48 89 fb             	mov    rbx,rdi
 204:	eb 89                	jmp    0x18f
 206:	48 89 55 d0          	mov    QWORD PTR [rbp-0x30],rdx
 20a:	48 89 75 e0          	mov    QWORD PTR [rbp-0x20],rsi
 20e:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
 212:	4c 89 6d e8          	mov    QWORD PTR [rbp-0x18],r13
 216:	48 0f b6 79 fe       	movzx  rdi,BYTE PTR [rcx-0x2]
 21b:	48 c1 e7 08          	shl    rdi,0x8
 21f:	48 0f b6 71 fd       	movzx  rsi,BYTE PTR [rcx-0x3]
 224:	48 09 f7             	or     rdi,rsi
 227:	48 0f b6 71 ff       	movzx  rsi,BYTE PTR [rcx-0x1]
 22c:	48 c1 e6 10          	shl    rsi,0x10
 230:	48 09 f7             	or     rdi,rsi
 233:	48 0f b6 71 00       	movzx  rsi,BYTE PTR [rcx+0x0]
 238:	48 c1 e6 18          	shl    rsi,0x18
 23c:	48 09 f7             	or     rdi,rsi
 23f:	48 0f b6 51 07       	movzx  rdx,BYTE PTR [rcx+0x7]
 244:	48 89 55 f8          	mov    QWORD PTR [rbp-0x8],rdx
 248:	48 83 e2 02          	and    rdx,0x2
 24c:	48 85 d2             	test   rdx,rdx
 24f:	74 29                	je     0x27a
 251:	48 0f b6 79 0e       	movzx  rdi,BYTE PTR [rcx+0xe]
 256:	48 c1 e7 08          	shl    rdi,0x8
 25a:	48 0f b6 51 0d       	movzx  rdx,BYTE PTR [rcx+0xd]
 25f:	48 09 d7             	or     rdi,rdx
 262:	48 0f b6 51 0f       	movzx  rdx,BYTE PTR [rcx+0xf]
 267:	48 c1 e2 10          	shl    rdx,0x10
 26b:	48 09 d7             	or     rdi,rdx
 26e:	48 0f b6 51 10       	movzx  rdx,BYTE PTR [rcx+0x10]
 273:	48 c1 e2 18          	shl    rdx,0x18
 277:	48 09 d7             	or     rdi,rdx
 27a:	48 89 5d f0          	mov    QWORD PTR [rbp-0x10],rbx
 27e:	4c 0f b6 79 fa       	movzx  r15,BYTE PTR [rcx-0x6]
 283:	49 c1 e7 08          	shl    r15,0x8
 287:	48 0f b6 51 f9       	movzx  rdx,BYTE PTR [rcx-0x7]
 28c:	49 09 d7             	or     r15,rdx
 28f:	48 0f b6 51 fb       	movzx  rdx,BYTE PTR [rcx-0x5]
 294:	48 c1 e2 10          	shl    rdx,0x10
 298:	49 09 d7             	or     r15,rdx
 29b:	48 0f b6 51 fc       	movzx  rdx,BYTE PTR [rcx-0x4]
 2a0:	48 c1 e2 18          	shl    rdx,0x18
 2a4:	49 09 d7             	or     r15,rdx
 2a7:	4c 8b 6d f8          	mov    r13,QWORD PTR [rbp-0x8]
 2ab:	49 83 e5 01          	and    r13,0x1
 2af:	48 8b 75 e0          	mov    rsi,QWORD PTR [rbp-0x20]
 2b3:	4d 85 ed             	test   r13,r13
 2b6:	74 29                	je     0x2e1
 2b8:	4c 0f b6 79 0a       	movzx  r15,BYTE PTR [rcx+0xa]
 2bd:	49 c1 e7 08          	shl    r15,0x8
 2c1:	48 0f b6 51 09       	movzx  rdx,BYTE PTR [rcx+0x9]
 2c6:	49 09 d7             	or     r15,rdx
 2c9:	48 0f b6 51 0b       	movzx  rdx,BYTE PTR [rcx+0xb]
 2ce:	48 c1 e2 10          	shl    rdx,0x10
 2d2:	49 09 d7             	or     r15,rdx
 2d5:	48 0f b6 51 0c       	movzx  rdx,BYTE PTR [rcx+0xc]
 2da:	48 c1 e2 18          	shl    rdx,0x18
 2de:	49 09 d7             	or     r15,rdx
 2e1:	48 c1 e0 08          	shl    rax,0x8
 2e5:	48 8b 55 d0          	mov    rdx,QWORD PTR [rbp-0x30]
 2e9:	48 09 d0             	or     rax,rdx
 2ec:	49 c1 e6 08          	shl    r14,0x8
 2f0:	49 09 f6             	or     r14,rsi
 2f3:	4c 89 f6             	mov    rsi,r14
 2f6:	4c 0f b6 71 04       	movzx  r14,BYTE PTR [rcx+0x4]
 2fb:	49 c1 e6 08          	shl    r14,0x8
 2ff:	48 0f b6 51 03       	movzx  rdx,BYTE PTR [rcx+0x3]
 304:	49 09 d6             	or     r14,rdx
 307:	48 8b 55 f8          	mov    rdx,QWORD PTR [rbp-0x8]
 30b:	48 c1 e2 3e          	shl    rdx,0x3e
 30f:	48 c1 fa 3f          	sar    rdx,0x3f
 313:	48 21 f2             	and    rdx,rsi
 316:	49 31 d6             	xor    r14,rdx
 319:	48 0f b6 51 02       	movzx  rdx,BYTE PTR [rcx+0x2]
 31e:	48 c1 e2 08          	shl    rdx,0x8
 322:	48 0f b6 59 01       	movzx  rbx,BYTE PTR [rcx+0x1]
 327:	48 09 da             	or     rdx,rbx
 32a:	49 f7 dd             	neg    r13
 32d:	48 89 75 e0          	mov    QWORD PTR [rbp-0x20],rsi
 331:	49 21 f5             	and    r13,rsi
 334:	4c 31 ea             	xor    rdx,r13
 337:	48 0f b6 71 06       	movzx  rsi,BYTE PTR [rcx+0x6]
 33c:	48 83 e6 01          	and    rsi,0x1
 340:	4c 89 f3             	mov    rbx,r14
 343:	49 89 fd             	mov    r13,rdi
 346:	48 85 f6             	test   rsi,rsi
 349:	0f 84 94 fd ff ff    	je     0xe3
 34f:	48 89 d3             	mov    rbx,rdx
 352:	4c 89 f2             	mov    rdx,r14
 355:	4d 89 fd             	mov    r13,r15
 358:	49 89 ff             	mov    r15,rdi
 35b:	e9 83 fd ff ff       	jmp    0xe3
 360:	48 89 df             	mov    rdi,rbx
 363:	48 c1 ef 38          	shr    rdi,0x38
 367:	48 8b 75 c8          	mov    rsi,QWORD PTR [rbp-0x38]
 36b:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 36f:	48 89 df             	mov    rdi,rbx
 372:	48 c1 ef 30          	shr    rdi,0x30
 376:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 37a:	48 89 df             	mov    rdi,rbx
 37d:	48 c1 ef 28          	shr    rdi,0x28
 381:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 385:	48 89 df             	mov    rdi,rbx
 388:	48 c1 ef 20          	shr    rdi,0x20
 38c:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 390:	48 89 df             	mov    rdi,rbx
 393:	48 c1 ef 18          	shr    rdi,0x18
 397:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 39b:	48 89 df             	mov    rdi,rbx
 39e:	48 c1 ef 10          	shr    rdi,0x10
 3a2:	40 88 7e 02          	mov    BYTE PTR [rsi+0x2],dil
 3a6:	88 5e 00             	mov    BYTE PTR [rsi+0x0],bl
 3a9:	48 c1 eb 08          	shr    rbx,0x8
 3ad:	88 5e 01             	mov    BYTE PTR [rsi+0x1],bl
 3b0:	b8 02 00 00 00       	mov    eax,0x2
 3b5:	41 5f                	pop    r15
 3b7:	41 5e                	pop    r14
 3b9:	41 5d                	pop    r13
 3bb:	5b                   	pop    rbx
 3bc:	c9                   	leave
 3bd:	e9 92 2c c1 d8       	jmp    0xffffffffd8c13054
```

## llvmbpf JIT ASM
```asm
not captured
```
