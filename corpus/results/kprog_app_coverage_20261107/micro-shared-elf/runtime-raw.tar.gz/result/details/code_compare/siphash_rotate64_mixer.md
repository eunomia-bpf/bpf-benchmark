# siphash_rotate64_mixer

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <siphash_rotate64_mixer_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	0f 87 4b 05 00 00    	ja     1660 <siphash_rotate64_mixer_xdp+0x560>
    1115:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1119:	48 39 f7             	cmp    rdi,rsi
    111c:	0f 87 3e 05 00 00    	ja     1660 <siphash_rotate64_mixer_xdp+0x560>
    1122:	48 8d 7a 48          	lea    rdi,[rdx+0x48]
    1126:	48 39 f7             	cmp    rdi,rsi
    1129:	0f 87 31 05 00 00    	ja     1660 <siphash_rotate64_mixer_xdp+0x560>
    112f:	41 57                	push   r15
    1131:	41 56                	push   r14
    1133:	41 54                	push   r12
    1135:	53                   	push   rbx
    1136:	4c 8b 5a 08          	mov    r11,QWORD PTR [rdx+0x8]
    113a:	4c 8b 52 10          	mov    r10,QWORD PTR [rdx+0x10]
    113e:	4c 8b 4a 18          	mov    r9,QWORD PTR [rdx+0x18]
    1142:	4c 8b 42 20          	mov    r8,QWORD PTR [rdx+0x20]
    1146:	48 8b 7a 28          	mov    rdi,QWORD PTR [rdx+0x28]
    114a:	48 8b 72 30          	mov    rsi,QWORD PTR [rdx+0x30]
    114e:	48 8b 42 40          	mov    rax,QWORD PTR [rdx+0x40]
    1152:	48 8b 52 38          	mov    rdx,QWORD PTR [rdx+0x38]
    1156:	48 bb 73 65 74 79 62 	movabs rbx,0x7465646279746573
    115d:	64 65 74 
    1160:	4c 31 db             	xor    rbx,r11
    1163:	49 be 61 72 65 6e 65 	movabs r14,0x6c7967656e657261
    116a:	67 79 6c 
    116d:	49 01 de             	add    r14,rbx
    1170:	c4 63 fb f0 fb 30    	rorx   r15,rbx,0x30
    1176:	4d 31 f7             	xor    r15,r14
    1179:	49 be c6 df de d7 e2 	movabs r14,0xded7d4e2d7dedfc6
    1180:	d4 d7 de 
    1183:	4d 01 fe             	add    r14,r15
    1186:	c4 43 fb f0 ff 2b    	rorx   r15,r15,0x2b
    118c:	4d 31 f7             	xor    r15,r14
    118f:	49 bc d0 ea 9f c1 6f 	movabs r12,0xa60c596fc19fead0
    1196:	59 0c a6 
    1199:	49 01 dc             	add    r12,rbx
    119c:	48 bb 25 73 de f0 74 	movabs rbx,0xe414a674f0de7325
    11a3:	a6 14 e4 
    11a6:	4c 31 e3             	xor    rbx,r12
    11a9:	c4 43 fb f0 e4 20    	rorx   r12,r12,0x20
    11af:	49 01 de             	add    r14,rbx
    11b2:	c4 e3 fb f0 db 33    	rorx   rbx,rbx,0x33
    11b8:	4c 31 f3             	xor    rbx,r14
    11bb:	c4 43 fb f0 f6 20    	rorx   r14,r14,0x20
    11c1:	4d 01 fc             	add    r12,r15
    11c4:	c4 43 fb f0 ff 30    	rorx   r15,r15,0x30
    11ca:	4d 31 e7             	xor    r15,r12
    11cd:	4d 01 fe             	add    r14,r15
    11d0:	c4 43 fb f0 ff 2b    	rorx   r15,r15,0x2b
    11d6:	4d 31 f7             	xor    r15,r14
    11d9:	49 01 dc             	add    r12,rbx
    11dc:	c4 e3 fb f0 db 2f    	rorx   rbx,rbx,0x2f
    11e2:	4c 31 e3             	xor    rbx,r12
    11e5:	c4 43 fb f0 e4 20    	rorx   r12,r12,0x20
    11eb:	4d 31 de             	xor    r14,r11
    11ee:	4d 31 d7             	xor    r15,r10
    11f1:	49 01 de             	add    r14,rbx
    11f4:	c4 63 fb f0 db 33    	rorx   r11,rbx,0x33
    11fa:	4d 31 f3             	xor    r11,r14
    11fd:	c4 c3 fb f0 de 20    	rorx   rbx,r14,0x20
    1203:	4d 01 fc             	add    r12,r15
    1206:	c4 43 fb f0 f7 30    	rorx   r14,r15,0x30
    120c:	4d 31 e6             	xor    r14,r12
    120f:	4c 01 f3             	add    rbx,r14
    1212:	c4 43 fb f0 f6 2b    	rorx   r14,r14,0x2b
    1218:	49 31 de             	xor    r14,rbx
    121b:	4d 01 dc             	add    r12,r11
    121e:	c4 43 fb f0 db 2f    	rorx   r11,r11,0x2f
    1224:	4d 31 e3             	xor    r11,r12
    1227:	c4 43 fb f0 fc 20    	rorx   r15,r12,0x20
    122d:	4c 01 db             	add    rbx,r11
    1230:	c4 43 fb f0 db 33    	rorx   r11,r11,0x33
    1236:	49 31 db             	xor    r11,rbx
    1239:	c4 e3 fb f0 db 20    	rorx   rbx,rbx,0x20
    123f:	4d 01 f7             	add    r15,r14
    1242:	c4 43 fb f0 f6 30    	rorx   r14,r14,0x30
    1248:	4d 31 fe             	xor    r14,r15
    124b:	4c 01 f3             	add    rbx,r14
    124e:	c4 43 fb f0 f6 2b    	rorx   r14,r14,0x2b
    1254:	49 31 de             	xor    r14,rbx
    1257:	4d 01 df             	add    r15,r11
    125a:	c4 43 fb f0 db 2f    	rorx   r11,r11,0x2f
    1260:	4d 31 fb             	xor    r11,r15
    1263:	c4 43 fb f0 ff 20    	rorx   r15,r15,0x20
    1269:	4c 31 d3             	xor    rbx,r10
    126c:	4d 31 ce             	xor    r14,r9
    126f:	4c 01 db             	add    rbx,r11
    1272:	c4 43 fb f0 d3 33    	rorx   r10,r11,0x33
    1278:	49 31 da             	xor    r10,rbx
    127b:	c4 63 fb f0 db 20    	rorx   r11,rbx,0x20
    1281:	4d 01 f7             	add    r15,r14
    1284:	c4 c3 fb f0 de 30    	rorx   rbx,r14,0x30
    128a:	4c 31 fb             	xor    rbx,r15
    128d:	49 01 db             	add    r11,rbx
    1290:	c4 e3 fb f0 db 2b    	rorx   rbx,rbx,0x2b
    1296:	4c 31 db             	xor    rbx,r11
    1299:	4d 01 d7             	add    r15,r10
    129c:	c4 43 fb f0 d2 2f    	rorx   r10,r10,0x2f
    12a2:	4d 31 fa             	xor    r10,r15
    12a5:	c4 43 fb f0 f7 20    	rorx   r14,r15,0x20
    12ab:	4d 01 d3             	add    r11,r10
    12ae:	c4 43 fb f0 d2 33    	rorx   r10,r10,0x33
    12b4:	4d 31 da             	xor    r10,r11
    12b7:	c4 43 fb f0 db 20    	rorx   r11,r11,0x20
    12bd:	49 01 de             	add    r14,rbx
    12c0:	c4 e3 fb f0 db 30    	rorx   rbx,rbx,0x30
    12c6:	4c 31 f3             	xor    rbx,r14
    12c9:	49 01 db             	add    r11,rbx
    12cc:	c4 e3 fb f0 db 2b    	rorx   rbx,rbx,0x2b
    12d2:	4c 31 db             	xor    rbx,r11
    12d5:	4d 01 d6             	add    r14,r10
    12d8:	c4 43 fb f0 d2 2f    	rorx   r10,r10,0x2f
    12de:	4d 31 f2             	xor    r10,r14
    12e1:	c4 43 fb f0 f6 20    	rorx   r14,r14,0x20
    12e7:	4d 31 cb             	xor    r11,r9
    12ea:	4c 31 c3             	xor    rbx,r8
    12ed:	4d 01 d3             	add    r11,r10
    12f0:	c4 43 fb f0 ca 33    	rorx   r9,r10,0x33
    12f6:	4d 31 d9             	xor    r9,r11
    12f9:	c4 43 fb f0 d3 20    	rorx   r10,r11,0x20
    12ff:	49 01 de             	add    r14,rbx
    1302:	c4 63 fb f0 db 30    	rorx   r11,rbx,0x30
    1308:	4d 31 f3             	xor    r11,r14
    130b:	4d 01 da             	add    r10,r11
    130e:	c4 43 fb f0 db 2b    	rorx   r11,r11,0x2b
    1314:	4d 31 d3             	xor    r11,r10
    1317:	4d 01 ce             	add    r14,r9
    131a:	c4 43 fb f0 c9 2f    	rorx   r9,r9,0x2f
    1320:	4d 31 f1             	xor    r9,r14
    1323:	c4 c3 fb f0 de 20    	rorx   rbx,r14,0x20
    1329:	4d 01 ca             	add    r10,r9
    132c:	c4 43 fb f0 c9 33    	rorx   r9,r9,0x33
    1332:	4d 31 d1             	xor    r9,r10
    1335:	c4 43 fb f0 d2 20    	rorx   r10,r10,0x20
    133b:	4c 01 db             	add    rbx,r11
    133e:	c4 43 fb f0 db 30    	rorx   r11,r11,0x30
    1344:	49 31 db             	xor    r11,rbx
    1347:	4d 01 da             	add    r10,r11
    134a:	c4 43 fb f0 db 2b    	rorx   r11,r11,0x2b
    1350:	4d 31 d3             	xor    r11,r10
    1353:	4c 01 cb             	add    rbx,r9
    1356:	c4 43 fb f0 c9 2f    	rorx   r9,r9,0x2f
    135c:	49 31 d9             	xor    r9,rbx
    135f:	c4 e3 fb f0 db 20    	rorx   rbx,rbx,0x20
    1365:	4d 31 c2             	xor    r10,r8
    1368:	49 31 fb             	xor    r11,rdi
    136b:	4d 01 ca             	add    r10,r9
    136e:	c4 43 fb f0 c1 33    	rorx   r8,r9,0x33
    1374:	4d 31 d0             	xor    r8,r10
    1377:	c4 43 fb f0 ca 20    	rorx   r9,r10,0x20
    137d:	4c 01 db             	add    rbx,r11
    1380:	c4 43 fb f0 d3 30    	rorx   r10,r11,0x30
    1386:	49 31 da             	xor    r10,rbx
    1389:	4d 01 d1             	add    r9,r10
    138c:	c4 43 fb f0 d2 2b    	rorx   r10,r10,0x2b
    1392:	4d 31 ca             	xor    r10,r9
    1395:	4c 01 c3             	add    rbx,r8
    1398:	c4 43 fb f0 c0 2f    	rorx   r8,r8,0x2f
    139e:	49 31 d8             	xor    r8,rbx
    13a1:	c4 63 fb f0 db 20    	rorx   r11,rbx,0x20
    13a7:	4d 01 c1             	add    r9,r8
    13aa:	c4 43 fb f0 c0 33    	rorx   r8,r8,0x33
    13b0:	4d 31 c8             	xor    r8,r9
    13b3:	c4 43 fb f0 c9 20    	rorx   r9,r9,0x20
    13b9:	4d 01 d3             	add    r11,r10
    13bc:	c4 43 fb f0 d2 30    	rorx   r10,r10,0x30
    13c2:	4d 31 da             	xor    r10,r11
    13c5:	4d 01 d1             	add    r9,r10
    13c8:	c4 43 fb f0 d2 2b    	rorx   r10,r10,0x2b
    13ce:	4d 31 ca             	xor    r10,r9
    13d1:	4d 01 c3             	add    r11,r8
    13d4:	c4 43 fb f0 c0 2f    	rorx   r8,r8,0x2f
    13da:	4d 31 d8             	xor    r8,r11
    13dd:	c4 43 fb f0 db 20    	rorx   r11,r11,0x20
    13e3:	49 31 f9             	xor    r9,rdi
    13e6:	49 31 f2             	xor    r10,rsi
    13e9:	4d 01 c1             	add    r9,r8
    13ec:	c4 c3 fb f0 f8 33    	rorx   rdi,r8,0x33
    13f2:	4c 31 cf             	xor    rdi,r9
    13f5:	c4 43 fb f0 c1 20    	rorx   r8,r9,0x20
    13fb:	4d 01 d3             	add    r11,r10
    13fe:	c4 43 fb f0 ca 30    	rorx   r9,r10,0x30
    1404:	4d 31 d9             	xor    r9,r11
    1407:	4d 01 c8             	add    r8,r9
    140a:	c4 43 fb f0 c9 2b    	rorx   r9,r9,0x2b
    1410:	4d 31 c1             	xor    r9,r8
    1413:	49 01 fb             	add    r11,rdi
    1416:	c4 e3 fb f0 ff 2f    	rorx   rdi,rdi,0x2f
    141c:	4c 31 df             	xor    rdi,r11
    141f:	c4 43 fb f0 d3 20    	rorx   r10,r11,0x20
    1425:	49 01 f8             	add    r8,rdi
    1428:	c4 e3 fb f0 ff 33    	rorx   rdi,rdi,0x33
    142e:	4c 31 c7             	xor    rdi,r8
    1431:	c4 43 fb f0 c0 20    	rorx   r8,r8,0x20
    1437:	4d 01 ca             	add    r10,r9
    143a:	c4 43 fb f0 c9 30    	rorx   r9,r9,0x30
    1440:	4d 31 d1             	xor    r9,r10
    1443:	4d 01 c8             	add    r8,r9
    1446:	c4 43 fb f0 c9 2b    	rorx   r9,r9,0x2b
    144c:	4d 31 c1             	xor    r9,r8
    144f:	49 01 fa             	add    r10,rdi
    1452:	c4 e3 fb f0 ff 2f    	rorx   rdi,rdi,0x2f
    1458:	4c 31 d7             	xor    rdi,r10
    145b:	c4 43 fb f0 d2 20    	rorx   r10,r10,0x20
    1461:	49 31 f0             	xor    r8,rsi
    1464:	49 31 d1             	xor    r9,rdx
    1467:	49 01 f8             	add    r8,rdi
    146a:	c4 e3 fb f0 f7 33    	rorx   rsi,rdi,0x33
    1470:	4c 31 c6             	xor    rsi,r8
    1473:	c4 c3 fb f0 f8 20    	rorx   rdi,r8,0x20
    1479:	4d 01 ca             	add    r10,r9
    147c:	c4 43 fb f0 c1 30    	rorx   r8,r9,0x30
    1482:	4d 31 d0             	xor    r8,r10
    1485:	4c 01 c7             	add    rdi,r8
    1488:	c4 43 fb f0 c0 2b    	rorx   r8,r8,0x2b
    148e:	49 31 f8             	xor    r8,rdi
    1491:	49 01 f2             	add    r10,rsi
    1494:	c4 e3 fb f0 f6 2f    	rorx   rsi,rsi,0x2f
    149a:	4c 31 d6             	xor    rsi,r10
    149d:	c4 43 fb f0 ca 20    	rorx   r9,r10,0x20
    14a3:	48 01 f7             	add    rdi,rsi
    14a6:	c4 e3 fb f0 f6 33    	rorx   rsi,rsi,0x33
    14ac:	48 31 fe             	xor    rsi,rdi
    14af:	c4 e3 fb f0 ff 20    	rorx   rdi,rdi,0x20
    14b5:	4d 01 c1             	add    r9,r8
    14b8:	c4 43 fb f0 c0 30    	rorx   r8,r8,0x30
    14be:	4d 31 c8             	xor    r8,r9
    14c1:	4c 01 c7             	add    rdi,r8
    14c4:	c4 43 fb f0 c0 2b    	rorx   r8,r8,0x2b
    14ca:	49 31 f8             	xor    r8,rdi
    14cd:	49 01 f1             	add    r9,rsi
    14d0:	c4 e3 fb f0 f6 2f    	rorx   rsi,rsi,0x2f
    14d6:	4c 31 ce             	xor    rsi,r9
    14d9:	c4 43 fb f0 c9 20    	rorx   r9,r9,0x20
    14df:	48 31 d7             	xor    rdi,rdx
    14e2:	49 31 c0             	xor    r8,rax
    14e5:	48 01 f7             	add    rdi,rsi
    14e8:	c4 e3 fb f0 d6 33    	rorx   rdx,rsi,0x33
    14ee:	48 31 fa             	xor    rdx,rdi
    14f1:	c4 e3 fb f0 f7 20    	rorx   rsi,rdi,0x20
    14f7:	4d 01 c1             	add    r9,r8
    14fa:	c4 c3 fb f0 f8 30    	rorx   rdi,r8,0x30
    1500:	4c 31 cf             	xor    rdi,r9
    1503:	48 01 fe             	add    rsi,rdi
    1506:	c4 e3 fb f0 ff 2b    	rorx   rdi,rdi,0x2b
    150c:	48 31 f7             	xor    rdi,rsi
    150f:	49 01 d1             	add    r9,rdx
    1512:	c4 e3 fb f0 d2 2f    	rorx   rdx,rdx,0x2f
    1518:	4c 31 ca             	xor    rdx,r9
    151b:	c4 43 fb f0 c1 20    	rorx   r8,r9,0x20
    1521:	48 01 d6             	add    rsi,rdx
    1524:	c4 e3 fb f0 d2 33    	rorx   rdx,rdx,0x33
    152a:	48 31 f2             	xor    rdx,rsi
    152d:	c4 e3 fb f0 f6 20    	rorx   rsi,rsi,0x20
    1533:	49 01 f8             	add    r8,rdi
    1536:	c4 e3 fb f0 ff 30    	rorx   rdi,rdi,0x30
    153c:	4c 31 c7             	xor    rdi,r8
    153f:	48 01 fe             	add    rsi,rdi
    1542:	c4 e3 fb f0 ff 2b    	rorx   rdi,rdi,0x2b
    1548:	48 31 f7             	xor    rdi,rsi
    154b:	49 01 d0             	add    r8,rdx
    154e:	c4 e3 fb f0 d2 2f    	rorx   rdx,rdx,0x2f
    1554:	4c 31 c2             	xor    rdx,r8
    1557:	c4 43 fb f0 c0 20    	rorx   r8,r8,0x20
    155d:	48 31 c6             	xor    rsi,rax
    1560:	49 81 f0 ff 00 00 00 	xor    r8,0xff
    1567:	48 01 d6             	add    rsi,rdx
    156a:	c4 e3 fb f0 c2 33    	rorx   rax,rdx,0x33
    1570:	48 31 f0             	xor    rax,rsi
    1573:	c4 e3 fb f0 d6 20    	rorx   rdx,rsi,0x20
    1579:	49 01 f8             	add    r8,rdi
    157c:	c4 e3 fb f0 f7 30    	rorx   rsi,rdi,0x30
    1582:	4c 31 c6             	xor    rsi,r8
    1585:	48 01 f2             	add    rdx,rsi
    1588:	c4 e3 fb f0 f6 2b    	rorx   rsi,rsi,0x2b
    158e:	48 31 d6             	xor    rsi,rdx
    1591:	49 01 c0             	add    r8,rax
    1594:	c4 e3 fb f0 c0 2f    	rorx   rax,rax,0x2f
    159a:	4c 31 c0             	xor    rax,r8
    159d:	c4 c3 fb f0 f8 20    	rorx   rdi,r8,0x20
    15a3:	48 01 c2             	add    rdx,rax
    15a6:	c4 e3 fb f0 c0 33    	rorx   rax,rax,0x33
    15ac:	48 31 d0             	xor    rax,rdx
    15af:	c4 e3 fb f0 d2 20    	rorx   rdx,rdx,0x20
    15b5:	48 01 f7             	add    rdi,rsi
    15b8:	c4 e3 fb f0 f6 30    	rorx   rsi,rsi,0x30
    15be:	48 31 fe             	xor    rsi,rdi
    15c1:	48 01 f2             	add    rdx,rsi
    15c4:	c4 e3 fb f0 f6 2b    	rorx   rsi,rsi,0x2b
    15ca:	48 31 d6             	xor    rsi,rdx
    15cd:	48 01 c7             	add    rdi,rax
    15d0:	c4 e3 fb f0 c0 2f    	rorx   rax,rax,0x2f
    15d6:	48 31 f8             	xor    rax,rdi
    15d9:	c4 e3 fb f0 ff 20    	rorx   rdi,rdi,0x20
    15df:	48 01 c2             	add    rdx,rax
    15e2:	c4 e3 fb f0 c0 33    	rorx   rax,rax,0x33
    15e8:	48 31 d0             	xor    rax,rdx
    15eb:	c4 e3 fb f0 d2 20    	rorx   rdx,rdx,0x20
    15f1:	48 01 f7             	add    rdi,rsi
    15f4:	c4 e3 fb f0 f6 30    	rorx   rsi,rsi,0x30
    15fa:	48 31 fe             	xor    rsi,rdi
    15fd:	48 01 f2             	add    rdx,rsi
    1600:	c4 e3 fb f0 f6 2b    	rorx   rsi,rsi,0x2b
    1606:	48 31 d6             	xor    rsi,rdx
    1609:	48 01 c7             	add    rdi,rax
    160c:	c4 e3 fb f0 c0 2f    	rorx   rax,rax,0x2f
    1612:	48 31 f8             	xor    rax,rdi
    1615:	c4 e3 fb f0 ff 20    	rorx   rdi,rdi,0x20
    161b:	48 01 c2             	add    rdx,rax
    161e:	c4 e3 fb f0 c0 33    	rorx   rax,rax,0x33
    1624:	48 31 d0             	xor    rax,rdx
    1627:	48 01 f7             	add    rdi,rsi
    162a:	c4 e3 fb f0 d6 30    	rorx   rdx,rsi,0x30
    1630:	48 31 fa             	xor    rdx,rdi
    1633:	c4 e3 fb f0 d2 2b    	rorx   rdx,rdx,0x2b
    1639:	48 01 c7             	add    rdi,rax
    163c:	c4 e3 fb f0 c0 2f    	rorx   rax,rax,0x2f
    1642:	48 31 d0             	xor    rax,rdx
    1645:	c4 e3 fb f0 d7 20    	rorx   rdx,rdi,0x20
    164b:	48 31 fa             	xor    rdx,rdi
    164e:	48 31 c2             	xor    rdx,rax
    1651:	48 89 11             	mov    QWORD PTR [rcx],rdx
    1654:	b8 02 00 00 00       	mov    eax,0x2
    1659:	5b                   	pop    rbx
    165a:	41 5c                	pop    r12
    165c:	41 5e                	pop    r14
    165e:	41 5f                	pop    r15
    1660:	c3                   	ret

Disassembly of section .fini:

0000000000001664 <_fini>:
    1664:	f3 0f 1e fa          	endbr64
    1668:	48 83 ec 08          	sub    rsp,0x8
    166c:	48 83 c4 08          	add    rsp,0x8
    1670:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 48 00 00 00 	sub    rsp,0x48
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 57 00          	mov    rdx,QWORD PTR [rdi+0x0]
  24:	48 39 f2             	cmp    rdx,rsi
  27:	0f 87 8a 0d 00 00    	ja     0xdb7
  2d:	48 89 d7             	mov    rdi,rdx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 7a 0d 00 00    	ja     0xdb7
  3d:	48 89 d7             	mov    rdi,rdx
  40:	48 83 c7 48          	add    rdi,0x48
  44:	48 39 f7             	cmp    rdi,rsi
  47:	0f 87 6a 0d 00 00    	ja     0xdb7
  4d:	48 0f b6 7a 09       	movzx  rdi,BYTE PTR [rdx+0x9]
  52:	48 c1 e7 08          	shl    rdi,0x8
  56:	48 0f b6 72 08       	movzx  rsi,BYTE PTR [rdx+0x8]
  5b:	48 09 f7             	or     rdi,rsi
  5e:	48 0f b6 72 0a       	movzx  rsi,BYTE PTR [rdx+0xa]
  63:	48 c1 e6 10          	shl    rsi,0x10
  67:	48 09 fe             	or     rsi,rdi
  6a:	48 0f b6 7a 0b       	movzx  rdi,BYTE PTR [rdx+0xb]
  6f:	48 c1 e7 18          	shl    rdi,0x18
  73:	48 09 f7             	or     rdi,rsi
  76:	48 0f b6 4a 31       	movzx  rcx,BYTE PTR [rdx+0x31]
  7b:	48 c1 e1 08          	shl    rcx,0x8
  7f:	48 0f b6 72 30       	movzx  rsi,BYTE PTR [rdx+0x30]
  84:	48 09 f1             	or     rcx,rsi
  87:	4c 0f b6 42 39       	movzx  r8,BYTE PTR [rdx+0x39]
  8c:	49 c1 e0 08          	shl    r8,0x8
  90:	48 0f b6 72 38       	movzx  rsi,BYTE PTR [rdx+0x38]
  95:	49 09 f0             	or     r8,rsi
  98:	48 0f b6 42 41       	movzx  rax,BYTE PTR [rdx+0x41]
  9d:	48 c1 e0 08          	shl    rax,0x8
  a1:	48 0f b6 72 40       	movzx  rsi,BYTE PTR [rdx+0x40]
  a6:	48 09 f0             	or     rax,rsi
  a9:	48 0f b6 72 29       	movzx  rsi,BYTE PTR [rdx+0x29]
  ae:	48 c1 e6 08          	shl    rsi,0x8
  b2:	49 89 d7             	mov    r15,rdx
  b5:	49 0f b6 57 28       	movzx  rdx,BYTE PTR [r15+0x28]
  ba:	48 09 d6             	or     rsi,rdx
  bd:	49 0f b6 5f 0c       	movzx  rbx,BYTE PTR [r15+0xc]
  c2:	48 c1 e3 20          	shl    rbx,0x20
  c6:	48 09 fb             	or     rbx,rdi
  c9:	49 0f b6 7f 11       	movzx  rdi,BYTE PTR [r15+0x11]
  ce:	48 c1 e7 08          	shl    rdi,0x8
  d2:	49 0f b6 57 10       	movzx  rdx,BYTE PTR [r15+0x10]
  d7:	48 09 d7             	or     rdi,rdx
  da:	49 0f b6 57 42       	movzx  rdx,BYTE PTR [r15+0x42]
  df:	48 c1 e2 10          	shl    rdx,0x10
  e3:	48 09 c2             	or     rdx,rax
  e6:	49 0f b6 47 3a       	movzx  rax,BYTE PTR [r15+0x3a]
  eb:	48 c1 e0 10          	shl    rax,0x10
  ef:	4c 09 c0             	or     rax,r8
  f2:	4d 0f b6 47 32       	movzx  r8,BYTE PTR [r15+0x32]
  f7:	49 c1 e0 10          	shl    r8,0x10
  fb:	49 09 c8             	or     r8,rcx
  fe:	4d 0f b6 6f 21       	movzx  r13,BYTE PTR [r15+0x21]
 103:	49 c1 e5 08          	shl    r13,0x8
 107:	49 0f b6 4f 20       	movzx  rcx,BYTE PTR [r15+0x20]
 10c:	49 09 cd             	or     r13,rcx
 10f:	4d 0f b6 77 0d       	movzx  r14,BYTE PTR [r15+0xd]
 114:	49 c1 e6 28          	shl    r14,0x28
 118:	49 09 de             	or     r14,rbx
 11b:	49 0f b6 4f 0e       	movzx  rcx,BYTE PTR [r15+0xe]
 120:	48 c1 e1 30          	shl    rcx,0x30
 124:	4c 09 f1             	or     rcx,r14
 127:	49 0f b6 5f 2a       	movzx  rbx,BYTE PTR [r15+0x2a]
 12c:	48 c1 e3 10          	shl    rbx,0x10
 130:	48 09 f3             	or     rbx,rsi
 133:	4d 0f b6 77 22       	movzx  r14,BYTE PTR [r15+0x22]
 138:	49 c1 e6 10          	shl    r14,0x10
 13c:	4d 09 ee             	or     r14,r13
 13f:	49 0f b6 77 33       	movzx  rsi,BYTE PTR [r15+0x33]
 144:	48 c1 e6 18          	shl    rsi,0x18
 148:	4c 09 c6             	or     rsi,r8
 14b:	4d 0f b6 47 3b       	movzx  r8,BYTE PTR [r15+0x3b]
 150:	49 c1 e0 18          	shl    r8,0x18
 154:	49 09 c0             	or     r8,rax
 157:	4d 0f b6 6f 43       	movzx  r13,BYTE PTR [r15+0x43]
 15c:	4c 89 f8             	mov    rax,r15
 15f:	49 c1 e5 18          	shl    r13,0x18
 163:	49 09 d5             	or     r13,rdx
 166:	4c 0f b6 78 12       	movzx  r15,BYTE PTR [rax+0x12]
 16b:	49 c1 e7 10          	shl    r15,0x10
 16f:	49 09 ff             	or     r15,rdi
 172:	48 0f b6 78 19       	movzx  rdi,BYTE PTR [rax+0x19]
 177:	48 c1 e7 08          	shl    rdi,0x8
 17b:	48 0f b6 50 18       	movzx  rdx,BYTE PTR [rax+0x18]
 180:	48 09 d7             	or     rdi,rdx
 183:	48 0f b6 50 23       	movzx  rdx,BYTE PTR [rax+0x23]
 188:	48 c1 e2 18          	shl    rdx,0x18
 18c:	4c 09 f2             	or     rdx,r14
 18f:	49 89 c6             	mov    r14,rax
 192:	49 0f b6 46 2b       	movzx  rax,BYTE PTR [r14+0x2b]
 197:	48 c1 e0 18          	shl    rax,0x18
 19b:	48 09 d8             	or     rax,rbx
 19e:	49 0f b6 5e 0f       	movzx  rbx,BYTE PTR [r14+0xf]
 1a3:	48 c1 e3 38          	shl    rbx,0x38
 1a7:	48 09 cb             	or     rbx,rcx
 1aa:	48 89 5d f0          	mov    QWORD PTR [rbp-0x10],rbx
 1ae:	49 0f b6 4e 1a       	movzx  rcx,BYTE PTR [r14+0x1a]
 1b3:	48 c1 e1 10          	shl    rcx,0x10
 1b7:	48 09 f9             	or     rcx,rdi
 1ba:	49 0f b6 7e 13       	movzx  rdi,BYTE PTR [r14+0x13]
 1bf:	48 c1 e7 18          	shl    rdi,0x18
 1c3:	4c 09 ff             	or     rdi,r15
 1c6:	48 89 7d e0          	mov    QWORD PTR [rbp-0x20],rdi
 1ca:	49 0f b6 7e 44       	movzx  rdi,BYTE PTR [r14+0x44]
 1cf:	48 c1 e7 20          	shl    rdi,0x20
 1d3:	4c 09 ef             	or     rdi,r13
 1d6:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
 1da:	49 0f b6 5e 3c       	movzx  rbx,BYTE PTR [r14+0x3c]
 1df:	48 c1 e3 20          	shl    rbx,0x20
 1e3:	4c 09 c3             	or     rbx,r8
 1e6:	4d 0f b6 7e 34       	movzx  r15,BYTE PTR [r14+0x34]
 1eb:	49 c1 e7 20          	shl    r15,0x20
 1ef:	49 09 f7             	or     r15,rsi
 1f2:	49 0f b6 76 1b       	movzx  rsi,BYTE PTR [r14+0x1b]
 1f7:	48 c1 e6 18          	shl    rsi,0x18
 1fb:	48 09 ce             	or     rsi,rcx
 1fe:	48 bf 73 65 74 79 62 	movabs rdi,0x7465646279746573
 205:	64 65 74 
 208:	4c 8b 6d f0          	mov    r13,QWORD PTR [rbp-0x10]
 20c:	49 31 fd             	xor    r13,rdi
 20f:	4c 89 6d f8          	mov    QWORD PTR [rbp-0x8],r13
 213:	4c 89 ef             	mov    rdi,r13
 216:	48 c1 ef 30          	shr    rdi,0x30
 21a:	49 c1 e5 10          	shl    r13,0x10
 21e:	49 09 fd             	or     r13,rdi
 221:	4d 0f b6 46 2c       	movzx  r8,BYTE PTR [r14+0x2c]
 226:	49 c1 e0 20          	shl    r8,0x20
 22a:	49 09 c0             	or     r8,rax
 22d:	49 0f b6 4e 24       	movzx  rcx,BYTE PTR [r14+0x24]
 232:	48 c1 e1 20          	shl    rcx,0x20
 236:	48 09 d1             	or     rcx,rdx
 239:	49 0f b6 7e 1c       	movzx  rdi,BYTE PTR [r14+0x1c]
 23e:	48 c1 e7 20          	shl    rdi,0x20
 242:	48 09 f7             	or     rdi,rsi
 245:	49 0f b6 76 35       	movzx  rsi,BYTE PTR [r14+0x35]
 24a:	48 c1 e6 28          	shl    rsi,0x28
 24e:	4c 09 fe             	or     rsi,r15
 251:	48 89 75 d0          	mov    QWORD PTR [rbp-0x30],rsi
 255:	49 0f b6 46 3d       	movzx  rax,BYTE PTR [r14+0x3d]
 25a:	48 c1 e0 28          	shl    rax,0x28
 25e:	48 09 d8             	or     rax,rbx
 261:	49 0f b6 56 45       	movzx  rdx,BYTE PTR [r14+0x45]
 266:	48 c1 e2 28          	shl    rdx,0x28
 26a:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
 26e:	48 09 f2             	or     rdx,rsi
 271:	49 0f b6 5e 14       	movzx  rbx,BYTE PTR [r14+0x14]
 276:	48 c1 e3 20          	shl    rbx,0x20
 27a:	48 8b 75 e0          	mov    rsi,QWORD PTR [rbp-0x20]
 27e:	48 09 f3             	or     rbx,rsi
 281:	49 0f b6 76 1d       	movzx  rsi,BYTE PTR [r14+0x1d]
 286:	48 c1 e6 28          	shl    rsi,0x28
 28a:	48 09 fe             	or     rsi,rdi
 28d:	48 89 75 c8          	mov    QWORD PTR [rbp-0x38],rsi
 291:	4d 0f b6 7e 25       	movzx  r15,BYTE PTR [r14+0x25]
 296:	49 c1 e7 28          	shl    r15,0x28
 29a:	49 09 cf             	or     r15,rcx
 29d:	49 0f b6 76 2d       	movzx  rsi,BYTE PTR [r14+0x2d]
 2a2:	48 c1 e6 28          	shl    rsi,0x28
 2a6:	4c 09 c6             	or     rsi,r8
 2a9:	48 b9 61 72 65 6e 65 	movabs rcx,0x6c7967656e657261
 2b0:	67 79 6c 
 2b3:	48 8b 7d f8          	mov    rdi,QWORD PTR [rbp-0x8]
 2b7:	49 89 f8             	mov    r8,rdi
 2ba:	49 01 c8             	add    r8,rcx
 2bd:	4d 31 c5             	xor    r13,r8
 2c0:	49 0f b6 4e 15       	movzx  rcx,BYTE PTR [r14+0x15]
 2c5:	48 c1 e1 28          	shl    rcx,0x28
 2c9:	48 09 d9             	or     rcx,rbx
 2cc:	49 b8 d0 ea 9f c1 6f 	movabs r8,0xa60c596fc19fead0
 2d3:	59 0c a6 
 2d6:	4c 01 c7             	add    rdi,r8
 2d9:	48 89 7d f8          	mov    QWORD PTR [rbp-0x8],rdi
 2dd:	4c 89 f3             	mov    rbx,r14
 2e0:	48 0f b6 7b 46       	movzx  rdi,BYTE PTR [rbx+0x46]
 2e5:	48 c1 e7 30          	shl    rdi,0x30
 2e9:	48 09 d7             	or     rdi,rdx
 2ec:	48 89 7d e0          	mov    QWORD PTR [rbp-0x20],rdi
 2f0:	48 0f b6 7b 3e       	movzx  rdi,BYTE PTR [rbx+0x3e]
 2f5:	48 c1 e7 30          	shl    rdi,0x30
 2f9:	48 09 c7             	or     rdi,rax
 2fc:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
 300:	48 0f b6 7b 36       	movzx  rdi,BYTE PTR [rbx+0x36]
 305:	48 c1 e7 30          	shl    rdi,0x30
 309:	48 8b 55 d0          	mov    rdx,QWORD PTR [rbp-0x30]
 30d:	48 09 d7             	or     rdi,rdx
 310:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
 314:	4c 0f b6 73 2e       	movzx  r14,BYTE PTR [rbx+0x2e]
 319:	49 c1 e6 30          	shl    r14,0x30
 31d:	49 09 f6             	or     r14,rsi
 320:	4c 0f b6 43 26       	movzx  r8,BYTE PTR [rbx+0x26]
 325:	49 c1 e0 30          	shl    r8,0x30
 329:	4d 09 f8             	or     r8,r15
 32c:	48 0f b6 53 1e       	movzx  rdx,BYTE PTR [rbx+0x1e]
 331:	48 c1 e2 30          	shl    rdx,0x30
 335:	48 8b 7d c8          	mov    rdi,QWORD PTR [rbp-0x38]
 339:	48 09 fa             	or     rdx,rdi
 33c:	48 0f b6 7b 16       	movzx  rdi,BYTE PTR [rbx+0x16]
 341:	48 c1 e7 30          	shl    rdi,0x30
 345:	48 09 cf             	or     rdi,rcx
 348:	48 b9 c6 df de d7 e2 	movabs rcx,0xded7d4e2d7dedfc6
 34f:	d4 d7 de 
 352:	4c 89 ee             	mov    rsi,r13
 355:	48 01 ce             	add    rsi,rcx
 358:	4c 89 e9             	mov    rcx,r13
 35b:	48 c1 e9 2b          	shr    rcx,0x2b
 35f:	49 c1 e5 15          	shl    r13,0x15
 363:	49 09 cd             	or     r13,rcx
 366:	48 b8 25 73 de f0 74 	movabs rax,0xe414a674f0de7325
 36d:	a6 14 e4 
 370:	48 8b 4d f8          	mov    rcx,QWORD PTR [rbp-0x8]
 374:	48 31 c1             	xor    rcx,rax
 377:	48 89 c8             	mov    rax,rcx
 37a:	48 c1 e8 33          	shr    rax,0x33
 37e:	49 89 cf             	mov    r15,rcx
 381:	49 c1 e7 0d          	shl    r15,0xd
 385:	49 09 c7             	or     r15,rax
 388:	48 89 5d e8          	mov    QWORD PTR [rbp-0x18],rbx
 38c:	48 0f b6 43 17       	movzx  rax,BYTE PTR [rbx+0x17]
 391:	48 c1 e0 38          	shl    rax,0x38
 395:	48 09 f8             	or     rax,rdi
 398:	48 0f b6 7b 1f       	movzx  rdi,BYTE PTR [rbx+0x1f]
 39d:	48 c1 e7 38          	shl    rdi,0x38
 3a1:	48 09 d7             	or     rdi,rdx
 3a4:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
 3a8:	48 0f b6 7b 27       	movzx  rdi,BYTE PTR [rbx+0x27]
 3ad:	48 c1 e7 38          	shl    rdi,0x38
 3b1:	4c 09 c7             	or     rdi,r8
 3b4:	48 89 7d c0          	mov    QWORD PTR [rbp-0x40],rdi
 3b8:	48 0f b6 7b 2f       	movzx  rdi,BYTE PTR [rbx+0x2f]
 3bd:	48 c1 e7 38          	shl    rdi,0x38
 3c1:	4c 09 f7             	or     rdi,r14
 3c4:	48 89 7d c8          	mov    QWORD PTR [rbp-0x38],rdi
 3c8:	48 0f b6 7b 37       	movzx  rdi,BYTE PTR [rbx+0x37]
 3cd:	48 c1 e7 38          	shl    rdi,0x38
 3d1:	48 8b 55 d0          	mov    rdx,QWORD PTR [rbp-0x30]
 3d5:	48 09 d7             	or     rdi,rdx
 3d8:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
 3dc:	48 0f b6 7b 3f       	movzx  rdi,BYTE PTR [rbx+0x3f]
 3e1:	48 c1 e7 38          	shl    rdi,0x38
 3e5:	48 8b 55 d8          	mov    rdx,QWORD PTR [rbp-0x28]
 3e9:	48 09 d7             	or     rdi,rdx
 3ec:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
 3f0:	48 0f b6 7b 47       	movzx  rdi,BYTE PTR [rbx+0x47]
 3f5:	48 c1 e7 38          	shl    rdi,0x38
 3f9:	48 8b 55 e0          	mov    rdx,QWORD PTR [rbp-0x20]
 3fd:	48 09 d7             	or     rdi,rdx
 400:	48 89 7d e0          	mov    QWORD PTR [rbp-0x20],rdi
 404:	49 31 f5             	xor    r13,rsi
 407:	48 01 ce             	add    rsi,rcx
 40a:	4c 89 ef             	mov    rdi,r13
 40d:	48 c1 ef 30          	shr    rdi,0x30
 411:	4d 89 ee             	mov    r14,r13
 414:	49 c1 e6 10          	shl    r14,0x10
 418:	49 09 fe             	or     r14,rdi
 41b:	48 89 f7             	mov    rdi,rsi
 41e:	4c 31 ff             	xor    rdi,r15
 421:	48 89 f9             	mov    rcx,rdi
 424:	48 c1 e9 2f          	shr    rcx,0x2f
 428:	48 89 fa             	mov    rdx,rdi
 42b:	48 c1 e2 11          	shl    rdx,0x11
 42f:	48 09 ca             	or     rdx,rcx
 432:	4c 8b 45 f8          	mov    r8,QWORD PTR [rbp-0x8]
 436:	4c 89 c1             	mov    rcx,r8
 439:	48 c1 e9 20          	shr    rcx,0x20
 43d:	49 c1 e0 20          	shl    r8,0x20
 441:	49 09 c8             	or     r8,rcx
 444:	4d 01 c5             	add    r13,r8
 447:	4d 31 ee             	xor    r14,r13
 44a:	49 01 fd             	add    r13,rdi
 44d:	4c 31 ea             	xor    rdx,r13
 450:	48 89 d7             	mov    rdi,rdx
 453:	48 c1 ef 33          	shr    rdi,0x33
 457:	48 89 d1             	mov    rcx,rdx
 45a:	48 c1 e1 0d          	shl    rcx,0xd
 45e:	48 09 f9             	or     rcx,rdi
 461:	48 89 f7             	mov    rdi,rsi
 464:	48 c1 ef 20          	shr    rdi,0x20
 468:	48 c1 e6 20          	shl    rsi,0x20
 46c:	48 09 fe             	or     rsi,rdi
 46f:	4d 89 f0             	mov    r8,r14
 472:	49 01 f0             	add    r8,rsi
 475:	4c 89 c6             	mov    rsi,r8
 478:	48 8b 7d f0          	mov    rdi,QWORD PTR [rbp-0x10]
 47c:	48 31 fe             	xor    rsi,rdi
 47f:	48 01 d6             	add    rsi,rdx
 482:	48 89 f7             	mov    rdi,rsi
 485:	48 31 cf             	xor    rdi,rcx
 488:	48 89 fa             	mov    rdx,rdi
 48b:	48 c1 ea 2f          	shr    rdx,0x2f
 48f:	48 89 f9             	mov    rcx,rdi
 492:	48 c1 e1 11          	shl    rcx,0x11
 496:	48 09 d1             	or     rcx,rdx
 499:	4c 89 ea             	mov    rdx,r13
 49c:	48 c1 ea 20          	shr    rdx,0x20
 4a0:	49 c1 e5 20          	shl    r13,0x20
 4a4:	49 09 d5             	or     r13,rdx
 4a7:	4c 89 f2             	mov    rdx,r14
 4aa:	48 c1 ea 2b          	shr    rdx,0x2b
 4ae:	49 c1 e6 15          	shl    r14,0x15
 4b2:	49 09 d6             	or     r14,rdx
 4b5:	4d 31 c6             	xor    r14,r8
 4b8:	49 31 c6             	xor    r14,rax
 4bb:	4c 89 f2             	mov    rdx,r14
 4be:	4c 01 ea             	add    rdx,r13
 4c1:	4d 89 f0             	mov    r8,r14
 4c4:	49 c1 e8 30          	shr    r8,0x30
 4c8:	49 c1 e6 10          	shl    r14,0x10
 4cc:	4d 09 c6             	or     r14,r8
 4cf:	49 31 d6             	xor    r14,rdx
 4d2:	48 01 fa             	add    rdx,rdi
 4d5:	49 89 d0             	mov    r8,rdx
 4d8:	49 31 c8             	xor    r8,rcx
 4db:	4c 89 c7             	mov    rdi,r8
 4de:	48 c1 ef 33          	shr    rdi,0x33
 4e2:	4c 89 c1             	mov    rcx,r8
 4e5:	48 c1 e1 0d          	shl    rcx,0xd
 4e9:	48 09 f9             	or     rcx,rdi
 4ec:	4c 89 f3             	mov    rbx,r14
 4ef:	48 c1 eb 2b          	shr    rbx,0x2b
 4f3:	4c 89 f7             	mov    rdi,r14
 4f6:	48 c1 e7 15          	shl    rdi,0x15
 4fa:	48 09 df             	or     rdi,rbx
 4fd:	48 89 f3             	mov    rbx,rsi
 500:	48 c1 eb 20          	shr    rbx,0x20
 504:	48 c1 e6 20          	shl    rsi,0x20
 508:	48 09 de             	or     rsi,rbx
 50b:	49 01 f6             	add    r14,rsi
 50e:	4c 31 f7             	xor    rdi,r14
 511:	4d 01 c6             	add    r14,r8
 514:	4c 31 f1             	xor    rcx,r14
 517:	48 89 ce             	mov    rsi,rcx
 51a:	48 c1 ee 2f          	shr    rsi,0x2f
 51e:	49 89 c8             	mov    r8,rcx
 521:	49 c1 e0 11          	shl    r8,0x11
 525:	49 09 f0             	or     r8,rsi
 528:	48 89 fb             	mov    rbx,rdi
 52b:	48 c1 eb 30          	shr    rbx,0x30
 52f:	48 89 fe             	mov    rsi,rdi
 532:	48 c1 e6 10          	shl    rsi,0x10
 536:	48 09 de             	or     rsi,rbx
 539:	48 89 d3             	mov    rbx,rdx
 53c:	48 c1 eb 20          	shr    rbx,0x20
 540:	48 c1 e2 20          	shl    rdx,0x20
 544:	48 09 da             	or     rdx,rbx
 547:	48 01 d7             	add    rdi,rdx
 54a:	48 31 fe             	xor    rsi,rdi
 54d:	48 01 cf             	add    rdi,rcx
 550:	49 31 f8             	xor    r8,rdi
 553:	4c 89 c2             	mov    rdx,r8
 556:	48 c1 ea 33          	shr    rdx,0x33
 55a:	4c 89 c3             	mov    rbx,r8
 55d:	48 c1 e3 0d          	shl    rbx,0xd
 561:	48 09 d3             	or     rbx,rdx
 564:	4c 89 f2             	mov    rdx,r14
 567:	48 c1 ea 20          	shr    rdx,0x20
 56b:	49 c1 e6 20          	shl    r14,0x20
 56f:	49 09 d6             	or     r14,rdx
 572:	48 89 f1             	mov    rcx,rsi
 575:	4c 01 f1             	add    rcx,r14
 578:	48 89 ca             	mov    rdx,rcx
 57b:	48 31 c2             	xor    rdx,rax
 57e:	4c 01 c2             	add    rdx,r8
 581:	49 89 d0             	mov    r8,rdx
 584:	49 31 d8             	xor    r8,rbx
 587:	4c 89 c3             	mov    rbx,r8
 58a:	48 c1 eb 2f          	shr    rbx,0x2f
 58e:	4c 89 c0             	mov    rax,r8
 591:	48 c1 e0 11          	shl    rax,0x11
 595:	48 09 d8             	or     rax,rbx
 598:	48 89 fb             	mov    rbx,rdi
 59b:	48 c1 eb 20          	shr    rbx,0x20
 59f:	48 c1 e7 20          	shl    rdi,0x20
 5a3:	48 09 df             	or     rdi,rbx
 5a6:	48 89 f3             	mov    rbx,rsi
 5a9:	48 c1 eb 2b          	shr    rbx,0x2b
 5ad:	48 c1 e6 15          	shl    rsi,0x15
 5b1:	48 09 de             	or     rsi,rbx
 5b4:	48 31 ce             	xor    rsi,rcx
 5b7:	4c 8b 6d b8          	mov    r13,QWORD PTR [rbp-0x48]
 5bb:	4c 31 ee             	xor    rsi,r13
 5be:	48 89 f1             	mov    rcx,rsi
 5c1:	48 01 f9             	add    rcx,rdi
 5c4:	48 89 f7             	mov    rdi,rsi
 5c7:	48 c1 ef 30          	shr    rdi,0x30
 5cb:	48 c1 e6 10          	shl    rsi,0x10
 5cf:	48 09 fe             	or     rsi,rdi
 5d2:	48 31 ce             	xor    rsi,rcx
 5d5:	4c 01 c1             	add    rcx,r8
 5d8:	48 89 cb             	mov    rbx,rcx
 5db:	48 31 c3             	xor    rbx,rax
 5de:	48 89 df             	mov    rdi,rbx
 5e1:	48 c1 ef 33          	shr    rdi,0x33
 5e5:	49 89 d8             	mov    r8,rbx
 5e8:	49 c1 e0 0d          	shl    r8,0xd
 5ec:	49 09 f8             	or     r8,rdi
 5ef:	48 89 f0             	mov    rax,rsi
 5f2:	48 c1 e8 2b          	shr    rax,0x2b
 5f6:	48 89 f7             	mov    rdi,rsi
 5f9:	48 c1 e7 15          	shl    rdi,0x15
 5fd:	48 09 c7             	or     rdi,rax
 600:	48 89 d0             	mov    rax,rdx
 603:	48 c1 e8 20          	shr    rax,0x20
 607:	48 c1 e2 20          	shl    rdx,0x20
 60b:	48 09 c2             	or     rdx,rax
 60e:	48 01 d6             	add    rsi,rdx
 611:	48 31 f7             	xor    rdi,rsi
 614:	48 01 de             	add    rsi,rbx
 617:	49 31 f0             	xor    r8,rsi
 61a:	4c 89 c2             	mov    rdx,r8
 61d:	48 c1 ea 2f          	shr    rdx,0x2f
 621:	4c 89 c0             	mov    rax,r8
 624:	48 c1 e0 11          	shl    rax,0x11
 628:	48 09 d0             	or     rax,rdx
 62b:	48 89 fb             	mov    rbx,rdi
 62e:	48 c1 eb 30          	shr    rbx,0x30
 632:	48 89 fa             	mov    rdx,rdi
 635:	48 c1 e2 10          	shl    rdx,0x10
 639:	48 09 da             	or     rdx,rbx
 63c:	48 89 cb             	mov    rbx,rcx
 63f:	48 c1 eb 20          	shr    rbx,0x20
 643:	48 c1 e1 20          	shl    rcx,0x20
 647:	48 09 d9             	or     rcx,rbx
 64a:	48 01 cf             	add    rdi,rcx
 64d:	48 31 fa             	xor    rdx,rdi
 650:	4c 01 c7             	add    rdi,r8
 653:	48 31 f8             	xor    rax,rdi
 656:	48 89 c1             	mov    rcx,rax
 659:	48 c1 e9 33          	shr    rcx,0x33
 65d:	48 89 c3             	mov    rbx,rax
 660:	48 c1 e3 0d          	shl    rbx,0xd
 664:	48 09 cb             	or     rbx,rcx
 667:	48 89 f1             	mov    rcx,rsi
 66a:	48 c1 e9 20          	shr    rcx,0x20
 66e:	48 c1 e6 20          	shl    rsi,0x20
 672:	48 09 ce             	or     rsi,rcx
 675:	48 89 d1             	mov    rcx,rdx
 678:	48 01 f1             	add    rcx,rsi
 67b:	48 89 ce             	mov    rsi,rcx
 67e:	4c 31 ee             	xor    rsi,r13
 681:	48 01 c6             	add    rsi,rax
 684:	49 89 f0             	mov    r8,rsi
 687:	49 31 d8             	xor    r8,rbx
 68a:	4c 89 c3             	mov    rbx,r8
 68d:	48 c1 eb 2f          	shr    rbx,0x2f
 691:	4c 89 c0             	mov    rax,r8
 694:	48 c1 e0 11          	shl    rax,0x11
 698:	48 09 d8             	or     rax,rbx
 69b:	48 89 fb             	mov    rbx,rdi
 69e:	48 c1 eb 20          	shr    rbx,0x20
 6a2:	48 c1 e7 20          	shl    rdi,0x20
 6a6:	48 09 df             	or     rdi,rbx
 6a9:	48 89 d3             	mov    rbx,rdx
 6ac:	48 c1 eb 2b          	shr    rbx,0x2b
 6b0:	48 c1 e2 15          	shl    rdx,0x15
 6b4:	48 09 da             	or     rdx,rbx
 6b7:	48 31 ca             	xor    rdx,rcx
 6ba:	4c 8b 6d c0          	mov    r13,QWORD PTR [rbp-0x40]
 6be:	4c 31 ea             	xor    rdx,r13
 6c1:	48 89 d1             	mov    rcx,rdx
 6c4:	48 01 f9             	add    rcx,rdi
 6c7:	48 89 d7             	mov    rdi,rdx
 6ca:	48 c1 ef 30          	shr    rdi,0x30
 6ce:	48 c1 e2 10          	shl    rdx,0x10
 6d2:	48 09 fa             	or     rdx,rdi
 6d5:	48 31 ca             	xor    rdx,rcx
 6d8:	4c 01 c1             	add    rcx,r8
 6db:	48 89 cb             	mov    rbx,rcx
 6de:	48 31 c3             	xor    rbx,rax
 6e1:	48 89 df             	mov    rdi,rbx
 6e4:	48 c1 ef 33          	shr    rdi,0x33
 6e8:	49 89 d8             	mov    r8,rbx
 6eb:	49 c1 e0 0d          	shl    r8,0xd
 6ef:	49 09 f8             	or     r8,rdi
 6f2:	48 89 d0             	mov    rax,rdx
 6f5:	48 c1 e8 2b          	shr    rax,0x2b
 6f9:	48 89 d7             	mov    rdi,rdx
 6fc:	48 c1 e7 15          	shl    rdi,0x15
 700:	48 09 c7             	or     rdi,rax
 703:	48 89 f0             	mov    rax,rsi
 706:	48 c1 e8 20          	shr    rax,0x20
 70a:	48 c1 e6 20          	shl    rsi,0x20
 70e:	48 09 c6             	or     rsi,rax
 711:	48 01 f2             	add    rdx,rsi
 714:	48 31 d7             	xor    rdi,rdx
 717:	48 01 da             	add    rdx,rbx
 71a:	49 31 d0             	xor    r8,rdx
 71d:	4c 89 c6             	mov    rsi,r8
 720:	48 c1 ee 2f          	shr    rsi,0x2f
 724:	4c 89 c0             	mov    rax,r8
 727:	48 c1 e0 11          	shl    rax,0x11
 72b:	48 09 f0             	or     rax,rsi
 72e:	48 89 fb             	mov    rbx,rdi
 731:	48 c1 eb 30          	shr    rbx,0x30
 735:	48 89 fe             	mov    rsi,rdi
 738:	48 c1 e6 10          	shl    rsi,0x10
 73c:	48 09 de             	or     rsi,rbx
 73f:	48 89 cb             	mov    rbx,rcx
 742:	48 c1 eb 20          	shr    rbx,0x20
 746:	48 c1 e1 20          	shl    rcx,0x20
 74a:	48 09 d9             	or     rcx,rbx
 74d:	48 01 cf             	add    rdi,rcx
 750:	48 31 fe             	xor    rsi,rdi
 753:	4c 01 c7             	add    rdi,r8
 756:	48 31 f8             	xor    rax,rdi
 759:	48 89 c1             	mov    rcx,rax
 75c:	48 c1 e9 33          	shr    rcx,0x33
 760:	48 89 c3             	mov    rbx,rax
 763:	48 c1 e3 0d          	shl    rbx,0xd
 767:	48 09 cb             	or     rbx,rcx
 76a:	48 89 d1             	mov    rcx,rdx
 76d:	48 c1 e9 20          	shr    rcx,0x20
 771:	48 c1 e2 20          	shl    rdx,0x20
 775:	48 09 ca             	or     rdx,rcx
 778:	48 89 f1             	mov    rcx,rsi
 77b:	48 01 d1             	add    rcx,rdx
 77e:	48 89 ca             	mov    rdx,rcx
 781:	4c 31 ea             	xor    rdx,r13
 784:	48 01 c2             	add    rdx,rax
 787:	49 89 d0             	mov    r8,rdx
 78a:	49 31 d8             	xor    r8,rbx
 78d:	4c 89 c3             	mov    rbx,r8
 790:	48 c1 eb 2f          	shr    rbx,0x2f
 794:	4c 89 c0             	mov    rax,r8
 797:	48 c1 e0 11          	shl    rax,0x11
 79b:	48 09 d8             	or     rax,rbx
 79e:	48 89 fb             	mov    rbx,rdi
 7a1:	48 c1 eb 20          	shr    rbx,0x20
 7a5:	48 c1 e7 20          	shl    rdi,0x20
 7a9:	48 09 df             	or     rdi,rbx
 7ac:	48 89 f3             	mov    rbx,rsi
 7af:	48 c1 eb 2b          	shr    rbx,0x2b
 7b3:	48 c1 e6 15          	shl    rsi,0x15
 7b7:	48 09 de             	or     rsi,rbx
 7ba:	48 31 ce             	xor    rsi,rcx
 7bd:	4c 8b 6d c8          	mov    r13,QWORD PTR [rbp-0x38]
 7c1:	4c 31 ee             	xor    rsi,r13
 7c4:	48 89 f1             	mov    rcx,rsi
 7c7:	48 01 f9             	add    rcx,rdi
 7ca:	48 89 f7             	mov    rdi,rsi
 7cd:	48 c1 ef 30          	shr    rdi,0x30
 7d1:	48 c1 e6 10          	shl    rsi,0x10
 7d5:	48 09 fe             	or     rsi,rdi
 7d8:	48 31 ce             	xor    rsi,rcx
 7db:	4c 01 c1             	add    rcx,r8
 7de:	48 89 cb             	mov    rbx,rcx
 7e1:	48 31 c3             	xor    rbx,rax
 7e4:	48 89 df             	mov    rdi,rbx
 7e7:	48 c1 ef 33          	shr    rdi,0x33
 7eb:	49 89 d8             	mov    r8,rbx
 7ee:	49 c1 e0 0d          	shl    r8,0xd
 7f2:	49 09 f8             	or     r8,rdi
 7f5:	48 89 f0             	mov    rax,rsi
 7f8:	48 c1 e8 2b          	shr    rax,0x2b
 7fc:	48 89 f7             	mov    rdi,rsi
 7ff:	48 c1 e7 15          	shl    rdi,0x15
 803:	48 09 c7             	or     rdi,rax
 806:	48 89 d0             	mov    rax,rdx
 809:	48 c1 e8 20          	shr    rax,0x20
 80d:	48 c1 e2 20          	shl    rdx,0x20
 811:	48 09 c2             	or     rdx,rax
 814:	48 01 d6             	add    rsi,rdx
 817:	48 31 f7             	xor    rdi,rsi
 81a:	48 01 de             	add    rsi,rbx
 81d:	49 31 f0             	xor    r8,rsi
 820:	4c 89 c2             	mov    rdx,r8
 823:	48 c1 ea 2f          	shr    rdx,0x2f
 827:	4c 89 c0             	mov    rax,r8
 82a:	48 c1 e0 11          	shl    rax,0x11
 82e:	48 09 d0             	or     rax,rdx
 831:	48 89 fb             	mov    rbx,rdi
 834:	48 c1 eb 30          	shr    rbx,0x30
 838:	48 89 fa             	mov    rdx,rdi
 83b:	48 c1 e2 10          	shl    rdx,0x10
 83f:	48 09 da             	or     rdx,rbx
 842:	48 89 cb             	mov    rbx,rcx
 845:	48 c1 eb 20          	shr    rbx,0x20
 849:	48 c1 e1 20          	shl    rcx,0x20
 84d:	48 09 d9             	or     rcx,rbx
 850:	48 01 cf             	add    rdi,rcx
 853:	48 31 fa             	xor    rdx,rdi
 856:	4c 01 c7             	add    rdi,r8
 859:	48 31 f8             	xor    rax,rdi
 85c:	48 89 c1             	mov    rcx,rax
 85f:	48 c1 e9 33          	shr    rcx,0x33
 863:	48 89 c3             	mov    rbx,rax
 866:	48 c1 e3 0d          	shl    rbx,0xd
 86a:	48 09 cb             	or     rbx,rcx
 86d:	48 89 f1             	mov    rcx,rsi
 870:	48 c1 e9 20          	shr    rcx,0x20
 874:	48 c1 e6 20          	shl    rsi,0x20
 878:	48 09 ce             	or     rsi,rcx
 87b:	48 89 d1             	mov    rcx,rdx
 87e:	48 01 f1             	add    rcx,rsi
 881:	48 89 ce             	mov    rsi,rcx
 884:	4c 31 ee             	xor    rsi,r13
 887:	48 01 c6             	add    rsi,rax
 88a:	49 89 f0             	mov    r8,rsi
 88d:	49 31 d8             	xor    r8,rbx
 890:	4c 89 c3             	mov    rbx,r8
 893:	48 c1 eb 2f          	shr    rbx,0x2f
 897:	4c 89 c0             	mov    rax,r8
 89a:	48 c1 e0 11          	shl    rax,0x11
 89e:	48 09 d8             	or     rax,rbx
 8a1:	48 89 fb             	mov    rbx,rdi
 8a4:	48 c1 eb 20          	shr    rbx,0x20
 8a8:	48 c1 e7 20          	shl    rdi,0x20
 8ac:	48 09 df             	or     rdi,rbx
 8af:	48 89 d3             	mov    rbx,rdx
 8b2:	48 c1 eb 2b          	shr    rbx,0x2b
 8b6:	48 c1 e2 15          	shl    rdx,0x15
 8ba:	48 09 da             	or     rdx,rbx
 8bd:	48 31 ca             	xor    rdx,rcx
 8c0:	4c 8b 75 d0          	mov    r14,QWORD PTR [rbp-0x30]
 8c4:	4c 31 f2             	xor    rdx,r14
 8c7:	48 89 d1             	mov    rcx,rdx
 8ca:	48 01 f9             	add    rcx,rdi
 8cd:	48 89 d7             	mov    rdi,rdx
 8d0:	48 c1 ef 30          	shr    rdi,0x30
 8d4:	48 c1 e2 10          	shl    rdx,0x10
 8d8:	48 09 fa             	or     rdx,rdi
 8db:	48 31 ca             	xor    rdx,rcx
 8de:	4c 01 c1             	add    rcx,r8
 8e1:	49 89 c8             	mov    r8,rcx
 8e4:	49 31 c0             	xor    r8,rax
 8e7:	4c 89 c7             	mov    rdi,r8
 8ea:	48 c1 ef 33          	shr    rdi,0x33
 8ee:	4c 89 c0             	mov    rax,r8
 8f1:	48 c1 e0 0d          	shl    rax,0xd
 8f5:	48 09 f8             	or     rax,rdi
 8f8:	48 89 d3             	mov    rbx,rdx
 8fb:	48 c1 eb 2b          	shr    rbx,0x2b
 8ff:	48 89 d7             	mov    rdi,rdx
 902:	48 c1 e7 15          	shl    rdi,0x15
 906:	48 09 df             	or     rdi,rbx
 909:	48 89 f3             	mov    rbx,rsi
 90c:	48 c1 eb 20          	shr    rbx,0x20
 910:	48 c1 e6 20          	shl    rsi,0x20
 914:	48 09 de             	or     rsi,rbx
 917:	48 01 f2             	add    rdx,rsi
 91a:	48 31 d7             	xor    rdi,rdx
 91d:	4c 01 c2             	add    rdx,r8
 920:	48 31 d0             	xor    rax,rdx
 923:	48 89 c6             	mov    rsi,rax
 926:	48 c1 ee 2f          	shr    rsi,0x2f
 92a:	48 89 c3             	mov    rbx,rax
 92d:	48 c1 e3 11          	shl    rbx,0x11
 931:	48 09 f3             	or     rbx,rsi
 934:	48 89 fe             	mov    rsi,rdi
 937:	48 c1 ee 30          	shr    rsi,0x30
 93b:	49 89 f8             	mov    r8,rdi
 93e:	49 c1 e0 10          	shl    r8,0x10
 942:	49 09 f0             	or     r8,rsi
 945:	48 89 ce             	mov    rsi,rcx
 948:	48 c1 ee 20          	shr    rsi,0x20
 94c:	48 c1 e1 20          	shl    rcx,0x20
 950:	48 09 f1             	or     rcx,rsi
 953:	48 01 cf             	add    rdi,rcx
 956:	49 31 f8             	xor    r8,rdi
 959:	48 01 c7             	add    rdi,rax
 95c:	48 31 fb             	xor    rbx,rdi
 95f:	48 89 de             	mov    rsi,rbx
 962:	48 c1 ee 33          	shr    rsi,0x33
 966:	48 89 d8             	mov    rax,rbx
 969:	48 c1 e0 0d          	shl    rax,0xd
 96d:	48 09 f0             	or     rax,rsi
 970:	48 89 d6             	mov    rsi,rdx
 973:	48 c1 ee 20          	shr    rsi,0x20
 977:	48 c1 e2 20          	shl    rdx,0x20
 97b:	48 09 f2             	or     rdx,rsi
 97e:	4d 89 c5             	mov    r13,r8
 981:	49 01 d5             	add    r13,rdx
 984:	4c 89 ee             	mov    rsi,r13
 987:	4c 31 f6             	xor    rsi,r14
 98a:	48 01 de             	add    rsi,rbx
 98d:	48 89 f1             	mov    rcx,rsi
 990:	48 31 c1             	xor    rcx,rax
 993:	48 89 ca             	mov    rdx,rcx
 996:	48 c1 ea 2f          	shr    rdx,0x2f
 99a:	48 89 c8             	mov    rax,rcx
 99d:	48 c1 e0 11          	shl    rax,0x11
 9a1:	48 09 d0             	or     rax,rdx
 9a4:	48 89 fa             	mov    rdx,rdi
 9a7:	48 c1 ea 20          	shr    rdx,0x20
 9ab:	48 c1 e7 20          	shl    rdi,0x20
 9af:	48 09 d7             	or     rdi,rdx
 9b2:	4c 89 c2             	mov    rdx,r8
 9b5:	48 c1 ea 2b          	shr    rdx,0x2b
 9b9:	49 c1 e0 15          	shl    r8,0x15
 9bd:	49 09 d0             	or     r8,rdx
 9c0:	4d 31 e8             	xor    r8,r13
 9c3:	4c 8b 6d d8          	mov    r13,QWORD PTR [rbp-0x28]
 9c7:	4d 31 e8             	xor    r8,r13
 9ca:	4c 89 c2             	mov    rdx,r8
 9cd:	48 01 fa             	add    rdx,rdi
 9d0:	4c 89 c7             	mov    rdi,r8
 9d3:	48 c1 ef 30          	shr    rdi,0x30
 9d7:	49 c1 e0 10          	shl    r8,0x10
 9db:	49 09 f8             	or     r8,rdi
 9de:	49 31 d0             	xor    r8,rdx
 9e1:	48 01 ca             	add    rdx,rcx
 9e4:	48 89 d3             	mov    rbx,rdx
 9e7:	48 31 c3             	xor    rbx,rax
 9ea:	48 89 df             	mov    rdi,rbx
 9ed:	48 c1 ef 33          	shr    rdi,0x33
 9f1:	48 89 d9             	mov    rcx,rbx
 9f4:	48 c1 e1 0d          	shl    rcx,0xd
 9f8:	48 09 f9             	or     rcx,rdi
 9fb:	4c 89 c0             	mov    rax,r8
 9fe:	48 c1 e8 2b          	shr    rax,0x2b
 a02:	4c 89 c7             	mov    rdi,r8
 a05:	48 c1 e7 15          	shl    rdi,0x15
 a09:	48 09 c7             	or     rdi,rax
 a0c:	48 89 f0             	mov    rax,rsi
 a0f:	48 c1 e8 20          	shr    rax,0x20
 a13:	48 c1 e6 20          	shl    rsi,0x20
 a17:	48 09 c6             	or     rsi,rax
 a1a:	49 01 f0             	add    r8,rsi
 a1d:	4c 31 c7             	xor    rdi,r8
 a20:	49 01 d8             	add    r8,rbx
 a23:	4c 31 c1             	xor    rcx,r8
 a26:	48 89 ce             	mov    rsi,rcx
 a29:	48 c1 ee 2f          	shr    rsi,0x2f
 a2d:	48 89 c8             	mov    rax,rcx
 a30:	48 c1 e0 11          	shl    rax,0x11
 a34:	48 09 f0             	or     rax,rsi
 a37:	48 89 fb             	mov    rbx,rdi
 a3a:	48 c1 eb 30          	shr    rbx,0x30
 a3e:	48 89 fe             	mov    rsi,rdi
 a41:	48 c1 e6 10          	shl    rsi,0x10
 a45:	48 09 de             	or     rsi,rbx
 a48:	48 89 d3             	mov    rbx,rdx
 a4b:	48 c1 eb 20          	shr    rbx,0x20
 a4f:	48 c1 e2 20          	shl    rdx,0x20
 a53:	48 09 da             	or     rdx,rbx
 a56:	48 01 d7             	add    rdi,rdx
 a59:	48 31 fe             	xor    rsi,rdi
 a5c:	48 01 cf             	add    rdi,rcx
 a5f:	48 31 f8             	xor    rax,rdi
 a62:	48 89 c2             	mov    rdx,rax
 a65:	48 c1 ea 33          	shr    rdx,0x33
 a69:	48 89 c3             	mov    rbx,rax
 a6c:	48 c1 e3 0d          	shl    rbx,0xd
 a70:	48 09 d3             	or     rbx,rdx
 a73:	4c 89 c2             	mov    rdx,r8
 a76:	48 c1 ea 20          	shr    rdx,0x20
 a7a:	49 c1 e0 20          	shl    r8,0x20
 a7e:	49 09 d0             	or     r8,rdx
 a81:	48 89 f1             	mov    rcx,rsi
 a84:	4c 01 c1             	add    rcx,r8
 a87:	48 89 ca             	mov    rdx,rcx
 a8a:	4c 31 ea             	xor    rdx,r13
 a8d:	48 01 c2             	add    rdx,rax
 a90:	49 89 d0             	mov    r8,rdx
 a93:	49 31 d8             	xor    r8,rbx
 a96:	4c 89 c3             	mov    rbx,r8
 a99:	48 c1 eb 2f          	shr    rbx,0x2f
 a9d:	4c 89 c0             	mov    rax,r8
 aa0:	48 c1 e0 11          	shl    rax,0x11
 aa4:	48 09 d8             	or     rax,rbx
 aa7:	48 89 fb             	mov    rbx,rdi
 aaa:	48 c1 eb 20          	shr    rbx,0x20
 aae:	48 c1 e7 20          	shl    rdi,0x20
 ab2:	48 09 df             	or     rdi,rbx
 ab5:	48 89 f3             	mov    rbx,rsi
 ab8:	48 c1 eb 2b          	shr    rbx,0x2b
 abc:	48 c1 e6 15          	shl    rsi,0x15
 ac0:	48 09 de             	or     rsi,rbx
 ac3:	48 31 ce             	xor    rsi,rcx
 ac6:	4c 8b 6d e0          	mov    r13,QWORD PTR [rbp-0x20]
 aca:	4c 31 ee             	xor    rsi,r13
 acd:	48 89 f1             	mov    rcx,rsi
 ad0:	48 01 f9             	add    rcx,rdi
 ad3:	48 89 f7             	mov    rdi,rsi
 ad6:	48 c1 ef 30          	shr    rdi,0x30
 ada:	48 c1 e6 10          	shl    rsi,0x10
 ade:	48 09 fe             	or     rsi,rdi
 ae1:	48 31 ce             	xor    rsi,rcx
 ae4:	4c 01 c1             	add    rcx,r8
 ae7:	48 89 cf             	mov    rdi,rcx
 aea:	48 31 c7             	xor    rdi,rax
 aed:	49 89 f8             	mov    r8,rdi
 af0:	49 c1 e8 33          	shr    r8,0x33
 af4:	48 89 fb             	mov    rbx,rdi
 af7:	48 c1 e3 0d          	shl    rbx,0xd
 afb:	4c 09 c3             	or     rbx,r8
 afe:	48 89 f0             	mov    rax,rsi
 b01:	48 c1 e8 2b          	shr    rax,0x2b
 b05:	49 89 f0             	mov    r8,rsi
 b08:	49 c1 e0 15          	shl    r8,0x15
 b0c:	49 09 c0             	or     r8,rax
 b0f:	48 89 d0             	mov    rax,rdx
 b12:	48 c1 e8 20          	shr    rax,0x20
 b16:	48 c1 e2 20          	shl    rdx,0x20
 b1a:	48 09 c2             	or     rdx,rax
 b1d:	48 01 d6             	add    rsi,rdx
 b20:	49 31 f0             	xor    r8,rsi
 b23:	48 01 fe             	add    rsi,rdi
 b26:	48 31 f3             	xor    rbx,rsi
 b29:	48 89 da             	mov    rdx,rbx
 b2c:	48 c1 ea 2f          	shr    rdx,0x2f
 b30:	48 89 df             	mov    rdi,rbx
 b33:	48 c1 e7 11          	shl    rdi,0x11
 b37:	48 09 d7             	or     rdi,rdx
 b3a:	4c 89 c2             	mov    rdx,r8
 b3d:	48 c1 ea 30          	shr    rdx,0x30
 b41:	4c 89 c0             	mov    rax,r8
 b44:	48 c1 e0 10          	shl    rax,0x10
 b48:	48 09 d0             	or     rax,rdx
 b4b:	48 89 ca             	mov    rdx,rcx
 b4e:	48 c1 ea 20          	shr    rdx,0x20
 b52:	48 c1 e1 20          	shl    rcx,0x20
 b56:	48 09 d1             	or     rcx,rdx
 b59:	49 01 c8             	add    r8,rcx
 b5c:	4c 31 c0             	xor    rax,r8
 b5f:	49 01 d8             	add    r8,rbx
 b62:	4c 31 c7             	xor    rdi,r8
 b65:	48 89 fa             	mov    rdx,rdi
 b68:	48 c1 ea 33          	shr    rdx,0x33
 b6c:	48 89 f9             	mov    rcx,rdi
 b6f:	48 c1 e1 0d          	shl    rcx,0xd
 b73:	48 09 d1             	or     rcx,rdx
 b76:	48 89 f2             	mov    rdx,rsi
 b79:	48 c1 ea 20          	shr    rdx,0x20
 b7d:	48 c1 e6 20          	shl    rsi,0x20
 b81:	48 09 d6             	or     rsi,rdx
 b84:	48 89 c3             	mov    rbx,rax
 b87:	48 c1 eb 2b          	shr    rbx,0x2b
 b8b:	48 89 c2             	mov    rdx,rax
 b8e:	48 c1 e2 15          	shl    rdx,0x15
 b92:	48 09 da             	or     rdx,rbx
 b95:	48 01 f0             	add    rax,rsi
 b98:	48 31 c2             	xor    rdx,rax
 b9b:	4c 31 e8             	xor    rax,r13
 b9e:	48 01 f8             	add    rax,rdi
 ba1:	48 89 c7             	mov    rdi,rax
 ba4:	48 31 cf             	xor    rdi,rcx
 ba7:	48 89 f9             	mov    rcx,rdi
 baa:	48 c1 e9 2f          	shr    rcx,0x2f
 bae:	48 89 fe             	mov    rsi,rdi
 bb1:	48 c1 e6 11          	shl    rsi,0x11
 bb5:	48 09 ce             	or     rsi,rcx
 bb8:	4c 89 c1             	mov    rcx,r8
 bbb:	48 c1 e9 20          	shr    rcx,0x20
 bbf:	49 c1 e0 20          	shl    r8,0x20
 bc3:	49 09 c8             	or     r8,rcx
 bc6:	49 81 f0 ff 00 00 00 	xor    r8,0xff
 bcd:	49 01 d0             	add    r8,rdx
 bd0:	4c 01 c7             	add    rdi,r8
 bd3:	48 31 fe             	xor    rsi,rdi
 bd6:	48 89 f3             	mov    rbx,rsi
 bd9:	48 c1 eb 33          	shr    rbx,0x33
 bdd:	48 89 f1             	mov    rcx,rsi
 be0:	48 c1 e1 0d          	shl    rcx,0xd
 be4:	48 09 d9             	or     rcx,rbx
 be7:	48 89 d3             	mov    rbx,rdx
 bea:	48 c1 eb 30          	shr    rbx,0x30
 bee:	48 c1 e2 10          	shl    rdx,0x10
 bf2:	48 09 da             	or     rdx,rbx
 bf5:	4c 31 c2             	xor    rdx,r8
 bf8:	49 89 c0             	mov    r8,rax
 bfb:	49 c1 e8 20          	shr    r8,0x20
 bff:	48 c1 e0 20          	shl    rax,0x20
 c03:	4c 09 c0             	or     rax,r8
 c06:	48 01 d0             	add    rax,rdx
 c09:	48 01 c6             	add    rsi,rax
 c0c:	48 31 f1             	xor    rcx,rsi
 c0f:	48 89 cb             	mov    rbx,rcx
 c12:	48 c1 eb 2f          	shr    rbx,0x2f
 c16:	49 89 c8             	mov    r8,rcx
 c19:	49 c1 e0 11          	shl    r8,0x11
 c1d:	49 09 d8             	or     r8,rbx
 c20:	48 89 fb             	mov    rbx,rdi
 c23:	48 c1 eb 20          	shr    rbx,0x20
 c27:	48 c1 e7 20          	shl    rdi,0x20
 c2b:	48 09 df             	or     rdi,rbx
 c2e:	48 89 d3             	mov    rbx,rdx
 c31:	48 c1 eb 2b          	shr    rbx,0x2b
 c35:	48 c1 e2 15          	shl    rdx,0x15
 c39:	48 09 da             	or     rdx,rbx
 c3c:	48 31 c2             	xor    rdx,rax
 c3f:	48 01 d7             	add    rdi,rdx
 c42:	48 01 f9             	add    rcx,rdi
 c45:	49 31 c8             	xor    r8,rcx
 c48:	4c 89 c3             	mov    rbx,r8
 c4b:	48 c1 eb 33          	shr    rbx,0x33
 c4f:	4c 89 c0             	mov    rax,r8
 c52:	48 c1 e0 0d          	shl    rax,0xd
 c56:	48 09 d8             	or     rax,rbx
 c59:	48 89 d3             	mov    rbx,rdx
 c5c:	48 c1 eb 30          	shr    rbx,0x30
 c60:	48 c1 e2 10          	shl    rdx,0x10
 c64:	48 09 da             	or     rdx,rbx
 c67:	48 31 fa             	xor    rdx,rdi
 c6a:	48 89 f7             	mov    rdi,rsi
 c6d:	48 c1 ef 20          	shr    rdi,0x20
 c71:	48 c1 e6 20          	shl    rsi,0x20
 c75:	48 09 fe             	or     rsi,rdi
 c78:	48 01 d6             	add    rsi,rdx
 c7b:	49 01 f0             	add    r8,rsi
 c7e:	4c 31 c0             	xor    rax,r8
 c81:	48 89 c7             	mov    rdi,rax
 c84:	48 c1 ef 2f          	shr    rdi,0x2f
 c88:	48 89 c3             	mov    rbx,rax
 c8b:	48 c1 e3 11          	shl    rbx,0x11
 c8f:	48 09 fb             	or     rbx,rdi
 c92:	48 89 cf             	mov    rdi,rcx
 c95:	48 c1 ef 20          	shr    rdi,0x20
 c99:	48 c1 e1 20          	shl    rcx,0x20
 c9d:	48 09 f9             	or     rcx,rdi
 ca0:	48 89 d7             	mov    rdi,rdx
 ca3:	48 c1 ef 2b          	shr    rdi,0x2b
 ca7:	48 c1 e2 15          	shl    rdx,0x15
 cab:	48 09 fa             	or     rdx,rdi
 cae:	48 31 f2             	xor    rdx,rsi
 cb1:	48 01 d1             	add    rcx,rdx
 cb4:	48 01 c8             	add    rax,rcx
 cb7:	48 31 c3             	xor    rbx,rax
 cba:	48 89 de             	mov    rsi,rbx
 cbd:	48 c1 ee 33          	shr    rsi,0x33
 cc1:	48 89 df             	mov    rdi,rbx
 cc4:	48 c1 e7 0d          	shl    rdi,0xd
 cc8:	48 09 f7             	or     rdi,rsi
 ccb:	48 89 d6             	mov    rsi,rdx
 cce:	48 c1 ee 30          	shr    rsi,0x30
 cd2:	48 c1 e2 10          	shl    rdx,0x10
 cd6:	48 09 f2             	or     rdx,rsi
 cd9:	48 31 ca             	xor    rdx,rcx
 cdc:	4c 89 c6             	mov    rsi,r8
 cdf:	48 c1 ee 20          	shr    rsi,0x20
 ce3:	49 c1 e0 20          	shl    r8,0x20
 ce7:	49 09 f0             	or     r8,rsi
 cea:	49 01 d0             	add    r8,rdx
 ced:	4c 01 c3             	add    rbx,r8
 cf0:	48 31 df             	xor    rdi,rbx
 cf3:	48 89 c6             	mov    rsi,rax
 cf6:	48 c1 ee 20          	shr    rsi,0x20
 cfa:	48 c1 e0 20          	shl    rax,0x20
 cfe:	48 09 f0             	or     rax,rsi
 d01:	48 89 d6             	mov    rsi,rdx
 d04:	48 c1 ee 2b          	shr    rsi,0x2b
 d08:	48 c1 e2 15          	shl    rdx,0x15
 d0c:	48 09 f2             	or     rdx,rsi
 d0f:	4c 31 c2             	xor    rdx,r8
 d12:	48 01 d0             	add    rax,rdx
 d15:	48 89 d6             	mov    rsi,rdx
 d18:	48 c1 ee 30          	shr    rsi,0x30
 d1c:	48 c1 e2 10          	shl    rdx,0x10
 d20:	48 09 f2             	or     rdx,rsi
 d23:	48 31 c2             	xor    rdx,rax
 d26:	48 89 fe             	mov    rsi,rdi
 d29:	48 01 c6             	add    rsi,rax
 d2c:	48 89 f1             	mov    rcx,rsi
 d2f:	48 c1 e9 20          	shr    rcx,0x20
 d33:	49 89 f0             	mov    r8,rsi
 d36:	49 c1 e0 20          	shl    r8,0x20
 d3a:	49 09 c8             	or     r8,rcx
 d3d:	48 89 d1             	mov    rcx,rdx
 d40:	48 c1 e9 2b          	shr    rcx,0x2b
 d44:	48 c1 e2 15          	shl    rdx,0x15
 d48:	48 09 ca             	or     rdx,rcx
 d4b:	48 89 f9             	mov    rcx,rdi
 d4e:	48 c1 e9 2f          	shr    rcx,0x2f
 d52:	48 c1 e7 11          	shl    rdi,0x11
 d56:	48 09 cf             	or     rdi,rcx
 d59:	48 31 fa             	xor    rdx,rdi
 d5c:	4c 31 c2             	xor    rdx,r8
 d5f:	48 31 f2             	xor    rdx,rsi
 d62:	48 89 d7             	mov    rdi,rdx
 d65:	48 c1 ef 38          	shr    rdi,0x38
 d69:	48 8b 75 e8          	mov    rsi,QWORD PTR [rbp-0x18]
 d6d:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 d71:	48 89 d7             	mov    rdi,rdx
 d74:	48 c1 ef 30          	shr    rdi,0x30
 d78:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 d7c:	48 89 d7             	mov    rdi,rdx
 d7f:	48 c1 ef 28          	shr    rdi,0x28
 d83:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 d87:	48 89 d7             	mov    rdi,rdx
 d8a:	48 c1 ef 20          	shr    rdi,0x20
 d8e:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 d92:	48 89 d7             	mov    rdi,rdx
 d95:	48 c1 ef 18          	shr    rdi,0x18
 d99:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 d9d:	48 89 d7             	mov    rdi,rdx
 da0:	48 c1 ef 10          	shr    rdi,0x10
 da4:	40 88 7e 02          	mov    BYTE PTR [rsi+0x2],dil
 da8:	88 56 00             	mov    BYTE PTR [rsi+0x0],dl
 dab:	48 c1 ea 08          	shr    rdx,0x8
 daf:	88 56 01             	mov    BYTE PTR [rsi+0x1],dl
 db2:	b8 02 00 00 00       	mov    eax,0x2
 db7:	41 5f                	pop    r15
 db9:	41 5e                	pop    r14
 dbb:	41 5d                	pop    r13
 dbd:	5b                   	pop    rbx
 dbe:	c9                   	leave
 dbf:	e9 70 1b c1 d8       	jmp    0xffffffffd8c12934
```

## llvmbpf JIT ASM
```asm
not captured
```
