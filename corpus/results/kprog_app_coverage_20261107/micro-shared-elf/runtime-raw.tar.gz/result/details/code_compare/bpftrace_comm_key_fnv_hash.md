# bpftrace_comm_key_fnv_hash

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <bpftrace_comm_key_fnv_hash_xdp>:
    1100:	4c 8b 07             	mov    r8,QWORD PTR [rdi]
    1103:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
    1107:	4c 89 c2             	mov    rdx,r8
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 ca             	cmp    rdx,rcx
    110f:	76 01                	jbe    1112 <bpftrace_comm_key_fnv_hash_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 72 08          	lea    rsi,[rdx+0x8]
    1116:	48 39 ce             	cmp    rsi,rcx
    1119:	77 f6                	ja     1111 <bpftrace_comm_key_fnv_hash_xdp+0x11>
    111b:	48 8d b2 10 04 00 00 	lea    rsi,[rdx+0x410]
    1122:	48 39 ce             	cmp    rsi,rcx
    1125:	77 ea                	ja     1111 <bpftrace_comm_key_fnv_hash_xdp+0x11>
    1127:	83 7a 08 20          	cmp    DWORD PTR [rdx+0x8],0x20
    112b:	75 e4                	jne    1111 <bpftrace_comm_key_fnv_hash_xdp+0x11>
    112d:	83 7a 0c 20          	cmp    DWORD PTR [rdx+0xc],0x20
    1131:	75 de                	jne    1111 <bpftrace_comm_key_fnv_hash_xdp+0x11>
    1133:	55                   	push   rbp
    1134:	41 57                	push   r15
    1136:	41 56                	push   r14
    1138:	41 55                	push   r13
    113a:	41 54                	push   r12
    113c:	53                   	push   rbx
    113d:	48 83 ec 48          	sub    rsp,0x48
    1141:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    1146:	49 be b3 01 00 00 00 	movabs r14,0x100000001b3
    114d:	01 00 00 
    1150:	48 83 c2 2f          	add    rdx,0x2f
    1154:	49 b8 eb 11 31 13 bb 	movabs r8,0x94d049bb133111eb
    115b:	49 d0 94 
    115e:	31 f6                	xor    esi,esi
    1160:	eb 5b                	jmp    11bd <bpftrace_comm_key_fnv_hash_xdp+0xbd>
    1162:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    1169:	1f 84 00 00 00 00 00 
    1170:	c1 e5 08             	shl    ebp,0x8
    1173:	c1 e3 10             	shl    ebx,0x10
    1176:	09 eb                	or     ebx,ebp
    1178:	41 c1 e2 18          	shl    r10d,0x18
    117c:	41 09 da             	or     r10d,ebx
    117f:	41 09 fa             	or     r10d,edi
    1182:	89 f1                	mov    ecx,esi
    1184:	80 e1 07             	and    cl,0x7
    1187:	8d 79 01             	lea    edi,[rcx+0x1]
    118a:	c4 c2 c1 f7 f9       	shlx   rdi,r9,rdi
    118f:	f6 d1                	not    cl
    1191:	c4 c2 f3 f7 c9       	shrx   rcx,r9,rcx
    1196:	48 09 f9             	or     rcx,rdi
    1199:	4c 89 c7             	mov    rdi,r8
    119c:	48 31 cf             	xor    rdi,rcx
    119f:	49 c1 e3 38          	shl    r11,0x38
    11a3:	45 89 d0             	mov    r8d,r10d
    11a6:	4d 09 d8             	or     r8,r11
    11a9:	49 01 f8             	add    r8,rdi
    11ac:	48 ff c6             	inc    rsi
    11af:	48 83 c2 20          	add    rdx,0x20
    11b3:	48 83 fe 20          	cmp    rsi,0x20
    11b7:	0f 84 47 02 00 00    	je     1404 <bpftrace_comm_key_fnv_hash_xdp+0x304>
    11bd:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
    11c2:	44 0f b6 7a e1       	movzx  r15d,BYTE PTR [rdx-0x1f]
    11c7:	44 0f b6 62 e2       	movzx  r12d,BYTE PTR [rdx-0x1e]
    11cc:	0f b6 4a e3          	movzx  ecx,BYTE PTR [rdx-0x1d]
    11d0:	0f b6 7a e4          	movzx  edi,BYTE PTR [rdx-0x1c]
    11d4:	0f b6 6a e5          	movzx  ebp,BYTE PTR [rdx-0x1b]
    11d8:	0f b6 42 e6          	movzx  eax,BYTE PTR [rdx-0x1a]
    11dc:	0f b6 72 e7          	movzx  esi,BYTE PTR [rdx-0x19]
    11e0:	48 89 74 24 38       	mov    QWORD PTR [rsp+0x38],rsi
    11e5:	0f b6 72 e8          	movzx  esi,BYTE PTR [rdx-0x18]
    11e9:	48 89 74 24 30       	mov    QWORD PTR [rsp+0x30],rsi
    11ee:	44 0f b6 6a e9       	movzx  r13d,BYTE PTR [rdx-0x17]
    11f3:	0f b6 72 ea          	movzx  esi,BYTE PTR [rdx-0x16]
    11f7:	0f b6 5a eb          	movzx  ebx,BYTE PTR [rdx-0x15]
    11fb:	44 0f b6 52 ec       	movzx  r10d,BYTE PTR [rdx-0x14]
    1200:	4d 89 f9             	mov    r9,r15
    1203:	49 bb 25 23 22 84 e4 	movabs r11,0xcbf29ce484222325
    120a:	9c f2 cb 
    120d:	4d 31 d9             	xor    r9,r11
    1210:	4d 0f af ce          	imul   r9,r14
    1214:	4c 89 64 24 10       	mov    QWORD PTR [rsp+0x10],r12
    1219:	4d 31 e1             	xor    r9,r12
    121c:	4d 0f af ce          	imul   r9,r14
    1220:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    1225:	49 31 c9             	xor    r9,rcx
    1228:	4d 0f af ce          	imul   r9,r14
    122c:	48 89 7c 24 18       	mov    QWORD PTR [rsp+0x18],rdi
    1231:	49 31 f9             	xor    r9,rdi
    1234:	4d 0f af ce          	imul   r9,r14
    1238:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    123d:	49 31 e9             	xor    r9,rbp
    1240:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
    1245:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    124a:	48 89 f5             	mov    rbp,rsi
    124d:	4d 0f af ce          	imul   r9,r14
    1251:	49 31 c1             	xor    r9,rax
    1254:	4d 0f af ce          	imul   r9,r14
    1258:	4c 89 de             	mov    rsi,r11
    125b:	4d 31 d9             	xor    r9,r11
    125e:	4d 0f af ce          	imul   r9,r14
    1262:	49 31 f9             	xor    r9,rdi
    1265:	4d 0f af ce          	imul   r9,r14
    1269:	4c 89 2c 24          	mov    QWORD PTR [rsp],r13
    126d:	4d 31 e9             	xor    r9,r13
    1270:	4d 0f af ce          	imul   r9,r14
    1274:	49 31 e9             	xor    r9,rbp
    1277:	4d 0f af ce          	imul   r9,r14
    127b:	49 31 d9             	xor    r9,rbx
    127e:	4d 0f af ce          	imul   r9,r14
    1282:	4d 89 d3             	mov    r11,r10
    1285:	4d 31 cb             	xor    r11,r9
    1288:	4d 0f af de          	imul   r11,r14
    128c:	44 0f b6 4a f1       	movzx  r9d,BYTE PTR [rdx-0xf]
    1291:	4d 31 d9             	xor    r9,r11
    1294:	4d 0f af ce          	imul   r9,r14
    1298:	44 0f b6 5a f2       	movzx  r11d,BYTE PTR [rdx-0xe]
    129d:	4d 31 cb             	xor    r11,r9
    12a0:	4d 0f af de          	imul   r11,r14
    12a4:	44 0f b6 4a f3       	movzx  r9d,BYTE PTR [rdx-0xd]
    12a9:	4d 31 d9             	xor    r9,r11
    12ac:	4d 0f af ce          	imul   r9,r14
    12b0:	44 0f b6 5a f4       	movzx  r11d,BYTE PTR [rdx-0xc]
    12b5:	4d 31 cb             	xor    r11,r9
    12b8:	4d 0f af de          	imul   r11,r14
    12bc:	44 0f b6 4a f5       	movzx  r9d,BYTE PTR [rdx-0xb]
    12c1:	4d 31 d9             	xor    r9,r11
    12c4:	4d 0f af ce          	imul   r9,r14
    12c8:	44 0f b6 5a f6       	movzx  r11d,BYTE PTR [rdx-0xa]
    12cd:	4d 31 cb             	xor    r11,r9
    12d0:	4d 0f af de          	imul   r11,r14
    12d4:	44 0f b6 4a f7       	movzx  r9d,BYTE PTR [rdx-0x9]
    12d9:	4d 31 d9             	xor    r9,r11
    12dc:	4d 0f af ce          	imul   r9,r14
    12e0:	44 0f b6 5a f8       	movzx  r11d,BYTE PTR [rdx-0x8]
    12e5:	4d 31 cb             	xor    r11,r9
    12e8:	4d 0f af de          	imul   r11,r14
    12ec:	44 0f b6 4a f9       	movzx  r9d,BYTE PTR [rdx-0x7]
    12f1:	4d 31 d9             	xor    r9,r11
    12f4:	4d 0f af ce          	imul   r9,r14
    12f8:	44 0f b6 5a fa       	movzx  r11d,BYTE PTR [rdx-0x6]
    12fd:	4d 31 cb             	xor    r11,r9
    1300:	4d 0f af de          	imul   r11,r14
    1304:	44 0f b6 4a fb       	movzx  r9d,BYTE PTR [rdx-0x5]
    1309:	4d 31 d9             	xor    r9,r11
    130c:	4d 0f af ce          	imul   r9,r14
    1310:	44 0f b6 5a fc       	movzx  r11d,BYTE PTR [rdx-0x4]
    1315:	4d 31 cb             	xor    r11,r9
    1318:	4d 0f af de          	imul   r11,r14
    131c:	44 0f b6 4a fd       	movzx  r9d,BYTE PTR [rdx-0x3]
    1321:	4d 31 d9             	xor    r9,r11
    1324:	4d 0f af ce          	imul   r9,r14
    1328:	44 0f b6 5a fe       	movzx  r11d,BYTE PTR [rdx-0x2]
    132d:	4d 31 cb             	xor    r11,r9
    1330:	4d 0f af de          	imul   r11,r14
    1334:	44 0f b6 6a ff       	movzx  r13d,BYTE PTR [rdx-0x1]
    1339:	4d 31 dd             	xor    r13,r11
    133c:	4d 0f af ee          	imul   r13,r14
    1340:	44 0f b6 0a          	movzx  r9d,BYTE PTR [rdx]
    1344:	4d 31 e9             	xor    r9,r13
    1347:	44 0f b6 5a ed       	movzx  r11d,BYTE PTR [rdx-0x13]
    134c:	4d 0f af ce          	imul   r9,r14
    1350:	41 f6 c3 01          	test   r11b,0x1
    1354:	75 1a                	jne    1370 <bpftrace_comm_key_fnv_hash_xdp+0x270>
    1356:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
    135a:	41 f6 c3 02          	test   r11b,0x2
    135e:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    1363:	0f 84 07 fe ff ff    	je     1170 <bpftrace_comm_key_fnv_hash_xdp+0x70>
    1369:	e9 7c 00 00 00       	jmp    13ea <bpftrace_comm_key_fnv_hash_xdp+0x2ea>
    136e:	66 90                	xchg   ax,ax
    1370:	48 89 c1             	mov    rcx,rax
    1373:	48 89 f8             	mov    rax,rdi
    1376:	c1 e0 18             	shl    eax,0x18
    1379:	c1 e6 10             	shl    esi,0x10
    137c:	49 89 cd             	mov    r13,rcx
    137f:	41 c1 e5 08          	shl    r13d,0x8
    1383:	48 8b 4c 24 20       	mov    rcx,QWORD PTR [rsp+0x20]
    1388:	48 c1 e1 30          	shl    rcx,0x30
    138c:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    1391:	48 c1 e7 38          	shl    rdi,0x38
    1395:	4c 8b 64 24 10       	mov    r12,QWORD PTR [rsp+0x10]
    139a:	49 c1 e4 28          	shl    r12,0x28
    139e:	49 c1 e7 20          	shl    r15,0x20
    13a2:	4d 09 e7             	or     r15,r12
    13a5:	49 09 cf             	or     r15,rcx
    13a8:	49 09 ff             	or     r15,rdi
    13ab:	4d 09 ef             	or     r15,r13
    13ae:	49 09 f7             	or     r15,rsi
    13b1:	49 09 c7             	or     r15,rax
    13b4:	4c 0b 7c 24 28       	or     r15,QWORD PTR [rsp+0x28]
    13b9:	4c 8b 24 24          	mov    r12,QWORD PTR [rsp]
    13bd:	44 89 e1             	mov    ecx,r12d
    13c0:	80 e1 07             	and    cl,0x7
    13c3:	8d 79 01             	lea    edi,[rcx+0x1]
    13c6:	c4 c2 c1 f7 ff       	shlx   rdi,r15,rdi
    13cb:	f6 d1                	not    cl
    13cd:	c4 c2 f3 f7 cf       	shrx   rcx,r15,rcx
    13d2:	48 09 f9             	or     rcx,rdi
    13d5:	49 31 c9             	xor    r9,rcx
    13d8:	4c 89 e7             	mov    rdi,r12
    13db:	41 f6 c3 02          	test   r11b,0x2
    13df:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    13e4:	0f 84 86 fd ff ff    	je     1170 <bpftrace_comm_key_fnv_hash_xdp+0x70>
    13ea:	48 b9 87 ca eb 85 b1 	movabs rcx,0x9e3779b185ebca87
    13f1:	79 37 9e 
    13f4:	4c 01 c9             	add    rcx,r9
    13f7:	80 7a f1 70          	cmp    BYTE PTR [rdx-0xf],0x70
    13fb:	4c 0f 44 c9          	cmove  r9,rcx
    13ff:	e9 6c fd ff ff       	jmp    1170 <bpftrace_comm_key_fnv_hash_xdp+0x70>
    1404:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    1409:	4c 89 00             	mov    QWORD PTR [rax],r8
    140c:	b8 02 00 00 00       	mov    eax,0x2
    1411:	48 83 c4 48          	add    rsp,0x48
    1415:	5b                   	pop    rbx
    1416:	41 5c                	pop    r12
    1418:	41 5d                	pop    r13
    141a:	41 5e                	pop    r14
    141c:	41 5f                	pop    r15
    141e:	5d                   	pop    rbp
    141f:	c3                   	ret

Disassembly of section .fini:

0000000000001420 <_fini>:
    1420:	f3 0f 1e fa          	endbr64
    1424:	48 83 ec 08          	sub    rsp,0x8
    1428:	48 83 c4 08          	add    rsp,0x8
    142c:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 58 00 00 00 	sub    rsp,0x58
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 4f 00          	mov    rcx,QWORD PTR [rdi+0x0]
  24:	48 39 f1             	cmp    rcx,rsi
  27:	0f 87 ac 03 00 00    	ja     0x3d9
  2d:	48 89 cf             	mov    rdi,rcx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 9c 03 00 00    	ja     0x3d9
  3d:	48 89 cf             	mov    rdi,rcx
  40:	48 81 c7 10 04 00 00 	add    rdi,0x410
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 89 03 00 00    	ja     0x3d9
  50:	48 0f b6 79 09       	movzx  rdi,BYTE PTR [rcx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 71 08       	movzx  rsi,BYTE PTR [rcx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 71 0a       	movzx  rsi,BYTE PTR [rcx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 71 0b       	movzx  rsi,BYTE PTR [rcx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 83 ff 20          	cmp    rdi,0x20
  85:	0f 85 4e 03 00 00    	jne    0x3d9
  8b:	48 0f b6 79 0d       	movzx  rdi,BYTE PTR [rcx+0xd]
  90:	48 c1 e7 08          	shl    rdi,0x8
  94:	48 0f b6 71 0c       	movzx  rsi,BYTE PTR [rcx+0xc]
  99:	48 09 f7             	or     rdi,rsi
  9c:	48 0f b6 71 0e       	movzx  rsi,BYTE PTR [rcx+0xe]
  a1:	48 c1 e6 10          	shl    rsi,0x10
  a5:	48 09 f7             	or     rdi,rsi
  a8:	48 0f b6 71 0f       	movzx  rsi,BYTE PTR [rcx+0xf]
  ad:	48 c1 e6 18          	shl    rsi,0x18
  b1:	48 09 f7             	or     rdi,rsi
  b4:	48 c1 e7 20          	shl    rdi,0x20
  b8:	48 c1 ef 20          	shr    rdi,0x20
  bc:	48 83 ff 20          	cmp    rdi,0x20
  c0:	0f 85 13 03 00 00    	jne    0x3d9
  c6:	48 be eb 11 31 13 bb 	movabs rsi,0x94d049bb133111eb
  cd:	49 d0 94 
  d0:	31 d2                	xor    edx,edx
  d2:	48 89 4d a8          	mov    QWORD PTR [rbp-0x58],rcx
  d6:	48 83 c1 17          	add    rcx,0x17
  da:	48 b8 b3 01 00 00 00 	movabs rax,0x100000001b3
  e1:	01 00 00 
  e4:	eb 66                	jmp    0x14c
  e6:	48 8b 7d e0          	mov    rdi,QWORD PTR [rbp-0x20]
  ea:	48 c1 e7 10          	shl    rdi,0x10
  ee:	49 c1 e6 08          	shl    r14,0x8
  f2:	49 09 fe             	or     r14,rdi
  f5:	48 8b 7d e8          	mov    rdi,QWORD PTR [rbp-0x18]
  f9:	48 c1 e7 18          	shl    rdi,0x18
  fd:	49 09 fe             	or     r14,rdi
 100:	48 8b 7d f8          	mov    rdi,QWORD PTR [rbp-0x8]
 104:	49 09 fe             	or     r14,rdi
 107:	48 89 d7             	mov    rdi,rdx
 10a:	48 83 e7 07          	and    rdi,0x7
 10e:	49 89 f8             	mov    r8,rdi
 111:	49 83 f0 3f          	xor    r8,0x3f
 115:	48 89 f3             	mov    rbx,rsi
 118:	c4 e2 bb f7 db       	shrx   rbx,rbx,r8
 11d:	48 83 c7 01          	add    rdi,0x1
 121:	c4 e2 c1 f7 f6       	shlx   rsi,rsi,rdi
 126:	48 09 de             	or     rsi,rbx
 129:	48 8b 7d f0          	mov    rdi,QWORD PTR [rbp-0x10]
 12d:	48 31 fe             	xor    rsi,rdi
 130:	49 c1 e7 38          	shl    r15,0x38
 134:	4d 09 f7             	or     r15,r14
 137:	4c 01 fe             	add    rsi,r15
 13a:	48 83 c1 20          	add    rcx,0x20
 13e:	48 83 c2 01          	add    rdx,0x1
 142:	48 83 fa 20          	cmp    rdx,0x20
 146:	0f 84 36 02 00 00    	je     0x382
 14c:	48 89 75 f0          	mov    QWORD PTR [rbp-0x10],rsi
 150:	4c 0f b6 69 03       	movzx  r13,BYTE PTR [rcx+0x3]
 155:	4c 0f b6 71 02       	movzx  r14,BYTE PTR [rcx+0x2]
 15a:	4c 0f b6 79 04       	movzx  r15,BYTE PTR [rcx+0x4]
 15f:	4c 0f b6 41 f9       	movzx  r8,BYTE PTR [rcx-0x7]
 164:	4c 89 c6             	mov    rsi,r8
 167:	48 bf 25 23 22 84 e4 	movabs rdi,0xcbf29ce484222325
 16e:	9c f2 cb 
 171:	48 31 fe             	xor    rsi,rdi
 174:	48 0f af f0          	imul   rsi,rax
 178:	48 0f b6 79 fa       	movzx  rdi,BYTE PTR [rcx-0x6]
 17d:	48 89 7d d8          	mov    QWORD PTR [rbp-0x28],rdi
 181:	48 31 fe             	xor    rsi,rdi
 184:	48 0f af f0          	imul   rsi,rax
 188:	48 0f b6 79 fb       	movzx  rdi,BYTE PTR [rcx-0x5]
 18d:	48 89 7d c0          	mov    QWORD PTR [rbp-0x40],rdi
 191:	48 31 fe             	xor    rsi,rdi
 194:	48 0f af f0          	imul   rsi,rax
 198:	48 0f b6 79 fc       	movzx  rdi,BYTE PTR [rcx-0x4]
 19d:	48 89 7d c8          	mov    QWORD PTR [rbp-0x38],rdi
 1a1:	48 31 fe             	xor    rsi,rdi
 1a4:	48 0f af f0          	imul   rsi,rax
 1a8:	48 0f b6 79 fd       	movzx  rdi,BYTE PTR [rcx-0x3]
 1ad:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
 1b1:	48 31 fe             	xor    rsi,rdi
 1b4:	48 0f af f0          	imul   rsi,rax
 1b8:	48 0f b6 79 fe       	movzx  rdi,BYTE PTR [rcx-0x2]
 1bd:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
 1c1:	48 31 fe             	xor    rsi,rdi
 1c4:	48 0f af f0          	imul   rsi,rax
 1c8:	48 0f b6 59 ff       	movzx  rbx,BYTE PTR [rcx-0x1]
 1cd:	48 31 de             	xor    rsi,rbx
 1d0:	48 0f af f0          	imul   rsi,rax
 1d4:	48 0f b6 79 00       	movzx  rdi,BYTE PTR [rcx+0x0]
 1d9:	48 89 7d b0          	mov    QWORD PTR [rbp-0x50],rdi
 1dd:	48 31 fe             	xor    rsi,rdi
 1e0:	48 0f af f0          	imul   rsi,rax
 1e4:	48 0f b6 79 01       	movzx  rdi,BYTE PTR [rcx+0x1]
 1e9:	48 89 7d f8          	mov    QWORD PTR [rbp-0x8],rdi
 1ed:	48 31 fe             	xor    rsi,rdi
 1f0:	48 0f af f0          	imul   rsi,rax
 1f4:	4c 31 f6             	xor    rsi,r14
 1f7:	48 0f af f0          	imul   rsi,rax
 1fb:	4c 89 6d e0          	mov    QWORD PTR [rbp-0x20],r13
 1ff:	4c 31 ee             	xor    rsi,r13
 202:	48 0f af f0          	imul   rsi,rax
 206:	4c 89 7d e8          	mov    QWORD PTR [rbp-0x18],r15
 20a:	4c 31 fe             	xor    rsi,r15
 20d:	48 0f af f0          	imul   rsi,rax
 211:	48 0f b6 79 09       	movzx  rdi,BYTE PTR [rcx+0x9]
 216:	48 31 fe             	xor    rsi,rdi
 219:	48 0f af f0          	imul   rsi,rax
 21d:	48 0f b6 79 0a       	movzx  rdi,BYTE PTR [rcx+0xa]
 222:	48 31 fe             	xor    rsi,rdi
 225:	48 0f af f0          	imul   rsi,rax
 229:	48 0f b6 79 0b       	movzx  rdi,BYTE PTR [rcx+0xb]
 22e:	48 31 fe             	xor    rsi,rdi
 231:	48 0f af f0          	imul   rsi,rax
 235:	48 0f b6 79 0c       	movzx  rdi,BYTE PTR [rcx+0xc]
 23a:	48 31 fe             	xor    rsi,rdi
 23d:	48 0f af f0          	imul   rsi,rax
 241:	48 0f b6 79 0d       	movzx  rdi,BYTE PTR [rcx+0xd]
 246:	48 31 fe             	xor    rsi,rdi
 249:	48 0f af f0          	imul   rsi,rax
 24d:	48 0f b6 79 0e       	movzx  rdi,BYTE PTR [rcx+0xe]
 252:	48 31 fe             	xor    rsi,rdi
 255:	48 0f af f0          	imul   rsi,rax
 259:	48 0f b6 79 0f       	movzx  rdi,BYTE PTR [rcx+0xf]
 25e:	48 31 fe             	xor    rsi,rdi
 261:	48 0f af f0          	imul   rsi,rax
 265:	48 0f b6 79 10       	movzx  rdi,BYTE PTR [rcx+0x10]
 26a:	48 31 fe             	xor    rsi,rdi
 26d:	48 0f af f0          	imul   rsi,rax
 271:	48 0f b6 79 11       	movzx  rdi,BYTE PTR [rcx+0x11]
 276:	48 31 fe             	xor    rsi,rdi
 279:	48 0f af f0          	imul   rsi,rax
 27d:	48 0f b6 79 12       	movzx  rdi,BYTE PTR [rcx+0x12]
 282:	48 31 fe             	xor    rsi,rdi
 285:	48 0f af f0          	imul   rsi,rax
 289:	48 0f b6 79 13       	movzx  rdi,BYTE PTR [rcx+0x13]
 28e:	48 31 fe             	xor    rsi,rdi
 291:	48 0f af f0          	imul   rsi,rax
 295:	48 0f b6 79 14       	movzx  rdi,BYTE PTR [rcx+0x14]
 29a:	48 31 fe             	xor    rsi,rdi
 29d:	48 0f af f0          	imul   rsi,rax
 2a1:	48 0f b6 79 15       	movzx  rdi,BYTE PTR [rcx+0x15]
 2a6:	48 31 fe             	xor    rsi,rdi
 2a9:	48 0f af f0          	imul   rsi,rax
 2ad:	48 0f b6 79 16       	movzx  rdi,BYTE PTR [rcx+0x16]
 2b2:	48 31 fe             	xor    rsi,rdi
 2b5:	48 0f af f0          	imul   rsi,rax
 2b9:	48 0f b6 79 17       	movzx  rdi,BYTE PTR [rcx+0x17]
 2be:	48 31 fe             	xor    rsi,rdi
 2c1:	48 0f af f0          	imul   rsi,rax
 2c5:	48 0f b6 79 18       	movzx  rdi,BYTE PTR [rcx+0x18]
 2ca:	48 31 fe             	xor    rsi,rdi
 2cd:	48 0f af f0          	imul   rsi,rax
 2d1:	4c 0f b6 79 05       	movzx  r15,BYTE PTR [rcx+0x5]
 2d6:	4c 89 ff             	mov    rdi,r15
 2d9:	48 83 e7 01          	and    rdi,0x1
 2dd:	48 85 ff             	test   rdi,rdi
 2e0:	74 6f                	je     0x351
 2e2:	49 c1 e0 20          	shl    r8,0x20
 2e6:	48 8b 7d c0          	mov    rdi,QWORD PTR [rbp-0x40]
 2ea:	48 c1 e7 30          	shl    rdi,0x30
 2ee:	49 09 f8             	or     r8,rdi
 2f1:	48 8b 7d d8          	mov    rdi,QWORD PTR [rbp-0x28]
 2f5:	48 c1 e7 28          	shl    rdi,0x28
 2f9:	4c 8b 6d c8          	mov    r13,QWORD PTR [rbp-0x38]
 2fd:	49 c1 e5 38          	shl    r13,0x38
 301:	4c 09 ef             	or     rdi,r13
 304:	49 09 f8             	or     r8,rdi
 307:	48 8b 7d b8          	mov    rdi,QWORD PTR [rbp-0x48]
 30b:	48 c1 e7 08          	shl    rdi,0x8
 30f:	49 09 f8             	or     r8,rdi
 312:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
 316:	48 c1 e7 18          	shl    rdi,0x18
 31a:	48 c1 e3 10          	shl    rbx,0x10
 31e:	48 09 fb             	or     rbx,rdi
 321:	49 09 d8             	or     r8,rbx
 324:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
 328:	49 09 f8             	or     r8,rdi
 32b:	48 8b 7d f8          	mov    rdi,QWORD PTR [rbp-0x8]
 32f:	48 83 e7 07          	and    rdi,0x7
 333:	48 89 fb             	mov    rbx,rdi
 336:	48 83 c3 01          	add    rbx,0x1
 33a:	48 83 f7 3f          	xor    rdi,0x3f
 33e:	4d 89 c5             	mov    r13,r8
 341:	c4 42 c3 f7 ed       	shrx   r13,r13,rdi
 346:	c4 42 e1 f7 c0       	shlx   r8,r8,rbx
 34b:	4d 09 e8             	or     r8,r13
 34e:	4c 31 c6             	xor    rsi,r8
 351:	4c 89 ff             	mov    rdi,r15
 354:	48 83 e7 02          	and    rdi,0x2
 358:	48 85 ff             	test   rdi,rdi
 35b:	0f 84 85 fd ff ff    	je     0xe6
 361:	48 0f b6 79 09       	movzx  rdi,BYTE PTR [rcx+0x9]
 366:	48 83 ff 70          	cmp    rdi,0x70
 36a:	0f 85 76 fd ff ff    	jne    0xe6
 370:	48 bf 87 ca eb 85 b1 	movabs rdi,0x9e3779b185ebca87
 377:	79 37 9e 
 37a:	48 01 fe             	add    rsi,rdi
 37d:	e9 64 fd ff ff       	jmp    0xe6
 382:	48 89 f7             	mov    rdi,rsi
 385:	48 c1 ef 38          	shr    rdi,0x38
 389:	48 8b 55 a8          	mov    rdx,QWORD PTR [rbp-0x58]
 38d:	40 88 7a 07          	mov    BYTE PTR [rdx+0x7],dil
 391:	48 89 f7             	mov    rdi,rsi
 394:	48 c1 ef 30          	shr    rdi,0x30
 398:	40 88 7a 06          	mov    BYTE PTR [rdx+0x6],dil
 39c:	48 89 f7             	mov    rdi,rsi
 39f:	48 c1 ef 28          	shr    rdi,0x28
 3a3:	40 88 7a 05          	mov    BYTE PTR [rdx+0x5],dil
 3a7:	48 89 f7             	mov    rdi,rsi
 3aa:	48 c1 ef 20          	shr    rdi,0x20
 3ae:	40 88 7a 04          	mov    BYTE PTR [rdx+0x4],dil
 3b2:	48 89 f7             	mov    rdi,rsi
 3b5:	48 c1 ef 18          	shr    rdi,0x18
 3b9:	40 88 7a 03          	mov    BYTE PTR [rdx+0x3],dil
 3bd:	48 89 f7             	mov    rdi,rsi
 3c0:	48 c1 ef 10          	shr    rdi,0x10
 3c4:	40 88 7a 02          	mov    BYTE PTR [rdx+0x2],dil
 3c8:	40 88 72 00          	mov    BYTE PTR [rdx+0x0],sil
 3cc:	48 c1 ee 08          	shr    rsi,0x8
 3d0:	40 88 72 01          	mov    BYTE PTR [rdx+0x1],sil
 3d4:	b8 02 00 00 00       	mov    eax,0x2
 3d9:	41 5f                	pop    r15
 3db:	41 5e                	pop    r14
 3dd:	41 5d                	pop    r13
 3df:	5b                   	pop    rbx
 3e0:	c9                   	leave
 3e1:	e9 6e 2c c1 d8       	jmp    0xffffffffd8c13054
```

## llvmbpf JIT ASM
```asm
not captured
```
