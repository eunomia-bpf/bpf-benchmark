# tracee_syscall_name_table_lookup

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <tracee_syscall_name_table_lookup_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <tracee_syscall_name_table_lookup_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <tracee_syscall_name_table_lookup_xdp+0x11>
    111b:	4c 8d 82 0c 01 00 00 	lea    r8,[rdx+0x10c]
    1122:	49 39 f0             	cmp    r8,rsi
    1125:	77 ea                	ja     1111 <tracee_syscall_name_table_lookup_xdp+0x11>
    1127:	83 3f 40             	cmp    DWORD PTR [rdi],0x40
    112a:	75 e5                	jne    1111 <tracee_syscall_name_table_lookup_xdp+0x11>
    112c:	55                   	push   rbp
    112d:	41 57                	push   r15
    112f:	41 56                	push   r14
    1131:	41 55                	push   r13
    1133:	41 54                	push   r12
    1135:	53                   	push   rbx
    1136:	48 bf 09 c9 bc f3 67 	movabs rdi,0x6a09e667f3bcc909
    113d:	e6 09 6a 
    1140:	49 bd 63 6c 6f 73 65 	movabs r13,0x65736f6c63
    1147:	00 00 00 
    114a:	45 31 c9             	xor    r9d,r9d
    114d:	4d 8d 85 14 06 fa 00 	lea    r8,[r13+0xfa0614]
    1154:	49 be 6f 70 65 6e 61 	movabs r14,0x74616e65706f
    115b:	74 00 00 
    115e:	49 ba 75 6e 6c 69 6e 	movabs r10,0x74616b6e696c6e75
    1165:	6b 61 74 
    1168:	49 bb 73 74 61 74 32 	movabs r11,0x74613274617473
    116f:	61 74 00 
    1172:	48 bb 73 69 67 6e 65 	movabs rbx,0x647466656e676973
    1179:	66 74 64 
    117c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    1180:	46 0f b6 7c 8a 0c    	movzx  r15d,BYTE PTR [rdx+r9*4+0xc]
    1186:	42 0f b6 44 8a 0d    	movzx  eax,BYTE PTR [rdx+r9*4+0xd]
    118c:	c1 e0 08             	shl    eax,0x8
    118f:	44 09 f8             	or     eax,r15d
    1192:	46 0f b7 64 8a 0e    	movzx  r12d,WORD PTR [rdx+r9*4+0xe]
    1198:	41 c1 e4 10          	shl    r12d,0x10
    119c:	41 09 c4             	or     r12d,eax
    119f:	41 83 fc 4f          	cmp    r12d,0x4f
    11a3:	7f 3b                	jg     11e0 <tracee_syscall_name_table_lookup_xdp+0xe0>
    11a5:	41 83 fc 26          	cmp    r12d,0x26
    11a9:	0f 8f 81 00 00 00    	jg     1230 <tracee_syscall_name_table_lookup_xdp+0x130>
    11af:	41 83 fc 02          	cmp    r12d,0x2
    11b3:	0f 8f f3 00 00 00    	jg     12ac <tracee_syscall_name_table_lookup_xdp+0x1ac>
    11b9:	45 85 e4             	test   r12d,r12d
    11bc:	0f 84 e4 01 00 00    	je     13a6 <tracee_syscall_name_table_lookup_xdp+0x2a6>
    11c2:	41 83 fc 01          	cmp    r12d,0x1
    11c6:	0f 84 97 01 00 00    	je     1363 <tracee_syscall_name_table_lookup_xdp+0x263>
    11cc:	41 83 fc 02          	cmp    r12d,0x2
    11d0:	0f 85 47 02 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    11d6:	b8 6f 70 65 6e       	mov    eax,0x6e65706f
    11db:	e9 00 02 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    11e0:	41 81 fc 00 01 00 00 	cmp    r12d,0x100
    11e7:	0f 8f 83 00 00 00    	jg     1270 <tracee_syscall_name_table_lookup_xdp+0x170>
    11ed:	41 81 fc 9d 00 00 00 	cmp    r12d,0x9d
    11f4:	0f 8f dd 00 00 00    	jg     12d7 <tracee_syscall_name_table_lookup_xdp+0x1d7>
    11fa:	41 83 fc 50          	cmp    r12d,0x50
    11fe:	0f 84 a9 01 00 00    	je     13ad <tracee_syscall_name_table_lookup_xdp+0x2ad>
    1204:	41 83 fc 57          	cmp    r12d,0x57
    1208:	0f 84 5a 01 00 00    	je     1368 <tracee_syscall_name_table_lookup_xdp+0x268>
    120e:	41 83 fc 59          	cmp    r12d,0x59
    1212:	0f 85 05 02 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    1218:	48 b8 55 6c 69 6e 6b 	movabs rax,0x6b6e696c55
    121f:	00 00 00 
    1222:	e9 b9 01 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1227:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    122e:	00 00 
    1230:	41 83 fc 3a          	cmp    r12d,0x3a
    1234:	0f 8f d3 00 00 00    	jg     130d <tracee_syscall_name_table_lookup_xdp+0x20d>
    123a:	41 83 fc 27          	cmp    r12d,0x27
    123e:	0f 84 70 01 00 00    	je     13b4 <tracee_syscall_name_table_lookup_xdp+0x2b4>
    1244:	41 83 fc 38          	cmp    r12d,0x38
    1248:	0f 84 26 01 00 00    	je     1374 <tracee_syscall_name_table_lookup_xdp+0x274>
    124e:	41 83 fc 39          	cmp    r12d,0x39
    1252:	0f 85 c5 01 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    1258:	b8 66 6f 72 6b       	mov    eax,0x6b726f66
    125d:	e9 7e 01 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1262:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    1269:	1f 84 00 00 00 00 00 
    1270:	41 81 fc 22 01 00 00 	cmp    r12d,0x122
    1277:	0f 8f b9 00 00 00    	jg     1336 <tracee_syscall_name_table_lookup_xdp+0x236>
    127d:	41 81 fc 01 01 00 00 	cmp    r12d,0x101
    1284:	0f 84 36 01 00 00    	je     13c0 <tracee_syscall_name_table_lookup_xdp+0x2c0>
    128a:	41 81 fc 07 01 00 00 	cmp    r12d,0x107
    1291:	0f 84 e9 00 00 00    	je     1380 <tracee_syscall_name_table_lookup_xdp+0x280>
    1297:	41 81 fc 19 01 00 00 	cmp    r12d,0x119
    129e:	0f 85 79 01 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    12a4:	4c 89 d8             	mov    rax,r11
    12a7:	e9 34 01 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    12ac:	4c 89 e8             	mov    rax,r13
    12af:	41 83 fc 03          	cmp    r12d,0x3
    12b3:	0f 84 27 01 00 00    	je     13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    12b9:	41 83 fc 09          	cmp    r12d,0x9
    12bd:	0f 84 c2 00 00 00    	je     1385 <tracee_syscall_name_table_lookup_xdp+0x285>
    12c3:	41 83 fc 0c          	cmp    r12d,0xc
    12c7:	0f 85 50 01 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    12cd:	b8 6b 62 72 6b       	mov    eax,0x6b72626b
    12d2:	e9 09 01 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    12d7:	41 81 fc 9e 00 00 00 	cmp    r12d,0x9e
    12de:	0f 84 e1 00 00 00    	je     13c5 <tracee_syscall_name_table_lookup_xdp+0x2c5>
    12e4:	41 81 fc ca 00 00 00 	cmp    r12d,0xca
    12eb:	0f 84 9b 00 00 00    	je     138c <tracee_syscall_name_table_lookup_xdp+0x28c>
    12f1:	41 81 fc d9 00 00 00 	cmp    r12d,0xd9
    12f8:	0f 85 1f 01 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    12fe:	48 b8 67 65 74 61 64 	movabs rax,0x646461746567
    1305:	64 00 00 
    1308:	e9 d3 00 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    130d:	41 83 fc 3b          	cmp    r12d,0x3b
    1311:	0f 84 ba 00 00 00    	je     13d1 <tracee_syscall_name_table_lookup_xdp+0x2d1>
    1317:	41 83 fc 3c          	cmp    r12d,0x3c
    131b:	74 7b                	je     1398 <tracee_syscall_name_table_lookup_xdp+0x298>
    131d:	41 83 fc 3d          	cmp    r12d,0x3d
    1321:	0f 85 f6 00 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    1327:	48 b8 55 77 61 69 74 	movabs rax,0x347469617755
    132e:	34 00 00 
    1331:	e9 aa 00 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1336:	41 81 fc 23 01 00 00 	cmp    r12d,0x123
    133d:	0f 84 9a 00 00 00    	je     13dd <tracee_syscall_name_table_lookup_xdp+0x2dd>
    1343:	41 81 fc 41 01 00 00 	cmp    r12d,0x141
    134a:	74 53                	je     139f <tracee_syscall_name_table_lookup_xdp+0x29f>
    134c:	41 81 fc 4c 01 00 00 	cmp    r12d,0x14c
    1353:	0f 85 c4 00 00 00    	jne    141d <tracee_syscall_name_table_lookup_xdp+0x31d>
    1359:	b8 73 61 74 78       	mov    eax,0x78746173
    135e:	e9 7d 00 00 00       	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1363:	4c 89 c0             	mov    rax,r8
    1366:	eb 78                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1368:	48 b8 75 6e 6c 69 6e 	movabs rax,0x6b6e696c6e75
    136f:	6b 00 00 
    1372:	eb 6c                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1374:	48 b8 55 63 6c 6f 6e 	movabs rax,0x656e6f6c6355
    137b:	65 00 00 
    137e:	eb 60                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1380:	4c 89 d0             	mov    rax,r10
    1383:	eb 5b                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1385:	b8 6d 6d 61 70       	mov    eax,0x70616d6d
    138a:	eb 54                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    138c:	48 b8 55 66 75 74 65 	movabs rax,0x786574756655
    1393:	78 00 00 
    1396:	eb 48                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    1398:	b8 65 78 69 74       	mov    eax,0x74697865
    139d:	eb 41                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    139f:	b8 62 66 70 00       	mov    eax,0x706662
    13a4:	eb 3a                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13a6:	b8 64 61 65 72       	mov    eax,0x72656164
    13ab:	eb 33                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13ad:	b8 63 68 64 69       	mov    eax,0x69646863
    13b2:	eb 2c                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13b4:	48 b8 67 74 70 69 64 	movabs rax,0x6469707467
    13bb:	00 00 00 
    13be:	eb 20                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13c0:	4c 89 f0             	mov    rax,r14
    13c3:	eb 1b                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13c5:	48 b8 61 72 63 68 5f 	movabs rax,0x6c74635f68637261
    13cc:	63 74 6c 
    13cf:	eb 0f                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13d1:	48 b8 65 78 65 63 76 	movabs rax,0x657663657865
    13d8:	65 00 00 
    13db:	eb 03                	jmp    13e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
    13dd:	48 89 d8             	mov    rax,rbx
    13e0:	45 89 e4             	mov    r12d,r12d
    13e3:	49 31 c4             	xor    r12,rax
    13e6:	44 89 ce             	mov    esi,r9d
    13e9:	83 e6 07             	and    esi,0x7
    13ec:	8d 6e 01             	lea    ebp,[rsi+0x1]
    13ef:	c4 c2 d1 f7 ec       	shlx   rbp,r12,rbp
    13f4:	89 f0                	mov    eax,esi
    13f6:	f6 d0                	not    al
    13f8:	c4 c2 fb f7 c4       	shrx   rax,r12,rax
    13fd:	48 09 e8             	or     rax,rbp
    1400:	48 01 f8             	add    rax,rdi
    1403:	c1 e6 03             	shl    esi,0x3
    1406:	c4 c2 c9 f7 ff       	shlx   rdi,r15,rsi
    140b:	48 31 c7             	xor    rdi,rax
    140e:	49 ff c1             	inc    r9
    1411:	49 83 f9 40          	cmp    r9,0x40
    1415:	0f 85 65 fd ff ff    	jne    1180 <tracee_syscall_name_table_lookup_xdp+0x80>
    141b:	eb 21                	jmp    143e <tracee_syscall_name_table_lookup_xdp+0x33e>
    141d:	44 89 e0             	mov    eax,r12d
    1420:	48 be 87 ca eb 85 b1 	movabs rsi,0x9e3779b185ebca87
    1427:	79 37 9e 
    142a:	48 0f af c6          	imul   rax,rsi
    142e:	48 31 c7             	xor    rdi,rax
    1431:	49 ff c1             	inc    r9
    1434:	49 83 f9 40          	cmp    r9,0x40
    1438:	0f 85 42 fd ff ff    	jne    1180 <tracee_syscall_name_table_lookup_xdp+0x80>
    143e:	48 89 39             	mov    QWORD PTR [rcx],rdi
    1441:	b8 02 00 00 00       	mov    eax,0x2
    1446:	5b                   	pop    rbx
    1447:	41 5c                	pop    r12
    1449:	41 5d                	pop    r13
    144b:	41 5e                	pop    r14
    144d:	41 5f                	pop    r15
    144f:	5d                   	pop    rbp
    1450:	c3                   	ret

Disassembly of section .fini:

0000000000001454 <_fini>:
    1454:	f3 0f 1e fa          	endbr64
    1458:	48 83 ec 08          	sub    rsp,0x8
    145c:	48 83 c4 08          	add    rsp,0x8
    1460:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	53                   	push   rbx
   d:	41 55                	push   r13
   f:	41 56                	push   r14
  11:	41 57                	push   r15
  13:	31 c0                	xor    eax,eax
  15:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  19:	48 8b 7f 00          	mov    rdi,QWORD PTR [rdi+0x0]
  1d:	48 39 f7             	cmp    rdi,rsi
  20:	0f 87 ca 03 00 00    	ja     0x3f0
  26:	48 89 fa             	mov    rdx,rdi
  29:	48 83 c2 08          	add    rdx,0x8
  2d:	48 39 f2             	cmp    rdx,rsi
  30:	0f 87 ba 03 00 00    	ja     0x3f0
  36:	48 89 fa             	mov    rdx,rdi
  39:	48 81 c2 0c 01 00 00 	add    rdx,0x10c
  40:	48 39 f2             	cmp    rdx,rsi
  43:	0f 87 a7 03 00 00    	ja     0x3f0
  49:	48 0f b6 77 09       	movzx  rsi,BYTE PTR [rdi+0x9]
  4e:	48 c1 e6 08          	shl    rsi,0x8
  52:	48 0f b6 57 08       	movzx  rdx,BYTE PTR [rdi+0x8]
  57:	48 09 d6             	or     rsi,rdx
  5a:	48 0f b6 57 0a       	movzx  rdx,BYTE PTR [rdi+0xa]
  5f:	48 c1 e2 10          	shl    rdx,0x10
  63:	48 09 d6             	or     rsi,rdx
  66:	48 0f b6 57 0b       	movzx  rdx,BYTE PTR [rdi+0xb]
  6b:	48 c1 e2 18          	shl    rdx,0x18
  6f:	48 09 d6             	or     rsi,rdx
  72:	48 c1 e6 20          	shl    rsi,0x20
  76:	48 c1 ee 20          	shr    rsi,0x20
  7a:	48 83 fe 40          	cmp    rsi,0x40
  7e:	0f 85 6c 03 00 00    	jne    0x3f0
  84:	49 b8 09 c9 bc f3 67 	movabs r8,0x6a09e667f3bcc909
  8b:	e6 09 6a 
  8e:	31 f6                	xor    esi,esi
  90:	48 89 fa             	mov    rdx,rdi
  93:	48 83 c2 0f          	add    rdx,0xf
  97:	48 b9 87 ca eb 85 b1 	movabs rcx,0x9e3779b185ebca87
  9e:	79 37 9e 
  a1:	48 0f b6 5a fe       	movzx  rbx,BYTE PTR [rdx-0x2]
  a6:	48 c1 e3 08          	shl    rbx,0x8
  aa:	48 0f b6 42 fd       	movzx  rax,BYTE PTR [rdx-0x3]
  af:	48 09 c3             	or     rbx,rax
  b2:	4c 0f b6 6a ff       	movzx  r13,BYTE PTR [rdx-0x1]
  b7:	49 c1 e5 10          	shl    r13,0x10
  bb:	4c 09 eb             	or     rbx,r13
  be:	4c 0f b6 6a 00       	movzx  r13,BYTE PTR [rdx+0x0]
  c3:	49 c1 e5 18          	shl    r13,0x18
  c7:	4c 09 eb             	or     rbx,r13
  ca:	49 89 de             	mov    r14,rbx
  cd:	49 c1 e6 20          	shl    r14,0x20
  d1:	49 c1 ee 20          	shr    r14,0x20
  d5:	49 83 fe 4f          	cmp    r14,0x4f
  d9:	7f 34                	jg     0x10f
  db:	49 83 fe 26          	cmp    r14,0x26
  df:	7f 72                	jg     0x153
  e1:	49 83 fe 02          	cmp    r14,0x2
  e5:	0f 8f e0 00 00 00    	jg     0x1cb
  eb:	41 bd 64 61 65 72    	mov    r13d,0x72656164
  f1:	4d 85 f6             	test   r14,r14
  f4:	0f 84 3a 02 00 00    	je     0x334
  fa:	49 83 fe 01          	cmp    r14,0x1
  fe:	0f 84 85 01 00 00    	je     0x289
 104:	41 bd 6f 70 65 6e    	mov    r13d,0x6e65706f
 10a:	e9 25 02 00 00       	jmp    0x334
 10f:	49 81 fe 00 01 00 00 	cmp    r14,0x100
 116:	7f 6f                	jg     0x187
 118:	49 81 fe 9d 00 00 00 	cmp    r14,0x9d
 11f:	0f 8f d0 00 00 00    	jg     0x1f5
 125:	49 83 fe 50          	cmp    r14,0x50
 129:	0f 84 b7 01 00 00    	je     0x2e6
 12f:	49 83 fe 57          	cmp    r14,0x57
 133:	0f 84 5f 01 00 00    	je     0x298
 139:	49 83 fe 59          	cmp    r14,0x59
 13d:	74 05                	je     0x144
 13f:	e9 45 02 00 00       	jmp    0x389
 144:	49 bd 55 6c 69 6e 6b 	movabs r13,0x6b6e696c55
 14b:	00 00 00 
 14e:	e9 e1 01 00 00       	jmp    0x334
 153:	49 83 fe 3a          	cmp    r14,0x3a
 157:	0f 8f cf 00 00 00    	jg     0x22c
 15d:	49 83 fe 27          	cmp    r14,0x27
 161:	0f 84 87 01 00 00    	je     0x2ee
 167:	49 83 fe 38          	cmp    r14,0x38
 16b:	0f 84 36 01 00 00    	je     0x2a7
 171:	49 83 fe 39          	cmp    r14,0x39
 175:	74 05                	je     0x17c
 177:	e9 0d 02 00 00       	jmp    0x389
 17c:	41 bd 66 6f 72 6b    	mov    r13d,0x6b726f66
 182:	e9 ad 01 00 00       	jmp    0x334
 187:	49 81 fe 22 01 00 00 	cmp    r14,0x122
 18e:	0f 8f c6 00 00 00    	jg     0x25a
 194:	49 81 fe 01 01 00 00 	cmp    r14,0x101
 19b:	0f 84 59 01 00 00    	je     0x2fa
 1a1:	49 81 fe 07 01 00 00 	cmp    r14,0x107
 1a8:	0f 84 08 01 00 00    	je     0x2b6
 1ae:	49 81 fe 19 01 00 00 	cmp    r14,0x119
 1b5:	74 05                	je     0x1bc
 1b7:	e9 cd 01 00 00       	jmp    0x389
 1bc:	49 bd 73 74 61 74 32 	movabs r13,0x74613274617473
 1c3:	61 74 00 
 1c6:	e9 69 01 00 00       	jmp    0x334
 1cb:	49 83 fe 03          	cmp    r14,0x3
 1cf:	0f 84 31 01 00 00    	je     0x306
 1d5:	49 83 fe 09          	cmp    r14,0x9
 1d9:	0f 84 e3 00 00 00    	je     0x2c2
 1df:	49 83 fe 0c          	cmp    r14,0xc
 1e3:	74 05                	je     0x1ea
 1e5:	e9 9f 01 00 00       	jmp    0x389
 1ea:	41 bd 6b 62 72 6b    	mov    r13d,0x6b72626b
 1f0:	e9 3f 01 00 00       	jmp    0x334
 1f5:	49 81 fe 9e 00 00 00 	cmp    r14,0x9e
 1fc:	0f 84 10 01 00 00    	je     0x312
 202:	49 81 fe ca 00 00 00 	cmp    r14,0xca
 209:	0f 84 bb 00 00 00    	je     0x2ca
 20f:	49 81 fe d9 00 00 00 	cmp    r14,0xd9
 216:	74 05                	je     0x21d
 218:	e9 6c 01 00 00       	jmp    0x389
 21d:	49 bd 67 65 74 61 64 	movabs r13,0x646461746567
 224:	64 00 00 
 227:	e9 08 01 00 00       	jmp    0x334
 22c:	49 83 fe 3b          	cmp    r14,0x3b
 230:	0f 84 e8 00 00 00    	je     0x31e
 236:	49 83 fe 3c          	cmp    r14,0x3c
 23a:	0f 84 96 00 00 00    	je     0x2d6
 240:	49 83 fe 3d          	cmp    r14,0x3d
 244:	74 05                	je     0x24b
 246:	e9 3e 01 00 00       	jmp    0x389
 24b:	49 bd 55 77 61 69 74 	movabs r13,0x347469617755
 252:	34 00 00 
 255:	e9 da 00 00 00       	jmp    0x334
 25a:	49 81 fe 23 01 00 00 	cmp    r14,0x123
 261:	0f 84 c3 00 00 00    	je     0x32a
 267:	49 81 fe 41 01 00 00 	cmp    r14,0x141
 26e:	74 6e                	je     0x2de
 270:	49 81 fe 4c 01 00 00 	cmp    r14,0x14c
 277:	74 05                	je     0x27e
 279:	e9 0b 01 00 00       	jmp    0x389
 27e:	41 bd 73 61 74 78    	mov    r13d,0x78746173
 284:	e9 ab 00 00 00       	jmp    0x334
 289:	49 bd 77 72 69 74 65 	movabs r13,0x6574697277
 290:	00 00 00 
 293:	e9 9c 00 00 00       	jmp    0x334
 298:	49 bd 75 6e 6c 69 6e 	movabs r13,0x6b6e696c6e75
 29f:	6b 00 00 
 2a2:	e9 8d 00 00 00       	jmp    0x334
 2a7:	49 bd 55 63 6c 6f 6e 	movabs r13,0x656e6f6c6355
 2ae:	65 00 00 
 2b1:	e9 7e 00 00 00       	jmp    0x334
 2b6:	49 bd 75 6e 6c 69 6e 	movabs r13,0x74616b6e696c6e75
 2bd:	6b 61 74 
 2c0:	eb 72                	jmp    0x334
 2c2:	41 bd 6d 6d 61 70    	mov    r13d,0x70616d6d
 2c8:	eb 6a                	jmp    0x334
 2ca:	49 bd 55 66 75 74 65 	movabs r13,0x786574756655
 2d1:	78 00 00 
 2d4:	eb 5e                	jmp    0x334
 2d6:	41 bd 65 78 69 74    	mov    r13d,0x74697865
 2dc:	eb 56                	jmp    0x334
 2de:	41 bd 62 66 70 00    	mov    r13d,0x706662
 2e4:	eb 4e                	jmp    0x334
 2e6:	41 bd 63 68 64 69    	mov    r13d,0x69646863
 2ec:	eb 46                	jmp    0x334
 2ee:	49 bd 67 74 70 69 64 	movabs r13,0x6469707467
 2f5:	00 00 00 
 2f8:	eb 3a                	jmp    0x334
 2fa:	49 bd 6f 70 65 6e 61 	movabs r13,0x74616e65706f
 301:	74 00 00 
 304:	eb 2e                	jmp    0x334
 306:	49 bd 63 6c 6f 73 65 	movabs r13,0x65736f6c63
 30d:	00 00 00 
 310:	eb 22                	jmp    0x334
 312:	49 bd 61 72 63 68 5f 	movabs r13,0x6c74635f68637261
 319:	63 74 6c 
 31c:	eb 16                	jmp    0x334
 31e:	49 bd 65 78 65 63 76 	movabs r13,0x657663657865
 325:	65 00 00 
 328:	eb 0a                	jmp    0x334
 32a:	49 bd 73 69 67 6e 65 	movabs r13,0x647466656e676973
 331:	66 74 64 
 334:	48 c1 e3 20          	shl    rbx,0x20
 338:	48 c1 eb 20          	shr    rbx,0x20
 33c:	49 31 dd             	xor    r13,rbx
 33f:	48 89 f3             	mov    rbx,rsi
 342:	48 83 e3 07          	and    rbx,0x7
 346:	49 89 de             	mov    r14,rbx
 349:	49 83 f6 3f          	xor    r14,0x3f
 34d:	4d 89 ef             	mov    r15,r13
 350:	c4 42 8b f7 ff       	shrx   r15,r15,r14
 355:	49 89 de             	mov    r14,rbx
 358:	49 83 c6 01          	add    r14,0x1
 35c:	c4 42 89 f7 ed       	shlx   r13,r13,r14
 361:	4d 09 fd             	or     r13,r15
 364:	4d 01 c5             	add    r13,r8
 367:	48 c1 e3 03          	shl    rbx,0x3
 36b:	c4 e2 e1 f7 c0       	shlx   rax,rax,rbx
 370:	49 31 c5             	xor    r13,rax
 373:	48 83 c2 04          	add    rdx,0x4
 377:	48 83 c6 01          	add    rsi,0x1
 37b:	4d 89 e8             	mov    r8,r13
 37e:	48 83 fe 40          	cmp    rsi,0x40
 382:	74 19                	je     0x39d
 384:	e9 18 fd ff ff       	jmp    0xa1
 389:	48 c1 e3 20          	shl    rbx,0x20
 38d:	48 c1 eb 20          	shr    rbx,0x20
 391:	48 0f af d9          	imul   rbx,rcx
 395:	4c 31 c3             	xor    rbx,r8
 398:	49 89 dd             	mov    r13,rbx
 39b:	eb d6                	jmp    0x373
 39d:	4c 89 ee             	mov    rsi,r13
 3a0:	48 c1 ee 38          	shr    rsi,0x38
 3a4:	40 88 77 07          	mov    BYTE PTR [rdi+0x7],sil
 3a8:	4c 89 ee             	mov    rsi,r13
 3ab:	48 c1 ee 30          	shr    rsi,0x30
 3af:	40 88 77 06          	mov    BYTE PTR [rdi+0x6],sil
 3b3:	4c 89 ee             	mov    rsi,r13
 3b6:	48 c1 ee 28          	shr    rsi,0x28
 3ba:	40 88 77 05          	mov    BYTE PTR [rdi+0x5],sil
 3be:	4c 89 ee             	mov    rsi,r13
 3c1:	48 c1 ee 20          	shr    rsi,0x20
 3c5:	40 88 77 04          	mov    BYTE PTR [rdi+0x4],sil
 3c9:	4c 89 ee             	mov    rsi,r13
 3cc:	48 c1 ee 18          	shr    rsi,0x18
 3d0:	40 88 77 03          	mov    BYTE PTR [rdi+0x3],sil
 3d4:	4c 89 ee             	mov    rsi,r13
 3d7:	48 c1 ee 10          	shr    rsi,0x10
 3db:	40 88 77 02          	mov    BYTE PTR [rdi+0x2],sil
 3df:	44 88 6f 00          	mov    BYTE PTR [rdi+0x0],r13b
 3e3:	49 c1 ed 08          	shr    r13,0x8
 3e7:	44 88 6f 01          	mov    BYTE PTR [rdi+0x1],r13b
 3eb:	b8 02 00 00 00       	mov    eax,0x2
 3f0:	41 5f                	pop    r15
 3f2:	41 5e                	pop    r14
 3f4:	41 5d                	pop    r13
 3f6:	5b                   	pop    rbx
 3f7:	c9                   	leave
 3f8:	e9 bf 1e c1 d8       	jmp    0xffffffffd8c122bc
```

## llvmbpf JIT ASM
```asm
not captured
```
