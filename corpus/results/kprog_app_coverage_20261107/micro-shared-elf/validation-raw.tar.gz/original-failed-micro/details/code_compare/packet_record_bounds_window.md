# packet_record_bounds_window

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c1 2f 00 00 	lea    rdi,[rip+0x2fc1]        # 4008 <completed.0>
    1047:	48 8d 05 ba 2f 00 00 	lea    rax,[rip+0x2fba]        # 4008 <completed.0>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 91 2f 00 00 	lea    rdi,[rip+0x2f91]        # 4008 <completed.0>
    1077:	48 8d 35 8a 2f 00 00 	lea    rsi,[rip+0x2f8a]        # 4008 <completed.0>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 4d 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f4d],0x0        # 4008 <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 25 2f 00 00 01 	mov    BYTE PTR [rip+0x2f25],0x1        # 4008 <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <packet_record_bounds_window_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    1107:	48 89 ca             	mov    rdx,rcx
    110a:	31 c0                	xor    eax,eax
    110c:	48 39 f2             	cmp    rdx,rsi
    110f:	76 01                	jbe    1112 <packet_record_bounds_window_xdp+0x12>
    1111:	c3                   	ret
    1112:	48 8d 7a 08          	lea    rdi,[rdx+0x8]
    1116:	48 39 f7             	cmp    rdi,rsi
    1119:	77 f6                	ja     1111 <packet_record_bounds_window_xdp+0x11>
    111b:	48 8d ba 10 03 00 00 	lea    rdi,[rdx+0x310]
    1122:	48 39 f7             	cmp    rdi,rsi
    1125:	77 ea                	ja     1111 <packet_record_bounds_window_xdp+0x11>
    1127:	83 7a 08 20          	cmp    DWORD PTR [rdx+0x8],0x20
    112b:	75 e4                	jne    1111 <packet_record_bounds_window_xdp+0x11>
    112d:	83 7a 0c 18          	cmp    DWORD PTR [rdx+0xc],0x18
    1131:	75 de                	jne    1111 <packet_record_bounds_window_xdp+0x11>
    1133:	41 56                	push   r14
    1135:	53                   	push   rbx
    1136:	48 83 c2 27          	add    rdx,0x27
    113a:	49 b9 93 fd 59 66 b8 	movabs r9,0xd6e8feb86659fd93
    1141:	fe e8 d6 
    1144:	b8 00 03 00 00       	mov    eax,0x300
    1149:	31 f6                	xor    esi,esi
    114b:	eb 5e                	jmp    11ab <packet_record_bounds_window_xdp+0xab>
    114d:	0f 1f 00             	nop    DWORD PTR [rax]
    1150:	48 c1 e3 20          	shl    rbx,0x20
    1154:	45 89 db             	mov    r11d,r11d
    1157:	49 09 db             	or     r11,rbx
    115a:	4d 01 da             	add    r10,r11
    115d:	44 0f b7 5a ff       	movzx  r11d,WORD PTR [rdx-0x1]
    1162:	8d 1c bd 00 00 00 00 	lea    ebx,[rdi*4+0x0]
    1169:	80 e3 1c             	and    bl,0x1c
    116c:	c4 42 e1 f7 c9       	shlx   r9,r9,rbx
    1171:	4d 31 d1             	xor    r9,r10
    1174:	41 89 f2             	mov    r10d,esi
    1177:	41 80 e2 18          	and    r10b,0x18
    117b:	c4 42 a9 f7 d3       	shlx   r10,r11,r10
    1180:	4d 01 ca             	add    r10,r9
    1183:	83 e7 07             	and    edi,0x7
    1186:	44 31 c7             	xor    edi,r8d
    1189:	44 8d 47 01          	lea    r8d,[rdi+0x1]
    118d:	c4 42 b9 f7 c2       	shlx   r8,r10,r8
    1192:	40 f6 d7             	not    dil
    1195:	c4 42 c3 f7 ca       	shrx   r9,r10,rdi
    119a:	4d 09 c1             	or     r9,r8
    119d:	48 83 c6 08          	add    rsi,0x8
    11a1:	48 83 c2 18          	add    rdx,0x18
    11a5:	48 83 c0 e8          	add    rax,0xffffffffffffffe8
    11a9:	74 4c                	je     11f7 <packet_record_bounds_window_xdp+0xf7>
    11ab:	44 0f b6 42 e9       	movzx  r8d,BYTE PTR [rdx-0x17]
    11b0:	41 83 e0 03          	and    r8d,0x3
    11b4:	49 8d 78 18          	lea    rdi,[r8+0x18]
    11b8:	48 39 f8             	cmp    rax,rdi
    11bb:	72 e0                	jb     119d <packet_record_bounds_window_xdp+0x9d>
    11bd:	0f b6 7a ea          	movzx  edi,BYTE PTR [rdx-0x16]
    11c1:	44 8b 72 ed          	mov    r14d,DWORD PTR [rdx-0x13]
    11c5:	8b 5a f1             	mov    ebx,DWORD PTR [rdx-0xf]
    11c8:	44 8b 5a f5          	mov    r11d,DWORD PTR [rdx-0xb]
    11cc:	44 0f b7 52 fd       	movzx  r10d,WORD PTR [rdx-0x3]
    11d1:	4d 01 ce             	add    r14,r9
    11d4:	49 01 da             	add    r10,rbx
    11d7:	4d 01 f2             	add    r10,r14
    11da:	44 8b 4a f9          	mov    r9d,DWORD PTR [rdx-0x7]
    11de:	40 f6 c7 01          	test   dil,0x1
    11e2:	0f 84 68 ff ff ff    	je     1150 <packet_record_bounds_window_xdp+0x50>
    11e8:	49 c1 e3 20          	shl    r11,0x20
    11ec:	4d 09 cb             	or     r11,r9
    11ef:	4d 31 da             	xor    r10,r11
    11f2:	e9 66 ff ff ff       	jmp    115d <packet_record_bounds_window_xdp+0x5d>
    11f7:	4c 89 09             	mov    QWORD PTR [rcx],r9
    11fa:	b8 02 00 00 00       	mov    eax,0x2
    11ff:	5b                   	pop    rbx
    1200:	41 5e                	pop    r14
    1202:	c3                   	ret

Disassembly of section .fini:

0000000000001204 <_fini>:
    1204:	f3 0f 1e fa          	endbr64
    1208:	48 83 ec 08          	sub    rsp,0x8
    120c:	48 83 c4 08          	add    rsp,0x8
    1210:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 08 00 00 00 	sub    rsp,0x8
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
  20:	48 8b 4f 00          	mov    rcx,QWORD PTR [rdi+0x0]
  24:	48 39 f1             	cmp    rcx,rsi
  27:	0f 87 96 02 00 00    	ja     0x2c3
  2d:	48 89 cf             	mov    rdi,rcx
  30:	48 83 c7 08          	add    rdi,0x8
  34:	48 39 f7             	cmp    rdi,rsi
  37:	0f 87 86 02 00 00    	ja     0x2c3
  3d:	48 89 cf             	mov    rdi,rcx
  40:	48 81 c7 10 03 00 00 	add    rdi,0x310
  47:	48 39 f7             	cmp    rdi,rsi
  4a:	0f 87 73 02 00 00    	ja     0x2c3
  50:	48 0f b6 79 09       	movzx  rdi,BYTE PTR [rcx+0x9]
  55:	48 c1 e7 08          	shl    rdi,0x8
  59:	48 0f b6 71 08       	movzx  rsi,BYTE PTR [rcx+0x8]
  5e:	48 09 f7             	or     rdi,rsi
  61:	48 0f b6 71 0a       	movzx  rsi,BYTE PTR [rcx+0xa]
  66:	48 c1 e6 10          	shl    rsi,0x10
  6a:	48 09 f7             	or     rdi,rsi
  6d:	48 0f b6 71 0b       	movzx  rsi,BYTE PTR [rcx+0xb]
  72:	48 c1 e6 18          	shl    rsi,0x18
  76:	48 09 f7             	or     rdi,rsi
  79:	48 c1 e7 20          	shl    rdi,0x20
  7d:	48 c1 ef 20          	shr    rdi,0x20
  81:	48 83 ff 20          	cmp    rdi,0x20
  85:	0f 85 38 02 00 00    	jne    0x2c3
  8b:	48 0f b6 79 0d       	movzx  rdi,BYTE PTR [rcx+0xd]
  90:	48 c1 e7 08          	shl    rdi,0x8
  94:	48 0f b6 71 0c       	movzx  rsi,BYTE PTR [rcx+0xc]
  99:	48 09 f7             	or     rdi,rsi
  9c:	48 0f b6 71 0e       	movzx  rsi,BYTE PTR [rcx+0xe]
  a1:	48 c1 e6 10          	shl    rsi,0x10
  a5:	48 09 f7             	or     rdi,rsi
  a8:	48 0f b6 71 0f       	movzx  rsi,BYTE PTR [rcx+0xf]
  ad:	48 c1 e6 18          	shl    rsi,0x18
  b1:	48 09 f7             	or     rdi,rsi
  b4:	48 c1 e7 20          	shl    rdi,0x20
  b8:	48 c1 ef 20          	shr    rdi,0x20
  bc:	48 83 ff 18          	cmp    rdi,0x18
  c0:	0f 85 fd 01 00 00    	jne    0x2c3
  c6:	48 bb 93 fd 59 66 b8 	movabs rbx,0xd6e8feb86659fd93
  cd:	fe e8 d6 
  d0:	31 f6                	xor    esi,esi
  d2:	ba 00 03 00 00       	mov    edx,0x300
  d7:	48 89 4d f8          	mov    QWORD PTR [rbp-0x8],rcx
  db:	48 83 c1 14          	add    rcx,0x14
  df:	e9 8b 00 00 00       	jmp    0x16f
  e4:	49 c1 e7 20          	shl    r15,0x20
  e8:	48 c1 e3 20          	shl    rbx,0x20
  ec:	48 c1 eb 20          	shr    rbx,0x20
  f0:	49 09 df             	or     r15,rbx
  f3:	4d 01 fd             	add    r13,r15
  f6:	49 c1 e6 20          	shl    r14,0x20
  fa:	49 c1 ee 20          	shr    r14,0x20
  fe:	4c 89 eb             	mov    rbx,r13
 101:	48 0f b6 79 13       	movzx  rdi,BYTE PTR [rcx+0x13]
 106:	48 c1 e7 08          	shl    rdi,0x8
 10a:	4c 0f b6 69 12       	movzx  r13,BYTE PTR [rcx+0x12]
 10f:	4c 09 ef             	or     rdi,r13
 112:	49 89 f5             	mov    r13,rsi
 115:	49 83 e5 18          	and    r13,0x18
 119:	c4 e2 91 f7 ff       	shlx   rdi,rdi,r13
 11e:	49 89 c5             	mov    r13,rax
 121:	49 c1 e5 02          	shl    r13,0x2
 125:	49 83 e5 1c          	and    r13,0x1c
 129:	c4 42 91 f7 f6       	shlx   r14,r14,r13
 12e:	4c 31 f3             	xor    rbx,r14
 131:	48 01 fb             	add    rbx,rdi
 134:	48 83 e0 07          	and    rax,0x7
 138:	4c 31 c0             	xor    rax,r8
 13b:	48 89 c7             	mov    rdi,rax
 13e:	48 83 f7 3f          	xor    rdi,0x3f
 142:	49 89 d8             	mov    r8,rbx
 145:	c4 42 c3 f7 c0       	shrx   r8,r8,rdi
 14a:	48 83 c0 01          	add    rax,0x1
 14e:	c4 e2 f9 f7 db       	shlx   rbx,rbx,rax
 153:	4c 09 c3             	or     rbx,r8
 156:	48 83 c1 18          	add    rcx,0x18
 15a:	48 83 c2 e8          	add    rdx,0xffffffffffffffe8
 15e:	48 83 c6 08          	add    rsi,0x8
 162:	48 81 fe 00 01 00 00 	cmp    rsi,0x100
 169:	0f 84 ff 00 00 00    	je     0x26e
 16f:	4c 0f b6 41 fc       	movzx  r8,BYTE PTR [rcx-0x4]
 174:	49 83 e0 03          	and    r8,0x3
 178:	4c 89 c7             	mov    rdi,r8
 17b:	48 83 cf 18          	or     rdi,0x18
 17f:	48 39 d7             	cmp    rdi,rdx
 182:	77 d2                	ja     0x156
 184:	48 0f b6 41 fd       	movzx  rax,BYTE PTR [rcx-0x3]
 189:	4c 0f b6 79 05       	movzx  r15,BYTE PTR [rcx+0x5]
 18e:	49 c1 e7 08          	shl    r15,0x8
 192:	48 0f b6 79 04       	movzx  rdi,BYTE PTR [rcx+0x4]
 197:	49 09 ff             	or     r15,rdi
 19a:	4c 0f b6 69 01       	movzx  r13,BYTE PTR [rcx+0x1]
 19f:	49 c1 e5 08          	shl    r13,0x8
 1a3:	48 0f b6 79 00       	movzx  rdi,BYTE PTR [rcx+0x0]
 1a8:	49 09 fd             	or     r13,rdi
 1ab:	48 0f b6 79 02       	movzx  rdi,BYTE PTR [rcx+0x2]
 1b0:	48 c1 e7 10          	shl    rdi,0x10
 1b4:	49 09 fd             	or     r13,rdi
 1b7:	48 0f b6 79 03       	movzx  rdi,BYTE PTR [rcx+0x3]
 1bc:	48 c1 e7 18          	shl    rdi,0x18
 1c0:	49 09 fd             	or     r13,rdi
 1c3:	48 0f b6 79 06       	movzx  rdi,BYTE PTR [rcx+0x6]
 1c8:	48 c1 e7 10          	shl    rdi,0x10
 1cc:	49 09 ff             	or     r15,rdi
 1cf:	48 0f b6 79 11       	movzx  rdi,BYTE PTR [rcx+0x11]
 1d4:	48 c1 e7 08          	shl    rdi,0x8
 1d8:	4c 0f b6 71 10       	movzx  r14,BYTE PTR [rcx+0x10]
 1dd:	4c 09 f7             	or     rdi,r14
 1e0:	4c 0f b6 71 07       	movzx  r14,BYTE PTR [rcx+0x7]
 1e5:	49 c1 e6 18          	shl    r14,0x18
 1e9:	4d 09 f7             	or     r15,r14
 1ec:	49 01 dd             	add    r13,rbx
 1ef:	4c 0f b6 71 0d       	movzx  r14,BYTE PTR [rcx+0xd]
 1f4:	49 c1 e6 08          	shl    r14,0x8
 1f8:	48 0f b6 59 0c       	movzx  rbx,BYTE PTR [rcx+0xc]
 1fd:	49 09 de             	or     r14,rbx
 200:	48 0f b6 59 0e       	movzx  rbx,BYTE PTR [rcx+0xe]
 205:	48 c1 e3 10          	shl    rbx,0x10
 209:	49 09 de             	or     r14,rbx
 20c:	4d 01 fd             	add    r13,r15
 20f:	49 01 fd             	add    r13,rdi
 212:	48 0f b6 79 0f       	movzx  rdi,BYTE PTR [rcx+0xf]
 217:	48 c1 e7 18          	shl    rdi,0x18
 21b:	49 09 fe             	or     r14,rdi
 21e:	48 0f b6 59 09       	movzx  rbx,BYTE PTR [rcx+0x9]
 223:	48 c1 e3 08          	shl    rbx,0x8
 227:	48 0f b6 79 08       	movzx  rdi,BYTE PTR [rcx+0x8]
 22c:	48 09 fb             	or     rbx,rdi
 22f:	48 0f b6 79 0a       	movzx  rdi,BYTE PTR [rcx+0xa]
 234:	48 c1 e7 10          	shl    rdi,0x10
 238:	48 09 fb             	or     rbx,rdi
 23b:	48 0f b6 79 0b       	movzx  rdi,BYTE PTR [rcx+0xb]
 240:	48 c1 e7 18          	shl    rdi,0x18
 244:	48 09 fb             	or     rbx,rdi
 247:	48 89 c7             	mov    rdi,rax
 24a:	48 83 e7 01          	and    rdi,0x1
 24e:	48 85 ff             	test   rdi,rdi
 251:	0f 84 8d fe ff ff    	je     0xe4
 257:	48 c1 e3 20          	shl    rbx,0x20
 25b:	49 c1 e6 20          	shl    r14,0x20
 25f:	49 c1 ee 20          	shr    r14,0x20
 263:	4c 09 f3             	or     rbx,r14
 266:	49 31 dd             	xor    r13,rbx
 269:	e9 90 fe ff ff       	jmp    0xfe
 26e:	48 89 df             	mov    rdi,rbx
 271:	48 c1 ef 38          	shr    rdi,0x38
 275:	48 8b 75 f8          	mov    rsi,QWORD PTR [rbp-0x8]
 279:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 27d:	48 89 df             	mov    rdi,rbx
 280:	48 c1 ef 30          	shr    rdi,0x30
 284:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 288:	48 89 df             	mov    rdi,rbx
 28b:	48 c1 ef 28          	shr    rdi,0x28
 28f:	40 88 7e 05          	mov    BYTE PTR [rsi+0x5],dil
 293:	48 89 df             	mov    rdi,rbx
 296:	48 c1 ef 20          	shr    rdi,0x20
 29a:	40 88 7e 04          	mov    BYTE PTR [rsi+0x4],dil
 29e:	48 89 df             	mov    rdi,rbx
 2a1:	48 c1 ef 18          	shr    rdi,0x18
 2a5:	40 88 7e 03          	mov    BYTE PTR [rsi+0x3],dil
 2a9:	48 89 df             	mov    rdi,rbx
 2ac:	48 c1 ef 10          	shr    rdi,0x10
 2b0:	40 88 7e 02          	mov    BYTE PTR [rsi+0x2],dil
 2b4:	88 5e 00             	mov    BYTE PTR [rsi+0x0],bl
 2b7:	48 c1 eb 08          	shr    rbx,0x8
 2bb:	88 5e 01             	mov    BYTE PTR [rsi+0x1],bl
 2be:	b8 02 00 00 00       	mov    eax,0x2
 2c3:	41 5f                	pop    r15
 2c5:	41 5e                	pop    r14
 2c7:	41 5d                	pop    r13
 2c9:	5b                   	pop    rbx
 2ca:	c9                   	leave
 2cb:	e9 bc 1c a1 c8       	jmp    0xffffffffc8a11f8c
```

## llvmbpf JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	f3 0f 1e fa          	endbr64
   4:	8b 0f                	mov    ecx,DWORD PTR [rdi]
   6:	8b 57 04             	mov    edx,DWORD PTR [rdi+0x4]
   9:	31 c0                	xor    eax,eax
   b:	39 d1                	cmp    ecx,edx
   d:	0f 87 04 01 00 00    	ja     0x117
  13:	48 8d 71 08          	lea    rsi,[rcx+0x8]
  17:	48 39 d6             	cmp    rsi,rdx
  1a:	0f 87 f7 00 00 00    	ja     0x117
  20:	48 8d b1 10 03 00 00 	lea    rsi,[rcx+0x310]
  27:	48 39 d6             	cmp    rsi,rdx
  2a:	0f 87 e7 00 00 00    	ja     0x117
  30:	83 79 08 20          	cmp    DWORD PTR [rcx+0x8],0x20
  34:	0f 85 d1 00 00 00    	jne    0x10b
  3a:	83 79 0c 18          	cmp    DWORD PTR [rcx+0xc],0x18
  3e:	0f 85 c7 00 00 00    	jne    0x10b
  44:	53                   	push   rbx
  45:	48 8d 41 14          	lea    rax,[rcx+0x14]
  49:	49 b9 93 fd 59 66 b8 	movabs r9,0xd6e8feb86659fd93
  50:	fe e8 d6 
  53:	ba 00 03 00 00       	mov    edx,0x300
  58:	31 f6                	xor    esi,esi
  5a:	eb 65                	jmp    0xc1
  5c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  60:	48 c1 e3 20          	shl    rbx,0x20
  64:	49 09 da             	or     r10,rbx
  67:	4d 01 da             	add    r10,r11
  6a:	44 0f b7 58 12       	movzx  r11d,WORD PTR [rax+0x12]
  6f:	89 f3                	mov    ebx,esi
  71:	80 e3 18             	and    bl,0x18
  74:	c4 42 e1 f7 db       	shlx   r11,r11,rbx
  79:	42 8d 1c 85 00 00 00 	lea    ebx,[r8*4+0x0]
  80:	00 
  81:	80 e3 1c             	and    bl,0x1c
  84:	c4 42 e1 f7 c9       	shlx   r9,r9,rbx
  89:	4d 31 d1             	xor    r9,r10
  8c:	4d 01 d9             	add    r9,r11
  8f:	41 83 e0 07          	and    r8d,0x7
  93:	44 31 c7             	xor    edi,r8d
  96:	41 89 f8             	mov    r8d,edi
  99:	41 f6 d0             	not    r8b
  9c:	c4 42 bb f7 c1       	shrx   r8,r9,r8
  a1:	40 fe c7             	inc    dil
  a4:	c4 42 c1 f7 c9       	shlx   r9,r9,rdi
  a9:	4d 09 c1             	or     r9,r8
  ac:	48 83 c0 18          	add    rax,0x18
  b0:	48 83 c2 e8          	add    rdx,0xffffffffffffffe8
  b4:	48 83 c6 08          	add    rsi,0x8
  b8:	48 81 fe 00 01 00 00 	cmp    rsi,0x100
  bf:	74 4d                	je     0x10e
  c1:	0f b6 78 fc          	movzx  edi,BYTE PTR [rax-0x4]
  c5:	83 e7 03             	and    edi,0x3
  c8:	4c 8d 47 18          	lea    r8,[rdi+0x18]
  cc:	49 39 d0             	cmp    r8,rdx
  cf:	77 db                	ja     0xac
  d1:	44 0f b6 40 fd       	movzx  r8d,BYTE PTR [rax-0x3]
  d6:	44 8b 10             	mov    r10d,DWORD PTR [rax]
  d9:	8b 58 04             	mov    ebx,DWORD PTR [rax+0x4]
  dc:	44 0f b7 58 10       	movzx  r11d,WORD PTR [rax+0x10]
  e1:	4d 01 ca             	add    r10,r9
  e4:	49 01 db             	add    r11,rbx
  e7:	4d 01 d3             	add    r11,r10
  ea:	44 8b 48 0c          	mov    r9d,DWORD PTR [rax+0xc]
  ee:	44 8b 50 08          	mov    r10d,DWORD PTR [rax+0x8]
  f2:	41 f6 c0 01          	test   r8b,0x1
  f6:	0f 84 64 ff ff ff    	je     0x60
  fc:	49 c1 e2 20          	shl    r10,0x20
 100:	4d 09 ca             	or     r10,r9
 103:	4d 31 da             	xor    r10,r11
 106:	e9 5f ff ff ff       	jmp    0x6a
 10b:	31 c0                	xor    eax,eax
 10d:	c3                   	ret
 10e:	4c 89 09             	mov    QWORD PTR [rcx],r9
 111:	b8 02 00 00 00       	mov    eax,0x2
 116:	5b                   	pop    rbx
 117:	c3                   	ret
```
