# flow_5tuple_rss_hash

## Original C
```c
not captured
```

## Native ASM
```asm
Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    rsp,0x8
    1008:	48 8b 05 c1 2f 00 00 	mov    rax,QWORD PTR [rip+0x2fc1]        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   rax,rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   rax
    1016:	48 83 c4 08          	add    rsp,0x8
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 ca 2f 00 00    	push   QWORD PTR [rip+0x2fca]        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    QWORD PTR [rip+0x2fcc]        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	ff 25 aa 2f 00 00    	jmp    QWORD PTR [rip+0x2faa]        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	66 90                	xchg   ax,ax

Disassembly of section .text:

0000000000001040 <deregister_tm_clones>:
    1040:	48 8d 3d c9 2f 00 00 	lea    rdi,[rip+0x2fc9]        # 4010 <__TMC_END__>
    1047:	48 8d 05 c2 2f 00 00 	lea    rax,[rip+0x2fc2]        # 4010 <__TMC_END__>
    104e:	48 39 f8             	cmp    rax,rdi
    1051:	74 15                	je     1068 <deregister_tm_clones+0x28>
    1053:	48 8b 05 6e 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f6e]        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    105a:	48 85 c0             	test   rax,rax
    105d:	74 09                	je     1068 <deregister_tm_clones+0x28>
    105f:	ff e0                	jmp    rax
    1061:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
    1068:	c3                   	ret
    1069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001070 <register_tm_clones>:
    1070:	48 8d 3d 99 2f 00 00 	lea    rdi,[rip+0x2f99]        # 4010 <__TMC_END__>
    1077:	48 8d 35 92 2f 00 00 	lea    rsi,[rip+0x2f92]        # 4010 <__TMC_END__>
    107e:	48 29 fe             	sub    rsi,rdi
    1081:	48 89 f0             	mov    rax,rsi
    1084:	48 c1 ee 3f          	shr    rsi,0x3f
    1088:	48 c1 f8 03          	sar    rax,0x3
    108c:	48 01 c6             	add    rsi,rax
    108f:	48 d1 fe             	sar    rsi,1
    1092:	74 14                	je     10a8 <register_tm_clones+0x38>
    1094:	48 8b 05 3d 2f 00 00 	mov    rax,QWORD PTR [rip+0x2f3d]        # 3fd8 <_ITM_registerTMCloneTable@Base>
    109b:	48 85 c0             	test   rax,rax
    109e:	74 08                	je     10a8 <register_tm_clones+0x38>
    10a0:	ff e0                	jmp    rax
    10a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010b0 <__do_global_dtors_aux>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	80 3d 51 2f 00 00 00 	cmp    BYTE PTR [rip+0x2f51],0x0        # 400c <completed.0>
    10bb:	75 2b                	jne    10e8 <__do_global_dtors_aux+0x38>
    10bd:	55                   	push   rbp
    10be:	48 83 3d 1a 2f 00 00 	cmp    QWORD PTR [rip+0x2f1a],0x0        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10c5:	00 
    10c6:	48 89 e5             	mov    rbp,rsp
    10c9:	74 0c                	je     10d7 <__do_global_dtors_aux+0x27>
    10cb:	48 8b 3d 2e 2f 00 00 	mov    rdi,QWORD PTR [rip+0x2f2e]        # 4000 <__dso_handle>
    10d2:	e8 59 ff ff ff       	call   1030 <__cxa_finalize@plt>
    10d7:	e8 64 ff ff ff       	call   1040 <deregister_tm_clones>
    10dc:	c6 05 29 2f 00 00 01 	mov    BYTE PTR [rip+0x2f29],0x1        # 400c <completed.0>
    10e3:	5d                   	pop    rbp
    10e4:	c3                   	ret
    10e5:	0f 1f 00             	nop    DWORD PTR [rax]
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

00000000000010f0 <frame_dummy>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	e9 77 ff ff ff       	jmp    1070 <register_tm_clones>
    10f9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]

0000000000001100 <flow_5tuple_rss_hash_xdp>:
    1100:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    1103:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
    1107:	31 c0                	xor    eax,eax
    1109:	48 39 d1             	cmp    rcx,rdx
    110c:	0f 87 f2 01 00 00    	ja     1304 <flow_5tuple_rss_hash_xdp+0x204>
    1112:	48 8d 71 08          	lea    rsi,[rcx+0x8]
    1116:	48 39 d6             	cmp    rsi,rdx
    1119:	0f 87 e5 01 00 00    	ja     1304 <flow_5tuple_rss_hash_xdp+0x204>
    111f:	48 8d 71 16          	lea    rsi,[rcx+0x16]
    1123:	48 39 d6             	cmp    rsi,rdx
    1126:	0f 87 d8 01 00 00    	ja     1304 <flow_5tuple_rss_hash_xdp+0x204>
    112c:	55                   	push   rbp
    112d:	41 57                	push   r15
    112f:	41 56                	push   r14
    1131:	53                   	push   rbx
    1132:	66 0f 38 f0 79 14    	movbe  di,WORD PTR [rcx+0x14]
    1138:	0f b7 ff             	movzx  edi,di
    113b:	81 ff 00 08 00 00    	cmp    edi,0x800
    1141:	0f 85 b7 01 00 00    	jne    12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    1147:	48 8d 79 2a          	lea    rdi,[rcx+0x2a]
    114b:	48 39 d7             	cmp    rdi,rdx
    114e:	0f 87 aa 01 00 00    	ja     12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    1154:	0f b6 3e             	movzx  edi,BYTE PTR [rsi]
    1157:	41 89 f8             	mov    r8d,edi
    115a:	41 80 e0 f0          	and    r8b,0xf0
    115e:	41 80 f8 40          	cmp    r8b,0x40
    1162:	0f 85 96 01 00 00    	jne    12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    1168:	83 e7 0f             	and    edi,0xf
    116b:	40 80 ff 05          	cmp    dil,0x5
    116f:	0f 82 89 01 00 00    	jb     12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    1175:	48 8d 3c be          	lea    rdi,[rsi+rdi*4]
    1179:	48 39 d7             	cmp    rdi,rdx
    117c:	0f 87 7c 01 00 00    	ja     12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    1182:	44 0f b6 41 18       	movzx  r8d,BYTE PTR [rcx+0x18]
    1187:	0f b6 71 19          	movzx  esi,BYTE PTR [rcx+0x19]
    118b:	0f b6 59 1f          	movzx  ebx,BYTE PTR [rcx+0x1f]
    118f:	83 fb 11             	cmp    ebx,0x11
    1192:	74 09                	je     119d <flow_5tuple_rss_hash_xdp+0x9d>
    1194:	83 fb 06             	cmp    ebx,0x6
    1197:	0f 85 61 01 00 00    	jne    12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    119d:	4c 8d 4f 04          	lea    r9,[rdi+0x4]
    11a1:	49 39 d1             	cmp    r9,rdx
    11a4:	0f 87 54 01 00 00    	ja     12fe <flow_5tuple_rss_hash_xdp+0x1fe>
    11aa:	44 89 c0             	mov    eax,r8d
    11ad:	0f 38 f0 51 26       	movbe  edx,DWORD PTR [rcx+0x26]
    11b2:	c1 e0 08             	shl    eax,0x8
    11b5:	44 0f 38 f0 49 22    	movbe  r9d,DWORD PTR [rcx+0x22]
    11bb:	66 44 0f 38 f0 17    	movbe  r10w,WORD PTR [rdi]
    11c1:	09 f0                	or     eax,esi
    11c3:	41 0f b7 f2          	movzx  esi,r10w
    11c7:	66 0f 38 f0 7f 02    	movbe  di,WORD PTR [rdi+0x2]
    11cd:	0f b7 ff             	movzx  edi,di
    11d0:	46 8d 14 08          	lea    r10d,[rax+r9*1]
    11d4:	8d aa b9 79 37 9e    	lea    ebp,[rdx-0x61c88647]
    11da:	41 89 f3             	mov    r11d,esi
    11dd:	41 c1 e3 10          	shl    r11d,0x10
    11e1:	41 09 fb             	or     r11d,edi
    11e4:	46 8d 34 1b          	lea    r14d,[rbx+r11*1]
    11e8:	46 8d 3c 1b          	lea    r15d,[rbx+r11*1]
    11ec:	41 81 c7 78 56 34 12 	add    r15d,0x12345678
    11f3:	45 29 fa             	sub    r10d,r15d
    11f6:	41 81 c2 ef be ad de 	add    r10d,0xdeadbeef
    11fd:	c4 43 7b f0 ff 1c    	rorx   r15d,r15d,0x1c
    1203:	45 31 d7             	xor    r15d,r10d
    1206:	46 8d 14 32          	lea    r10d,[rdx+r14*1]
    120a:	41 81 c2 31 d0 6b b0 	add    r10d,0xb06bd031
    1211:	44 29 fd             	sub    ebp,r15d
    1214:	c4 43 7b f0 f7 1a    	rorx   r14d,r15d,0x1a
    121a:	41 31 ee             	xor    r14d,ebp
    121d:	45 01 d7             	add    r15d,r10d
    1220:	45 29 f2             	sub    r10d,r14d
    1223:	c4 c3 7b f0 ee 18    	rorx   ebp,r14d,0x18
    1229:	44 31 d5             	xor    ebp,r10d
    122c:	45 01 fe             	add    r14d,r15d
    122f:	41 29 ef             	sub    r15d,ebp
    1232:	c4 63 7b f0 d5 10    	rorx   r10d,ebp,0x10
    1238:	45 31 fa             	xor    r10d,r15d
    123b:	44 01 f5             	add    ebp,r14d
    123e:	45 29 d6             	sub    r14d,r10d
    1241:	c4 43 7b f0 fa 0d    	rorx   r15d,r10d,0xd
    1247:	45 31 f7             	xor    r15d,r14d
    124a:	41 01 ea             	add    r10d,ebp
    124d:	44 29 fd             	sub    ebp,r15d
    1250:	c4 43 7b f0 f7 1c    	rorx   r14d,r15d,0x1c
    1256:	41 31 ee             	xor    r14d,ebp
    1259:	41 31 d1             	xor    r9d,edx
    125c:	c4 43 7b f0 c9 19    	rorx   r9d,r9d,0x19
    1262:	45 01 d1             	add    r9d,r10d
    1265:	45 01 da             	add    r10d,r11d
    1268:	45 01 fa             	add    r10d,r15d
    126b:	89 da                	mov    edx,ebx
    126d:	c1 e2 18             	shl    edx,0x18
    1270:	09 c2                	or     edx,eax
    1272:	44 01 f2             	add    edx,r14d
    1275:	44 31 d2             	xor    edx,r10d
    1278:	c4 43 7b f0 da 12    	rorx   r11d,r10d,0x12
    127e:	44 29 da             	sub    edx,r11d
    1281:	41 31 d1             	xor    r9d,edx
    1284:	c4 63 7b f0 da 15    	rorx   r11d,edx,0x15
    128a:	45 29 d9             	sub    r9d,r11d
    128d:	45 31 ca             	xor    r10d,r9d
    1290:	c4 43 7b f0 d9 07    	rorx   r11d,r9d,0x7
    1296:	45 29 da             	sub    r10d,r11d
    1299:	44 31 d2             	xor    edx,r10d
    129c:	c4 43 7b f0 da 10    	rorx   r11d,r10d,0x10
    12a2:	44 29 da             	sub    edx,r11d
    12a5:	41 31 d1             	xor    r9d,edx
    12a8:	c4 63 7b f0 da 1c    	rorx   r11d,edx,0x1c
    12ae:	45 29 d9             	sub    r9d,r11d
    12b1:	45 31 ca             	xor    r10d,r9d
    12b4:	c4 43 7b f0 c9 12    	rorx   r9d,r9d,0x12
    12ba:	45 29 ca             	sub    r10d,r9d
    12bd:	44 31 d2             	xor    edx,r10d
    12c0:	c4 43 7b f0 ca 08    	rorx   r9d,r10d,0x8
    12c6:	c1 e0 10             	shl    eax,0x10
    12c9:	c1 e6 08             	shl    esi,0x8
    12cc:	09 f3                	or     ebx,esi
    12ce:	31 fb                	xor    ebx,edi
    12d0:	88 19                	mov    BYTE PTR [rcx],bl
    12d2:	88 79 01             	mov    BYTE PTR [rcx+0x1],bh
    12d5:	31 c6                	xor    esi,eax
    12d7:	c1 ee 10             	shr    esi,0x10
    12da:	40 88 71 02          	mov    BYTE PTR [rcx+0x2],sil
    12de:	44 88 41 03          	mov    BYTE PTR [rcx+0x3],r8b
    12e2:	44 29 ca             	sub    edx,r9d
    12e5:	88 51 04             	mov    BYTE PTR [rcx+0x4],dl
    12e8:	88 71 05             	mov    BYTE PTR [rcx+0x5],dh
    12eb:	89 d0                	mov    eax,edx
    12ed:	c1 e8 10             	shr    eax,0x10
    12f0:	88 41 06             	mov    BYTE PTR [rcx+0x6],al
    12f3:	c1 ea 18             	shr    edx,0x18
    12f6:	88 51 07             	mov    BYTE PTR [rcx+0x7],dl
    12f9:	b8 02 00 00 00       	mov    eax,0x2
    12fe:	5b                   	pop    rbx
    12ff:	41 5e                	pop    r14
    1301:	41 5f                	pop    r15
    1303:	5d                   	pop    rbp
    1304:	c3                   	ret

Disassembly of section .fini:

0000000000001308 <_fini>:
    1308:	f3 0f 1e fa          	endbr64
    130c:	48 83 ec 08          	sub    rsp,0x8
    1310:	48 83 c4 08          	add    rsp,0x8
    1314:	c3                   	ret
```

## Original Kernel JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	0f 1f 00             	nop    DWORD PTR [rax]
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 10 00 00 00 	sub    rsp,0x10
  13:	53                   	push   rbx
  14:	41 55                	push   r13
  16:	41 56                	push   r14
  18:	41 57                	push   r15
  1a:	31 c0                	xor    eax,eax
  1c:	48 8b 77 00          	mov    rsi,QWORD PTR [rdi+0x0]
  20:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
  24:	48 39 fe             	cmp    rsi,rdi
  27:	0f 87 bb 03 00 00    	ja     0x3e8
  2d:	48 89 f2             	mov    rdx,rsi
  30:	48 83 c2 08          	add    rdx,0x8
  34:	48 39 fa             	cmp    rdx,rdi
  37:	0f 87 ab 03 00 00    	ja     0x3e8
  3d:	49 89 f0             	mov    r8,rsi
  40:	49 83 c0 16          	add    r8,0x16
  44:	49 39 f8             	cmp    r8,rdi
  47:	0f 87 9b 03 00 00    	ja     0x3e8
  4d:	48 0f b6 56 14       	movzx  rdx,BYTE PTR [rsi+0x14]
  52:	48 c1 e2 08          	shl    rdx,0x8
  56:	48 0f b6 4e 15       	movzx  rcx,BYTE PTR [rsi+0x15]
  5b:	48 09 ca             	or     rdx,rcx
  5e:	48 81 e2 ff ff 00 00 	and    rdx,0xffff
  65:	48 81 fa 00 08 00 00 	cmp    rdx,0x800
  6c:	0f 85 76 03 00 00    	jne    0x3e8
  72:	48 89 f2             	mov    rdx,rsi
  75:	48 83 c2 2a          	add    rdx,0x2a
  79:	48 39 fa             	cmp    rdx,rdi
  7c:	0f 87 66 03 00 00    	ja     0x3e8
  82:	49 0f b6 50 00       	movzx  rdx,BYTE PTR [r8+0x0]
  87:	48 89 d1             	mov    rcx,rdx
  8a:	48 81 e1 f0 00 00 00 	and    rcx,0xf0
  91:	48 83 f9 40          	cmp    rcx,0x40
  95:	0f 85 4d 03 00 00    	jne    0x3e8
  9b:	48 83 e2 0f          	and    rdx,0xf
  9f:	b9 05 00 00 00       	mov    ecx,0x5
  a4:	48 39 d1             	cmp    rcx,rdx
  a7:	0f 87 3b 03 00 00    	ja     0x3e8
  ad:	48 c1 e2 02          	shl    rdx,0x2
  b1:	49 01 d0             	add    r8,rdx
  b4:	49 39 f8             	cmp    r8,rdi
  b7:	0f 87 2b 03 00 00    	ja     0x3e8
  bd:	48 0f b6 4e 19       	movzx  rcx,BYTE PTR [rsi+0x19]
  c2:	4c 0f b6 6e 18       	movzx  r13,BYTE PTR [rsi+0x18]
  c7:	48 0f b6 56 1f       	movzx  rdx,BYTE PTR [rsi+0x1f]
  cc:	48 83 fa 11          	cmp    rdx,0x11
  d0:	74 0a                	je     0xdc
  d2:	48 83 fa 06          	cmp    rdx,0x6
  d6:	0f 85 0c 03 00 00    	jne    0x3e8
  dc:	4c 89 c3             	mov    rbx,r8
  df:	48 83 c3 04          	add    rbx,0x4
  e3:	48 39 fb             	cmp    rbx,rdi
  e6:	0f 87 fc 02 00 00    	ja     0x3e8
  ec:	4c 89 ef             	mov    rdi,r13
  ef:	48 c1 e7 08          	shl    rdi,0x8
  f3:	48 09 cf             	or     rdi,rcx
  f6:	48 0f b6 46 26       	movzx  rax,BYTE PTR [rsi+0x26]
  fb:	48 c1 e0 18          	shl    rax,0x18
  ff:	48 0f b6 4e 27       	movzx  rcx,BYTE PTR [rsi+0x27]
 104:	48 c1 e1 10          	shl    rcx,0x10
 108:	48 09 c1             	or     rcx,rax
 10b:	4c 89 6d f8          	mov    QWORD PTR [rbp-0x8],r13
 10f:	4d 0f b6 68 00       	movzx  r13,BYTE PTR [r8+0x0]
 114:	49 c1 e5 08          	shl    r13,0x8
 118:	49 0f b6 40 01       	movzx  rax,BYTE PTR [r8+0x1]
 11d:	49 09 c5             	or     r13,rax
 120:	49 0f b6 40 03       	movzx  rax,BYTE PTR [r8+0x3]
 125:	4d 0f b6 40 02       	movzx  r8,BYTE PTR [r8+0x2]
 12a:	49 c1 e0 08          	shl    r8,0x8
 12e:	49 09 c0             	or     r8,rax
 131:	48 0f b6 46 28       	movzx  rax,BYTE PTR [rsi+0x28]
 136:	48 c1 e0 08          	shl    rax,0x8
 13a:	48 09 c1             	or     rcx,rax
 13d:	48 0f b6 46 22       	movzx  rax,BYTE PTR [rsi+0x22]
 142:	48 c1 e0 18          	shl    rax,0x18
 146:	48 0f b6 5e 23       	movzx  rbx,BYTE PTR [rsi+0x23]
 14b:	48 c1 e3 10          	shl    rbx,0x10
 14f:	48 09 c3             	or     rbx,rax
 152:	48 0f b6 46 24       	movzx  rax,BYTE PTR [rsi+0x24]
 157:	48 c1 e0 08          	shl    rax,0x8
 15b:	48 09 c3             	or     rbx,rax
 15e:	48 0f b6 46 25       	movzx  rax,BYTE PTR [rsi+0x25]
 163:	48 09 c3             	or     rbx,rax
 166:	48 0f b6 46 29       	movzx  rax,BYTE PTR [rsi+0x29]
 16b:	48 09 c1             	or     rcx,rax
 16e:	49 81 e0 ff ff 00 00 	and    r8,0xffff
 175:	4c 89 e8             	mov    rax,r13
 178:	49 89 c7             	mov    r15,rax
 17b:	49 81 e7 ff ff 00 00 	and    r15,0xffff
 182:	48 c1 e0 10          	shl    rax,0x10
 186:	4c 09 c0             	or     rax,r8
 189:	49 89 c5             	mov    r13,rax
 18c:	4c 89 6d f0          	mov    QWORD PTR [rbp-0x10],r13
 190:	49 c1 e7 08          	shl    r15,0x8
 194:	48 89 f8             	mov    rax,rdi
 197:	48 c1 e0 10          	shl    rax,0x10
 19b:	4d 89 fe             	mov    r14,r15
 19e:	49 31 c6             	xor    r14,rax
 1a1:	49 09 d7             	or     r15,rdx
 1a4:	4d 31 c7             	xor    r15,r8
 1a7:	4c 8b 45 f8          	mov    r8,QWORD PTR [rbp-0x8]
 1ab:	44 88 46 03          	mov    BYTE PTR [rsi+0x3],r8b
 1af:	49 89 d0             	mov    r8,rdx
 1b2:	4d 01 e8             	add    r8,r13
 1b5:	49 81 c0 78 56 34 12 	add    r8,0x12345678
 1bc:	41 bd 00 00 00 f0    	mov    r13d,0xf0000000
 1c2:	4c 89 c0             	mov    rax,r8
 1c5:	4c 21 e8             	and    rax,r13
 1c8:	48 c1 e8 1c          	shr    rax,0x1c
 1cc:	49 89 d5             	mov    r13,rdx
 1cf:	4c 89 c2             	mov    rdx,r8
 1d2:	48 c1 e2 04          	shl    rdx,0x4
 1d6:	48 09 c2             	or     rdx,rax
 1d9:	49 c1 e5 18          	shl    r13,0x18
 1dd:	49 09 fd             	or     r13,rdi
 1e0:	4c 89 6d f8          	mov    QWORD PTR [rbp-0x8],r13
 1e4:	48 01 df             	add    rdi,rbx
 1e7:	4c 29 c7             	sub    rdi,r8
 1ea:	48 81 c7 ef be ad de 	add    rdi,0xffffffffdeadbeef
 1f1:	48 31 d7             	xor    rdi,rdx
 1f4:	ba 00 00 00 fc       	mov    edx,0xfc000000
 1f9:	48 89 f8             	mov    rax,rdi
 1fc:	48 21 d0             	and    rax,rdx
 1ff:	48 c1 e8 1a          	shr    rax,0x1a
 203:	48 89 fa             	mov    rdx,rdi
 206:	48 c1 e2 06          	shl    rdx,0x6
 20a:	48 09 c2             	or     rdx,rax
 20d:	49 c1 ee 10          	shr    r14,0x10
 211:	44 88 76 02          	mov    BYTE PTR [rsi+0x2],r14b
 215:	48 31 cb             	xor    rbx,rcx
 218:	48 81 c1 b9 79 37 9e 	add    rcx,0xffffffff9e3779b9
 21f:	49 01 c8             	add    r8,rcx
 222:	48 29 f9             	sub    rcx,rdi
 225:	48 31 d1             	xor    rcx,rdx
 228:	ba 00 00 00 fe       	mov    edx,0xfe000000
 22d:	48 89 d8             	mov    rax,rbx
 230:	48 21 d0             	and    rax,rdx
 233:	48 c1 e3 07          	shl    rbx,0x7
 237:	48 c1 e8 19          	shr    rax,0x19
 23b:	48 09 c3             	or     rbx,rax
 23e:	44 88 7e 00          	mov    BYTE PTR [rsi+0x0],r15b
 242:	49 c1 ef 08          	shr    r15,0x8
 246:	44 88 7e 01          	mov    BYTE PTR [rsi+0x1],r15b
 24a:	ba 00 00 00 ff       	mov    edx,0xff000000
 24f:	48 89 c8             	mov    rax,rcx
 252:	48 21 d0             	and    rax,rdx
 255:	48 c1 e8 18          	shr    rax,0x18
 259:	48 89 ca             	mov    rdx,rcx
 25c:	48 c1 e2 08          	shl    rdx,0x8
 260:	48 09 c2             	or     rdx,rax
 263:	4c 01 c7             	add    rdi,r8
 266:	49 29 c8             	sub    r8,rcx
 269:	49 31 d0             	xor    r8,rdx
 26c:	b8 00 00 ff ff       	mov    eax,0xffff0000
 271:	4c 89 c2             	mov    rdx,r8
 274:	48 21 c2             	and    rdx,rax
 277:	48 c1 ea 10          	shr    rdx,0x10
 27b:	4c 89 c0             	mov    rax,r8
 27e:	48 c1 e0 10          	shl    rax,0x10
 282:	48 09 d0             	or     rax,rdx
 285:	48 01 f9             	add    rcx,rdi
 288:	4c 29 c7             	sub    rdi,r8
 28b:	48 31 c7             	xor    rdi,rax
 28e:	ba 00 e0 ff ff       	mov    edx,0xffffe000
 293:	48 89 f8             	mov    rax,rdi
 296:	48 21 d0             	and    rax,rdx
 299:	48 c1 e8 0d          	shr    rax,0xd
 29d:	48 89 fa             	mov    rdx,rdi
 2a0:	48 c1 e2 13          	shl    rdx,0x13
 2a4:	48 09 c2             	or     rdx,rax
 2a7:	49 01 c8             	add    r8,rcx
 2aa:	48 29 f9             	sub    rcx,rdi
 2ad:	48 31 d1             	xor    rcx,rdx
 2b0:	4c 01 c7             	add    rdi,r8
 2b3:	48 89 f8             	mov    rax,rdi
 2b6:	48 8b 55 f0          	mov    rdx,QWORD PTR [rbp-0x10]
 2ba:	48 01 d0             	add    rax,rdx
 2bd:	48 01 c8             	add    rax,rcx
 2c0:	41 be 00 00 fc ff    	mov    r14d,0xfffc0000
 2c6:	48 89 c2             	mov    rdx,rax
 2c9:	4c 21 f2             	and    rdx,r14
 2cc:	48 c1 ea 12          	shr    rdx,0x12
 2d0:	49 89 c7             	mov    r15,rax
 2d3:	49 c1 e7 0e          	shl    r15,0xe
 2d7:	49 09 d7             	or     r15,rdx
 2da:	48 89 ca             	mov    rdx,rcx
 2dd:	41 bd 00 00 00 f0    	mov    r13d,0xf0000000
 2e3:	4c 21 ea             	and    rdx,r13
 2e6:	48 c1 ea 1c          	shr    rdx,0x1c
 2ea:	49 29 c8             	sub    r8,rcx
 2ed:	48 c1 e1 04          	shl    rcx,0x4
 2f1:	48 09 d1             	or     rcx,rdx
 2f4:	49 31 c8             	xor    r8,rcx
 2f7:	48 01 df             	add    rdi,rbx
 2fa:	48 8b 55 f8          	mov    rdx,QWORD PTR [rbp-0x8]
 2fe:	49 01 d0             	add    r8,rdx
 301:	49 31 c0             	xor    r8,rax
 304:	4d 29 f8             	sub    r8,r15
 307:	ba 00 00 e0 ff       	mov    edx,0xffe00000
 30c:	4c 89 c1             	mov    rcx,r8
 30f:	48 21 d1             	and    rcx,rdx
 312:	48 c1 e9 15          	shr    rcx,0x15
 316:	4c 89 c3             	mov    rbx,r8
 319:	48 c1 e3 0b          	shl    rbx,0xb
 31d:	48 09 cb             	or     rbx,rcx
 320:	4c 89 c2             	mov    rdx,r8
 323:	48 31 fa             	xor    rdx,rdi
 326:	48 29 da             	sub    rdx,rbx
 329:	bf 80 ff ff ff       	mov    edi,0xffffff80
 32e:	48 89 d1             	mov    rcx,rdx
 331:	48 21 f9             	and    rcx,rdi
 334:	48 c1 e9 07          	shr    rcx,0x7
 338:	48 89 d7             	mov    rdi,rdx
 33b:	48 c1 e7 19          	shl    rdi,0x19
 33f:	48 09 cf             	or     rdi,rcx
 342:	48 89 d3             	mov    rbx,rdx
 345:	48 31 c3             	xor    rbx,rax
 348:	48 29 fb             	sub    rbx,rdi
 34b:	48 89 df             	mov    rdi,rbx
 34e:	b9 00 00 ff ff       	mov    ecx,0xffff0000
 353:	48 21 cf             	and    rdi,rcx
 356:	48 c1 ef 10          	shr    rdi,0x10
 35a:	48 89 d9             	mov    rcx,rbx
 35d:	48 c1 e1 10          	shl    rcx,0x10
 361:	48 09 f9             	or     rcx,rdi
 364:	48 89 df             	mov    rdi,rbx
 367:	4c 31 c7             	xor    rdi,r8
 36a:	48 29 cf             	sub    rdi,rcx
 36d:	48 89 f9             	mov    rcx,rdi
 370:	4c 21 e9             	and    rcx,r13
 373:	48 c1 e9 1c          	shr    rcx,0x1c
 377:	49 89 f8             	mov    r8,rdi
 37a:	49 c1 e0 04          	shl    r8,0x4
 37e:	49 09 c8             	or     r8,rcx
 381:	48 89 f9             	mov    rcx,rdi
 384:	48 31 d1             	xor    rcx,rdx
 387:	4c 29 c1             	sub    rcx,r8
 38a:	48 89 ca             	mov    rdx,rcx
 38d:	4c 21 f2             	and    rdx,r14
 390:	48 c1 ea 12          	shr    rdx,0x12
 394:	49 89 c8             	mov    r8,rcx
 397:	49 c1 e0 0e          	shl    r8,0xe
 39b:	49 09 d0             	or     r8,rdx
 39e:	48 31 d9             	xor    rcx,rbx
 3a1:	4c 29 c1             	sub    rcx,r8
 3a4:	ba 00 ff ff ff       	mov    edx,0xffffff00
 3a9:	49 89 c8             	mov    r8,rcx
 3ac:	49 21 d0             	and    r8,rdx
 3af:	49 c1 e8 08          	shr    r8,0x8
 3b3:	48 89 ca             	mov    rdx,rcx
 3b6:	48 c1 e2 18          	shl    rdx,0x18
 3ba:	4c 09 c2             	or     rdx,r8
 3bd:	48 31 f9             	xor    rcx,rdi
 3c0:	48 29 d1             	sub    rcx,rdx
 3c3:	48 89 cf             	mov    rdi,rcx
 3c6:	48 c1 ef 18          	shr    rdi,0x18
 3ca:	40 88 7e 07          	mov    BYTE PTR [rsi+0x7],dil
 3ce:	48 89 cf             	mov    rdi,rcx
 3d1:	48 c1 ef 10          	shr    rdi,0x10
 3d5:	40 88 7e 06          	mov    BYTE PTR [rsi+0x6],dil
 3d9:	88 4e 04             	mov    BYTE PTR [rsi+0x4],cl
 3dc:	48 c1 e9 08          	shr    rcx,0x8
 3e0:	88 4e 05             	mov    BYTE PTR [rsi+0x5],cl
 3e3:	b8 02 00 00 00       	mov    eax,0x2
 3e8:	41 5f                	pop    r15
 3ea:	41 5e                	pop    r14
 3ec:	41 5d                	pop    r13
 3ee:	5b                   	pop    rbx
 3ef:	c9                   	leave
 3f0:	e9 97 1b a1 c8       	jmp    0xffffffffc8a11f8c
```

## llvmbpf JIT ASM
```asm
Disassembly of section .data:

0000000000000000 <.data>:
   0:	f3 0f 1e fa          	endbr64
   4:	8b 0f                	mov    ecx,DWORD PTR [rdi]
   6:	8b 57 04             	mov    edx,DWORD PTR [rdi+0x4]
   9:	31 c0                	xor    eax,eax
   b:	39 d1                	cmp    ecx,edx
   d:	0f 87 65 02 00 00    	ja     0x278
  13:	48 8d 71 08          	lea    rsi,[rcx+0x8]
  17:	48 39 d6             	cmp    rsi,rdx
  1a:	0f 87 58 02 00 00    	ja     0x278
  20:	48 8d 71 16          	lea    rsi,[rcx+0x16]
  24:	48 39 d6             	cmp    rsi,rdx
  27:	76 03                	jbe    0x2c
  29:	31 c0                	xor    eax,eax
  2b:	c3                   	ret
  2c:	66 0f 38 f0 41 14    	movbe  ax,WORD PTR [rcx+0x14]
  32:	0f b7 f8             	movzx  edi,ax
  35:	31 c0                	xor    eax,eax
  37:	81 ff 00 08 00 00    	cmp    edi,0x800
  3d:	0f 85 35 02 00 00    	jne    0x278
  43:	48 8d 79 2a          	lea    rdi,[rcx+0x2a]
  47:	48 39 d7             	cmp    rdi,rdx
  4a:	0f 87 28 02 00 00    	ja     0x278
  50:	0f b6 06             	movzx  eax,BYTE PTR [rsi]
  53:	89 c7                	mov    edi,eax
  55:	83 e7 f0             	and    edi,0xfffffff0
  58:	83 ff 40             	cmp    edi,0x40
  5b:	75 cc                	jne    0x29
  5d:	83 e0 0f             	and    eax,0xf
  60:	48 83 f8 05          	cmp    rax,0x5
  64:	72 c3                	jb     0x29
  66:	48 8d 04 86          	lea    rax,[rsi+rax*4]
  6a:	48 39 d0             	cmp    rax,rdx
  6d:	77 ba                	ja     0x29
  6f:	0f b6 79 19          	movzx  edi,BYTE PTR [rcx+0x19]
  73:	44 0f b6 41 18       	movzx  r8d,BYTE PTR [rcx+0x18]
  78:	0f b6 71 1f          	movzx  esi,BYTE PTR [rcx+0x1f]
  7c:	83 fe 11             	cmp    esi,0x11
  7f:	74 05                	je     0x86
  81:	83 fe 06             	cmp    esi,0x6
  84:	75 a3                	jne    0x29
  86:	4c 8d 48 04          	lea    r9,[rax+0x4]
  8a:	49 39 d1             	cmp    r9,rdx
  8d:	77 9a                	ja     0x29
  8f:	41 56                	push   r14
  91:	53                   	push   rbx
  92:	41 0f b6 d0          	movzx  edx,r8b
  96:	66 44 0f 38 f0 08    	movbe  r9w,WORD PTR [rax]
  9c:	66 44 0f 38 f0 50 02 	movbe  r10w,WORD PTR [rax+0x2]
  a3:	44 0f 38 f0 41 22    	movbe  r8d,DWORD PTR [rcx+0x22]
  a9:	0f 38 f0 41 26       	movbe  eax,DWORD PTR [rcx+0x26]
  ae:	88 51 03             	mov    BYTE PTR [rcx+0x3],dl
  b1:	41 89 d3             	mov    r11d,edx
  b4:	41 c1 e3 08          	shl    r11d,0x8
  b8:	49 09 fb             	or     r11,rdi
  bb:	41 0f b7 fa          	movzx  edi,r10w
  bf:	45 0f b7 d1          	movzx  r10d,r9w
  c3:	44 89 d2             	mov    edx,r10d
  c6:	c1 e2 10             	shl    edx,0x10
  c9:	48 09 fa             	or     rdx,rdi
  cc:	41 c1 e2 08          	shl    r10d,0x8
  d0:	45 89 d9             	mov    r9d,r11d
  d3:	41 c1 e1 10          	shl    r9d,0x10
  d7:	45 31 d1             	xor    r9d,r10d
  da:	49 8d 1c 32          	lea    rbx,[r10+rsi*1]
  de:	48 31 fb             	xor    rbx,rdi
  e1:	4c 8d 14 16          	lea    r10,[rsi+rdx*1]
  e5:	48 8d 3c 16          	lea    rdi,[rsi+rdx*1]
  e9:	48 81 c7 78 56 34 12 	add    rdi,0x12345678
  f0:	49 89 fe             	mov    r14,rdi
  f3:	c1 e6 18             	shl    esi,0x18
  f6:	4c 09 de             	or     rsi,r11
  f9:	49 29 fb             	sub    r11,rdi
  fc:	c1 ef 1c             	shr    edi,0x1c
  ff:	49 c1 e6 04          	shl    r14,0x4
 103:	49 09 fe             	or     r14,rdi
 106:	4b 8d 3c 03          	lea    rdi,[r11+r8*1]
 10a:	48 81 c7 ef be ad de 	add    rdi,0xffffffffdeadbeef
 111:	4c 31 f7             	xor    rdi,r14
 114:	41 89 fb             	mov    r11d,edi
 117:	41 c1 eb 1a          	shr    r11d,0x1a
 11b:	49 89 fe             	mov    r14,rdi
 11e:	49 c1 e6 06          	shl    r14,0x6
 122:	4d 09 de             	or     r14,r11
 125:	41 c1 e9 10          	shr    r9d,0x10
 129:	44 88 49 02          	mov    BYTE PTR [rcx+0x2],r9b
 12d:	49 31 c0             	xor    r8,rax
 130:	4e 8d 0c 10          	lea    r9,[rax+r10*1]
 134:	49 81 c1 31 d0 6b b0 	add    r9,0xffffffffb06bd031
 13b:	48 05 b9 79 37 9e    	add    rax,0xffffffff9e3779b9
 141:	48 29 f8             	sub    rax,rdi
 144:	4c 31 f0             	xor    rax,r14
 147:	4d 89 c2             	mov    r10,r8
 14a:	49 c1 e2 07          	shl    r10,0x7
 14e:	41 c1 e8 19          	shr    r8d,0x19
 152:	88 19                	mov    BYTE PTR [rcx],bl
 154:	4d 09 d0             	or     r8,r10
 157:	88 79 01             	mov    BYTE PTR [rcx+0x1],bh
 15a:	41 89 c2             	mov    r10d,eax
 15d:	41 c1 ea 18          	shr    r10d,0x18
 161:	49 89 c3             	mov    r11,rax
 164:	49 c1 e3 08          	shl    r11,0x8
 168:	4d 09 d3             	or     r11,r10
 16b:	4c 01 cf             	add    rdi,r9
 16e:	49 29 c1             	sub    r9,rax
 171:	4d 31 d9             	xor    r9,r11
 174:	45 89 ca             	mov    r10d,r9d
 177:	41 c1 ea 10          	shr    r10d,0x10
 17b:	4d 89 cb             	mov    r11,r9
 17e:	49 c1 e3 10          	shl    r11,0x10
 182:	4d 09 d3             	or     r11,r10
 185:	48 01 f8             	add    rax,rdi
 188:	4c 29 cf             	sub    rdi,r9
 18b:	4c 31 df             	xor    rdi,r11
 18e:	41 89 fa             	mov    r10d,edi
 191:	41 c1 ea 0d          	shr    r10d,0xd
 195:	49 89 fb             	mov    r11,rdi
 198:	49 c1 e3 13          	shl    r11,0x13
 19c:	4d 09 d3             	or     r11,r10
 19f:	49 01 c1             	add    r9,rax
 1a2:	48 29 f8             	sub    rax,rdi
 1a5:	4c 31 d8             	xor    rax,r11
 1a8:	4c 01 cf             	add    rdi,r9
 1ab:	48 01 fa             	add    rdx,rdi
 1ae:	48 01 c2             	add    rdx,rax
 1b1:	41 89 d2             	mov    r10d,edx
 1b4:	41 c1 ea 12          	shr    r10d,0x12
 1b8:	49 89 d3             	mov    r11,rdx
 1bb:	49 c1 e3 0e          	shl    r11,0xe
 1bf:	4d 09 d3             	or     r11,r10
 1c2:	41 89 c2             	mov    r10d,eax
 1c5:	41 c1 ea 1c          	shr    r10d,0x1c
 1c9:	49 29 c1             	sub    r9,rax
 1cc:	48 c1 e0 04          	shl    rax,0x4
 1d0:	4c 09 d0             	or     rax,r10
 1d3:	4c 31 c8             	xor    rax,r9
 1d6:	48 01 f0             	add    rax,rsi
 1d9:	4c 01 c7             	add    rdi,r8
 1dc:	48 31 d0             	xor    rax,rdx
 1df:	4c 29 d8             	sub    rax,r11
 1e2:	89 c6                	mov    esi,eax
 1e4:	c1 ee 15             	shr    esi,0x15
 1e7:	48 31 c7             	xor    rdi,rax
 1ea:	49 89 c0             	mov    r8,rax
 1ed:	49 c1 e0 0b          	shl    r8,0xb
 1f1:	49 09 f0             	or     r8,rsi
 1f4:	4c 29 c7             	sub    rdi,r8
 1f7:	89 fe                	mov    esi,edi
 1f9:	c1 ee 07             	shr    esi,0x7
 1fc:	48 31 fa             	xor    rdx,rdi
 1ff:	49 89 f8             	mov    r8,rdi
 202:	49 c1 e0 19          	shl    r8,0x19
 206:	49 09 f0             	or     r8,rsi
 209:	4c 29 c2             	sub    rdx,r8
 20c:	89 d6                	mov    esi,edx
 20e:	c1 ee 10             	shr    esi,0x10
 211:	48 31 d0             	xor    rax,rdx
 214:	49 89 d0             	mov    r8,rdx
 217:	49 c1 e0 10          	shl    r8,0x10
 21b:	49 09 f0             	or     r8,rsi
 21e:	4c 29 c0             	sub    rax,r8
 221:	89 c6                	mov    esi,eax
 223:	c1 ee 1c             	shr    esi,0x1c
 226:	48 31 c7             	xor    rdi,rax
 229:	49 89 c0             	mov    r8,rax
 22c:	49 c1 e0 04          	shl    r8,0x4
 230:	49 09 f0             	or     r8,rsi
 233:	4c 29 c7             	sub    rdi,r8
 236:	89 fe                	mov    esi,edi
 238:	c1 ee 12             	shr    esi,0x12
 23b:	48 31 fa             	xor    rdx,rdi
 23e:	48 c1 e7 0e          	shl    rdi,0xe
 242:	48 09 f7             	or     rdi,rsi
 245:	48 29 fa             	sub    rdx,rdi
 248:	89 d6                	mov    esi,edx
 24a:	c1 ee 08             	shr    esi,0x8
 24d:	48 31 d0             	xor    rax,rdx
 250:	48 c1 e2 18          	shl    rdx,0x18
 254:	48 09 f2             	or     rdx,rsi
 257:	48 29 d0             	sub    rax,rdx
 25a:	89 c2                	mov    edx,eax
 25c:	c1 ea 18             	shr    edx,0x18
 25f:	88 51 07             	mov    BYTE PTR [rcx+0x7],dl
 262:	89 c2                	mov    edx,eax
 264:	c1 ea 10             	shr    edx,0x10
 267:	88 51 06             	mov    BYTE PTR [rcx+0x6],dl
 26a:	88 41 04             	mov    BYTE PTR [rcx+0x4],al
 26d:	88 61 05             	mov    BYTE PTR [rcx+0x5],ah
 270:	b8 02 00 00 00       	mov    eax,0x2
 275:	5b                   	pop    rbx
 276:	41 5e                	pop    r14
 278:	c3                   	ret
```
