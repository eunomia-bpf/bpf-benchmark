#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <linux/bpf.h>
struct prog_entry {const char *name;uint32_t insn_cnt,prog_type,expected_attach_type,attach_btf_id;uint64_t hash,policy_hash;};
static int shim_native_loader_is_libbpf_probe(const struct prog_entry *prog) {
    const char *name = prog ? prog->name : "";
    uint32_t insn_cnt = prog ? prog->insn_cnt : 0;

    if ((!name || !name[0]) && insn_cnt <= 2)
        return 1;
    if (prog && (!name || !name[0]) && insn_cnt <= 4 &&
        (prog->prog_type == BPF_PROG_TYPE_CGROUP_SOCK ||
         prog->prog_type == BPF_PROG_TYPE_CGROUP_SOCK_ADDR ||
         prog->prog_type == BPF_PROG_TYPE_CGROUP_SOCKOPT ||
         prog->prog_type == BPF_PROG_TYPE_XDP ||
         prog->prog_type == BPF_PROG_TYPE_SCHED_CLS ||
         prog->prog_type == BPF_PROG_TYPE_SCHED_ACT)) {
        return 1;
    }
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_SOCKET_FILTER &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt <= 5)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_TRACEPOINT &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt <= 6)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 11 && prog->policy_hash == 0x7f60b6fbd3faebcfULL)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_TRACING &&
        prog->expected_attach_type != 0 && prog->attach_btf_id != 0 &&
        insn_cnt == 3 && prog->hash == 0x145b4e38542e17e8ULL)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_KPROBE &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt <= 6)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_LSM &&
        prog->expected_attach_type == BPF_LSM_MAC &&
        prog->attach_btf_id != 0 && insn_cnt == 3 &&
        prog->hash == 0x145b4e38542e17e8ULL)
        return 1;
    if (name && strcmp(name, "libbpf_nametest") == 0 && insn_cnt <= 2)
        return 1;
    if (name && strcmp(name, "det_arg_ctx") == 0 && insn_cnt <= 4)
        return 1;
    if (prog && name && strcmp(name, "test") == 0 &&
        prog->prog_type == BPF_PROG_TYPE_XDP && prog->expected_attach_type == 0 &&
        prog->attach_btf_id == 0 && insn_cnt == 6 &&
        prog->hash == 0xf2c52b5b17d11f48ULL)
        return 1;
    if (prog && (!name || !name[0]) &&
        prog->prog_type == BPF_PROG_TYPE_SOCKET_FILTER &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 4097 && prog->hash == 0xdad2efe83d9579b0ULL)
        return 1;
    if (prog && name && strcmp(name, "probe_fib_looku") == 0 &&
        prog->prog_type == BPF_PROG_TYPE_SCHED_CLS &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 23 && (prog->hash == 0xf436d54fbd8c7ea7ULL ||
                           prog->hash == 0xca5c856e97173b3bULL ||
                           prog->hash == 0xb81a739a980c3e63ULL))
        return 1;
    if (prog && name && strcmp(name, "adjust_mac_room") == 0 &&
        prog->prog_type == BPF_PROG_TYPE_SCHED_CLS &&
        prog->expected_attach_type == 0 && prog->attach_btf_id == 0 &&
        insn_cnt == 5 && prog->hash == 0x708e759c87fe3b92ULL)
        return 1;
    if (prog && name &&
        (strcmp(name, "probe_bpf_kprob") == 0 ||
         strcmp(name, "probe_bpf_perf_") == 0 ||
         strcmp(name, "probe_kpm_link") == 0 ||
         strcmp(name, "probe_upm_link") == 0 ||
         strcmp(name, "probe_fmod_ret") == 0 ||
         strcmp(name, "probe_sys_fmod_") == 0 ||
         strcmp(name, "probe_lsm_file_") == 0 ||
         strcmp(name, "probe_get_func_") == 0 ||
         strcmp(name, "uprobe_regs") == 0) &&
        insn_cnt <= 6)
        return 1;
    return 0;
}

int main(void) {struct prog_entry p;char name[128];while(scanf("%u %u %u %u %"SCNx64" %"SCNx64" %127s",&p.prog_type,&p.expected_attach_type,&p.attach_btf_id,&p.insn_cnt,&p.hash,&p.policy_hash,name)==7) {p.name=strcmp(name,"-")?name:"";printf("%d\n",shim_native_loader_is_libbpf_probe(&p));}return ferror(stdin)?1:0;}
