set -eu
D=/workspaces/.agent-state/kprog-lanes/C/native-core-helper-candidate
trap 'echo $? > "$D/host.exit"' EXIT
cd "$D"
for arch in x86 arm64; do
 for flavor in kernel legacy; do
  extra=""; if test "$flavor" = legacy; then extra=-DMICRO_NATIVE_TETRAGON; fi
  for epoch in before candidate; do
   cc -O2 -g -Wall -Wextra -fsanitize=undefined -fno-sanitize-recover=undefined -D__TARGET_ARCH_$arch $extra -DCOMPAT_HEADER=\"$epoch.h\" helper-contract.c -o "$epoch-$arch-$flavor"
   arg=0; if test "$epoch" = candidate; then arg=1; fi
   "./$epoch-$arch-$flavor" "$arg"
  done
 done
 done
