#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <unistd.h>
#define MICRO_NATIVE
#ifndef COMPAT_HEADER
#define COMPAT_HEADER "candidate.h"
#endif
#include COMPAT_HEADER
struct pt_regs { unsigned long long regs[31],orig_x0,pc,di,si,dx,cx,r8,r9,r10,sp,bp,ax,ip; };
struct fields { unsigned char a;unsigned short b;unsigned c;unsigned long long d; };
static unsigned calls,last_id;static int last_result;static const void *last_address;static unsigned last_size;
static long read_helper(unsigned id,void *dst,unsigned size,const void *src) {
 calls++;last_id=id;last_address=src;last_size=size;
 struct iovec to={dst,size},from={(void*)src,size};ssize_t n=process_vm_readv(getpid(),&to,1,&from,1,0);
 if(n!=(ssize_t)size) { memset(dst,0,size);last_result=-EFAULT;return -EFAULT; }
 last_result=0;return 0;
}
long bpf_probe_read_kernel(void *d,unsigned n,const void *s) {return read_helper(113,d,n,s);}
long bpf_probe_read(void *d,unsigned n,const void *s) {return read_helper(4,d,n,s);}
long bpf_probe_read_user(void *d,unsigned n,const void *s) {return read_helper(112,d,n,s);}
static unsigned long long core(unsigned op,struct pt_regs *p) {
 switch(op) {
 case 0:return PT_REGS_RET_CORE(p);
 case 1:return PT_REGS_FP_CORE(p);
 case 2:return PT_REGS_RC_CORE(p);
 case 3:return PT_REGS_SP_CORE(p);
 case 4:return PT_REGS_IP_CORE(p);
 case 5:return PT_REGS_PARM1_CORE(p);
 case 6:return PT_REGS_PARM2_CORE(p);
 case 7:return PT_REGS_PARM3_CORE(p);
 case 8:return PT_REGS_PARM4_CORE(p);
 case 9:return PT_REGS_PARM5_CORE(p);
 case 10:return PT_REGS_PARM6_CORE(p);
 case 11:return PT_REGS_PARM1_CORE_SYSCALL(p);
 case 12:return PT_REGS_PARM2_CORE_SYSCALL(p);
 case 13:return PT_REGS_PARM3_CORE_SYSCALL(p);
 case 14:return PT_REGS_PARM4_CORE_SYSCALL(p);
 case 15:return PT_REGS_PARM5_CORE_SYSCALL(p);
 case 16:return PT_REGS_PARM6_CORE_SYSCALL(p);
 case 17:return BPF_CORE_READ(p,di);
 case 18:return BPF_CORE_READ((const struct pt_regs *)p,di);
 case 19:{unsigned long long v;BPF_CORE_READ_INTO(&v,p,di);return v;}
 case 20:{unsigned long long v;bpf_core_read(&v,sizeof(v),&p->di);return v;}
 } abort();
}
static const void *address(unsigned op,struct pt_regs *p) {
#ifdef __TARGET_ARCH_arm64
 const unsigned long long *a[]={&p->regs[30],&p->regs[29],&p->regs[0],&p->sp,&p->pc,&p->regs[0],&p->regs[1],&p->regs[2],&p->regs[3],&p->regs[4],&p->regs[5],&p->orig_x0,&p->regs[1],&p->regs[2],&p->regs[3],&p->regs[4],&p->regs[5]};
#else
 const unsigned long long *a[]={&p->sp,&p->bp,&p->ax,&p->sp,&p->ip,&p->di,&p->si,&p->dx,&p->cx,&p->r8,&p->r9,&p->di,&p->si,&p->dx,&p->r10,&p->r8,&p->r9};
#endif
 return op<17?a[op]:&p->di;
}
int main(int argc,char **argv) {
 if(argc!=2)return 2;
 int candidate=atoi(argv[1]);unsigned long cases=0,elided=0,faults=0;
#ifdef MICRO_NATIVE_TETRAGON
 unsigned expected_id=4;
#else
 unsigned expected_id=113;
#endif
 for(unsigned seed=0;seed<1024;seed++) {
  struct pt_regs p;unsigned long long *words=(void*)&p;
  for(unsigned i=0;i<sizeof(p)/8;i++)words[i]=0xfedcab9876543210ULL^(0x9e3779b97f4a7c15ULL*(seed+1)*(i+1));
  for(unsigned op=0;op<21;op++) {
   calls=0;unsigned long long v=core(op,&p),want=*(const unsigned long long*)address(op,&p);unsigned expected_calls=(candidate||op>=19)?1:0;
   if(v!=want||calls!=expected_calls||(calls&&(last_id!=expected_id||last_address!=address(op,&p)||last_size!=8||last_result))) {printf("core contract difference op=%u calls=%u value=%llu expected=%llu\n",op,calls,v,want);return 1;}
   elided+=calls==0;cases++;
  }
  calls=0;unsigned long long direct=PT_REGS_PARM1(&p);if(calls||direct!=*(const unsigned long long*)address(5,&p))return 1;
  struct fields f={(unsigned char)seed,(unsigned short)(seed*57),seed*1000001U,words[0]};
#define FIELD(F,N) do {calls=0;unsigned long long v=BPF_CORE_READ(&f,F);if(v!=f.F||calls!=1||last_size!=N||last_address!=&f.F||last_id!=expected_id)return 1;cases++;} while(0)
  FIELD(a,1);FIELD(b,2);FIELD(c,4);FIELD(d,8);
 }
 if(candidate) {
  void *bad=mmap(0,4096,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(bad==MAP_FAILED)return 2;
  for(unsigned op=0;op<21;op++) {calls=0;unsigned long long v=core(op,bad);if(v||calls!=1||last_result!=-EFAULT||last_id!=expected_id)return 1;faults++;}
  munmap(bad,4096);
 }
 printf("generic CORE helper contract: cases=%lu helper_elisions=%lu protected_reads=%lu differences=0\n",cases,elided,faults);return 0;
}
