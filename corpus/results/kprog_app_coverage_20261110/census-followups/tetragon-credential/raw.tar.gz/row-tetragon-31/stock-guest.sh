#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/replay-claude/census/tetragon-credential/row-tetragon-31
mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
insmod "$D/stock-runtime/kprog_stock.ko"
export CLANG="$D/stock-compile-proxy" PYTHONDONTWRITEBYTECODE=1
python3 /workspaces/repository/kprog/corpus_resident_verifier.py guest --scratch "$D"
