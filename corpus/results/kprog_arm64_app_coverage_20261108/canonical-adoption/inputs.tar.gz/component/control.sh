F=/workspaces/.agent-state/kprog-lanes/A/design-only/canonical-adoption
cd /workspaces/repository || exit
taskset -c 16-19 unshare --mount --propagation private sh "$F/control-inside.sh" > "$F/control.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$F/control.exit"
exit "$rc"
