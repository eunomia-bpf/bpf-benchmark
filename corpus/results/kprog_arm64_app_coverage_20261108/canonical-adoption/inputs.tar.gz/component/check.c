#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"
static unsigned long cases;
static uint64_t mask(unsigned width) { return width==8 ? UINT64_MAX : (UINT64_C(1)<<(8*width))-1; }
static int test_cb(struct __sk_buff *ctx, unsigned width, unsigned off, int alias, uint64_t value) {
 ARM64_SIM_ENTRY_SKB(ctx);
 if (__a64_x0.ptr != (void *)ctx) return 1;
 ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X1,(__u8 *)__a64_x0.ptr+alias,ARM64_SIM_TAG_ABI);
 unsigned char expected[sizeof(*ctx)]; memcpy(expected,ctx,sizeof(*ctx));
 uint64_t before=0; memcpy(&before,expected+offsetof(struct __sk_buff,cb)+off,width);
 uint64_t got=ARM64_SIM_L_MEM_READ(ARM64_X1,ARM64_REG_NONE,0,ARM64_SKB_CB_OFF+off-alias,0,width);
 if (got!=(before&mask(width))) return 2;
 memcpy(expected+offsetof(struct __sk_buff,cb)+off,&value,width);
 ARM64_SIM_L_MEM_WRITE(ARM64_X1,ARM64_REG_NONE,0,ARM64_SKB_CB_OFF+off-alias,0,width,value,ARM64_SIM_TAG_SCALAR);
 if (memcmp(expected,ctx,sizeof(*ctx))) return 3;
 got=ARM64_SIM_L_MEM_READ(ARM64_X1,ARM64_REG_NONE,0,ARM64_SKB_CB_OFF+off-alias,0,width);
 cases++;return got!=(value&mask(width)) ? 4:0;
}
static int test_packet(struct __sk_buff *ctx,unsigned width,unsigned lane,int alias,int end) {
 ARM64_SIM_ENTRY_SKB(ctx);
 ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X1,(__u8 *)__a64_x0.ptr+alias,ARM64_SIM_TAG_ABI);
 long off=(end ? ARM64_SKB_DATA_END_OFF:ARM64_SKB_DATA_OFF)+lane-alias;
 uint64_t got=ARM64_SIM_L_MEM_READ(ARM64_X1,ARM64_REG_NONE,0,off,0,width);
 uint64_t expected=((uint64_t)(end?ctx->data_end:ctx->data)>>(lane*8))&mask(width);
 unsigned tag=ARM64_SIM_L_MEM_READ_TAG(ARM64_X1,ARM64_REG_NONE,0,off,0,width);
 unsigned wanted=width==8?(end?ARM64_SIM_TAG_PACKET_END:ARM64_SIM_TAG_PACKET):ARM64_SIM_TAG_SCALAR;
 cases++;return got!=expected||tag!=wanted ? 5:0;
}
int main(void) {
 struct __sk_buff ctx;uint64_t state=0x43215678aa55cc33ULL;
 for(unsigned round=0;round<256;round++) {
  for(unsigned i=0;i<sizeof(ctx);i++){state^=state<<13;state^=state>>7;state^=state<<17;((unsigned char *)&ctx)[i]=state;}
  for(unsigned width=1;width<=8;width*=2) {
   for(unsigned off=0;off+width<=20;off++)for(int alias=-16;alias<=16;alias+=8) {
    int rc=test_cb(&ctx,width,off,alias,state^((uint64_t)off<<32));if(rc){printf("cb fail %d/%u/%u/%d\n",rc,width,off,alias);return rc;}
   }
   for(unsigned lane=0;lane+width<=8;lane++)for(int alias=-16;alias<=16;alias+=8)for(int end=0;end<2;end++) {
    int rc=test_packet(&ctx,width,lane,alias,end);if(rc){printf("packet fail %u/%u/%d/%d\n",width,lane,alias,end);return rc;}
   }
  }
 }
 printf("ARM skb live projection: %lu full-state/width/alias observations PASS\n",cases);return 0;
}
