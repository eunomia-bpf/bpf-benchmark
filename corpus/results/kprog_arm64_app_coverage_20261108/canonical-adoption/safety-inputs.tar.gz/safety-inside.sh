set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/safety /workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/safety-transport.py /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py
exec make -f /workspaces/.agent-state/kprog-lanes/A/design-only/canonical-adoption/Makefile safety
