
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define ARM64_SIM_ENABLE_STACK 1
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef unsigned long long __u64;
typedef signed long long __s64;
typedef signed int __s32;
#define __always_inline inline
#include "/workspaces/repository/kprog/formal/oracles/arm64_entry_environment_host.h"
#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"
static void arm64_sim_unsupported_opcode(void) { abort(); }
unsigned long native_lab_exclusive_failure_choice(unsigned int site) { (void)site; return 0; }
static unsigned long cases;
static int scene(unsigned op,unsigned width,unsigned order,unsigned dst,unsigned src,unsigned space,unsigned seed)
{
 ARM64_SIM_L_DECLARE_STATE();
 ARM64_SIM_L_DECLARE_STACK();
 __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
 (void)__a64_sim_abi_kind;
 union { uint64_t align[2]; unsigned char bytes[16]; } cell;
 unsigned char expected[16];
 unsigned char *bytes=space ? &__a64_stack.b[32] : cell.bytes;
 for(unsigned i=0;i<16;i++)bytes[i]=expected[i]=(unsigned char)(seed*17+i*31);
 for(unsigned i=0;i<20;i++)__a64_stack_tag[i]=ARM64_SIM_TAG_SCALAR;
 __u64 value=0x1032547698badcfeULL*(seed+1);
 ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X1,value,ARM64_WIDTH_64);
 ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X2,(void *)(long)(space ? -64 : (__s64)(long)cell.bytes),space ? ARM64_SIM_TAG_STACK : ARM64_SIM_TAG_MAP_PTR);
 if(src==ARM64_X2)value=ARM64_SIM_L_READ_REG(ARM64_X2);
 __u64 old=0;
 for(unsigned i=0;i<width;i++)old|=(__u64)expected[i]<<(i*8);
 __u64 next=op==ARM64_OP_LDSET ? old|value : op==ARM64_OP_LDCLR ? old&~value : old+value;
 for(unsigned i=0;i<width;i++)expected[i]=(unsigned char)(next>>(i*8));
 ARM64_SIM_L_EXEC(op,dst,src,ARM64_X2,ARM64_REG_NONE,width,order,0);
 __u64 got=ARM64_SIM_L_READ_REG(dst);
 cases++;
 if(memcmp(bytes,expected,16) || (dst!=ARM64_XZR && got!=old) || (dst!=ARM64_XZR && ARM64_SIM_L_REG_TAG(dst)!=ARM64_SIM_TAG_SCALAR)) {
  fprintf(stderr,"mismatch op=%u width=%u order=%u dst=%u src=%u space=%u seed=%u got=%llx old=%llx\n",op,width,order,dst,src,space,seed,got,old);return 1;
 }
 return 0;
}
int main(void)
{
 unsigned ops[]={ARM64_OP_LDADD,ARM64_OP_LDSET,ARM64_OP_LDCLR};
 unsigned widths[]={1,2,4,8},dsts[]={ARM64_X1,ARM64_X2,ARM64_XZR};
 for(unsigned o=0;o<3;o++)for(unsigned w=0;w<4;w++)for(unsigned order=0;order<4;order++)for(unsigned d=0;d<3;d++)for(unsigned src=1;src<=2;src++)for(unsigned s=0;s<2;s++)for(unsigned seed=0;seed<20;seed++)
  if(scene(ops[o],widths[w],order,dsts[d],src,s,seed))return 1;
 printf("ARM LSE RMW actual C model: %lu scenes, matching result, byte extent and destination tag\n",cases);return 0;
}
