cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/A/bitwise-lse/Makefile component > /workspaces/.agent-state/kprog-lanes/A/bitwise-lse/component.log 2>&1
rc=$?
printf "%s\n" "$rc" > /workspaces/.agent-state/kprog-lanes/A/bitwise-lse/component.exit
exit "$rc"
