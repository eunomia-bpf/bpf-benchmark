from pathlib import Path
import datetime,gzip,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');E=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/bitwise-lse/safety'
def save(phase,**kw):(E/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
try:
 save('actual_existing34')
 with (E/'run.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(E/'mount.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (O/'driver.log.gz').write_bytes(gzip.compress((E/'run.log').read_bytes(),mtime=0));report=dict(make_exit=p.returncode,launch=json.loads((E/'launch.json').read_text()));paths=[O/'driver.log.gz']
 Q=O/'trusted-arm64-service-result'
 if (Q/'summary.json').exists():
  s=json.loads((Q/'summary.json').read_text());archive=Q/s['archive'];report['summary']=s;paths.extend([Q/'summary.json',archive])
  with tarfile.open(archive) as tf:
   if 'run/outcomes.json' in tf.getnames():report['outcomes']=json.load(tf.extractfile('run/outcomes.json'))
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for n in ['controller.py','mount.py','transport.py','Makefile','launch.json']:tf.add(E/n,arcname=n)
  tf.add(E/'source',arcname='source');tf.add(E/'suite',arcname='suite')
 paths.append(O/'inputs.tar.gz')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect existing ARM safety cohort on the LSE source epoch','arm-bitwise-lse-safety');save('finished',make_exit=p.returncode,publication=rec,cases=len(report.get('outcomes',[])))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+rec['commit']+' existing34 ARM ISA safety cohort at canonical LSE source a8d17004c; Makeexit'+str(p.returncode)+', collected'+str(len(report.get('outcomes',[])))+' rows. Raw per-stage/native-control/verifier outcomes retained. Runtime check additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
