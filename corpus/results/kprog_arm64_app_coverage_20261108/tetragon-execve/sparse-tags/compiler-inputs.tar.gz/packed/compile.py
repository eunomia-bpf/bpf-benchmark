from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');G=Path(__file__).resolve().parent
d=json.loads((G/'compiler-original.json').read_text());cmd=d['command']
cmd[cmd.index('-c')+1]=str(G/'trusted_arm64.bpf.c');output=G/'sparse-tags.bpf.o';cmd[cmd.index('-o')+1]=str(output)
pins={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'kprog/arm64/arm64_sim_local_bpf.h',R/'kprog/arm64/arm64_sim_direct.h',R/'kprog/arm64/arm64_sim.h']}
start=time.monotonic()
with (G/'sparse-tags.log').open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);_,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Identical complete event_execve generated C with private common finite ordered ghost tags; original native inputs and operation bodies retained',command=cmd,returncode=p.returncode,wall_seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss,source_pins=pins,baseline_native_stack_bytes=480,baseline_payload_words=3,baseline_bpf_stack_refused_offset=-672,baseline_compiler=json.loads((G/'compiler-original.json').read_text()))
if p.returncode==0:
 dis=subprocess.check_output(['llvm-objdump-18','-d',str(output)],text=True);(G/'sparse-tags.dis').write_text(dis);report['maximum_fp_minus_offset']=max([int(x,0) for x in re.findall(r'\br10\s*-\s*(0x[0-9a-fA-F]+|[0-9]+)',dis)],default=0)
 with output.open('rb') as f:report['bpf_instructions']=sum(s.data_size//8 for s in ELFFile(f).iter_sections() if s['sh_flags']&4)
(G/'sparse-tags.json').write_text(json.dumps(report,indent=2)+'\n')
if p.returncode:raise RuntimeError('existing full native body compiler: '+str(p.returncode))
