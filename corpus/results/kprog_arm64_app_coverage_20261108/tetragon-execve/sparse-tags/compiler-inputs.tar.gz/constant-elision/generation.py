from pathlib import Path
import importlib.util,json,sys,tarfile
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'kprog/arm64/micro-prog'))
spec=importlib.util.spec_from_file_location('scalar_elision_gen',R/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py');gen=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gen;spec.loader.exec_module(gen)
old=A/'tetragon-execve/event-execve'
with tarfile.open(old/'request.tar.gz') as tf:meta=json.loads(tf.extractfile('request/generation.metadata.json').read())
functions,rodata=gen.parse_native_linked_program(gen.Bench('trusted_arm64','event_execve','raw'),old)
text=gen.render_program('trusted_arm64','event_execve',functions,'raw',rodata16=rodata,linked_exit=True,program_section=meta['section'],trusted_map_bindings=[dict(native_symbol=m['name'],value_offset=m.get('value_offset')) for m in meta['maps']])
text=text.replace('#include "../arm64_sim_local_bpf.h"','#include '+json.dumps(str(R/'kprog/arm64/arm64_sim_local_bpf.h')))
(F/'trusted_arm64.bpf.c').write_text(text)
