from pathlib import Path
import os,subprocess
F=Path(__file__).resolve().parent;G=F.parent;R=Path('/workspaces/repository')
for base in [G/'source',F/'source']:
 for p in sorted(base.rglob('*')):
  if p.is_file() and p.suffix!='.pyc':subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(base))],check=True)
for p in sorted((R/'kprog/arm64/micro-prog').glob('*.bpf.c')):
 q=F/'isolated-micro-source'/p.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
 subprocess.run(['mount','--bind',str(q),str(p)],check=True)
os.execvp('make',['make','-f',str(F/'Makefile'),'generation','compile'])
