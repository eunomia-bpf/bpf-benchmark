#!/bin/sh
cd /workspaces/repository || exit
taskset -c 12-15 unshare --mount --propagation private python3 /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/sparse-tags/scalar-elision/inside.py > /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/sparse-tags/scalar-elision/check.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/sparse-tags/scalar-elision/check.exit
exit "$rc"
