from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-execve/tag-storage/application';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in {'controller.log','status.json'}:tf.add(p,arcname=str(p.relative_to(G)))
 (O/'README.md').write_text('Complete ARM application replay with local numeric tag storage\n\nThis serial queue consumes generic source5379bb7ca, the paired byte-atomic Image/module and original complete Tetragon, OTel and Tracee two-start recipes. Every native manifest entry and actual map match is retained. Each guest uses8vCPUs/8GiB on16-19 after original byte-source Tetragon1942504 closes. launch.json and launch-inputs.tar.gz capture source/manifest identities; each terminal archive and coverage file retain actual outcomes and work counters. QEMU timing supplies functional evidence. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Queue complete ARM application replay with local numeric tag storage','arm-tag-app-launch')
 save('waiting_original_tetragon',predecessor_pid=1942504,publication=rec);notice('PUSHED '+rec['commit']+' captured serial whole Tetragon/OTel/Tracee successor at tag source5379bb7ca, paired byte Image/module,8GiB/eightvCPU16-19; waits actual1942504 closure through pidfd. Original workload/native manifests/maps retained. New runtime admission0.')
 try:fd=os.pidfd_open(1942504)
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 results={}
 for app in ['tetragon','otelcol-ebpf-profiler','tracee']:
  save('actual_application',application=app,closed=results)
  with (G/(app+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  q=O/('trusted-arm64-'+app+'-result');q.mkdir(exist_ok=True)
  (q/'driver.log.gz').write_bytes(gzip.compress((G/(app+'.log')).read_bytes(),mtime=0))
  paths=[q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
  if (q/'summary.json').exists():
   d=json.loads((q/'summary.json').read_text());archive=q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](d,archive);paths.extend([q/'summary.json',archive])
  (q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(q/'coverage.json')
  rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM '+app+' local tag storage outcomes','arm-tag-'+app+'-result')
  results[app]=dict(make_exit=p.returncode,publication=rec)
  notice('PUSHED '+rec['commit']+' complete ARM '+app+' tag-source terminal attempt, Makeexit'+str(p.returncode)+'. Every service outcome and raw application work counter retained; serial queue continues.')
 save('finished',results=results)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
