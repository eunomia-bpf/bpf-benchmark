#define ARM64_SIM_RET_CASES_f00 
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BIAS 240LL
#define ARM64_SIM_STACK_BYTES 240U
#define ARM64_SIM_STACK_PAYLOAD_WORDS 1U
#define ARM64_SIM_L_STACK_PAYLOAD_LOAD(INDEX) (__a64_stack_payload[(((__u64)(INDEX) > 22ULL))])
#define ARM64_SIM_L_STACK_PAYLOAD_STORE(INDEX, VALUE) do { __a64_stack_payload[(((__u64)(INDEX) > 22ULL))] = (VALUE); } while (0)
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x4cULL: goto arm64_l_4c; \
	case 0x74ULL: goto arm64_l_74; \
	case 0x94ULL: goto arm64_l_94; \
	case 0xb4ULL: goto arm64_l_b4; \
	case 0xd8ULL: goto arm64_l_d8; \
	case 0xf8ULL: goto arm64_l_f8; \
	case 0x118ULL: goto arm64_l_118; \
	case 0x130ULL: goto arm64_l_130; \
	case 0x190ULL: goto arm64_l_190; \
	case 0x1a4ULL: goto arm64_l_1a4; \
	case 0x1b8ULL: goto arm64_l_1b8; \
	case 0x1c8ULL: goto arm64_l_1c8; \
	case 0x230ULL: goto arm64_l_230; \
	case 0x254ULL: goto arm64_l_254; \
	case 0x278ULL: goto arm64_l_278; \
	case 0x294ULL: goto arm64_l_294; \
	case 0x304ULL: goto arm64_l_304; \
	case 0x334ULL: goto arm64_l_334; \
	case 0x358ULL: goto arm64_l_358; \
	case 0x384ULL: goto arm64_l_384; \
	case 0x3e0ULL: goto arm64_l_3e0; \
	case 0x490ULL: goto arm64_l_490; \
	case 0x4d0ULL: goto arm64_l_4d0; \
	case 0x508ULL: goto arm64_l_508; \
	case 0x520ULL: goto arm64_l_520; \
	case 0x558ULL: goto arm64_l_558; \
	case 0x590ULL: goto arm64_l_590; \
	case 0x598ULL: goto arm64_l_598; \
	case 0x5bcULL: goto arm64_l_5bc; \
	case 0x6bcULL: goto arm64_l_6bc; \
	case 0x6d8ULL: goto arm64_l_6d8; \
	case 0x6fcULL: goto arm64_l_6fc; \
	case 0x724ULL: goto arm64_l_724; \
	case 0x750ULL: goto arm64_l_750; \
	case 0x76cULL: goto arm64_l_76c; \
	case 0x7a0ULL: goto arm64_l_7a0; \
	case 0x7ccULL: goto arm64_l_7cc; \
	case 0x7e8ULL: goto arm64_l_7e8; \
	case 0x81cULL: goto arm64_l_81c; \
	case 0x848ULL: goto arm64_l_848; \
	case 0x864ULL: goto arm64_l_864; \
	case 0x898ULL: goto arm64_l_898; \
	case 0x8c4ULL: goto arm64_l_8c4; \
	case 0x8e0ULL: goto arm64_l_8e0; \
	case 0x908ULL: goto arm64_l_908; \
	case 0x91cULL: goto arm64_l_91c; \
	case 0x950ULL: goto arm64_l_950; \
	case 0x994ULL: goto arm64_l_994; \
	case 0x9ecULL: goto arm64_l_9ec; \
	case 0xa18ULL: goto arm64_l_a18; \
	case 0xa58ULL: goto arm64_l_a58; \
	case 0xa90ULL: goto arm64_l_a90; \
	case 0xabcULL: goto arm64_l_abc; \
	case 0xafcULL: goto arm64_l_afc; \
	case 0xb34ULL: goto arm64_l_b34; \
	case 0xb48ULL: goto arm64_l_b48; \
	case 0xb70ULL: goto arm64_l_b70; \
	case 0xb9cULL: goto arm64_l_b9c; \
	case 0xbb8ULL: goto arm64_l_bb8; \
	case 0xbecULL: goto arm64_l_bec; \
	case 0xc18ULL: goto arm64_l_c18; \
	case 0xc34ULL: goto arm64_l_c34; \
	case 0xc68ULL: goto arm64_l_c68; \
	case 0xc94ULL: goto arm64_l_c94; \
	case 0xcb0ULL: goto arm64_l_cb0; \
	case 0xce4ULL: goto arm64_l_ce4; \
	case 0xd10ULL: goto arm64_l_d10; \
	case 0xd2cULL: goto arm64_l_d2c; \
	case 0xd58ULL: goto arm64_l_d58; \
	case 0xd9cULL: goto arm64_l_d9c; \
	case 0xdccULL: goto arm64_l_dcc; \
	case 0xdf0ULL: goto arm64_l_df0; \
	case 0xe34ULL: goto arm64_l_e34; \
	case 0xe58ULL: goto arm64_l_e58;
#include "/workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-candidate.h"

extern __u8 CONFIG_ITER_NUM[] __ksym;
extern __u8 PARENTS_MAP_ENABLED[] __ksym;
extern __u8 buffer_heap_map[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 execve_msg_heap_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_binary_heap[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 tg_mbset_map[] __ksym;
extern __u8 tg_parents_bin[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
static const __u8 __arm64_rodata_0[2408] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0xff, 0x03, 0x01, 0xd1, 0xfe, 0x5f, 0x01, 0xa9, 0xf6, 0x57, 0x02, 0xa9, 0xf4, 0x4f, 0x03, 0xa9, 0xf5, 0x03, 0x00, 0xaa, 0xff, 0x0f, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0x28, 0x00, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe9, 0x33, 0x00, 0x91, 0xf3, 0x03, 0x01, 0xaa, 0xe1, 0x33, 0x00, 0x91, 0xf4, 0x03, 0x02, 0xaa, 0x00, 0x01, 0x3f, 0xd6, 0x60, 0x04, 0x00, 0xb4, 0x08, 0x03, 0x80, 0x52, 0xf6, 0x03, 0x00, 0xaa, 0x08, 0x00, 0x00, 0xb9, 0xc8, 0x01, 0x80, 0x52, 0x00, 0x01, 0x3f, 0xd6, 0xf7, 0x03, 0x16, 0xaa, 0x1f, 0x58, 0x00, 0xb1, 0xe0, 0x0e, 0x01, 0xf8, 0x41, 0x01, 0x00, 0x54, 0xa2, 0xa2, 0x03, 0x91, 0x08, 0x01, 0x80, 0x52, 0x89, 0x00, 0x80, 0x52, 0xea, 0x03, 0x00, 0x91, 0xe0, 0x03, 0x00, 0x91, 0x01, 0x01, 0x80, 0x52, 0x20, 0x01, 0x3f, 0xd6, 0xe8, 0x03, 0x40, 0xf9, 0xe8, 0x02, 0x00, 0xf9, 0xa8, 0x0f, 0x80, 0x52, 0x00, 0x01, 0x3f, 0xd6, 0xc0, 0x0e, 0x00, 0xf9, 0xe0, 0x03, 0x15, 0xaa, 0xe1, 0x03, 0x16, 0xaa, 0xe2, 0x03, 0x14, 0xaa, 0xe8, 0x26, 0x40, 0xa9, 0x68, 0x26, 0x01, 0xa9, 0x0f, 0x00, 0x00, 0x94, 0x08, 0x7c, 0x1f, 0x13, 0x7f, 0x42, 0x00, 0xf8, 0x09, 0x00, 0x08, 0x0a, 0x08, 0x00, 0x28, 0x0a, 0x00, 0x04, 0x80, 0x52, 0x69, 0x02, 0x00, 0xb9, 0x68, 0x0e, 0x00, 0xb9, 0xf4, 0x4f, 0x43, 0xa9, 0xf6, 0x57, 0x42, 0xa9, 0xfe, 0x5f, 0x41, 0xa9, 0xff, 0x03, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0xff, 0xc3, 0x00, 0xd1, 0xfe, 0x57, 0x01, 0xa9, 0xf4, 0x4f, 0x02, 0xa9, 0xe3, 0x33, 0x00, 0x91, 0xf5, 0x03, 0x02, 0xaa, 0xf3, 0x03, 0x01, 0xaa, 0xff, 0x33, 0x00, 0x39, 0xf4, 0x03, 0x00, 0xaa, 0x14, 0x00, 0x00, 0x94, 0x80, 0x01, 0xf8, 0xb7, 0xe8, 0x33, 0x40, 0x39, 0x48, 0x01, 0x00, 0x35, 0x02, 0x00, 0x15, 0x8b, 0xe3, 0x33, 0x00, 0x91, 0xf5, 0x03, 0x00, 0xaa, 0xe0, 0x03, 0x14, 0xaa, 0xe1, 0x03, 0x13, 0xaa, 0x0b, 0x00, 0x00, 0x94, 0x1f, 0x00, 0x00, 0xf1, 0xe8, 0xb3, 0x95, 0x9a, 0x00, 0x00, 0x08, 0x8b, 0xf4, 0x4f, 0x42, 0xa9, 0xfe, 0x57, 0x41, 0xa9, 0xff, 0xc3, 0x00, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0xff, 0x03, 0x01, 0xd1, 0xfe, 0x0b, 0x00, 0xf9, 0xf6, 0x57, 0x02, 0xa9, 0xf4, 0x4f, 0x03, 0xa9, 0xf4, 0x03, 0x00, 0xaa, 0x20, 0x80, 0x00, 0x91, 0xe8, 0xfb, 0x8f, 0x52, 0xa9, 0x05, 0x80, 0x52, 0xf3, 0x03, 0x01, 0xaa, 0xe1, 0xfb, 0x8f, 0x52, 0xf5, 0x03, 0x03, 0xaa, 0x20, 0x01, 0x3f, 0xd6, 0x80, 0x0c, 0xf8, 0xb7, 0xe8, 0xfb, 0x8f, 0x52, 0x1f, 0x00, 0x08, 0xeb, 0xe8, 0x07, 0x9f, 0x1a, 0xa8, 0x02, 0x00, 0x39, 0xe0, 0x0b, 0x00, 0xb4, 0x08, 0x7c, 0x00, 0x11, 0x16, 0x04, 0x00, 0xd1, 0xff, 0x0f, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0xe9, 0x33, 0x00, 0x91, 0xe1, 0x33, 0x00, 0x91, 0x15, 0x39, 0x40, 0x92, 0x75, 0x06, 0x00, 0xb9, 0x28, 0x00, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0x00, 0x01, 0x3f, 0xd6, 0xe0, 0x03, 0x00, 0xb4, 0x08, 0xa0, 0x40, 0x39, 0xa8, 0x03, 0x00, 0x34, 0x01, 0x00, 0x00, 0x90, 0x08, 0x00, 0x80, 0x12, 0x29, 0x03, 0x80, 0x52, 0x21, 0x00, 0x40, 0xf9, 0xe0, 0x03, 0x14, 0xaa, 0x02, 0x00, 0x80, 0x12, 0xe3, 0x03, 0x13, 0xaa, 0xe4, 0x03, 0x15, 0xaa, 0x20, 0x01, 0x3f, 0xd6, 0xc0, 0x08, 0xf8, 0xb6, 0xf3, 0x03, 0x00, 0xaa, 0xff, 0x1f, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0x28, 0x00, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe9, 0x73, 0x00, 0x91, 0xe1, 0x73, 0x00, 0x91, 0x00, 0x01, 0x3f, 0xd6, 0xa0, 0x07, 0x00, 0xb4, 0xe8, 0x03, 0x13, 0xaa, 0x7f, 0x32, 0x00, 0xb1, 0x6c, 0x05, 0x00, 0x54, 0x1f, 0x71, 0x00, 0xb1, 0x20, 0x06, 0x00, 0x54, 0x1f, 0x59, 0x00, 0xb1, 0x61, 0x03, 0x00, 0x54, 0x08, 0x80, 0x15, 0x91, 0x32, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x90, 0xe3, 0x03, 0x1f, 0xaa, 0x48, 0x10, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe1, 0x03, 0x13, 0xaa, 0xe2, 0x03, 0x15, 0xaa, 0x00, 0x01, 0x3f, 0xd6, 0x80, 0x05, 0xf8, 0xb6, 0xf3, 0x03, 0x00, 0xaa, 0xff, 0x1b, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0x28, 0x00, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe9, 0x63, 0x00, 0x91, 0xe1, 0x63, 0x00, 0x91, 0x00, 0x01, 0x3f, 0xd6, 0x60, 0x04, 0x00, 0xb4, 0xe8, 0x03, 0x13, 0xaa, 0x7f, 0x32, 0x00, 0xb1, 0x2c, 0x01, 0x00, 0x54, 0x1f, 0x71, 0x00, 0xb1, 0xe0, 0x02, 0x00, 0x54, 0x1f, 0x59, 0x00, 0xb1, 0xe0, 0xfc, 0xff, 0x54, 0x1f, 0x41, 0x00, 0xb1, 0x21, 0x02, 0x00, 0x54, 0x08, 0x60, 0x15, 0x91, 0x16, 0x00, 0x00, 0x14, 0x1f, 0x2d, 0x00, 0xb1, 0x20, 0x02, 0x00, 0x54, 0x1f, 0x1d, 0x00, 0xb1, 0x20, 0x02, 0x00, 0x54, 0x1f, 0x09, 0x00, 0xb1, 0x21, 0x01, 0x00, 0x54, 0x08, 0x20, 0x15, 0x91, 0x0e, 0x00, 0x00, 0x14, 0x1f, 0x2d, 0x00, 0xb1, 0x20, 0x01, 0x00, 0x54, 0x1f, 0x1d, 0x00, 0xb1, 0x20, 0x01, 0x00, 0x54, 0x1f, 0x09, 0x00, 0xb1, 0x20, 0xff, 0xff, 0x54, 0x08, 0x00, 0x15, 0x91, 0x06, 0x00, 0x00, 0x14, 0x08, 0xa0, 0x15, 0x91, 0x04, 0x00, 0x00, 0x14, 0x08, 0xc0, 0x15, 0x91, 0x02, 0x00, 0x00, 0x14, 0x08, 0x40, 0x15, 0x91, 0x29, 0x00, 0x80, 0x52, 0x08, 0x01, 0xe9, 0xf8, 0xe0, 0x03, 0x16, 0xaa, 0xf4, 0x4f, 0x43, 0xa9, 0xfe, 0x0b, 0x40, 0xf9, 0xf6, 0x57, 0x42, 0xa9, 0xff, 0x03, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0xff, 0x43, 0x01, 0xd1, 0xfe, 0x0b, 0x00, 0xf9, 0xf8, 0x5f, 0x02, 0xa9, 0xf6, 0x57, 0x03, 0xa9, 0xf4, 0x4f, 0x04, 0xa9, 0xf6, 0x03, 0x00, 0xaa, 0xff, 0x1f, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0x28, 0x00, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe9, 0x73, 0x00, 0x91, 0xf3, 0x03, 0x01, 0xaa, 0xe1, 0x73, 0x00, 0x91, 0xf4, 0x03, 0x03, 0xaa, 0xf5, 0x03, 0x02, 0xaa, 0x00, 0x01, 0x3f, 0xd6, 0x00, 0x05, 0x00, 0xb4, 0x08, 0x03, 0x80, 0x52, 0xf7, 0x03, 0x00, 0xaa, 0x08, 0x00, 0x00, 0xb9, 0xc8, 0x01, 0x80, 0x52, 0x00, 0x01, 0x3f, 0xd6, 0xf8, 0x03, 0x17, 0xaa, 0x1f, 0x58, 0x00, 0xb1, 0x00, 0x0f, 0x01, 0xf8, 0x41, 0x01, 0x00, 0x54, 0xc2, 0xa2, 0x03, 0x91, 0x08, 0x01, 0x80, 0x52, 0x89, 0x00, 0x80, 0x52, 0xea, 0x23, 0x00, 0x91, 0xe0, 0x23, 0x00, 0x91, 0x01, 0x01, 0x80, 0x52, 0x20, 0x01, 0x3f, 0xd6, 0xe8, 0x07, 0x40, 0xf9, 0x08, 0x03, 0x00, 0xf9, 0xa8, 0x0f, 0x80, 0x52, 0x00, 0x01, 0x3f, 0xd6, 0xe0, 0x0e, 0x00, 0xf9, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x17, 0xaa, 0xe2, 0x03, 0x15, 0xaa, 0x08, 0x27, 0x40, 0xa9, 0xe3, 0x03, 0x14, 0xaa, 0x68, 0x26, 0x01, 0xa9, 0x14, 0x00, 0x00, 0x94, 0xc0, 0x00, 0xf8, 0x37, 0x88, 0x02, 0x00, 0x4b, 0x9f, 0x06, 0x00, 0xb1, 0x7f, 0x02, 0x00, 0xf9, 0xe8, 0x03, 0x88, 0x1a, 0x04, 0x00, 0x00, 0x14, 0xe8, 0x03, 0x1f, 0x2a, 0x60, 0x7e, 0x00, 0x29, 0xe0, 0x03, 0x1f, 0x2a, 0x68, 0x02, 0x01, 0x29, 0x00, 0x04, 0x80, 0x52, 0xf4, 0x4f, 0x44, 0xa9, 0xfe, 0x0b, 0x40, 0xf9, 0xf6, 0x57, 0x43, 0xa9, 0xf8, 0x5f, 0x42, 0xa9, 0xff, 0x43, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0xff, 0x03, 0x01, 0xd1, 0xfe, 0x5f, 0x01, 0xa9, 0xf6, 0x57, 0x02, 0xa9, 0xf4, 0x4f, 0x03, 0xa9, 0xf3, 0x03, 0x03, 0xaa, 0xf5, 0x03, 0x02, 0xaa, 0xf4, 0x03, 0x01, 0xaa, 0xf6, 0x03, 0x00, 0xaa, 0x88, 0x00, 0x00, 0x94, 0x20, 0x0b, 0xf8, 0x37, 0x17, 0x78, 0x40, 0x92, 0x63, 0x02, 0x17, 0xeb, 0x80, 0x0f, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x80, 0x00, 0x00, 0x94, 0x20, 0x0a, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0x60, 0x0e, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x77, 0x00, 0x00, 0x94, 0x00, 0x09, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0x40, 0x0d, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x6e, 0x00, 0x00, 0x94, 0xe0, 0x07, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0x20, 0x0c, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x65, 0x00, 0x00, 0x94, 0xc0, 0x06, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0x00, 0x0b, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x5c, 0x00, 0x00, 0x94, 0xa0, 0x05, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0xe0, 0x09, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x53, 0x00, 0x00, 0x94, 0x80, 0x04, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0xc0, 0x08, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x4a, 0x00, 0x00, 0x94, 0x60, 0x03, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0xa0, 0x07, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x41, 0x00, 0x00, 0x94, 0x40, 0x02, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x17, 0x01, 0x17, 0x8b, 0x63, 0x02, 0x17, 0xeb, 0x80, 0x06, 0x00, 0x54, 0xe2, 0x02, 0x15, 0x8b, 0xe0, 0x03, 0x16, 0xaa, 0xe1, 0x03, 0x14, 0xaa, 0x38, 0x00, 0x00, 0x94, 0x20, 0x01, 0xf8, 0x37, 0x08, 0x78, 0x40, 0x92, 0x13, 0x01, 0x17, 0x8b, 0xe0, 0x03, 0x13, 0xaa, 0xf4, 0x4f, 0x43, 0xa9, 0xf6, 0x57, 0x42, 0xa9, 0xfe, 0x5f, 0x41, 0xa9, 0xff, 0x03, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x13, 0x7c, 0x40, 0x93, 0xff, 0x0f, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0x28, 0x00, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe9, 0x33, 0x00, 0x91, 0xe1, 0x33, 0x00, 0x91, 0x00, 0x01, 0x3f, 0xd6, 0xc0, 0x03, 0x00, 0xb4, 0x7f, 0x32, 0x00, 0xb1, 0x2c, 0x01, 0x00, 0x54, 0x7f, 0x72, 0x00, 0xb1, 0xe0, 0x01, 0x00, 0x54, 0x7f, 0x5a, 0x00, 0xb1, 0x60, 0x02, 0x00, 0x54, 0x7f, 0x42, 0x00, 0xb1, 0xe1, 0x01, 0x00, 0x54, 0x08, 0x60, 0x15, 0x91, 0x12, 0x00, 0x00, 0x14, 0x7f, 0x2e, 0x00, 0xb1, 0x20, 0x01, 0x00, 0x54, 0x7f, 0x1e, 0x00, 0xb1, 0xa0, 0x01, 0x00, 0x54, 0x7f, 0x0a, 0x00, 0xb1, 0xe1, 0x00, 0x00, 0x54, 0x08, 0x20, 0x15, 0x91, 0x0a, 0x00, 0x00, 0x14, 0x08, 0xa0, 0x15, 0x91, 0x08, 0x00, 0x00, 0x14, 0x08, 0xc0, 0x15, 0x91, 0x06, 0x00, 0x00, 0x14, 0x08, 0x00, 0x15, 0x91, 0x04, 0x00, 0x00, 0x14, 0x08, 0x80, 0x15, 0x91, 0x02, 0x00, 0x00, 0x14, 0x08, 0x40, 0x15, 0x91, 0x29, 0x00, 0x80, 0x52, 0x08, 0x01, 0xe9, 0xf8, 0xe0, 0x03, 0x13, 0xaa, 0xf4, 0x4f, 0x43, 0xa9, 0xf6, 0x57, 0x42, 0xa9, 0xfe, 0x5f, 0x41, 0xa9, 0xff, 0x03, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0xfe, 0x0f, 0x1d, 0xf8, 0xf6, 0x57, 0x01, 0xa9, 0xf4, 0x4f, 0x02, 0xa9, 0xc3, 0x04, 0xf8, 0xb7, 0x08, 0xfc, 0x8f, 0x52, 0xf6, 0x03, 0x00, 0xaa, 0x20, 0x80, 0x00, 0x91, 0xf4, 0x03, 0x01, 0xaa, 0x7f, 0x00, 0x08, 0xeb, 0x73, 0x30, 0x88, 0x9a, 0x88, 0x00, 0x80, 0x52, 0xe1, 0x03, 0x13, 0x2a, 0x00, 0x01, 0x3f, 0xd6, 0x40, 0x05, 0xf8, 0x37, 0x75, 0x82, 0x00, 0x11, 0xff, 0x0f, 0x00, 0xb9, 0x00, 0x00, 0x00, 0x90, 0x28, 0x00, 0x80, 0x52, 0x95, 0x06, 0x00, 0xb9, 0xe9, 0x33, 0x00, 0x91, 0xe1, 0x33, 0x00, 0x91, 0x00, 0x00, 0x40, 0xf9, 0x00, 0x01, 0x3f, 0xd6, 0x00, 0x03, 0x00, 0xb4, 0x08, 0xa0, 0x40, 0x39, 0xc8, 0x02, 0x00, 0x34, 0x01, 0x00, 0x00, 0x90, 0x08, 0x00, 0x80, 0x12, 0x29, 0x03, 0x80, 0x52, 0x21, 0x00, 0x40, 0xf9, 0xe0, 0x03, 0x16, 0xaa, 0x02, 0x00, 0x80, 0x12, 0xe3, 0x03, 0x14, 0xaa, 0xe4, 0x03, 0x15, 0xaa, 0x20, 0x01, 0x3f, 0xd6, 0x80, 0x02, 0xf8, 0x37, 0xe0, 0x03, 0x13, 0xaa, 0xf4, 0x4f, 0x42, 0xa9, 0xf6, 0x57, 0x41, 0xa9, 0xfe, 0x07, 0x43, 0xf8, 0xc0, 0x03, 0x5f, 0xd6, 0x13, 0x00, 0x80, 0x92, 0xe0, 0x03, 0x13, 0xaa, 0xf4, 0x4f, 0x42, 0xa9, 0xf6, 0x57, 0x41, 0xa9, 0xfe, 0x07, 0x43, 0xf8, 0xc0, 0x03, 0x5f, 0xd6, 0x00, 0x00, 0x00, 0x90, 0xe3, 0x03, 0x1f, 0xaa, 0x48, 0x10, 0x80, 0x52, 0x00, 0x00, 0x40, 0xf9, 0xe1, 0x03, 0x14, 0xaa, 0xe2, 0x03, 0x15, 0xaa, 0x00, 0x01, 0x3f, 0xd6, 0xc0, 0xfd, 0xff, 0x36, 0x13, 0x7c, 0x40, 0x93, 0xe0, 0x03, 0x13, 0xaa, 0xf4, 0x4f, 0x42, 0xa9, 0xf6, 0x57, 0x41, 0xa9, 0xfe, 0x07, 0x43, 0xf8, 0xc0, 0x03, 0x5f, 0xd6, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0x1f, 0x20, 0x03, 0xd5, 0xff, 0x43, 0x01, 0xd1, 0xfe, 0x5f, 0x02, 0xa9, 0xf6, 0x57, 0x03, 0xa9, 0xf4, 0x4f, 0x04, 0xa9, 0xf4, 0x03, 0x01, 0xaa, 0x28, 0x00, 0x40, 0xf9, 0x22, 0x58, 0x42, 0xa9, 0xf3, 0x03, 0x01, 0xaa, 0x97, 0x8e, 0x41, 0xf8, 0xff, 0x02, 0x08, 0xeb, 0x81, 0x00, 0x00, 0x54, 0x68, 0x06, 0x40, 0xf9, 0x5f, 0x00, 0x08, 0xeb, 0x80, 0x0c, 0x00, 0x54, 0x08, 0x01, 0x80, 0x52, 0x89, 0x00, 0x80, 0x52, 0xea, 0x03, 0x00, 0x91, 0xe0, 0x03, 0x00, 0x91, 0x01, 0x01, 0x80, 0x52, 0x20, 0x01, 0x3f, 0xd6, 0xe8, 0x03, 0x40, 0xf9, 0xff, 0x02, 0x08, 0xeb, 0x20, 0x08, 0x00, 0x54, 0xf5, 0x62, 0x00, 0x91, 0x08, 0x01, 0x80, 0x52, 0x89, 0x00, 0x80, 0x52, 0xea, 0x43, 0x00, 0x91, 0xe0, 0x43, 0x00, 0x91, 0x01, 0x01, 0x80, 0x52, 0xe2, 0x03, 0x15, 0xaa, 0x20, 0x01, 0x3f, 0xd6, 0xe8, 0x0b, 0x40, 0xf9, 0x1f, 0x01, 0x17, 0xeb, 0xc0, 0x06, 0x00, 0x54, 0x08, 0x01, 0x80, 0x52, 0xe9, 0x23, 0x00, 0x91, 0x8a, 0x00, 0x80, 0x52, 0xe0, 0x23, 0x00, 0x91, 0x01, 0x01, 0x80, 0x52, 0xe2, 0x03, 0x15, 0xaa, 0x96, 0x00, 0x80, 0x52, 0x40, 0x01, 0x3f, 0xd6, 0xe2, 0x82, 0x00, 0x91, 0x08, 0x02, 0x80, 0x52, 0xe9, 0x43, 0x00, 0x91, 0xe0, 0x43, 0x00, 0x91, 0x01, 0x02, 0x80, 0x52, 0xc0, 0x02, 0x3f, 0xd6, 0x68, 0x0a, 0x40, 0xf9, 0xf5, 0x17, 0x40, 0xb9, 0x69, 0x1a, 0x40, 0xf9, 0x2b, 0x01, 0x08, 0xcb, 0x76, 0x3a, 0x40, 0xb9, 0xa9, 0x02, 0x16, 0x6b, 0xea, 0x0f, 0x40, 0xf9, 0xec, 0x33, 0x89, 0x1a, 0xdf, 0x02, 0x15, 0x6b, 0xc9, 0x32, 0x95, 0x1a, 0x2d, 0x95, 0x89, 0x1a, 0xce, 0x02, 0x0d, 0x4b, 0x6b, 0x01, 0x0d, 0xeb, 0x6e, 0x3a, 0x00, 0xb9, 0x43, 0x07, 0x00, 0x54, 0x7f, 0xfd, 0x3f, 0xf1, 0x08, 0x07, 0x00, 0x54, 0x42, 0x01, 0x0c, 0x8b, 0xdf, 0x02, 0x15, 0x6b, 0x69, 0x00, 0x00, 0x54, 0xea, 0x05, 0x80, 0x52, 0x0a, 0x69, 0x2b, 0x38, 0x17, 0x01, 0x0b, 0x8b, 0xdf, 0x02, 0x15, 0x6b, 0x21, 0x1d, 0x00, 0x12, 0x88, 0x00, 0x80, 0x52, 0xe0, 0x96, 0x97, 0x9a, 0x00, 0x01, 0x3f, 0xd6, 0xdf, 0x02, 0x15, 0x6b, 0x77, 0x1a, 0x00, 0xf9, 0x49, 0x05, 0x00, 0x54, 0xe8, 0x07, 0x40, 0xf9, 0xe0, 0x03, 0x1f, 0xaa, 0x88, 0x02, 0x00, 0xf9, 0xf4, 0x4f, 0x44, 0xa9, 0xf6, 0x57, 0x43, 0xa9, 0xfe, 0x5f, 0x42, 0xa9, 0xff, 0x43, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0xc2, 0x42, 0x00, 0x91, 0x08, 0x01, 0x80, 0x52, 0x89, 0x00, 0x80, 0x52, 0xea, 0x43, 0x00, 0x91, 0xe0, 0x43, 0x00, 0x91, 0x01, 0x01, 0x80, 0x52, 0x20, 0x01, 0x3f, 0xd6, 0x68, 0x16, 0x40, 0xf9, 0xe9, 0x0b, 0x40, 0xf9, 0x1f, 0x01, 0x09, 0xeb, 0x00, 0x02, 0x00, 0x54, 0xc2, 0x62, 0x00, 0x91, 0x08, 0x01, 0x80, 0x52, 0x89, 0x00, 0x80, 0x52, 0xe0, 0x03, 0x14, 0xaa, 0x01, 0x01, 0x80, 0x52, 0x20, 0x01, 0x3f, 0xd6, 0xe8, 0x0b, 0x40, 0xf9, 0xe0, 0x03, 0x1f, 0xaa, 0x09, 0x81, 0x00, 0x91, 0x69, 0x22, 0x02, 0xa9, 0xf4, 0x4f, 0x44, 0xa9, 0xf6, 0x57, 0x43, 0xa9, 0xfe, 0x5f, 0x42, 0xa9, 0xff, 0x43, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x20, 0x00, 0x80, 0x52, 0x60, 0xf2, 0x00, 0x39, 0xf4, 0x4f, 0x44, 0xa9, 0xf6, 0x57, 0x43, 0xa9, 0xfe, 0x5f, 0x42, 0xa9, 0xff, 0x43, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0x20, 0x00, 0x80, 0x52, 0xf4, 0x4f, 0x44, 0xa9, 0xf6, 0x57, 0x43, 0xa9, 0xfe, 0x5f, 0x42, 0xa9, 0xff, 0x43, 0x01, 0x91, 0xc0, 0x03, 0x5f, 0xd6};
static const __u8 __arm64_rodata_1[11] SEC(".rodata.native.1") __attribute__((aligned(16))) = {0x20, 0x28, 0x64, 0x65, 0x6c, 0x65, 0x74, 0x65, 0x64, 0x29, 0x00};
static const char __arm64_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__arm64_rodata_0\",\"native_symbol\":\"__arm64_section_Some(SectionIndex(2))_addend_1904\",\"size\":2408},{\"proof_section\":\".rodata.native.1\",\"proof_symbol\":\"__arm64_rodata_1\",\"native_symbol\":\"__arm64_section_Some(SectionIndex(12))_addend_0\",\"size\":11}]}";

SEC("tracepoint/trusted/trusted")
int trusted_arm64_arm64_sim_xdp(void *ctx)
{
	ARM64_SIM_ENTRY_RAW(ctx);
	/* native subroutine execve_send */
arm64_l_0:
	/* 0x0: sub sp, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_18:
	/* 0x18: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <execve_msg_heap_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)execve_msg_heap_map));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, ee4 <execve_send+0xee4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0xee4, arm64_l_ee4);
arm64_l_3c:
	/* 0x3c: str x19, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_40:
	/* 0x40: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_44:
	/* 0x44: mov x29, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_48:
	/* 0x48: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x4cULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4c:
	/* 0x4c: mov w8, #0x16c0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5824ULL);
arm64_l_50:
	/* 0x50: add x2, x0, #0x858 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2136ULL);
arm64_l_54:
	/* 0x54: mov w19, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_58:
	/* 0x58: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5c:
	/* 0x5c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_60:
	/* 0x60: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_64:
	/* 0x64: mov w20, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_68:
	/* 0x68: add x21, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_6c:
	/* 0x6c: add x8, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_70:
	/* 0x70: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x74ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_74:
	/* 0x74: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_78:
	/* 0x78: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_7c:
	/* 0x7c: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_80:
	/* 0x80: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_84:
	/* 0x84: add x8, x8, #0x528 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1320ULL);
arm64_l_88:
	/* 0x88: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_8c:
	/* 0x8c: add x2, x8, #0x528 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1320ULL);
arm64_l_90:
	/* 0x90: blr x20 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X20);
		if (ARM64_SIM_L_REG_TAG(ARM64_X20) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_94:
	/* 0x94: str wzr, [sp, #44] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_98:
	/* 0x98: adrp x0, 0 <buffer_heap_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)buffer_heap_map));
arm64_l_9c:
	/* 0x9c: ldr x20, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_a0:
	/* 0xa0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a4:
	/* 0xa4: add x9, sp, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_a8:
	/* 0xa8: add x1, sp, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_ac:
	/* 0xac: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_b0:
	/* 0xb0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xb4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b4:
	/* 0xb4: cbz x0, 590 <execve_send+0x590> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb4, 0x590, arm64_l_590);
arm64_l_b8:
	/* 0xb8: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_bc:
	/* 0xbc: str x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_c0:
	/* 0xc0: str x29, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_c4:
	/* 0xc4: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c8:
	/* 0xc8: add x19, x0, #0x1, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_cc:
	/* 0xcc: str w8, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_d0:
	/* 0xd0: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_d4:
	/* 0xd4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0xd8ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d8:
	/* 0xd8: add x2, x0, #0xb30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2864ULL);
arm64_l_dc:
	/* 0xdc: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e0:
	/* 0xe0: add x8, sp, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_e4:
	/* 0xe4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e8:
	/* 0xe8: add x0, sp, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_ec:
	/* 0xec: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_f0:
	/* 0xf0: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_f4:
	/* 0xf4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xf8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_f8:
	/* 0xf8: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_fc:
	/* 0xfc: add x23, x20, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_100:
	/* 0x100: add x8, sp, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_104:
	/* 0x104: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_108:
	/* 0x108: add x0, sp, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_10c:
	/* 0x10c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_110:
	/* 0x110: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_114:
	/* 0x114: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x118ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_118:
	/* 0x118: ldr x24, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_11c:
	/* 0x11c: add x8, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_120:
	/* 0x120: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_124:
	/* 0x124: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_128:
	/* 0x128: add x2, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_12c:
	/* 0x12c: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x130ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_130:
	/* 0x130: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_134:
	/* 0x134: cbz x8, 368 <execve_send+0x368> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x134, 0x368, arm64_l_368);
arm64_l_138:
	/* 0x138: ldr x8, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_13c:
	/* 0x13c: stp xzr, xzr, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_140:
	/* 0x140: add x25, x21, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_144:
	/* 0x144: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_148:
	/* 0x148: add x2, x21, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_14c:
	/* 0x14c: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_150:
	/* 0x150: stp x22, xzr, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_154:
	/* 0x154: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_158:
	/* 0x158: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_15c:
	/* 0x15c: add x24, x20, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_160:
	/* 0x160: add x29, x9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_164:
	/* 0x164: ldr w8, [x8, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_168:
	/* 0x168: stp xzr, xzr, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_16c:
	/* 0x16c: str x19, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_170:
	/* 0x170: str x19, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_174:
	/* 0x174: add x22, x9, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_178:
	/* 0x178: add x20, x9, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_17c:
	/* 0x17c: mov w19, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_180:
	/* 0x180: strb wzr, [sp, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_184:
	/* 0x184: str w8, [sp, #120] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_188:
	/* 0x188: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18c:
	/* 0x18c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x190ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_190:
	/* 0x190: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_194:
	/* 0x194: mov x0, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_198:
	/* 0x198: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_19c:
	/* 0x19c: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a0:
	/* 0x1a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a4:
	/* 0x1a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a8:
	/* 0x1a8: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ac:
	/* 0x1ac: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b0:
	/* 0x1b0: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b4:
	/* 0x1b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b8:
	/* 0x1b8: mov x0, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1bc:
	/* 0x1bc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c0:
	/* 0x1c0: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c4:
	/* 0x1c4: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c8:
	/* 0x1c8: ldr x8, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1cc:
	/* 0x1cc: sub x8, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1d0:
	/* 0x1d0: str x8, [sp, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_1d4:
	/* 0x1d4: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)CONFIG_ITER_NUM));
arm64_l_1d8:
	/* 0x1d8: ldr x8, [x8] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X8, ARM64_SIM_L_READ_REG_PTR(ARM64_X8), ARM64_SIM_TAG_MAP_VALUE);
arm64_l_1dc:
	/* 0x1dc: ldrb w8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e0:
	/* 0x1e0: cbz w8, 3bc <execve_send+0x3bc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x1e0, 0x3bc, arm64_l_3bc);
arm64_l_1e4:
	/* 0x1e4: mov w20, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_1e8:
	/* 0x1e8: mov w24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ec:
	/* 0x1ec: add x25, sp, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_1f0:
	/* 0x1f0: add x29, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1f4:
	/* 0x1f4: b 208 <execve_send+0x208> */
	ARM64_SIM_A64_JMP(0x1f4, 0x208, arm64_l_208);
arm64_l_1f8:
	/* 0x1f8: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1fc:
	/* 0x1fc: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_200:
	/* 0x200: subs w20, w20, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_204:
	/* 0x204: b.eq 3e0 <execve_send+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x204, 0x3e0, arm64_l_3e0);
arm64_l_208:
	/* 0x208: ldp x19, x2, [sp, #88] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_20c:
	/* 0x20c: ldp x8, x9, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_210:
	/* 0x210: cmp x19, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_214:
	/* 0x214: ccmp x2, x9, #0x0, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CCMP_REG, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_218:
	/* 0x218: b.eq 430 <execve_send+0x430> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x218, 0x430, arm64_l_430);
arm64_l_21c:
	/* 0x21c: ldr x21, [sp, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_220:
	/* 0x220: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_224:
	/* 0x224: add x0, sp, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_228:
	/* 0x228: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_22c:
	/* 0x22c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x230ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_230:
	/* 0x230: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_234:
	/* 0x234: cmp x19, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_238:
	/* 0x238: b.eq 320 <execve_send+0x320> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x238, 0x320, arm64_l_320);
arm64_l_23c:
	/* 0x23c: add x23, x19, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_240:
	/* 0x240: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_244:
	/* 0x244: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_248:
	/* 0x248: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24c:
	/* 0x24c: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_250:
	/* 0x250: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x254ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_254:
	/* 0x254: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_258:
	/* 0x258: cmp x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25c:
	/* 0x25c: b.eq 320 <execve_send+0x320> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25c, 0x320, arm64_l_320);
arm64_l_260:
	/* 0x260: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_264:
	/* 0x264: add x9, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_268:
	/* 0x268: add x0, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_26c:
	/* 0x26c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_270:
	/* 0x270: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_274:
	/* 0x274: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x278ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_278:
	/* 0x278: add x2, x19, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_27c:
	/* 0x27c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_280:
	/* 0x280: mov w9, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_284:
	/* 0x284: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_288:
	/* 0x288: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_28c:
	/* 0x28c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_290:
	/* 0x290: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x294ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_294:
	/* 0x294: ldr w19, [sp, #148] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_298:
	/* 0x298: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_29c:
	/* 0x29c: ldr x10, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_2a0:
	/* 0x2a0: sub x12, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2a4:
	/* 0x2a4: ldr w21, [sp, #120] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_2a8:
	/* 0x2a8: subs w10, w19, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X10, ARM64_X19, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ac:
	/* 0x2ac: ldr x9, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2b0:
	/* 0x2b0: csel w10, wzr, w10, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_XZR, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2b4:
	/* 0x2b4: cmp w21, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b8:
	/* 0x2b8: csel w11, w21, w19, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2bc:
	/* 0x2bc: cinc w13, w11, hi */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CINC, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2c0:
	/* 0x2c0: sub w14, w21, w13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X21, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2c4:
	/* 0x2c4: subs x12, x12, x13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c8:
	/* 0x2c8: str w14, [sp, #120] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_2cc:
	/* 0x2cc: b.cc 3e0 <execve_send+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2cc, 0x3e0, arm64_l_3e0);
arm64_l_2d0:
	/* 0x2d0: cmp x12, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2d4:
	/* 0x2d4: b.hi 3e0 <execve_send+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d4, 0x3e0, arm64_l_3e0);
arm64_l_2d8:
	/* 0x2d8: cmp w21, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dc:
	/* 0x2dc: b.ls 2e8 <execve_send+0x2e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2dc, 0x2e8, arm64_l_2e8);
arm64_l_2e0:
	/* 0x2e0: mov w13, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2e4:
	/* 0x2e4: strb w13, [x8, x12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X12, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e8:
	/* 0x2e8: add x23, x8, x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2ec:
	/* 0x2ec: cmp w21, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f0:
	/* 0x2f0: add x2, x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2f4:
	/* 0x2f4: and w1, w11, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2f8:
	/* 0x2f8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2fc:
	/* 0x2fc: cinc x0, x23, hi */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CINC, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_HI, 0);
arm64_l_300:
	/* 0x300: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x304ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_304:
	/* 0x304: cmp w21, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_308:
	/* 0x308: str x23, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_30c:
	/* 0x30c: b.ls 3e0 <execve_send+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x30c, 0x3e0, arm64_l_3e0);
arm64_l_310:
	/* 0x310: ldr x8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_314:
	/* 0x314: str x8, [sp, #88] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_318:
	/* 0x318: b 200 <execve_send+0x200> */
	ARM64_SIM_A64_JMP(0x318, 0x200, arm64_l_200);
arm64_l_31c:
	/* 0x31c: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_320:
	/* 0x320: add x2, x21, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_324:
	/* 0x324: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_328:
	/* 0x328: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_32c:
	/* 0x32c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_330:
	/* 0x330: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x334ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_334:
	/* 0x334: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_338:
	/* 0x338: ldr x9, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_33c:
	/* 0x33c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_340:
	/* 0x340: b.eq 430 <execve_send+0x430> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x340, 0x430, arm64_l_430);
arm64_l_344:
	/* 0x344: add x2, x21, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_348:
	/* 0x348: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_34c:
	/* 0x34c: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_350:
	/* 0x350: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_354:
	/* 0x354: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x358ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_358:
	/* 0x358: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_35c:
	/* 0x35c: add x9, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_360:
	/* 0x360: stp x9, x8, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_364:
	/* 0x364: b 200 <execve_send+0x200> */
	ARM64_SIM_A64_JMP(0x364, 0x200, arm64_l_200);
arm64_l_368:
	/* 0x368: add x2, x24, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_36c:
	/* 0x36c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_370:
	/* 0x370: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_374:
	/* 0x374: add x10, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_378:
	/* 0x378: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_37c:
	/* 0x37c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_380:
	/* 0x380: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x384ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_384:
	/* 0x384: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_388:
	/* 0x388: cmp x8, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_38c:
	/* 0x38c: b.eq 138 <execve_send+0x138> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x38c, 0x138, arm64_l_138);
arm64_l_390:
	/* 0x390: ldr x29, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_394:
	/* 0x394: ldr w9, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_398:
	/* 0x398: sub w8, w9, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_39c:
	/* 0x39c: cmp w9, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_3a0:
	/* 0x3a0: str w8, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_3a4:
	/* 0x3a4: b.gt 9a8 <execve_send+0x9a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x3a4, 0x9a8, arm64_l_9a8);
arm64_l_3a8:
	/* 0x3a8: ldr x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3ac:
	/* 0x3ac: mov w9, #0xffffffdc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967260ULL);
arm64_l_3b0:
	/* 0x3b0: mov x22, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3b4:
	/* 0x3b4: str w9, [x29, #6212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6212ULL);
arm64_l_3b8:
	/* 0x3b8: b 45c <execve_send+0x45c> */
	ARM64_SIM_A64_JMP(0x3b8, 0x45c, arm64_l_45c);
arm64_l_3bc:
	/* 0x3bc: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3c0:
	/* 0x3c0: adrp x1, 0 <execve_send> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)((const __u8 *)__arm64_rodata_0 + 1904)));
arm64_l_3c4:
	/* 0x3c4: add x1, x1, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_3c8:
	/* 0x3c8: mov w8, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_3cc:
	/* 0x3cc: mov w9, #0xb5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 181ULL);
arm64_l_3d0:
	/* 0x3d0: add x10, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_3d4:
	/* 0x3d4: add x2, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_3d8:
	/* 0x3d8: mov w0, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_3dc:
	/* 0x3dc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 181ULL: ARM64_SIM_A64_LINK(0x3e0ULL); ARM64_SIM_BPF_CALL_bpf_loop(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e0:
	/* 0x3e0: ldr x22, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_3e4:
	/* 0x3e4: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_3e8:
	/* 0x3e8: cmp x22, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3ec:
	/* 0x3ec: b.eq 448 <execve_send+0x448> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3ec, 0x448, arm64_l_448);
arm64_l_3f0:
	/* 0x3f0: ldrb w8, [sp, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_3f4:
	/* 0x3f4: ldr x29, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_3f8:
	/* 0x3f8: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_3fc:
	/* 0x3fc: ldr x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_400:
	/* 0x400: cset w8, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_404:
	/* 0x404: lsl w9, w8, #1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 1ULL);
arm64_l_408:
	/* 0x408: ldr w8, [sp, #120] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_40c:
	/* 0x40c: cmp w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_410:
	/* 0x410: str w8, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_414:
	/* 0x414: str w9, [x29, #6212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6212ULL);
arm64_l_418:
	/* 0x418: b.lt 428 <execve_send+0x428> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x418, 0x428, arm64_l_428);
arm64_l_41c:
	/* 0x41c: mov w9, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_420:
	/* 0x420: sub w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_424:
	/* 0x424: str w8, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_428:
	/* 0x428: cbnz x22, 45c <execve_send+0x45c> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x428, 0x45c, arm64_l_45c);
arm64_l_42c:
	/* 0x42c: b 590 <execve_send+0x590> */
	ARM64_SIM_A64_JMP(0x42c, 0x590, arm64_l_590);
arm64_l_430:
	/* 0x430: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_434:
	/* 0x434: strb w8, [sp, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_438:
	/* 0x438: ldr x22, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_43c:
	/* 0x43c: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_440:
	/* 0x440: cmp x22, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_444:
	/* 0x444: b.ne 3f0 <execve_send+0x3f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x444, 0x3f0, arm64_l_3f0);
arm64_l_448:
	/* 0x448: ldr x29, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_44c:
	/* 0x44c: ldr x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_450:
	/* 0x450: mov w8, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_454:
	/* 0x454: mov x22, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_458:
	/* 0x458: str xzr, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_45c:
	/* 0x45c: subs w9, w8, #0x7f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_460:
	/* 0x460: mov w10, #0x7f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_464:
	/* 0x464: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_468:
	/* 0x468: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_46c:
	/* 0x46c: csel w24, w8, w10, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X24, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_470:
	/* 0x470: csel w19, wzr, w9, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_XZR, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_474:
	/* 0x474: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_478:
	/* 0x478: mov w9, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_47c:
	/* 0x47c: csel w8, w8, w9, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_480:
	/* 0x480: str w8, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_484:
	/* 0x484: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_488:
	/* 0x488: ldr w1, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_48c:
	/* 0x48c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x490ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_490:
	/* 0x490: adrp x23, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
arm64_l_494:
	/* 0x494: ldr x23, [x23] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X23, ARM64_SIM_L_READ_REG_PTR(ARM64_X23), ARM64_SIM_TAG_MAP_PTR);
arm64_l_498:
	/* 0x498: cbz x0, 508 <execve_send+0x508> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x498, 0x508, arm64_l_508);
arm64_l_49c:
	/* 0x49c: neg w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4a0:
	/* 0x4a0: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4a4:
	/* 0x4a4: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_4a8:
	/* 0x4a8: strh w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_4ac:
	/* 0x4ac: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_4b0:
	/* 0x4b0: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4b4:
	/* 0x4b4: mov w20, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4b8:
	/* 0x4b8: strh w8, [sp, #66] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_4bc:
	/* 0x4bc: mov x8, #0x2da */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 730ULL);
arm64_l_4c0:
	/* 0x4c0: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_4c4:
	/* 0x4c4: stur x8, [sp, #68] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_4c8:
	/* 0x4c8: add x8, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_4cc:
	/* 0x4cc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x4d0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4d0:
	/* 0x4d0: cbz x0, 4e4 <execve_send+0x4e4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x4d0, 0x4e4, arm64_l_4e4);
arm64_l_4d4:
	/* 0x4d4: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4d8:
	/* 0x4d8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_4dc:
	/* 0x4dc: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4e0:
	/* 0x4e0: b 508 <execve_send+0x508> */
	ARM64_SIM_A64_JMP(0x4e0, 0x508, arm64_l_508);
arm64_l_4e4:
	/* 0x4e4: str w20, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4e8:
	/* 0x4e8: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4ec:
	/* 0x4ec: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_4f0:
	/* 0x4f0: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_4f4:
	/* 0x4f4: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_4f8:
	/* 0x4f8: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_4fc:
	/* 0x4fc: add x2, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_500:
	/* 0x500: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_504:
	/* 0x504: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x508ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_508:
	/* 0x508: mov w8, #0x17c0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6080ULL);
arm64_l_50c:
	/* 0x50c: add x2, x22, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X22, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_510:
	/* 0x510: mov w1, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_514:
	/* 0x514: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_518:
	/* 0x518: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_51c:
	/* 0x51c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x520ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_520:
	/* 0x520: cbz x0, 590 <execve_send+0x590> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x520, 0x590, arm64_l_590);
arm64_l_524:
	/* 0x524: neg w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_528:
	/* 0x528: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_52c:
	/* 0x52c: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_530:
	/* 0x530: strh w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_534:
	/* 0x534: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_538:
	/* 0x538: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_53c:
	/* 0x53c: mov w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_540:
	/* 0x540: strh w8, [sp, #66] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_544:
	/* 0x544: mov x8, #0x2dc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 732ULL);
arm64_l_548:
	/* 0x548: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_54c:
	/* 0x54c: stur x8, [sp, #68] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_550:
	/* 0x550: add x8, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_554:
	/* 0x554: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x558ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_558:
	/* 0x558: cbz x0, 56c <execve_send+0x56c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x558, 0x56c, arm64_l_56c);
arm64_l_55c:
	/* 0x55c: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_560:
	/* 0x560: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_564:
	/* 0x564: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_568:
	/* 0x568: b 590 <execve_send+0x590> */
	ARM64_SIM_A64_JMP(0x568, 0x590, arm64_l_590);
arm64_l_56c:
	/* 0x56c: str w19, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_570:
	/* 0x570: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_574:
	/* 0x574: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_578:
	/* 0x578: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_57c:
	/* 0x57c: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_580:
	/* 0x580: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_584:
	/* 0x584: add x2, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_588:
	/* 0x588: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_58c:
	/* 0x58c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x590ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_590:
	/* 0x590: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_594:
	/* 0x594: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x598ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_598:
	/* 0x598: lsr x8, x0, #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_59c:
	/* 0x59c: adrp x23, 0 <execve_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)execve_map));
arm64_l_5a0:
	/* 0x5a0: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_5a4:
	/* 0x5a4: str w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_5a8:
	/* 0x5a8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5ac:
	/* 0x5ac: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_5b0:
	/* 0x5b0: ldr x23, [x23] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X23, ARM64_SIM_L_READ_REG_PTR(ARM64_X23), ARM64_SIM_TAG_MAP_PTR);
arm64_l_5b4:
	/* 0x5b4: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5b8:
	/* 0x5b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x5bcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5bc:
	/* 0x5bc: cbz x0, d68 <execve_send+0xd68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x5bc, 0xd68, arm64_l_d68);
arm64_l_5c0:
	/* 0x5c0: ldp x8, x9, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5c4:
	/* 0x5c4: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5c8:
	/* 0x5c8: stp x8, x9, [x29, #304] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X29, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 304ULL);
arm64_l_5cc:
	/* 0x5cc: ldr w9, [x29, #324] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 324ULL);
arm64_l_5d0:
	/* 0x5d0: ldr w8, [x0, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_5d4:
	/* 0x5d4: str w9, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5d8:
	/* 0x5d8: ldr x9, [x29, #368] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 368ULL);
arm64_l_5dc:
	/* 0x5dc: str x9, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_5e0:
	/* 0x5e0: ldr w9, [x29, #332] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 332ULL);
arm64_l_5e4:
	/* 0x5e4: str w9, [x0, #36] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_5e8:
	/* 0x5e8: ldp x11, x10, [x29, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_5ec:
	/* 0x5ec: stp x11, x10, [x0, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_5f0:
	/* 0x5f0: tbnz w8, #0, 658 <execve_send+0x658> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 0, 0x5f0, 0x658, arm64_l_658);
arm64_l_5f4:
	/* 0x5f4: and w10, w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_5f8:
	/* 0x5f8: cmp w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_5fc:
	/* 0x5fc: orr w11, w10, #0x2000000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 33554432ULL);
arm64_l_600:
	/* 0x600: csel w9, w11, w10, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_604:
	/* 0x604: str w9, [x22, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_608:
	/* 0x608: tbnz w9, #25, 67c <execve_send+0x67c> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 25, 0x608, 0x67c, arm64_l_67c);
arm64_l_60c:
	/* 0x60c: cmp w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_610:
	/* 0x610: b.ne 690 <execve_send+0x690> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x610, 0x690, arm64_l_690);
arm64_l_614:
	/* 0x614: ldr x8, [x29, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_618:
	/* 0x618: str x8, [x22, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_61c:
	/* 0x61c: ldp x8, x9, [x29, #272] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_620:
	/* 0x620: ldp x10, x11, [x29, #288] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_624:
	/* 0x624: stp x10, x11, [x22, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X22, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_628:
	/* 0x628: stp x8, x9, [x22, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_62c:
	/* 0x62c: ldr x8, [x29, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_630:
	/* 0x630: str x8, [x22, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_634:
	/* 0x634: ldr x8, [x29, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_638:
	/* 0x638: str x8, [x22, #88] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_63c:
	/* 0x63c: ldr x8, [x29, #240] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_640:
	/* 0x640: str x8, [x22, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_644:
	/* 0x644: adrp x8, 0 <PARENTS_MAP_ENABLED> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)PARENTS_MAP_ENABLED));
arm64_l_648:
	/* 0x648: ldr x8, [x8] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X8, ARM64_SIM_L_READ_REG_PTR(ARM64_X8), ARM64_SIM_TAG_MAP_VALUE);
arm64_l_64c:
	/* 0x64c: ldrb w8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_650:
	/* 0x650: cbnz w8, 6a0 <execve_send+0x6a0> */
	ARM64_SIM_A64_CBNZ_W(ARM64_X8, 0x650, 0x6a0, arm64_l_6a0);
arm64_l_654:
	/* 0x654: b 908 <execve_send+0x908> */
	ARM64_SIM_A64_JMP(0x654, 0x908, arm64_l_908);
arm64_l_658:
	/* 0x658: ldr w10, [x29, #348] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 348ULL);
arm64_l_65c:
	/* 0x65c: orr w10, w10, #0x4000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 16384ULL);
arm64_l_660:
	/* 0x660: str w10, [x29, #348] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 348ULL);
arm64_l_664:
	/* 0x664: and w10, w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_668:
	/* 0x668: cmp w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_66c:
	/* 0x66c: orr w11, w10, #0x2000000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 33554432ULL);
arm64_l_670:
	/* 0x670: csel w9, w11, w10, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_674:
	/* 0x674: str w9, [x22, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_678:
	/* 0x678: tbz w9, #25, 60c <execve_send+0x60c> */
	ARM64_SIM_A64_TBZ(ARM64_X9, 25, 0x678, 0x60c, arm64_l_60c);
arm64_l_67c:
	/* 0x67c: ldr w9, [x29, #348] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 348ULL);
arm64_l_680:
	/* 0x680: orr w9, w9, #0x2000000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 33554432ULL);
arm64_l_684:
	/* 0x684: str w9, [x29, #348] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 348ULL);
arm64_l_688:
	/* 0x688: cmp w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_68c:
	/* 0x68c: b.eq 614 <execve_send+0x614> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x68c, 0x614, arm64_l_614);
arm64_l_690:
	/* 0x690: adrp x8, 0 <PARENTS_MAP_ENABLED> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)PARENTS_MAP_ENABLED));
arm64_l_694:
	/* 0x694: ldr x8, [x8] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X8, ARM64_SIM_L_READ_REG_PTR(ARM64_X8), ARM64_SIM_TAG_MAP_VALUE);
arm64_l_698:
	/* 0x698: ldrb w8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_69c:
	/* 0x69c: cbz w8, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x69c, 0x908, arm64_l_908);
arm64_l_6a0:
	/* 0x6a0: str wzr, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_6a4:
	/* 0x6a4: adrp x0, 0 <tg_binary_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_binary_heap));
arm64_l_6a8:
	/* 0x6a8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6ac:
	/* 0x6ac: add x9, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_6b0:
	/* 0x6b0: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_6b4:
	/* 0x6b4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_6b8:
	/* 0x6b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6bcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6bc:
	/* 0x6bc: cbz x0, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6bc, 0x908, arm64_l_908);
arm64_l_6c0:
	/* 0x6c0: ldrb w8, [x29, #349] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 349ULL);
arm64_l_6c4:
	/* 0x6c4: tbnz w8, #6, 6f4 <execve_send+0x6f4> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 6, 0x6c4, 0x6f4, arm64_l_6f4);
arm64_l_6c8:
	/* 0x6c8: add x1, x22, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 104ULL);
arm64_l_6cc:
	/* 0x6cc: mov w2, #0x318 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 792ULL);
arm64_l_6d0:
	/* 0x6d0: mov x20, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6d4:
	/* 0x6d4: bl 0 <memcpy> */
	ARM64_SIM_A64_LINK(0x6d8ULL);
	ARM64_SIM_LIBC_MEMCPY();
arm64_l_6d8:
	/* 0x6d8: adrp x0, 0 <tg_parents_bin> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_parents_bin));
arm64_l_6dc:
	/* 0x6dc: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6e0:
	/* 0x6e0: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_6e4:
	/* 0x6e4: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_6e8:
	/* 0x6e8: mov x1, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6ec:
	/* 0x6ec: mov x2, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6f0:
	/* 0x6f0: b 904 <execve_send+0x904> */
	ARM64_SIM_A64_JMP(0x6f0, 0x904, arm64_l_904);
arm64_l_6f4:
	/* 0x6f4: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_6f8:
	/* 0x6f8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x6fcULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6fc:
	/* 0x6fc: str x0, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_700:
	/* 0x700: add x8, x0, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_704:
	/* 0x704: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_708:
	/* 0x708: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_70c:
	/* 0x70c: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_710:
	/* 0x710: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_714:
	/* 0x714: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_718:
	/* 0x718: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_71c:
	/* 0x71c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_720:
	/* 0x720: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x724ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_724:
	/* 0x724: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_728:
	/* 0x728: cbz x8, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x728, 0x908, arm64_l_908);
arm64_l_72c:
	/* 0x72c: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_730:
	/* 0x730: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_734:
	/* 0x734: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_738:
	/* 0x738: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_73c:
	/* 0x73c: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_740:
	/* 0x740: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_744:
	/* 0x744: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_748:
	/* 0x748: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_74c:
	/* 0x74c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x750ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_750:
	/* 0x750: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_754:
	/* 0x754: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_758:
	/* 0x758: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_75c:
	/* 0x75c: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_760:
	/* 0x760: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_764:
	/* 0x764: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_768:
	/* 0x768: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x76cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_76c:
	/* 0x76c: cbz x0, 778 <execve_send+0x778> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x76c, 0x778, arm64_l_778);
arm64_l_770:
	/* 0x770: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_774:
	/* 0x774: cbnz x8, 8ec <execve_send+0x8ec> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x774, 0x8ec, arm64_l_8ec);
arm64_l_778:
	/* 0x778: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_77c:
	/* 0x77c: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_780:
	/* 0x780: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_784:
	/* 0x784: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_788:
	/* 0x788: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_78c:
	/* 0x78c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_790:
	/* 0x790: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_794:
	/* 0x794: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_798:
	/* 0x798: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_79c:
	/* 0x79c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x7a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7a0:
	/* 0x7a0: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_7a4:
	/* 0x7a4: cbz x8, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x7a4, 0x908, arm64_l_908);
arm64_l_7a8:
	/* 0x7a8: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_7ac:
	/* 0x7ac: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7b0:
	/* 0x7b0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_7b4:
	/* 0x7b4: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_7b8:
	/* 0x7b8: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_7bc:
	/* 0x7bc: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_7c0:
	/* 0x7c0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7c4:
	/* 0x7c4: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_7c8:
	/* 0x7c8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x7ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7cc:
	/* 0x7cc: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_7d0:
	/* 0x7d0: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_7d4:
	/* 0x7d4: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_7d8:
	/* 0x7d8: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7dc:
	/* 0x7dc: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_7e0:
	/* 0x7e0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_7e4:
	/* 0x7e4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x7e8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7e8:
	/* 0x7e8: cbz x0, 7f4 <execve_send+0x7f4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x7e8, 0x7f4, arm64_l_7f4);
arm64_l_7ec:
	/* 0x7ec: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_7f0:
	/* 0x7f0: cbnz x8, 8ec <execve_send+0x8ec> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x7f0, 0x8ec, arm64_l_8ec);
arm64_l_7f4:
	/* 0x7f4: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_7f8:
	/* 0x7f8: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7fc:
	/* 0x7fc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_800:
	/* 0x800: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_804:
	/* 0x804: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_808:
	/* 0x808: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_80c:
	/* 0x80c: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_810:
	/* 0x810: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_814:
	/* 0x814: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_818:
	/* 0x818: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x81cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_81c:
	/* 0x81c: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_820:
	/* 0x820: cbz x8, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x820, 0x908, arm64_l_908);
arm64_l_824:
	/* 0x824: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_828:
	/* 0x828: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_82c:
	/* 0x82c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_830:
	/* 0x830: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_834:
	/* 0x834: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_838:
	/* 0x838: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_83c:
	/* 0x83c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_840:
	/* 0x840: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_844:
	/* 0x844: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x848ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_848:
	/* 0x848: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_84c:
	/* 0x84c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_850:
	/* 0x850: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_854:
	/* 0x854: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_858:
	/* 0x858: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_85c:
	/* 0x85c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_860:
	/* 0x860: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x864ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_864:
	/* 0x864: cbz x0, 870 <execve_send+0x870> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x864, 0x870, arm64_l_870);
arm64_l_868:
	/* 0x868: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_86c:
	/* 0x86c: cbnz x8, 8ec <execve_send+0x8ec> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x86c, 0x8ec, arm64_l_8ec);
arm64_l_870:
	/* 0x870: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_874:
	/* 0x874: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_878:
	/* 0x878: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_87c:
	/* 0x87c: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_880:
	/* 0x880: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_884:
	/* 0x884: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_888:
	/* 0x888: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_88c:
	/* 0x88c: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_890:
	/* 0x890: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_894:
	/* 0x894: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x898ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_898:
	/* 0x898: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_89c:
	/* 0x89c: cbz x8, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x89c, 0x908, arm64_l_908);
arm64_l_8a0:
	/* 0x8a0: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_8a4:
	/* 0x8a4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8a8:
	/* 0x8a8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_8ac:
	/* 0x8ac: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_8b0:
	/* 0x8b0: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_8b4:
	/* 0x8b4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_8b8:
	/* 0x8b8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8bc:
	/* 0x8bc: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_8c0:
	/* 0x8c0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x8c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8c4:
	/* 0x8c4: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_8c8:
	/* 0x8c8: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_8cc:
	/* 0x8cc: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_8d0:
	/* 0x8d0: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8d4:
	/* 0x8d4: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_8d8:
	/* 0x8d8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8dc:
	/* 0x8dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x8e0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8e0:
	/* 0x8e0: cbz x0, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x8e0, 0x908, arm64_l_908);
arm64_l_8e4:
	/* 0x8e4: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_8e8:
	/* 0x8e8: cbz x8, 908 <execve_send+0x908> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x8e8, 0x908, arm64_l_908);
arm64_l_8ec:
	/* 0x8ec: add x2, x0, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 104ULL);
arm64_l_8f0:
	/* 0x8f0: adrp x0, 0 <tg_parents_bin> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_parents_bin));
arm64_l_8f4:
	/* 0x8f4: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8f8:
	/* 0x8f8: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_8fc:
	/* 0x8fc: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_900:
	/* 0x900: mov x1, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_904:
	/* 0x904: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x908ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_908:
	/* 0x908: add x0, x22, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 104ULL);
arm64_l_90c:
	/* 0x90c: mov w1, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_910:
	/* 0x910: mov w2, #0x308 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 776ULL);
arm64_l_914:
	/* 0x914: add x20, x29, #0x140 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 320ULL);
arm64_l_918:
	/* 0x918: bl 0 <memset> */
	ARM64_SIM_A64_LINK(0x91cULL);
	ARM64_SIM_LIBC_MEMSET();
arm64_l_91c:
	/* 0x91c: ldr w8, [x29, #6208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6208ULL);
arm64_l_920:
	/* 0x920: sub w9, w8, #0x101 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_924:
	/* 0x924: cmn w9, #0x101 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 257ULL);
arm64_l_928:
	/* 0x928: b.hi 938 <execve_send+0x938> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x928, 0x938, arm64_l_938);
arm64_l_92c:
	/* 0x92c: mov w8, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_930:
	/* 0x930: stur w8, [x22, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_934:
	/* 0x934: b a90 <execve_send+0xa90> */
	ARM64_SIM_A64_JMP(0x934, 0xa90, arm64_l_a90);
arm64_l_938:
	/* 0x938: and x24, x8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_93c:
	/* 0x93c: add x0, x22, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_940:
	/* 0x940: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_944:
	/* 0x944: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_948:
	/* 0x948: mov w1, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_94c:
	/* 0x94c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x950ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_950:
	/* 0x950: mov x21, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_954:
	/* 0x954: cbz x0, 9ec <execve_send+0x9ec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x954, 0x9ec, arm64_l_9ec);
arm64_l_958:
	/* 0x958: neg w8, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_95c:
	/* 0x95c: adrp x25, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
arm64_l_960:
	/* 0x960: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_964:
	/* 0x964: strh w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_968:
	/* 0x968: mov w8, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_96c:
	/* 0x96c: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_970:
	/* 0x970: mov w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_974:
	/* 0x974: strh w8, [sp, #66] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_978:
	/* 0x978: mov x8, #0x168 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 360ULL);
arm64_l_97c:
	/* 0x97c: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_980:
	/* 0x980: stur x8, [sp, #68] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_984:
	/* 0x984: add x8, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_988:
	/* 0x988: ldr x25, [x25] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X25, ARM64_SIM_L_READ_REG_PTR(ARM64_X25), ARM64_SIM_TAG_MAP_PTR);
arm64_l_98c:
	/* 0x98c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_990:
	/* 0x990: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x994ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_994:
	/* 0x994: cbz x0, 9c8 <execve_send+0x9c8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x994, 0x9c8, arm64_l_9c8);
arm64_l_998:
	/* 0x998: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_99c:
	/* 0x99c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_9a0:
	/* 0x9a0: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9a4:
	/* 0x9a4: b 9ec <execve_send+0x9ec> */
	ARM64_SIM_A64_JMP(0x9a4, 0x9ec, arm64_l_9ec);
arm64_l_9a8:
	/* 0x9a8: mov w8, #0x2964 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10596ULL);
arm64_l_9ac:
	/* 0x9ac: add x19, x22, #0xff6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4086ULL);
arm64_l_9b0:
	/* 0x9b0: strh w8, [x22, #4094] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4094ULL);
arm64_l_9b4:
	/* 0x9b4: adrp x8, 970 <execve_send+0x970> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_1));
arm64_l_9b8:
	/* 0x9b8: add x8, x8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9bc:
	/* 0x9bc: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9c0:
	/* 0x9c0: str x8, [x19] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9c4:
	/* 0x9c4: b 138 <execve_send+0x138> */
	ARM64_SIM_A64_JMP(0x9c4, 0x138, arm64_l_138);
arm64_l_9c8:
	/* 0x9c8: str w19, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_9cc:
	/* 0x9cc: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9d0:
	/* 0x9d0: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_9d4:
	/* 0x9d4: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_9d8:
	/* 0x9d8: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_9dc:
	/* 0x9dc: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_9e0:
	/* 0x9e0: add x2, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_9e4:
	/* 0x9e4: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9e8:
	/* 0x9e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x9ecULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_9ec:
	/* 0x9ec: cmp w21, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9f0:
	/* 0x9f0: add x0, x22, #0x170 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 368ULL);
arm64_l_9f4:
	/* 0x9f4: csel w8, w24, w21, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_9f8:
	/* 0x9f8: cmp w24, #0x7f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_9fc:
	/* 0x9fc: str w8, [x22, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_a00:
	/* 0xa00: mov w8, #0x7f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_a04:
	/* 0xa04: csel w1, w24, w8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a08:
	/* 0xa08: mov w8, #0x17c0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6080ULL);
arm64_l_a0c:
	/* 0xa0c: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a10:
	/* 0xa10: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_a14:
	/* 0xa14: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xa18ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a18:
	/* 0xa18: cbz x0, a90 <execve_send+0xa90> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa18, 0xa90, arm64_l_a90);
arm64_l_a1c:
	/* 0xa1c: neg w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a20:
	/* 0xa20: adrp x21, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
arm64_l_a24:
	/* 0xa24: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a28:
	/* 0xa28: strh w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_a2c:
	/* 0xa2c: mov w8, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_a30:
	/* 0xa30: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_a34:
	/* 0xa34: mov w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a38:
	/* 0xa38: strh w8, [sp, #66] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_a3c:
	/* 0xa3c: mov x8, #0x16e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 366ULL);
arm64_l_a40:
	/* 0xa40: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_a44:
	/* 0xa44: stur x8, [sp, #68] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_a48:
	/* 0xa48: add x8, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_a4c:
	/* 0xa4c: ldr x21, [x21] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X21, ARM64_SIM_L_READ_REG_PTR(ARM64_X21), ARM64_SIM_TAG_MAP_PTR);
arm64_l_a50:
	/* 0xa50: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a54:
	/* 0xa54: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a58:
	/* 0xa58: cbz x0, a6c <execve_send+0xa6c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa58, 0xa6c, arm64_l_a6c);
arm64_l_a5c:
	/* 0xa5c: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a60:
	/* 0xa60: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_a64:
	/* 0xa64: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a68:
	/* 0xa68: b a90 <execve_send+0xa90> */
	ARM64_SIM_A64_JMP(0xa68, 0xa90, arm64_l_a90);
arm64_l_a6c:
	/* 0xa6c: str w19, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_a70:
	/* 0xa70: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a74:
	/* 0xa74: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_a78:
	/* 0xa78: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_a7c:
	/* 0xa7c: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_a80:
	/* 0xa80: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_a84:
	/* 0xa84: add x2, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_a88:
	/* 0xa88: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a8c:
	/* 0xa8c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xa90ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a90:
	/* 0xa90: ldr w9, [x29, #6216] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6216ULL);
arm64_l_a94:
	/* 0xa94: ldr w8, [x29, #6220] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6220ULL);
arm64_l_a98:
	/* 0xa98: mov w10, #0xfe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 254ULL);
arm64_l_a9c:
	/* 0xa9c: add x24, x22, #0x270 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 624ULL);
arm64_l_aa0:
	/* 0xaa0: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_aa4:
	/* 0xaa4: cmp w9, #0xfe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 254ULL);
arm64_l_aa8:
	/* 0xaa8: add x2, x20, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_aac:
	/* 0xaac: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ab0:
	/* 0xab0: csel w21, w9, w10, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X21, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_ab4:
	/* 0xab4: mov w1, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ab8:
	/* 0xab8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xabcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_abc:
	/* 0xabc: cbz x0, b34 <execve_send+0xb34> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xabc, 0xb34, arm64_l_b34);
arm64_l_ac0:
	/* 0xac0: neg w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ac4:
	/* 0xac4: adrp x25, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
arm64_l_ac8:
	/* 0xac8: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_acc:
	/* 0xacc: strh w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_ad0:
	/* 0xad0: mov w8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_ad4:
	/* 0xad4: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_ad8:
	/* 0xad8: mov w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_adc:
	/* 0xadc: strh w8, [sp, #66] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_ae0:
	/* 0xae0: mov x8, #0x1af */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 431ULL);
arm64_l_ae4:
	/* 0xae4: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_ae8:
	/* 0xae8: stur x8, [sp, #68] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_aec:
	/* 0xaec: add x8, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_af0:
	/* 0xaf0: ldr x25, [x25] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X25, ARM64_SIM_L_READ_REG_PTR(ARM64_X25), ARM64_SIM_TAG_MAP_PTR);
arm64_l_af4:
	/* 0xaf4: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_af8:
	/* 0xaf8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xafcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_afc:
	/* 0xafc: cbz x0, b10 <execve_send+0xb10> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xafc, 0xb10, arm64_l_b10);
arm64_l_b00:
	/* 0xb00: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b04:
	/* 0xb04: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b08:
	/* 0xb08: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b0c:
	/* 0xb0c: b b34 <execve_send+0xb34> */
	ARM64_SIM_A64_JMP(0xb0c, 0xb34, arm64_l_b34);
arm64_l_b10:
	/* 0xb10: str w19, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_b14:
	/* 0xb14: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b18:
	/* 0xb18: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_b1c:
	/* 0xb1c: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_b20:
	/* 0xb20: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_b24:
	/* 0xb24: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_b28:
	/* 0xb28: add x2, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_b2c:
	/* 0xb2c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b30:
	/* 0xb30: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xb34ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b34:
	/* 0xb34: add w8, w21, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b38:
	/* 0xb38: strb wzr, [x24, x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_XZR, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X21, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b3c:
	/* 0xb3c: strb wzr, [x24, w8, uxtw] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_b40:
	/* 0xb40: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_b44:
	/* 0xb44: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0xb48ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b48:
	/* 0xb48: str x0, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b4c:
	/* 0xb4c: add x8, x0, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_b50:
	/* 0xb50: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b54:
	/* 0xb54: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_b58:
	/* 0xb58: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_b5c:
	/* 0xb5c: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_b60:
	/* 0xb60: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b64:
	/* 0xb64: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b68:
	/* 0xb68: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_b6c:
	/* 0xb6c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xb70ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b70:
	/* 0xb70: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b74:
	/* 0xb74: cbz x8, d44 <execve_send+0xd44> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xb74, 0xd44, arm64_l_d44);
arm64_l_b78:
	/* 0xb78: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_b7c:
	/* 0xb7c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b80:
	/* 0xb80: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_b84:
	/* 0xb84: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_b88:
	/* 0xb88: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b8c:
	/* 0xb8c: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_b90:
	/* 0xb90: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b94:
	/* 0xb94: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_b98:
	/* 0xb98: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xb9cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b9c:
	/* 0xb9c: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_ba0:
	/* 0xba0: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_ba4:
	/* 0xba4: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_ba8:
	/* 0xba8: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bac:
	/* 0xbac: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_bb0:
	/* 0xbb0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bb4:
	/* 0xbb4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xbb8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bb8:
	/* 0xbb8: cbz x0, bc4 <execve_send+0xbc4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbb8, 0xbc4, arm64_l_bc4);
arm64_l_bbc:
	/* 0xbbc: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_bc0:
	/* 0xbc0: cbnz x8, d38 <execve_send+0xd38> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xbc0, 0xd38, arm64_l_d38);
arm64_l_bc4:
	/* 0xbc4: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_bc8:
	/* 0xbc8: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_bcc:
	/* 0xbcc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_bd0:
	/* 0xbd0: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_bd4:
	/* 0xbd4: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_bd8:
	/* 0xbd8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_bdc:
	/* 0xbdc: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_be0:
	/* 0xbe0: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_be4:
	/* 0xbe4: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_be8:
	/* 0xbe8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xbecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bec:
	/* 0xbec: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_bf0:
	/* 0xbf0: cbz x8, d44 <execve_send+0xd44> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xbf0, 0xd44, arm64_l_d44);
arm64_l_bf4:
	/* 0xbf4: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_bf8:
	/* 0xbf8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_bfc:
	/* 0xbfc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_c00:
	/* 0xc00: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_c04:
	/* 0xc04: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_c08:
	/* 0xc08: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_c0c:
	/* 0xc0c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c10:
	/* 0xc10: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_c14:
	/* 0xc14: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xc18ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c18:
	/* 0xc18: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_c1c:
	/* 0xc1c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_c20:
	/* 0xc20: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_c24:
	/* 0xc24: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c28:
	/* 0xc28: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_c2c:
	/* 0xc2c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c30:
	/* 0xc30: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc34ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c34:
	/* 0xc34: cbz x0, c40 <execve_send+0xc40> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc34, 0xc40, arm64_l_c40);
arm64_l_c38:
	/* 0xc38: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c3c:
	/* 0xc3c: cbnz x8, d38 <execve_send+0xd38> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xc3c, 0xd38, arm64_l_d38);
arm64_l_c40:
	/* 0xc40: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_c44:
	/* 0xc44: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c48:
	/* 0xc48: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_c4c:
	/* 0xc4c: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_c50:
	/* 0xc50: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_c54:
	/* 0xc54: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c58:
	/* 0xc58: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_c5c:
	/* 0xc5c: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_c60:
	/* 0xc60: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_c64:
	/* 0xc64: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xc68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c68:
	/* 0xc68: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_c6c:
	/* 0xc6c: cbz x8, d44 <execve_send+0xd44> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xc6c, 0xd44, arm64_l_d44);
arm64_l_c70:
	/* 0xc70: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_c74:
	/* 0xc74: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c78:
	/* 0xc78: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_c7c:
	/* 0xc7c: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_c80:
	/* 0xc80: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_c84:
	/* 0xc84: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_c88:
	/* 0xc88: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c8c:
	/* 0xc8c: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_c90:
	/* 0xc90: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xc94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c94:
	/* 0xc94: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_c98:
	/* 0xc98: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_c9c:
	/* 0xc9c: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_ca0:
	/* 0xca0: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ca4:
	/* 0xca4: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_ca8:
	/* 0xca8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cac:
	/* 0xcac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xcb0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_cb0:
	/* 0xcb0: cbz x0, cbc <execve_send+0xcbc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xcb0, 0xcbc, arm64_l_cbc);
arm64_l_cb4:
	/* 0xcb4: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_cb8:
	/* 0xcb8: cbnz x8, d38 <execve_send+0xd38> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xcb8, 0xd38, arm64_l_d38);
arm64_l_cbc:
	/* 0xcbc: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_cc0:
	/* 0xcc0: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_cc4:
	/* 0xcc4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_cc8:
	/* 0xcc8: add x11, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_ccc:
	/* 0xccc: add x0, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_cd0:
	/* 0xcd0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_cd4:
	/* 0xcd4: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_cd8:
	/* 0xcd8: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_cdc:
	/* 0xcdc: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_ce0:
	/* 0xce0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xce4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ce4:
	/* 0xce4: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_ce8:
	/* 0xce8: cbz x8, d44 <execve_send+0xd44> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xce8, 0xd44, arm64_l_d44);
arm64_l_cec:
	/* 0xcec: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_cf0:
	/* 0xcf0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cf4:
	/* 0xcf4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_cf8:
	/* 0xcf8: add x11, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_cfc:
	/* 0xcfc: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_d00:
	/* 0xd00: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_d04:
	/* 0xd04: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d08:
	/* 0xd08: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_d0c:
	/* 0xd0c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xd10ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d10:
	/* 0xd10: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_d14:
	/* 0xd14: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_d18:
	/* 0xd18: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_d1c:
	/* 0xd1c: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d20:
	/* 0xd20: str w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_d24:
	/* 0xd24: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d28:
	/* 0xd28: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd2cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d2c:
	/* 0xd2c: cbz x0, d44 <execve_send+0xd44> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd2c, 0xd44, arm64_l_d44);
arm64_l_d30:
	/* 0xd30: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_d34:
	/* 0xd34: cbz x8, d44 <execve_send+0xd44> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd34, 0xd44, arm64_l_d44);
arm64_l_d38:
	/* 0xd38: ldr x9, [x0, #880] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 880ULL);
arm64_l_d3c:
	/* 0xd3c: add x8, x22, #0x370 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 880ULL);
arm64_l_d40:
	/* 0xd40: ldsetal x9, x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDSET, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, 3, 0);
arm64_l_d44:
	/* 0xd44: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_mbset_map));
arm64_l_d48:
	/* 0xd48: add x1, x22, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_d4c:
	/* 0xd4c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d50:
	/* 0xd50: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_d54:
	/* 0xd54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d58:
	/* 0xd58: cbz x0, d68 <execve_send+0xd68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd58, 0xd68, arm64_l_d68);
arm64_l_d5c:
	/* 0xd5c: ldr x9, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d60:
	/* 0xd60: add x8, x22, #0x370 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 880ULL);
arm64_l_d64:
	/* 0xd64: ldsetal x9, x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDSET, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, 3, 0);
arm64_l_d68:
	/* 0xd68: ldr w8, [x29, #320] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 320ULL);
arm64_l_d6c:
	/* 0xd6c: strb wzr, [x29, #1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_d70:
	/* 0xd70: mov w9, #0x1710 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5904ULL);
arm64_l_d74:
	/* 0xd74: adrp x0, 0 <tg_conf_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
arm64_l_d78:
	/* 0xd78: add x1, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_d7c:
	/* 0xd7c: str wzr, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_d80:
	/* 0xd80: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_d84:
	/* 0xd84: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d88:
	/* 0xd88: csel w8, w8, w9, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_d8c:
	/* 0xd8c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_d90:
	/* 0xd90: add w21, w8, #0x140 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 320ULL);
arm64_l_d94:
	/* 0xd94: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d98:
	/* 0xd98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd9cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d9c:
	/* 0xd9c: cbz x0, e18 <execve_send+0xe18> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd9c, 0xe18, arm64_l_e18);
arm64_l_da0:
	/* 0xda0: ldrb w8, [x0, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_da4:
	/* 0xda4: cbz w8, e18 <execve_send+0xe18> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0xda4, 0xe18, arm64_l_e18);
arm64_l_da8:
	/* 0xda8: adrp x1, 0 <tcpmon_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
arm64_l_dac:
	/* 0xdac: mov w8, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_db0:
	/* 0xdb0: mov w9, #0x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25ULL);
arm64_l_db4:
	/* 0xdb4: ldr x1, [x1] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X1, ARM64_SIM_L_READ_REG_PTR(ARM64_X1), ARM64_SIM_TAG_MAP_PTR);
arm64_l_db8:
	/* 0xdb8: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_dbc:
	/* 0xdbc: mov w2, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_dc0:
	/* 0xdc0: mov x3, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_dc4:
	/* 0xdc4: mov x4, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X4, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_dc8:
	/* 0xdc8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 25ULL: ARM64_SIM_A64_LINK(0xdccULL); ARM64_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_dcc:
	/* 0xdcc: tbz x0, #63, ee4 <execve_send+0xee4> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 63, 0xdcc, 0xee4, arm64_l_ee4);
arm64_l_dd0:
	/* 0xdd0: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_dd4:
	/* 0xdd4: str wzr, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_dd8:
	/* 0xdd8: adrp x0, 0 <tg_stats_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
arm64_l_ddc:
	/* 0xddc: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_de0:
	/* 0xde0: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_de4:
	/* 0xde4: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_de8:
	/* 0xde8: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_dec:
	/* 0xdec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xdf0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_df0:
	/* 0xdf0: cbz x0, ee4 <execve_send+0xee4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xdf0, 0xee4, arm64_l_ee4);
arm64_l_df4:
	/* 0xdf4: mov x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_df8:
	/* 0xdf8: cmn x19, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 12ULL);
arm64_l_dfc:
	/* 0xdfc: b.gt ea8 <execve_send+0xea8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xdfc, 0xea8, arm64_l_ea8);
arm64_l_e00:
	/* 0xe00: cmn x8, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 28ULL);
arm64_l_e04:
	/* 0xe04: b.eq ec8 <execve_send+0xec8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe04, 0xec8, arm64_l_ec8);
arm64_l_e08:
	/* 0xe08: cmn x8, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_e0c:
	/* 0xe0c: b.ne e78 <execve_send+0xe78> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe0c, 0xe78, arm64_l_e78);
arm64_l_e10:
	/* 0xe10: add x8, x0, #0x138 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 312ULL);
arm64_l_e14:
	/* 0xe14: b edc <execve_send+0xedc> */
	ARM64_SIM_A64_JMP(0xe14, 0xedc, arm64_l_edc);
arm64_l_e18:
	/* 0xe18: adrp x0, 0 <tg_rb_events> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
arm64_l_e1c:
	/* 0xe1c: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e20:
	/* 0xe20: mov w8, #0x82 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 130ULL);
arm64_l_e24:
	/* 0xe24: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_e28:
	/* 0xe28: mov x1, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e2c:
	/* 0xe2c: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e30:
	/* 0xe30: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 130ULL: ARM64_SIM_A64_LINK(0xe34ULL); ARM64_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e34:
	/* 0xe34: tbz x0, #63, ee4 <execve_send+0xee4> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 63, 0xe34, 0xee4, arm64_l_ee4);
arm64_l_e38:
	/* 0xe38: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e3c:
	/* 0xe3c: str wzr, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_e40:
	/* 0xe40: adrp x0, 0 <tg_stats_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
arm64_l_e44:
	/* 0xe44: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e48:
	/* 0xe48: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_PTR);
arm64_l_e4c:
	/* 0xe4c: add x9, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_e50:
	/* 0xe50: add x1, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_e54:
	/* 0xe54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e58:
	/* 0xe58: cbz x0, ee4 <execve_send+0xee4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe58, 0xee4, arm64_l_ee4);
arm64_l_e5c:
	/* 0xe5c: mov x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e60:
	/* 0xe60: cmn x19, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 12ULL);
arm64_l_e64:
	/* 0xe64: b.gt e88 <execve_send+0xe88> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xe64, 0xe88, arm64_l_e88);
arm64_l_e68:
	/* 0xe68: cmn x8, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 28ULL);
arm64_l_e6c:
	/* 0xe6c: b.eq ec8 <execve_send+0xec8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe6c, 0xec8, arm64_l_ec8);
arm64_l_e70:
	/* 0xe70: cmn x8, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_e74:
	/* 0xe74: b.eq e10 <execve_send+0xe10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe74, 0xe10, arm64_l_e10);
arm64_l_e78:
	/* 0xe78: cmn x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 16ULL);
arm64_l_e7c:
	/* 0xe7c: b.ne ec0 <execve_send+0xec0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe7c, 0xec0, arm64_l_ec0);
arm64_l_e80:
	/* 0xe80: add x8, x0, #0x130 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 304ULL);
arm64_l_e84:
	/* 0xe84: b edc <execve_send+0xedc> */
	ARM64_SIM_A64_JMP(0xe84, 0xedc, arm64_l_edc);
arm64_l_e88:
	/* 0xe88: cmn x8, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 11ULL);
arm64_l_e8c:
	/* 0xe8c: b.eq ed0 <execve_send+0xed0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe8c, 0xed0, arm64_l_ed0);
arm64_l_e90:
	/* 0xe90: cmn x8, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 7ULL);
arm64_l_e94:
	/* 0xe94: b.eq ed8 <execve_send+0xed8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe94, 0xed8, arm64_l_ed8);
arm64_l_e98:
	/* 0xe98: cmn x8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 2ULL);
arm64_l_e9c:
	/* 0xe9c: b.ne ec0 <execve_send+0xec0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe9c, 0xec0, arm64_l_ec0);
arm64_l_ea0:
	/* 0xea0: add x8, x0, #0x120 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 288ULL);
arm64_l_ea4:
	/* 0xea4: b edc <execve_send+0xedc> */
	ARM64_SIM_A64_JMP(0xea4, 0xedc, arm64_l_edc);
arm64_l_ea8:
	/* 0xea8: cmn x8, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 11ULL);
arm64_l_eac:
	/* 0xeac: b.eq ed0 <execve_send+0xed0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xeac, 0xed0, arm64_l_ed0);
arm64_l_eb0:
	/* 0xeb0: cmn x8, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 7ULL);
arm64_l_eb4:
	/* 0xeb4: b.eq ed8 <execve_send+0xed8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xeb4, 0xed8, arm64_l_ed8);
arm64_l_eb8:
	/* 0xeb8: cmn x8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 2ULL);
arm64_l_ebc:
	/* 0xebc: b.eq ea0 <execve_send+0xea0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xebc, 0xea0, arm64_l_ea0);
arm64_l_ec0:
	/* 0xec0: add x8, x0, #0x118 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_ec4:
	/* 0xec4: b edc <execve_send+0xedc> */
	ARM64_SIM_A64_JMP(0xec4, 0xedc, arm64_l_edc);
arm64_l_ec8:
	/* 0xec8: add x8, x0, #0x140 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 320ULL);
arm64_l_ecc:
	/* 0xecc: b edc <execve_send+0xedc> */
	ARM64_SIM_A64_JMP(0xecc, 0xedc, arm64_l_edc);
arm64_l_ed0:
	/* 0xed0: add x8, x0, #0x148 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 328ULL);
arm64_l_ed4:
	/* 0xed4: b edc <execve_send+0xedc> */
	ARM64_SIM_A64_JMP(0xed4, 0xedc, arm64_l_edc);
arm64_l_ed8:
	/* 0xed8: add x8, x0, #0x128 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 296ULL);
arm64_l_edc:
	/* 0xedc: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ee0:
	/* 0xee0: ldaddal x9, x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDADD, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, 3, 0);
arm64_l_ee4:
	/* 0xee4: ldp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_ee8:
	/* 0xee8: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_eec:
	/* 0xeec: ldr x29, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_ef0:
	/* 0xef0: ldp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_ef4:
	/* 0xef4: ldp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_ef8:
	/* 0xef8: ldp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_efc:
	/* 0xefc: add sp, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_f00:
	/* 0xf00: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_f00);
arm64_l_f04:
	/* 0xf04: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f08:
	/* 0xf08: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
