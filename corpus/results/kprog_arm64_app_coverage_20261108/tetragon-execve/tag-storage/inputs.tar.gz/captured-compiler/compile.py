from pathlib import Path
import subprocess,json,time,os,hashlib,re,datetime
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');E=Path(__file__).resolve().parent;G=A/'design-only/lse-input/tetragon-layout/source';root=R/'kprog/arm64/build/app-runtime-v35/root'
def image(p):
 with p.open('rb') as f:return {s.name:hashlib.sha256(s.data()).hexdigest() for s in ELFFile(f).iter_sections() if s['sh_flags']&2}
original=next((E/'request').rglob('trusted_arm64.bpf.o'));rows=[]
for label,opt in [('baseline','O2'),('tags','O2'),('tags','O3')]:
 output=E/(label+'-'+opt+'.bpf.o')
 cmd=['clang-18','-g','-'+opt,'-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','--sysroot='+str(root),'-I'+str(root/'usr/include/aarch64-linux-gnu'),'-I'+str(G/'kprog/arm64'),'-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-c',str(E/(label+'.bpf.c')),'-o',str(output)]
 start=time.monotonic()
 with (E/(label+'-'+opt+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);_,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 row=dict(label=label,opt=opt,returncode=p.returncode,command=cmd,wall_seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss)
 if p.returncode==0:
  dis=subprocess.check_output(['llvm-objdump-18','-d',str(output)],text=True);(E/(label+'-'+opt+'.dis')).write_text(dis)
  row.update(max_fp_minus_offset=max([int(x,0) for x in re.findall(r'\br10\s*-\s*(0x[0-9a-fA-F]+|[0-9]+)',dis)],default=0),allocated_sections_match_original=image(output)==image(original))
  with output.open('rb') as f:row['bpf_exec_insns']=sum(s.data_size//8 for s in ELFFile(f).iter_sections() if s['sh_flags']&4)
 rows.append(row);(E/'compiler-results.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_scope='Identical captured P and generated instruction C bodies; numeric private tag-word volatility and existing proof compiler optimization level',rows=rows),indent=2)+'\n')
