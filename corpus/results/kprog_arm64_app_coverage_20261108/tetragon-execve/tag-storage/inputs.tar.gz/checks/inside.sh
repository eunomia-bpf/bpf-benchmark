set -e
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-check/candidate.h /workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h
make -f /workspaces/.agent-state/kprog-lanes/A/unaligned-stack/Makefile check HERE=/workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-check
make -C kprog/arm64 micro-proofs-build PROOF_BUILD_DIR=/workspaces/repository/kprog/arm64/build/byte-atomic/tag-micros CLANG=clang-18
