#!/bin/sh
cd /workspaces/repository || exit
taskset -c 12-15 unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-check/inside.sh > /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-check/check.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-check/check.exit
exit "$rc"
