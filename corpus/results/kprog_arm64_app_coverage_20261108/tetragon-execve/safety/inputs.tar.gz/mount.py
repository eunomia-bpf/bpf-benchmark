from pathlib import Path
import subprocess,os
E=Path('/workspaces/.agent-state/kprog-lanes/A/tetragon-execve/safety')
R=Path("/workspaces/repository")
for p in sorted((E/"source").rglob("*")):
 if p.is_file():subprocess.run(["mount","--bind",str(p),str(R/p.relative_to(E/"source"))],check=True)
subprocess.run(["mount","--bind",str(E/"suite"),str(R/"kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp")],check=True)
subprocess.run(["mount","--bind",str(E/"transport.py"),str(R/"corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py")],check=True)
os.execvp("make",["make","-f",str(E/"Makefile"),"safety"])
