#!/bin/sh
cd /workspaces/repository || exit
taskset -c 12-15 unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-ordering/inside.sh > /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-ordering/check.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/tetragon-execve/tag-ordering/check.exit
exit "$rc"
