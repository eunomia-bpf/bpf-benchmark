from pathlib import Path
import collections,datetime,importlib.util,json,subprocess,sys,traceback
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/A/design-only/lse-input');O=R/'kprog/arm64/build/lse-native/bcc';G=F/'generated';G.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'kprog/arm64/micro-prog'))
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
g=load('arm_lse_gen',R/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py');sm=load('arm_lse_smoke',R/'kprog/arm64/run_app_sim_smoke.py')
rows=[]
for native in sorted(O.glob('*.native.o')):
 nm=subprocess.check_output(['llvm-nm-18','--defined-only','--format=posix',str(native)],text=True)
 for fields in [x.split() for x in nm.splitlines()]:
  if len(fields)<2 or fields[1] not in ['T','t']:continue
  symbol=fields[0]
  with native.open('rb') as elf_file:
   elf=ELFFile(elf_file);sym=elf.get_section_by_name('.symtab').get_symbol_by_name(symbol)[0];section=elf.get_section(sym['st_shndx']).name
  name=native.name.removesuffix('.native.o')+'_'+symbol;row=dict(native=str(native),symbol=symbol,name=name);rows.append(row)
  try:
   proof=G/(name+'.proof.o');cmd=[str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'--input',str(native),'--symbol',symbol,'--mode','proof','--preserve-entry-abi','--output',str(proof)]
   with (G/(name+'.link.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
   row['link_exit']=p.returncode
   if p.returncode:continue
   functions,rodata=g.parse_native_linked_program(g.Bench(name,symbol,'raw'),G);src=G/(name+'.bpf.c');source=g.render_program(name,symbol,functions,'raw',rodata16=rodata,linked_exit=True,program_section=section)
   source=source.replace('#include "../arm64_sim_local_bpf.h"','#include "'+str(R/'kprog/arm64/arm64_sim_local_bpf.h')+'"');src.write_text(source);sm.prepend_externs(src,proof);row['generated']=True
   cmd=['clang-18','-g','-O2','-target','bpf','-mcpu=v4','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','--sysroot='+str(R/'kprog/arm64/build/app-runtime-v35/root'),'-I'+str(R/'kprog/arm64/build/app-runtime-v35/root/usr/include/aarch64-linux-gnu'),'-I'+str(R/'vendor/libbpf/src'),'-I'+str(R/'vendor/libbpf/include/uapi'),'-c',str(src),'-o',str(G/(name+'.bpf.o'))]
   with (G/(name+'.compile.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
   row['compile_exit']=p.returncode
  except Exception as e:row.update(error=str(e),traceback=traceback.format_exc())
  finally:(F/'bcc-generation.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows),indent=2)+'\n')
print('complete',len(rows),'generated',sum(bool(x.get('generated')) for x in rows),'compiled',sum(x.get('compile_exit')==0 for x in rows),flush=True)
