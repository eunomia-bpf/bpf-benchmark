from pathlib import Path
import subprocess,json,datetime,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/A/design-only/lse-input');O=R/'kprog/arm64/build/lse-native';O.mkdir(exist_ok=True,parents=True)
cmd=['make','-C',str(R/'vendor/bpf'),'-o','bcc/libbpf-tools/arm64/vmlinux.h','-j4','ARCH=arm64','NATIVE_OUT='+str(O),'NATIVE_ARCH_CFLAGS=-mtune=neoverse-n1 -mgeneral-regs-only -mno-outline-atomics -ffixed-x18 -ffixed-x26 -ffixed-x27 -ffixed-x28 -march=armv8.1-a+lse','NATIVE_SYS_INCLUDE_FLAGS=--sysroot='+str(R/'kprog/arm64/build/app-runtime-v35/root')+' -I'+str(R/'vendor/build/.bcc-libbpf/none/arm64/output')+' -I'+str(R/'kprog/arm64/build/app-runtime-v35/root/usr/include/aarch64-linux-gnu')]
tools=['capable','biosnoop','vfsstat','opensnoop','syscount','tcpconnect','tcplife','runqlat'];cmd += [str(O/'bcc'/(n+'.native.o')) for n in tools]
record=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,tools=tools)
with (F/'bcc-build.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
record['compile_exit']=p.returncode
if p.returncode==0:
 cmd=['python3',str(R/'vendor/bpf/write_native_manifest.py'),'--app','bcc','--llvm-nm','llvm-nm-18','--output',str(O/'bcc/manifest.json')]
 for n in tools:cmd+=['--object',str(O/'bcc'/(n+'.native.o'))]
 with (F/'bcc-manifest.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 record['manifest_exit']=p.returncode
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(F/'bcc-build.json').write_text(json.dumps(record,indent=2)+'\n')
