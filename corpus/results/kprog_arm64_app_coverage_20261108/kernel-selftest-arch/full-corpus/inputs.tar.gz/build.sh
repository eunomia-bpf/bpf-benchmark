cd /workspaces/repository
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/inside-before.sh > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/x86-before.log 2>&1
printf "%s\n" "$?" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/x86-before.exit
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/inside-after.sh x86-after > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/x86-after.log 2>&1
printf "%s\n" "$?" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/x86-after.exit
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/inside-after.sh arm-corpus > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/arm-corpus.log 2>&1
rc=$?
printf "%s\n" "$rc" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/arm-corpus.exit
exit "$rc"
