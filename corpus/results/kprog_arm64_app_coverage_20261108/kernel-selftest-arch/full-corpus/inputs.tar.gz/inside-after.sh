set -e
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/selftests.py.after /workspaces/repository/kprog/selftests/selftests.py
cd /workspaces/repository
exec make -f /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/Makefile "$@"
