from pathlib import Path
import importlib.util,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
s=importlib.util.spec_from_file_location('catalog',F/'source/kprog/selftests/selftests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.ROOT=R;m.DEFAULT_PROGS=R/'vendor/linux-framework/tools/testing/selftests/bpf/progs'
raise SystemExit(m.main(sys.argv))
