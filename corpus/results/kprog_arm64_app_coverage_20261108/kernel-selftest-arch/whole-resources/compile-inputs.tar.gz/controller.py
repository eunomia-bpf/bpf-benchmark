from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/whole-resources';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(t):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+t+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('original_resource_catalog_compile')
 cmd=['taskset','-c','12-15','python3',str(F/'compile.py'),'--arch','arm64','--only','map_kptr_fail','--out',str(F/'catalog')]
 with (F/'compile.log').open('w') as log:p=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('catalog compiler exit '+str(p.returncode))
 path=F/'catalog/programs.json';raw=path.read_text();(F/'compiler-original-programs.json').write_text(raw)
 j=json.loads(raw.replace(str(F/'catalog'),str(R/'kprog/arm64/build/kernel-selftests-current')));path.write_text(json.dumps(j,indent=2)+'\n')
 report=dict(utc=now(),compile_command=cmd,compile_exit=p.returncode,counts=j['counts'],resource_objects=sorted({r.get('bpf_object') for r in j['programs'] if r.get('bpf_object')}),source_scope='Original complete source supplies BPF resource/program context; isolated native entries retain C bodies; all programs autoloadfalse.')
 (O/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Whole original BPF resource context\n\nNative C entries retain individual compilation; one complete original BPF object per source file supplies maps, program context and complete pointee BTF. Existing direct submission disables all program autoload flags and selects the requested named program. This generic compiler change preserves original resource semantics and reuses each source object across entries.\n\nThe existing map_kptr_fail annotations are the component corpus. compile.json retains exact native/BPF coverage and paths; compile-inputs.tar.gz contains original/final catalog, source, diagnostics, tool invocations and built objects. The source-isolation/type-emission observations are in ../kptr-btf. The direct load-only component follows the existing helper194 replay through pidfd. Full380 source0 annotation epoch remains captured and active. Runtime admission additions:0.\n')
 rec=pub.publish(['kprog/selftests/selftests.py']+[str((O/n).relative_to(R)) for n in ['compile.json','compile-inputs.tar.gz','README.md']],'Preserve original kernel resource BTF while compiling native entries separately','arm-whole-resources-source')
 save('queued_after_helper194',publication=rec);notice('PUSHED '+rec['commit']+' common selftests.py original whole BPF resource/context objects cached once per source, native C entries isolated. Original map_kptr_fail component compile '+json.dumps(j['counts'])+'; one original resource object. Complete BTF originalSTRUCT32/8 versus isolatedFWD observations4713715b6. Existingautoloadfalse keeps programs unloaded while creating maps/BTF. Queued after helper194 component, allnative load-only. Runtime admission additions0.')
 pid=int((A/'bpf34/kptr-helper/controller.pid').read_text())
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('actual_whole_resource_component',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect original ARM whole-resource selftest outcomes','arm-whole-resources-result')
 save('finished',publication=rec,**report);notice('PUSHED '+rec['commit']+' original whole-resource ARM component terminal '+json.dumps(report.get('counts'))+'. All actual maps/context/P/B/verifier rows retained; full380 earlier epoch stays distinct. Added runtime admission0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
