__attribute__((section("license"),used)) char __original_license[]="GPL";
#include "/workspaces/repository/vendor/linux-framework/tools/testing/selftests/bpf/progs/map_kptr_fail.c"
