from pathlib import Path
import sys,json,ctypes as c,traceback,hashlib
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/selftests'))
from submit import ObjectResources
out=[]
Path(sys.argv[1]).mkdir(parents=True,exist_ok=True)
(Path(sys.argv[1])/'kernel-btf-sha256.txt').write_text(hashlib.sha256(Path('/sys/kernel/btf/vmlinux').read_bytes()).hexdigest()+'\n')
for name in ['no_null_check','null_check']:
 obj=None;row=dict(program=name,original_object=str(G/'verifier_lsm.bpf.o'),mode='original stock BPF load-only',executions=0)
 try:
  obj=ObjectResources.__new__(ObjectResources);obj.__init__('arm64',row['original_object'],name)
  obj.bind('bpf_object__load',c.c_int,c.c_void_p);obj.bind('bpf_program__fd',c.c_int,c.c_void_p);obj.bind('bpf_program__set_log_buf',c.c_int,c.c_void_p,c.c_void_p,c.c_size_t);obj.bind('bpf_program__set_log_level',c.c_int,c.c_void_p,c.c_uint32)
  buf=c.create_string_buffer(262144)
  obj.ok(obj.lib.bpf_program__set_log_buf(obj.program,buf,len(buf)),'set stock BPF verifier log buffer');obj.ok(obj.lib.bpf_program__set_log_level(obj.program,1),'set stock BPF log level');obj.ok(obj.lib.bpf_program__set_autoload(obj.program,True),'enable original BPF fixture')
  row.update(prog_type=obj.lib.bpf_program__type(obj.program),expected_attach_type=obj.lib.bpf_program__expected_attach_type(obj.program),section=obj.lib.bpf_program__section_name(obj.program).decode(),original_object_sha256=hashlib.sha256(Path(row['original_object']).read_bytes()).hexdigest())
  row['target_btf_id']=obj.lib.libbpf_find_vmlinux_btf_id(b'mmap_file',row['expected_attach_type']);row['load_return']=obj.lib.bpf_object__load(obj.obj);row['verifier_log']=buf.value.decode(errors='replace');row['fd']=obj.lib.bpf_program__fd(obj.program);row['stage']='installed' if row['load_return']==0 else 'load_rejected'
 except Exception as e:row.update(stage='baseline_infrastructure_error',error=str(e),traceback=traceback.format_exc())
 finally:
  if obj:obj.close()
 out.append(row);(Path(sys.argv[1])/'original-stock-lsm.json').write_text(json.dumps(out,indent=2)+'\n');print(name,row['stage'],flush=True)
