from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/stock-lsm';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (O/'README.md').write_text('Original ARM stock BPF LSM load-only comparison\n\nThe original complete verifier_lsm resource object from the59-source paired compiler2e9f2fd19 is loaded with the existing C baseline method. Both original no_null_check and null_check fixtures retain their published instructions and annotations. ObjectResources opens all entries with autoload=false, selects each original BPF program and captures the stock load outcome, target BTF ID and verifier log. Native execution count:0. Runtime BTF hash joins the paired ARM88a Image/module.\n\nThis2GiB12-15 guest follows the nativeOs three-entry component through pidfd. It compares the actual ARM stock-BPF qualification with the native-source0 result and C expanded315 matched x86 result. Original kernel selftest source stays published; runtime admission additions:0.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for root in [G/'source',G/'catalog']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
  for n in ['controller.py','mount.py','transport.py']:tf.add(G/n,arcname=n)
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),resource_sha256=hashlib.sha256((G/'catalog/verifier_lsm.bpf.o').read_bytes()).hexdigest(),scope='Original2LSMfixtures/stockBPFloadonly/pairedARM88a/2GiB12-15',resource_publication='2e9f2fd196f50e1951d622c2c30e370f1bbc2c9c',runtime_admission_additions=0),indent=2)+'\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Queue the original ARM stock LSM load comparison','arm-stock-lsm-launch')
 save('queued_after_native_Os_component',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR COORDINATOR/C/V '+now()+': PUSHED '+rec['commit']+' original ARM stockBPF LSM pair queuedafterOscomponent12-15/2GiB, same88aImage/module. Reuses C existing loadonly baseline script with ARMlibbpf and unchanged original59-resource verifier_lsm.o. Logs targetBTF andruntimeBTFsha for comparison to nativeinstalledARM268/41d vsx86 file__nullable71327. Originalannotations/instructions staypublished; nativeexecution0/runtimeadmissionadditions0.\n')
 pid=int((A/'app-source/tetragon-loop/v61-os/controller.pid').read_text())
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('actual_original_stock_LSM',publication=rec)
 with (G/'driver.log').open('w') as output:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=output,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,native_executions=0);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   for arc,out in [('run/out/original-stock-lsm.json','original-stock-lsm.json'),('run/out/kernel-btf-sha256.txt','kernel-btf-sha256.txt'),('run/baseline.log','baseline.log')]:
    if arc in tf.getnames():
     data=tf.extractfile(arc).read();(O/out).write_bytes(data);paths.append(O/out)
   if (O/'original-stock-lsm.json').exists():report['rows']=json.loads((O/'original-stock-lsm.json').read_text())
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect original ARM stock BPF LSM load outcomes','arm-stock-lsm-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR COORDINATOR/C/V '+now()+': PUSHED '+rec['commit']+' original ARMstockLSM '+json.dumps([dict(program=r.get('program'),stage=r.get('stage'),target_btf_id=r.get('target_btf_id')) for r in report.get('rows',[])])+'. SamepairedImage/BTF pinned; source/annotations/raw logs retained. Nativeexecution0/runtime additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
