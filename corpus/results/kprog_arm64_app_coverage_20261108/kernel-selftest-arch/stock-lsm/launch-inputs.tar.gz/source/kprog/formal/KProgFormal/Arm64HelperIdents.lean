import KProgFormal.Generated.GeneratedArm64HelperIdents

namespace KProgFormal

/-- Independent enumeration of the encoder's 88 BPF helper ids with the
helper name each one denotes, in id-sorted order. Written out by hand so it
shares no structure with the generated table. -/
def helperIdentsSpec : List (Nat × String) := [
  (1, "bpf_map_lookup_elem"), (2, "bpf_map_update_elem"),
  (3, "bpf_map_delete_elem"), (4, "bpf_probe_read"),
  (5, "bpf_ktime_get_ns"), (6, "bpf_trace_printk"),
  (7, "bpf_get_prandom_u32"), (8, "bpf_get_smp_processor_id"),
  (9, "bpf_skb_store_bytes"), (10, "bpf_l3_csum_replace"),
  (11, "bpf_l4_csum_replace"), (12, "bpf_tail_call"),
  (13, "bpf_clone_redirect"), (14, "bpf_get_current_pid_tgid"),
  (15, "bpf_get_current_uid_gid"), (16, "bpf_get_current_comm"),
  (20, "bpf_skb_get_tunnel_key"),
  (21, "bpf_skb_set_tunnel_key"), (23, "bpf_redirect"),
  (25, "bpf_perf_event_output"), (26, "bpf_skb_load_bytes"),
  (27, "bpf_get_stackid"), (28, "bpf_csum_diff"),
  (31, "bpf_skb_change_proto"), (32, "bpf_skb_change_type"),
  (33, "bpf_skb_under_cgroup"), (35, "bpf_get_current_task"),
  (36, "bpf_probe_write_user"),
  (37, "bpf_current_task_under_cgroup"), (38, "bpf_skb_change_tail"),
  (39, "bpf_skb_pull_data"), (43, "bpf_skb_change_head"),
  (44, "bpf_xdp_adjust_head"), (45, "bpf_probe_read_str"),
  (46, "bpf_get_socket_cookie"), (50, "bpf_skb_adjust_room"),
  (54, "bpf_xdp_adjust_meta"),
  (58, "bpf_override_return"),
  (65, "bpf_xdp_adjust_tail"), (67, "bpf_get_stack"),
  (68, "bpf_skb_load_bytes_relative"), (69, "bpf_fib_lookup"),
  (80, "bpf_get_current_cgroup_id"), (85, "bpf_sk_lookup_udp"),
  (86, "bpf_sk_release"),
  (87, "bpf_map_push_elem"),
  (88, "bpf_map_pop_elem"),
  (95, "bpf_sk_fullsock"),
  (99, "bpf_skc_lookup_tcp"),
  (105, "bpf_strtol"),
  (109, "bpf_send_signal"),
  (112, "bpf_probe_read_user"), (113, "bpf_probe_read_kernel"),
  (114, "bpf_probe_read_user_str"), (115, "bpf_probe_read_kernel_str"),
  (118, "bpf_jiffies64"), (122, "bpf_get_netns_cookie"),
  (124, "bpf_sk_assign"),
  (125, "bpf_ktime_get_boot_ns"), (127, "bpf_seq_write"),
  (130, "bpf_ringbuf_output"),
  (131, "bpf_ringbuf_reserve"), (132, "bpf_ringbuf_submit"),
  (133, "bpf_ringbuf_discard"),
  (148, "bpf_copy_from_user"), (152, "bpf_redirect_neigh"),
  (154, "bpf_this_cpu_ptr"), (155, "bpf_redirect_peer"),
  (158, "bpf_get_current_task_btf"), (160, "bpf_ktime_get_coarse_ns"),
  (161, "bpf_ima_inode_hash"), (163, "bpf_check_mtu"),
  (173, "bpf_get_func_ip"),
  (174, "bpf_get_attach_cookie"), (175, "bpf_task_pt_regs"),
  (181, "bpf_loop"), (182, "bpf_strncmp"),
  (183, "bpf_get_func_arg"), (184, "bpf_get_func_ret"),
  (185, "bpf_get_func_arg_cnt"), (186, "bpf_get_retval"),
  (188, "bpf_xdp_get_buff_len"),
  (189, "bpf_xdp_load_bytes"),
  (190, "bpf_xdp_store_bytes"),
  (191, "bpf_copy_from_user_task"), (193, "bpf_ima_file_hash"),
  (194, "bpf_kptr_xchg"),
  (195, "bpf_map_lookup_percpu_elem"),
]

/-- Constructor enumeration of the generated table, in specification order;
the values still come from the generated `id`/`name` definitions. -/
def allHelperIdents : List GeneratedArm64HelperIdents.Helper := [
  .bpf_map_lookup_elem, .bpf_map_update_elem,
  .bpf_map_delete_elem, .bpf_probe_read,
  .bpf_ktime_get_ns, .bpf_trace_printk,
  .bpf_get_prandom_u32, .bpf_get_smp_processor_id,
  .bpf_skb_store_bytes, .bpf_l3_csum_replace,
  .bpf_l4_csum_replace, .bpf_tail_call,
  .bpf_clone_redirect, .bpf_get_current_pid_tgid,
  .bpf_get_current_uid_gid, .bpf_get_current_comm,
  .bpf_skb_get_tunnel_key,
  .bpf_skb_set_tunnel_key, .bpf_redirect,
  .bpf_perf_event_output, .bpf_skb_load_bytes,
  .bpf_get_stackid, .bpf_csum_diff,
  .bpf_skb_change_proto, .bpf_skb_change_type,
  .bpf_skb_under_cgroup, .bpf_get_current_task,
  .bpf_probe_write_user,
  .bpf_current_task_under_cgroup, .bpf_skb_change_tail,
  .bpf_skb_pull_data, .bpf_skb_change_head,
  .bpf_xdp_adjust_head, .bpf_probe_read_str,
  .bpf_get_socket_cookie, .bpf_skb_adjust_room,
  .bpf_xdp_adjust_meta,
  .bpf_override_return,
  .bpf_xdp_adjust_tail, .bpf_get_stack,
  .bpf_skb_load_bytes_relative, .bpf_fib_lookup,
  .bpf_get_current_cgroup_id, .bpf_sk_lookup_udp,
  .bpf_sk_release,
  .bpf_map_push_elem,
  .bpf_map_pop_elem,
  .bpf_sk_fullsock,
  .bpf_skc_lookup_tcp,
  .bpf_strtol,
  .bpf_send_signal,
  .bpf_probe_read_user, .bpf_probe_read_kernel,
  .bpf_probe_read_user_str, .bpf_probe_read_kernel_str,
  .bpf_jiffies64, .bpf_get_netns_cookie,
  .bpf_sk_assign,
  .bpf_ktime_get_boot_ns, .bpf_seq_write,
  .bpf_ringbuf_output,
  .bpf_ringbuf_reserve, .bpf_ringbuf_submit, .bpf_ringbuf_discard,
  .bpf_copy_from_user, .bpf_redirect_neigh,
  .bpf_this_cpu_ptr, .bpf_redirect_peer,
  .bpf_get_current_task_btf, .bpf_ktime_get_coarse_ns,
  .bpf_ima_inode_hash, .bpf_check_mtu, .bpf_get_func_ip,
  .bpf_get_attach_cookie, .bpf_task_pt_regs,
  .bpf_loop, .bpf_strncmp,
  .bpf_get_func_arg, .bpf_get_func_ret,
  .bpf_get_func_arg_cnt, .bpf_get_retval,
  .bpf_xdp_get_buff_len,
  .bpf_xdp_load_bytes,
  .bpf_xdp_store_bytes,
  .bpf_copy_from_user_task, .bpf_ima_file_hash,
  .bpf_kptr_xchg,
  .bpf_map_lookup_percpu_elem,
]

/-- The generated table, projected to `(id, name)` pairs, equals the
independent enumeration. A change to a generated id or name, or to the
independent list, breaks this equality. -/
theorem helper_idents_refines :
    helperIdentsSpec =
      allHelperIdents.map (fun h =>
                             (GeneratedArm64HelperIdents.id h,
                              GeneratedArm64HelperIdents.name h)) := by
  native_decide

/-- No two real helper calls share a name. -/
theorem helper_idents_names_nodup :
    (helperIdentsSpec.map Prod.snd).Nodup := by
  native_decide

/-- The ids are strictly increasing in the specification's order. -/
theorem helper_idents_ids_strictly_increasing :
    (List.zip helperIdentsSpec (List.tail helperIdentsSpec)).all
      (fun p => if p.1.1 < p.2.1 then true else false) = true := by
  native_decide

/-- Every generated constructor participates in the independent comparison.
Extending the generated helper type adds a constructor case to this law. -/
theorem helper_idents_complete (helper : GeneratedArm64HelperIdents.Helper) :
    helper ∈ allHelperIdents := by
  cases helper <;> decide

/-- Each generated helper's exact id/name pair occurs in the independent list. -/
theorem helper_idents_pair_complete (helper : GeneratedArm64HelperIdents.Helper) :
    (GeneratedArm64HelperIdents.id helper, GeneratedArm64HelperIdents.name helper) ∈ helperIdentsSpec := by
  rw [helper_idents_refines]
  exact List.mem_map.mpr ⟨helper, helper_idents_complete helper, rfl⟩

end KProgFormal
