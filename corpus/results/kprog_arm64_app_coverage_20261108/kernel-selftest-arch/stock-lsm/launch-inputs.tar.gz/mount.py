from pathlib import Path
import os,subprocess,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'source').rglob('*')):
 if p.is_file() and 'kernel-selftests-current' not in str(p):subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(F/'source'))],check=True)
subprocess.run(['mount','--bind',str(F/'catalog'),str(R/'kprog/arm64/build/kernel-selftests-current')],check=True)
target=R/'kprog/arm64/build/kernel-selftest-runner-current/bpf34-full.py'
subprocess.run(['mount','--bind',str(F/'transport.py'),str(target)],check=True)
os.execv(sys.executable,[sys.executable,str(target),'host','control',str(R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/stock-lsm')])
