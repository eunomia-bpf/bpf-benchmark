from pathlib import Path
import datetime,json,subprocess
F=Path(__file__).resolve().parent
cmd=['taskset','-c','12-15','unshare','--mount','--propagation','private','sh',str(F/'paired-build.sh')]
p=subprocess.run(cmd,cwd='/workspaces/repository')
(F/'paired-status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,returncode=p.returncode),indent=2)+'\n')
