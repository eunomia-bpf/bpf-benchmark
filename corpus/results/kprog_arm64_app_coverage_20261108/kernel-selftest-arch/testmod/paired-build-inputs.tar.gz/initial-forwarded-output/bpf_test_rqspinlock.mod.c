#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x5ffd9032, "__cpu_online_mask" },
	{ 0x32047ad5, "__per_cpu_offset" },
	{ 0x122c3a7e, "_printk" },
	{ 0x017de3d5, "nr_cpu_ids" },
	{ 0x53a1e8d9, "_find_next_bit" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xc3a050d2, "kthread_stop" },
	{ 0x037a0cba, "kfree" },
	{ 0xa74a136e, "perf_event_release_kernel" },
	{ 0x8554eded, "__num_online_cpus" },
	{ 0xb8342c83, "__kmalloc_noprof" },
	{ 0xe8f76c52, "perf_event_create_kernel_counter" },
	{ 0xcb9db21d, "kthread_bind" },
	{ 0xfd84892e, "wake_up_process" },
	{ 0xc0ece82f, "kthread_create_on_node" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0xf9a482f9, "msleep" },
	{ 0x18a4af23, "perf_event_enable" },
	{ 0xbd3d3a82, "rqspinlock_held_locks" },
	{ 0x6ebe366f, "ktime_get_mono_fast_ns" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xf70e4a4d, "preempt_schedule_notrace" },
	{ 0x43b0c9c3, "preempt_schedule" },
	{ 0x83950b0a, "resilient_queued_spin_lock_slowpath" },
	{ 0x8cd43da0, "param_ops_int" },
	{ 0x008a44e9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "031C47E962486809FFF2258");
