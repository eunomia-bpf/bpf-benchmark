./bpf_test_no_cfi.o
