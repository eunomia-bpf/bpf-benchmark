#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x8d24813b, "__register_bpf_struct_ops" },
	{ 0x008a44e9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "E3D6B4A1EF8CEF8556D81E6");
