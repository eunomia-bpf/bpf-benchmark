#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

KSYMTAB_FUNC(bpf_testmod_test_read, "", "");
KSYMTAB_FUNC(bpf_testmod_test_write, "", "");
KSYMTAB_FUNC(bpf_fentry_shadow_test, "_gpl", "");

SYMBOL_CRC(bpf_testmod_test_read, 0xf2a628c5, "");
SYMBOL_CRC(bpf_testmod_test_write, 0xf89e35ac, "");
SYMBOL_CRC(bpf_fentry_shadow_test, 0xa455f018, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xad863b58, "trace_event_buffer_reserve" },
	{ 0x9161370e, "trace_event_buffer_commit" },
	{ 0x67ef6d7b, "__trace_trigger_soft_disabled" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xc176730c, "trace_raw_output_prep" },
	{ 0x4fb1a6b7, "trace_event_printf" },
	{ 0x7a1929c1, "trace_handle_return" },
	{ 0x928cd9bc, "bpf_trace_run2" },
	{ 0x8bef7a38, "bpf_trace_run1" },
	{ 0x037a0cba, "kfree" },
	{ 0x81a4ceb2, "mutex_lock" },
	{ 0xeb5546a2, "mutex_unlock" },
	{ 0x122c3a7e, "_printk" },
	{ 0xd2f00bcf, "btf_ctx_access" },
	{ 0xc8a7599a, "bpf_struct_ops_id" },
	{ 0xc67e1059, "_raw_spin_lock_irqsave" },
	{ 0x52e94aa9, "_raw_spin_unlock_irqrestore" },
	{ 0x57a9c5f9, "bpf_find_btf_id" },
	{ 0xd31a4c91, "register_btf_kfunc_id_set" },
	{ 0x6985c2de, "bpf_fentry_test1" },
	{ 0xba8f4b02, "mutex_init_generic" },
	{ 0x49f719fb, "kernel_kobj" },
	{ 0x2865fd7a, "sysfs_create_bin_file" },
	{ 0x8d24813b, "__register_bpf_struct_ops" },
	{ 0x637c061d, "register_btf_id_dtor_kfuncs" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x5a921311, "strncmp" },
	{ 0xf70e4a4d, "preempt_schedule_notrace" },
	{ 0xb6e16cdb, "perf_trace_buf_alloc" },
	{ 0x45ee6c56, "perf_trace_run_bpf_submit" },
	{ 0x5ffd9032, "__cpu_online_mask" },
	{ 0x96e301c3, "tracepoint_srcu" },
	{ 0x6f38e04b, "kmalloc_caches" },
	{ 0x8db5feb1, "__kmalloc_cache_noprof" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0x28aa6a67, "call_rcu" },
	{ 0x5d16eed4, "refcount_warn_saturate" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x26b665bf, "rcu_tasks_trace_srcu_struct" },
	{ 0xa80ebeb5, "call_srcu" },
	{ 0xa0d2cd73, "sock_create_kern" },
	{ 0xe55a70dc, "sock_release" },
	{ 0xf9a482f9, "msleep" },
	{ 0x68d2a441, "irq_work_sync" },
	{ 0x07b6df18, "tasklet_kill" },
	{ 0x9296b73d, "sysfs_remove_bin_file" },
	{ 0x711790e9, "kernel_connect" },
	{ 0xfe2a1fc6, "kernel_bind" },
	{ 0x31f8179e, "kernel_listen" },
	{ 0xdcb764ad, "memset" },
	{ 0x10937734, "kernel_sendmsg" },
	{ 0xd75eeff7, "iov_iter_kvec" },
	{ 0x4769effa, "sock_sendmsg" },
	{ 0xdb9ba88a, "kernel_getsockname" },
	{ 0x57282aed, "kernel_getpeername" },
	{ 0x2c297515, "__tasklet_schedule" },
	{ 0xd4dca7d8, "irq_work_queue" },
	{ 0xdf0d489c, "bpf_prog_get_assoc_struct_ops" },
	{ 0x1d5ebe83, "bpf_base_func_proto" },
	{ 0x4490d798, "trace_event_reg" },
	{ 0x48e3b12d, "trace_event_raw_init" },
	{ 0x008a44e9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "34B656B5834206B839BA8C9");
