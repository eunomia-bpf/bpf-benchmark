from pathlib import Path
import datetime,json,os,subprocess
F=Path(__file__).resolve().parent;K=Path('/workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/kernel-link/cache')
command=['taskset','-c','12-15','make','-C',str(K),'ARCH=arm64','CROSS_COMPILE=aarch64-linux-gnu-','M='+str(F/'source'),'modules','-j2']
p=subprocess.run(command,cwd='/workspaces/repository')
(F/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,phase='build_finished',returncode=p.returncode),indent=2)+'\n')
