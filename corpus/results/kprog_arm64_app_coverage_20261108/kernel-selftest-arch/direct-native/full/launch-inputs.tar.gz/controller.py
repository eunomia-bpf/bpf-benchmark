from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR R/C/V '+now()+': '+s+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(G)))
 (O/'README.md').write_text('Complete ARM direct native kernel annotation catalog\n\nThis full-system2GiB/two-vCPU QEMU run consumes all380compiled native entries from the full1917-row catalog. Every source object opens with all program autoload flagsfalse; actual maps/BTF and temporary bpffs pins carry resources. source_prog_id0/context/native P go through SUBMIT_RESOURCES and the registered service. Installed __failure rows count as findings, installed __success rows as agreement, and stock-verifier refusals retain the annotation comparison. All resource/generation/compiler/transport/load stages keep their raw outcomes. The original source catalog keeps its compilation and entry stages. Current paired88a Image/module, current canonical runner/loader/linker, ordered tag source and the exact direct submit source are pinned in launch inputs. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run the full ARM kernel catalog through direct native submission','bpf34-full-launch')
 save('actual_full_direct_catalog',publication=rec);notice('PUSHED '+rec['commit']+' full380 ARM native direct/source0 catalog START, all types, objectsautoloadfalse/maps+BTF/pins, installed-stage agreement;2GiB/two-vCPU8-11 with current coherent producer/linker. Exact native/context/source/runtime pins archived. Runtime admission additions0.')
 with (G/'driver.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'})
 paths=[];report=dict(utc=now(),make_exit=p.returncode)
 (O/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 Q=O/'trusted-arm64-service-result'
 if (Q/'summary.json').exists():
  s=json.loads((Q/'summary.json').read_text());archive=Q/s['archive'];paths.extend([Q/'summary.json',archive]);report['runtime']={k:s.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(archive) as tf:
   name='run/out/submissions.json'
   if name in tf.getnames():
    payload=tf.extractfile(name).read();(O/'submissions.json').write_bytes(payload);paths.append(O/'submissions.json');report['counts']=json.loads(payload)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the complete ARM direct native kernel catalog outcomes','bpf34-full-result')
 save('finished',publication=rec,**report);notice('PUSHED '+rec['commit']+' complete direct ARM kernel catalog terminal Makeexit'+str(p.returncode)+'; actual counts '+json.dumps(report.get('counts'))+'. Full raw native/B/maps/context/verifier records retained. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
