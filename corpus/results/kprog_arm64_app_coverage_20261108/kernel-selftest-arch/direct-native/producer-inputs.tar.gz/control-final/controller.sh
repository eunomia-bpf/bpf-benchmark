#!/bin/sh
cd /workspaces/repository || exit
unshare --mount --propagation private python3 /workspaces/.agent-state/kprog-lanes/A/bpf34/control-final/mount.py > /workspaces/.agent-state/kprog-lanes/A/bpf34/control-final/driver.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/bpf34/control-final/control.exit
exit "$rc"
