#!/bin/sh
cd /workspaces/repository || exit
unshare --mount --propagation private python3 /workspaces/.agent-state/kprog-lanes/A/bpf34/control/mount.py > /workspaces/.agent-state/kprog-lanes/A/bpf34/control/driver.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/bpf34/control/control.exit
exit "$rc"
