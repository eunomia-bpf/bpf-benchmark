from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full-whole-resources';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(t):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': '+t+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('reusing_native_objects_refreshing_original_resource_objects')
 s=importlib.util.spec_from_file_location('catalog',F/'source/kprog/selftests/selftests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.ROOT=R
 table=json.loads((F/'original-programs.json').read_text());progs=R/'vendor/linux-framework/tools/testing/selftests/bpf/progs';bpf=progs.parent
 inc=[bpf,progs,F/'catalog/include',bpf/'tools/include',bpf/'tools/include/uapi',R/'vendor/libbpf/include/uapi',R/'vendor/libbpf/src',Path('/usr/aarch64-linux-gnu/include')]
 companions={};natives=[]
 for row in table['programs']:
  if not row.get('compiled'):continue
  src=Path(row['path']);native=src.stem+'__'+row['program']+'.native.o';original=R/'kprog/arm64/build/kernel-selftests-current'/native
  shutil.copy2(original,F/'catalog'/native);natives.append(dict(name=native,sha256=hashlib.sha256(original.read_bytes()).hexdigest()))
  if src not in companions:
   obj=F/'catalog'/(src.stem+'.bpf.o')
   ok,err=m.compile_bpf(src,obj,inc,'/usr/lib/llvm-18/bin/clang','arm64')
   companions[src]=dict(source=str(src),object=str(obj),ok=ok,error=err)
  c=companions[src]
  row['bpf_object']=str(R/'kprog/arm64/build/kernel-selftests-current'/(src.stem+'.bpf.o')) if c['ok'] else None
  if c['ok']:row.pop('bpf_error',None)
  else:row['bpf_error']=c['error'][-1200:]
 (F/'catalog/programs.json').write_text(json.dumps(table,indent=2)+'\n')
 report=dict(utc=now(),original_counts=table['counts'],native_objects_reused=len(natives),resource_sources=len(companions),resource_compiled=sum(c['ok'] for c in companions.values()),resources=list(companions.values()),native_sha256=natives,scope='Full original catalog; native objects reused byte for byte, original complete BPF resources compiled once per source, helper194 current source captured',runtime_admission_additions=0)
 (O/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Complete ARM original-resource successor\n\nThis complete380native-entry successor retains the1917-row source catalog and all native compilation outcomes. Every successful native object is reused byte for byte. One complete original BPF resource/context object per source file preserves maps and BTF pointees; existing direct source0 submission disables all program autoload flags. Current generic helper194 operation and exact linker identity are captured. compile.json records every original source-resource compilation result and native object hash.\n\nThe run follows the previous full380 direct epoch and the whole-resource component through existing pidfd waits. Guest memory2GiB/CPUs8-11; the serial application guest retains8GiB16-19. Every real generator/compiler/resource/verifier/installed stage enters the original annotation comparison, and all native annotation rows remain load-only. Launch inputs and actual terminal raw artifacts are published separately. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','compile.json','launch-inputs.tar.gz']],'Reuse the full ARM native catalog with original complete resource objects','arm-full-whole-resources-launch')
 save('queued_after_full_and_component',publication=rec);notice('PUSHED '+rec['commit']+' complete380 ARM original-resource successor queued after actual current380 and whole-resource component. Reused native objects'+str(len(natives))+'; original resource sources'+str(len(companions))+'/compiled'+str(report['resource_compiled'])+'. Exact original catalog/compiler errors retained; helper194 current model/linker. Source0/allprogramautoloadfalse/loadonly. Runtime admission additions0.')
 for name in ['full','whole-resources']:
  pid=int((A/'bpf34'/name/'controller.pid').read_text())
  try:
   fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
  except ProcessLookupError:pass
 save('actual_complete_original_resource_catalog',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the complete ARM original-resource native catalog','arm-full-whole-resources-result')
 save('finished',publication=rec,**report);notice('PUSHED '+rec['commit']+' complete original-resource ARM terminal '+json.dumps(report.get('counts'))+'. Every real P/B/maps/BTF/compiler/verifier row retained. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
