from pathlib import Path
import os,subprocess
F=Path(__file__).resolve().parent;G=F.parent;R=Path('/workspaces/repository')
for p in sorted((G/'source').rglob('*')):
 if p.is_file() and p.suffix!='.pyc':subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
subprocess.run(['mount','--bind',str(F/'suite'),str(R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp')],check=True)
subprocess.run(['mount','--bind',str(F/'transport.py'),str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py')],check=True)
subprocess.run(['mount','--bind',str(R/'runner/build-arm64-llvmbpf/native_loader/trusted-native-loader'),str(R/'kprog/libnativeloader/build-arm64-a-map-order-v3/trusted-native-loader')],check=True)
os.execvp('make',['make','-f',str(F/'Makefile'),'safety'])
