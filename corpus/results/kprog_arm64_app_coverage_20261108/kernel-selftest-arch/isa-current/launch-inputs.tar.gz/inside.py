from pathlib import Path
import os,subprocess
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'source').rglob('*')):
 if p.is_file() and p.suffix!='.pyc':subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(F/'source'))],check=True)
subprocess.run(['mount','--bind',str(F/'suite'),str(R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp')],check=True)
subprocess.run(['mount','--bind',str(F/'check.py'),str(R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py')],check=True)
subprocess.run(['mount','--bind',str(F/'transport.py'),str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py')],check=True)
for p in (F/'build').iterdir():
 subprocess.run(['mount','--bind',str(p),str(R/'kprog/formal/build/fidelity-trusted-arm64'/p.name)],check=True)
os.execvp('make',['make','-f',str(F/'Makefile'),'safety'])
