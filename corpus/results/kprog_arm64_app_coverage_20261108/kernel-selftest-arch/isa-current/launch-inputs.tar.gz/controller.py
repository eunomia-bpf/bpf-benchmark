from pathlib import Path
import datetime,gzip,hashlib,importlib.util,io,json,os,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/isa-current';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+s+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('incremental_producer_relink')
 args=json.loads((F/'suite/build.json').read_text())['producer_command']
 args=[str(F/'libnative_loader.a') if x.endswith('/libnative_loader.a') else str(F/'libbpf.a') if x.endswith('/libbpf.a') else x for x in args]
 args[-1]=str(F/'build/bound-probe');args=['taskset','-c','12-15',*args]
 with (F/'build.log').open('w') as log:p=subprocess.run(args,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(command=args,build_exit=p.returncode,source_sha256=hashlib.sha256((R/'kprog/fidelity/bound_probe.cpp').read_bytes()).hexdigest(),before_sha256=hashlib.sha256((F/'bound-probe.before').read_bytes()).hexdigest())
 (F/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 if p.returncode:raise RuntimeError('incremental producer relink exit '+str(p.returncode))
 report['producer_sha256']=hashlib.sha256((F/'build/bound-probe').read_bytes()).hexdigest()
 (F/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 target=R/'kprog/formal/build/fidelity-trusted-arm64/bound-probe';shutil.copy2(F/'build/bound-probe',target.with_suffix('.next'));os.replace(target.with_suffix('.next'),target)
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),source='ordered5c7a/exactextent88a/currenthelperlinker',cases=34,guest_memory='2GiB',cpus='12-15',producer=report,runtime_admission_additions=0),indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 old=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-execve/sparse-tags/safety-current-loader/trusted-arm64-service-result'
 oldsum=json.loads((old/'summary.json').read_text())
 (O/'historical-bootstrap.json').write_text(json.dumps(dict(scope='Prior packed-tag/fresh-loader transport reached valid_control then stale producer demanded nonzero-generation sidecar; cases0 and actual native outcomes0',summary=oldsum),indent=2)+'\n')
 with tarfile.open(O/'historical-bootstrap-inputs.tar.gz','w:gz') as tf:
  base=A/'tetragon-execve/sparse-tags/safety-current-loader'
  for p in sorted(base.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(base)))
 (O/'README.md').write_text('Current ARM ISA replay\n\nThe existing34 ISA fixtures run through the current canonical ordered-tag simulator and paired exact-native-extent runtime. The original stale producer generation-sidecar demand is retained in historical-bootstrap.json and the original full QEMU archive. Current bound_probe.cpp already follows the design-only path; an incremental single-unit relink against the current canonical ARM loader/libbpf refreshes the binary. Canonical producer adoption preserves the old binary and full source/command identities.\n\nThis replay preserves native inputs and named positive workload checks; negative cases are load-only. The private harness selects the current canonical loader path and reuses the existing request.lock archive-completion lifecycle. The complete380 direct source0 annotation catalog runs in its captured epoch alongside this2GiB guest; ordered applications use8GiB. Terminal publication records every actual stage. Runtime admission additions:0.\n')
 paths=[str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','historical-bootstrap.json','historical-bootstrap-inputs.tar.gz','README.md']]
 paths += [str((old/n).relative_to(R)) for n in ['summary.json',oldsum['archive']]]
 rec=pub.publish(paths,'Refresh the ARM design-only producer and replay the original ISA fixtures','arm-isa-current-launch')
 save('actual_isa_replay',publication=rec);notice('PUSHED '+rec['commit']+' current canonical ARM producer incrementally relinked from existing design-only source. Original34 ISA replay START12-15/2GiB; captured ordered5c7a/extent88a/currenthelper linker. Prior packed/fresh-loader bootstrap case0 stalegeneration demand archived. Full3802GiB+apps8GiB+ISA2GiB total12GiB. Runtime admission additions0.')
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'inside.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 paths=[];report=dict(utc=now(),make_exit=p.returncode)
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 Q=O/'trusted-arm64-service-result'
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths += [Q/'summary.json',Q/j['archive']];report['runtime']={k:j.get(k) for k in ['ok','guest_exit','qemu_returncode','compiler_exit','guest','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/outcomes.json'
   if n in tf.getnames():
    payload=tf.extractfile(n).read();(O/'outcomes.json').write_bytes(payload);paths.append(O/'outcomes.json')
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the current ARM ISA native service outcomes','arm-isa-current-result')
 save('finished',publication=rec,**report);notice('PUSHED '+rec['commit']+' current canonical ARM original34 terminal Makeexit'+str(p.returncode)+'; actual '+json.dumps(report.get('runtime',{}).get('guest'))+'. Full P/B/verifier/raw bootstrap records retained. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
