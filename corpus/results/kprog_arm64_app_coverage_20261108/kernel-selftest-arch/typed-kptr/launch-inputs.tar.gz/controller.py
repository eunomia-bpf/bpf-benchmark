from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;G=A/'bpf34/testmod';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/typed-kptr';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(t):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': '+t+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('paired_module_and_component_publication')
 P=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/testmod'
 j=dict(utc=now(),paired_build=json.loads((G/'paired-status.json').read_text()),cache_restore=json.loads((G/'cache-bookkeeping-restoration.json').read_text()),modules={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (G/'build').glob('*.ko')},kernel_image_sha256=hashlib.sha256((R/'kprog/arm64/build/native-extent/Image').read_bytes()).hexdigest(),scope='Exact preceding88a source mounts and sole warm kernel cache; external module output has its explicit MO directory.')
 (P/'paired-build.json').write_text(json.dumps(j,indent=2)+'\n')
 with tarfile.open(P/'paired-build-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name!='publication.json':tf.add(p,arcname=str(p.relative_to(G)))
 with (P/'README.md').open('a') as f:f.write('\nThe first direct-cache command followed the generated Makefile forwarding path to the shared kernel base and placed external outputs in the cache root. paired-build.json records exact restoration of Makefile, the paired vmlinux symbol table and the identical-config module order. The established88a mount recipe now selects the exact retained kernel source/cache and gives external modules a separate MO output directory; paired build exits0 and all five split-BTF modules are archived in paired-build-inputs.tar.gz. Actual guest module admission and typed-map outcomes follow in ../typed-kptr.\n')
 H=A/'bpf34/full-whole-resources';Q=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full-whole-resources'
 module='kprog/arm64/build/native-extent/kinsn/bpf_testmod.ko';target=H/'source'/module;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((F/'source'/module).read_bytes())
 p=H/'transport.py';text=p.read_text().replace("'insmod ' + str(module),","'insmod ' + str(module),\n                            'insmod ' + str(ROOT / 'kprog/arm64/build/native-extent/kinsn/bpf_testmod.ko'),");p.write_text(text)
 (Q/'module-refresh.json').write_text(json.dumps(dict(utc=now(),module=module,module_sha256=j['modules']['bpf_testmod.ko'],paired_image_sha256=j['kernel_image_sha256'],scope=j['scope']),indent=2)+'\n')
 with tarfile.open(Q/'module-refresh.tar.gz','w:gz') as tf:
  tf.add(target,arcname='source/'+module);tf.add(H/'transport.py',arcname='transport.py')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Typed original ARM kptr resource replay\n\nThe same19 compiled native entries and original whole map_kptr_fail resource object run with the upstream bpf_testmod loaded into the exact paired88a guest. Native P bytes are reused from7a812373a; generic helper194 operation/identity376b9e3fd and actual address-registry641fd9d43 are captured. Every program remains autoload=false during map/BTF creation, and every native request is load-only/source0. The20-row annotation catalog retains its original one native compilation failure. Kernel test source and safety cases retain their published bytes.\n\nLaunch inputs carry exact loader/module/source/catalog bytes. Terminal publication keeps each real resource/generation/compiler/verifier/installed stage and the separate annotation agreement. Earlier isolated-BTF and missing-module epochs keep their original raw evidence. Runtime admission additions:0.\n')
 paths=[str((P/n).relative_to(R)) for n in ['README.md','paired-build.json','paired-build-inputs.tar.gz']]+[str((Q/n).relative_to(R)) for n in ['module-refresh.json','module-refresh.tar.gz']]+[str((O/n).relative_to(R)) for n in ['README.md','launch-inputs.tar.gz']]
 rec=pub.publish(paths,'Replay original ARM typed resources with the exact upstream test module','arm-typed-kptr-launch')
 save('actual_typed_kptr_component',publication=rec);notice('PUSHED '+rec['commit']+' exact88a mount recipe/current paired bpf_testmod build0 plus original19native-entry typed-kptr START12-15/2GiB. Initial forwarding-path build, cache index restoration and all five modules archived; native P/annotations/safety source unchanged. Queued full380 original-resource epoch receives same module/boot refresh. Added admission0.')
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect original ARM typed kptr verifier and installed outcomes','arm-typed-kptr-result')
 save('finished',publication=rec,**report);notice('PUSHED '+rec['commit']+' actual paired-testmod whole-resource original kernel annotation component terminal '+json.dumps(report.get('counts'))+'. Every native/maps/BTF/B/verifier outcome retained; source edits0. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
