from pathlib import Path
import datetime,gzip,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/resource-prepare';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Existing libbpf resource-only preparation\n\nThe common direct producer uses the existing bpf_object__prepare API to create/pin maps+BTF and relocate source context while every program remains autoload=false. This API already serves finish_simulator_proof in the common loader. Program loading and program-array FD initialization remain separate program lifecycle operations. The previous app component preserved the execve_rate fd-2 initializer error from bpf_object__load.\n\nThe existing original global_func8 positive control and edited original Tetragon execve_send input are load-only components through source0 and the paired88a runtime. Complete original source resources and object-default global values remain captured; actual full-application data/counters retain their own phase. Runtime admission additions:0.\n')

 rec=pub.publish(['kprog/selftests/submit.py']+[str((O/n).relative_to(R)) for n in ['README.md','launch-inputs.tar.gz']],'Prepare native submission resources through the existing libbpf API','arm-resource-prepare-launch')
 save('actual_source_component',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the resource-only native submission control outcomes','arm-resource-prepare-result')
 save('finished',publication=rec,**report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' existing libbpf prepare/source0 GF8+edited application component actual '+json.dumps(report.get('counts'))+'. Complete same-source baseline resources/native input and original object-default globals captured; whole-application acceptance retains separate work phase. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
