#!/bin/sh
cd /workspaces/repository || exit
make -f /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/Makefile control > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/control.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/control.exit
exit "$rc"
