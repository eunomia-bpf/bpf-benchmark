#!/bin/sh
cd /workspaces/repository || exit
taskset -c 8-11 make -f /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/Makefile build > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/build.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/build.exit
exit "$rc"
