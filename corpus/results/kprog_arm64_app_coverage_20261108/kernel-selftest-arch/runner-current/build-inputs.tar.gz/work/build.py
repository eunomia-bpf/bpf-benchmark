from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,re,shlex,subprocess,time
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;B=R/'runner/build-arm64-llvmbpf';objects=G/'objects';objects.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),canonical_binary_before=sha(B/'micro_exec'),source_pins={str(p.relative_to(G/'source')):sha(p) for p in (G/'source').rglob('*') if p.is_file()},objects=[],commands=[])
def save():(G/'build.json').write_text(json.dumps(report,indent=2)+'\n')
def run(command,label,cwd=None):
 start=time.monotonic()
 with (G/(label+'.log')).open('w') as log:p=subprocess.run([str(x) for x in command],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 return dict(command=[str(x) for x in command],returncode=p.returncode,wall_seconds=time.monotonic()-start,log=label+'.log')
def flags(name):
 values={}
 for line in (G/name).read_text().splitlines():
  if line.startswith('CXX_'):
   k,v=line.split('=',1);values[k.strip()]=shlex.split(v.strip())
 result=values['CXX_DEFINES']+values['CXX_INCLUDES']+values['CXX_FLAGS']
 # The retained CMake epoch predates the native-sim -> kprog path rename.
 return [v.replace('/native-sim/libnativeloader/','/kprog/libnativeloader/').replace('/build-bpf-kop-arm64/','/build-bpf-kinsn-arm64/').replace(str(R/'runner/include'),str(G/'source/runner/include')).replace(str(R/'kprog/libnativeloader/include'),str(G/'source/kprog/libnativeloader/include')) for v in result]
tokens=[t.replace('/build-bpf-kop-arm64/','/build-bpf-kinsn-arm64/') for t in shlex.split((G/'link.txt').read_text())];previous=json.loads((G/'retired-path-diagnostic/build.json').read_text());previous_by_source={x['source']:x for x in previous['objects']};make=(G/'build.make').read_text();tasks=[];replacements={}
for index,token in enumerate(tokens):
 if not token.endswith('.o'):continue
 original=B/token
 source=Path(re.findall(re.escape(token)+r': (/\S+\.cpp)',make)[0])
 dependency=Path(str(original)+'.d')
 deps=shlex.split(dependency.read_text().replace('\\\n',' '))[1:] if dependency.exists() else [str(source)]
 changed=source.stat().st_mtime_ns>original.stat().st_mtime_ns or any(not Path(d).exists() or Path(d).stat().st_mtime_ns>original.stat().st_mtime_ns for d in deps)
 if source.name=='native_lab_runner.cpp':changed=True
 record=dict(source=str(source),cached_object=str(original),cached_sha256=sha(original),rebuilt=changed)
 if changed:
  frozen=G/'source'/source.relative_to(R);target=objects/(str(source.relative_to(R)).replace('/','_')+'.o')
  if not frozen.exists():frozen=source
  label=target.stem
  command=['/usr/bin/aarch64-linux-gnu-g++',*flags('runner.flags.make'),'-MD','-MF',str(target)+'.d','-o',target,'-c',frozen]
  prior=previous_by_source.get(str(source),{})
  if target.exists() and prior.get('compile',{}).get('returncode')==0:
   record['compile']=prior['compile'];record['private_object_reused']=True;record['sha256']=sha(target)
  else:tasks.append((record,command,label,target))
  replacements[token]=str(target)
 else:replacements[token]=str(original)
 report['objects'].append(record)
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[(record,target,pool.submit(run,command,label)) for record,command,label,target in tasks]
 for record,target,future in futures:
  result=future.result();record['compile']=result
  if result['returncode']:save();raise RuntimeError('runner component '+record['source'])
  record['sha256']=sha(target);save()
loader_obj=objects/'native_loader.cpp.o'
result=run(['/usr/bin/aarch64-linux-gnu-g++',*flags('loader.flags.make'),'-MD','-MF',str(loader_obj)+'.d','-o',loader_obj,'-c',G/'source/kprog/libnativeloader/src/native_loader.cpp'],'native_loader')
report['commands'].append(result);save()
if result['returncode']:raise RuntimeError('native loader component')
result=run(['aarch64-linux-gnu-ar','rcs',G/'libnative_loader.a',loader_obj],'native_loader_archive');report['commands'].append(result);save()
if result['returncode']:raise RuntimeError('native loader archive')
for i,t in enumerate(tokens):
 if t in replacements:tokens[i]=replacements[t]
 elif t=='native_loader/libnative_loader.a':tokens[i]=str(G/'libnative_loader.a')
 elif t=='micro_exec' and i and tokens[i-1]=='-o':tokens[i]=str(G/'micro_exec')
result=run(tokens,'link',B);report['commands'].append(result);save()
if result['returncode']:raise RuntimeError('current ARM runner link')
result=run(['qemu-aarch64-static','-L',R/'kprog/arm64/build/app-runtime-v35/root',G/'micro_exec','list-programs','--program',R/'kprog/arm64/build/kernel-selftests-current/test_global_func2__global_func2.bpf.o'],'list_control')
report['commands'].append(result);report['canonical_binary_after']=sha(B/'micro_exec');report['binary_sha256']=sha(G/'micro_exec');report['canonical_binary_unchanged']=report['canonical_binary_before']==report['canonical_binary_after'];save()
if result['returncode']:raise RuntimeError('current ARM ELF listing control')
print(json.dumps(dict(binary_sha256=report['binary_sha256'],rebuilt=sum(r['rebuilt'] for r in report['objects']),reused=sum(not r['rebuilt'] for r in report['objects']),canonical_binary_unchanged=report['canonical_binary_unchanged'])))
