#!/bin/sh
cd /workspaces/repository || exit
make -f /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/Makefile control-drained > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/control-drained.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/control-drained.exit
exit "$rc"
