#include "micro_exec.hpp"
#include "bpf_helpers.hpp"
#include "kernel_test_run.hpp"

#include <bpf/bpf.h>
#include <bpf/btf.h>
#include <bpf/libbpf.h>
#include <linux/bpf.h>
#include <yaml-cpp/yaml.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <iostream>
#include <signal.h>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <thread>
#include <unordered_map>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using clock_type = std::chrono::steady_clock;
volatile sig_atomic_t g_measure_signal_seen = 0;
constexpr size_t kEthernetHeaderSize = 14;
constexpr const char *kVmlinuxBtfPath = "/sys/kernel/btf/vmlinux";

#ifndef BPF_PSEUDO_KINSN_CALL
#define BPF_PSEUDO_KINSN_CALL 4
#endif

#if defined(__x86_64__) || defined(__i386__)
constexpr bool kHasTscMeasurement = true;

static inline uint64_t rdtsc_start()
{
    unsigned int lo = 0;
    unsigned int hi = 0;
    asm volatile("lfence; rdtsc" : "=a"(lo), "=d"(hi));
    return (static_cast<uint64_t>(hi) << 32) | lo;
}

static inline uint64_t rdtsc_end()
{
    unsigned int lo = 0;
    unsigned int hi = 0;
    asm volatile("rdtsc; lfence" : "=a"(lo), "=d"(hi) :: "memory");
    return (static_cast<uint64_t>(hi) << 32) | lo;
}
#else
constexpr bool kHasTscMeasurement = false;

static inline uint64_t rdtsc_start()
{
    return 0;
}

static inline uint64_t rdtsc_end()
{
    return 0;
}
#endif

struct kernel_probe_context {
    int program_fd = -1;
    bpf_test_run_opts *test_opts = nullptr;
    uint32_t effective_repeat = 1;
    uint64_t tsc_freq_hz = 0;
    std::vector<uint8_t> *packet_out = nullptr;
    __sk_buff *context_out = nullptr;
    uint32_t context_out_size = 0;
    int result_fd = -1;
    uint32_t result_key = 0;
    bool reset_result_map = false;
};

struct kernel_run_measurement {
    uint64_t exec_ns = 0;
    std::optional<uint64_t> wall_exec_ns;
    std::optional<uint64_t> exec_cycles;
    uint32_t retval = 0;
    std::chrono::steady_clock::time_point wall_start {};
    std::chrono::steady_clock::time_point wall_end {};
};

struct kernel_run_pass {
    kernel_run_measurement measurement;
    perf_counter_capture perf_counters;
};

void handle_measure_signal(int)
{
    g_measure_signal_seen = 1;
}

void install_measure_signal_handler()
{
    g_measure_signal_seen = 0;
    struct sigaction action {};
    action.sa_handler = handle_measure_signal;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGUSR1, &action, nullptr) != 0) {
        fail("sigaction(SIGUSR1) failed: " + std::string(strerror(errno)));
    }
}

void wait_for_measure_signal()
{
    while (!g_measure_signal_seen) {
        pause();
    }
}

struct object_deleter {
    void operator()(bpf_object *obj) const
    {
        if (obj != nullptr) {
            bpf_object__close(obj);
        }
    }
};

using bpf_object_ptr = std::unique_ptr<bpf_object, object_deleter>;

struct fd_deleter {
    void operator()(int *fd) const
    {
        if (fd != nullptr && *fd >= 0) {
            close(*fd);
        }
        delete fd;
    }
};

using unique_fd = std::unique_ptr<int, fd_deleter>;

struct resolved_kinsn_call {
    int btf_func_id = 0;
    int fd_array_slot = 0;
};

enum class packet_context_kind {
    none,
    xdp,
    skb,
};

struct live_fixture_map {
    std::string name;
    uint32_t id = 0;
    uint32_t type = 0;
    uint32_t key_size = 0;
    uint32_t value_size = 0;
    uint32_t map_flags = 0;
    int fd = -1;
};

std::optional<uint64_t> read_nominal_tsc_freq_hz()
{
    std::ifstream cpuinfo("/proc/cpuinfo");
    if (!cpuinfo.is_open()) {
        return std::nullopt;
    }

    std::string line;
    while (std::getline(cpuinfo, line)) {
        if (!line.starts_with("model name")) {
            continue;
        }

        const auto at_pos = line.rfind('@');
        if (at_pos == std::string::npos) {
            continue;
        }

        const auto value_start = line.find_first_of("0123456789", at_pos);
        if (value_start == std::string::npos) {
            continue;
        }

        const auto value_end = line.find_first_not_of("0123456789.", value_start);
        if (value_end == std::string::npos) {
            continue;
        }

        const auto unit_start = line.find_first_not_of(" \t", value_end);
        if (unit_start == std::string::npos) {
            continue;
        }

        const auto unit_end =
            line.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", unit_start);
        const auto unit = line.substr(
            unit_start,
            unit_end == std::string::npos ? std::string::npos : unit_end - unit_start);

        long double multiplier = 0.0L;
        if (unit == "GHz") {
            multiplier = 1000000000.0L;
        } else if (unit == "MHz") {
            multiplier = 1000000.0L;
        } else if (unit == "KHz") {
            multiplier = 1000.0L;
        } else {
            continue;
        }

        try {
            const auto value = std::stold(line.substr(value_start, value_end - value_start));
            return static_cast<uint64_t>(std::llround(value * multiplier));
        } catch (const std::exception &) {
            continue;
        }
    }

    return std::nullopt;
}

uint64_t calibrate_tsc_freq_hz()
{
    constexpr auto calibration_window = std::chrono::milliseconds(20);

    const auto wall_start = clock_type::now();
    const auto tsc_start = rdtsc_start();
    std::this_thread::sleep_for(calibration_window);
    const auto tsc_end = rdtsc_end();
    const auto wall_end = clock_type::now();

    const uint64_t wall_ns = elapsed_ns(wall_start, wall_end);
    if (wall_ns == 0 || tsc_end <= tsc_start) {
        fail("unable to calibrate TSC frequency");
    }

    const long double freq_hz =
        (static_cast<long double>(tsc_end - tsc_start) * 1000000000.0L) /
        static_cast<long double>(wall_ns);
    return static_cast<uint64_t>(std::llround(freq_hz));
}

uint64_t detect_tsc_freq_hz()
{
    if constexpr (!kHasTscMeasurement) {
        fail("rdtsc timing requires x86/x86_64");
    }

    if (const auto nominal = read_nominal_tsc_freq_hz(); nominal.has_value()) {
        return *nominal;
    }
    return calibrate_tsc_freq_hz();
}

} // namespace

size_t packet_output_capacity(const cli_options &, size_t packet_size)
{
    return packet_size;
}

namespace {

void reset_kernel_probe_state(kernel_probe_context &context)
{
    if (context.test_opts == nullptr) {
        fail("internal error: missing test run options");
    }

    context.test_opts->duration = 0;
    context.test_opts->retval = 0;

    if (context.packet_out != nullptr) {
        std::fill(context.packet_out->begin(), context.packet_out->end(), 0);
        context.test_opts->data_out =
            context.packet_out->empty() ? nullptr : context.packet_out->data();
        context.test_opts->data_size_out =
            static_cast<__u32>(context.packet_out->size());
    }

    if (context.context_out != nullptr) {
        std::memset(context.context_out, 0, sizeof(*context.context_out));
        context.test_opts->ctx_out = context.context_out;
        context.test_opts->ctx_size_out = context.context_out_size;
    }

    if (context.reset_result_map) {
        uint64_t zero = 0;
        if (bpf_map_update_elem(context.result_fd, &context.result_key, &zero, BPF_ANY) != 0) {
            fail("bpf_map_update_elem(result_map) failed: " + std::string(strerror(errno)));
        }
    }
}

kernel_run_measurement execute_kernel_probe(kernel_probe_context &context)
{
    reset_kernel_probe_state(context);

    kernel_run_measurement measurement {};
    const auto wall_start = std::chrono::steady_clock::now();
    const uint64_t tsc_before = rdtsc_start();
    const int run_error = bpf_prog_test_run_opts(context.program_fd, context.test_opts);
    const uint64_t tsc_after = rdtsc_end();
    const auto wall_end = std::chrono::steady_clock::now();

    if (run_error != 0) {
        fail("bpf_prog_test_run_opts failed: " + std::string(strerror(errno)));
    }

    measurement.exec_ns = context.test_opts->duration;
    measurement.retval = context.test_opts->retval;
    measurement.wall_start = wall_start;
    measurement.wall_end = wall_end;

    if (kHasTscMeasurement && context.tsc_freq_hz > 0 && tsc_after > tsc_before) {
        const uint64_t total_cycles = tsc_after - tsc_before;
        measurement.exec_cycles = static_cast<uint64_t>(std::llround(
            static_cast<long double>(total_cycles) /
            static_cast<long double>(context.effective_repeat)));
        measurement.wall_exec_ns = static_cast<uint64_t>(std::llround(
            (static_cast<long double>(total_cycles) * 1000000000.0L) /
            (static_cast<long double>(context.tsc_freq_hz) *
             static_cast<long double>(context.effective_repeat))));
    }

    return measurement;
}

kernel_run_pass execute_kernel_measurement_pass(
    kernel_probe_context &context,
    const cli_options &options)
{
    for (uint32_t warmup_index = 0; warmup_index < options.warmup_repeat; ++warmup_index) {
        static_cast<void>(execute_kernel_probe(context));
    }

    kernel_run_pass pass;
    const perf_counter_options perf_options {
        .enabled = options.perf_counters,
        .include_kernel = true,
    };
    pass.perf_counters = measure_perf_counters(perf_options, [&]() {
        pass.measurement = execute_kernel_probe(context);
    });
    return pass;
}

bool context_mode_supports_kernel_repeat(uint32_t prog_type)
{
    switch (prog_type) {
    case BPF_PROG_TYPE_SK_LOOKUP:
    case BPF_PROG_TYPE_NETFILTER:
        return true;
    default:
        return false;
    }
}

const char *prepare_phase_name(std::string_view io_mode)
{
    if (io_mode == "packet") {
        return "packet_prepare_ns";
    }
    if (io_mode == "staged") {
        return "input_stage_ns";
    }
    if (io_mode == "context") {
        return "context_prepare_ns";
    }
    return "map_prepare_ns";
}

const char *result_phase_name(std::string_view io_mode)
{
    if (io_mode == "packet" || io_mode == "staged") {
        return "result_extract_ns";
    }
    if (io_mode == "context") {
        return "retval_read_ns";
    }
    return "result_read_ns";
}

packet_context_kind resolve_packet_context_kind(uint32_t prog_type)
{
    switch (prog_type) {
    case BPF_PROG_TYPE_XDP:
        return packet_context_kind::xdp;
    case BPF_PROG_TYPE_SCHED_CLS:
    case BPF_PROG_TYPE_SCHED_ACT:
    case BPF_PROG_TYPE_CGROUP_SKB:
        return packet_context_kind::skb;
    default:
        return packet_context_kind::none;
    }
}

std::string resolve_effective_io_mode(std::string_view requested_io_mode, bpf_object *object)
{
    if (requested_io_mode != "map") {
        return std::string(requested_io_mode);
    }

    const bool has_input_map = bpf_object__find_map_by_name(object, "input_map") != nullptr;
    const bool has_result_map = bpf_object__find_map_by_name(object, "result_map") != nullptr;
    if (has_input_map && !has_result_map) {
        fail("io-mode map requires result_map when input_map is present");
    }
    return std::string(requested_io_mode);
}

bool fixture_map_is_userspace_readonly(const live_fixture_map &map)
{
    if ((map.map_flags & BPF_F_RDONLY) != 0) {
        return true;
    }
    return map.name.rfind(".rodata", 0) == 0 ||
           map.name.rfind(".kconfig", 0) == 0 ||
           map.name.rfind(".ksyms", 0) == 0;
}

std::string require_scalar_string_field(const YAML::Node &node, std::string_view field_name)
{
    if (!node || !node.IsScalar()) {
        fail("fixture field '" + std::string(field_name) + "' must be a scalar string");
    }
    try {
        return node.as<std::string>();
    } catch (const YAML::Exception &) {
        fail("fixture field '" + std::string(field_name) + "' must be a scalar string");
    }
}

std::optional<std::string> optional_scalar_string_field(
    const YAML::Node &node,
    std::string_view field_name)
{
    if (!node) {
        return std::nullopt;
    }
    if (!node.IsScalar()) {
        fail("fixture field '" + std::string(field_name) + "' must be a scalar string");
    }
    try {
        return node.as<std::string>();
    } catch (const YAML::Exception &) {
        fail("fixture field '" + std::string(field_name) + "' must be a scalar string");
    }
}

std::optional<uint32_t> optional_u32_field(const YAML::Node &node, std::string_view field_name)
{
    if (!node) {
        return std::nullopt;
    }
    if (!node.IsScalar()) {
        fail("fixture field '" + std::string(field_name) + "' must be an integer");
    }
    try {
        return node.as<uint32_t>();
    } catch (const YAML::Exception &) {
        fail("fixture field '" + std::string(field_name) + "' must be an integer");
    }
}

int hex_nibble_value(char ch)
{
    if (ch >= '0' && ch <= '9') {
        return ch - '0';
    }
    if (ch >= 'a' && ch <= 'f') {
        return 10 + (ch - 'a');
    }
    if (ch >= 'A' && ch <= 'F') {
        return 10 + (ch - 'A');
    }
    return -1;
}

std::vector<uint8_t> decode_hex_bytes(std::string_view text, std::string_view field_name)
{
    size_t start = 0;
    size_t end = text.size();
    while (start < end && std::isspace(static_cast<unsigned char>(text[start])) != 0) {
        ++start;
    }
    while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1])) != 0) {
        --end;
    }

    std::string_view trimmed = text.substr(start, end - start);
    if (trimmed.starts_with("0x") || trimmed.starts_with("0X")) {
        trimmed.remove_prefix(2);
    }
    if (trimmed.size() % 2 != 0) {
        fail("fixture field '" + std::string(field_name) + "' must have even-length hex");
    }

    std::vector<uint8_t> bytes;
    bytes.reserve(trimmed.size() / 2);
    for (size_t index = 0; index < trimmed.size(); index += 2) {
        const int high = hex_nibble_value(trimmed[index]);
        const int low = hex_nibble_value(trimmed[index + 1]);
        if (high < 0 || low < 0) {
            fail("fixture field '" + std::string(field_name) + "' contains invalid hex");
        }
        bytes.push_back(static_cast<uint8_t>((high << 4) | low));
    }
    return bytes;
}

live_fixture_map describe_live_fixture_map(bpf_map *map)
{
    const int fd = bpf_map__fd(map);
    if (fd < 0) {
        fail("unable to obtain loaded map fd for fixture replay");
    }

    bpf_map_info info = {};
    __u32 info_len = sizeof(info);
    if (bpf_map_get_info_by_fd(fd, &info, &info_len) != 0) {
        fail("bpf_map_get_info_by_fd failed during fixture replay: " + std::string(strerror(errno)));
    }

    const char *map_name = bpf_map__name(map);
    return {
        .name = map_name != nullptr ? std::string(map_name) : std::string(),
        .id = info.id,
        .type = info.type,
        .key_size = info.key_size,
        .value_size = info.value_size,
        .map_flags = info.map_flags,
        .fd = fd,
    };
}

void load_map_fixtures(const std::filesystem::path &fixture_json_path, bpf_object *object)
{
    YAML::Node root;
    try {
        root = YAML::LoadFile(fixture_json_path.string());
    } catch (const YAML::Exception &error) {
        fail("unable to parse fixture JSON '" + fixture_json_path.string() + "': " + error.what());
    }

    const YAML::Node maps = root["maps"];
    if (!maps || !maps.IsSequence()) {
        fail("fixture JSON '" + fixture_json_path.string() + "' must contain a 'maps' sequence");
    }

    std::unordered_map<std::string, live_fixture_map> maps_by_name;
    std::unordered_map<uint32_t, live_fixture_map> maps_by_id;
    bpf_map *map = nullptr;
    while ((map = bpf_object__next_map(object, map)) != nullptr) {
        const auto live_map = describe_live_fixture_map(map);
        if (!live_map.name.empty()) {
            maps_by_name.insert_or_assign(live_map.name, live_map);
        }
        maps_by_id.insert_or_assign(live_map.id, live_map);
    }

    size_t loaded_entries = 0;
    for (const auto &map_node : maps) {
        if (!map_node.IsMap()) {
            fail("fixture JSON '" + fixture_json_path.string() + "' contains a non-object map entry");
        }

        std::optional<std::string> map_name =
            optional_scalar_string_field(map_node["map_name"], "map_name");
        if (!map_name.has_value()) {
            map_name = optional_scalar_string_field(map_node["name"], "name");
        }
        const auto map_id = optional_u32_field(map_node["map_id"], "map_id");
        if (!map_name.has_value() && !map_id.has_value()) {
            fail("fixture JSON '" + fixture_json_path.string() +
                 "' requires each map entry to specify map_name or map_id");
        }

        const live_fixture_map *live_map = nullptr;
        if (map_name.has_value()) {
            const auto found = maps_by_name.find(*map_name);
            if (found == maps_by_name.end()) {
                fail("fixture map '" + *map_name + "' not found in loaded object");
            }
            live_map = &found->second;
        } else {
            const auto found = maps_by_id.find(*map_id);
            if (found == maps_by_id.end()) {
                fail("fixture map id " + std::to_string(*map_id) + " not found in loaded object");
            }
            live_map = &found->second;
        }

        if (fixture_map_is_userspace_readonly(*live_map)) {
            fail("fixture map '" + live_map->name + "' is read-only to userspace");
        }
        if (live_map->type == BPF_MAP_TYPE_PROG_ARRAY ||
            live_map->type == BPF_MAP_TYPE_ARRAY_OF_MAPS ||
            live_map->type == BPF_MAP_TYPE_HASH_OF_MAPS) {
            fail("fixture map '" + live_map->name + "' uses unsupported reference-valued map type");
        }

        const YAML::Node entries = map_node["entries"];
        if (!entries || !entries.IsSequence()) {
            fail("fixture map '" + live_map->name + "' must contain an 'entries' sequence");
        }

        for (const auto &entry_node : entries) {
            if (!entry_node.IsMap()) {
                fail("fixture map '" + live_map->name + "' contains a non-object entry");
            }

            const auto key = decode_hex_bytes(
                require_scalar_string_field(entry_node["key_hex"], "key_hex"),
                "key_hex");
            const auto value = decode_hex_bytes(
                require_scalar_string_field(entry_node["value_hex"], "value_hex"),
                "value_hex");
            if (key.size() != live_map->key_size) {
                fail("fixture map '" + live_map->name + "' key size mismatch");
            }
            if (value.size() != live_map->value_size) {
                fail("fixture map '" + live_map->name + "' value size mismatch");
            }

            if (bpf_map_update_elem(live_map->fd, key.data(), value.data(), BPF_ANY) != 0) {
                fail("bpf_map_update_elem(" + live_map->name + ") failed: " +
                     std::string(strerror(errno)));
            }
            ++loaded_entries;
        }
    }

    std::fprintf(
        stderr,
        "loaded %zu fixture entries from %s\n",
        loaded_entries,
        fixture_json_path.c_str());
}

void maybe_load_map_fixtures(const cli_options &options, bpf_object *object)
{
    if (!options.fixture_path.has_value()) {
        return;
    }
    load_map_fixtures(*options.fixture_path, object);
}

bpf_program *find_single_program(bpf_object *object)
{
    bpf_program *program = nullptr;
    bpf_program *selected = nullptr;
    while ((program = bpf_object__next_program(object, program)) != nullptr) {
        if (selected != nullptr) {
            fail("object contains multiple BPF programs; split it before running micro_exec");
        }
        selected = program;
    }
    if (selected == nullptr) {
        fail("no program found in object");
    }
    return selected;
}

bool skb_payload_starts_after_l2(uint32_t prog_type)
{
    return prog_type == BPF_PROG_TYPE_CGROUP_SKB;
}

} // namespace

std::vector<uint8_t> build_packet_input(const std::vector<uint8_t> &input_bytes, uint32_t prog_type)
{
    const size_t prefix_offset =
        skb_payload_starts_after_l2(prog_type) ? kEthernetHeaderSize : 0;
    std::vector<uint8_t> packet(prefix_offset + input_bytes.size() + sizeof(uint64_t), 0);

    if (prefix_offset == kEthernetHeaderSize) {
        packet[12] = 0x08;
        packet[13] = 0x00;
    }

    std::copy(
        input_bytes.begin(),
        input_bytes.end(),
        packet.begin() + prefix_offset + sizeof(uint64_t));
    return packet;
}

uint64_t read_kernel_test_run_result(
    std::string_view effective_io_mode,
    bool result_from_skb_context,
    const std::vector<uint8_t> &packet_out,
    const __sk_buff &context_out,
    int result_fd,
    uint32_t key,
    uint32_t retval)
{
    if (effective_io_mode == "packet" || effective_io_mode == "staged") {
        if (result_from_skb_context) {
            return static_cast<uint64_t>(context_out.cb[0]) |
                   (static_cast<uint64_t>(context_out.cb[1]) << 32);
        }
        if (packet_out.size() < sizeof(uint64_t)) {
            fail("result buffer shorter than 8 bytes");
        }
        uint64_t result = 0;
        std::memcpy(&result, packet_out.data(), sizeof(result));
        return result;
    }

    if (effective_io_mode == "context") {
        return retval;
    }

    if (result_fd < 0) {
        fail("read_kernel_test_run_result: result_fd unavailable for io_mode "
             + std::string(effective_io_mode));
    }
    uint64_t result = 0;
    if (bpf_map_lookup_elem(result_fd, &key, &result) != 0) {
        fail("bpf_map_lookup_elem(result_map) failed: " + std::string(strerror(errno)));
    }
    return result;
}

namespace {

void maybe_write_program_dumps(const cli_options &options, int program_fd, const bpf_prog_info &program_info)
{
    if (options.dump_jit || options.dump_jit_path.has_value()) {
        const auto jited_program = load_jited_program(program_fd, program_info.jited_prog_len);
        const auto dump_path = options.dump_jit_path.value_or(
            std::filesystem::path(benchmark_name_for_program(options.program) + ".kernel.bin"));
        write_binary_file(dump_path, jited_program.data(), jited_program.size());
    }
    if (options.dump_xlated.has_value()) {
        const auto xlated_program = load_xlated_program(program_fd, program_info.xlated_prog_len);
        write_binary_file(*options.dump_xlated, xlated_program.data(), xlated_program.size());
    }
}

std::string btf_name_for_fd(int fd)
{
    bpf_btf_info info = {};
    char name[128] = {};
    info.name = reinterpret_cast<uintptr_t>(name);
    info.name_len = sizeof(name);
    uint32_t info_len = sizeof(info);
    if (bpf_obj_get_info_by_fd(fd, &info, &info_len) != 0) {
        fail("bpf_obj_get_info_by_fd(BTF) failed: " + std::string(strerror(errno)));
    }
    return name;
}

std::unordered_map<std::string, resolved_kinsn_call> resolve_kinsn_calls(
    const std::vector<kinsn_call_relocation> &calls,
    std::vector<unique_fd> &owned_btf_fds,
    std::vector<int> &fd_array)
{
    std::unordered_map<std::string, resolved_kinsn_call> resolved;
    std::vector<std::string> unresolved;
    for (const auto &call : calls) {
        if (!resolved.contains(call.name) &&
            std::find(unresolved.begin(), unresolved.end(), call.name) == unresolved.end()) {
            unresolved.push_back(call.name);
        }
    }
    if (unresolved.empty()) {
        return resolved;
    }

    btf *vmlinux = btf__parse(kVmlinuxBtfPath, nullptr);
    if (libbpf_get_error(vmlinux)) {
        fail("btf__parse vmlinux: " + std::string(strerror(static_cast<int>(-libbpf_get_error(vmlinux)))));
    }

    std::unordered_map<std::string, int> module_slots;
    uint32_t id = 0;
    while (!unresolved.empty()) {
        uint32_t next = 0;
        if (bpf_btf_get_next_id(id, &next) < 0) {
            if (errno == ENOENT) {
                break;
            }
            btf__free(vmlinux);
            fail("bpf_btf_get_next_id: " + std::string(strerror(errno)));
        }
        id = next;

        int fd = bpf_btf_get_fd_by_id(id);
        if (fd < 0) {
            continue;
        }
        const std::string module_name = btf_name_for_fd(fd);
        if (!module_name.starts_with("bpf_")) {
            close(fd);
            continue;
        }

        const std::string module_btf_path = "/sys/kernel/btf/" + module_name;
        btf *module_btf = btf__parse_split(module_btf_path.c_str(), vmlinux);
        if (libbpf_get_error(module_btf)) {
            close(fd);
            continue;
        }

        bool keep_fd = false;
        for (auto it = unresolved.begin(); it != unresolved.end();) {
            const int func_id = btf__find_by_name_kind(module_btf, it->c_str(), BTF_KIND_FUNC);
            if (func_id < 0) {
                ++it;
                continue;
            }
            auto slot_it = module_slots.find(module_name);
            if (slot_it == module_slots.end()) {
                const int slot = static_cast<int>(owned_btf_fds.size()) + 1;
                slot_it = module_slots.emplace(module_name, slot).first;
                owned_btf_fds.emplace_back(new int(fd));
                keep_fd = true;
            }
            resolved.emplace(*it, resolved_kinsn_call{
                .btf_func_id = func_id,
                .fd_array_slot = slot_it->second,
            });
            it = unresolved.erase(it);
        }

        btf__free(module_btf);
        if (!keep_fd) {
            close(fd);
        }
    }
    btf__free(vmlinux);

    if (!unresolved.empty()) {
        std::string names;
        for (const auto &name : unresolved) {
            if (!names.empty()) {
                names += ", ";
            }
            names += name;
        }
        fail("unable to resolve kinsn BTF functions: " + names);
    }

    if (!owned_btf_fds.empty()) {
        fd_array.reserve(owned_btf_fds.size() + 1);
        fd_array.push_back(*owned_btf_fds.front());
        for (const auto &fd_ptr : owned_btf_fds) {
            fd_array.push_back(*fd_ptr);
        }
    }
    return resolved;
}

int load_raw_kinsn_program(program_image &image)
{
    if (!image.maps.empty()) {
        fail("raw kinsn micro loader does not support maps");
    }
    if (image.code.empty() || image.code.size() % sizeof(bpf_insn) != 0) {
        fail("raw kinsn micro loader received invalid BPF instruction image");
    }

    auto *insns = reinterpret_cast<bpf_insn *>(image.code.data());
    const size_t insn_count = image.code.size() / sizeof(bpf_insn);
    std::vector<unique_fd> owned_btf_fds;
    std::vector<int> fd_array;
    const auto resolved = resolve_kinsn_calls(image.kinsn_calls, owned_btf_fds, fd_array);
    for (const auto &call : image.kinsn_calls) {
        if (call.insn_index >= insn_count) {
            fail("kinsn relocation points beyond program image");
        }
        auto target = resolved.find(call.name);
        if (target == resolved.end()) {
            fail("internal error: unresolved kinsn relocation " + call.name);
        }
        auto &insn = insns[call.insn_index];
        if (insn.code != (BPF_JMP | BPF_CALL) || insn.src_reg != BPF_PSEUDO_KINSN_CALL) {
            fail("kinsn relocation does not point at a kinsn call instruction");
        }
        insn.off = static_cast<int16_t>(target->second.fd_array_slot);
        insn.imm = target->second.btf_func_id;
    }

    LIBBPF_OPTS(bpf_prog_load_opts, opts,
        .expected_attach_type = static_cast<bpf_attach_type>(image.expected_attach_type),
        .fd_array = fd_array.empty() ? nullptr : fd_array.data(),
    );
    opts.fd_array_cnt = static_cast<__u32>(fd_array.size());
    int fd = bpf_prog_load(
        static_cast<bpf_prog_type>(image.prog_type),
        image.program_name.c_str(),
        image.license.c_str(),
        insns,
        insn_count,
        &opts);
    if (fd < 0) {
        std::vector<char> log_buf(4 * 1024 * 1024, '\0');
        opts.log_level = 1;
        opts.log_size = static_cast<__u32>(log_buf.size());
        opts.log_buf = log_buf.data();
        fd = bpf_prog_load(
            static_cast<bpf_prog_type>(image.prog_type),
            image.program_name.c_str(),
            image.license.c_str(),
            insns,
            insn_count,
            &opts);
    }
    if (fd < 0) {
        const char *log = opts.log_buf ? opts.log_buf : "";
        fail("bpf_prog_load(raw kinsn): " + std::string(strerror(errno)) +
             "\nverifier log:\n" + log);
    }
    return fd;
}

} // namespace

std::vector<sample_result> run_kernel(const cli_options &options)
{
    if (options.wait_signal) {
        install_measure_signal_handler();
    }

    const auto memory_prepare_start = std::chrono::steady_clock::now();
    auto input_bytes = materialize_memory(options.memory, options.input_size);
    const auto memory_prepare_end = std::chrono::steady_clock::now();
    if (options.input_size != 0 && input_bytes.size() < options.input_size) {
        input_bytes.resize(options.input_size, 0);
    }

    const auto object_open_start = std::chrono::steady_clock::now();
    program_image raw_image = load_program_image(options.program);
    const bool raw_kinsn_program = !raw_image.kinsn_calls.empty();
    bpf_object_ptr object;
    unique_fd raw_program_fd;
    int program_fd = -1;
    std::string effective_io_mode;
    clock_type::time_point object_open_end {};
    clock_type::time_point object_load_start {};
    clock_type::time_point object_load_end {};

    if (raw_kinsn_program) {
        if (options.btf_custom_path.has_value()) {
            fail("raw kinsn micro loader does not support custom BTF paths");
        }
        if (options.fixture_path.has_value()) {
            fail("raw kinsn micro loader does not support map fixtures");
        }
        object_open_end = std::chrono::steady_clock::now();
        object_load_start = std::chrono::steady_clock::now();
        raw_program_fd.reset(new int(load_raw_kinsn_program(raw_image)));
        program_fd = *raw_program_fd;
        object_load_end = std::chrono::steady_clock::now();
        effective_io_mode = options.io_mode;
    } else {
        bpf_object_open_opts open_opts = {};
        open_opts.sz = sizeof(open_opts);
        if (options.btf_custom_path.has_value()) {
            open_opts.btf_custom_path = options.btf_custom_path->c_str();
        }
        bpf_object *raw_object = bpf_object__open_file(options.program.c_str(), &open_opts);
        const int open_error = libbpf_get_error(raw_object);
        if (open_error != 0) {
            fail("bpf_object__open_file failed: " + libbpf_error_string(open_error));
        }
        object_open_end = std::chrono::steady_clock::now();

        object.reset(raw_object);
        bpf_program *prog = find_single_program(object.get());

        object_load_start = std::chrono::steady_clock::now();
        const int load_error = bpf_object__load(object.get());
        if (load_error != 0) {
            fail("bpf_object__load failed: " + libbpf_error_string(-load_error));
        }
        object_load_end = std::chrono::steady_clock::now();
        effective_io_mode = resolve_effective_io_mode(options.io_mode, object.get());

        maybe_load_map_fixtures(options, object.get());

        program_fd = bpf_program__fd(prog);
        if (program_fd < 0) {
            fail("unable to obtain program fd");
        }
    }

    const auto program_info = load_prog_info(program_fd);

    std::chrono::steady_clock::time_point exec_input_prepare_start {};
    std::chrono::steady_clock::time_point exec_input_prepare_end {};
    std::chrono::steady_clock::time_point result_read_start {};
    std::chrono::steady_clock::time_point result_read_end {};

    std::vector<uint8_t> packet;
    std::vector<uint8_t> packet_out;
    std::vector<uint8_t> context_in;
    __sk_buff context_out = {};
    int result_fd = -1;
    uint32_t key = 0;

    const auto packet_kind = resolve_packet_context_kind(program_info.type);
    const bool result_from_skb_context =
        packet_kind == packet_context_kind::skb &&
        (effective_io_mode == "packet" || effective_io_mode == "staged");

    if (effective_io_mode == "map") {
        if (raw_kinsn_program) {
            fail("raw kinsn micro loader does not support io-mode map");
        }
        bpf_map *input_map = bpf_object__find_map_by_name(object.get(), "input_map");
        bpf_map *result_map = bpf_object__find_map_by_name(object.get(), "result_map");
        if (result_map == nullptr) {
            fail("required result_map not found");
        }

        result_fd = bpf_map__fd(result_map);
        if (result_fd < 0) {
            fail("unable to obtain map fd");
        }

        uint64_t zero = 0;
        exec_input_prepare_start = std::chrono::steady_clock::now();
        if (input_map != nullptr) {
            const uint32_t input_value_size = bpf_map__value_size(input_map);
            if (input_bytes.size() < input_value_size) {
                input_bytes.resize(input_value_size, 0);
            }

            const int input_fd = bpf_map__fd(input_map);
            if (input_fd < 0) {
                fail("unable to obtain input_map fd");
            }
            if (bpf_map_update_elem(input_fd, &key, input_bytes.data(), BPF_ANY) != 0) {
                fail("bpf_map_update_elem(input_map) failed: " + std::string(strerror(errno)));
            }
            packet.assign(64, 0);
            packet_out.assign(packet_output_capacity(options, packet.size()), 0);
        } else {
            if (packet_kind == packet_context_kind::none) {
                fail("io-mode map without input_map requires an XDP or skb packet context");
            }
            packet = options.raw_packet ? input_bytes : build_packet_input(input_bytes, program_info.type);
            packet_out.assign(packet_output_capacity(options, packet.size()), 0);
        }
        if (bpf_map_update_elem(result_fd, &key, &zero, BPF_ANY) != 0) {
            fail("bpf_map_update_elem(result_map) failed: " + std::string(strerror(errno)));
        }
        exec_input_prepare_end = std::chrono::steady_clock::now();
    } else if (effective_io_mode == "staged") {
        if (packet_kind == packet_context_kind::none) {
            fail("io-mode staged requires an XDP or skb packet context");
        }
        exec_input_prepare_start = std::chrono::steady_clock::now();
        packet = options.raw_packet ? input_bytes : build_packet_input(input_bytes, program_info.type);
        packet_out.assign(packet_output_capacity(options, packet.size()), 0);
        exec_input_prepare_end = std::chrono::steady_clock::now();
    } else if (effective_io_mode == "context") {
        exec_input_prepare_start = std::chrono::steady_clock::now();
        context_in = input_bytes;
        exec_input_prepare_end = std::chrono::steady_clock::now();
    } else {
        exec_input_prepare_start = std::chrono::steady_clock::now();
        if (packet_kind == packet_context_kind::none) {
            fail("io-mode packet requires an XDP or skb packet context");
        }
        packet = options.raw_packet ? input_bytes : build_packet_input(input_bytes, program_info.type);
        packet_out.assign(packet_output_capacity(options, packet.size()), 0);
        exec_input_prepare_end = std::chrono::steady_clock::now();
    }

    bpf_test_run_opts test_opts = {};
    test_opts.sz = sizeof(test_opts);
    const bool kernel_repeat_supported =
        effective_io_mode != "context" || context_mode_supports_kernel_repeat(program_info.type);
    const uint32_t effective_repeat = kernel_repeat_supported ? options.repeat : 1u;
    test_opts.repeat = kernel_repeat_supported ? effective_repeat : 0u;
    if (!packet.empty()) {
        test_opts.data_in = packet.data();
        test_opts.data_size_in = packet.size();
        test_opts.data_out = packet_out.data();
        test_opts.data_size_out = packet_out.size();
    }
    if (!context_in.empty()) {
        test_opts.ctx_in = context_in.data();
        test_opts.ctx_size_in = context_in.size();
    }
    if (result_from_skb_context) {
        test_opts.ctx_out = &context_out;
        test_opts.ctx_size_out = sizeof(context_out);
    }

    const uint64_t tsc_freq_hz = kHasTscMeasurement ? detect_tsc_freq_hz() : 0;
    kernel_probe_context run_context = {
        .program_fd = program_fd,
        .test_opts = &test_opts,
        .effective_repeat = effective_repeat,
        .tsc_freq_hz = tsc_freq_hz,
        .packet_out = packet_out.empty() ? nullptr : &packet_out,
        .context_out = result_from_skb_context ? &context_out : nullptr,
        .context_out_size = static_cast<uint32_t>(sizeof(context_out)),
        .result_fd = result_fd,
        .result_key = key,
        .reset_result_map = effective_io_mode == "map",
    };

    if (options.wait_signal) {
        wait_for_measure_signal();
    }

    auto run_pass = execute_kernel_measurement_pass(run_context, options);
    const auto &run_measurement = run_pass.measurement;

    result_read_start = std::chrono::steady_clock::now();
    const uint64_t result = read_kernel_test_run_result(
        effective_io_mode,
        result_from_skb_context,
        packet_out,
        context_out,
        result_fd,
        key,
        run_measurement.retval);
    result_read_end = std::chrono::steady_clock::now();

    const auto final_program_info = load_prog_info(program_fd);
    maybe_write_program_dumps(options, program_fd, final_program_info);

    sample_result sample;
    sample.compile_ns =
        elapsed_ns(object_open_start, object_open_end) +
        elapsed_ns(object_load_start, object_load_end);
    sample.exec_ns = run_measurement.exec_ns;
    sample.timing_source = "ktime";
    sample.timing_source_wall =
        run_measurement.wall_exec_ns.has_value() ? "rdtsc" : "unavailable";
    sample.wall_exec_ns = run_measurement.wall_exec_ns;
    sample.exec_cycles = run_measurement.exec_cycles;
    sample.tsc_freq_hz =
        tsc_freq_hz > 0 ? std::optional<uint64_t>(tsc_freq_hz) : std::nullopt;
    sample.result = result;
    sample.retval = run_measurement.retval;
    sample.perf_counters = std::move(run_pass.perf_counters);
    sample.jited_prog_len = final_program_info.jited_prog_len;
    sample.xlated_prog_len = final_program_info.xlated_prog_len;
    sample.code_size = {
        .bpf_bytecode_bytes = final_program_info.xlated_prog_len,
        .native_code_bytes = final_program_info.jited_prog_len,
    };
    sample.phases_ns = {
        {"memory_prepare_ns", elapsed_ns(memory_prepare_start, memory_prepare_end)},
        {"object_open_ns", elapsed_ns(object_open_start, object_open_end)},
        {"object_load_ns", elapsed_ns(object_load_start, object_load_end)},
        {prepare_phase_name(effective_io_mode), elapsed_ns(exec_input_prepare_start, exec_input_prepare_end)},
        {"prog_run_wall_ns", elapsed_ns(run_measurement.wall_start, run_measurement.wall_end)},
        {result_phase_name(effective_io_mode), elapsed_ns(result_read_start, result_read_end)},
    };
    return {std::move(sample)};
}
