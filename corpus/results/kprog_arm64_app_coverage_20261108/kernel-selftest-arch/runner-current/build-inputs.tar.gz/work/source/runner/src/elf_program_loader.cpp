#include "micro_exec.hpp"
#include "bpf_helpers.hpp"

#include <bpf/libbpf.h>
#include <elf.h>
#include <fcntl.h>
#include <gelf.h>
#include <linux/bpf.h>
#include <unistd.h>

#include <cstring>
#include <memory>
#include <optional>
#include <string_view>
#include <unordered_map>
#include <unordered_set>

namespace {

constexpr uint8_t k_bpf_ld_imm64 = BPF_LD | BPF_DW | BPF_IMM;

#ifndef BPF_PSEUDO_KINSN_CALL
#define BPF_PSEUDO_KINSN_CALL 4
#endif

bool infer_program_abi_from_section(const char *section_name,
                                    enum bpf_prog_type &prog_type,
                                    enum bpf_attach_type &attach_type)
{
    if (section_name == nullptr) {
        return false;
    }

    const std::string_view section(section_name);
    if (section == "cgroup_skb/ingress") {
        prog_type = BPF_PROG_TYPE_CGROUP_SKB;
        attach_type = BPF_CGROUP_INET_INGRESS;
        return true;
    }
    if (section == "cgroup_skb/egress") {
        prog_type = BPF_PROG_TYPE_CGROUP_SKB;
        attach_type = BPF_CGROUP_INET_EGRESS;
        return true;
    }

    enum bpf_prog_type inferred_prog_type = BPF_PROG_TYPE_UNSPEC;
    enum bpf_attach_type inferred_attach_type = attach_type;
    if (libbpf_prog_type_by_name(section_name, &inferred_prog_type, &inferred_attach_type) != 0) {
        return false;
    }
    if (prog_type == BPF_PROG_TYPE_UNSPEC) {
        prog_type = inferred_prog_type;
    }
    attach_type = inferred_attach_type;
    return true;
}

struct object_deleter {
    void operator()(bpf_object *obj) const
    {
        if (obj != nullptr) {
            bpf_object__close(obj);
        }
    }
};

using bpf_object_ptr = std::unique_ptr<bpf_object, object_deleter>;

struct fd_closer {
    void operator()(int *fd) const
    {
        if (fd != nullptr && *fd >= 0) {
            close(*fd);
        }
        delete fd;
    }
};

using unique_fd = std::unique_ptr<int, fd_closer>;

struct section_slice {
    size_t section_index = 0;
    size_t input_offset_bytes = 0;
    size_t size_bytes = 0;
    size_t output_insn_offset = 0;
};

struct function_symbol {
    std::string name;
    size_t section_index = 0;
    size_t offset_bytes = 0;
    size_t size_bytes = 0;
};

struct relocation_record {
    size_t offset = 0;
    size_t sym_index = 0;
    unsigned type = 0;
};

struct symbol_table_view {
    Elf_Data *data = nullptr;
    GElf_Shdr shdr {};
};

unique_fd open_readonly(const std::filesystem::path &path)
{
    const int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) {
        fail("unable to open ELF file: " + path.string());
    }
    return unique_fd(new int(fd));
}

GElf_Shdr get_section_header_or_fail(Elf_Scn *section, const char *context)
{
    GElf_Shdr shdr {};
    if (gelf_getshdr(section, &shdr) == nullptr) {
        fail(std::string("gelf_getshdr failed while ") + context);
    }
    return shdr;
}

symbol_table_view get_symbol_table_or_fail(Elf *elf)
{
    Elf_Scn *section = nullptr;
    while ((section = elf_nextscn(elf, section)) != nullptr) {
        const auto shdr = get_section_header_or_fail(section, "walking sections for symbol table");
        if (shdr.sh_type != SHT_SYMTAB) {
            continue;
        }

        Elf_Data *data = elf_getdata(section, nullptr);
        if (data == nullptr) {
            fail("unable to read ELF symbol table data");
        }
        return {.data = data, .shdr = shdr};
    }

    fail("unable to locate ELF symbol table");
}

std::vector<function_symbol> collect_function_symbols(Elf *elf)
{
    const auto symtab = get_symbol_table_or_fail(elf);
    const size_t entry_count = symtab.shdr.sh_size / symtab.shdr.sh_entsize;

    std::vector<function_symbol> functions;
    functions.reserve(entry_count);
    for (size_t index = 0; index < entry_count; ++index) {
        GElf_Sym sym {};
        if (gelf_getsym(symtab.data, static_cast<int>(index), &sym) == nullptr) {
            fail("gelf_getsym failed while collecting function symbols");
        }
        if (ELF64_ST_TYPE(sym.st_info) != STT_FUNC || sym.st_shndx == SHN_UNDEF || sym.st_size == 0) {
            continue;
        }

        const char *name = elf_strptr(elf, symtab.shdr.sh_link, sym.st_name);
        if (name == nullptr) {
            continue;
        }

        functions.push_back(
            {
                .name = name,
                .section_index = sym.st_shndx,
                .offset_bytes = static_cast<size_t>(sym.st_value),
                .size_bytes = static_cast<size_t>(sym.st_size),
            });
    }
    return functions;
}

const function_symbol *find_function_symbol_by_name(
    const std::vector<function_symbol> &functions,
    const std::string &name)
{
    const function_symbol *found = nullptr;
    for (const auto &function : functions) {
        if (function.name != name) {
            continue;
        }
        if (found != nullptr) {
            fail("program symbol is ambiguous: " + name);
        }
        found = &function;
    }
    return found;
}

std::string select_single_program_name(const std::filesystem::path &path)
{
    bpf_object_open_opts open_opts = {};
    open_opts.sz = sizeof(open_opts);
    bpf_object *raw_object = bpf_object__open_file(path.c_str(), &open_opts);
    const int open_error = libbpf_get_error(raw_object);
    if (open_error != 0) {
        fail("bpf_object__open_file failed: " + libbpf_error_string(open_error));
    }
    bpf_object_ptr object(raw_object);

    std::optional<std::string> selected;
    bpf_program *program = nullptr;
    while ((program = bpf_object__next_program(object.get(), program)) != nullptr) {
        const char *name = bpf_program__name(program);
        if (name == nullptr || name[0] == '\0') {
            fail("BPF program has no name in object: " + path.string());
        }
        if (selected.has_value()) {
            fail("object contains multiple BPF programs; split it before running micro_exec");
        }
        selected = name;
    }
    if (!selected.has_value()) {
        fail("no program found in object: " + path.string());
    }
    return *selected;
}

std::vector<map_spec> load_map_specs(const std::filesystem::path &path)
{
    bpf_object_open_opts open_opts = {};
    open_opts.sz = sizeof(open_opts);
    bpf_object *raw_object = bpf_object__open_file(path.c_str(), &open_opts);
    const int open_error = libbpf_get_error(raw_object);
    if (open_error != 0) {
        fail("bpf_object__open_file failed while reading map metadata: " +
             libbpf_error_string(open_error));
    }
    bpf_object_ptr object(raw_object);

    std::vector<map_spec> maps;
    uint32_t next_id = 1;
    bpf_map *map = nullptr;
    while ((map = bpf_object__next_map(object.get(), map)) != nullptr) {
        const char *name = bpf_map__name(map);
        if (name == nullptr || name[0] == '\0') {
            fail("BPF map has no name in object: " + path.string());
        }
        maps.push_back({
            .id = next_id++,
            .name = name,
            .type = static_cast<uint32_t>(bpf_map__type(map)),
            .key_size = bpf_map__key_size(map),
            .value_size = bpf_map__value_size(map),
            .max_entries = bpf_map__max_entries(map),
            .internal = bpf_map__is_internal(map),
        });
    }
    return maps;
}

std::string section_name_by_index(Elf *elf, size_t shstrndx, size_t section_index)
{
    Elf_Scn *section = elf_getscn(elf, section_index);
    if (section == nullptr) {
        fail("unable to resolve ELF section while resolving section name");
    }
    const auto shdr = get_section_header_or_fail(section, "resolving section name");
    const char *name = elf_strptr(elf, shstrndx, shdr.sh_name);
    if (name == nullptr) {
        fail("unable to resolve ELF section name");
    }
    return name;
}

Elf_Scn *get_section_or_fail(Elf *elf, size_t section_index, const char *context)
{
    Elf_Scn *section = elf_getscn(elf, section_index);
    if (section == nullptr) {
        fail(std::string("unable to resolve ELF section while ") + context);
    }
    return section;
}

std::string read_string_section_or_fail(Elf *elf, size_t shstrndx, std::string_view section_name)
{
    Elf_Scn *section = nullptr;
    while ((section = elf_nextscn(elf, section)) != nullptr) {
        const auto shdr = get_section_header_or_fail(section, "searching named ELF section");
        const char *name = elf_strptr(elf, shstrndx, shdr.sh_name);
        if (name == nullptr || std::string_view(name) != section_name) {
            continue;
        }

        Elf_Data *data = elf_getdata(section, nullptr);
        if (data == nullptr || data->d_buf == nullptr) {
            fail("unable to read ELF section '" + std::string(section_name) + "'");
        }

        size_t size = data->d_size;
        const auto *bytes = static_cast<const char *>(data->d_buf);
        while (size > 0 && bytes[size - 1] == '\0') {
            --size;
        }
        return std::string(bytes, size);
    }

    fail("unable to find ELF section '" + std::string(section_name) + "'");
}

bool is_executable_section(Elf *elf, size_t section_index)
{
    if (section_index == SHN_UNDEF || section_index >= SHN_LORESERVE) {
        return false;
    }

    Elf_Scn *section = elf_getscn(elf, section_index);
    if (section == nullptr) {
        return false;
    }
    const auto shdr = get_section_header_or_fail(section, "checking section flags");
    return (shdr.sh_flags & SHF_EXECINSTR) != 0;
}

std::optional<relocation_record> read_relocation(Elf_Data *rel_data, const GElf_Shdr &shdr, size_t index)
{
    if (shdr.sh_type == SHT_REL) {
        GElf_Rel rel {};
        if (gelf_getrel(rel_data, static_cast<int>(index), &rel) == nullptr) {
            fail("gelf_getrel failed");
        }
        return relocation_record {
            .offset = static_cast<size_t>(rel.r_offset),
            .sym_index = static_cast<size_t>(GELF_R_SYM(rel.r_info)),
            .type = static_cast<unsigned>(GELF_R_TYPE(rel.r_info)),
        };
    }

    if (shdr.sh_type == SHT_RELA) {
        GElf_Rela rela {};
        if (gelf_getrela(rel_data, static_cast<int>(index), &rela) == nullptr) {
            fail("gelf_getrela failed");
        }
        return relocation_record {
            .offset = static_cast<size_t>(rela.r_offset),
            .sym_index = static_cast<size_t>(GELF_R_SYM(rela.r_info)),
            .type = static_cast<unsigned>(GELF_R_TYPE(rela.r_info)),
        };
    }

    return std::nullopt;
}

std::optional<size_t> translate_output_insn_index(
    const std::vector<section_slice> &slices,
    size_t section_index,
    size_t source_offset_bytes)
{
    for (const auto &slice : slices) {
        if (slice.section_index != section_index) {
            continue;
        }
        if (source_offset_bytes < slice.input_offset_bytes ||
            source_offset_bytes >= slice.input_offset_bytes + slice.size_bytes) {
            continue;
        }

        const size_t local_offset_bytes = source_offset_bytes - slice.input_offset_bytes;
        if (local_offset_bytes % sizeof(bpf_insn) != 0) {
            fail("relocation points to a non-instruction-aligned offset");
        }
        return slice.output_insn_offset + local_offset_bytes / sizeof(bpf_insn);
    }
    return std::nullopt;
}

uint64_t read_ldimm64_immediate(const bpf_insn *insns, size_t insn_index, size_t insn_count)
{
    if (insn_index + 1 >= insn_count) {
        fail("LDDW relocation refers to a truncated instruction pair");
    }

    return static_cast<uint64_t>(static_cast<uint32_t>(insns[insn_index].imm)) |
           (static_cast<uint64_t>(static_cast<uint32_t>(insns[insn_index + 1].imm)) << 32);
}

void write_ldimm64_immediate(bpf_insn *insns, size_t insn_index, size_t insn_count, uint64_t value)
{
    if (insn_index + 1 >= insn_count) {
        fail("LDDW relocation refers to a truncated instruction pair");
    }

    insns[insn_index].imm = static_cast<int32_t>(value & 0xffffffffu);
    insns[insn_index + 1].imm = static_cast<int32_t>(value >> 32);
}

void append_section_slice(
    Elf *elf,
    size_t section_index,
    std::vector<section_slice> &slices,
    std::vector<uint8_t> &code)
{
    for (const auto &slice : slices) {
        if (slice.section_index == section_index && slice.input_offset_bytes == 0) {
            return;
        }
    }

    Elf_Scn *section = get_section_or_fail(elf, section_index, "appending referenced code section");
    const auto shdr = get_section_header_or_fail(section, "appending referenced code section");
    Elf_Data *data = elf_getdata(section, nullptr);
    if (data == nullptr || data->d_buf == nullptr || data->d_size == 0) {
        fail("unable to read referenced code section contents");
    }
    if ((shdr.sh_flags & SHF_EXECINSTR) == 0) {
        fail("attempted to append a non-executable section as code");
    }
    if (data->d_size % sizeof(bpf_insn) != 0) {
        fail("referenced code section does not contain aligned BPF instructions");
    }

    const size_t output_insn_offset = code.size() / sizeof(bpf_insn);
    const size_t old_size = code.size();
    code.resize(old_size + data->d_size);
    std::memcpy(code.data() + old_size, data->d_buf, data->d_size);
    slices.push_back(
        {
            .section_index = section_index,
            .input_offset_bytes = 0,
            .size_bytes = data->d_size,
            .output_insn_offset = output_insn_offset,
        });
}

void append_referenced_code_sections(
    Elf *elf,
    const symbol_table_view &symtab,
    size_t source_section_index,
    std::vector<section_slice> &slices,
    std::vector<uint8_t> &code)
{
    Elf_Scn *section = nullptr;
    while ((section = elf_nextscn(elf, section)) != nullptr) {
        const auto shdr = get_section_header_or_fail(section, "walking relocation sections");
        if (shdr.sh_info != source_section_index) {
            continue;
        }
        if (shdr.sh_type != SHT_REL && shdr.sh_type != SHT_RELA) {
            continue;
        }

        Elf_Data *rel_data = elf_getdata(section, nullptr);
        if (rel_data == nullptr) {
            fail("unable to read ELF relocation data");
        }

        const size_t entry_count = shdr.sh_size / shdr.sh_entsize;
        for (size_t index = 0; index < entry_count; ++index) {
            const auto relocation = read_relocation(rel_data, shdr, index);
            if (!relocation.has_value()) {
                continue;
            }

            GElf_Sym sym {};
            if (gelf_getsym(symtab.data, static_cast<int>(relocation->sym_index), &sym) == nullptr) {
                fail("gelf_getsym failed while walking code references");
            }
            if (!is_executable_section(elf, sym.st_shndx) || sym.st_shndx == source_section_index) {
                continue;
            }

            const unsigned symbol_type = ELF64_ST_TYPE(sym.st_info);
            if (symbol_type != STT_SECTION && symbol_type != STT_FUNC) {
                continue;
            }

            append_section_slice(elf, sym.st_shndx, slices, code);
        }
    }
}

std::unordered_map<size_t, std::unordered_set<size_t>> collect_function_entries_by_section(
    const std::vector<function_symbol> &functions,
    const std::vector<section_slice> &slices)
{
    std::unordered_map<size_t, std::unordered_set<size_t>> entries;
    for (const auto &function : functions) {
        for (const auto &slice : slices) {
            if (slice.section_index != function.section_index) {
                continue;
            }
            if (function.offset_bytes < slice.input_offset_bytes ||
                function.offset_bytes >= slice.input_offset_bytes + slice.size_bytes) {
                continue;
            }

            entries[function.section_index].insert(function.offset_bytes / sizeof(bpf_insn));
            break;
        }
    }
    return entries;
}

void mark_same_section_local_calls(
    const std::vector<section_slice> &slices,
    const std::unordered_map<size_t, std::unordered_set<size_t>> &function_entries_by_section,
    std::vector<uint8_t> &code)
{
    auto *insns = reinterpret_cast<bpf_insn *>(code.data());
    const size_t insn_count = code.size() / sizeof(bpf_insn);

    for (const auto &slice : slices) {
        const auto function_iter = function_entries_by_section.find(slice.section_index);
        if (function_iter == function_entries_by_section.end() || function_iter->second.size() <= 1) {
            continue;
        }

        const size_t section_start_insn = slice.input_offset_bytes / sizeof(bpf_insn);
        const size_t section_end_insn = section_start_insn + slice.size_bytes / sizeof(bpf_insn);
        const size_t slice_insn_count = slice.size_bytes / sizeof(bpf_insn);
        for (size_t local_index = 0; local_index < slice_insn_count; ++local_index) {
            const size_t insn_index = slice.output_insn_offset + local_index;
            if (insn_index >= insn_count) {
                fail("section slice extends beyond copied code");
            }

            auto &insn = insns[insn_index];
            if (insn.code != (BPF_JMP | BPF_CALL) || insn.src_reg == BPF_PSEUDO_CALL) {
                continue;
            }

            const int64_t target_section_insn = static_cast<int64_t>(section_start_insn + local_index) + insn.imm + 1;
            if (target_section_insn < static_cast<int64_t>(section_start_insn) ||
                target_section_insn >= static_cast<int64_t>(section_end_insn)) {
                continue;
            }
            if (!function_iter->second.contains(static_cast<size_t>(target_section_insn))) {
                continue;
            }

            insn.src_reg = BPF_PSEUDO_CALL;
        }
    }
}

void patch_program_relocations(
    Elf *elf,
    const std::vector<section_slice> &slices,
    const std::unordered_map<std::string, uint32_t> &map_ids,
    const std::unordered_map<size_t, std::unordered_set<size_t>> &function_entries_by_section,
    std::vector<uint8_t> &code,
    std::vector<kinsn_call_relocation> &kinsn_calls)
{
    auto *insns = reinterpret_cast<bpf_insn *>(code.data());
    const size_t insn_count = code.size() / sizeof(bpf_insn);
    const auto symtab = get_symbol_table_or_fail(elf);

    Elf_Scn *section = nullptr;
    while ((section = elf_nextscn(elf, section)) != nullptr) {
        const auto shdr = get_section_header_or_fail(section, "walking relocation sections");
        if (shdr.sh_type != SHT_REL && shdr.sh_type != SHT_RELA) {
            continue;
        }

        Elf_Data *rel_data = elf_getdata(section, nullptr);
        if (rel_data == nullptr) {
            fail("unable to read ELF relocation data");
        }

        const size_t entry_count = shdr.sh_size / shdr.sh_entsize;
        for (size_t index = 0; index < entry_count; ++index) {
            const auto relocation = read_relocation(rel_data, shdr, index);
            if (!relocation.has_value()) {
                continue;
            }

            const auto insn_index = translate_output_insn_index(slices, shdr.sh_info, relocation->offset);
            if (!insn_index.has_value()) {
                continue;
            }
            if (*insn_index >= insn_count) {
                fail("translated relocation points beyond copied code");
            }

            GElf_Sym sym {};
            if (gelf_getsym(symtab.data, static_cast<int>(relocation->sym_index), &sym) == nullptr) {
                fail("gelf_getsym failed");
            }
            const char *symbol_name = elf_strptr(elf, symtab.shdr.sh_link, sym.st_name);

            if (relocation->type == R_BPF_64_32 &&
                insns[*insn_index].code == (BPF_JMP | BPF_CALL) &&
                sym.st_shndx == SHN_UNDEF &&
                symbol_name != nullptr &&
                std::string_view(symbol_name).starts_with("bpf_x86_")) {
                insns[*insn_index].src_reg = BPF_PSEUDO_KINSN_CALL;
                insns[*insn_index].off = 0;
                insns[*insn_index].imm = 0;
                kinsn_calls.push_back({
                    .insn_index = static_cast<uint64_t>(*insn_index),
                    .name = symbol_name,
                });
                continue;
            }

            if (symbol_name != nullptr) {
                const auto map_iter = map_ids.find(symbol_name);
                if (map_iter != map_ids.end()) {
                    insns[*insn_index].src_reg = BPF_PSEUDO_MAP_FD;
                    insns[*insn_index].imm = static_cast<int32_t>(map_iter->second);
                    if (*insn_index + 1 < insn_count) {
                        insns[*insn_index + 1].imm = 0;
                    }
                    continue;
                }
            }

            const bool executable_target = is_executable_section(elf, sym.st_shndx);
            if (relocation->type == R_BPF_64_32 &&
                insns[*insn_index].code == (BPF_JMP | BPF_CALL) &&
                executable_target) {
                const int64_t target_offset_bytes =
                    static_cast<int64_t>(sym.st_value) +
                    static_cast<int64_t>(insns[*insn_index].imm + 1) * static_cast<int64_t>(sizeof(bpf_insn));
                if (target_offset_bytes < 0) {
                    fail("local call relocation resolved to a negative target");
                }

                const auto target_index = translate_output_insn_index(
                    slices,
                    sym.st_shndx,
                    static_cast<size_t>(target_offset_bytes));
                if (!target_index.has_value()) {
                    fail("unable to resolve local call target into copied code");
                }

                insns[*insn_index].src_reg = BPF_PSEUDO_CALL;
                insns[*insn_index].imm = static_cast<int32_t>(*target_index) - static_cast<int32_t>(*insn_index + 1);
                continue;
            }

            if (relocation->type == R_BPF_64_64 &&
                executable_target &&
                insns[*insn_index].code == k_bpf_ld_imm64) {
                const uint64_t raw_target_offset = read_ldimm64_immediate(insns, *insn_index, insn_count);
                const uint64_t target_offset_bytes = static_cast<uint64_t>(sym.st_value) + raw_target_offset;
                const auto target_index = translate_output_insn_index(slices, sym.st_shndx, target_offset_bytes);
                if (!target_index.has_value()) {
                    fail("unable to resolve subprogram address relocation into copied code");
                }

                write_ldimm64_immediate(
                    insns,
                    *insn_index,
                    insn_count,
                    static_cast<uint64_t>(*target_index * sizeof(bpf_insn)));
                insns[*insn_index].src_reg = 0;
            }
        }
    }

    mark_same_section_local_calls(slices, function_entries_by_section, code);
}

} // namespace

std::vector<program_descriptor> list_programs(const std::filesystem::path &path)
{
    if (elf_version(EV_CURRENT) == EV_NONE) {
        fail("libelf initialization failed");
    }

    bpf_object_open_opts open_opts = {};
    open_opts.sz = sizeof(open_opts);
    bpf_object *raw_object = bpf_object__open_file(path.c_str(), &open_opts);
    const int open_error = libbpf_get_error(raw_object);
    if (open_error != 0) {
        fail("bpf_object__open_file failed: " + libbpf_error_string(open_error));
    }
    bpf_object_ptr object(raw_object);

    std::vector<program_descriptor> programs;
    bpf_program *program = nullptr;
    while ((program = bpf_object__next_program(object.get(), program)) != nullptr) {
        const char *program_name = bpf_program__name(program);
        const char *section_name = bpf_program__section_name(program);
        enum bpf_prog_type prog_type = bpf_program__type(program);
        enum bpf_attach_type attach_type = bpf_program__expected_attach_type(program);

        infer_program_abi_from_section(section_name, prog_type, attach_type);

        const char *prog_type_name = libbpf_bpf_prog_type_str(prog_type);
        const char *attach_type_name = libbpf_bpf_attach_type_str(attach_type);
        programs.push_back(
            {
                .name = program_name == nullptr ? "" : program_name,
                .section_name = section_name == nullptr ? "" : section_name,
                .insn_count = bpf_program__insn_cnt(program),
                .prog_type = static_cast<uint32_t>(prog_type),
                .expected_attach_type = static_cast<uint32_t>(attach_type),
                .prog_type_name = prog_type_name == nullptr ? "" : prog_type_name,
                .attach_type_name = attach_type_name == nullptr ? "" : attach_type_name,
            });
    }

    if (programs.empty()) {
        fail("no program found in object: " + path.string());
    }
    return programs;
}

program_image load_program_image(const std::filesystem::path &path)
{
    if (elf_version(EV_CURRENT) == EV_NONE) {
        fail("libelf initialization failed");
    }

    auto fd = open_readonly(path);
    Elf *elf = elf_begin(*fd, ELF_C_READ, nullptr);
    if (elf == nullptr) {
        fail("elf_begin failed for " + path.string());
    }

    size_t shstrndx = 0;
    if (elf_getshdrstrndx(elf, &shstrndx) != 0) {
        elf_end(elf);
        fail("elf_getshdrstrndx failed for " + path.string());
    }

    program_image image;
    image.license = read_string_section_or_fail(elf, shstrndx, "license");

    const std::string program_name = select_single_program_name(path);
    const auto function_symbols = collect_function_symbols(elf);
    const function_symbol *selected_symbol =
        find_function_symbol_by_name(function_symbols, program_name);
    if (selected_symbol == nullptr) {
        elf_end(elf);
        fail("unable to find selected program symbol in ELF: " + program_name);
    }
    const size_t target_section_index = selected_symbol->section_index;
    const std::string section_name = section_name_by_index(elf, shstrndx, target_section_index);

    image.program_name = selected_symbol->name;
    enum bpf_prog_type prog_type = BPF_PROG_TYPE_UNSPEC;
    enum bpf_attach_type attach_type = static_cast<enum bpf_attach_type>(0);
    if (!infer_program_abi_from_section(section_name.c_str(), prog_type, attach_type) ||
        prog_type == BPF_PROG_TYPE_UNSPEC) {
        elf_end(elf);
        fail("unable to infer BPF program type from section '" + section_name + "'");
    }
    image.prog_type = static_cast<uint32_t>(prog_type);
    image.expected_attach_type = static_cast<uint32_t>(attach_type);

    Elf_Scn *target_section = get_section_or_fail(elf, target_section_index, "copying selected program");
    Elf_Data *target_data = elf_getdata(target_section, nullptr);
    if (target_data == nullptr || target_data->d_buf == nullptr) {
        elf_end(elf);
        fail("unable to read selected program section contents");
    }
    if (selected_symbol->offset_bytes + selected_symbol->size_bytes > target_data->d_size ||
        selected_symbol->size_bytes % sizeof(bpf_insn) != 0) {
        elf_end(elf);
        fail("selected program symbol has invalid BPF instruction bounds");
    }
    image.code.resize(selected_symbol->size_bytes);
    std::memcpy(
        image.code.data(),
        static_cast<const uint8_t *>(target_data->d_buf) + selected_symbol->offset_bytes,
        image.code.size());

    image.maps = load_map_specs(path);
    std::unordered_map<std::string, uint32_t> map_ids;
    for (const auto &map : image.maps) {
        map_ids.emplace(map.name, map.id);
    }

    std::vector<section_slice> code_slices;
    code_slices.push_back(
        {
            .section_index = target_section_index,
            .input_offset_bytes = selected_symbol->offset_bytes,
            .size_bytes = image.code.size(),
            .output_insn_offset = 0,
        });

    const auto symtab = get_symbol_table_or_fail(elf);
    for (size_t index = 0; index < code_slices.size(); ++index) {
        append_referenced_code_sections(elf, symtab, code_slices[index].section_index, code_slices, image.code);
    }

    const auto function_entries_by_section = collect_function_entries_by_section(function_symbols, code_slices);
    patch_program_relocations(
        elf,
        code_slices,
        map_ids,
        function_entries_by_section,
        image.code,
        image.kinsn_calls);
    elf_end(elf);
    return image;
}
