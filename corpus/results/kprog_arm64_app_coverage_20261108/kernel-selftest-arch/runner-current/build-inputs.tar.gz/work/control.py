"""AArch64 full-system replay of the common native-only trusted service."""
from datetime import datetime, timezone
import hashlib
import fcntl
import json
import os
from pathlib import Path
import queue
import signal
import shlex
import subprocess
import sys
import tarfile
import tempfile
import threading
import traceback

ROOT = Path('/workspaces/repository')
HERE = Path(__file__).resolve().parent
LOADER = ROOT / 'kprog/arm64/build/kernel-selftest-helpers/loader'
NATIVE_LINK = ROOT / 'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link-arm64-entry-resources'


CORPUS_APPS = {
    "bcc": "bcc/set", "otelcol-ebpf-profiler": "otelcol-ebpf-profiler/profiling",
    "cilium": "cilium/agent", "tetragon": "tetragon/observer",
    "katran": "katran", "tracee": "tracee/monitor",
}


def corpus_application(live, case):
    """Run the retained two-start recipe with the requested corpus app selector."""
    import shutil
    artifact_root = "/artifacts" if case in {"tracee", "tetragon"} else "/artifacts/user/repo-artifacts/arm64"
    os.environ.update(BPFREJIT_REPO_ARTIFACT_ROOT=artifact_root, BPFREJIT_REMOTE_PYTHON_BIN="python3",
        BPFREJIT_KERNEL_MODULES_ROOT=str(ROOT / "kprog/arm64/build/design-only/modules"),
        BPFREJIT_NATIVE_LOADER_SO=str(LOADER / "libnative_loader.so"),
        BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF="1",
        BPFREJIT_SHIM_NATIVE_MANIFEST=str(live / "native-only-manifest.json"),
        BPFREJIT_KEEP_ALL_WORKDIRS="1", BPFREJIT_CORPUS_REJIT_TIMEOUT="0")
    os.environ.pop("BPFREJIT_NATIVE_LOADER_REQUIRE_PREBUILT_PROOF", None)
    launcher = Path("/qemu-run.sh").read_text()
    entry = "exec python3 -m corpus.driver"
    if launcher.count(entry) != 1:
        raise RuntimeError("retained corpus launcher has no unique driver entry")
    # APP is an existing corpus knob; retain every other saved launcher setting.
    launcher = launcher.replace(entry, "export BPFREJIT_CORPUS_APPS=" +
        shlex.quote(CORPUS_APPS[case]) + "\n" + entry)
    launch_path = live / "corpus-launch.sh"
    launch_path.write_text(launcher)
    command = ["sh", str(launch_path)]
    work = dict(command=command)
    try:
        with (live / "corpus.log").open("w") as output:
            done = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
        work["returncode"] = done.returncode
        done.check_returncode()
    finally:
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        work["corpus_metadata"] = []
        for path in sorted((ROOT / "corpus/results").glob("arm64_qemu_corpus_*/metadata.json")):
            metadata = json.loads(path.read_text())
            if metadata.get("launcher_boot_id") == boot:
                work["corpus_metadata"].append(dict(path=str(path), status=metadata["status"],
                    error_message=metadata.get("error_message")))
                shutil.copytree(path.parent, live / "corpus-results" / path.parent.name)
        requests = live / "requests/requests.jsonl"
        work["completed_requests"] = [json.loads(line) for line in requests.read_text().splitlines()] if requests.exists() else []
        (live / "work.json").write_text(json.dumps(work, indent=2) + chr(10))
    if not work["corpus_metadata"]:
        raise RuntimeError(case + " corpus produced no application metadata")
    errors = [row for row in work["corpus_metadata"] if row["status"] == "error"]
    if errors:
        raise RuntimeError(case + " corpus recorded application errors: " + json.dumps(errors))
    return dict(app=CORPUS_APPS[case], **work)


def guest(live, case="control"):
    import importlib.util
    live=Path(live)
    service_home=live/'service-state';service_home.mkdir(mode=0o700)
    os.environ['TMPDIR']=str(service_home);tempfile.tempdir=str(service_home)
    os.environ['BPFREJIT_NATIVE_LINK_BINARY']=str(NATIVE_LINK)
    spec=importlib.util.spec_from_file_location('upstream_submit',ROOT/'kprog/selftests/submit.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    original_run=module.run;original_start=module.start_service
    observations=live/'commands';observations.mkdir();sequence=0;services=[];readers=[]
    def observed_run(command,cwd=None,timeout=120):
        nonlocal sequence
        sequence+=1
        stem=observations/('%04d'%sequence)
        rc,stdout,stderr=original_run(command,cwd=cwd,timeout=timeout)
        stem.with_suffix('.stdout').write_text(stdout);stem.with_suffix('.stderr').write_text(stderr)
        stem.with_suffix('.json').write_text(json.dumps(dict(command=[str(x) for x in command],returncode=rc,timeout=timeout),indent=2)+'\n')
        return rc,stdout,stderr
    def observed_start(arch=1):
        process,second=original_start(arch)
        if process is not None:
            services.append(process)
            def drain(stream,path):
                with path.open('w') as log:
                    for line in stream:log.write(line);log.flush()
            for name,stream in [('stdout',process.stdout),('stderr',process.stderr)]:
                reader=threading.Thread(target=drain,args=(stream,live/('service.'+name)));reader.start();readers.append(reader)
        return process,second
    module.run=observed_run;module.start_service=observed_start
    result=None
    try:
        result=module.main(['submit.py','--arch','arm64','--table',str(ROOT/'kprog/arm64/build/kernel-selftests-current'),'--out',str(live/'out'),'--micro-exec',str(ROOT/'kprog/arm64/build/kernel-selftest-runner-current/micro_exec'),'--only','global_func8'])
    finally:
        for process in services:
            if process.poll() is None:process.terminate()
            process.wait()
        for reader in readers:reader.join()
        summary=dict(ok=result==0,scope='Existing complete shared ARM kernel annotation sweep',runner_returncode=result)
        if (live/'out/submissions.json').exists():
            summary['counts']=json.loads((live/'out/submissions.json').read_text())['counts']
        (live/'guest.json').write_text(json.dumps(summary,indent=2)+'\n')
    if result:raise RuntimeError('shared ARM annotation runner exit '+str(result))

def start_host_compiler(live, scope, sysroot):
    import subprocess as host_process
    import time
    sys.path.insert(0, str(ROOT / 'kprog'))
    from trusted_compile import atomic_json
    state = live / 'compiler-broker'
    log = (live / 'compiler.log').open('wb')
    process = host_process.Popen(['taskset', '-c', '8-11', sys.executable,
        str(ROOT / 'kprog/trusted_compile.py'), 'serve', '--scope', str(scope),
        '--state', str(state), '--arm64-sysroot', str(sysroot),
        '--clang', '/usr/lib/llvm-18/bin/clang'], stdin=host_process.DEVNULL,
        stdout=log, stderr=host_process.STDOUT)
    stopping = threading.Event()
    def watch():
        code = process.wait()
        if not stopping.is_set():
            atomic_json(state / 'failed.json', dict(error='trusted compiler exited', returncode=code))
    watcher = threading.Thread(target=watch)
    watcher.start()
    try:
        while not (state / 'ready.json').exists():
            if process.poll() is not None:
                raise RuntimeError('ARM host compiler startup exited ' + str(process.returncode))
            time.sleep(.05)
    except BaseException:
        watcher.join(); log.close()
        raise
    return process, stopping, watcher, log


def stop_host_compiler(live, compiler):
    process, stopping, watcher, log = compiler
    stopping.set()
    (live / 'compiler-broker/STOP').write_text('ARM cohort closed' + chr(10))
    code = process.wait()
    watcher.join(); log.close()
    (live / 'compiler-exit.json').write_text(json.dumps(dict(pid=process.pid, returncode=code)) + chr(10))
    return code


def host(case="control", results=None):
    """Mount the retained runtime read-only; use the new canonical Image/module."""
    build = ROOT / 'kprog/arm64/build/trusted-transport'
    build.mkdir(exist_ok=True)
    out = (Path(results).resolve() if results else HERE) / ('trusted-arm64-' + case + '-result' if case in CORPUS_APPS else 'trusted-arm64-service-result')
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    archive = out / ('run-' + stamp + '.tar.gz')
    summary = dict(ok=False, case=case, started=datetime.now(timezone.utc).isoformat(), archive=archive.name)
    with tempfile.TemporaryDirectory(prefix='trusted-', dir=build) as temporary:
        live = Path(temporary)
        image = ROOT / 'kprog/arm64/build/native-extent/Image'
        module = ROOT / 'kprog/arm64/build/native-extent/kinsn/bpf_arm64_native_lab.ko'
        root = ROOT / 'kprog/arm64/build/app-runtime-v35/root'
        argv = ['taskset', '-c', '8-11', 'qemu-system-aarch64', '-M', 'virt',
            '-icount', 'shift=0,align=off,sleep=off', '-cpu', 'max', '-smp', '8' if case in CORPUS_APPS else '2', '-m', '8192' if case in CORPUS_APPS else '2048', '-nographic', '-no-reboot',
            '-kernel', str(image), '-fsdev',
            'local,id=rootfs,path=' + str(root) + ',security_model=none,readonly=on',
            '-device', 'virtio-9p-device,fsdev=rootfs,mount_tag=rootfs',
            '-fsdev', 'local,id=repo,path=' + str(ROOT) + ',security_model=none',
            '-device', 'virtio-9p-device,fsdev=repo,mount_tag=repo', '-append',
            'console=ttyAMA0 root=rootfs rootfstype=9p rootflags=trans=virtio,version=9p2000.L ro init=/bin/sh loglevel=7 panic=-1 oops=panic']
        inputs = [image, module, LOADER / 'trusted-native-loader', LOADER / 'trusted-service-client',
            LOADER / 'trusted-native.o', NATIVE_LINK, ROOT / 'kprog/trusted_service.py',
            ROOT / 'kprog/trusted_loader.cpp', ROOT / 'kprog/trusted_generation.py',
            ROOT / 'kprog/arm64/trusted_specializer.py',
            ROOT / 'kprog/arm64/arm64_sim_local_bpf.h', ROOT / 'kprog/arm64/arm64_sim.h',
            ROOT / 'kprog/arm64/micro-prog/generate_micro_sim_proofs.py',
            ROOT / 'kprog/arm64/micro-prog/arm64_abi.py', ROOT / 'kprog/arm64/arm64_sim_direct.h',
            ROOT / 'kinsn/module/include/native_lab_trusted_wire.h', Path(__file__)]
        if case in CORPUS_APPS:
            manifest = ROOT / 'kprog/arm64/build/app-verified-stage' / case / 'manifest.json'
            data = json.loads(manifest.read_text())
            inputs.append(manifest)
            for row in data['objects'] + data.get('data_objects', []):
                for key in ['simulator_object', 'simulator_program']:
                    row.pop(key, None)
                native = (manifest.parent / row['native_object']).resolve()
                row['native_object'] = str(native)
                inputs.append(native)
            (live / 'native-only-manifest.json').write_text(json.dumps(data, indent=2) + chr(10))
            inputs.extend([root / 'qemu-run.sh', root / 'qemu-init',
                ROOT / 'kprog/arm64/build/design-only/libbpfrejit_shim.so', LOADER / 'libnative_loader.so',
                ROOT / 'corpus/driver.py', ROOT / 'runner/libs/app_runners' / ({'bcc':'bcc_set', 'otelcol-ebpf-profiler':'otel_profiler'}.get(case, case) + '.py')])
            if case == 'bcc':
                inputs.append(ROOT / 'runner/libs/app_runners/bcc.py')
                inputs.extend(root / 'usr/local/bin' / name for name in
                    ['capable', 'biosnoop', 'vfsstat', 'opensnoop', 'syscount', 'tcpconnect', 'tcplife', 'runqlat'])
            if case == 'katran':
                inputs.append(root / 'artifacts/user/repo-artifacts/arm64/katran/bin/katran_server_grpc')
            elif case in {'tracee', 'tetragon'}:
                inputs.extend(p for p in (root / 'artifacts' / case).rglob('*') if p.is_file())
            elif case in {'cilium', 'otelcol-ebpf-profiler'}:
                inputs.append(root / 'usr/local/bin' / ('cilium-agent' if case == 'cilium' else case))
            inputs.extend([ROOT / 'runner/libs/app_runners/native_loader_env.py',
                ROOT / 'corpus/config/macro_apps.yaml', ROOT / 'corpus/config/benchmark_config.yaml'])
            inputs.extend(sorted((ROOT / 'kprog/arm64/build/design-only/kinsn').glob('*.ko')))
            inputs.extend([ROOT / 'kprog/arm64/build/design-only/Module.symvers',
                ROOT / 'kprog/arm64/build/design-only/modules/lib/modules' / (ROOT / 'kprog/arm64/build/design-only/kernel.release').read_text().strip() / 'modules.dep'])
            inputs = list(dict.fromkeys(inputs))
        inputs.append(ROOT / 'kprog/arm64/build/kernel-selftest-runner-current/micro_exec')
        inputs.append(ROOT / 'kprog/trusted_compile.py')
        inputs.extend(p for p in (root / 'usr/include').rglob('*') if p.is_file())
        inputs.extend(sorted((ROOT / 'kprog/formal/generated').glob('*.h')))
        summary['command'] = argv
        summary['hashes_before'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
        (live / 'inputs.json').write_text(json.dumps(summary, indent=2) + chr(10))
        compiler = start_host_compiler(live, build, root)
        qemu = None
        booted = False
        try:
            qemu = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            tail = b''
            with (live / 'qemu.log').open('wb') as log:
                while True:
                    chunk = os.read(qemu.stdout.fileno(), 4096)
                    if not chunk:
                        break
                    log.write(chunk); log.flush()
                    tail = (tail + chunk)[-8192:]
                    if not booted and tail.endswith(b'# '):
                        commands = [
                            'mount -t proc proc /proc', 'mount -t sysfs sysfs /sys',
                            'mount -t tmpfs tmpfs /tmp', 'mount -t tmpfs tmpfs /run',
                            'mount -t 9p -o trans=virtio,version=9p2000.L repo /workspaces/repository',
                            'mount -t debugfs debugfs /sys/kernel/debug',
                            'insmod ' + str(module),
                            'cd ' + str(ROOT),
                        ]
                        if case in CORPUS_APPS:
                            commands.append('mount --bind ' + str(ROOT / 'kprog/arm64/build/design-only/libbpfrejit_shim.so') + ' /usr/local/lib/bpfrejit/libbpfrejit_shim.so')
                        if case in CORPUS_APPS:
                            commands.extend(['mount --bind ' + str(ROOT / 'kprog/arm64/build/design-only/kinsn') + ' /artifacts/kinsn',
                                'mount --bind ' + str(ROOT / 'kprog/arm64/build/design-only/modules/lib/modules') + ' /artifacts/lib/modules',
                                'mount --bind ' + str(ROOT / 'kprog/arm64/build/design-only/modules/lib/modules') + ' /lib/modules',
                                'mount -t bpf bpffs /sys/fs/bpf',
                                'mount -t tmpfs -o mode=1777 tmpfs /var/tmp',
                                'install -d -m1777 /dev/shm', 'mount -t tmpfs -o mode=1777 tmpfs /dev/shm',
                                'install -d -m0700 /run/runtime-home', 'cp -a /root/. /run/runtime-home/',
                                'mount --bind /run/runtime-home /root', 'ulimit -l unlimited'])
                        if case == 'cilium':
                            commands.extend(['cp -a /var/lib/cilium /run/cilium-lib',
                                'mount --bind /run/cilium-lib /var/lib/cilium'])
                        commands.extend([
                            'KPROG_TRUSTED_COMPILE_STATE=' + str(live / 'compiler-broker') + ' PATH=' + str(ROOT / 'runner/build-arm64-llvmbpf') + ':/usr/lib/llvm-18/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin PYTHONDONTWRITEBYTECODE=1 python3 ' + str(Path(__file__)) + ' guest ' + str(live) + ' ' + case])
                        qemu.stdin.write((' && '.join(commands) + '; rc=$?; echo $rc > ' + str(live / 'guest.exit') + '; echo o > /proc/sysrq-trigger' + chr(10)).encode())
                        qemu.stdin.flush(); booted = True
            summary['qemu_returncode'] = qemu.wait()
            summary['booted'] = booted
            summary['guest_exit'] = int((live / 'guest.exit').read_text()) if (live / 'guest.exit').exists() else None
            if (live / 'guest.json').exists():
                summary['guest'] = json.loads((live / 'guest.json').read_text())
            summary['hashes_after'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
            summary['hashes_unchanged'] = summary['hashes_before'] == summary['hashes_after']
            summary['ok'] = summary['qemu_returncode'] == 0 and summary['guest_exit'] == 0 and summary.get('guest', {}).get('ok', False)
        finally:
            if qemu is not None and qemu.poll() is None:
                qemu.terminate(); qemu.wait()
            summary['compiler_exit'] = stop_host_compiler(live, compiler)
            summary['ok'] = summary.get('ok', False) and summary['compiler_exit'] == 0
            summary['finished'] = datetime.now(timezone.utc).isoformat()
            with tarfile.open(archive, 'x:gz') as output:
                output.add(live, arcname='run')
            summary['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
            (out / 'summary.json').write_text(json.dumps(summary, indent=2) + chr(10))
        if not summary['ok']:
            raise RuntimeError('ARM trusted service replay failed; see ' + str(out / 'summary.json'))


if __name__ == '__main__':
    if len(sys.argv) in (2, 3, 4) and sys.argv[1] == 'host':
        case = sys.argv[2] if len(sys.argv) >= 3 else 'control'
        if case not in {'control', 'xdp-control', 'tc-control', *CORPUS_APPS}:
            raise SystemExit('unknown case')
        host(case, sys.argv[3] if len(sys.argv) == 4 else None)
    elif len(sys.argv) in (3, 4) and sys.argv[1] == 'guest':
        guest(sys.argv[2], sys.argv[3] if len(sys.argv) == 4 else 'control')
    else:
        raise SystemExit('usage: trusted_service_arm64.py host [control|APP] [RESULTS] | guest LIVE [control|APP]')
