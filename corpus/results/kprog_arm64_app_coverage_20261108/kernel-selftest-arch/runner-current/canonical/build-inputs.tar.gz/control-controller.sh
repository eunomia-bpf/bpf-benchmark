#!/bin/sh
cd /workspaces/repository || exit
unshare --mount --propagation private python3 /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/canonical/control-mount.py > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/canonical/control-driver.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/runner-current/canonical/control.exit
exit "$rc"
