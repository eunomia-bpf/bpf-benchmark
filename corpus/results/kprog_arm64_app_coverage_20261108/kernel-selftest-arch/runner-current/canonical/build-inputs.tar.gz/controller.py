from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');G=Path(__file__).resolve().parent;B=R/'runner/build-arm64-llvmbpf'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(utc=now(),phase='refreshing',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),binary_before=sha(B/'micro_exec'),commands=[])
def save():(G/'status.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 save()
 with tarfile.open(G/'retired-canonical.tar.gz','w:gz') as tf:
  for p in [B/'micro_exec',B/'CMakeCache.txt',B/'CMakeFiles/micro_exec.dir/flags.make',B/'CMakeFiles/micro_exec.dir/link.txt']:tf.add(p,arcname=str(p.relative_to(B)))
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PKG_CONFIG_LIBDIR=str(R/'.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/pkgconfig')+':'+str(R/'.cache/aarch64-sysroot/usr/lib/pkgconfig')+':'+str(R/'.cache/aarch64-sysroot/usr/share/pkgconfig'))
 for target in ['refresh','list']:
  with (G/(target+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','12-15','make','-f',str(G/'Makefile'),target],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['commands'].append(dict(target=target,returncode=p.returncode));save();p.check_returncode()
 report.update(phase='finished',finished=now(),binary_after=sha(B/'micro_exec'),binary_size=(B/'micro_exec').stat().st_size)
 save()
except BaseException as e:
 report.update(phase='requires_continuation',error=str(e),traceback=traceback.format_exc());save();raise
