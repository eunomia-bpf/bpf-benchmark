from pathlib import Path
import os,subprocess
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((G/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
subprocess.run(['mount','--bind',str(G/'submit.py'),str(R/'kprog/selftests/submit.py')],check=True)
os.execvp('make',['make','-f',str(G/'Makefile'),'sweep'])
