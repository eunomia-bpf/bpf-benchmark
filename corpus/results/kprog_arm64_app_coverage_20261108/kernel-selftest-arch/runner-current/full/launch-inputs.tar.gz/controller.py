from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,tarfile,traceback,gzip
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/runner-current/full';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR R/C/V '+now()+': '+s+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in {'controller.log','status.json'}:tf.add(p,arcname=str(p.relative_to(G)))
 (O/'README.md').write_text('ARM kernel BPF selftest annotation replay\n\nThis full-system2GiB/two-vCPU QEMU invocation consumes the complete a13a486b5 ARM catalog and current shared submit.py --arch arm64 runner. Refreshed native-only micro_exec486b6037, paired native-extent88a Image/module, generic tag source5379bb7ca and completed service-archive lifecycle d2537bcf1 have explicit launch identities. Existing companion-object admission, type selection and timeout behavior retain their current definitions. Each program keeps its raw outcome, and the service archives retain generated B and stock-verifier diagnostics. Annotation agreement covers the actual reached programs; other rows retain their existing stage reason. R owns interpretation and the shared runner evolution. The logging wrapper preserves complete command streams and drains the service after its existing ready event. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run the full ARM annotation catalog with the current native-only runner','arm-kernel-annotation-current-launch')
 save('actual_shared_sweep',publication=rec);notice('PUSHED '+rec['commit']+' priority2a full380 ARM annotation successor START, runner486b6037/paireddynamicextent88a/closed-receipt d2537bcf1,2GiB/two-vCPU8-11; existing captured cohorts retained. R owns annotation interpretation; exact raw outcomes go to kernel-selftest-arch/runner-current/full. Existing companion/type/timeout semantics retained, full command/service logs captured. Runtime admission additions0.')
 with (G/'driver.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (O/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0));paths=[O/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 q=O/'trusted-arm64-service-result'
 if (q/'summary.json').exists():
  d=json.loads((q/'summary.json').read_text());archive=q/d['archive'];paths.extend([q/'summary.json',archive]);report['runtime']=dict(ok=d['ok'],guest=d.get('guest'),guest_exit=d.get('guest_exit'),compiler_exit=d.get('compiler_exit'),qemu_exit=d.get('qemu_returncode'))
  with tarfile.open(archive) as tf:
   for n in ['run/out/submissions.json']:
    try:payload=tf.extractfile(n).read()
    except KeyError:continue
    target=O/Path(n).name;target.write_bytes(payload);paths.append(target);report['counts']=json.loads(payload)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect full ARM native-only annotation replay outcomes','arm-kernel-annotation-current-result')
 save('finished',make_exit=p.returncode,publication=rec,counts=report.get('counts'));notice('PUSHED '+rec['commit']+' actual whole ARM shared annotation sweep closed, Makeexit'+str(p.returncode)+'; raw counts '+json.dumps(report.get('counts'))+'. Full client/service/native/compiler/verifier archives retained for R/C/A triage.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
