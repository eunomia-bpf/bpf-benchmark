from pathlib import Path
import os,subprocess,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'source').rglob('*')):
 if p.name=='native-link' and sys.argv[1]=='build':continue
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(F/'source'))],check=True)
os.execv(sys.executable,[sys.executable,str(F/'action.py'),sys.argv[1]])
