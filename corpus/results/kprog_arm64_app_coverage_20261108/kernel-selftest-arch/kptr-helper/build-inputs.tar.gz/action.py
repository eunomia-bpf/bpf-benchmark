from pathlib import Path
import json,os,subprocess,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
if sys.argv[1]=='build':
 commands=[
 ['python3','kprog/formal/tools/generate_arm64_helper_idents_spec.py','--check'],
 ['cc','-Wall','-Wextra','-O2','-Ikprog/formal','kprog/formal/oracles/test_arm64_helper_idents_host.c','-o',str(F/'helper-host')],
 [str(F/'helper-host')],
 ['taskset','-c','12-15','cargo','build','--release','--target','aarch64-unknown-linux-gnu','--manifest-path',str(R/'kprog/x86/native_lab/native_link/Cargo.toml'),'--target-dir',str(R/'kprog/arm64/build/app-native-link')],
 ['taskset','-c','12-15','lake','build','KProgFormal.Arm64HelperIdents']]
 rows=[]
 for c in commands:
  cwd=R/'kprog/formal' if 'lake' in c else R
  p=subprocess.run(c,cwd=cwd,env=os.environ|{'CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER':'aarch64-linux-gnu-gcc'})
  rows.append(dict(command=c,cwd=str(cwd),returncode=p.returncode))
  (F/'build-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
  if p.returncode:raise SystemExit(p.returncode)
else:
 import importlib.util
 s=importlib.util.spec_from_file_location('transport',F/'transport.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 target=R/'kprog/arm64/build/kernel-selftest-runner-current/bpf34-full.py'
 subprocess.run(['mount','--bind',str(F/'transport.py'),str(target)],check=True)
 m.__file__=str(target)
 m.host('control',str(R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/kptr-helper'))
