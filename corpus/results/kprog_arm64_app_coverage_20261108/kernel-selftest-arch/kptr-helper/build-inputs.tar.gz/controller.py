from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/kptr-helper';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(t):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+t+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('existing_helper_contract_and_incremental_linker')
 with (F/'build.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(F/'mount.py'),'build'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('helper existing build/oracle exit '+str(p.returncode))
 linker=R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link'
 shutil.copy2(linker,F/'source'/linker.relative_to(R))
 report=dict(utc=now(),build_commands=json.loads((F/'build-commands.json').read_text()),linker_sha256=hashlib.sha256(linker.read_bytes()).hexdigest(),scope='Generic helper194 operation and identity coverage; current pointer-result/clobber model; stock verifier owns kptr argument/ownership decisions',runtime_admission_additions=0)
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'build-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('ARM kptr exchange helper coverage\n\nThe direct ARM kernel catalog reaches finite helper194 calls and records their missing helper handler as generation coverage. The simulator now invokes the real bpf_kptr_xchg with both original pointer arguments, retains the returned verifier pointer through the existing pointer-result mechanism and applies existing AAPCS helper clobbers. Shared native-link resolves194 to its exact kernel helper name. The existing generated/independent ARM identity enumerations carry83helpers and their original host/Lean oracles.\n\nbuild.json and build-inputs.tar.gz retain actual existing generator/host/Lean commands, the warm incremental ARM linker rebuild, original source and resulting bytes. The original map_kptr_fail catalog component runs load-only after the current34 ISA replay completes; the full380 direct catalog keeps its earlier captured source. Each component row keeps installed, verifier, generation, compiler and resource stages. Runtime admission additions:0.\n')
 owned=json.loads((F/'owned-paths.json').read_text())
 rec=pub.publish(owned+[str((O/n).relative_to(R)) for n in ['build.json','build-inputs.tar.gz','README.md']],'Model the real ARM kptr exchange helper and synchronize its identity contract','arm-kptr-helper-source')
 notice('PUSHED '+rec['commit']+' helper194 ARM operation+shared native-link exact identity; existing83row host/generator/Lean checks and warm ARM linker build actual0. Both pointer arguments and verifier return pointer use existing helper model. Original map_kptr_fail component queued after current34ISA, all negative load-only. Added runtime predicate/gate/limit0.')
 save('queued_after_isa',publication=rec)
 pid=int((A/'bpf34/isa-current/controller.pid').read_text())
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('actual_kptr_catalog_component',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py'),'replay'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode)
 paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the ARM kptr helper catalog component service stages','arm-kptr-helper-result')
 save('finished',publication=rec,**report);notice('PUSHED '+rec['commit']+' original map_kptr_fail direct component terminal '+json.dumps(report.get('counts'))+'. All actual P/B/maps/BTF/verifier rows retained. Added admission0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
