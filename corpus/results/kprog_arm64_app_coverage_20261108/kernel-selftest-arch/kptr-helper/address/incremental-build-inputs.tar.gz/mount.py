from pathlib import Path
import os,subprocess
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(F/'source'))],check=True)
os.execvp('cmake',['cmake','--build',str(R/'runner/build-arm64-llvmbpf'),'--target','micro_exec','native_loader_shared','trusted-native-loader','trusted-service-client','--parallel','2'])
