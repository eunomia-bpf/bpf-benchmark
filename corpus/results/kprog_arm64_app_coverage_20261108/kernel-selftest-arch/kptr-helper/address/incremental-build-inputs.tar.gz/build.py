from pathlib import Path
import datetime,json,os,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R)
(F/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='build_finished',returncode=p.returncode),indent=2)+'\n')
