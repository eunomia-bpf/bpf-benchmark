from pathlib import Path
import datetime,hashlib,io,json,os,shlex,subprocess,tarfile,traceback
R=Path('/workspaces/repository');G=Path(__file__).resolve().parent;A=G.parents[1];LINK=R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link'
P=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/runner-current/full';Q=P/'trusted-arm64-service-result'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(utc=now(),phase='incremental_build',binary_before=sha(LINK),source_sha256={str(p.relative_to(G/'source')):sha(p) for p in (G/'source').rglob('*') if p.is_file()},commands=[])
def save():(G/'refresh-status.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 save()
 with (G/'refresh.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'})
 report['build_exit']=p.returncode;save();p.check_returncode();report['binary_after']=sha(LINK);report['phase']='captured_kernel_link_replay';save()
 summary=json.loads((Q/'summary.json').read_text());join=json.loads((P/'native-stage-join.json').read_text())
 with tarfile.open(Q/summary['archive']) as tf:
  for row in join['requests']:
   if row['stage']!='native_load_rejected':continue
   payload=tf.extractfile(row['request_archive']).read();entry=row['entry'];F=G/'requests'/entry;F.mkdir(parents=True,exist_ok=True);(F/'request.tar.gz').write_bytes(payload)
   with tarfile.open(fileobj=io.BytesIO(payload)) as rt:
    rt.extractall(F,filter='data')
   stderr=(F/'request/load.stderr').read_text();args=shlex.split(stderr.split('\ncommand: ',1)[1].strip())
   old=next(x for x in args if x.endswith('.proof.o')).split('/generated/')[0]
   for p in (F/'request').rglob('*.json'):
    p.write_text(p.read_text().replace(old,str(F/'request')))
   args=[x.replace(old,str(F/'request')) for x in args];args[0]=str(LINK)
   command=['qemu-aarch64-static','-L',str(R/'kprog/arm64/build/app-runtime-v35/root'),*args]
   with (F/'current.stdout').open('w') as so,(F/'current.stderr').open('w') as se:p=subprocess.run(command,cwd=R,stdout=so,stderr=se)
   report['commands'].append(dict(entry=entry,command=command,returncode=p.returncode,original_native_sha256=row['native_sha256'],original_error=stderr.split('\ncommand: ',1)[0]));save()
 report.update(phase='finished',finished=now());save()
except BaseException as e:
 report.update(phase='requires_continuation',error=str(e),traceback=traceback.format_exc());save();raise
