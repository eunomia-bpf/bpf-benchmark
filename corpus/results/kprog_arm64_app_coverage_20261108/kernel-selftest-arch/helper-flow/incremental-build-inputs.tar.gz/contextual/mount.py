from pathlib import Path
import os,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
subprocess.run(['mount','--bind',str(R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link'),str(R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link-arm64-entry-resources')],check=True)
subprocess.run(['mount','--bind',str(R/'runner/build-arm64-llvmbpf/native_loader/trusted-native-loader'),str(R/'kprog/arm64/build/kernel-selftest-helpers/loader/trusted-native-loader')],check=True)
os.execvp('make',['make','-f',str(F/'Makefile'),'replay'])
