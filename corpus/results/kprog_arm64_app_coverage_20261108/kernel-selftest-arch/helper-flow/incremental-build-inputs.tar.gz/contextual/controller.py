from pathlib import Path
import datetime,hashlib,json,os,subprocess,traceback
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
report=dict(utc=now(),phase='paired_incremental_build',commands=[])
def save():(F/'status.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 save()
 for label,command in [('build',['taskset','-c','12-15','make','-f',str(F/'Makefile'),'build']),('replay',['unshare','--mount','--propagation','private','python3',str(F/'mount.py')])]:
  with (F/(label+'.log')).open('w') as log:p=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'})
  report['commands'].append(dict(label=label,returncode=p.returncode));save();p.check_returncode()
 report.update(phase='finished',finished=now());save()
except BaseException as e:
 report.update(phase='requires_continuation',error=str(e),traceback=traceback.format_exc());save();raise
