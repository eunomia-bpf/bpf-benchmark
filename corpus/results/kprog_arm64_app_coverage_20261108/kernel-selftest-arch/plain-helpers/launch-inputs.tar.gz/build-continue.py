from pathlib import Path
import datetime,json,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
rows=json.loads((F/'build-commands.json').read_text());(F/'build-commands.initial.json').write_text(json.dumps(rows,indent=2)+'\n')
cmd=['cmake','--build','runner/build-arm64-llvmbpf','--target','micro_exec','native_loader_shared','trusted-native-loader','trusted-service-client','--parallel','2']
with (F/'command-8.stdout').open('w') as o,(F/'command-8.stderr').open('w') as e:p=subprocess.run(cmd,cwd=R,stdout=o,stderr=e)
rows.append(dict(command=cmd,cwd=str(R),returncode=p.returncode));(F/'build-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
(F/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='build_finished',returncode=p.returncode,commands=len(rows)),indent=2)+'\n')
