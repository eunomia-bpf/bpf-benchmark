from pathlib import Path
import os,subprocess,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'source').rglob('*')):
 if not p.is_file():continue
 if p.name in ['native-link','libnative_loader.so','trusted-native-loader','trusted-service-client']:continue
 subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(F/'source'))],check=True)
os.execv(sys.executable,[sys.executable,str(F/'build.py')])
