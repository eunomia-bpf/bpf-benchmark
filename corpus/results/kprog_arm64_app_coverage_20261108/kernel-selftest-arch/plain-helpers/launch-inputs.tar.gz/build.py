from pathlib import Path
import datetime,json,os,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
commands=[
 [ 'python3','kprog/formal/tools/generate_arm64_helper_idents_spec.py','--check'],
 ['cc','-Wall','-Wextra','-O2','-Ikprog/formal','kprog/formal/oracles/test_arm64_helper_idents_host.c','-o',str(F/'identity-host')],
 [str(F/'identity-host')],
 ['cc','-include','kprog/formal/oracles/arm64_entry_environment_host.h','-DKPROG_TEST_EXCLUSIVE_FAILURE=0','-include','kprog/formal/oracles/arm64_exclusive_choice_host.h','-Wall','-Wextra','-O2','-Ikprog/formal','-Ikprog/arm64','-Ikprog','-Ivendor/libbpf/src','kprog/formal/oracles/test_arm64_helper_call_host.c','-o',str(F/'helper-abi-host')],
 [str(F/'helper-abi-host')],
 ['lake','build','KProgFormal.Arm64HelperIdents'],
 ['cargo','build','--release','--target','aarch64-unknown-linux-gnu','--manifest-path',str(R/'kprog/x86/native_lab/native_link/Cargo.toml'),'--target-dir',str(R/'kprog/arm64/build/app-native-link')],
 ['cmake','--build','runner/build-arm64-llvmbpf','--target','micro_exec','native_loader_dso','trusted-native-loader','trusted-service-client','-j2']]
rows=[]
for cmd in commands:
 cwd=R/'kprog/formal' if cmd[0]=='lake' else R
 with (F/('command-'+str(len(rows))+'.stdout')).open('w') as o,(F/('command-'+str(len(rows))+'.stderr')).open('w') as e:p=subprocess.run(cmd,cwd=cwd,env=os.environ|{'CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER':'aarch64-linux-gnu-gcc'},stdout=o,stderr=e)
 rows.append(dict(command=cmd,cwd=str(cwd),returncode=p.returncode));(F/'build-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 if p.returncode:break
(F/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='build_finished',returncode=p.returncode,commands=len(rows)),indent=2)+'\n')
