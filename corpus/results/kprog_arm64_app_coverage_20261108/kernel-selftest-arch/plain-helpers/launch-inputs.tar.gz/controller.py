from pathlib import Path
import datetime,gzip,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/plain-helpers'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),source_publication='8eac3b42a58105c432057f6bd851d482c13d15fd',catalog=json.loads((F/'catalog/programs.json').read_text())['counts'],scope='Original full source family; source0/maps/BTF/bpf_testmod/loadonly; CPUs12-15/2GiB',runtime_admission_additions=0),indent=2)+'\n')
 rec=pub.publish(['kprog/arm64/README.md']+[str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz']],'Replay the original ARM kptr family with plain helper coverage','arm-plain-helper-launch')
 save('actual_original_family',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect original ARM kptr family outcomes with plain helpers','arm-plain-helper-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' original full kptr family under88helper model, actual '+json.dumps(report.get('counts'))+'. Original native/annotations/maps/BTF/module retained; all source0/loadonly stages retained. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
