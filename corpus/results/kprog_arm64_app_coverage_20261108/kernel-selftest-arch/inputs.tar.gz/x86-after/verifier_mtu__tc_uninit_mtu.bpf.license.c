__attribute__((section("license"), used))
char __only_license[] = "GPL";
#include "/workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/x86-after/verifier_mtu__tc_uninit_mtu.c"
