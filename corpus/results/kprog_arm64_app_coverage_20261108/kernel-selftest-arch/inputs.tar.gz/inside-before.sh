set -e
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/selftests.py.before /workspaces/repository/kprog/selftests/selftests.py
cd /workspaces/repository
exec python3 kprog/selftests/selftests.py --only verifier_mtu --out /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/x86-before
