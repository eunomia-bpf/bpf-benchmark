__attribute__((section("license"), used))
char __only_license[] = "GPL";
#include "/workspaces/.agent-state/kprog-lanes/A/kernel-selftest-arch/arm-verifier_const/verifier_const__bprm.c"
