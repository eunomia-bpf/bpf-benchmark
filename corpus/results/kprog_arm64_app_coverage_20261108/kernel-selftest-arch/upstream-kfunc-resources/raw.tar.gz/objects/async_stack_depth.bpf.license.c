__attribute__((section("license"), used))
char __only_license[] = "GPL";
#include "/workspaces/repository/vendor/linux-framework/tools/testing/selftests/bpf/progs/async_stack_depth.c"
