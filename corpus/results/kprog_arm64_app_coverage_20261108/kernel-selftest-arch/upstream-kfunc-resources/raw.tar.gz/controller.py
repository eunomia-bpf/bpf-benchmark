from pathlib import Path
import datetime,hashlib,importlib.util,json,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/upstream-kfunc-resources';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,phase=phase,utc=now()),indent=2)+'\n')
try:
 save('original_resource_compile')
 src=F/'source';src.mkdir(exist_ok=True);shutil.copy2(R/'kprog/selftests/selftests.py',src/'selftests.py')
 s=importlib.util.spec_from_file_location('m',src/'selftests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.ROOT=R;m.DEFAULT_PROGS=R/'vendor/linux-framework/tools/testing/selftests/bpf/progs'
 progs=m.DEFAULT_PROGS;bpf=progs.parent
 old=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full-whole-resources/compile.json').read_text())
 out=F/'objects';out.mkdir(exist_ok=True)
 shutil.copytree(A/'bpf34/full-whole-resources/catalog/include',out/'include')
 inc=[bpf,progs,out/'include',bpf/'tools/include',bpf/'tools/include/uapi',R/'vendor/libbpf/include/uapi',R/'vendor/libbpf/src',Path('/usr/aarch64-linux-gnu/include')]
 rows=[]
 for row in old['resources']:
  source=Path(row['source']);obj=out/(source.stem+'.bpf.o');ok,err=m.compile_bpf(source,obj,inc,'/usr/lib/llvm-18/bin/clang','arm64')
  (out/(source.stem+'.stderr')).write_text(err)
  rows.append(dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),object=str(obj.relative_to(F)),previous_ok=row['ok'],ok=ok,stderr=source.stem+'.stderr',object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest() if ok else None))
 report=dict(utc=now(),arch='arm64',upstream_wrapper_commit='60e37d8940565a990700ded37cc61aae1d3a624c',resource_sources=len(rows),compiled=sum(r['ok'] for r in rows),previous_compiled=old['resource_compiled'],resources=rows,compiler_source_sha256=hashlib.sha256((src/'selftests.py').read_bytes()).hexdigest(),scope='Original complete ARM resource sources; native P and published kernel annotations retain bytes',runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['status.json','controller.log','controller.pid']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Original ARM resource objects with upstream kfunc declarations\n\nThe common resource compiler60e37d894 preserves each original source type/header order and supplies upstream bpf_kfuncs declarations immediately after real helper declarations. All59 original ARM resource sources are compiled through that common path using the retained paired ARM vmlinux/header input and clang18. Original selftest sources, annotations and native P bytes retain their published identities. summary.json records actual compilation outcomes against the previous55/59 source epoch; raw.tar.gz contains compiler inputs, every original diagnostic and generated resource object. Complete-catalog runtime adoption follows the current immutable original-resource guest. Runtime admission additions0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','summary.json','raw.tar.gz']],'Compile ARM original resource objects with upstream kfunc declarations','arm-upstream-kfunc-resources')
 save('finished',publication=rec,compiled=report['compiled'],resource_sources=len(rows))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' original ARM resource compile through common60e37 upstream kfunc wrapper: '+str(report['compiled'])+'/'+str(len(rows))+' from prior55/59. Every original source/native/annotation retained; actual errors archived. Current immutable full guest stayscaptured. Runtime admission additions0.\n')
 print(json.dumps(dict(compiled=report['compiled'],resource_sources=len(rows),failed=[r['source'] for r in rows if not r['ok']],publication=rec['commit'])))
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
