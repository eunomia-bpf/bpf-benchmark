#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <linux/btf.h>
#include <bpf/btf.h>
#include <bpf/libbpf.h>
static void output(void *ctx, const char *fmt, va_list ap) { vfprintf(stdout, fmt, ap); }
static const struct btf_type *unqualified(const struct btf *b, unsigned id) {
 const struct btf_type *t=btf__type_by_id(b,id);
 while (t && (btf_is_typedef(t)||btf_is_const(t)||btf_is_volatile(t)||btf_is_restrict(t)))t=btf__type_by_id(b,t->type);
 return t;
}
int main(int argc,char **argv) {
 struct btf *b=btf__parse(argv[1],NULL);
 if(libbpf_get_error(b))return 1;
 struct btf_dump *d=btf_dump__new(b,output,NULL,NULL);
 if(libbpf_get_error(d))return 2;
 for(int i=2;i<argc;i++) {
  int id=btf__find_by_name_kind(b,argv[i],BTF_KIND_FUNC);
  if(id<0)return 3;
  const struct btf_type *fn=btf__type_by_id(b,id);
  struct btf_type *p=(struct btf_type *)btf__type_by_id(b,fn->type);
  unsigned original=p->info;
  if(btf_vlen(p)) {
   const struct btf_param *args=btf_params(p);
   const struct btf_type *last=unqualified(b,args[btf_vlen(p)-1].type);
   if(last && btf_is_ptr(last)) {
    const struct btf_type *target=unqualified(b,last->type);
    if(target && btf_is_struct(target) && !strcmp(btf__name_by_offset(b,target->name_off),"bpf_prog_aux"))
     p->info=(p->info&~0xffffU)|(btf_vlen(p)-1);
   }
  }
  struct btf_dump_emit_type_decl_opts opts={.sz=sizeof(opts),.field_name=argv[i]};
  struct btf_param *params=(struct btf_param *)btf_params(p);
  unsigned saved_types[btf_vlen(p)];
  for(unsigned a=0;a<btf_vlen(p);a++) {
   saved_types[a]=params[a].type;
   const struct btf_type *type=btf__type_by_id(b,params[a].type);
   while(btf_is_typedef(type)) {params[a].type=type->type;type=btf__type_by_id(b,type->type);}
  }
  printf("extern ");
  int rc=btf_dump__emit_type_decl(d,fn->type,&opts);
  printf(" __weak __ksym;\n");
  for(unsigned a=0;a<btf_vlen(p);a++)params[a].type=saved_types[a];
  p->info=original;
  if(rc)return 4;
 }
 btf_dump__free(d);btf__free(b);return 0;
}
