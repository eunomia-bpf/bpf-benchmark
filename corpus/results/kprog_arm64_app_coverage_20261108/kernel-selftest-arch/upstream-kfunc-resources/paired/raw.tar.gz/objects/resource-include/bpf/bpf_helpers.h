#include_next <bpf/bpf_helpers.h>
#include <stdbool.h>
#include "/workspaces/repository/vendor/linux-framework/tools/testing/selftests/bpf/bpf_kfuncs.h"
#include "/workspaces/.agent-state/kprog-lanes/A/bpf34/kfunc-resources/paired/kfunc-declarations.h"
