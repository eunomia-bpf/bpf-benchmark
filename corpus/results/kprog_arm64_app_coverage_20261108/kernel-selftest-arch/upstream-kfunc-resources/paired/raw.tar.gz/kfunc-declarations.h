struct bpf_res_spin_lock;
struct bpf_wq;
struct task_struct;
struct bpf_task_work;
struct bpf_map;
extern int bpf_res_spin_lock_irqsave(struct bpf_res_spin_lock *lock, long unsigned int *flags__irq_flag) __weak __ksym;
extern void bpf_res_spin_unlock_irqrestore(struct bpf_res_spin_lock *lock, long unsigned int *flags__irq_flag) __weak __ksym;
extern int bpf_wq_set_callback(struct bpf_wq *wq, int (*callback_fn)(void *, int *, void *), unsigned int flags) __weak __ksym;
extern int bpf_task_work_schedule_resume(struct task_struct *task, struct bpf_task_work *tw, void *map__map, int (*callback)(struct bpf_map *, void *, void *)) __weak __ksym;
