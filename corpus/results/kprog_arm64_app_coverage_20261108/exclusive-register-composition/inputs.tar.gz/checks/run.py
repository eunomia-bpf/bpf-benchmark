from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;F=R/'kprog/formal';target='KProgFormal/Refinement/Arm64Exclusive.lean';sources={};seen=set()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(N/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def visit(path):
 if path in seen:return
 seen.add(path);p=F/path;data=(N/'after.lean').read_bytes() if path==target else p.read_bytes();q=N/'source'/path;q.parent.mkdir(parents=True,exist_ok=True)
 if path==target:q.write_bytes(data)
 else:shutil.copy2(p,q)
 sources[path]=dict(sha256=hashlib.sha256(data).hexdigest(),root_git_blob_sha256=hashlib.sha256(subprocess.check_output(['git','show','HEAD:kprog/formal/'+path],cwd=R)).hexdigest())
 if path!=target:assert data==subprocess.check_output(['git','show','HEAD:kprog/formal/'+path],cwd=R),path
 for line in data.decode().splitlines():
  if line.startswith('import '):
   for name in line[7:].split():
    if name.startswith('KProgFormal.'):visit(name.replace('.','/')+'.lean')
cache=N/'warm-build'
try:
 visit(target);visit('KProgFormal/Refinement/Arm64Dispatcher.lean');visit('KProgFormal/Arm64Stlxr.lean');(N/'source-pins.json').write_text(json.dumps(sources,indent=2)+'\n');save('copying_incremental_cache',source_files=len(sources));cache.mkdir();subprocess.run(['cp','-a','--reflink=auto',str(F/'.lake/build')+'/.',str(cache)],check=True)
 mounts=['mount --bind '+str(cache)+' '+str(F/'.lake/build')]+['mount --bind '+str(N/'source'/p)+' '+str(F/p) for p in sources];(N/'inside.sh').write_text('set -eu\n'+'\n'.join(mounts)+'\nexec make -f '+str(N/'Makefile')+' check\n');save('checking_current_canonical_closure',source_files=len(sources))
 with (N/'check.log').open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/'inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (N/'check.exit').write_text(str(done.returncode)+'\n');artifacts={str(p.relative_to(cache)):sha(p) for p in cache.rglob('*.olean') if any(str(p).endswith(str(Path(src).with_suffix('.olean'))) for src in sources)};(N/'import-artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n');done.check_returncode()
 for path,pin in sources.items():assert sha(F/path)==(sha(N/'before.lean') if path==target else pin['sha256']),path
 save('checks_passed',source_files=len(sources),returncode=0)
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
finally:
 if cache.exists():
  assert cache.resolve()==(N/'warm-build').absolute() and cache.parent==N and not cache.is_symlink();shutil.rmtree(cache)
 (N/'cache-retirement.json').write_text(json.dumps(dict(utc=now(),retired_private_cache=True,scope=str(cache)),indent=2)+'\n')
