#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x9444f9a9, "bpf_prog_by_id" },
	{ 0xdcb764ad, "memset" },
	{ 0x85faab5b, "bpf_stats_enabled_key" },
	{ 0x43b0c9c3, "preempt_schedule" },
	{ 0x122c3a7e, "_printk" },
	{ 0x0303fb4a, "bpf_prog_put" },
	{ 0xe94986d6, "sched_clock" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x55ac52af, "param_ops_ulong" },
	{ 0xc897445c, "param_ops_uint" },
	{ 0x008a44e9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "99DC7E4741D5D5F724CCFDD");
