savedcmd_modules.order := {   echo native_load_fault_module.o; :; } > modules.order
