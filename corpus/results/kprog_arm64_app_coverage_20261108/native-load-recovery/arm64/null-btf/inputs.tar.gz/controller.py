from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;G=F.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64/null-btf';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('queued_after_ARM_recovery_build')
 try:fd=os.pidfd_open(int((G/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 build=json.loads((O.parent/'build.json').read_text())
 if build.get('module_exit')!=0:raise RuntimeError('ARM recovery build outcome '+repr(build))
 save('fixture_build')
 with (F/'fixture-build.log').open('w') as out:p=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(F/'inside-fixture.sh')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 report=dict(utc=now(),fixture_make_exit=p.returncode,build=build.get('source_commit'),shared='5598b9321',return_policy='Existing LSM [-4095,0]: negate the loaded low bit',expected_control=0xffffffff,expected_null=0)
 if p.returncode==0:
  stage=R/'kprog/arm64/build/native-load-recovery/null-fixture';stage.mkdir(parents=True,exist_ok=True)
  for name,src in [('native.o',F/'fixture/native.o'),('probe',F/'fixture/probe'),('native_load_fault_module.ko',F/'fixture/module/native_load_fault_module.ko')]:shutil.copy2(src,stage/name)
  save('actual_NULL_BTF_guest')
  with (F/'driver.log').open('w') as out:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
  report['make_exit']=p.returncode
 paths=[];Q=O/'trusted-arm64-service-result'
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','qemu_returncode','compiler_exit']}
  with tarfile.open(Q/j['archive']) as tf:
   if 'run/guest.json' in tf.getnames():report['guest']=json.loads(tf.extractfile('run/guest.json').read())
 for name in ['fixture-build.log','driver.log']:
  if (F/name).exists():(O/(name+'.gz')).write_bytes(gzip.compress((F/name).read_bytes(),mtime=0));paths.append(O/(name+'.gz'))
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for name in ['fixture-source','Makefile','inside-fixture.sh','controller.py','mount.py','transport.py','source','fixture']:
   p=F/name
   if p.exists():tf.add(p,arcname=name)
 paths.append(O/'inputs.tar.gz')
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 (O/'README.md').write_text('Authorized ARM full-word NULL BTF load recovery\n\nThe shared guest module body and full-word volatile BTF read are preserved. The fixture returns the negated low bit of that read to satisfy the existing LSM return range; live-file control returns u32 0xffffffff and recovered NULL returns0. The ARM producer/header and cross-link commands build that same file_open read; the fixture invokes one service-loaded native program with a live file and then argument0, recording extable count, return values and guest survival. Program generation and stock verification run through the captured ARM recovery service/Image/module. Original kernel annotation sources keep their published bytes. Actual build/guest outcomes and full raw records follow in summary.json. Generic protected-read/B correspondence continues with V.\n');paths.append(O/'README.md')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Record the authorized ARM NULL BTF recovery control','arm-null-btf-recovery')
 save('finished',publication=rec,**report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' authorized ARM NULL BTF recovery actual '+json.dumps(report)+'. Original C fixture bodies retained; full native/B/service/kernel/return values archived. Generic fault-prefix interfaces stay explicit. Product checks/gates/limits0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
