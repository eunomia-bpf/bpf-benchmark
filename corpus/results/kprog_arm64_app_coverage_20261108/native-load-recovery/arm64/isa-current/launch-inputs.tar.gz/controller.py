from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64/isa-current';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+s+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('incremental_producer_relink')
 args=json.loads((F/'suite/build.json').read_text())['producer_command']
 args=[str(F/'libnative_loader.a') if x.endswith('/libnative_loader.a') else str(F/'libbpf.a') if x.endswith('/libbpf.a') else str(F/'source/kprog/fidelity/bound_probe.cpp') if x.endswith('/kprog/fidelity/bound_probe.cpp') else x for x in args]
 args[-1]=str(F/'build/bound-probe');args=['taskset','-c','20-23',*args]
 with (F/'build.log').open('w') as log:p=subprocess.run(args,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(command=args,build_exit=p.returncode,source_sha256=hashlib.sha256((F/'source/kprog/fidelity/bound_probe.cpp').read_bytes()).hexdigest(),static_loader_sha256=hashlib.sha256((F/'libnative_loader.a').read_bytes()).hexdigest())
 (F/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 if p.returncode:raise RuntimeError('incremental producer relink exit '+str(p.returncode))
 report['producer_sha256']=hashlib.sha256((F/'build/bound-probe').read_bytes()).hexdigest();(F/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),runtime='f1/e5/99b native load recovery',model_helpers=92,cases=34,guest_memory='2GiB',cpus='12-15',producer=report,scope='Original ISA fixtures, four named positives executed; negative cases load-only',runtime_admission_additions=0),indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Original ARM ISA fixtures on native-load recovery\n\nAll34original fixtures retain original native bytes and annotations. Four named controls execute and compare their existing expected result2; negative cases retain load-only admission outcomes. A private runtime copy carries thef1/e5recovery Image/module/loader/linker and92helper simulator. The producer is incrementally relinked against the captured paired static loader. The existing check.py and original fixture source remain captured. QEMU2GiB12-15 follows the complete92helper dynptr family bypidfd, alongside the completecatalog2GiB8-11 and serialapps up to8GiB16-19. Every actual stage and raw request archive is collected. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Replay original ARM ISA fixtures on native-load recovery','arm-recovery-isa-launch')
 save('queued_after_92helper_family',publication=rec);notice('PUSHED '+rec['commit']+' original34 ISA recovery replay prepared, incremental producer0, private f1/e5/92helper runtime. Queue follows92helper family12-15/2GiB; positives4 retain expected2, negatives load-only. Framework/originalfixture bytes retained. Runtime admission additions0.')
 try:
  fd=os.pidfd_open(int((A/'bpf34/dynptr-memory/qemu/controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('actual_isa_replay',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'inside.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 paths=[];report=dict(utc=now(),make_exit=p.returncode)
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 Q=O/'trusted-arm64-service-result'
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths += [Q/'summary.json',Q/j['archive']];report['runtime']={k:j.get(k) for k in ['ok','guest_exit','qemu_returncode','compiler_exit','guest','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/outcomes.json'
   if n in tf.getnames():
    payload=tf.extractfile(n).read();(O/'outcomes.json').write_bytes(payload);paths.append(O/'outcomes.json');report['stages']=dict(collections.Counter(r['stage'] for r in json.loads(payload)))
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect original ARM ISA native recovery outcomes','arm-recovery-isa-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'});notice('PUSHED '+rec['commit']+' original34 ISA recovery terminal Makeexit'+str(p.returncode)+'; actual '+json.dumps(report.get('runtime',{}).get('guest'))+' stages'+json.dumps(report.get('stages'))+'. Full P/B/verifier/raw retained. Runtime admission additions0.')
 removed=[]
 for name in ['source','build','suite','runtime']:
  root=F/name;size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);removed.append(dict(path=str(root),bytes=size))
 (F/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=rec,retired=removed),indent=2)+'\n')
 notice('Original34 recovery terminal private copies retired '+str(sum(r['bytes'] for r in removed))+'bytes; canonical runtime/incremental caches retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
