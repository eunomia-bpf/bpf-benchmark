set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/full-catalog/runtime /workspaces/repository/kprog/arm64/build/native-load-recovery/recovery
exec python3 /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/full-catalog/controller.py
