from pathlib import Path
import os,subprocess,sys
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');app=sys.argv[1]
for p in sorted((G/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
K=G.parent
stage=R/'kprog/arm64/build/native-load-recovery/recovery'
for source,target in [
 ('native-link','kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link'),
 ('native-link','kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link-arm64-entry-resources'),
 ('libnative_loader.so','runner/build-arm64-llvmbpf/native_loader/libnative_loader.so'),
 ('libnative_loader.so','kprog/arm64/build/design-only/loader/libnative_loader.so'),
 ('trusted-native-loader','runner/build-arm64-llvmbpf/native_loader/trusted-native-loader'),
 ('trusted-native-loader','kprog/arm64/build/design-only/loader/trusted-native-loader'),
 ('trusted-service-client','runner/build-arm64-llvmbpf/native_loader/trusted-service-client'),
 ('trusted-service-client','kprog/arm64/build/design-only/loader/trusted-service-client')]:
 subprocess.run(['mount','--bind',str(stage/source),str(R/target)],check=True)
subprocess.run(['mount','--bind',str(K/'paired-modules'),str(R/'kprog/arm64/build/design-only/modules')],check=True)
subprocess.run(['mount','--bind',str(K/'module-output'),str(R/'kprog/arm64/build/design-only/kinsn')],check=True)
for p in (G/'manifests').glob('*.json'):subprocess.run(['mount','--bind',str(p),str(R/'kprog/arm64/build/app-verified-stage'/p.name[:-5]/'manifest.json')],check=True)
subprocess.run(['mount','--bind',str(G/(app+'-transport.py')),str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py')],check=True)
if app=='bcc':subprocess.run(['mount','--bind',str(G/'bcc-workload.py'),str(R/'runner/libs/workload.py')],check=True)
os.execvp('make',['make','-f',str(G/'Makefile'),'application','APP='+app])
