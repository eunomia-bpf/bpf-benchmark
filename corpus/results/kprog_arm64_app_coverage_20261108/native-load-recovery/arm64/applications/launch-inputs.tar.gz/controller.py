from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64/applications'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 stage=R/'kprog/arm64/build/native-load-recovery/recovery'
 binaries={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
 for p in (G/'source').rglob('*'):
  if p.is_file() and p.name in binaries:
   shutil.copy2(stage/binaries[p.name],p)
 (O/'README.md').write_text('ARM BCC and Katran paired native-load recovery replay\n\nThis two-start cohort retains original whole application manifests and workload. BCC uses the8exact archived Armv8.1LSE native tool objects from b9378e020, preserving all23application and startup manifest rows. Katran retains its native inputs. Both use the newly built same-copy native-load recovery Image/module/worker and configured module BTF epoch together, including all11native kinsn modules. BCC retains originalTCP/fsync/libaio/256MiBext4 recipe2GiB16-19; Katran follows8GiB16-19. Full per-program work and actual service/verifier stages are retained. Runtime admission additions:0.\n')
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),source_publication='5598b93219eaaaf69c5b17b1bf64955d5a3927ed',ARM_build_publication=json.loads((O.parent/'build.json').read_text()).get('source_commit'),applications=['bcc','katran'],source_hashes={str(p.relative_to(G/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (G/'source').rglob('*') if p.is_file()},runtime_admission_additions=0),indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for root in [G/'source',G/'manifests']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
  for n in ['controller.py','mount.py','Makefile','bcc-transport.py','bcc-workload.py','katran-transport.py']:tf.add(G/n,arcname=n)
  tf.add(O/'input.py',arcname='input.py')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz','input.py']],'Replay ARM BCC and Katran through public helper relocations','arm-recovery-app-launch')
 save('actual_application',application='bcc',publication=rec,results={});results={}
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' actualsame-copy ARM BCC/Katran serialreplays16-19; BCC2GiB original23rows/TCP/fsync/libaio/block workload, Katran8GiB originalpacketwork follows. NewARM exception recovery Image/module/worker/Rust and paired configured modules captured; BCC exactLSE producer b9378e020. Current380/inlinecomponent keep inputs; totalAguestmemory fits12GiB. Runtimeadmissionadditions0.\n')
 for app in ['bcc','katran']:
  save('actual_application',application=app,launch_publication=rec,results=results)
  with (G/(app+'.log')).open('w') as output:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT)
  Q=O/('trusted-arm64-'+app+'-result');Q.mkdir(exist_ok=True);(Q/'driver.log.gz').write_bytes(gzip.compress((G/(app+'.log')).read_bytes(),mtime=0));paths=[Q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
  if (Q/'summary.json').exists():
   d=json.loads((Q/'summary.json').read_text());archive=Q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](d,archive);paths.extend([Q/'summary.json',archive])
  (Q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(Q/'coverage.json')
  result=pub.publish([str(p.relative_to(R)) for p in paths],'Collect ARM '+app+' public-helper application outcomes','arm-recovery-'+app+'-result');results[app]=dict(make_exit=p.returncode,publication=result)
  with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+result['commit']+' ARM '+app+' same-copy publichelper completeattempt Makeexit'+str(p.returncode)+'. Alloriginal app/work/service/verifier records retained; serialqueue continues. Runtimeadmissionadditions0.\n')
 save('finished',results=results)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
