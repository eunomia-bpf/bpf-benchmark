from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def run(label,script):
 save('incremental_'+label)
 with (G/(label+'.log')).open('w') as out:
  p=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(script)],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 return p.returncode
def git(args,**kw):return subprocess.check_output(['git',*args],cwd=R,**kw)
try:
 report=dict(utc=now(),shared_source='5598b93219eaaaf69c5b17b1bf64955d5a3927ed',runtime_admission_additions=0)
 report['host_exit']=run('host',G/'inside-host.sh')
 if report['host_exit']==0:report['kernel_exit']=run('kernel',G/'inside-kernel.sh')
 if report.get('kernel_exit')==0:report['module_exit']=run('module',G/'inside-module.sh')
 if report.get('module_exit')==0:
  stage=R/'kprog/arm64/build/native-load-recovery/recovery';stage.mkdir(parents=True,exist_ok=True)
  cache=A/'design-only/stack-frame/kernel-link/cache'
  files={'Image':cache/'arch/arm64/boot/Image','bpf_arm64_native_lab.ko':G/'module-output/bpf_arm64_native_lab.ko','bpf_testmod.ko':G/'testmod-output/bpf_testmod.ko','native-link':R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link','libnative_loader.so':R/'runner/build-arm64-llvmbpf/native_loader/libnative_loader.so','trusted-native-loader':R/'runner/build-arm64-llvmbpf/native_loader/trusted-native-loader','trusted-service-client':R/'runner/build-arm64-llvmbpf/native_loader/trusted-service-client'}
  report['sha256']={}
  for name,p in files.items():
   q=stage/name;q.write_bytes(p.read_bytes());q.chmod(p.stat().st_mode & 0o777);report['sha256'][name]=hashlib.sha256(q.read_bytes()).hexdigest()
  with tarfile.open(O/'runtime.tar.gz','w:gz') as tf:
   for p in stage.iterdir():tf.add(p,arcname=p.name)
  with tarfile.open(O/'paired-modules.tar.gz','w:gz') as tf:
   for p in sorted((G/'paired-modules').rglob('*')):
    if p.is_file() and not p.is_symlink() and 'build' not in p.relative_to(G/'paired-modules').parts:tf.add(p,arcname=str(p.relative_to(G/'paired-modules')))
 # Store raw outcomes for every build invocation, preserving continuation.
 for name in ['host','kernel','module']:
  p=G/(name+'.log')
  if p.exists():(O/(name+'.log.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'README.md').write_text('AArch64 same-copy native load exception integration\n\nShared source5598b9321 supplies the service load-site span and descriptor callbacks. ARM decodes final code before its literal pool, copies sites into request chunks, allocates the program exception table and fills RX-relative EX_TYPE_BPF entries while emitting the same native bytes. Native fixups clear X0-X30, discard XZR, handle X5 through a native marker, clear paired GPR destinations and resume at PC+4. The upstream file__nullable hook metadata is included.\n\nbuild.json records actual incremental host/kernel/module outcomes against the retained ARM cache. Runtime and configured module archives carry exact binary inputs. Vector resume-only effects and protected-read/B fault-prefix correspondence continue through the shared model/reference work. The authorized full-word NULL guest is the following functional control. Runtime admission additions:0.\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for n in ['bpf.h','bpf_jit_comp.c','bpf_arm64_native_lab.c','load-sites.rs.inc','Makefile','inside-host.sh','inside-kernel.sh','inside-module.sh','own-production.diff','production-paths.json','adoption.json','build-controller.py']:tf.add(G/n,arcname=n)
  for d in ['source','include','module-source']:
   for p in sorted((G/d).rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 # Commit only this lane's production hunks, through a private index.
 if report.get('module_exit')==0:
  env=dict(os.environ,GIT_INDEX_FILE=str(G/'source.index'))
  while True:
   base=git(['rev-parse','HEAD'],text=True).strip();git(['read-tree',base],env=env)
   git(['apply','--cached',str(G/'own-production.diff')],env=env)
   git(['diff','--cached','--check',base],env=env)
   tree=git(['write-tree'],env=env,text=True).strip()
   commit=git(['commit-tree',tree,'-p',base,'-m','Register native AArch64 load sites in the stock exception table'],env=env,text=True).strip()
   p=subprocess.run(['git','update-ref','refs/heads/master',commit,base],cwd=R)
   if p.returncode==0:break
  subprocess.run(['git','push','origin','HEAD:master'],cwd=R,check=True)
  remote=git(['ls-remote','origin','refs/heads/master'],text=True).split()[0];subprocess.run(['git','merge-base','--is-ancestor',commit,remote],cwd=R,check=True)
  report['source_commit']=commit;(O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 paths=[str(p.relative_to(R)) for p in O.iterdir() if p.is_file()]
 rec=pub.publish(paths,'Record the incremental ARM native load recovery build','arm-load-recovery-build')
 save('build_finished',publication=rec,**report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' ARM native-load recovery incremental '+json.dumps(report)+'. Same-copy bytes and stock EX_TYPE_BPF lifetime; authorized NULL guest follows actual runtime. Product checks/gates/limits0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
