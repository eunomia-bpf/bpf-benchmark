set -eu
cd /workspaces/repository
export PATH=/root/.cargo/bin:$PATH
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/source/kinsn/module/include/native_lab_trusted_wire.h /workspaces/repository/kinsn/module/include/native_lab_trusted_wire.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/source/kprog/libnativeloader/src/native_loader.cpp /workspaces/repository/kprog/libnativeloader/src/native_loader.cpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/source/kprog/libnativeloader/src/native_loader_link_schema.hpp /workspaces/repository/kprog/libnativeloader/src/native_loader_link_schema.hpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/source/kprog/x86/native_lab/native_link/src/main.rs /workspaces/repository/kprog/x86/native_lab/native_link/src/main.rs
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/source/kprog/x86/native_lab/native_link/src/x86.rs /workspaces/repository/kprog/x86/native_lab/native_link/src/x86.rs
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc
CARGO_TARGET_DIR=/workspaces/repository/kprog/arm64/build/app-native-link cargo build --release --target aarch64-unknown-linux-gnu -j2 --manifest-path kprog/x86/native_lab/native_link/Cargo.toml
cmake --build runner/build-arm64-llvmbpf --target micro_exec native_loader_shared trusted-native-loader trusted-service-client --parallel 2
