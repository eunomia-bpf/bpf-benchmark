from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64/symbol-refresh';K=A/'design-only/stack-frame/kernel-link/cache'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'symbol-status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('incremental_in_tree_modpost_and_external_relink')
 with (G/'symbol-refresh.log').open('w') as out:p=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(G/'inside-symbols.sh')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,source='f1caa1cd9',image_sha256=hashlib.sha256((R/'kprog/arm64/build/native-load-recovery/recovery/Image').read_bytes()).hexdigest(),reason='Existing in-tree Module.symvers replaces the stale pre-copy input')
 if p.returncode==0:
  stage=R/'kprog/arm64/build/native-load-recovery/recovery'
  for name,src in [('bpf_arm64_native_lab.ko',G/'module-output/bpf_arm64_native_lab.ko'),('bpf_testmod.ko',G/'testmod-output/bpf_testmod.ko')]:shutil.copy2(src,stage/name)
  report['module_sha256']=hashlib.sha256((stage/'bpf_arm64_native_lab.ko').read_bytes()).hexdigest()
  with tarfile.open(O/'modules.tar.gz','w:gz') as tf:
   for p in (G/'module-output').glob('*.ko'):tf.add(p,arcname='kinsn/'+p.name)
   tf.add(G/'testmod-output/bpf_testmod.ko',arcname='bpf_testmod.ko')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in [G/'Makefile',G/'inside-symbols.sh',G/'symbol-controller.py',K/'Module.symvers',K/'.vmlinux.export.c',G/'module-output/bpf_arm64_native_lab.mod.c']:
   if p.exists():tf.add(p,arcname=p.name)
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'build.log.gz').write_bytes(gzip.compress((G/'symbol-refresh.log').read_bytes(),mtime=0))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str(p.relative_to(R)) for p in O.iterdir() if p.is_file()],'Refresh ARM module symbol versions from the linked kernel objects','arm-recovery-symbol-refresh')
 save('finished',publication=rec,**report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' ARM symbol refresh '+json.dumps(report)+'. Warmcode/cache andexistingImage retained; matchedNULL follows actualpairedmodule. Product checks/gates/limits0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
