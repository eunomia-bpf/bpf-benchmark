#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x81a4ceb2, "mutex_lock" },
	{ 0xe797f835, "xa_load" },
	{ 0xeb5546a2, "mutex_unlock" },
	{ 0x037a0cba, "kfree" },
	{ 0x5ac1f2e4, "bpf_map_put" },
	{ 0x0303fb4a, "bpf_prog_put" },
	{ 0x7aa1756e, "kvfree" },
	{ 0x4829a47e, "memcpy" },
	{ 0x74c134b9, "__sw_hweight32" },
	{ 0xf06dba40, "debugfs_create_dir" },
	{ 0x9cdcc873, "debugfs_create_file_full" },
	{ 0xb3c47d95, "register_btf_kfunc_id_set" },
	{ 0x3ce26622, "debugfs_remove" },
	{ 0x619cb7dd, "simple_read_from_buffer" },
	{ 0x6e9c57cd, "xa_destroy" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x6f38e04b, "kmalloc_caches" },
	{ 0x8db5feb1, "__kmalloc_cache_noprof" },
	{ 0xc6cbbc89, "capable" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0x5d16eed4, "refcount_warn_saturate" },
	{ 0x427ce06c, "xa_erase" },
	{ 0x950eb34e, "__list_del_entry_valid_or_report" },
	{ 0xcead5019, "__wake_up" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0xdcb764ad, "memset" },
	{ 0x36dcb0a8, "validate_usercopy_range" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x3b6c41ea, "kstrtouint" },
	{ 0x1ed09d06, "bpf_map_get" },
	{ 0x96848186, "scnprintf" },
	{ 0x747339cb, "btf_obj_id" },
	{ 0xe2f93174, "vmemdup_user" },
	{ 0xb8342c83, "__kmalloc_noprof" },
	{ 0x36f8d241, "bpf_map_get_curr_or_next" },
	{ 0xbe0d6fc9, "_raw_spin_lock" },
	{ 0x06f04b13, "__xa_alloc" },
	{ 0xe47c1dcf, "_raw_spin_unlock" },
	{ 0x7696f8c7, "__list_add_valid_or_report" },
	{ 0x9444f9a9, "bpf_prog_by_id" },
	{ 0x1d07e365, "memdup_user_nul" },
	{ 0x1c9e978f, "memdup_user" },
	{ 0xf04a02c2, "__init_waitqueue_head" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x01000e51, "schedule" },
	{ 0xdb9c9937, "prepare_to_wait_event" },
	{ 0xcc1f2035, "finish_wait" },
	{ 0xdd766f86, "system_cpucaps" },
	{ 0x488c520e, "___ratelimit" },
	{ 0x1c1bb726, "try_module_get" },
	{ 0x122c3a7e, "_printk" },
	{ 0x0133f405, "default_llseek" },
	{ 0x008a44e9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "EF3E5196463F31AAB6C38EA");
