from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/lsm-comparison';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (O/'README.md').write_text('Paired ARM nullable-context LSM comparison\n\nThe two original verifier_lsm fixtures run stock BPF load-only, then native source0 generation/verification/installation in one guest. Native executions:0. The source objects and annotations remain published. This runtime uses61656250e upstream file__nullable Image/module and the captureddc120/88-helper worker. Bootstrap loads the native-lab module required by these two LSM fixtures. The comparison follows the active inline component on12-15/2GiB. Target BTF ID, runtime BTF identity, original verifier logs, native request artifacts and installed-stage annotation agreement are retained.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for root in [G/'source',G/'catalog']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
  for n in ['controller.py','mount.py','transport.py']:tf.add(G/n,arcname=n)
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),resource_sha256=hashlib.sha256((G/'catalog/verifier_lsm.bpf.o').read_bytes()).hexdigest(),scope='Original2LSMfixtures/stockBPF+native-source0-loadonly/file__nullable61656250e/2GiB12-15',resource_publication='2e9f2fd196f50e1951d622c2c30e370f1bbc2c9c',runtime_admission_additions=0),indent=2)+'\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Queue paired ARM LSM context loads on the nullable kernel','arm-nullable-lsm-context-launch')
 save('queued_after_inline_component',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR COORDINATOR/C/V '+now()+': PUSHED '+rec['commit']+' original ARM stockBPF LSM pair stockplusnative2 queuedafterinlinecomponent12-15/2GiB, nullable61656250e Image/module. Reuses C existing loadonly baseline script with ARMlibbpf and unchanged original59-resource verifier_lsm.o. Logs targetBTF andruntimeBTFsha for comparison to nativeinstalledARM268/41d vsx86 file__nullable71327. Originalannotations/instructions staypublished; nativeexecution0/runtimeadmissionadditions0.\n')
 pid=int((A/'app-source/tetragon-loop/data-event-inline/component-mode-corrected/controller.pid').read_text())
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('actual_original_stock_LSM',publication=rec)
 with (G/'driver.log').open('w') as output:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=output,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,native_executions=0);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   for arc,out in [('run/out/submissions.json','submissions.json'),('run/out/original-stock-lsm.json','original-stock-lsm.json'),('run/out/kernel-btf-sha256.txt','kernel-btf-sha256.txt'),('run/baseline.log','baseline.log')]:
    if arc in tf.getnames():
     data=tf.extractfile(arc).read();(O/out).write_bytes(data);paths.append(O/out)
   if (O/'original-stock-lsm.json').exists():report['rows']=json.loads((O/'original-stock-lsm.json').read_text())
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect paired ARM LSM outcomes with nullable context','arm-nullable-lsm-context-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR COORDINATOR/C/V '+now()+': PUSHED '+rec['commit']+' original ARMstockLSM '+json.dumps([dict(program=r.get('program'),stage=r.get('stage'),target_btf_id=r.get('target_btf_id')) for r in report.get('rows',[])])+'. SamepairedImage/BTF pinned; source/annotations/raw logs retained. Nativeexecution0/runtime additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
