from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
def note(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+s+'\n')
try:
 (O/'README.md').write_text('ARM native-load recovery integration\n\nThe coordinator decision of2026-11-08 assigns native load exception recovery to C(shared/x86) and A(ARM), with V supplying the universal O4/reference law. Native instruction bytes remain the submitted bytes; exception metadata supplies the stock handler behavior.\n\nThis first incremental ARM build uses the retained88a kernel source/cache and changes the upstream mmap_file hook argument name from file to file__nullable. Existing stock btf_ctx_access then supplies PTR_MAYBE_NULL to the original BPF context. The one-line source patch and exact private build inputs are retained. Current guests keep their captured88a runtime. The separate Image and rebuilt module feed the following matched LSM load-only comparison and shared recovery integration.\n\nThe shared load-site transport and ARM exception table emission are the next implementation stage after C publication. The complete paired-kernel NULL recovery execution follows that stage. Runtime admission additions:0.\n')
 (O/'launch.json').write_text((G/'plan.json').read_text())
 with tarfile.open(O/'metadata-build-inputs.tar.gz','w:gz') as tf:
  for n in ['lsm_hook_defs.h','Makefile','inside-kernel.sh','inside-module.sh','controller.py','plan.json']:tf.add(G/n,arcname=n)
  roots=[A/'design-only/kernel-source',A/'native-extent/module-source',A/'native-extent/include']
  for root in roots:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(A)))
  for p in [A/'design-only/stack-frame/kernel-link/verifier.c',A/'byte-atomic/btf.c',A/'native-extent/bpf_jit_comp.c',A/'design-only/stack-frame/kernel-link/cache/.config']:
   tf.add(p,arcname=str(p.relative_to(A)))
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','lsm-hook.patch','metadata-build-inputs.tar.gz']],'Prepare upstream nullable LSM metadata in the retained ARM kernel','arm-load-recovery-metadata-launch')
 save('incremental_nullable_metadata_kernel',publication=rec)
 note('PUSHED '+rec['commit']+' authorized ARM file__nullable metadata incremental build on sole warm cache, CPUs20-23/-j4. Exact source/mounts/patch captured; active guests retain their88a files. Shared native-load recovery interface follows C publication.')
 with (G/'kernel.log').open('w') as out:
  p=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(G/'inside-kernel.sh')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 report=dict(utc=now(),kernel_exit=p.returncode,source='88a+upstream file__nullable',native_executions=0,shared_recovery='C publication pending')
 if p.returncode==0:
  image=A/'design-only/stack-frame/kernel-link/cache/arch/arm64/boot/Image'
  (G/'Image').write_bytes(image.read_bytes())
  with (G/'module.log').open('w') as out:
   m=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(G/'inside-module.sh')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
  report['module_exit']=m.returncode
  if m.returncode==0:
   (G/'bpf_arm64_native_lab.ko').write_bytes((G/'module-output/bpf_arm64_native_lab.ko').read_bytes())
  p=subprocess.run(['aarch64-linux-gnu-objcopy','--dump-section','.BTF='+str(G/'vmlinux.btf'),str(A/'design-only/stack-frame/kernel-link/cache/vmlinux')],cwd=R)
  report['btf_extract_exit']=p.returncode
 paths=[]
 for n in ['kernel.log','module.log']:
  if (G/n).exists():(O/(n+'.gz')).write_bytes(gzip.compress((G/n).read_bytes(),mtime=0));paths.append(O/(n+'.gz'))
 with tarfile.open(O/'metadata-build-output.tar.gz','w:gz') as tf:
  report['sha256']={}
  for n in ['Image','bpf_arm64_native_lab.ko','vmlinux.btf']:
   if (G/n).exists():tf.add(G/n,arcname=n);report['sha256'][n]=hashlib.sha256((G/n).read_bytes()).hexdigest()
 paths.append(O/'metadata-build-output.tar.gz')
 (O/'metadata-build.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'metadata-build.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Record the incremental ARM nullable-context kernel build','arm-load-recovery-metadata-result')
 save('metadata_build_finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 note('PUSHED '+rec['commit']+' ARM upstream nullable metadata kernel actual '+json.dumps(report)+'. Source0/load-only comparison and shared recovery adoption follow captured Image/module; native executions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
