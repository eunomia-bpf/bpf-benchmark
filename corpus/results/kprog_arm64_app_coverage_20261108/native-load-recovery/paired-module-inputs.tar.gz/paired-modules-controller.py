from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'paired-modules-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('building_paired_modules',kernel='61656250e90663eb1cf32c09eb2c8a6191cfd47d')
 with (G/'paired-modules.log').open('w') as out:p=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(G/'inside-paired-modules.sh')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,kernel='61656250e90663eb1cf32c09eb2c8a6191cfd47d',module_files=[])
 paths=[]
 if p.returncode==0:
  for f in sorted((G/'paired-modules').rglob('*')):
   if f.is_file() and not f.is_symlink() and 'build' not in f.relative_to(G/'paired-modules').parts:
    report['module_files'].append(dict(path=str(f.relative_to(G/'paired-modules')),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
  m=G/'testmod-output/bpf_testmod.ko';report['testmod_sha256']=hashlib.sha256(m.read_bytes()).hexdigest()
  with tarfile.open(O/'paired-modules.tar.gz','w:gz') as tf:
   for x in report['module_files']:
    f=G/'paired-modules'/x['path'];tf.add(f,arcname='modules/'+x['path'])
   tf.add(m,arcname='bpf_testmod.ko')
  paths.append(O/'paired-modules.tar.gz')
 with tarfile.open(O/'paired-module-inputs.tar.gz','w:gz') as tf:
  for n in ['paired-modules.mk','inside-paired-modules.sh','paired-modules-controller.py']:tf.add(G/n,arcname=n)
  for f in (A/'bpf34/testmod/source').rglob('*'):
   if f.is_file():tf.add(f,arcname='testmod-source/'+str(f.relative_to(A/'bpf34/testmod/source')))
 (O/'paired-modules.json').write_text(json.dumps(report,indent=2)+'\n');paths.extend([O/'paired-modules.json',O/'paired-module-inputs.tar.gz'])
 (O/'paired-modules.log.gz').write_bytes(gzip.compress((G/'paired-modules.log').read_bytes(),mtime=0));paths.append(O/'paired-modules.log.gz')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Build ARM runtime modules against the nullable-context kernel','arm-nullable-paired-modules')
 save('finished',publication=rec,make_exit=p.returncode,files=len(report['module_files']))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' nullable616 paired module build actualexit'+str(p.returncode)+'/'+str(len(report['module_files']))+'files, originaltestmod included. Exact output/source/raw retained; following guests use paired BTF module tree. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
