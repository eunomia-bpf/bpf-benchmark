R := /workspaces/repository
G := /workspaces/.agent-state/kprog-lanes/A/native-load-recovery
.PHONY: paired-modules
paired-modules:
	make -C $(R)/vendor/linux-framework O=$(R)/vendor/build/arm64/linux ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- -j4 modules
	make -C $(R)/vendor/linux-framework O=$(R)/vendor/build/arm64/linux ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- INSTALL_MOD_PATH=$(G)/paired-modules INSTALL_MOD_STRIP=1 modules_install
	make -C $(R)/vendor/linux-framework O=$(R)/vendor/build/arm64/linux ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- M=/workspaces/.agent-state/kprog-lanes/A/bpf34/testmod/source MO=$(G)/testmod-output -j2 modules
