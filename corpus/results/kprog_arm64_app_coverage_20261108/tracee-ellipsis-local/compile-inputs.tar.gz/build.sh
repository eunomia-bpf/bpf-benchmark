set -eu
cd /workspaces/repository
G=/workspaces/.agent-state/kprog-lanes/A/app-source/tracee-ellipsis-local
mount --bind "$G/tree" vendor/bpf/tracee/pkg/ebpf/c
mount --bind "$G/tree" vendor/repos/tracee/pkg/ebpf/c
mount --bind "$G/embedded-dist" vendor/repos/tracee/dist
mount --bind "$G/build-source/vendor/bpf/Makefile" vendor/bpf/Makefile
mount --bind "$G/build-source/vendor/bpf/native_compat.h" vendor/bpf/native_compat.h
mount --bind "$G/build-source/vendor/bpf/write_native_manifest.py" vendor/bpf/write_native_manifest.py
mount --bind "$G/build-source/vendor/repos/tracee/Makefile" vendor/repos/tracee/Makefile
make -f "$G/Makefile" native baseline binary
