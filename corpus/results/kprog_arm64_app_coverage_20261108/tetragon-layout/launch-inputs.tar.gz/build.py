from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback,collections
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=A/'design-only/lse-input/tetragon';O=R/'kprog/arm64/build/lse-native';S=R/'kprog/arm64/build/lse-stage';D=R/'corpus/results/kprog_arm64_app_coverage_20261108/lse-input/tetragon';D.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 cmd=['make','-C',str(R/'vendor/bpf'),'-o','tetragon/bpf/include/vmlinux_generated_arm64.h','ARCH=arm64','NATIVE_OUT='+str(O),'NATIVE_STAGE_ROOT='+str(S),'NATIVE_LINK='+str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'NATIVE_ARCH_CFLAGS=-mtune=neoverse-n1 -mgeneral-regs-only -mno-outline-atomics -ffixed-x18 -ffixed-x26 -ffixed-x27 -ffixed-x28 -march=armv8.1-a+lse','NATIVE_SYS_INCLUDE_FLAGS=--sysroot='+str(R/'kprog/arm64/build/app-runtime-v35/root')+' -I'+str(R/'vendor/build/.bcc-libbpf/none/arm64/output')+' -I'+str(R/'kprog/arm64/build/app-runtime-v35/root/usr/include/aarch64-linux-gnu'),'native-tetragon'];save('compiling_complete_tetragon',command=cmd);(F/'Makefile.input').write_bytes((R/'vendor/bpf/Makefile').read_bytes())
 with (F/'build.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),command=cmd,make_exit=p.returncode,scope='Complete existing upstream native-tetragon recipe; current ARM ABI plus Armv8.1 LSE; original247 application rows remain the submission manifest',native_objects=[])
 counts=collections.Counter()
 for native in sorted((O/'tetragon').glob('*.native.o')):
  dis=subprocess.check_output(['aarch64-linux-gnu-objdump','-d',str(native)],text=True);(F/(native.stem+'.dis.gz')).write_bytes(gzip.compress(dis.encode(),mtime=0));ops=collections.Counter(x.split('\t')[2].split()[0] for x in dis.splitlines() if len(x.split('\t'))>=3);atomics={k:v for k,v in ops.items() if k.startswith(('ldadd','stadd','ldclr','stclr','ldset','stset','ldeor','steor','swp','cas','ldxr','stxr','ldaxr','stlxr'))};counts.update(atomics);report['native_objects'].append(dict(path=str(native.relative_to(R)),sha256=hashlib.sha256(native.read_bytes()).hexdigest(),atomics=atomics))
 report['atomic_counts']=dict(counts)
 manifest=json.loads((R/'kprog/arm64/build/app-verified-stage/tetragon/manifest.json').read_text())
 for row in manifest['objects']+manifest.get('data_objects',[]):
  old=Path(row['native_object']);row['native_object']=str(O/'tetragon'/old.name)
 (F/'live-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'build.json').write_text(json.dumps(report,indent=2)+'\n');(D/'build.log.gz').write_bytes(gzip.compress((F/'build.log').read_bytes(),mtime=0))
 with tarfile.open(D/'inputs.tar.gz','w:gz') as t:
  for n in ['build.py','Makefile.input','live-manifest.json']:t.add(F/n,arcname=n)
  for p in (F).glob('*.dis.gz'):t.add(p,arcname=p.name)
  for p in (O/'tetragon').glob('*.native.o'):t.add(p,arcname='native/'+p.name)
  if (O/'tetragon/manifest.json').exists():t.add(O/'tetragon/manifest.json',arcname='native/generated-manifest.json')
 (D/'README.md').write_text('Complete Tetragon Armv8.1 LSE native compiler input\n\nThe existing native-tetragon recipe uses the current AArch64 ABI/reserved registers, captured guest sysroot and installed libbpf headers, with -march=armv8.1-a+lse. The original247 application manifest rows retain their identities and point to the rebuilt native files. Complete compiler output and native instruction census accompany the exact build recipe and native inputs. Runtime submission uses the paired five-step QEMU path after the active application cohorts close.\n\nMake exit '+str(report['make_exit'])+'; native objects '+str(len(report['native_objects']))+'; atomic census '+json.dumps(report['atomic_counts'],sort_keys=True)+'.\n')
 spec=importlib.util.spec_from_file_location('arm_tetra_lse_pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);rec=pub.publish([str((D/n).relative_to(R)) for n in ['README.md','build.json','build.log.gz','inputs.tar.gz']],'Build complete Tetragon native inputs with ARM LSE','arm-tetragon-lse-input');save('compiled',make_exit=report['make_exit'],publication=rec,native_objects=len(report['native_objects']),atomic_counts=report['atomic_counts'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED '+rec['commit']+' completeTetragon LSE nativebuild, Makeexit'+str(report['make_exit'])+', objects'+str(len(report['native_objects']))+', atomiccensus='+json.dumps(report['atomic_counts'],sort_keys=True)+'. Original247applicationrows retained; actualruntime follows existingimmutableguestCPU/memoryrelease.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
