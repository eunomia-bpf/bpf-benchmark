from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent;A=F.parent.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/stack-frame';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 results={}
 for stage in ['component','loader','control']:
  save('actual_'+stage,results=results)
  command=['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(F/'control-inside.sh')] if stage=='control' else ['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(F/'inside.sh'),stage]
  with (F/(stage+'.log')).open('w') as log:done=subprocess.run(command,cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  results[stage]=dict(command=command,returncode=done.returncode);(F/(stage+'.exit')).write_text(str(done.returncode)+'\n');(O/(stage+'.log.gz')).write_bytes(gzip.compress((F/(stage+'.log')).read_bytes(),mtime=0))
  if done.returncode:break
 report=dict(utc=now(),results=results,source_pins={str(p.relative_to(F/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (F/'source').rglob('*') if p.is_file()},generated_micros=len(list((F/'micros').glob('*.bpf.c'))),compiled_micros=len(list((F/'micros').glob('*.bpf.o'))),runtime_commit='e2d3a5ee89349608fb79f4d4d397fdfc683ff7a8');(O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as t:
  for n in ['source','plan.json','Makefile','inside.sh','control-inside.sh','transport.py','candidate.h','check.c','check.bpf.c','run.py','micros']:
   if (F/n).exists():t.add(F/n,arcname=n)
 (O/'README.md').write_text('Generic ARM simulator stack storage across BPF call frames\n\nTracee09208 reaches stack off-520 in the flat simulator. The candidate places native byte storage in the caller and execution state in an ordinary BPF body function. Existing tail-call bodies retain their flat representation. The loader preserves ordinary callee EXIT and redirects the outer entry EXIT to the native-stub continuation. Existing142080 host observations,29-micro generation/compile and the existing32-width native control supply actual outcomes: '+json.dumps({k:v['returncode'] for k,v in results.items()})+'. Exact source, commands, compiler and stock-verifier logs accompany the result. Additional runtime admission gates0.\n')
 paths=[O/'summary.json',O/'inputs.tar.gz',O/'README.md',*O.glob('*.log.gz')];q=O/'control/trusted-arm64-service-result/summary.json'
 if q.exists():
  s=json.loads(q.read_text());paths.extend([q,q.parent/s['archive']])
 spec=importlib.util.spec_from_file_location('arm_pub',A/'six-app-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);receipt=m.publish([str(p.relative_to(R)) for p in paths],'Exercise generic ARM simulator storage across BPF frames','arm-stack-frame-component');(F/'publication.json').write_text(json.dumps(receipt,indent=2)+'\n');save('finished',publication=receipt,results=results)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED '+receipt['commit']+' genericARMcaller-arena/BPFbody-frame candidate actualstageexits='+json.dumps({k:v['returncode'] for k,v in results.items()})+'. Existing142080hosts/29micros/32widthnativecontrolretaininputs. OrdinarycalleeEXIT/outercontinuation loadercandidate private; paired e2d3kernel/module retained. SharedC/V link/compiledB interfaces followexactreceipt; addedadmissiongates0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
