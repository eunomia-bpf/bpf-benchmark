from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,re,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');E=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/stack-frame/ordinary-private-storage';O.mkdir(exist_ok=True,parents=True)
def save(phase,**kw):(E/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
try:
 report=dict(scope='Captured complete Tetragon event_wake_up_new_task body; original native P and instruction bodies, private raw arena qualifier comparison',source_epoch='a74c904fd82dd31c7b480a5a5b6b310061a06d4d',variants={})
 for variant in ['baseline','ordinary']:
  save('compiling_'+variant)
  with (E/(variant+'.log')).open('w') as log:p=subprocess.run(['make','-f',str(E/'Makefile'),'compile','VARIANT='+variant],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  row=dict(make_exit=p.returncode,source_sha256=hashlib.sha256((E/(variant+'.bpf.c')).read_bytes()).hexdigest())
  if p.returncode==0:
   obj=E/(variant+'.bpf.o');d=subprocess.run(['llvm-objdump-18','-d','--no-show-raw-insn',str(obj)],capture_output=True,text=True,check=True);(E/(variant+'.disasm')).write_text(d.stdout)
   offsets=[int(x,0) for x in re.findall(r'r10 - (0x[0-9a-f]+|[0-9]+)',d.stdout)]
   row.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),maximum_fp_minus_offset=max(offsets,default=0))
  report['variants'][variant]=row
 (O/'compiler.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'compiler-inputs.tar.gz','w:gz') as t:
  for p in E.iterdir():
   if p.name not in ['controller.log','status.json']:t.add(p,arcname=p.name)
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['compiler.json','compiler-inputs.tar.gz']],'Record ARM private stack storage compiler comparison','arm-ordinary-private-storage')
 save('finished',report=report,publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+rec['commit']+' captured complete Tetragon third-body private raw-arena storage compiler comparison '+json.dumps(report['variants'])+'. Native P/instruction bodies remain the captured epoch. Ordinary C storage is a private representation candidate; stock-verifier, safety-cohort and whole-application replay are subsequent evidence. New runtime admission checks0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
