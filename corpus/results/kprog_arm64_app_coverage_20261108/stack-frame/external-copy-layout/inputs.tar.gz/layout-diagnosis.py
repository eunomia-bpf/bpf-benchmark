from pathlib import Path
import importlib.util,json,sys,time
R=Path('/workspaces/repository');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'kprog'),str(R/'kprog/arm64/micro-prog')]
path=R/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py'
spec=importlib.util.spec_from_file_location('arm_layout_decode',path);gen=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gen;spec.loader.exec_module(gen)
proof=next((E/'captured').rglob('trusted_arm64.proof.o'))
functions,_=gen.parse_native_linked_program(gen.Bench('trusted_arm64','event_wake_up_new_task','raw'),proof.parent)
insns=[i for fn in functions.values() for i in fn];targets=gen.indirect_targets(insns)
seen={}
def trace(frame,event,arg):
 if event=='line' and frame.f_code.co_filename.endswith('/arm64_abi.py') and frame.f_lineno in {190,371,392}:
  v=frame.f_locals;outer=frame.f_back.f_locals if frame.f_code.co_name=='store' else v
  where=outer.get('where');context=outer.get('context')
  incoming=outer.get('incoming')
  record=dict(line=frame.f_lineno,instruction=where,context=context,location=repr(v.get('location')),source=repr(v.get('source')),start=repr(v.get('start')),length=repr(v.get('length')),aliases=[repr(x) for x in incoming.aliases[:32]] if incoming else [],ghost=[i for i,x in enumerate(incoming.ghost[:32]) if x] if incoming else [])
  seen[(frame.f_lineno,where,context)]=record
 return trace
start=time.time();sys.settrace(trace)
layout=gen.collect_layout(insns,targets,gen)
sys.settrace(None)
report=dict(layout=layout,seconds=time.time()-start,instructions=len(insns),unknown_layout_sites=list(seen.values()))
(E/'layout-diagnosis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(layout=layout,seconds=report['seconds'],sites=len(seen))))
