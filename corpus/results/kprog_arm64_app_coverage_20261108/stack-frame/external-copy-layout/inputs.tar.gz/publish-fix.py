from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');E=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/stack-frame/external-copy-layout';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(E/'fix-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 save('current_micro_and_service_regressions')
 outcomes={}
 commands={'service':['make','-C',str(R/'kprog/libnativeloader'),'trusted-service-check'],'micro':['make','-f',str(A/'kernel-selftest-helpers/Makefile'),'micro']}
 for name,command in commands.items():
  with (E/('final-'+name+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','16-19',*command],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  outcomes[name]=p.returncode
  if p.returncode:break
 report=dict(utc=now(),outcomes=outcomes,scope='Private payload geometry follows proven external, private and conservative dynamic destinations; raw memory instruction bodies retained',regression='Original external-copy fixture fails; first precision proposal also fails added SP-derived dynamic destination; final four-scene regression passes',layout=json.loads((E/'layout-input.json').read_text())['layout'],compiler=json.loads((E/'layout-compiler.json').read_text()),canonical_sources={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'kprog/arm64/micro-prog/arm64_abi.py',R/'kprog/test/check_trusted_service.py']})
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 for name in ['layout-before.log','layout-dynamic-before.log','layout-four-cases.log','final-service.log','final-micro.log']:
  p=E/name
  if p.exists():(O/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 with tarfile.open(O/'inputs.tar.gz','w:gz',dereference=True) as t:
  for n in ['layout-diagnosis.py','layout-diagnosis.json','render-layout.py','layout-input.json','layout-compiler.json','layout.bpf.c','layout.bpf.o','layout.disasm','captured','layout-candidate','Makefile','publish-fix.py']:t.add(E/n,arcname=n)
  for n in ['kprog/arm64/micro-prog/arm64_abi.py','kprog/test/check_trusted_service.py']:t.add(R/n,arcname='canonical/'+n)
 (O/'README.md').write_text('Private pointer payload layout for external copies\n\nThe layout collector now distinguishes a proved external memcpy destination from private and unknown destinations. SP-derived dynamic destinations preserve their existing complete payload geometry. Memory instructions and simulator C bodies retain their semantics. The original external-copy regression and the first proposal dynamic-destination regression retain their failing outputs; the final four-scene test and shared service suite carry the current outcomes in summary.json.\n\nThe captured Tetragon event_wake_up_new_task native P, proof object and baseline B are retained. Baseline recompilation has identical allocated sections to the original B and maxFP872. The precise layout uses native368bytes, one pointer payload slot at-64, and compiled maxFP488. Exact commands, source, objects and disassembly accompany these compiler measurements. Stock verification and complete application outcomes follow the corrected queued Tetragon cohort.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 paths=[str(p.relative_to(R)) for p in O.iterdir() if p.is_file()]
 if all(v==0 for v in outcomes.values()) and len(outcomes)==2:
  paths += ['kprog/arm64/micro-prog/arm64_abi.py','kprog/test/check_trusted_service.py']
 rec=pub.publish(paths,'Keep private pointer payloads local to private copy destinations','arm-external-copy-layout-fix')
 save('finished',outcomes=outcomes,publication=rec);(E/'fix-publication.json').write_text(json.dumps(rec,indent=2)+'\n')
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' precise private memcpy payload geometry; proved external destinations keep raw memory operation and local payload slots unchanged, SP-derived dynamic destinations retain full layout. Final service/micro exits'+json.dumps(outcomes)+', four geometry scenes; original two failing regression epochs retained. Same Tetragon P/baseline allocated sections exact, maxFP872->488, payload slot-64. Corrected whole Tetragon follows initial-candidate terminal archival. Runtime admission additions0.\n')
except BaseException as error:save('requires_continuation',error=str(error),traceback=traceback.format_exc());raise
