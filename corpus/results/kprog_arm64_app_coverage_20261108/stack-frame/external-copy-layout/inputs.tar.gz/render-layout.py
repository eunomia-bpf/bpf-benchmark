from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path('/workspaces/repository');E=Path(__file__).resolve().parent;C=E/'layout-candidate'
sys.path[:0]=[str(C/'kprog'),str(C/'kprog/arm64/micro-prog')]
spec=importlib.util.spec_from_file_location('layout_candidate',C/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py')
gen=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gen;spec.loader.exec_module(gen)
proof=next((E/'captured').rglob('trusted_arm64.proof.o'))
meta=json.loads(next((E/'captured').rglob('kernel.metadata.json')).read_text())
functions,rodata=gen.parse_native_linked_program(gen.Bench('trusted_arm64','event_wake_up_new_task','raw'),proof.parent)
text=gen.render_program('trusted_arm64','event_wake_up_new_task',functions,'raw',rodata16=rodata,linked_exit=True,program_section='kprobe/trusted',trusted_map_bindings=[dict(native_symbol=m['name'],value_offset=m.get('value_offset')) for m in meta['maps']])
text=text.replace('#include "../arm64_sim_local_bpf.h"','#include '+json.dumps(str(C/'kprog/arm64/arm64_sim_local_bpf.h')))
(E/'layout.bpf.c').write_text(text)
insns=[i for group in functions.values() for i in group]
(E/'layout-input.json').write_text(json.dumps(dict(layout=gen.collect_layout(insns,gen.indirect_targets(insns),gen),source_sha256=hashlib.sha256(text.encode()).hexdigest(),native_proof_sha256=hashlib.sha256(proof.read_bytes()).hexdigest()),indent=2)+'\n')
