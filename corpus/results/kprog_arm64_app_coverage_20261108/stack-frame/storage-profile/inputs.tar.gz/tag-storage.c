#include <stdio.h>
#include <stdint.h>
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BYTES 272U
#define ARM64_SIM_STACK_BIAS 272LL
#include "candidate.h"
int main(void) {
 ARM64_SIM_L_DECLARE_STACK();
 const unsigned slots=KPROG_ARM64_STACK_TAG_SLOTS(ARM64_SIM_STACK_BYTES);
 unsigned char expected[slots]; unsigned long observations=0;
 for (unsigned seed=0;seed<11;seed++) {
  for (unsigned i=0;i<slots;i++) { expected[i]=(i+seed)%11; ARM64_SIM_L_TAG_SET(i,expected[i]); }
  for(unsigned i=0;i<slots;i++) for(unsigned tag=0;tag<11;tag++) {
   ARM64_SIM_L_TAG_SET(i,tag); expected[i]=tag;
   for(unsigned j=0;j<slots;j++) {
    if(ARM64_SIM_L_TAG_GET(j)!=expected[j]) {printf("slot %u tag %u neighbour %u\n",i,tag,j);return 1;}
    observations++;
   }
  }
 }
 printf("ARM packed tags: %lu neighbour-preservation observations, %u slots, %zu bytes PASS\n",observations,slots,sizeof(__a64_stack_tag));
 return 0;
}
