set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/byte-tags.h /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/source/kprog/arm64/arm64_sim_local_bpf.h
exec sh /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/inside.sh flat-byte-o3
