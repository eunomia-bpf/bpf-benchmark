#include "/workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/source/kprog/arm64/arm64_sim_local_bpf.h"
