from pathlib import Path
import datetime,json,subprocess,gzip,tarfile,hashlib,importlib.util,traceback,os,signal
K=Path(__file__).resolve().parent;A=K.parent.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_arm64_app_coverage_20261108/stack-frame/kernel-link/entry-clobber';E=R/'kprog/arm64/build/frame-link'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(K/'entry-clobber-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 results={}
 for stage in ['module','control']:
  save('actual_'+stage,results=results)
  with (K/(stage+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(K/('inside-control-entry-clobber.sh' if stage=='control' else 'inside-module.sh'))],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  results[stage]=p.returncode;(O/(stage+'.log.gz')).write_bytes(gzip.compress((K/(stage+'.log')).read_bytes(),mtime=0))
  if p.returncode:break
 report=dict(utc=now(),results=results,kernel_build='f1b19edf9465252f585706e626b3205fa1954fee',source_sha256={str(p.relative_to(K/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (K/'source').rglob('*') if p.is_file()},generated_micros=len(list((K/'micros').glob('*.bpf.c'))),compiled_micros=len(list((K/'micros').glob('*.bpf.o'))),scope='Private generic ordinary proof-body integration; current canonical admission removals/raw-context ABI/four approved architecture faults retained',runtime_admission_predicates_added=0)
 (O/'runtime.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'runtime-inputs.tar.gz','w:gz') as t:
  for n in ['source','include','module-source','Makefile','inside-runtime.sh','inside-control.sh','transport.py','runtime-controller-entry-clobber.py','arm64_sim_local_bpf.h','module-before-entry-clobber.c','micros']:
   if (K/n).exists():t.add(K/n,arcname=n)
  t.add(E,arcname='runtime')
 paths=[O/'runtime.json',O/'runtime-inputs.tar.gz',*O.glob('module.log.gz'),*O.glob('control.log.gz')];q=O/'control/trusted-arm64-service-result/summary.json'
 if q.exists():
  s=json.loads(q.read_text());paths.extend([q,q.parent/s['archive']])
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);rec=pub.publish([str(p.relative_to(R)) for p in paths],'Record paired ARM ordinary proof-body runtime and QEMU control','arm-frame-link-entry-clobber');save('finished',results=results,publication=rec);(K/'entry-clobber-publication.json').write_text(json.dumps(rec,indent=2)+'\n')
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED '+rec['commit']+' privategenericordinaryproof-body pairedruntime/control stageexits'+json.dumps(results)+'. Source/currentcanonicalfaults+removals/rawcontext,29microgenerationcompile andexistingwidth/alignmentQEMUcontrol exactinputs/logsretained. Wholeapp/BTFentry interface followsactualstockverifierreceipt; runtimeadmissionadditions0. BCCqueue1675362 resumesafterprioritycontrolcloses.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
finally:
 try:os.kill(1689667,signal.SIGCONT)
 except ProcessLookupError:pass
