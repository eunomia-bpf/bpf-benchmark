from pathlib import Path
import datetime,json,subprocess,os,traceback,gzip,tarfile,hashlib,importlib.util
K=Path(__file__).resolve().parent;A=K.parent.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_arm64_app_coverage_20261108/stack-frame/kernel-link';O.mkdir(parents=True,exist_ok=True)
def save(phase,**kw):(K/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
try:
 save('clone_paired_warm_cache')
 if not (K/'cache').exists():subprocess.run(['cp','-a','--reflink=auto',str(A/'kfunc-kernel/cache'),str(K/'cache')],check=True)
 save('incremental_kernel_build')
 with (K/'kernel.log').open('w') as log:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','sh',str(K/'inside-kernel.sh')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (K/'kernel.exit').write_text(str(p.returncode)+'\n');(O/'kernel.log.gz').write_bytes(gzip.compress((K/'kernel.log').read_bytes(),mtime=0))
 report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),build_exit=p.returncode,scope='Private ordinary B proof subprogram discovery/layout and code-metadata lifetime prototype; current shared kernel source remains the published design-only implementation',cache='Paired e2d3 warm object clone; original runtime/cache retained',runtime_admission_predicates_added=0,actual_qemu_control='Loader and paired module/control integration follow this kernel build')
 if p.returncode==0:
  E=R/'kprog/arm64/build/frame-link';E.mkdir(exist_ok=True)
  import shutil
  shutil.copy2(K/'cache/arch/arm64/boot/Image',E/'Image');report['image_sha256']=hashlib.sha256((E/'Image').read_bytes()).hexdigest()
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as t:
  for n in ['verifier.before.c','verifier.c','plan.json','Makefile','inside-kernel.sh','build-controller.py']:t.add(K/n,arcname=n)
 (O/'README.md').write_text('Ordinary BPF proof-body kernel integration prototype\n\nThe stock verifier discovers ordinary B subprograms after expansion. Entry EXIT stays before ordinary callees. The last callee EXIT supplies the original native-stub terminal EXIT after proof collapse; proof-only function metadata follows the expanded code lifetime. Existing verifier rules decide the expanded B. This prototype introduces0 runtime admission predicates. The build incrementally reuses a private clone of the paired e2d3warm cache. Kernel build exit'+str(p.returncode)+'. Exact source and raw build log are retained. Paired module/loader and the existing rawXDPwidth/alignment QEMU control follow.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);rec=pub.publish([str((O/n).relative_to(R)) for n in ['build.json','kernel.log.gz','inputs.tar.gz','README.md']],'Build ordinary BPF proof subprogram kernel integration incrementally','arm-frame-link-kernel-build');(K/'publication.json').write_text(json.dumps(rec,indent=2)+'\n');save('finished',build_exit=p.returncode,publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+rec['commit']+' privateordinaryBPFproof-body kernelbuildexit'+str(p.returncode)+'. Stock subprog discovery afterBexpansion/ordinaryEXITlayout/proof-onlymetadata lifetime. Actualmodule/loader/QEMUcontrol follow; sharedcanonicalkernel andactiveImagecopies retained. Warmpairedcachecloned8GiB andincrementalbuild8-11; runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
