from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;F=G.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tracee-shared-min/application';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def wait(p):
 try:
  fd=os.pidfd_open(int(p.read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('waiting_paired_source_build')
 wait(F/'controller.pid');build=json.loads((F/'status.json').read_text())
 build_publication=build['publication']['commit']
 I=F/'image';m=json.loads((G/'manifests/tracee.json').read_text())
 for r in m['objects']+m.get('data_objects',[]):
  p=Path(r['native_object']);candidate=I/'native'/p.name
  if candidate.exists():
   target=G/'source'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.unlink(missing_ok=True);os.link(candidate,target)
 target=G/'source/kprog/arm64/build/app-runtime-v35/root/artifacts/tracee/bin/tracee';target.parent.mkdir(parents=True,exist_ok=True);target.unlink(missing_ok=True);os.link(I/'tracee',target)
 before=dict(utc=now(),build_publication=build_publication,native_objects={r['native_object']:hashlib.sha256((G/'source'/Path(r['native_object']).relative_to(R)).read_bytes()).hexdigest() for r in m['objects']},embedded_binary_sha256=hashlib.sha256((I/'tracee').read_bytes()).hexdigest(),paired_bpf_sha256=hashlib.sha256((I/'tracee.bpf.o').read_bytes()).hexdigest(),predecessor='mode-corrected same-copy BCC/Katran serial apps',scope='Full original Tracee recipe; all existing native manifest entries and paired embedded BPF retained;88-helper model;8GiB16-19',runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(before,indent=2)+'\n')
 (O/'README.md').write_text('Complete paired-source ARM Tracee\n\nThe original Tracee recipe and workload run with the complete native manifest and paired 20096bb3c source artifacts. Both C frontends retain the recorded source edits and original size bounds; the new ARM binary embeds the paired JIT object. Native P uses canonical O3 flags, the88-helper ARM model8eac3b42a and same-copy dc120a8eb ARM loader ba6e31c1 public-helper route. QEMU8GiB/eightvCPU16-19 follows the mode-corrected same-copy BCC/Katran serial apps through pidfd. Same-copy runtime source and all input hashes are captured. Runtime admission additions:0.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for root in [G/'source',G/'manifests']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
  for n in ['Makefile','mount.py','transport.py','controller.py']:tf.add(G/n,arcname=n)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','README.md','launch-inputs.tar.gz']],'Queue the complete paired-source ARM Tracee application','arm-tracee-shared-min-app-launch')
 save('queued_after_same_copy_apps',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' complete paired ARM Tracee queuedaftersame-copyBCC/Katran,16-19/8GiB. Native/JIT/source 20096bb3c and originalwholemanifest/workload captured; baselinebinary embeds pairedJIT. Model88helpers8eac source fixed. Runtime admission additions0.\n')
 wait(A/'same-copy-arm/replays-mode-corrected/controller.pid')
 save('actual_application',publication=rec,application='tracee')
 with (G/'tracee.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),'tracee'],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=O/'trusted-arm64-tracee-result';Q.mkdir(exist_ok=True);(Q/'driver.log.gz').write_bytes(gzip.compress((G/'tracee.log').read_bytes(),mtime=0));paths=[Q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (Q/'summary.json').exists():
  d=json.loads((Q/'summary.json').read_text());archive=Q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](d,archive);paths.extend([Q/'summary.json',archive])
 (Q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(Q/'coverage.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the complete paired-source ARM Tracee application','arm-tracee-shared-min-app-result')
 save('finished',publication=rec,make_exit=p.returncode)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' complete ARM Tracee pairedsource outcome Makeexit'+str(p.returncode)+'. Every native/service/verifier/work outcome retained; original workload completeattempt. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
