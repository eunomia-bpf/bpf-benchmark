from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-source-length/application-v61';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
rec={'commit': '94a48967b17f38b73334b22859374d6fcee46d10', 'remote_ancestor_verified': True}
try:
 save('actual_application_ready',publication=rec);notice('PUSHED '+rec['commit']+' paired-source whole Tetragon V61 native/JIT replay; both edits and complete original workload captured. Source a9abb84e5, actual updated bytecode selectors and current canonical loader/linker;16-19/8GiB. Runtime admission additions0.')
 results={}
 for app in ['tetragon']:
  save('actual_application',application=app,closed=results)
  with (G/(app+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  q=O/('trusted-arm64-'+app+'-result');q.mkdir(exist_ok=True)
  (q/'driver.log.gz').write_bytes(gzip.compress((G/(app+'.log')).read_bytes(),mtime=0))
  paths=[q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
  if (q/'summary.json').exists():
   d=json.loads((q/'summary.json').read_text());archive=q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](d,archive);paths.extend([q/'summary.json',archive])
  (q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(q/'coverage.json')
  rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM '+app+' paired-source outcomes','arm-tetragon-v61-app-'+app+'-result')
  results[app]=dict(make_exit=p.returncode,publication=rec)
  notice('PUSHED '+rec['commit']+' complete ARM '+app+' paired-source terminal attempt, Makeexit'+str(p.returncode)+'. Every service outcome and raw application work counter retained; serial queue continues.')
 save('finished',results=results)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
