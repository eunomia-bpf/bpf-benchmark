from pathlib import Path
import datetime,gzip,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-source-length/v61-component';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Actual-selected V61 paired source ARM component\n\nBoth original native and upstream BPF resource objects use the same edited process.h/bpf_d_path.h/main C bytes from3b9a5561f. V61 keeps original2048path iterations and helper/iterator choices. Actual RAW helper contextae04d80a6, source0 libbpf map/BTF preparation and object-default global values feed this load-only component. The complete real-application phase remains separate. Runtime admission additions0.\n')

 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch-inputs.tar.gz']],'Replay the actual-selected Tetragon V61 from paired source','arm-paired-v61-component-launch')
 save('actual_source_component',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the paired Tetragon V61 ARM component outcome','arm-paired-v61-component-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' actual-selected paired V61 component actual '+json.dumps(report.get('counts'))+'. Complete same-source baseline resources/native input and original object-default globals captured; whole-application acceptance retains separate work phase. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
