from pathlib import Path
import json,subprocess,sys
F=Path(__file__).resolve().parent
cmd=json.loads((F/'v61-native-command.json').read_text())['command']
with (F/'v61-native.stdout').open('w') as o,(F/'v61-native.stderr').open('w') as e:p=subprocess.run(cmd,stdout=o,stderr=e)
(F/'v61-native-command.json').write_text(json.dumps(dict(command=cmd,returncode=p.returncode),indent=2)+'\n')
sys.exit(p.returncode)
