from pathlib import Path
import os,subprocess,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'baseline-source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/'vendor/repos/tetragon'/p.relative_to(F/'baseline-source'))],check=True)
os.execv(sys.executable,[sys.executable,str(F/'v61-baseline-compile.py')])
