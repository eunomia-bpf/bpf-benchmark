from pathlib import Path
import datetime,json,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
cmd=json.loads((F/'length-native-command.json').read_text())['command']
cmd=[x.replace('bpf_execve_event_v511.native.o','bpf_execve_event_v61.native.o') for x in cmd]
cmd.insert(cmd.index('-D__V511_BPF_PROG')+1,'-D__V61_BPF_PROG')
(F/'v61-native-command.json').write_text(json.dumps(dict(command=cmd),indent=2)+'\n')
(F/'v61-compile.py').write_text("from pathlib import Path\nimport json,subprocess,sys\nF=Path(__file__).resolve().parent\ncmd=json.loads((F/'v61-native-command.json').read_text())['command']\nwith (F/'v61-native.stdout').open('w') as o,(F/'v61-native.stderr').open('w') as e:p=subprocess.run(cmd,stdout=o,stderr=e)\n(F/'v61-native-command.json').write_text(json.dumps(dict(command=cmd,returncode=p.returncode),indent=2)+'\\n')\nsys.exit(p.returncode)\n")
(F/'v61-native-mount.py').write_text((F/'length-mount.py').read_text().replace('length-compile.py','v61-compile.py'))
old=(F/'baseline-compile.py').read_text().replace('bpf_execve_event_v511','bpf_execve_event_v61').replace('baseline-v511','baseline-v61').replace('baseline-command.json','v61-baseline-command.json')
(F/'v61-baseline-compile.py').write_text(old)
(F/'v61-baseline-mount.py').write_text((F/'baseline-mount.py').read_text().replace('baseline-compile.py','v61-baseline-compile.py'))
rows=[]
for script in ['v61-native-mount.py','v61-baseline-mount.py']:
 with (F/(script+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(script=script,returncode=p.returncode));(F/'v61-build-status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=rows),indent=2)+'\n')
