from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-source-length/application';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in {'controller.log','status.json'}:tf.add(p,arcname=str(p.relative_to(G)))
 (O/'README.md').write_text('Complete Tetragon ARM replay from paired application source\n\nThe actual V511 execve object selected by the retained application recipe uses both recorded source edits: counted path loop and existing bounded local read length. The upstream JIT BPF object and native input compile the same edited process.h, bpf_d_path.h and main C bytes. Other application objects keep their captured sources. Every existing native manifest entry remains selected; bytecode length metadata for the rebuilt object comes from the existing source-program scanner. The complete two-start workload and work-counter collection use the retained recipe. Runtime source and canonical deployed loader/linker match the resource-prepare component; the paired88a Image/module stays incremental. QEMU8GiB/eightvCPU16-19 supplies functional timing. The first host bootstrap kept the original control fixture path while the executable path advanced to the canonical loader; its driver outcome is retained in bootstrap. The continuation uses the existing fixture at its original path. Runtime admission additions0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz','bootstrap/driver.log.gz','bootstrap/coverage.json']],'Run complete Tetragon ARM application from paired source','arm-tetragon-source-app-launch')
 save('actual_application_ready',publication=rec);notice('PUSHED '+rec['commit']+' paired-source whole Tetragon V511 native/JIT replay; both edits and complete original workload captured. Source a9abb84e5, actual updated bytecode selectors and current canonical loader/linker;16-19/8GiB. Runtime admission additions0.')
 results={}
 for app in ['tetragon']:
  save('actual_application',application=app,closed=results)
  with (G/(app+'.log')).open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  q=O/('trusted-arm64-'+app+'-result');q.mkdir(exist_ok=True)
  (q/'driver.log.gz').write_bytes(gzip.compress((G/(app+'.log')).read_bytes(),mtime=0))
  paths=[q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
  if (q/'summary.json').exists():
   d=json.loads((q/'summary.json').read_text());archive=q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](d,archive);paths.extend([q/'summary.json',archive])
  (q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(q/'coverage.json')
  rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM '+app+' paired-source outcomes','arm-tetragon-source-app-'+app+'-result')
  results[app]=dict(make_exit=p.returncode,publication=rec)
  notice('PUSHED '+rec['commit']+' complete ARM '+app+' paired-source terminal attempt, Makeexit'+str(p.returncode)+'. Every service outcome and raw application work counter retained; serial queue continues.')
 save('finished',results=results)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
