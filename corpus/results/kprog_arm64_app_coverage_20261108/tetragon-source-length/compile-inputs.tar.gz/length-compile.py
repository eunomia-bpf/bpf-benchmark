from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
old=json.loads((F/'commands.json').read_text())
cmd=next(r['command'] for r in old if r['label']=='native-v511')
with (F/'length-native.stdout').open('w') as o,(F/'length-native.stderr').open('w') as e:p=subprocess.run(cmd,cwd=R,stdout=o,stderr=e)
(F/'length-native-command.json').write_text(json.dumps(dict(command=cmd,returncode=p.returncode),indent=2)+'\n')
