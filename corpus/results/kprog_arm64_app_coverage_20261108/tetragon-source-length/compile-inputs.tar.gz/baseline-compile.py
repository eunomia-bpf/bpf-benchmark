from pathlib import Path
import json,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
p=F/'bpf/bpf_execve_event_v511.o'
cmd=['make','--no-print-directory','-C',str(R/'vendor/repos/tetragon/bpf'),'CLANG=/usr/lib/llvm-18/bin/clang','LLC=/usr/lib/llvm-18/bin/llc','BPF_TARGET_ARCH=arm64','OBJSDIR='+str(F/'bpf')+'/','DEPSDIR='+str(F/'baseline-deps')+'/',str(p),'-j2']
with (F/'baseline-v511.stdout').open('w') as o,(F/'baseline-v511.stderr').open('w') as e:r=subprocess.run(cmd,cwd=R,stdout=o,stderr=e)
(F/'baseline-command.json').write_text(json.dumps(dict(command=cmd,returncode=r.returncode),indent=2)+'\n')
