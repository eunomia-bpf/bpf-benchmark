from pathlib import Path
import subprocess,os,json,hashlib,datetime
R=Path('/workspaces/repository');N=Path(__file__).resolve().parent
command=['taskset','-c','16-19','qemu-system-aarch64','-M','virt','-cpu','max','-smp','2','-m','2048','-nographic','-no-reboot','-kernel',str(R/'vendor/build/arm64/linux/arch/arm64/boot/Image'),'-fsdev','local,id=rootfs,path='+str(R/'kprog/arm64/build/app-runtime-v35/root')+',security_model=none,readonly=on','-device','virtio-9p-device,fsdev=rootfs,mount_tag=rootfs','-fsdev','local,id=lane,path='+str(N)+',security_model=none','-device','virtio-9p-device,fsdev=lane,mount_tag=lane','-append','console=ttyAMA0 root=rootfs rootfstype=9p rootflags=trans=virtio,version=9p2000.L ro init=/bin/sh loglevel=4 panic=-1 oops=panic']
inputs=json.loads((N/'input-pins.json').read_text());inputs['vendor/build/arm64/linux/arch/arm64/boot/Image']=hashlib.sha256((R/'vendor/build/arm64/linux/arch/arm64/boot/Image').read_bytes()).hexdigest()
(N/'qemu-inputs.json').write_text(json.dumps(dict(command=command,inputs=inputs),indent=2)+'\n')
script='mount -t proc proc /proc; mount -t sysfs sysfs /sys; mount -t tmpfs tmpfs /run; mkdir -p /run/lane; mount -t 9p -o trans=virtio lane /run/lane; sh /run/lane/guest.sh; rc=$?; echo $rc > /run/lane/guest.exit; sync; echo o > /proc/sysrq-trigger\n'
p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(N/'qemu.pid').write_text(str(p.pid)+'\n');sent=False;tail=b''
with (N/'console.log').open('wb') as log:
 while True:
  chunk=os.read(p.stdout.fileno(),8192)
  if not chunk:break
  log.write(chunk);log.flush();tail=(tail+chunk)[-4096:]
  if not sent and tail.endswith(b'# '):p.stdin.write(script.encode());p.stdin.flush();sent=True
 rc=p.wait()
status=dict(qemu_exit=rc,commands_sent=sent,guest_exit=int((N/'guest.exit').read_text()) if (N/'guest.exit').exists() else None,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(N/'qemu-result.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status));raise SystemExit(0 if status['guest_exit']==0 and rc==0 else 1)
