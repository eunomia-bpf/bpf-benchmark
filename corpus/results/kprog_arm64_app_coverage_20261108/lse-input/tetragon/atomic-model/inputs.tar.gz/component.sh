#!/bin/sh
cd /workspaces/repository
taskset -c 16-19 unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/design-only/lse-input/tetragon/candidate-inside.sh component > /workspaces/.agent-state/kprog-lanes/A/design-only/lse-input/tetragon/component.log 2>&1
printf '%s\n' "$?" > /workspaces/.agent-state/kprog-lanes/A/design-only/lse-input/tetragon/component.exit
