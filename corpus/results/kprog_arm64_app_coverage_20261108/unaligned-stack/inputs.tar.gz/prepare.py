from pathlib import Path
import hashlib,json,datetime
A=Path('/workspaces/.agent-state/kprog-lanes/A');N=A/'unaligned-stack';H=A/'xdp-byte-helpers';R=Path.cwd();h='kprog/arm64/arm64_sim_local_bpf.h';before=(N/'before.h').read_text()
i=before.index('#define ARM64_SIM_L_STACK_READ(');a=before.index('\t\t\t__a64_str_value =',before.index('} else {',i));b=before.index('\t\t}',a)
lines=['\t\t\t__a64_str_value = (__u64)__a64_stack.b[__a64_str_index];']
for i in range(1,8):
 w=16 if i==1 else 32 if i<4 else 64
 lines+=['\t\t\tif (__a64_str_width >= ARM64_WIDTH_'+str(w)+')','\t\t\t\t__a64_str_value |= (__u64)__a64_stack.b[__a64_str_index + '+str(i)+'] << '+str(i*8)+';']
after=before[:a]+''.join(l+chr(92)+'\n' for l in lines)+before[b:];(N/'after.h').write_text(after);(N/'source'/h).write_text(after)
rows=['.text','.global trusted_entry','.type trusted_entry,%function','trusted_entry:','sub sp,sp,#32']
def mov(reg,val):return ['movz '+reg+',#'+str(val&65535)]+['movk '+reg+',#'+str((val>>s)&65535)+',lsl #'+str(s) for s in [16,32,48] if (val>>s)&65535]
pattern=0x8877665544332211;rows+=mov('x10',pattern)+['stp x10,x10,[sp]','stp x10,x10,[sp,#16]']
for width,op,reg in [(1,'ldurb','w8'),(2,'ldurh','w8'),(4,'ldur','w8'),(8,'ldur','x8')]:
 for offset in range(8):
  expect=int.from_bytes((pattern.to_bytes(8,'little')*3)[offset:offset+width],'little');rows+=[op+' '+reg+',[sp,#'+str(offset)+']']+mov('x9',expect)+['cmp x8,x9','b.ne bad']
rows+=['mov w0,#2','b done','bad:','mov w0,#1','done:','add sp,sp,#32','ret','.size trusted_entry,.-trusted_entry','.section .note.GNU-stack,"",@progbits'];(N/'width-alignments.S').write_text('\n'.join(rows)+'\n')
transport=(H/'app-otelcol-ebpf-profiler-transport.py').read_text();transport=transport.replace('"-smp", "8", "-m", "8192"','"-smp", "2", "-m", "2048"').replace("'-smp', '8', '-m', '8192'","'-smp', '2', '-m', '2048'")
(N/'transport.py').write_text(transport)
srcs=sorted(str(p.relative_to(N/'source')) for p in (N/'source').rglob('*') if p.is_file())
for case in ['before','after']:
 mounts=['mount --bind '+str(N/'source'/p)+' '+str(R/p) for p in srcs];mounts+=['mount --bind '+str(N/(case+'.h'))+' '+str(R/h),'mount --bind '+str(N/'transport.py')+' '+str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py'),'mount --bind '+str(N/'width-alignments.native.o')+' '+str(R/'kprog/libnativeloader/build-arm64-kfunc-resources/trusted-native.o')]
 out=R/'corpus/results/kprog_arm64_app_coverage_20261108/unaligned-stack'/case
 (N/(case+'.sh')).write_text('set -eu\n'+'\n'.join(mounts)+'\nexec make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=control TRUSTED_RESULTS='+str(out)+'\n')
tests=[p for p in (R/'kprog/formal/oracles').glob('test_arm64*host.c') if any(s in p.name for s in ['stack_arm_route','stack_write_lanes_route','stack_read_tag_source_route','stack_arena_route','dynamic_memory','memory_pair_route'])]
recipe=['ROOT := '+str(R),'HERE := '+str(N),'.PHONY: check fixtures','fixtures:','\taarch64-linux-gnu-gcc -c $(HERE)/width-alignments.S -o $(HERE)/width-alignments.native.o','check:','\tcd $(ROOT)/kprog/formal && python3 ../arm64/generate_sim_dispatch.py --check']
for p in tests:
 exe=p.stem;recipe+=['\tcd $(ROOT)/kprog/formal && cc -O2 -Wall -Wextra -fsanitize=undefined -fno-sanitize-recover=all -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/'+p.name+' -o $(HERE)/'+exe,'\t$(HERE)/'+exe]
(N/'Makefile').write_text('\n'.join(recipe)+'\n');(N/'check.sh').write_text('set -eu\n'+'\n'.join('mount --bind '+str(N/'source'/p)+' '+str(R/p) for p in srcs)+'\nexec make -f '+str(N/'Makefile')+' check fixtures\n')
plan=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),trigger_commit='1d63beebe3330d53d9a54a6ea5758a51d0f34c80',cause='Native LDUR unaligned stack windows lower to wide BPF stack accesses at offsets29/21/45.',scope='The existing stack selector byte arm reads each selected volatile byte and assembles the established little-endian value. Aligned whole-word pointer spills retain their word arm.',source_pins={p:hashlib.sha256((N/'source'/p).read_bytes()).hexdigest() for p in srcs},host_tests=[p.name for p in tests]);(N/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+plan['utc']+': wholeOTel8GiB closed1d63beebe:1bound/secondcompiled, verifier detects wideunalignedstackload atnativeLDUR offsets29/21/45. Originalskb nowadoptedaed0d2b57. A privategenericstack byte-arm candidate preservesalignedword spills and emitsactualvolatilebytes; existinghostroutes +same32width/alignment nativecontrol before/after follow16-19. ActiveH/Psourceepochs retaintheirhashes; productionadoption follows Hcanonicalhelperpromotion.\n')
print('source',len(srcs),'hosts',plan['host_tests'])
