from pathlib import Path
import ast,datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback,io
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261108/unaligned-stack';state={}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(utc=now(),phase=phase,**kw);(N/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
try:
 assert (N/'check.exit').read_text().strip()=='0';plan=json.loads((N/'plan.json').read_text());pub=load('stack_pub',A/'six-app-publish.py');results={}
 for p,h in plan['source_pins'].items():assert sha(N/'source'/p)==h,p
 tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
  nodes.append(node)
 scope={'__name__':'stack_control_review'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'stack_control_review','exec'),scope)
 for case in ['before','after']:
  save('actual_'+case,results=results)
  with (N/(case+'.log')).open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/(case+'.sh'))],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  F=D/case/'trusted-arm64-service-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];audit=load('stack_identity',A/'context-native-collector.py').inspect(summary,archive,'control');coverage=scope['coverage'](summary,archive)
  assert not audit['identity_errors'],audit
  with tarfile.open(archive) as t:
   errors=[]
   for member in t.getmembers():
    if member.name.endswith('.failure.tar.gz'):
     with tarfile.open(fileobj=io.BytesIO(t.extractfile(member).read())) as q:
      errors.append(q.extractfile('request/load.stderr').read().decode())
  expected=done.returncode==0 and summary['ok'] and coverage['stages']=={'bound_accepted':1} if case=='after' else (not summary['ok'] and any('misaligned stack access' in e for e in errors))
  (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/(case+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Generic stack load width/alignment '+case+' control\n\nThe same native fixture checks four widths across all eight byte alignments against independently assembled expected values. Fresh kernel-owned generation, compiler, verifier and binding outcomes are '+json.dumps(coverage['stages'])+'. Host success '+str(summary['ok'])+'; expected component outcome '+str(expected)+'. Complete source/native/request/compiler/verifier records accompany this result.\n')
  receipt=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Exercise generic ARM stack load width and alignment '+case,'arm-stack-byte-'+case);results[case]=dict(commit=receipt['commit'],host_ok=summary['ok'],stages=coverage['stages'],expected=expected);save('closed_'+case,results=results);assert expected,results[case]
 D.mkdir(exist_ok=True);patch=subprocess.run(['diff','-u','--label','a/kprog/arm64/arm64_sim_local_bpf.h','--label','b/kprog/arm64/arm64_sim_local_bpf.h',str(N/'before.h'),str(N/'after.h')],capture_output=True);assert patch.returncode==1;(D/'source.patch.gz').write_bytes(gzip.compress(patch.stdout,mtime=0))
 summary=dict(utc=now(),trigger_commit=plan['trigger_commit'],source_pins=plan['source_pins'],host_tests=plan['host_tests'],host_exit=0,generic_width_alignment_cases=32,controls=results,production_status='Candidate promotion follows the active H canonical helper epoch; private whole OTel consumes this frozen byte-arm profile.',interfaces='Aligned word/pointer spill arm, provenance selector and raw context loads retain their existing contracts.')
 (D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 with tarfile.open(D/'inputs.tar.gz','w:gz') as t:
  for name in ['source','before.h','after.h','plan.json','prepare.py','Makefile','check.sh','check.log','check.exit','width-alignments.S','width-alignments.native.o','transport.py','before.sh','after.sh','run.py']:t.add(N/name,arcname=name)
 (D/'README.md').write_text('Generic ARM stack byte-arm lowering\n\nWhole OTel8GiB cohort1d63beebe reaches verifier stack-alignment checks after two fresh compilations and one binding. Native LDUR reads offsets29/21/45; the old byte arm emits wide BPF stack accesses. The candidate assembles each selected volatile stack byte into the established little-endian value. The aligned whole-word/pointer spill arm and provenance selector retain their contracts.\n\nFour existing UBSan stack routing/tag/arena/write hosts pass. A single generic native control spans four widths and eight byte alignments: the prior source reaches the verifier alignment refusal, and the candidate freshly generates, compiles, verifies, binds and executes with retval2. Both raw cohorts retain exact source/native/compiler/request identities. The source patch and complete80-source private profile accompany this result. Generic34 safety and complete OTel consumption continue through the captured successor.\n')
 receipt=pub.publish([str((D/n).relative_to(R)) for n in ['source.patch.gz','summary.json','inputs.tar.gz','README.md']],'Read unaligned ARM stack windows through their byte lanes','arm-stack-byte-component');(N/'publication.json').write_text(json.dumps(receipt,indent=2)+'\n');save('component_published',publication=receipt);notice('PUSHED '+receipt['commit']+' ARMgenericstackbyte-arm candidate:4existingUBSanhosts0/same32width-alignment control oldverifierrefusal andnewfreshgen/compile/bound/native2. Alignedwordspills/provenance/rawctxcontracts retained; captured80-source epochs retained. Generic34suite follows16-19; productionafterHcanonicalhelperpromotion.')
 subprocess.run(['python3',str(N/'full-run.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},check=True);save('safety_finished',safety=json.loads((N/'full-status.json').read_text()))
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
