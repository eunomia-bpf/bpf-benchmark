.PHONY: run
run:
	python3 /workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp/replay.py host --out /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261108/unaligned-stack/safety
