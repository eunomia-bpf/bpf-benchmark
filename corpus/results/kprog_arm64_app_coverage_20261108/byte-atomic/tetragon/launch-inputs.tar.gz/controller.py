from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/byte-atomic/tetragon';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('capturing_launch')
 (O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in {'controller.log','status.json'}:tf.add(p,arcname=str(p.relative_to(G)))
 (O/'README.md').write_text('Complete ARM Tetragon replay on the byte-atomic source\n\nThe original Tetragon two-start recipe retains every native manifest entry and its actual map matching. This epoch carries the published exact-width byte atomics and paired Image/module, with8vCPUs/8GiB on16-19. launch.json and launch-inputs.tar.gz retain all source and transport identities. Raw terminal archives carry application work and every generated/compiled/stock-verifier request outcome. QEMU timing supplies functional evidence. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run complete ARM Tetragon with exact-width byte atomics','arm-byte-tetragon-launch')
 save('actual_tetragon',publication=rec);notice('PUSHED '+rec['commit']+' complete original Tetragon replay on byte-atomic042ae2e50 source; original native manifest/map matching and two-start work retained,8GiB/eightvCPU16-19. Exact paired Image/module and source archived. Runtime admission additions0.')
 with (G/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (O/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0))
 paths=[O/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 q=O/'trusted-arm64-tetragon-result'
 if (q/'summary.json').exists():
  d=json.loads((q/'summary.json').read_text());archive=q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](d,archive);paths.extend([q/'summary.json',archive])
 (O/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'coverage.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM Tetragon byte-atomic workload and verifier outcomes','arm-byte-tetragon-result')
 save('finished',make_exit=p.returncode,publication=rec);notice('PUSHED '+rec['commit']+' complete ARM Tetragon byte-atomic terminal attempt; Makeexit'+str(p.returncode)+'. Raw application counters and every service outcome retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
