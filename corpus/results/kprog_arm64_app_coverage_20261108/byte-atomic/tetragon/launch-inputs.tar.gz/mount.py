from pathlib import Path
import os,subprocess
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((G/'source').rglob('*')):
 if p.is_file(): subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
for src,dst in [(G/'transport.py',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py'),(G/'live-manifest.json',R/'kprog/arm64/build/app-verified-stage/tetragon/manifest.json')]:
 subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
os.execvp('make',['make','-f',str(G/'Makefile'),'application'])
