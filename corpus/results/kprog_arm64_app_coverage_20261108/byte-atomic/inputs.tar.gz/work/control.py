from pathlib import Path
import importlib.util
R=Path("/workspaces/repository")
p=R/"kprog/arm64/build/byte-atomic/control.py"
s=importlib.util.spec_from_file_location("byte_control",p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.host("control",str(R/"corpus/results/kprog_arm64_app_coverage_20261108/byte-atomic/control-final"))
