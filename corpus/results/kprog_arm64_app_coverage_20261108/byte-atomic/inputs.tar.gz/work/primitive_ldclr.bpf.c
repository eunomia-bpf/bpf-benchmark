#include "/workspaces/.agent-state/kprog-lanes/A/byte-atomic/arm64_sim_local_bpf.h"
SEC("xdp") int byte_ldclr(struct xdp_md *ctx) { __u8 word=7; __u8 old=bpf_arm64_native_lab_atomic8(&word,~(__u64)(ctx->ingress_ifindex+3),2,__ATOMIC_ACQ_REL); return ((ctx->ingress_ifindex & 255U)<<16)|((__u32)old<<8)|word; }
char LICENSE[] SEC("license")="GPL";
