#include "/workspaces/.agent-state/kprog-lanes/A/byte-atomic/arm64_sim_local_bpf.h"
SEC("xdp") int byte_ldset(struct xdp_md *ctx) { __u8 word=7; __u8 old=bpf_arm64_native_lab_atomic8(&word,ctx->ingress_ifindex+3,1,__ATOMIC_ACQ_REL); return old+word; }
char LICENSE[] SEC("license")="GPL";
