set -e
cd /workspaces/repository
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/byte-atomic/inside-byte-kernel.sh > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/kernel.log 2>&1
printf "0\n" > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/kernel.exit
cp /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/kernel-link/cache/arch/arm64/boot/Image /workspaces/repository/kprog/arm64/build/byte-atomic/Image
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/byte-atomic/inside-module.sh > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/module-mixed.log 2>&1
cp /workspaces/.agent-state/kprog-lanes/A/byte-atomic/module-output/bpf_arm64_native_lab.ko /workspaces/repository/kprog/arm64/build/byte-atomic/kinsn/bpf_arm64_native_lab.ko
printf "0\n" > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/module-mixed.exit
make -f /workspaces/.agent-state/kprog-lanes/A/byte-atomic/Makefile control > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/control-descriptor.log 2>&1
