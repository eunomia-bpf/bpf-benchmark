cd /workspaces/repository
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/byte-atomic/inside-module.sh > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/module-paired.log 2>&1
rc=$?
printf "%s\n" "$rc" > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/module-paired.exit
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
cp /workspaces/.agent-state/kprog-lanes/A/byte-atomic/module-output/bpf_arm64_native_lab.ko /workspaces/repository/kprog/arm64/build/byte-atomic/kinsn/bpf_arm64_native_lab.ko
make -f /workspaces/.agent-state/kprog-lanes/A/byte-atomic/Makefile observe > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/observe-paired.log 2>&1
rc=$?
printf "%s\n" "$rc" > /workspaces/.agent-state/kprog-lanes/A/byte-atomic/observe-paired.exit
exit "$rc"
