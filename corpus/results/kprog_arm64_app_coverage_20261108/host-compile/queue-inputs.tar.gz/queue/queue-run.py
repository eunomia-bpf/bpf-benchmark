from pathlib import Path
import datetime,hashlib,json,os,select,signal,shutil,subprocess,tarfile,time,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;H=A/'xdp-byte-helpers'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(N/'queue-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def wait(pid):
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:return
 try:select.select([fd],[],[])
 finally:os.close(fd)
try:
 save('waiting_host_compiler_native_controls',pid=int((N/'full-run.pid').read_text()));control=json.loads((N/'full-status.json').read_text())
 if control['phase']!='finished':wait(int((N/'full-run.pid').read_text()));control=json.loads((N/'full-status.json').read_text())
 assert control['phase']=='finished';out=control['outcome'];assert out['host_ok'] and out['cases']==34 and out['unsafe_accepted']==0 and out['unsafe_executed']==0 and out['compiler_exit']['returncode']==0
 assert out['compiler_jobs'] and all('-O2' in j['command'] and '-D__TARGET_ARCH_arm64' in j['command'] for j in out['compiler_jobs'])
 pid=226427;status=json.loads((H/'app-status.json').read_text())
 if status['phase']!='waiting_original_epoch':save('current_serial_epoch_active',status=status,host_compiler_safety_commit=control['publication']['commit']);exit()
 command=Path('/proc/'+str(pid)+'/cmdline').read_bytes();assert str(H/'app-run.py').encode() in command
 fd=os.pidfd_open(pid);os.kill(pid,signal.SIGSTOP)
 try:
  while Path('/proc/'+str(pid)+'/stat').read_text().split(') ')[1].split()[0] not in ['T','t']:time.sleep(.01)
  status=json.loads((H/'app-status.json').read_text());assert status['phase']=='waiting_original_epoch' and status['waiting_pid']==4109581;assert Path('/proc/'+str(pid)+'/task/'+str(pid)+'/children').read_text().strip()==''
  archive=R/'corpus/results/kprog_arm64_app_coverage_20261107/xdp-byte-helpers/app-launch-inputs.tar.gz'
  with tarfile.open(archive) as t:
   for m in t:
    if m.isfile():assert t.extractfile(m).read()==(H/Path(m.name).relative_to('launch')).read_bytes(),m.name
  shutil.copy2(archive,N/'superseded-app-launch.tar.gz');retired=dict(pid=pid,status=status,command=command.decode().replace(chr(0),' '),archive_sha256=sha(archive),launch_commit=status['launch_commit'],utc=now());(N/'retired-controller.json').write_text(json.dumps(retired,indent=2)+'\n')
 except BaseException:os.kill(pid,signal.SIGCONT);os.close(fd);raise
 os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT);select.select([fd],[],[]);os.close(fd)
 plan=json.loads((H/'app-plan.json').read_text());plan['retired_helper_controllers']=plan.get('retired_helper_controllers',[])+[retired];plan['host_compile_component_commit']=json.loads((N/'publication.json').read_text())['commit'];plan['host_compile_safety_commit']=control['publication']['commit']
 checked=json.loads((N/'full-plan.json').read_text());plan['source_pins']=checked['source_pins'];assert plan['predecessor_pid']==4109581
 for q in sorted((N/'source').rglob('*')):
  if q.is_file():p=H/'app-source'/q.relative_to(N/'source');p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,p)
 profile=json.loads((N/'plan.json').read_text())
 for p,h in profile['sysroot_header_pins'].items():plan['binary_and_manifest_pins'][profile['sysroot']+'/'+p]=h
 manifest=R/'kprog/arm64/build/app-verified-stage/otelcol-ebpf-profiler/manifest.json';objects=json.loads(manifest.read_text());extra=[manifest,R/'kprog/arm64/build/app-runtime-v35/root/usr/local/bin/otelcol-ebpf-profiler',R/'runner/libs/app_runners/otel_profiler.py']
 for row in objects['objects']+objects.get('data_objects',[]):extra.append((manifest.parent/row['native_object']).resolve())
 for p in extra:plan['binary_and_manifest_pins'][str(p.relative_to(R))]=sha(p)
 for app in ['cilium','tracee','otelcol-ebpf-profiler']:
  shutil.copy2(N/('next-'+app+'-transport.py'),H/('app-'+app+'-transport.py'))
  s=(N/'next-otelcol-ebpf-profiler.sh').read_text() if app=='otelcol-ebpf-profiler' else (H/('app-'+app+'.sh')).read_text();at=s.index('exec make -f');s=s[:at]+''.join('mount --bind '+str(H/'app-source'/p)+' '+str(R/p)+chr(10) for p in ['kprog/trusted_compile.py','kprog/arm64/trusted_specializer.py'])+s[at:];(H/('app-'+app+'.sh')).write_text(s);subprocess.run(['sh','-n',str(H/('app-'+app+'.sh'))],check=True)
 shutil.copy2(N/'next-app-run.py',H/'app-run.py');plan.pop('safety_fixture_pins',None);(H/'app-plan.json').write_text(json.dumps(plan,indent=2)+'\n');(H/'app-status.json').write_text(json.dumps(dict(utc=now(),phase='starting_host_compiler_successor',retired_pid=pid),indent=2)+'\n')
 with (H/'app-launch.log').open('wb') as log:p=subprocess.Popen(['setsid','nohup','python3',str(H/'app-run.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 (H/'app-run.pid').write_text(str(p.pid)+'\n');save('successor_started',pid=p.pid,source_files=len(plan['source_pins']),runtime_pins=len(plan['binary_and_manifest_pins']),host_compiler_safety_commit=control['publication']['commit'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': ARM13hostcompiler controls andactual34native-only safety consumed. Retired exactpublished waiting226427; solehostcompiler app successor'+str(p.pid)+' waitsoriginal4109581, then wholeCilium/Tracee/OTel8GiB/eightvCPU16-19. Source80/O2/2270sysrootheaders/newmodule9a andkernel-owned generation/verifier-binding retained. Newcontroller publishes capturedlaunch andeachterminalwholeapp outcome. OriginalOTel/skb runtime preserved.\n')
except BaseException as error:save('needs_continuation',error=str(error),traceback=traceback.format_exc());raise
