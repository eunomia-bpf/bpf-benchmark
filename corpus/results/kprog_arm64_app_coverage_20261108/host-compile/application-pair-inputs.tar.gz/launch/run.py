from pathlib import Path
import ast,datetime,gzip,hashlib,importlib.util,json,os,shutil,subprocess,tarfile,time,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261108/host-compile/applications';plan=json.loads((N/'plan.json').read_text());state={}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(utc=now(),phase=phase,**kw);(N/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def notice(text):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+text+'\n')
try:
 save('waiting_cilium_tracee_release',predecessor_status=plan['predecessor_status'])
 while True:
  try:prior=json.loads(Path(plan['predecessor_status']).read_text())
  except json.JSONDecodeError:time.sleep(.2);continue
  if prior.get('tracee_result_commit'):break
  if prior['phase']=='needs_continuation':raise RuntimeError('prior private application controller requires continuation')
  time.sleep(1)
 plan['prior_closed_cilium']=prior['cilium_result_commit'];plan['prior_closed_tracee']=prior['tracee_result_commit'];plan['release_utc']=now();(N/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 for p,h in plan['source_pins'].items():assert sha(N/'source'/p)==h,p
 for p,h in plan['binary_pins'].items():assert sha(R/p)==h,p
 pub=load('private_pair_pub',A/'six-app-publish.py')
 for app in plan['apps']:
  save('actual_'+app);notice('START complete ARM '+app+' matched hostO2/native-only replay8GiB/eightvCPU8-11 after closedCilium/Tracee; original16-19 epoch retained.')
  with (N/(app+'.log')).open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/(app+'.sh'))],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  F=D/app/('trusted-arm64-'+app+'-result');summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];identity=load('private_pair_identity',A/'context-native-collector.py').inspect(summary,archive,app)
  tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
  for node in tree.body:
   if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
   nodes.append(node)
  scope={'__name__':'private_pair_coverage'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'private_pair_coverage','exec'),scope);coverage=scope['coverage'](summary,archive)
  (F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'native-identity-audit.json').write_text(json.dumps(identity,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/(app+'.log')).read_bytes(),mtime=0));(F/'README.md').write_text('Complete ARM '+app+' two-start through the matched kernel/module/worker/hostO2 profile. Guest exit '+str(summary['guest_exit'])+', host status '+str(summary['ok'])+', Make exit '+str(done.returncode)+', stages '+json.dumps(coverage['stages'])+'. Source80, original native/application/workload inputs and private compiler readiness/exit/receipts retain their captured identities. Raw per-phase work and every service request accompany the cohort.\n')
  rec=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'coverage.json',F/'native-identity-audit.json',F/'driver.log.gz',F/'README.md']],'Retain complete ARM '+app+' matched host compiler coverage','arm-host-compiler-'+app+'-result');state[app+'_publication']=rec;save('closed_'+app,host_ok=summary['ok'],stages=coverage['stages']);notice('PUSHED '+rec['commit']+' complete ARM '+app+' guest='+str(summary['guest_exit'])+' stages='+json.dumps(coverage['stages'])+'; complete raw native/service/work/compiler identities retained. Generic class closure continues.')
 save('finished')
 source=N/'source';assert source.resolve()==(N/'source').absolute() and source.parent==N and not source.is_symlink();shutil.rmtree(source);(N/'source-retirement.json').write_text(json.dumps(dict(utc=now(),retired=str(source),source_pins=plan['source_pins'],launch_publication=json.loads((N/'launch-publication.json').read_text())['commit']),indent=2)+'\n')
except BaseException as error:save('needs_continuation',error=str(error),traceback=traceback.format_exc());raise
