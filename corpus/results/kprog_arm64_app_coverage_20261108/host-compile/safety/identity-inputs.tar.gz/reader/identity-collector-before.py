"""Collect only closed A guest results, audit captured native bytes, and publish exact paths."""
from pathlib import Path
from datetime import datetime, timezone
from elftools.elf.elffile import ELFFile
import fcntl, hashlib, io, json, os, re, select, subprocess, tarfile, traceback
ROOT=Path('/workspaces/repository')
A=Path('/workspaces/.agent-state/kprog-lanes/A')
OUT=ROOT/'corpus/results/kprog_arm64_app_coverage_20261106/trusted-bcc-frame-result/context-native'
STATUS=A/'context-native-collector.status.json'

def digest(data): return hashlib.sha256(data).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def read(ar,name):
    try:
        member=ar.getmember(name)
    except KeyError:
        return None
    if not member.isfile(): raise RuntimeError('expected regular archive member '+name)
    return ar.extractfile(member).read()
def request_audit(blob,receipt):
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as ar:
        native=read(ar,'request/kernel.native.o')
        generated=read(ar,'request/generated/request.native.o')
        entry=read(ar,'request/kernel.entry')
        if native is None or entry is None: raise RuntimeError('closed request lacks kernel native bytes or entry')
        entry=entry.decode().strip()
        with io.BytesIO(native) as stream:
            elf=ELFFile(stream)
            if elf['e_machine']!='EM_AARCH64': raise RuntimeError('native request is not AArch64')
            symbols=elf.get_section_by_name('.symtab').get_symbol_by_name(entry)
            if not symbols or not any(s['st_shndx']!='SHN_UNDEF' for s in symbols): raise RuntimeError('kernel entry not defined in captured ELF')
        wanted=receipt['native_sha256']
        if digest(native)!=wanted: raise RuntimeError('kernel native differs from receipt')
        if generated is not None and generated!=native: raise RuntimeError('generated native differs from kernel copy')
        artifacts={}
        for name in ['request/generated/trusted_arm64.proof.o','request/generated/trusted_arm64.bpf.o','request/generated/trusted_arm64.bpf.c','request/generation.metadata.json','request/kernel.facts.json','request/source-identities.json']:
            value=read(ar,name)
            if value is not None: artifacts[name]=digest(value)
        layout=read(ar,'request/generated/candidate-layout.json')
        if layout is not None and not json.loads(layout)['hashes_unchanged']: raise RuntimeError('candidate layout input drift')
        return dict(request_id=receipt['request_id'],status=receipt['status'],entry=entry,native_sha256=wanted,kernel_native_matches_receipt=True,generated_native_present=generated is not None,generated_native_matches_kernel=generated==native if generated is not None else None,request_archive_sha256=digest(blob),artifacts=artifacts)

def inspect(summary,archive,kind):
    errors=[];audits=[];counts={};missing=[]
    if digest(archive.read_bytes())!=summary['archive_sha256']: raise RuntimeError('closed host archive checksum mismatch')
    with tarfile.open(archive,'r:gz') as ar:
        logs=read(ar,'run/requests/requests.jsonl')
        receipts=[json.loads(line) for line in logs.decode().splitlines()] if logs else []
        for receipt in receipts:
            path=receipt.get('artifact_archive') or receipt.get('failure_archive')
            if not path:
                errors.append('request has no closed archive: '+str(receipt['request_id']));continue
            member='run/requests/'+Path(path).name
            blob=read(ar,member)
            if blob is None:
                errors.append('missing request archive '+member);continue
            try: audits.append(request_audit(blob,receipt))
            except Exception as error: errors.append(str(error))
        if kind=='safety':
            raw_cases=read(ar,'run/cases.json');raw_outcomes=read(ar,'run/outcomes.json')
            cases=json.loads(raw_cases) if raw_cases else []
            outcomes=json.loads(raw_outcomes) if raw_outcomes else []
            expected=json.loads((ROOT/'kprog/arm64/build/trusted-transport/context-memory-read/safety-inputs/cases.json').read_text())
            original={r['name']:r for r in expected};actual={r['name']:r for r in cases}
            if {n:r['native_sha256'] for n,r in actual.items()}!={n:r['native_sha256'] for n,r in original.items()}: errors.append('guest case inventory differs from frozen45 inputs')
            for row in outcomes:
                name=row['name'];counts[row['stage']]=counts.get(row['stage'],0)+1
                if name not in original or original[name]['native_sha256']!=row['native_sha256'] or row['request']['native_sha256']!=row['native_sha256']:errors.append('case native identity mismatch '+name)
                if row.get('unsafe_native_executed'):errors.append('unsafe native execution reported '+name)
                if row['negative'] and len(row['command'])!=3:errors.append('negative is not load-only '+name)
                if not row['negative'] and row['stage']=='valid_executed' and 'nonzero_generations=' not in row['message']:errors.append('positive lacks generation receipt '+name)
            complete={r['name'] for r in outcomes};missing=[n for n in original if n not in complete]
            expected_count=len(expected);completed_count=len(outcomes)
        else:
            counts={'service_accepted':sum(r['status']==0 for r in receipts),'service_refused':sum(r['status']!=0 for r in receipts)}
            work=read(ar,'run/work.json');expected_count=None;completed_count=len(receipts)
    return dict(utc=now(),kind=kind,scope='native byte identity and closed raw results; no compiler/ISA refinement claim',archive=archive.name,archive_sha256=summary['archive_sha256'],host_reported_ok=summary['ok'],hashes_unchanged=summary.get('hashes_unchanged'),completed_counts=counts,expected_safety_cases=expected_count,completed_requests_or_cases=completed_count,not_completed=missing,request_identities=audits,identity_errors=errors,all_recorded_identities_match=bool(audits) and not errors,collector_source_sha256=digest(Path(__file__).read_bytes()))

def git(args,**kw): return subprocess.run(['git',*args],cwd=ROOT,check=True,**kw)
def publish(paths,kind):
    env=dict(os.environ,GIT_INDEX_FILE=str(A/('context-native-'+kind+'-collector.index')))
    branch=subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()
    if branch!='master':raise RuntimeError('unexpected branch '+branch)
    subprocess.run(['git','status','--short','--branch','--',*paths],cwd=ROOT,check=True)
    while True:
        parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
        git(['read-tree',parent],env=env);git(['add','-f','--',*paths],env=env)
        names=subprocess.check_output(['git','diff','--cached','--name-only',parent],cwd=ROOT,env=env,text=True).splitlines()
        if not names:
            commit=subprocess.check_output(['git','log','-1','--format=%H','--',paths[1]],cwd=ROOT,text=True).strip();break
        if set(names)!=set(paths):raise RuntimeError('unexpected private staged paths '+repr(names))
        result=subprocess.run(['git','commit','-m','Retain completed ARM trusted '+kind+' replay and native identity audit'],cwd=ROOT,env=env,text=True,capture_output=True)
        if result.returncode==0:
            print(result.stdout,flush=True)
            token=re.search(r'^\[[^\]]+ ([0-9a-f]+)\]',result.stdout,re.M)
            if token is None:raise RuntimeError('cannot identify own completed commit')
            commit=subprocess.check_output(['git','rev-parse',token[1]],cwd=ROOT,text=True).strip();break
        current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
        if current==parent or 'cannot lock ref' not in result.stderr:raise RuntimeError(result.stdout+result.stderr)
    changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=ROOT,text=True).splitlines()
    if set(changed)!=set(paths):raise RuntimeError('own commit scope differs '+repr(changed))
    for p in paths:
        if subprocess.check_output(['git','show',commit+':'+p],cwd=ROOT)!=(ROOT/p).read_bytes():raise RuntimeError('committed physical blob differs '+p)
    git(['push','origin','HEAD:master'],env=env)
    remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/master'],cwd=ROOT,text=True).split()[0]
    git(['merge-base','--is-ancestor',commit,remote])
    return commit

def collect(job):
    if not (A/job['exit']).exists():raise RuntimeError('driver closed without exit receipt')
    folder=OUT/job['folder'];summary=json.loads((folder/'summary.json').read_text())
    if summary['started']!=job['started']:raise RuntimeError('stale or foreign result summary')
    archive=folder/summary['archive'];audit=inspect(summary,archive,job['kind'])
    audit_path=folder/'native-identity-audit.json';audit_path.write_text(json.dumps(audit,indent=2)+'\n')
    readme=folder/'README.md';marker='## Closed run '+summary['started']
    text=readme.read_text() if readme.exists() else '# ARM trusted '+job['kind']+' replay\n'
    if marker not in text:
        text+='\n'+marker+'\n\nHost status: `'+str(summary['ok'])+'`; guest exit: `'+str(summary.get('guest_exit'))+'`. Completed counts: `'+json.dumps(audit['completed_counts'],sort_keys=True)+'`. '+('Expected45 safety cases; not completed: `'+json.dumps(audit['not_completed'])+'`. ' if job['kind']=='safety' else 'Application/work counters and errors are retained in run/work.json and run/guest.json inside the raw archive. ')
        text+='Native identity errors: `'+json.dumps(audit['identity_errors'])+'`. Raw archive: `'+archive.name+'` SHA256 `'+summary['archive_sha256']+'`. Every available closed request archive is retained, including generated C/BPF, compiler/verifier logs, kernel/native bytes and pinned facts. This is the frozen private context/compact worker; canonical production promotion and all-six-application acceptance remain open. '
        if job['kind']=='katran':text+='The launch argv says20-23; host-affinity-migration.json in the raw archive records the actual later8-11 placement. '
        text+='QEMU timing is functional only.\n';readme.write_text(text)
    paths=[str(p.relative_to(ROOT)) for p in [folder/'summary.json',archive,audit_path,readme]]
    commit=publish(paths,job['kind'])
    record=dict(utc=now(),kind=job['kind'],commit=commit,paths=paths,host_ok=summary['ok'],counts=audit['completed_counts'],identity_errors=audit['identity_errors'],native_identities=len(audit['request_identities']))
    (A/('context-native-'+job['kind']+'-collected.json')).write_text(json.dumps(record,indent=2)+'\n')
    notice='\n- LOCAL A automatic closed-result collector '+now()+': PUSHED '+commit+' PRIVATEindex/exact4ownresultpaths/remoteancestor+physicalblobs VERIFIED; '+job['kind']+' host_ok='+str(summary['ok'])+' completed='+json.dumps(audit['completed_counts'],separators=(',',':'))+' nativeidentity_errors='+json.dumps(audit['identity_errors'])+'. Frozen private worker ONLY; no canonical producer promotion/all6app/wholeO1-O4 claim. Raw '+str(folder.relative_to(ROOT))+'/'+archive.name+' retained.\n'
    with Path('/workspaces/.agent-state/kprog-lanes/COORDINATION.md').open('a') as f:f.write(notice)
    with (A/'last.md').open('a') as f:f.write('\nCLOSED COLLECTOR '+json.dumps(record,indent=2)+'\nNext inspect actual errors/work counters and fix native-only producer; do not infer all-app/full-safety acceptance from a partial run.\n')
    return record

if __name__=='__main__':
    lock=(A/'context-native-collector.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=dict(utc=now(),phase='starting',results=[])
    def save():state['utc']=now();STATUS.write_text(json.dumps(state,indent=2)+'\n')
    try:
        live=ROOT/'kprog/arm64/build/trusted-transport/service-06947zy4';rows=json.loads((live/'outcomes.json').read_text())
        for row in [rows[0],next(r for r in rows if r['stage']=='verifier_rejected')]:
            receipt=row['request'];path=Path(receipt.get('artifact_archive') or receipt['failure_archive']);request_audit(path.read_bytes(),receipt)
        state['preflight']='two actual closed success/failure native request archives PASS';save()
        jobs=json.loads((A/'context-native-collector.jobs.json').read_text());pending={}
        for job in jobs:
            try:fd=os.pidfd_open(job['pid'])
            except ProcessLookupError:
                state['results'].append(collect(job));save();continue
            stat=Path('/proc/'+str(job['pid'])+'/stat')
            if stat.exists() and stat.read_text().rsplit(')',1)[1].split()[19]!=job['starttime']:raise RuntimeError('PID identity changed')
            pending[fd]=job
        state['phase']='waiting_for_existing_jobs';save()
        while pending:
            ready,_,_=select.select(list(pending),[],[])
            for fd in ready:
                job=pending.pop(fd);os.close(fd);state['phase']='collecting_'+job['kind'];save();state['results'].append(collect(job));state['phase']='waiting_for_existing_jobs' if pending else 'finished';save()
        state['phase']='finished';save()
    except BaseException as error:
        state.update(phase='failed',error=str(error),traceback=traceback.format_exc());save();raise
