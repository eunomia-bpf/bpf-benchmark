from pathlib import Path
import subprocess,sys,json,time,uuid,hashlib,importlib.util
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');D=Path('/workspaces/.agent-state/kprog-lanes/A/host-compile/legacy');D.mkdir(exist_ok=True);S=D/'scope';S.mkdir();state=S/'broker'
spec=importlib.util.spec_from_file_location('trusted_compile',R/'kprog/trusted_compile.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
def path(name):
 d=S/'trusted-control/requests'/('request-'+name)/'generated';d.mkdir(parents=True);return d/'trusted_x86.bpf.c',d/'trusted_x86.bpf.o'
def send(job):
 identity=uuid.uuid4().hex;m.atomic_json(state/(identity+'.request.json'),job);out=state/(identity+'.result.json')
 while not out.exists():
  assert p.poll() is None;time.sleep(.05)
 return json.loads(out.read_text())
log=(D/'server.log').open('wb');p=subprocess.Popen([sys.executable,str(R/'kprog/trusted_compile.py'),'serve','--scope',str(S),'--state',str(state)],stdout=log,stderr=subprocess.STDOUT)
try:
 while not (state/'ready.json').exists():
  assert p.poll() is None;time.sleep(.05)
 source,output=path('valid');source.write_text('unsigned entry(unsigned *ctx) { return ctx[0]*3+17; }\n')
 q=subprocess.run([sys.executable,str(R/'kprog/trusted_compile.py'),'submit','--state',str(state),'--source',str(source),'--output',str(output),'--arch','x86'],capture_output=True,text=True);assert q.returncode==0,q.stderr
 reference=output.with_name('direct.bpf.o');args=m.compile_command(source,reference,'x86','/usr/lib/llvm-18/bin/clang');subprocess.run(args,check=True)
 with output.open('rb')as a,reference.open('rb')as b:assert ELFFile(a).get_section_by_name('.text').data()==ELFFile(b).get_section_by_name('.text').data()
 rows.append(dict(case='fresh_compile_and_object_transport',ok=True,receipt=json.loads(output.with_suffix('.o.compiler.json').read_text())))
 result=send(dict(source=str(source),output=str(output),arch='x86',source_sha256=m.digest(source)));assert result['returncode']==1 and 'fresh output' in result['stderr'];rows.append(dict(case='existing_output_preserved',ok=True))
 source,output=path('digest');source.write_text('unsigned entry(void) { return 7; }\n');result=send(dict(source=str(source),output=str(output),arch='x86',source_sha256='0'*64));assert result['returncode']==1 and 'identity changed' in result['stderr'] and not output.exists();rows.append(dict(case='source_digest_mismatch',ok=True))
 result=send(dict(source=str(R/'kprog/trusted_compile.py'),output=str(output),arch='x86',source_sha256=m.digest(R/'kprog/trusted_compile.py')));assert result['returncode']==1 and not output.exists();rows.append(dict(case='source_scope_enforced',ok=True))
 result=send(dict(source=str(source),output=str(output),arch='arm64',source_sha256=m.digest(source)));assert result['returncode']==1 and 'architecture' in result['stderr'];rows.append(dict(case='architecture_identity',ok=True))
 result=send(dict(source=str(source),output=str(output),arch='x86',source_sha256=m.digest(source),extra='-fplugin=/tmp/foreign'));assert result['returncode']==1 and 'fields' in result['stderr'];rows.append(dict(case='compiler_argument_protocol',ok=True))
 source,output=path('syntax');source.write_text('this is invalid C\n');result=send(dict(source=str(source),output=str(output),arch='x86',source_sha256=m.digest(source)));assert result['returncode']!=0 and 'error:' in result['stderr'];rows.append(dict(case='actual_clang_failure_forwarded',ok=True))
 q=subprocess.run([sys.executable,str(R/'kprog/trusted_compile.py'),'serve','--scope',str(S),'--state',str(state)],capture_output=True,text=True);assert q.returncode!=0 and 'temporarily unavailable' in q.stderr;rows.append(dict(case='one_broker_owner',ok=True))
 (D/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');print('trusted compiler transport: OK',len(rows),'controls',flush=True)
finally:
 (state/'STOP').write_text('control complete\n');p.wait();log.close()
