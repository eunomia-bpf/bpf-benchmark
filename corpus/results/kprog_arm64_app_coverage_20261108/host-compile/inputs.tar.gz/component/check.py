from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
from elftools.elf.elffile import ELFFile
R=Path('/workspaces/repository');N=Path(__file__).resolve().parent;S=N/'scope';S.mkdir();state=S/'broker';root=R/'kprog/arm64/build/app-runtime-v35/root';rows=[]
spec=importlib.util.spec_from_file_location('arm_host_compile',R/'kprog/trusted_compile.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def sections(p):
 with p.open('rb') as f:
  e=ELFFile(f);return {s.name:s.data() for s in e.iter_sections() if s['sh_flags']&2 and s['sh_type']!='SHT_NOBITS'}
def relocs(p):
 with p.open('rb') as f:
  e=ELFFile(f);out=[]
  for s in e.iter_sections():
   if s['sh_type'] in ['SHT_REL','SHT_RELA'] and e.get_section(s['sh_info'])['sh_flags']&2:
    symbols=e.get_section(s['sh_link'])
    out.extend([s.name,r['r_offset'],r['r_info_type'],symbols.get_symbol(r['r_info_sym']).name] for r in s.iter_relocations())
  return out
log=(N/'server.log').open('wb');p=subprocess.Popen([sys.executable,str(R/'kprog/trusted_compile.py'),'serve','--scope',str(S),'--state',str(state),'--arm64-sysroot',str(root),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
try:
 while not (state/'ready.json').exists():
  assert p.poll() is None;time.sleep(.05)
 for case in ['valid','bounds']:
  d=S/('trusted-'+case)/'requests'/('request-'+case)/'generated';d.mkdir(parents=True);source=d/'trusted_arm64.bpf.c';output=d/'trusted_arm64.bpf.o';source.write_bytes((N/'reference'/(case+'-trusted_arm64.bpf.c')).read_bytes())
  command=[sys.executable,str(R/'kprog/trusted_compile.py'),'submit','--state',str(state),'--source',str(source),'--output',str(output),'--arch','arm64'];q=subprocess.run(command,capture_output=True,text=True);(N/(case+'.stdout')).write_text(q.stdout);(N/(case+'.stderr')).write_text(q.stderr);assert q.returncode==0,q.stderr
  guest=N/'reference'/(case+'-trusted_arm64.bpf.o');a,b=sections(guest),sections(output);matches={name:a.get(name)==b.get(name) for name in sorted(set(a)|set(b))};relocation_equal=relocs(guest)==relocs(output);receipt=json.loads(output.with_suffix('.o.compiler.json').read_text());assert '-O2' in receipt['command'] and '-O3' not in receipt['command'] and '--sysroot='+str(root) in receipt['command']
  rows.append(dict(case=case,allocated_section_bytes_equal=matches,relocations_equal=relocation_equal,guest_allocated_sha256={n:hashlib.sha256(x).hexdigest() for n,x in a.items()},host_allocated_sha256={n:hashlib.sha256(x).hexdigest() for n,x in b.items()},compiler_receipt=receipt))
  (N/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(matches.values()) and relocation_equal,rows[-1]
 before_spec=importlib.util.spec_from_file_location('original_host_compile',N/'before.py');before=importlib.util.module_from_spec(before_spec);before_spec.loader.exec_module(before);before.ROOT=R
 source=S/'trusted-profile/requests/request-profile/generated/trusted_arm64.bpf.c';source.parent.mkdir(parents=True);source.write_text('unsigned entry(void) { return 2; }\n');output=source.with_suffix('.o')
 assert m.compile_command(source,output,'x86','clang-18')==before.compile_command(source,output,'x86','clang-18');rows.append(dict(case='existing_x86_compile_profile_exact',ok=True))
 try:m.compile_command(source,output,'arm64','clang-18')
 except ValueError as error:assert 'trusted sysroot' in str(error);rows.append(dict(case='arm_profile_requires_trusted_sysroot',ok=True))
 else:raise AssertionError('expected explicit sysroot requirement')
 bad=subprocess.run([sys.executable,str(R/'kprog/trusted_compile.py'),'serve','--scope',str(S),'--state',str(S/'bad-broker'),'--arm64-sysroot',str(N)],capture_output=True,text=True);assert bad.returncode!=0 and 'ARM trusted sysroot header' in bad.stderr;rows.append(dict(case='sysroot_header_identity_scope',ok=True))
 (N/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');print('ARM host compiler: OK',len(rows),'controls; two full QEMU fixture allocated byte/relocation identities',flush=True)
finally:
 (state/'STOP').write_text('control complete\n');p.wait();log.close()
