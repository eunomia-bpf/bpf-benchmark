unsigned entry(void) { return 2; }
