set +e
cd /workspaces/repository
taskset -c 16-19 unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/host-compile/inside.sh
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/host-compile/check.exit
exit "$rc"
