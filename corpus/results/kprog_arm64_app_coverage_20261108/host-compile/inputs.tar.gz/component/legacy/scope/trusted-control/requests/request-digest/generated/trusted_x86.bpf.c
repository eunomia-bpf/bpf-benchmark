unsigned entry(void) { return 7; }
