unsigned entry(unsigned *ctx) { return ctx[0]*3+17; }
