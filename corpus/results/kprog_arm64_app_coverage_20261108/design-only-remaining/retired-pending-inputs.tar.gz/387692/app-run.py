from pathlib import Path
import ast,datetime,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');N=Path(__file__).resolve().parent;D=R/'corpus/results/kprog_arm64_app_coverage_20261108/unaligned-stack';state={}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):
 state.update(utc=now(),phase=phase,**kw);(N/'app-status.json').write_text(json.dumps(state,indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
def wait(pid):
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:return
 try:select.select([fd],[],[])
 finally:os.close(fd)
try:
 plan=json.loads((N/'app-plan.json').read_text());pub=load('stack_app_pub',A/'six-app-publish.py');(D/'application-launch.json').write_text(json.dumps(plan,indent=2)+'\n')
 with tarfile.open(D/'application-inputs.tar.gz','w:gz') as t:
  for name in ['app-plan.json','app-run.py','app-transport.py','app.sh','source','before.h','after.h','prior-application-status.json','publication-repair-status.json','startup-repair-publication.json']:t.add(N/name,arcname='launch/'+name)
 (D/'application-README.md').write_text('Complete OTel stack-byte-arm successor\n\nThe captured80-source profile runs the original OTel native ELF and two-start workload through the matched kfunc Image/module9a and registered native-only worker. Host ARM O2/BPFv4/4096-byte frame compilation uses2270guest header identities. The existing application/rejit lifecycle interfaces use0, and the registered service retains the kernel-owned generation/verifier/binding route. Guest8GiB/eightvCPU uses16-19. The generic controls and current Cilium/Tracee/OTel controller finish before canonical stack promotion and this new complete run. Runtime3196 identities, commands and private source snapshots accompany this concrete launch.\n')
 paths=[str((D/n).relative_to(R)) for n in ['application-launch.json','application-inputs.tar.gz','application-README.md']];changed=[p for p in paths if subprocess.run(['git','show','HEAD:'+p],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL).stdout!=(R/p).read_bytes()];rec=pub.publish(changed,'Queue complete ARM OTel with generic stack byte reads','arm-stack-byte-application-launch');save('waiting_component_and_application_epochs',launch_commit=rec['commit'],component_pid=plan['component_predecessor'],application_pid=plan['application_predecessor']);notice('PUSHED '+rec['commit']+' completeARM OTel successor80source/3196runtime/8GiB/eightvCPU16-19, aftergenericbyte-arm controls andcurrentH applicationepoch. Originalnative/workload andkernel-ownedfreshbinding retained; existingAPPTIMEOUT/REJITTIMEOUT0 follows actualstartupcompletion.')
 wait(plan['component_predecessor']);safety=json.loads((N/'full-status.json').read_text());assert safety['phase']=='finished';out=safety['outcome'];assert out['host_ok'] and out['cases']==34 and out['unsafe_accepted']==0 and out['unsafe_executed']==0
 wait(plan['application_predecessor']);save('adopting_generic_byte_arm',safety_commit=safety['publication']['commit'])
 path='kprog/arm64/arm64_sim_local_bpf.h';p=R/path;current=p.read_bytes();assert current==subprocess.check_output(['git','show','HEAD:'+path]);before=(N/'before.h').read_text();after=(N/'after.h').read_text();a=before.index('#define ARM64_SIM_L_STACK_READ(');b=before.index('#define ARM64_SIM_L_STACK_READ_TAG',a);old=before[a:b];a2=after.index('#define ARM64_SIM_L_STACK_READ(');b2=after.index('#define ARM64_SIM_L_STACK_READ_TAG',a2);new=after[a2:b2];assert current.decode().count(old)==1;p.write_text(current.decode().replace(old,new))
 adoption=dict(utc=now(),source_before_sha256=hashlib.sha256(current).hexdigest(),source_after_sha256=sha(p),component_commit=json.loads((N/'publication.json').read_text())['commit'],safety_commit=safety['publication']['commit'],application_predecessor=plan['application_predecessor']);(D/'production-adoption.json').write_text(json.dumps(adoption,indent=2)+'\n');rec=pub.publish([path,str((D/'production-adoption.json').relative_to(R))],'Read generic ARM stack byte windows with byte accesses','arm-stack-byte-production');save('production_adopted',production_commit=rec['commit']);notice('PUSHED '+rec['commit']+' genericARM stackbyte-arm productionaftercapturedH epoch andfull34safety. Alignedwordspills/provenance/rawcontext loads retaintheircontracts.')
 for path,h in plan['source_pins'].items():assert sha(N/'source'/path)==h,path
 for path,h in plan['binary_and_manifest_pins'].items():assert sha(R/path)==h,path
 assert sha(N/'app-transport.py')==plan['transport_sha256'] and sha(N/'app.sh')==plan['script_sha256'];save('actual_complete_otel')
 with (N/'app.log').open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(N/'app.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 F=D/'application/trusted-arm64-otelcol-ebpf-profiler-result';summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];audit=load('stack_app_identity',A/'context-native-collector.py').inspect(summary,archive,'otelcol-ebpf-profiler');tree=ast.parse((A/'six-app-queue.py').read_text());nodes=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='lock' for x in node.targets):break
  nodes.append(node)
 scope={'__name__':'stack_app_review'};exec(compile(ast.Module(body=nodes,type_ignores=[]),'stack_app_review','exec'),scope);coverage=scope['coverage'](summary,archive)
 (F/'native-identity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(F/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');(F/'driver.log.gz').write_bytes(gzip.compress((N/'app.log').read_bytes(),mtime=0));(F/'README.md').write_text('Complete original OTel through the generic stack byte-arm profile. Guest exit '+str(summary.get('guest_exit'))+'; host success '+str(summary['ok'])+'; fresh service stages '+json.dumps(coverage['stages'])+'. Complete raw workload/application/kernel/compiler/request identities accompany the result. Universal mechanism and six-application closure continue.\n');rec=pub.publish([str(p.relative_to(R)) for p in [F/'summary.json',archive,F/'native-identity-audit.json',F/'coverage.json',F/'driver.log.gz',F/'README.md']],'Retain complete ARM OTel stack byte-arm runtime','arm-stack-byte-application-result');save('finished',result_commit=rec['commit'],host_ok=summary['ok'],stages=coverage['stages']);notice('PUSHED '+rec['commit']+' completeOTel byte-arm rawcohort stages='+json.dumps(coverage['stages'])+'; native/source/compiler/appwork identities retained.')
except BaseException as e:save('needs_continuation',error=str(e),traceback=traceback.format_exc());raise
