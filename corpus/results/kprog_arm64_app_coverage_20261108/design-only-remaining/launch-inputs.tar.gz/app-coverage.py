def get(ar, name):
    try:
        m = ar.getmember(name)
    except KeyError:
        return None
    if not m.isfile():
        raise RuntimeError('nonregular archive member ' + name)
    return ar.extractfile(m).read()

def coverage(summary, archive):
    rows = []
    apps = []
    with tarfile.open(archive) as ar:
        raw = get(ar, 'run/requests/requests.jsonl')
        receipts = [json.loads(x) for x in raw.decode().splitlines()] if raw else []
        for receipt in receipts:
            name = 'run/requests/' + Path(receipt.get('artifact_archive') or receipt['failure_archive']).name
            blob = get(ar, name)
            if blob is None:
                raise RuntimeError('closed receipt lacks archive ' + name)
            with tarfile.open(fileobj=io.BytesIO(blob)) as request:
                bpf = get(request, 'request/generated/trusted_arm64.bpf.o')
                source = get(request, 'request/generated/trusted_arm64.bpf.c')
                message = (get(request, 'request/load.stderr') or b'').decode(errors='replace')
                commands = get(request, 'request/generated/commands.jsonl')
                commands = [json.loads(x) for x in commands.decode().splitlines()] if commands else []
                failed = [x for x in commands if x['returncode']]
                if receipt['status'] == 0:
                    stage, cause = ('verifier_accepted_installed', None)
                elif 'infinite loop detected' in message:
                    stage, cause = ('verifier_rejected', 'infinite_loop')
                elif 'BPF_PROG_LOAD' in message and any((x in message for x in ['BPF program is too large', 'too many states', 'processed 1000001 insns', 'The sequence of 8193 jumps'])):
                    stage, cause = ('verifier_rejected', 'complexity_or_size')
                elif 'verifier log:' in message and any((x in message for x in ['invalid mem access', 'invalid access to', '!read_ok', 'invalid func', 'unbounded memory access', 'out of bounds', 'misaligned', 'math between', 'R0 leaks', 'stack depth', 'negative min value'])):
                    stage, cause = ('verifier_rejected', 'verifier_diagnostic')
                elif 'native-link kernel failed' in message and 'link-plan tail_call_maps entry' in message:
                    stage, cause = ('loader_rejected', 'native_link_tail_map_plan')
                elif bpf is not None:
                    stage, cause = ('loader_rejected', 'see_exact_load_stderr')
                elif source is not None:
                    stage, cause = ('specialization_failed', 'compiler')
                else:
                    stage, cause = ('specialization_failed', 'generation_or_metadata')
                entry = get(request, 'request/kernel.entry')
                rows.append(dict(request_id=receipt['request_id'], source_prog_id=receipt['source_prog_id'], native_sha256=receipt['native_sha256'], entry=entry.decode().strip() if entry else None, status=receipt['status'], stage=stage, cause=cause, proof_generated=bpf is not None, source_generated=source is not None, prog_id=receipt.get('prog_id'), request_archive=name, request_archive_sha256=hashlib.sha256(blob).hexdigest(), failed_commands=failed, error=receipt.get('error'), load_stderr=message))
        for m in ar:
            if m.isfile() and '/details/apps/' in m.name and m.name.endswith('.json'):
                app = json.loads(ar.extractfile(m).read())
                phases = {}
                for phase in ['baseline', 'post_rejit']:
                    measurement = app.get(phase) or {}
                    phases[phase] = {'programs': list(measurement.get('bpf', {}).values()), 'workload': measurement.get('workload'), 'raw_measurement': measurement}
                apps.append(dict(archive_member=m.name, app=app['app'], status=app['status'], error=app.get('error'), phases=phases))
    counts = Counter((x['stage'] for x in rows))
    return dict(utc=now(), host_ok=summary['ok'], guest_exit=summary.get('guest_exit'), hashes_unchanged=summary.get('hashes_unchanged'), service_request_attempts=len(rows), distinct_source_prog_ids=len({x['source_prog_id'] for x in rows}), proof_generated=sum((x['proof_generated'] for x in rows)), stages=dict(counts), failure_causes=dict(Counter((x['cause'] for x in rows if x['cause']))), requests=rows, applications=apps, denominators='Service requests retain retries. Distinct source IDs are recorded separately. Baseline resident programs and every raw phase measurement are retained without using manifest entries as loaded-program counts.')
