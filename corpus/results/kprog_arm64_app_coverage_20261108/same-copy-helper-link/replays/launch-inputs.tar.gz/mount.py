from pathlib import Path
import os,subprocess,sys
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');app=sys.argv[1]
for p in sorted((G/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
for p in (G/'manifests').glob('*.json'):subprocess.run(['mount','--bind',str(p),str(R/'kprog/arm64/build/app-verified-stage'/p.name[:-5]/'manifest.json')],check=True)
subprocess.run(['mount','--bind',str(G/(app+'-transport.py')),str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py')],check=True)
if app=='bcc':subprocess.run(['mount','--bind',str(G/'bcc-workload.py'),str(R/'runner/libs/workload.py')],check=True)
os.execvp('make',['make','-f',str(G/'Makefile'),'application','APP='+app])
