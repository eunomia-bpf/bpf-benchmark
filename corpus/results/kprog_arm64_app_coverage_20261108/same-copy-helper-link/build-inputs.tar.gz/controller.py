from pathlib import Path
import datetime,hashlib,importlib.util,json,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/same-copy-helper-link';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('warm_ARM_loader_build',source_publication='dc120a8ebc2fea2dd274c510fe045a22e29bc52d')
 command=['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/'build.py')]
 with (G/'build.log').open('w') as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 files=['runner/build-arm64-llvmbpf/micro_exec','runner/build-arm64-llvmbpf/native_loader/libnative_loader.so','runner/build-arm64-llvmbpf/native_loader/trusted-native-loader','runner/build-arm64-llvmbpf/native_loader/trusted-service-client']
 captures={}
 for rel in files:
  path=R/rel
  if path.exists():
   target=G/'binaries'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target);captures[rel]=dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
 j=dict(utc=now(),command=command,returncode=p.returncode,source_publication='dc120a8ebc2fea2dd274c510fe045a22e29bc52d',source_hashes={str(p.relative_to(G/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (G/'source').rglob('*') if p.is_file()},outputs=captures,scope='Owning ARM incremental cache; trusted worker uses existing public helper relocation resolution and functional ARM helper/tail ABI; direct-native optimizer hints retain their own path',runtime_admission_additions=0)
 (O/'build.json').write_text(json.dumps(j,indent=2)+'\n')
 (O/'README.md').write_text('ARM same-copy helper resolution\n\nThe shared loader source dc120a8eb resolves trusted native map/helper calls through the existing public helper relocations. Optimizer map/CPU hints belong to direct-native invocation. Functional ARM helper slots and tail-call ABI stay current. ARM adopts the exact published CPP/link-schema through private source mounts and the existing warm CMake targets. Actual build exit:'+str(p.returncode)+'.\n\nbuild.json and build-inputs.tar.gz retain source/binary hashes, complete commands and diagnostics. Current ARM application/catalog captures keep their existing binary epoch. BCC/Katran functional replays follow successful owning ARM build adoption. Runtime admission additions:0.\n')
 with tarfile.open(O/'build-inputs.tar.gz','w:gz') as tf:
  for n in ['source','binaries','build.py','controller.py','build.log']:tf.add(G/n,arcname=n)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','build.json','build-inputs.tar.gz']],'Build the same-copy public helper route on ARM','arm-same-copy-helper-build')
 save('finished',publication=rec,returncode=p.returncode)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' ARM same-copy loader dc120a8eb owningwarm4target build'+str(p.returncode)+', exactCPP/link-schema/binaries archived. Trustedpublichelperrelocations andfunctionalARMslots/tailABI retained; currentcapturedguests retainolderbinaries. BCC/Katran actualreplays follow; runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
