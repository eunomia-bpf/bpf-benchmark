from pathlib import Path
import subprocess,os
R=Path('/workspaces/repository');G=Path(__file__).resolve().parent
for p in (G/'source').rglob('*'):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
os.chdir(R)
os.execvp('cmake',['cmake','--build','runner/build-arm64-llvmbpf','--target','micro_exec','native_loader_shared','trusted-native-loader','trusted-service-client','--parallel','2'])
