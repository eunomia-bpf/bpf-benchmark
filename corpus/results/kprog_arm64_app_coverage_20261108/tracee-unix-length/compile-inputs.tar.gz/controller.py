from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,tarfile,traceback,shutil
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tracee-unix-length';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('paired_native_baseline_binary_compile')
 with (G/'build.log').open('w') as f:p=subprocess.run(['taskset','-c','20-23','unshare','--mount','--propagation','private','sh',str(G/'build.sh')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 rc=p.returncode;(G/'build.exit').write_text(str(rc)+'\n');D=R/'vendor/build/.tracee-build/none/arm64/dist'
 files=[]
 for root in [G/'stage/tracee',D]:
  if root.exists():
   files.extend(p for p in root.rglob('*') if p.is_file() and (p.name.endswith('.native.o') or p.name in ['tracee','tracee.bpf.o','lsm_check.bpf.o','kprobe_check.bpf.o','manifest.json']))
 j=dict(utc=now(),make_exit=rc,source=json.loads((G/'source.json').read_text()),build_phases='Fresh paired native/JIT/embedded binary; existing canonical ARM cross-library flags and warm caches',output_files={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files},runtime_admission_additions=0)
 (O/'compile.json').write_text(json.dumps(j,indent=2)+'\n')
 (O/'README.md').write_text((G/'README.md').read_text()+'\nActual paired Makeexit:'+str(rc)+'\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz') as tf:
  for n in ['source.json','Makefile','build.sh','controller.py','build.log','build.exit','tree','build-source','buffer.before.h']:
   tf.add(G/n,arcname=n)
 if rc==0:
  I=G/'image';I.mkdir(exist_ok=True)
  shutil.copytree(G/'stage/tracee',I/'native',dirs_exist_ok=True)
  shutil.copy2(D/'tracee',I/'tracee');shutil.copy2(D/'tracee.bpf.o',I/'tracee.bpf.o');shutil.copytree(D/'lsm_support',I/'lsm_support',dirs_exist_ok=True)
  with tarfile.open(O/'paired-artifacts.tar.gz','w:gz') as tf:
   for p in sorted(I.rglob('*')):
    if p.is_file() and (p.name.endswith('.native.o') or p.name.endswith('.bpf.o') or p.name in ['tracee','manifest.json']):tf.add(p,arcname=str(p.relative_to(I)))
 paths=[str(p.relative_to(R)) for p in O.iterdir() if p.is_file()]
 rec=pub.publish(paths,'Build paired ARM Tracee with unsigned UNIX address lengths','arm-tracee-unix-length-compile')
 save('finished',make_exit=rc,publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' ARM Tracee pairedsource 09f40af86 Makeexit'+str(rc)+'. Complete selectedC/native/BPF/embeddedbinary source+output identities and rawcompiler records retained; original workload follows serialguest. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
