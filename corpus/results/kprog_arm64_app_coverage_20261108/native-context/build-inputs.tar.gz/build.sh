set +e
taskset -c 16-19 unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/design-only/native-context/inside-build.sh > /workspaces/.agent-state/kprog-lanes/A/design-only/native-context/build.log 2>&1
rc=$?
echo $rc > /workspaces/.agent-state/kprog-lanes/A/design-only/native-context/build.exit
exit $rc
