from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback,collections
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent;A=F.parent.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/native-context'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
try:
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  for n in ['Makefile','inside-safety.sh','transport.py','raw-check.py','suite','controller.py']:t.add(F/n,arcname=n)
 launch=dict(utc=now(),runtime_build=json.loads((F/'build-publication.json').read_text()),cases=34,source_prog_id=0,source_programs_loaded=0,resource_context='Original companion objects autoloadfalse; actual resource maps stay pinned',programs_executed=4,risk_cases_load_only=30)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz']],'Replay ARM native safety inputs with direct native context','arm-native-context-launch');save('actual_existing34_raw_context',launch_publication=rec);notice('PUSHED '+rec['commit']+' ARMdirectnativePcontext existing34QEMU starts2vCPU/2GiB16-19; companionprogramautoloadfalse/mapresourcesretained; fourpositivesexecuted/risk30load-only. Buildda734ec7a module/worker/producer0 andpairedImageunchanged. R sharedannotationrunner retainsownership; rawARMresultsfollow. Runtimeadmissionadditions0.')
 with (F/'safety.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(F/'inside-safety.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (O/'safety.log.gz').write_bytes(gzip.compress((F/'safety.log').read_bytes(),mtime=0));paths=[O/'safety.log.gz'];report=dict(utc=now(),make_exit=p.returncode,launch=launch)
 q=O/'safety/trusted-arm64-service-result'
 if (q/'summary.json').exists():
  s=json.loads((q/'summary.json').read_text());ar=q/s['archive'];paths += [q/'summary.json',ar];report['summary']=s
  with tarfile.open(ar) as t:
   if 'run/outcomes.json' in t.getnames():report['outcomes']=json.load(t.extractfile('run/outcomes.json'))
 report['counts']=dict(collections.Counter(x['stage'] for x in report.get('outcomes',[])));(O/'safety-complete.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'safety-complete.json');rec=pub.publish([str(p.relative_to(R)) for p in paths],'Record ARM direct native context verifier outcomes','arm-native-context-safety');save('finished',publication=rec,make_exit=p.returncode,cases=len(report.get('outcomes',[])),counts=report['counts']);notice('PUSHED '+rec['commit']+' ARMdirectnativePcontext existing34 terminalMakeexit'+str(p.returncode)+'; counts'+json.dumps(report['counts'])+'. R/C: rawsource0producer/module/worker andcompleteoriginalnative/context/mapinputs retainedin native-context results. Eachrawrequest reachesactualspecializer/verifier; originalsourceprogramloadcount0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
