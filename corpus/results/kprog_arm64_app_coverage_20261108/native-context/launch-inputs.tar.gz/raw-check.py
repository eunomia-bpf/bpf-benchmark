def raw_check():
 import subprocess,json,os,sys,tarfile
 from pathlib import Path
 R=Path('/workspaces/repository');E=R/'kprog/arm64/build/native-context';ROOT=R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp'
 rows=json.loads((ROOT/'cases.json').read_text());outcomes=[];state=m.OUT/'requests';state.mkdir(mode=0o700,exist_ok=True)
 argv=[sys.executable,str(R/'kprog/trusted_service.py'),'--arch','2','--endpoint','/sys/kernel/debug/bpf_arm64_native_lab/specializer','--state',str(state),'--native-link',str(m.native_link()),'--loader',str(E/'loader/trusted-native-loader')]
 service=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);log=[]
 try:
  line=service.stdout.readline();log.append(line);print('SERVICE',line.strip(),flush=True)
  for row in rows:
   negative=row['negative'];context=m.BUILD/('context_hash.bpf.o' if negative else 'context_array.bpf.o');data=json.loads(Path(row['manifest']).read_text());native=data['objects'][0]['native_object']
   command=[str(E/'raw-probe'),str(context),native]
   if not negative:command+=['0','2']
   done=subprocess.run(command,cwd=R,env=os.environ|{'BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF':'1'},text=True,capture_output=True);(m.OUT/(row['name']+'.stdout')).write_text(done.stdout);(m.OUT/(row['name']+'.stderr')).write_text(done.stderr)
   if done.returncode and 'trusted specializer refused native program:' not in done.stderr:raise RuntimeError('producer/setup failure before completion: '+row['name']+'\n'+done.stderr)
   line=service.stdout.readline();log.append(line);record=json.loads(line)
   if negative:stage,message=('accepted_finding',done.stdout+done.stderr) if record['status']==0 else m.classify(record)
   else:stage,message=('valid_executed' if record['status']==0 and done.returncode==0 else 'positive_infrastructure_error'),done.stdout+done.stderr
   outcomes.append(dict(row,command=command,returncode=done.returncode,request=record,stage=stage,message=message,unsafe_native_executed=False));(m.OUT/'outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n');print(row['name'],stage,flush=True)
 finally:
  service.terminate();log.append(service.communicate()[0]);(m.OUT/'service.log').write_text(''.join(log))
m.check=raw_check
