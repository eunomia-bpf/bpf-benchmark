from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-v61-os';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def note(t):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+t+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('native_producer_compile')
 with (G/'build.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/'build-mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 p.check_returncode();command=json.loads((G/'native-command.json').read_text())
 before=G.parent/'bpf_execve_event_v61.native.o';before_sha=hashlib.sha256(before.read_bytes()).hexdigest();after=G/'bpf_execve_event_v61.native.o'
 objs={}
 for name in ['event_execve','execve_rate','execve_send']:
  target=G/'catalog'/('bpf_execve_event__'+name+'.native.o');shutil.copy2(after,target)
  objs[name]=hashlib.sha256(target.read_bytes()).hexdigest()
 baseline=G/'catalog/bpf_execve_event_v61.bpf.o'
 report=dict(utc=now(),source_publication='47cfe359424456f61567f8a90911453a05e21681',model_publication='8eac3b42a58105c432057f6bd851d482c13d15fd',command=command,original_native_O3_sha256=before_sha,native_Os_sha256=hashlib.sha256(after.read_bytes()).hexdigest(),paired_BPF_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),native_entries=objs,source_scope='Identical recorded counted-loop source47cfe3594; native compile -O3 to -Os before submission; original2048 bound and complete three-entry component',runtime_admission_additions=0)
 (O/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'README.md').write_text('Tetragon V61 native producer Os\n\nThe authorized source47cfe3594 keeps its original2048 bound, cwd_read body, iteration order, early break, path output and recorded credential namespace/local-length changes. Native compilation uses -Os in place of -O3 before submission. The paired JIT object retains the same edited C source. The native kernel copy remains both simulator input and emitted P. Canonical producer flags retain their current definition.\n\nThe component submits every V61 execve object entry: event_execve, execve_rate, execve_send. Original object-default globals, maps/BTF and baseline resources are captured. It follows the current counted component through pidfd on12-15/2GiB, with88-helper model8eac3b42a and paired88a Image/module. Source0/load-only admission, raw verifier logs and per-entry outcomes retain their normal meaning. Runtime admission additions:0.\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz') as tf:
  for root in [G/'source',G/'baseline-source']:
   for f in sorted(root.rglob('*')):
    if f.is_file():tf.add(f,arcname=str(f.relative_to(G)))
  for f in [G/'native-command.json',G/'compile.py',G/'build-mount.py',G/'native.stdout',G/'native.stderr',G/'build.log',after,baseline,before]:
   tf.add(f,arcname=('original-O3.native.o' if f==before else str(f.relative_to(G))))
 compile_rec=pub.publish([str((O/n).relative_to(R)) for n in ['compile.json','README.md','compile-inputs.tar.gz']],'Compile paired ARM Tetragon with a native Os producer','arm-v61-os-compile')
 note('PUSHED '+compile_rec['commit']+' same-source V61 nativeOs compile0; all3execve entries captured for originalresource load-only replay. Canonical flags/source/runtime captures retained; admission additions0.')
 C=O/'component';C.mkdir(exist_ok=True)
 with tarfile.open(C/'launch-inputs.tar.gz','w:gz') as tf:
  for root in [G/'runtime-source',G/'catalog']:
   for f in sorted(root.rglob('*')):
    if f.is_file():tf.add(f,arcname=str(f.relative_to(G)))
  for n in ['controller.py','mount.py','transport.py']:tf.add(G/n,arcname=n)
 (C/'launch.json').write_text(json.dumps(dict(utc=now(),compile_publication=compile_rec['commit'],catalog=json.loads((G/'catalog/programs.json').read_text())['counts'],scope='All3V61execve entries/originalresources/nativeOs/source0/loadonly/2GiB12-15'),indent=2)+'\n')
 launch_rec=pub.publish([str((C/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz']],'Queue all ARM V61 execve entries from the Os producer','arm-v61-os-launch')
 save('queued_after_counted_component',compile_publication=compile_rec,publication=launch_rec)
 pid=int((G.parent/'v61-counted-loop/component/controller.pid').read_text())
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('actual_Os_component',publication=launch_rec)
 with (G/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,compile_publication=compile_rec['commit']);paths=[];Q=C/'trusted-arm64-service-result'
 (C/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0));paths.append(C/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   if 'run/out/submissions.json' in tf.getnames():
    data=tf.extractfile('run/out/submissions.json').read();(C/'submissions.json').write_bytes(data);paths.append(C/'submissions.json');report['counts']=json.loads(data)['counts']
 (C/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(C/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect all ARM V61 execve entries from the Os producer','arm-v61-os-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 note('PUSHED '+rec['commit']+' nativeOs V61 three-entry outcome '+json.dumps(report.get('counts'))+'. Source0/load-only; original semantics and source ledger retained. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
