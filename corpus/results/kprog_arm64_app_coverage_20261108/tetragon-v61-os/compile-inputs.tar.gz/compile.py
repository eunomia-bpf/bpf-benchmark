from pathlib import Path
import json,subprocess,sys
G=Path(__file__).resolve().parent
j=json.loads((G/'native-command.json').read_text())
with (G/'native.stdout').open('w') as o,(G/'native.stderr').open('w') as e:p=subprocess.run(j['command'],stdout=o,stderr=e)
j['returncode']=p.returncode;(G/'native-command.json').write_text(json.dumps(j,indent=2)+'\n');sys.exit(p.returncode)
