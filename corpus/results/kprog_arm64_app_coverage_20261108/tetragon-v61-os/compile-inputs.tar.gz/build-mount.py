from pathlib import Path
import os,subprocess,sys
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((G/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'source'))],check=True)
os.execv(sys.executable,[sys.executable,str(G/'compile.py')])
