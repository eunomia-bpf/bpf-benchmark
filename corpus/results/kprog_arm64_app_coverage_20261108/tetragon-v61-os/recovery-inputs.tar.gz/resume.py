from pathlib import Path
import hashlib,json,subprocess,textwrap,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
exec((G/'controller.py').read_text().split('try:\n save',1)[0])
commit='a3c512ed4'
commit=subprocess.check_output(['git','rev-parse',commit],cwd=R,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/master'],cwd=R,text=True).split()[0]
subprocess.run(['git','merge-base','--is-ancestor',commit,remote],cwd=R,check=True)
paths=[str((O/n).relative_to(R)) for n in ['compile.json','README.md','compile-inputs.tar.gz']]
compile_rec=dict(commit=commit,paths=paths,sha256={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},remote_ancestor_verified=True)
(G/'publication-error.json').write_bytes((G/'status.json').read_bytes())
(O/'resume.json').write_text(json.dumps(dict(utc=now(),compile_publication=compile_rec,original_remote_error='Remote GitHub temporary pack directory error on two ordinary pushes; subsequent normal push and remote ancestry confirm delivery'),indent=2)+'\n')
rec=pub.publish([str((O/'resume.json').relative_to(R))],'Record ARM Os producer publication recovery','arm-v61-os-resume')
note('PUSHED '+rec['commit']+' remote GitHub packerror resolved; a3c512ed4 nativeOs compile and d243825c9 countedcomponent delivered. Captured Os successor resumes from publishedcompile through existingthree-entry replay; active guests/canonicalcache retained.')
tail=(G/'controller.py').read_text().split(" C=O/'component'",1)[1].split('\nexcept BaseException',1)[0]
tail=" C=O/'component'"+tail
try:exec(textwrap.dedent(tail))
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
