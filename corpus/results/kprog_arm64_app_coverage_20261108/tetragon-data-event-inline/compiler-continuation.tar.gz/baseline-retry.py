from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-data-event-inline'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('baseline_frontend_continuation',native_exit=0)
 with (G/'baseline-retry.log').open('w') as out:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/'baseline-mount.py')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 j=json.loads((O/'compile.json').read_text());j['commands']=[dict(phase='native',returncode=0),dict(phase='initial_baseline_Make',returncode=2),dict(phase='baseline_retry',returncode=p.returncode)];j['initial_wrapper_status']='Initial wrapper returned0 while Make returned2; original command/stderr retained and actual Make exit propagated in retry';j['compiler_context']='Baseline uses the existing native frontend -fms-extensions for generated anonymous-tag members and three public iterator declarations from vendor/libbpf/src/bpf_helpers.h345-347; complete selected appC/header bytes remain equal';j['output_files']={str(q.relative_to(G)):dict(sha256=hashlib.sha256(q.read_bytes()).hexdigest(),bytes=q.stat().st_size) for q in [G/'bpf_execve_event_v61.native.o',G/'bpf/bpf_execve_event_v61.o'] if q.exists()}
 (O/'compile.json').write_text(json.dumps(j,indent=2)+'\n')
 pth=O/'README.md';t=pth.read_text();t=t.replace('Both compilers complete at exit0.','Native compiler completes at exit0. The initial JIT Make returns2 for generated anonymous-tag members and missing public iterator declarations; the inherited wrapper reported0. The original diagnostics are preserved. This continuation propagates the actual Make exit and supplies the existing frontend -fms-extensions plus public libbpf iterator signatures. Actual JIT retry exit:'+str(p.returncode)+'.')
 pth.write_text(t)
 with tarfile.open(O/'compiler-continuation.tar.gz','w:gz') as tf:
  for n in ['baseline-retry.py','baseline-compile.py','baseline-mount.py','baseline-retry.log','baseline-v61.stdout','baseline-v61.stderr','baseline-command.json','iterator-public-decls.h','initial-baseline']:
   tf.add(G/n,arcname=n)
  obj=G/'bpf/bpf_execve_event_v61.o'
  if obj.exists():tf.add(obj,arcname='bpf/bpf_execve_event_v61.o')
 ledger=R/'corpus/results/kprog_app_source_changes/README.md';text=ledger.read_text();text=text.replace('Canonical O3 native and upstream V61 JIT compile0; all99 selected C/header file pairs have identical hashes. QEMU component covers all3execve entries.','Canonical O3 native compile0; initial JIT Make2 (wrapper0) preserved; JIT frontend continuation exit'+str(p.returncode)+' uses existing MS anonymous-tag support and public iterator declarations. All99 selected C/header pairs match. QEMU component covers all3execve entries.');ledger.write_text(text)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','compile.json','compiler-continuation.tar.gz']]+[str(ledger.relative_to(R))],'Record the actual paired ARM JIT compiler continuation','arm-inline-baseline-continuation')
 save('finished',commands=j['commands'],publication=rec,baseline_exit=p.returncode)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' actualdata-inline frontend continuation native0/initialJITMake2(wrapper0)/JITretry'+str(p.returncode)+'. Originalinitiallogs andcorrectactualexits archived. Baseline nowsharesnative -fms-extensions foractualgeneratedanonymousstructs, plus3publiciteratorsignatures alreadyinlibbpf345-347. All99 appC/H pairs remainidentical;3inliningattributes andoriginalbounds/body retained. Sourceledger compilerstatus corrected. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
