#include "vmlinux.h"
#ifndef __ksym
#define __ksym __attribute__((section(".ksyms")))
#endif
struct bpf_iter_num;
extern int bpf_iter_num_new(struct bpf_iter_num *it, int start, int end) __attribute__((weak)) __ksym;
extern int *bpf_iter_num_next(struct bpf_iter_num *it) __attribute__((weak)) __ksym;
extern void bpf_iter_num_destroy(struct bpf_iter_num *it) __attribute__((weak)) __ksym;
