from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-data-event-inline';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('paired_application_source_compile')
 rows=[]
 for name in ['native','baseline']:
  with (G/(name+'.log')).open('w') as f:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(G/(name+'-mount.py'))],cwd=R,stdout=f,stderr=subprocess.STDOUT)
  rows.append(dict(phase=name,returncode=p.returncode))
  save('paired_application_source_compile',commands=rows)
 outputs=[G/'bpf_execve_event_v61.native.o',G/'bpf/bpf_execve_event_v61.o']
 native=G/'source/vendor/bpf/tetragon/bpf';baseline=G/'baseline-source/bpf'
 j=dict(utc=now(),commands=rows,scope='Private candidate: three internal inlining attributes, complete identical selected C/header source; original2048 bound/helper/output logic retained; canonicalO3/native and upstreamV61BPF',source_files={str(p.relative_to(native)):dict(native=hashlib.sha256(p.read_bytes()).hexdigest(),baseline=hashlib.sha256((baseline/p.relative_to(native)).read_bytes()).hexdigest()) for p in native.rglob('*') if p.is_file() and p.suffix in ['.c','.h']},output_files={str(p.relative_to(G)):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in outputs if p.exists()},runtime_admission_additions=0)
 (O/'compile.json').write_text(json.dumps(j,indent=2)+'\n')
 (O/'README.md').write_text('Tetragon V61 data-event function inlining\n\nPrivate candidate changes three internal function attributes in process/data_event.h: __do_str, data_event_bytes and data_event_str use FUNC_INLINE. The original O3/Os P retains480-byte maximum native stack; compiled B reaches stack offset-520. The candidate removes nested native call-frame boundaries while retaining the complete function bodies, loop counts, limits, helper arguments, error state and output fields. Every selected C/header source is identical between the native and JIT frontends; compile.json records actual hashes and compiler outcomes. Canonical O3 flags and original V61 definitions are retained.\n\nSource publication and the required source-change row/patch follow successful paired compilation. Current running program captures remain fixed. Runtime admission additions:0.\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz') as tf:
  for n in ['controller.py','data_event.before.h','data_event.after.h','native-command.json','native-compile.py','native-mount.py','baseline-compile.py','baseline-mount.py','native.log','baseline.log','native.stdout','native.stderr','baseline-v61.stdout','baseline-v61.stderr','baseline-command.json','source','baseline-source']:
   p=G/n
   if p.exists():tf.add(p,arcname=n)
  for p in outputs:
   if p.exists():tf.add(p,arcname=str(p.relative_to(G)))
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','compile.json','compile-inputs.tar.gz']],'Compile paired ARM Tetragon internal data-event inlining','arm-tetragon-data-inline-compile')
 save('finished',commands=rows,publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' private paired V61 data-event attribute candidate actual '+json.dumps(rows)+'. All selectedC/header hashes andnative/JITobjects/rawcompiler records retained. Sharedsource/requiredpatchledger publication follows result review. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
