from pathlib import Path
import datetime,gzip,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;G=F.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-data-event-inline/component';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('waiting_baseline_frontend')
 pid=int((G/'baseline-retry.pid').read_text())
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 for name in ['event_execve','execve_rate','execve_send']:
  p=F/'catalog'/('bpf_execve_event__'+name+'.native.o');p.unlink(missing_ok=True);os.link(G/'bpf_execve_event_v61.native.o',p)
 p=F/'catalog/bpf_execve_event_v61.bpf.o';p.unlink(missing_ok=True);os.link(G/'bpf/bpf_execve_event_v61.o',p)
 build=json.loads((G/'status.json').read_text())
 (O/'README.md').write_text('All ARM V61 execve entries with inlined data helpers\n\nSource e532845ab changes exactly three internal inlining attributes. Complete bodies, all bounds, helpers and descriptor/output/error values are retained. Native O3 and JIT share all99 selected C/header files; the JIT frontend continuation supplies its original generated-header language mode and three public iterator declarations. Every event_execve/execve_rate/execve_send entry is submitted with source0, complete original resource object and object-default globals. Runtime88-helper model8eac3b42a and paired88a Image/module retained. Guest2GiB12-15; load-only stages. Runtime admission additions:0.\n')
 (O/'launch.json').write_text(json.dumps(dict(utc=now(),source_publication='e532845abd3ebe80d8a02469970bf85253e98489',compiler_publication=build.get('publication'),catalog=json.loads((F/'catalog/programs.json').read_text())['counts'],scope='All3execve entries/source0/loadonly/2GiB12-15',runtime_admission_additions=0),indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for root in [F/'source',F/'catalog']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(F)))
  for n in ['controller.py','mount.py','transport.py']:tf.add(F/n,arcname=n)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Replay all ARM V61 execve entries with inlined data helpers','arm-data-event-inline-launch')
 save('actual_component',publication=rec)
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   if 'run/out/submissions.json' in tf.getnames():
    data=tf.extractfile('run/out/submissions.json').read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect ARM V61 inlined data-helper component outcomes','arm-data-event-inline-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!='utc'})
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' data-event-inline V61 threeentry component actual '+json.dumps(report.get('counts'))+'. Every source0/compile/verifier stage retained; originalbounds/editedpairedsource keep scope. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
