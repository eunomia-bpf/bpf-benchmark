set -e
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-extent/native-proof-regions.patch /workspaces/repository/kprog/tv/native-proof-regions.patch
exec make -f /workspaces/.agent-state/kprog-lanes/A/native-extent/Makefile patch-check
