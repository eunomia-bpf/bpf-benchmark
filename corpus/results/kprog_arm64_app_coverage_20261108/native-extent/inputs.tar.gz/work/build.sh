#!/bin/sh
set -e
cd /workspaces/repository
G=/workspaces/.agent-state/kprog-lanes/A/native-extent
unshare --mount --propagation private sh "$G/inside-patch.sh" > "$G/patch-check.log" 2>&1
taskset -c 8-11 unshare --mount --propagation private sh "$G/inside-kernel.sh" > "$G/kernel.log" 2>&1
cp /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/kernel-link/cache/arch/arm64/boot/Image kprog/arm64/build/native-extent/Image
taskset -c 8-11 unshare --mount --propagation private sh "$G/inside-module.sh" > "$G/module.log" 2>&1
cp "$G/module-output/bpf_arm64_native_lab.ko" kprog/arm64/build/native-extent/kinsn/
aarch64-linux-gnu-gcc -c "$G/large-native.S" -o kprog/arm64/build/native-extent/large-native.o
make -f "$G/Makefile" control-small > "$G/control-small.log" 2>&1
make -f "$G/Makefile" control-large > "$G/control-large.log" 2>&1
