#!/bin/sh
cd /workspaces/repository || exit
sh /workspaces/.agent-state/kprog-lanes/A/native-extent/build.sh
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/native-extent/build.exit
exit "$rc"
