from pathlib import Path
import json,subprocess,os,time,datetime
E=Path('/workspaces/.agent-state/kprog-lanes/A/cilium-compile')
cmd=json.loads((E/"command.json").read_text())
start=time.monotonic()
with (E/"compile.log").open("w") as log:
 p=subprocess.Popen(cmd,cwd="/workspaces/repository",stdout=log,stderr=subprocess.STDOUT)
 _,status,usage=os.wait4(p.pid,0)
 p.returncode=os.waitstatus_to_exitcode(status)
(E/"result.json").write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=p.returncode,wall_seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime),indent=2)+"\n")
