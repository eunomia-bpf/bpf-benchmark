from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent;A=Path('/workspaces/.agent-state/kprog-lanes/A');O=R/'corpus/results/kprog_arm64_app_coverage_20261108/architectural-fault';Q=O/'safety/trusted-arm64-service-result'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'safety-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 save('actual_complete_existing34')
 command=['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(F/'inside.sh')]
 with (F/'safety.log').open('w') as log:done=subprocess.run(command,cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (F/'safety.exit').write_text(str(done.returncode)+'\n');(O/'safety.log.gz').write_bytes(gzip.compress((F/'safety.log').read_bytes(),mtime=0));report=dict(utc=now(),make_exit=done.returncode,launch=json.loads((F/'safety-launch.json').read_text()));paths=[O/'safety.log.gz']
 if (Q/'summary.json').exists():
  s=json.loads((Q/'summary.json').read_text());archive=Q/s['archive'];report['summary']=s;paths.extend([Q/'summary.json',archive])
  with tarfile.open(archive) as t:
   if 'run/outcomes.json' in t.getnames():report['outcomes']=json.load(t.extractfile('run/outcomes.json'))
 (O/'safety-complete.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'safety-complete.json')
 with tarfile.open(O/'safety-inputs.tar.gz','w:gz') as t:
  for n in ['safety-launch.json','inside.sh','safety-controller.py','Makefile','approval.json']:t.add(F/n,arcname=n)
  t.add(R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py',arcname='native-safety-check.current.py')
 paths.append(O/'safety-inputs.tar.gz');h=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py'
 if hashlib.sha256(h.read_bytes()).hexdigest()==report['launch']['harness_sha256']:paths.append(h)
 spec=importlib.util.spec_from_file_location('a_pub',A/'six-app-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);rec=m.publish([str(p.relative_to(R)) for p in paths],'Collect the complete ARM native safety cohort before its verdict','arm-architectural-fault-safety');(F/'safety-publication.json').write_text(json.dumps(rec,indent=2)+'\n');save('finished',publication=rec,make_exit=done.returncode,cases=len(report.get('outcomes',[])))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED'+rec['commit']+' canonical ARM existing34 fullcollection Makeexit'+str(done.returncode)+' cases'+str(len(report.get('outcomes',[])))+'. Existing finding decision runs after cohort collection; risk cases retain load-only. Actual nativepositive/verifier/generation/acceptedfinding classes and full raw receipts retained. Operator approved four architectural fault classes implemented in canonical operation bodies.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
