set -eu
cd /workspaces/repository
F=/workspaces/.agent-state/kprog-lanes/A/design-only/architectural-fault
cp kprog/fidelity/driver.h "$F/driver.h"
for family in memory exclusive; do
 python3 kprog/fidelity/arm64_bank.py --out "$F/$family" --family "$family"
 aarch64-linux-gnu-gcc -O1 -g -std=gnu11 -static -Werror=implicit-function-declaration -DKPROG_FIDELITY_VECTOR_BANK=32 -Ivendor/libbpf/src -Ivendor/libbpf/include/uapi kprog/fidelity/driver.c "$F/$family/generated.c" "$F/$family/native.S" -o "$F/$family/cpu-differential"
done
python3 kprog/fidelity/arm64_control.py "$F/control"
aarch64-linux-gnu-gcc -O1 -g -std=gnu11 -static -Werror=implicit-function-declaration -Ivendor/libbpf/src -Ivendor/libbpf/include/uapi kprog/fidelity/driver.c "$F/control/generated.c" "$F/control/native.S" -o "$F/control/cpu-differential"
