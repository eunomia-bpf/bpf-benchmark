from pathlib import Path
import json,subprocess
F=Path(__file__).resolve().parent;forms=json.loads((F/'fault-forms.json').read_text())
s=['.section .text.boot,"ax"','.global _start','_start:','ldr x0,=stack_top','mov sp,x0','mrs x0,CurrentEL','cmp x0,#4','b.ne wrong_el','adr x0,vectors','msr vbar_el1,x0','mrs x0,sctlr_el1','orr x0,x0,#8','msr sctlr_el1,x0','isb','bl main','b .','wrong_el:','b .','.balign 2048','vectors:']
for i in range(16):s+=['b exception','.balign 128']
s+=['exception:','mrs x12,esr_el1','ldr x13,=last_esr','str x12,[x13]','mrs x12,elr_el1','add x12,x12,#4','msr elr_el1,x12','eret']
for i,row in enumerate(forms):
 s += [f'.global op_{i}',f'op_{i}:','mov x9,sp','mov sp,x0','mov x4,x1','mov x0,#37','mov x1,#38','clrex',row['assembly'],'mov sp,x9','ret']
s+=['.section .bss',' .balign 16',' .skip 8192','stack_top:','.section .note.GNU-stack,"",%progbits']
(F/'el1.S').write_text('\n'.join(s)+'\n')
c=['#include <stdint.h>','volatile uint64_t last_esr;','static _Alignas(16) unsigned char memory[256];','static void output(const char *s) { register uint64_t x0 asm("x0")=4; register const char *x1 asm("x1")=s; asm volatile("hlt #0xf000" : "+r"(x0) : "r"(x1) : "memory"); }','static void hex(uint64_t x) { char b[17];const char *d="0123456789abcdef";for(unsigned i=0;i<16;i++)b[i]=d[(x>>(60-i*4))&15];b[16]=0;output(b); }']
for i in range(len(forms)):c.append(f'extern void op_{i}(void *,void *);')
c+=['static void (*const ops[])(void *,void *)={'+','.join('op_'+str(i) for i in range(len(forms)))+'};','static const unsigned deltas[]={'+','.join(str(x['sp_delta']) for x in forms)+'};','void main(void) { uint64_t ctl;asm volatile("mrs %0,sctlr_el1":"=r"(ctl));output("SCTLR_EL1 ");hex(ctl);output("\\n");for(unsigned i=0;i<sizeof(ops)/sizeof(ops[0]);i++){for(unsigned n=0;n<256;n++)memory[n]=(unsigned char)(n*7+3);last_esr=0;ops[i](memory+128+deltas[i],memory+64);hex(i);output(" ");hex(last_esr);output("\\n");}output("EL1_DONE\\n");uint64_t arg[2]={0x20026,0};register uint64_t x0 asm("x0")=0x20;register void *x1 asm("x1")=arg;asm volatile("hlt #0xf000":"+r"(x0):"r"(x1):"memory");for(;;){} }']
(F/'el1.c').write_text('\n'.join(c)+'\n');(F/'el1.ld').write_text('ENTRY(_start)\nSECTIONS { . = 0x40080000; .text : { *(.text.boot) *(.text*) } .rodata : { *(.rodata*) } .data : { *(.data*) } .bss : { *(.bss*) *(COMMON) } }\n')
subprocess.run(['aarch64-linux-gnu-gcc','-O2','-nostdlib','-ffreestanding','-fno-stack-protector','-mgeneral-regs-only','-Wl,--build-id=none','-T',str(F/'el1.ld'),str(F/'el1.c'),str(F/'el1.S'),'-o',str(F/'el1.elf')],check=True)
