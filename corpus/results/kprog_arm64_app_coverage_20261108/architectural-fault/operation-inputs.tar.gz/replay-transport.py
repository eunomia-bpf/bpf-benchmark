from pathlib import Path
import importlib.util,json,os,subprocess,sys,hashlib
R=Path('/workspaces/repository');E=R/'kprog/arm64/build/architectural-fault-replay';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/architectural-fault/operation-body'
if sys.argv[1]=='guest':
 live=Path(sys.argv[2]);out=live/'operations';out.mkdir();records=[]
 for family in ['memory','exclusive','control']:
  dest=out/family;dest.mkdir();binary=E/family/'cpu-differential'
  with (out/(family+'.log')).open('w') as log:p=subprocess.run([str(binary),'128',str(dest),str(dest/'cpu-states.bin')],stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(family=family,returncode=p.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
 with (out/'fault-replay.jsonl').open('w') as log:p=subprocess.run([str(E/'fault-replay')],stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(family='architectural_fault',returncode=p.returncode,binary_sha256=hashlib.sha256((E/'fault-replay').read_bytes()).hexdigest()))
 (live/'guest.json').write_text(json.dumps(dict(ok=all(x['returncode']==0 for x in records),operation_replays=records),indent=2)+'\n');sys.exit(int(any(x['returncode'] for x in records)))
else:
 s=importlib.util.spec_from_file_location('t',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t);t.__file__=__file__;t.host(results=O)
