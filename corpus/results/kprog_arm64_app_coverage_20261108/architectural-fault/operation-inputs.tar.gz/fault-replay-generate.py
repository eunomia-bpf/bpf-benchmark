from pathlib import Path
import importlib.util,json,sys,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'kprog/arm64/micro-prog'));import generate_micro_sim_proofs as g
forms=[]
def add(asm,kind,delta=0):forms.append(dict(assembly=asm,kind=kind,sp_delta=delta))
for asm in ['ldr x0,[sp]','str x0,[sp]','ldrsb x0,[sp]','ldp x0,x1,[sp]','stp x0,x1,[sp]','stxr w0,x1,[sp]','stlxr w0,x1,[sp]']:
 for delta in range(16):add(asm,'sp_alignment' if delta else 'defined',delta)
for asm in ['ldr x0,[sp,#-8]!','str x0,[sp,#-8]!','ldr x0,[sp],#8','ldp x0,x1,[sp,#-8]!']:
 add(asm,'defined');add(asm,'sp_alignment',8)
for asm in ['ldp x0,x0,[x4]','ldp xzr,xzr,[x4]'] :add(asm,'pair_overlap')
for asm in ['ldr x4,[x4,#8]!','ldr w4,[x4],#4','ldrsb x4,[x4],#1','str x4,[x4,#8]!','strb w4,[x4],#1','ldp x4,x1,[x4],#16','ldp x0,x4,[x4,#16]!','stp x4,x1,[x4],#16','stp x0,x4,[x4,#16]!']:add(asm,'writeback_overlap')
for op in ['stxr','stlxr']:
 for asm in [f'{op} w0,x0,[x4]',f'{op} w4,x1,[x4]',f'{op} wzr,xzr,[x4]']:add(asm,'exclusive_overlap')
for asm in ['ldp x4,x1,[x4]','stp x0,x0,[x4]','ldr x4,[x4]','str x4,[x4]','stxr w0,x1,[x4]','stlxr w0,x1,[x4]']:add(asm,'defined')
(F/'fault-instructions.S').write_text('.text\n'+'\n'.join(x['assembly'] for x in forms)+'\n')
subprocess.run(['aarch64-linux-gnu-gcc','-c',str(F/'fault-instructions.S'),'-o',str(F/'fault-instructions.o')],check=True)
dump=subprocess.check_output(['aarch64-linux-gnu-objdump','-d',str(F/'fault-instructions.o')],text=True);(F/'fault-instructions.asm').write_text(dump);ins=g.parse_flat_instructions(dump)
source=['''#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BYTES 512U
#define ARM64_SIM_STACK_BIAS 256LL
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/mman.h>
#include "kprog/arm64/arm64_sim_local_bpf.h"
static sigjmp_buf target;
static volatile sig_atomic_t observed_signal;
static void arm64_sim_unsupported_opcode(void) { siglongjmp(target, 1); }
unsigned long native_lab_exclusive_failure_choice(unsigned int site) { (void)site; return 1; }
static void signal_handler(int signal) { observed_signal=signal; siglongjmp(target,1); }
struct state { uint64_t r[32]; };
static struct state input, native, simulated;
static _Alignas(16) unsigned char memory[256], before[256], native_memory[256];
''']
assembly=['.text'];entries=[]
for i,(form,inst) in enumerate(zip(forms,ins)):
 encoded=g.encode(inst,{},{});form['encoding']=int(inst.raw.split(':')[1].strip().split()[0],16) if False else None
 # GNU objdump provides the instruction word immediately after its address.
 import re
 line=[x for x in dump.splitlines() if re.match(r'\s*'+format(inst.addr,'x')+r':',x)][0];word=int(line.split(':')[1].split()[0],16);form['native_bytes']=list(word.to_bytes(4,'little'))
 source+=['extern void native_'+str(i)+'(struct state *);',f'static void sim_{i}(struct state *s) {{','ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;']
 source += [f'__a64_x{r}.x=s->r[{r}];' for r in range(31)]
 source += ['__a64_sp=(int64_t)(s->r[31]-(uintptr_t)(memory+256));','memcpy(__a64_stack.b+ARM64_SIM_STACK_BIAS-256,memory,256); memset(__a64_stack_tag,0,sizeof(__a64_stack_tag));']
 source += [f'ARM64_SIM_L_EXEC({encoded.op}, {encoded.dst}, {encoded.src}, {encoded.src2}, {encoded.src3}, {encoded.width}, {encoded.aux}, {encoded.imm});']
 source += [f's->r[{r}]=__a64_x{r}.x;' for r in range(31)]
 source += ['s->r[31]=(uintptr_t)(memory+256)+__a64_sp;' + (' memcpy(memory,__a64_stack.b+ARM64_SIM_STACK_BIAS-256,256);' if '[sp' in form['assembly'] else '') + '','}']
 assembly += [f'.global native_{i}',f'native_{i}:','mov x10,x0','mov x9,sp']+[f'ldr x{r},[x10,#{r*8}]' for r in range(6)]
 assembly += ['ldr x11,[x10,#248]','mov sp,x11','clrex',form['assembly'],'mov x11,sp','mov sp,x9']+[f'str x{r},[x10,#{r*8}]' for r in range(6)]+['str x11,[x10,#248]','ret']
 entries.append(f'{{native_{i},sim_{i},{form["sp_delta"]}}}')
source += ['struct row { void (*native)(struct state *),(*sim)(struct state *); int delta; };','static const struct row rows[]={'+','.join(entries)+'};',r'''
static void registers(const struct state *s) { putchar('[');for(unsigned i=0;i<32;i++)printf("%s%llu",i?",":"",(unsigned long long)s->r[i]);putchar(']'); }
static void bytes(const unsigned char *p) { putchar('[');for(unsigned i=0;i<256;i++)printf("%s%u",i?",":"",p[i]);putchar(']'); }
int main(void) {
 stack_t alt={.ss_sp=malloc(SIGSTKSZ),.ss_size=SIGSTKSZ};sigaltstack(&alt,0);
 struct sigaction a={.sa_handler=signal_handler,.sa_flags=SA_ONSTACK};sigemptyset(&a.sa_mask);
 sigaction(SIGSEGV,&a,0);sigaction(SIGBUS,&a,0);sigaction(SIGILL,&a,0);
 for(unsigned i=0;i<sizeof(rows)/sizeof(rows[0]);i++) {
  for(unsigned n=0;n<256;n++)memory[n]=before[n]=(unsigned char)(n*7+3);
  for(unsigned r=0;r<32;r++)input.r[r]=37+r;
  input.r[4]=(uintptr_t)(memory+64);input.r[31]=(uintptr_t)(memory+128)+rows[i].delta;
  native=simulated=input;observed_signal=0;
  int native_fault=sigsetjmp(target,1);if(!native_fault)rows[i].native(&native);
  int signal=observed_signal;memcpy(native_memory,memory,256);memcpy(memory,before,256);
  int sim_fault=sigsetjmp(target,1);if(!sim_fault)rows[i].sim(&simulated);
  printf("{\"form\":%u,\"memory_base\":%llu,\"input\":",i,(unsigned long long)(uintptr_t)memory);registers(&input);
  printf(",\"native\":");registers(&native);printf(",\"simulator\":");registers(&simulated);
  printf(",\"native_signal\":%d,\"simulator_fault\":%d,\"before\":",signal,sim_fault!=0);bytes(before);
  printf(",\"native_memory\":");bytes(native_memory);printf(",\"simulator_memory\":");bytes(memory);puts("}");
 }
 return 0;
}
''']
(F/'fault-replay.c').write_text('\n'.join(source));(F/'fault-native.S').write_text('\n'.join(assembly)+'\n.section .note.GNU-stack,"",%progbits\n');(F/'fault-forms.json').write_text(json.dumps(forms,indent=2)+'\n')
subprocess.run(['aarch64-linux-gnu-gcc','-O1','-static','-g','-I'+str(R),'-I'+str(R/'vendor/libbpf/src'),'-I'+str(R/'vendor/libbpf/include/uapi'),str(F/'fault-replay.c'),str(F/'fault-native.S'),'-o',str(F/'fault-replay')],check=True)
print('fault operation forms',len(forms))
