from pathlib import Path
import json,subprocess,collections
F=Path(__file__).resolve().parent
forms=json.loads((F/'fault-forms.json').read_text());rows=[json.loads(x) for x in (F/'qemu-output/operations/fault-replay.jsonl').read_text().splitlines()];results=[]
for row in rows:
 form=forms[row['form']];base=row['memory_base'];cells=[dict(address=base+i,value=b,readable=True,writable=True,initialized=True) for i,b in enumerate(row['before'])]
 state=dict(registers=row['input'],flags=0,pc=4096,vector0=0,memory=cells,sp_alignment_check=True,exclusive_monitor=None,exclusive_inputs=dict(physical_address=row['input'][31] if '[sp' in form['assembly'] else row['input'][4],reservation=None,retain_local=False,virtual_pass=False,global_pass=False,commit_pass=False,abort_on_failure=False))
 request=dict(isa='aarch64',state=state,native_bytes=form['native_bytes']);p=subprocess.run([str(F/'reference-captured')],input=json.dumps(request)+'\n',text=True,capture_output=True)
 answer=json.loads(p.stdout) if p.returncode==0 else None;kind=form['kind'];match=False;cpu_match=None
 if kind.endswith('overlap'):
  match=bool(row['simulator_fault']) and p.returncode==1 and 'constrained-unpredictable' in p.stderr
 elif kind=='sp_alignment':
  match=bool(row['simulator_fault']) and answer is not None and answer['fault'] and answer['fault']['kind']=='sp_alignment'
  cpu_match=row['native_signal'] in [7] # SIGBUS is the Linux SP-alignment delivery.
 else:
  memory=[x['value'] for x in answer['memory']] if answer else None
  match=not row['simulator_fault'] and answer is not None and answer['fault'] is None and answer['registers']==row['simulator'] and memory==row['simulator_memory']
  cpu_match=not row['native_signal'] and answer is not None and answer['registers']==row['native'] and memory==row['native_memory']
 results.append(dict(form=row['form'],assembly=form['assembly'],kind=kind,sp_delta=form['sp_delta'],simulator_reference_match=bool(match),cpu_reference_match=cpu_match,native_signal=row['native_signal'],simulator_fault=bool(row['simulator_fault']),reference_returncode=p.returncode,reference_error=p.stderr,reference=answer,request=request))
(F/'fault-reference.json').write_text(json.dumps(dict(cases=len(results),classes=dict(collections.Counter(r['kind'] for r in results)),simulator_reference_mismatches=sum(not r['simulator_reference_match'] for r in results),cpu_reference_mismatches=sum(r['cpu_reference_match'] is False for r in results),overlap_qemu_outcomes=dict(collections.Counter('signal'+str(r['native_signal']) for r in results if r['kind'].endswith('overlap'))),rows=results),indent=2)+'\n')
print('fault reference cases',len(results),'simulator mismatches',sum(not r['simulator_reference_match'] for r in results),'CPU mismatches',sum(r['cpu_reference_match'] is False for r in results))
