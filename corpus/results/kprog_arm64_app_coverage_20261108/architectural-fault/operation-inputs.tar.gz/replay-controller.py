from pathlib import Path
import os,select,subprocess,json,datetime,tarfile,gzip,hashlib,traceback
A=Path('/workspaces/.agent-state/kprog-lanes/A');F=A/'design-only/architectural-fault';R=Path('/workspaces/repository');E=R/'kprog/arm64/build/architectural-fault-replay';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/architectural-fault'
def save(phase,**k):(F/'replay-status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**k),indent=2)+'\n')
try:
 save('waiting_operation_build',pids=[1651074,1657009])
 for pid in [1651074,1657009]:
  try:fd=os.pidfd_open(pid)
  except ProcessLookupError:continue
  select.select([fd],[],[]);os.close(fd)
 import shutil
 for family in ['memory','exclusive','control']:
  (E/family).mkdir(exist_ok=True);shutil.copy2(F/family/'cpu-differential',E/family/'cpu-differential');shutil.copy2(F/family/'coverage.json',E/family/'coverage.json')
 shutil.copy2(F/'fault-replay',E/'fault-replay');shutil.copy2(F/'fault-forms.json',E/'fault-forms.json')
 commands=['set -eu','cd '+str(R)]
 for p in sorted((F/'source').rglob('*')):
  if p.is_file():commands.append('mount --bind '+str(p)+' '+str(R/p.relative_to(F/'source')))
 commands+=['mount --bind '+str(F/'transport.py')+' '+str(R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py'),'exec python3 '+str(F/'replay-transport.py')+' host']
 # The guest executes the same driver through its repository path.
 target=E/'replay-transport.py';shutil.copy2(F/'replay-transport.py',target);commands[-1]='exec python3 '+str(target)+' host'
 (F/'replay-inside.sh').write_text('\n'.join(commands)+'\n');save('actual_qemu_operation_replay')
 with (F/'replay.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(F/'replay-inside.sh')],stdout=log,stderr=subprocess.STDOUT,cwd=R)
 save('qemu_closed',returncode=p.returncode)
 q=O/'operation-body/trusted-arm64-service-result';summary=json.loads((q/'summary.json').read_text());archive=q/summary['archive']
 with tarfile.open(archive) as t:
  for m in t.getmembers():
   if m.name.startswith('run/operations/') and m.isfile():
    target=F/'qemu-output'/m.name.removeprefix('run/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read())
 reference=R/'kprog/formal/.lake/build/bin/reference';shutil.copy2(reference,F/'reference-captured');reference=F/'reference-captured'
 save('actual_reference_replay',qemu_returncode=p.returncode)
 codes={}
 for family in ['memory','exclusive','control']:
  cmd=['python3',str(R/'kprog/fidelity'/('arm64_reference_path.py' if family=='control' else 'reference_check.py')),'--binary',str(E/family/'cpu-differential'),'--reference',str(reference),'--cases','128','--out',str(F/'qemu-output/operations'/family)]
  if family!='control':cmd+=['--arch','arm64','--reuse-trace']
  with (F/(family+'-reference.log')).open('w') as log:done=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,cwd=R)
  codes[family]=done.returncode
 save('reference_closed',qemu_returncode=p.returncode,reference_returncodes=codes,reference_sha256=hashlib.sha256(reference.read_bytes()).hexdigest())
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
