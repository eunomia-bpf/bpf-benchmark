from pathlib import Path
import os,select,subprocess,json,datetime,shutil,tarfile,traceback
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository');E=R/'kprog/arm64/build/architectural-fault-replay';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/architectural-fault/fault-body'
def save(phase,**kw):(F/'fault-retry-status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
try:
 try:fd=os.pidfd_open(1659938)
 except ProcessLookupError:fd=None
 if fd is not None:select.select([fd],[],[]);os.close(fd)
 shutil.copy2(F/'fault-replay',E/'fault-replay')
 p=F/'replay-transport.py';s=p.read_text().replace("architectural-fault/operation-body'","architectural-fault/fault-body'").replace("for family in ['memory','exclusive','control']:","for family in []:")
 (E/'fault-transport.py').write_text(s)
 inside=(F/'replay-inside.sh').read_text().replace(str(E/'replay-transport.py'),str(E/'fault-transport.py'));(F/'fault-inside.sh').write_text(inside)
 save('actual_qemu_fault_body')
 with (F/'fault-qemu.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(F/'fault-inside.sh')],stdout=log,stderr=subprocess.STDOUT,cwd=R)
 q=O/'trusted-arm64-service-result';summary=json.loads((q/'summary.json').read_text())
 with tarfile.open(q/summary['archive']) as t:
  raw=t.extractfile('run/operations/fault-replay.jsonl').read();(F/'qemu-output/operations/fault-replay.jsonl').write_bytes(raw)
 with (F/'fault-reference.log').open('w') as log:c=subprocess.run(['python3',str(F/'fault-reference.py')],stdout=log,stderr=subprocess.STDOUT)
 save('finished',qemu_exit=p.returncode,reference_exit=c.returncode)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
