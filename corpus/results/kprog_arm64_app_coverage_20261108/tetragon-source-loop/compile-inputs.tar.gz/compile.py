from pathlib import Path
import hashlib,json,shlex,subprocess
R=Path('/workspaces/repository');F=Path(__file__).resolve().parent
rows=[]
def run(label,args,cwd=R,capture=False):
 with (F/(label+'.stdout')).open('w') as o,(F/(label+'.stderr')).open('w') as e:p=subprocess.run(args,cwd=cwd,stdout=o,stderr=e)
 rows.append(dict(label=label,command=args,cwd=str(cwd),returncode=p.returncode));(F/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 return p.returncode
base=['make','--no-print-directory','-s','-C',str(R/'vendor/bpf'),'ARCH=arm64','BUILD='+str(F/'build'),'OUT='+str(F/'out'),'CLANG=/usr/lib/llvm-18/bin/clang']
plugin=F/'build/arm64/stage/native_division.so'
rc=run('division-plugin',base+[str(plugin)])
args=base+['--eval=print-native:\n\t@echo $(NATIVE_CFLAGS)\n','print-native']
rc2=run('native-flags',args)
if rc==0 and rc2==0:
 flags=shlex.split((F/'native-flags.stdout').read_text())
 root=R/'vendor/bpf/tetragon/bpf'
 native=F/'bpf_execve_event_v511.native.o'
 cmd=['/usr/lib/llvm-18/bin/clang',*flags,'-march=armv8.1-a+lse','-DMICRO_NATIVE_HELPER_MACROS','-DMICRO_NATIVE_TETRAGON','-D__TARGET_ARCH_arm64','-include',str(R/'vendor/bpf/native_compat.h'),'-D__LARGE_BPF_PROG','-D__V511_BPF_PROG']
 for p in [root,root/'include',root/'lib',root/'libbpf',root/'process',root/'errmetrics',Path('/usr/aarch64-linux-gnu/include')]:cmd+=['-I',str(p)]
 cmd+=['-o',str(native),str(root/'process/bpf_execve_event.c')]
 run('native-v511',cmd)
bpf=F/'bpf/bpf_execve_event_v511.o'
run('bpf-v511',['make','--no-print-directory','-C',str(R/'vendor/bpf/tetragon/bpf'),'CLANG=/usr/lib/llvm-18/bin/clang','LLC=/usr/lib/llvm-18/bin/llc','BPF_TARGET_ARCH=arm64','OBJSDIR='+str(F/'bpf')+'/','DEPSDIR='+str(F/'deps')+'/',str(bpf),'-j2'])
artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [F/'bpf_execve_event_v511.native.o',bpf] if p.exists()}
(F/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
