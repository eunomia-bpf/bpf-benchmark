from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-source-loop';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('same_source_bpf_and_native_compile')
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 commands=json.loads((F/'commands.json').read_text())
 report=dict(utc=now(),driver_exit=p.returncode,source=json.loads((F/'source-change.json').read_text()),commands=commands,artifacts=json.loads((F/'artifacts.json').read_text()),outcome='Both compiler outcomes are recorded; verifier and whole-application outcomes follow.')
 (O/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 D=R/'corpus/results/kprog_app_source_changes'
 readme=D/'README.md'
 if not readme.exists():readme.write_text('Application source changes\n\nOperator2026-11-08 authorizes small application eBPF C changes after hard generic simulator/compiler attempts. Each comparison builds the JIT baseline and native program from the same edited source bytes. Kernel selftests and safety cases retain their published sources.\n\n| Application | Original source / function | Trigger | Edit and preserved behavior | Outcome | Patch |\n| --- | --- | --- | --- | --- | --- |\n')
 outcomes=', '.join(c['label']+' exit'+str(c['returncode']) for c in commands)
 with readme.open('a') as f:f.write('| Tetragon | vendor/bpf/tetragon/bpf/lib/bpf_d_path.h: prepend_path, used by read_exe/execve_send | Stock8193-jump sequence,667530instructions/6806states after generic frame/tag/extent epochs c9a653161 and006a97056 | Existing modern large-program counted path loop uses unroll(disable); original bound, iteration order, cwd_read body, break and output/error handling stay exact. Small legacy/V61helper branches retain their form. | '+outcomes+'; actual verifier and complete application replay continue | [tetragon-path-loop.patch](tetragon-path-loop.patch) |\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 paths=['vendor/bpf/tetragon/bpf/lib/bpf_d_path.h',str(readme.relative_to(R)),str((D/'tetragon-path-loop.patch').relative_to(R))]+[str((O/n).relative_to(R)) for n in ['compile.json','compile-inputs.tar.gz']]
 rec=pub.publish(paths,'Keep Tetragon path traversal counted in the matched original source','arm-tetragon-source-loop')
 save('compiled_source_published',publication=rec,report=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' operator-authorized original Tetragon source loop directive, exact patch/required row in corpus/results/kprog_app_source_changes/README.md. Same edited source compilers: '+outcomes+'. Existing bound/body/order/break/helper/output behavior retained; generic kernel/selftest/safety source unchanged. Verifier and complete matched-source app replay follow actual compiler artifacts. Runtime predicate/gate/limit additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
