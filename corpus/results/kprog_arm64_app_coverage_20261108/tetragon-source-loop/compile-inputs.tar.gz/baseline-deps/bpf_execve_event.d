/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_execve_event.o: \
  process/bpf_execve_event.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/environ_conf.h \
  process/bpf_process_event.h lib/bpf_cgroup.h libbpf/bpf_tracing.h \
  include/bpf_ktime.h cgroup/cgtracker.h process/bpf_rate.h \
  process/bpf_mbset.h process/data_event.h lib/data_msg.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
process/bpf_process_event.h:
lib/bpf_cgroup.h:
libbpf/bpf_tracing.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/bpf_rate.h:
process/bpf_mbset.h:
process/data_event.h:
lib/data_msg.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_execve_event.ll: \
  process/bpf_execve_event.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/environ_conf.h \
  process/bpf_process_event.h lib/bpf_cgroup.h libbpf/bpf_tracing.h \
  include/bpf_ktime.h cgroup/cgtracker.h process/bpf_rate.h \
  process/bpf_mbset.h process/data_event.h lib/data_msg.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
process/bpf_process_event.h:
lib/bpf_cgroup.h:
libbpf/bpf_tracing.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/bpf_rate.h:
process/bpf_mbset.h:
process/data_event.h:
lib/data_msg.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_execve_event.i: \
  process/bpf_execve_event.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/environ_conf.h \
  process/bpf_process_event.h lib/bpf_cgroup.h libbpf/bpf_tracing.h \
  include/bpf_ktime.h cgroup/cgtracker.h process/bpf_rate.h \
  process/bpf_mbset.h process/data_event.h lib/data_msg.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
process/bpf_process_event.h:
lib/bpf_cgroup.h:
libbpf/bpf_tracing.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/bpf_rate.h:
process/bpf_mbset.h:
process/data_event.h:
lib/data_msg.h:
