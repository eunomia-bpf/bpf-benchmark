/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_cgroup.o: \
  process/bpf_cgroup.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/compiler.h lib/bpf_cgroup.h \
  lib/bpf_event.h lib/bpf_helpers.h include/api.h include/bpf_elf.h \
  libbpf/bpf_core_read.h lib/environ_conf.h lib/common.h lib/process.h \
  lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h process/bpf_rate.h libbpf/bpf_tracing.h \
  lib/msg_types.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/compiler.h:
lib/bpf_cgroup.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_core_read.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
process/bpf_rate.h:
libbpf/bpf_tracing.h:
lib/msg_types.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_cgroup.ll: \
  process/bpf_cgroup.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/compiler.h lib/bpf_cgroup.h \
  lib/bpf_event.h lib/bpf_helpers.h include/api.h include/bpf_elf.h \
  libbpf/bpf_core_read.h lib/environ_conf.h lib/common.h lib/process.h \
  lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h process/bpf_rate.h libbpf/bpf_tracing.h \
  lib/msg_types.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/compiler.h:
lib/bpf_cgroup.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_core_read.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
process/bpf_rate.h:
libbpf/bpf_tracing.h:
lib/msg_types.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_cgroup.i: \
  process/bpf_cgroup.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/compiler.h lib/bpf_cgroup.h \
  lib/bpf_event.h lib/bpf_helpers.h include/api.h include/bpf_elf.h \
  libbpf/bpf_core_read.h lib/environ_conf.h lib/common.h lib/process.h \
  lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h process/bpf_rate.h libbpf/bpf_tracing.h \
  lib/msg_types.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/compiler.h:
lib/bpf_cgroup.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_core_read.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
process/bpf_rate.h:
libbpf/bpf_tracing.h:
lib/msg_types.h:
