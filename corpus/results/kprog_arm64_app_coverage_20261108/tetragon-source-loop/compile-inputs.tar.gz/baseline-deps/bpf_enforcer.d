/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_enforcer.o: \
  process/bpf_enforcer.c include/compiler.h process/bpf_enforcer.h \
  include/vmlinux.h include/vmlinux_generated_arm64.h lib/bpf_helpers.h \
  include/api.h include/bpf_elf.h libbpf/bpf_core_read.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h
include/compiler.h:
process/bpf_enforcer.h:
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_core_read.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_enforcer.ll: \
  process/bpf_enforcer.c include/compiler.h process/bpf_enforcer.h \
  include/vmlinux.h include/vmlinux_generated_arm64.h lib/bpf_helpers.h \
  include/api.h include/bpf_elf.h libbpf/bpf_core_read.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h
include/compiler.h:
process/bpf_enforcer.h:
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_core_read.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_enforcer.i: \
  process/bpf_enforcer.c include/compiler.h process/bpf_enforcer.h \
  include/vmlinux.h include/vmlinux_generated_arm64.h lib/bpf_helpers.h \
  include/api.h include/bpf_elf.h libbpf/bpf_core_read.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h
include/compiler.h:
process/bpf_enforcer.h:
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_core_read.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
