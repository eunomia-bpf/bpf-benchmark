/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_loader_v511.o: \
  process/bpf_loader.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h libbpf/bpf_tracing.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_event.h lib/bpf_task.h lib/generic.h \
  lib/common.h lib/msg_types.h lib/process.h lib/bpf_cred.h \
  lib/bpf_d_path.h lib/config.h lib/../process/string_maps.h \
  lib/policy_stats.h lib/policy_conf.h lib/errmetrics.h lib/err.h \
  include/errno.h errmetrics/get_fileid.h errmetrics/fileids.h \
  lib/environ_conf.h include/bpf_ktime.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
libbpf/bpf_tracing.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_event.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
include/bpf_ktime.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_loader_v511.ll: \
  process/bpf_loader.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h libbpf/bpf_tracing.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_event.h lib/bpf_task.h lib/generic.h \
  lib/common.h lib/msg_types.h lib/process.h lib/bpf_cred.h \
  lib/bpf_d_path.h lib/config.h lib/../process/string_maps.h \
  lib/policy_stats.h lib/policy_conf.h lib/errmetrics.h lib/err.h \
  include/errno.h errmetrics/get_fileid.h errmetrics/fileids.h \
  lib/environ_conf.h include/bpf_ktime.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
libbpf/bpf_tracing.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_event.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
include/bpf_ktime.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_loader_v511.i: \
  process/bpf_loader.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h libbpf/bpf_tracing.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_event.h lib/bpf_task.h lib/generic.h \
  lib/common.h lib/msg_types.h lib/process.h lib/bpf_cred.h \
  lib/bpf_d_path.h lib/config.h lib/../process/string_maps.h \
  lib/policy_stats.h lib/policy_conf.h lib/errmetrics.h lib/err.h \
  include/errno.h errmetrics/get_fileid.h errmetrics/fileids.h \
  lib/environ_conf.h include/bpf_ktime.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
libbpf/bpf_tracing.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_event.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
include/bpf_ktime.h:
