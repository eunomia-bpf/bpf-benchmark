/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_alignchecker.o: \
  alignchecker/bpf_alignchecker.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_cred.h process/retprobe_map.h \
  libbpf/bpf_tracing.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h process/types/basic.h \
  process/types/operations.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/environ_conf.h process/types/skb.h process/types/tuple.h \
  process/types/sock.h process/types/sockaddr.h process/types/socket.h \
  process/types/net_device.h process/types/../bpf_process_event.h \
  lib/bpf_cgroup.h include/bpf_ktime.h cgroup/cgtracker.h \
  process/types/bpfattr.h process/types/perfevent.h \
  process/types/bpfmap.h process/types/capabilities.h \
  process/types/module.h process/types/../argfilter_maps.h \
  process/types/../addr_lpm_maps.h process/types/../string_maps.h \
  process/data_event.h lib/data_msg.h process/bpf_enforcer.h \
  process/types/../syscall64.h process/ratelimit_maps.h process/heap.h \
  process/types/../bpf_mbset.h process/types/../cel_expr.h \
  process/event_config.h process/generic_maps.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_cred.h:
process/retprobe_map.h:
libbpf/bpf_tracing.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
process/types/basic.h:
process/types/operations.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/environ_conf.h:
process/types/skb.h:
process/types/tuple.h:
process/types/sock.h:
process/types/sockaddr.h:
process/types/socket.h:
process/types/net_device.h:
process/types/../bpf_process_event.h:
lib/bpf_cgroup.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/types/bpfattr.h:
process/types/perfevent.h:
process/types/bpfmap.h:
process/types/capabilities.h:
process/types/module.h:
process/types/../argfilter_maps.h:
process/types/../addr_lpm_maps.h:
process/types/../string_maps.h:
process/data_event.h:
lib/data_msg.h:
process/bpf_enforcer.h:
process/types/../syscall64.h:
process/ratelimit_maps.h:
process/heap.h:
process/types/../bpf_mbset.h:
process/types/../cel_expr.h:
process/event_config.h:
process/generic_maps.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_alignchecker.ll: \
  alignchecker/bpf_alignchecker.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_cred.h process/retprobe_map.h \
  libbpf/bpf_tracing.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h process/types/basic.h \
  process/types/operations.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/environ_conf.h process/types/skb.h process/types/tuple.h \
  process/types/sock.h process/types/sockaddr.h process/types/socket.h \
  process/types/net_device.h process/types/../bpf_process_event.h \
  lib/bpf_cgroup.h include/bpf_ktime.h cgroup/cgtracker.h \
  process/types/bpfattr.h process/types/perfevent.h \
  process/types/bpfmap.h process/types/capabilities.h \
  process/types/module.h process/types/../argfilter_maps.h \
  process/types/../addr_lpm_maps.h process/types/../string_maps.h \
  process/data_event.h lib/data_msg.h process/bpf_enforcer.h \
  process/types/../syscall64.h process/ratelimit_maps.h process/heap.h \
  process/types/../bpf_mbset.h process/types/../cel_expr.h \
  process/event_config.h process/generic_maps.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_cred.h:
process/retprobe_map.h:
libbpf/bpf_tracing.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
process/types/basic.h:
process/types/operations.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/environ_conf.h:
process/types/skb.h:
process/types/tuple.h:
process/types/sock.h:
process/types/sockaddr.h:
process/types/socket.h:
process/types/net_device.h:
process/types/../bpf_process_event.h:
lib/bpf_cgroup.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/types/bpfattr.h:
process/types/perfevent.h:
process/types/bpfmap.h:
process/types/capabilities.h:
process/types/module.h:
process/types/../argfilter_maps.h:
process/types/../addr_lpm_maps.h:
process/types/../string_maps.h:
process/data_event.h:
lib/data_msg.h:
process/bpf_enforcer.h:
process/types/../syscall64.h:
process/ratelimit_maps.h:
process/heap.h:
process/types/../bpf_mbset.h:
process/types/../cel_expr.h:
process/event_config.h:
process/generic_maps.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_alignchecker.i: \
  alignchecker/bpf_alignchecker.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_cred.h process/retprobe_map.h \
  libbpf/bpf_tracing.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h process/types/basic.h \
  process/types/operations.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/environ_conf.h process/types/skb.h process/types/tuple.h \
  process/types/sock.h process/types/sockaddr.h process/types/socket.h \
  process/types/net_device.h process/types/../bpf_process_event.h \
  lib/bpf_cgroup.h include/bpf_ktime.h cgroup/cgtracker.h \
  process/types/bpfattr.h process/types/perfevent.h \
  process/types/bpfmap.h process/types/capabilities.h \
  process/types/module.h process/types/../argfilter_maps.h \
  process/types/../addr_lpm_maps.h process/types/../string_maps.h \
  process/data_event.h lib/data_msg.h process/bpf_enforcer.h \
  process/types/../syscall64.h process/ratelimit_maps.h process/heap.h \
  process/types/../bpf_mbset.h process/types/../cel_expr.h \
  process/event_config.h process/generic_maps.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_cred.h:
process/retprobe_map.h:
libbpf/bpf_tracing.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
process/types/basic.h:
process/types/operations.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/environ_conf.h:
process/types/skb.h:
process/types/tuple.h:
process/types/sock.h:
process/types/sockaddr.h:
process/types/socket.h:
process/types/net_device.h:
process/types/../bpf_process_event.h:
lib/bpf_cgroup.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/types/bpfattr.h:
process/types/perfevent.h:
process/types/bpfmap.h:
process/types/capabilities.h:
process/types/module.h:
process/types/../argfilter_maps.h:
process/types/../addr_lpm_maps.h:
process/types/../string_maps.h:
process/data_event.h:
lib/data_msg.h:
process/bpf_enforcer.h:
process/types/../syscall64.h:
process/ratelimit_maps.h:
process/heap.h:
process/types/../bpf_mbset.h:
process/types/../cel_expr.h:
process/event_config.h:
process/generic_maps.h:
