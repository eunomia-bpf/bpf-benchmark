/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_map_test_p1.o: \
  process/bpf_map_test_p1.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  libbpf/bpf_tracing.h lib/bpf_helpers.h include/compiler.h \
  libbpf/bpf_core_read.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_map_test_p1.ll: \
  process/bpf_map_test_p1.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  libbpf/bpf_tracing.h lib/bpf_helpers.h include/compiler.h \
  libbpf/bpf_core_read.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_map_test_p1.i: \
  process/bpf_map_test_p1.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  libbpf/bpf_tracing.h lib/bpf_helpers.h include/compiler.h \
  libbpf/bpf_core_read.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
