/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_prog_iter.o: \
  process/bpf_prog_iter.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h lib/bpf_helpers.h include/api.h \
  include/bpf_elf.h include/compiler.h libbpf/bpf_core_read.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
libbpf/bpf_core_read.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_prog_iter.ll: \
  process/bpf_prog_iter.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h lib/bpf_helpers.h include/api.h \
  include/bpf_elf.h include/compiler.h libbpf/bpf_core_read.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
libbpf/bpf_core_read.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_prog_iter.i: \
  process/bpf_prog_iter.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h lib/bpf_helpers.h include/api.h \
  include/bpf_elf.h include/compiler.h libbpf/bpf_core_read.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
lib/bpf_helpers.h:
include/api.h:
include/bpf_elf.h:
include/compiler.h:
libbpf/bpf_core_read.h:
