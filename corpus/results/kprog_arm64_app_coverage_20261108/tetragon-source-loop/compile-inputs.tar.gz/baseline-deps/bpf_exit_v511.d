/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_exit_v511.o: \
  process/bpf_exit.c include/vmlinux.h include/vmlinux_generated_arm64.h \
  include/compiler.h process/bpf_exit.h include/api.h include/bpf_elf.h \
  lib/bpf_event.h lib/bpf_helpers.h libbpf/bpf_core_read.h \
  lib/bpf_task.h lib/generic.h lib/common.h lib/msg_types.h \
  lib/process.h lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h lib/environ_conf.h process/bpf_rate.h \
  libbpf/bpf_tracing.h process/bpf_process_event.h lib/bpf_cgroup.h \
  include/bpf_ktime.h cgroup/cgtracker.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/compiler.h:
process/bpf_exit.h:
include/api.h:
include/bpf_elf.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
process/bpf_rate.h:
libbpf/bpf_tracing.h:
process/bpf_process_event.h:
lib/bpf_cgroup.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_exit_v511.ll: \
  process/bpf_exit.c include/vmlinux.h include/vmlinux_generated_arm64.h \
  include/compiler.h process/bpf_exit.h include/api.h include/bpf_elf.h \
  lib/bpf_event.h lib/bpf_helpers.h libbpf/bpf_core_read.h \
  lib/bpf_task.h lib/generic.h lib/common.h lib/msg_types.h \
  lib/process.h lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h lib/environ_conf.h process/bpf_rate.h \
  libbpf/bpf_tracing.h process/bpf_process_event.h lib/bpf_cgroup.h \
  include/bpf_ktime.h cgroup/cgtracker.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/compiler.h:
process/bpf_exit.h:
include/api.h:
include/bpf_elf.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
process/bpf_rate.h:
libbpf/bpf_tracing.h:
process/bpf_process_event.h:
lib/bpf_cgroup.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_exit_v511.i: \
  process/bpf_exit.c include/vmlinux.h include/vmlinux_generated_arm64.h \
  include/compiler.h process/bpf_exit.h include/api.h include/bpf_elf.h \
  lib/bpf_event.h lib/bpf_helpers.h libbpf/bpf_core_read.h \
  lib/bpf_task.h lib/generic.h lib/common.h lib/msg_types.h \
  lib/process.h lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h lib/environ_conf.h process/bpf_rate.h \
  libbpf/bpf_tracing.h process/bpf_process_event.h lib/bpf_cgroup.h \
  include/bpf_ktime.h cgroup/cgtracker.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/compiler.h:
process/bpf_exit.h:
include/api.h:
include/bpf_elf.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_task.h:
lib/generic.h:
lib/common.h:
lib/msg_types.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
process/bpf_rate.h:
libbpf/bpf_tracing.h:
process/bpf_process_event.h:
lib/bpf_cgroup.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
