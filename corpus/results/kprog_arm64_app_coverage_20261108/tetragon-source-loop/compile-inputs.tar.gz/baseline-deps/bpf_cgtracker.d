/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_cgtracker.o: \
  cgroup/bpf_cgtracker.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  lib/bpf_helpers.h include/compiler.h libbpf/bpf_core_read.h \
  lib/bpf_cgroup.h lib/bpf_event.h lib/environ_conf.h lib/common.h \
  lib/process.h lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h libbpf/bpf_tracing.h cgroup/cgtracker.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
lib/bpf_cgroup.h:
lib/bpf_event.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
libbpf/bpf_tracing.h:
cgroup/cgtracker.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_cgtracker.ll: \
  cgroup/bpf_cgtracker.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  lib/bpf_helpers.h include/compiler.h libbpf/bpf_core_read.h \
  lib/bpf_cgroup.h lib/bpf_event.h lib/environ_conf.h lib/common.h \
  lib/process.h lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h libbpf/bpf_tracing.h cgroup/cgtracker.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
lib/bpf_cgroup.h:
lib/bpf_event.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
libbpf/bpf_tracing.h:
cgroup/cgtracker.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_cgtracker.i: \
  cgroup/bpf_cgtracker.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  lib/bpf_helpers.h include/compiler.h libbpf/bpf_core_read.h \
  lib/bpf_cgroup.h lib/bpf_event.h lib/environ_conf.h lib/common.h \
  lib/process.h lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h libbpf/bpf_tracing.h cgroup/cgtracker.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
lib/bpf_cgroup.h:
lib/bpf_event.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
libbpf/bpf_tracing.h:
cgroup/cgtracker.h:
