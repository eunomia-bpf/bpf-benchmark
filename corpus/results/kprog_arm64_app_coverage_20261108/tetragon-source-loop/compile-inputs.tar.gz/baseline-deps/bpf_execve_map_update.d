/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_execve_map_update.o: \
  process/bpf_execve_map_update.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  libbpf/bpf_tracing.h lib/common.h lib/process.h lib/bpf_event.h \
  lib/bpf_helpers.h include/compiler.h libbpf/bpf_core_read.h \
  lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h lib/environ_conf.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
lib/common.h:
lib/process.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_execve_map_update.ll: \
  process/bpf_execve_map_update.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  libbpf/bpf_tracing.h lib/common.h lib/process.h lib/bpf_event.h \
  lib/bpf_helpers.h include/compiler.h libbpf/bpf_core_read.h \
  lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h lib/environ_conf.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
lib/common.h:
lib/process.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_execve_map_update.i: \
  process/bpf_execve_map_update.c include/vmlinux.h \
  include/vmlinux_generated_arm64.h include/api.h include/bpf_elf.h \
  libbpf/bpf_tracing.h lib/common.h lib/process.h lib/bpf_event.h \
  lib/bpf_helpers.h include/compiler.h libbpf/bpf_core_read.h \
  lib/bpf_cred.h lib/bpf_d_path.h lib/config.h \
  lib/../process/string_maps.h lib/policy_stats.h lib/policy_conf.h \
  lib/errmetrics.h lib/err.h include/errno.h errmetrics/get_fileid.h \
  errmetrics/fileids.h lib/environ_conf.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
lib/common.h:
lib/process.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
include/compiler.h:
libbpf/bpf_core_read.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/environ_conf.h:
