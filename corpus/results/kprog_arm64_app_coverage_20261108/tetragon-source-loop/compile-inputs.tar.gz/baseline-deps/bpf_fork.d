/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_fork.o: \
  process/bpf_fork.c include/vmlinux.h include/vmlinux_generated_arm64.h \
  include/api.h include/bpf_elf.h libbpf/bpf_tracing.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_cgroup.h lib/environ_conf.h \
  lib/common.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/bpf_task.h \
  lib/generic.h lib/msg_types.h process/bpf_process_event.h \
  include/bpf_ktime.h cgroup/cgtracker.h process/bpf_rate.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_cgroup.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/bpf_task.h:
lib/generic.h:
lib/msg_types.h:
process/bpf_process_event.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/bpf_rate.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_fork.ll: \
  process/bpf_fork.c include/vmlinux.h include/vmlinux_generated_arm64.h \
  include/api.h include/bpf_elf.h libbpf/bpf_tracing.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_cgroup.h lib/environ_conf.h \
  lib/common.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/bpf_task.h \
  lib/generic.h lib/msg_types.h process/bpf_process_event.h \
  include/bpf_ktime.h cgroup/cgtracker.h process/bpf_rate.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_cgroup.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/bpf_task.h:
lib/generic.h:
lib/msg_types.h:
process/bpf_process_event.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/bpf_rate.h:
/workspaces/.agent-state/kprog-lanes/A/app-source/tetragon-loop/bpf/bpf_fork.i: \
  process/bpf_fork.c include/vmlinux.h include/vmlinux_generated_arm64.h \
  include/api.h include/bpf_elf.h libbpf/bpf_tracing.h \
  include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_cgroup.h lib/environ_conf.h \
  lib/common.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/bpf_task.h \
  lib/generic.h lib/msg_types.h process/bpf_process_event.h \
  include/bpf_ktime.h cgroup/cgtracker.h process/bpf_rate.h
include/vmlinux.h:
include/vmlinux_generated_arm64.h:
include/api.h:
include/bpf_elf.h:
libbpf/bpf_tracing.h:
include/compiler.h:
lib/bpf_event.h:
lib/bpf_helpers.h:
libbpf/bpf_core_read.h:
lib/bpf_cgroup.h:
lib/environ_conf.h:
lib/common.h:
lib/process.h:
lib/bpf_cred.h:
lib/bpf_d_path.h:
lib/config.h:
lib/../process/string_maps.h:
lib/policy_stats.h:
lib/policy_conf.h:
lib/errmetrics.h:
lib/err.h:
include/errno.h:
errmetrics/get_fileid.h:
errmetrics/fileids.h:
lib/bpf_task.h:
lib/generic.h:
lib/msg_types.h:
process/bpf_process_event.h:
include/bpf_ktime.h:
cgroup/cgtracker.h:
process/bpf_rate.h:
