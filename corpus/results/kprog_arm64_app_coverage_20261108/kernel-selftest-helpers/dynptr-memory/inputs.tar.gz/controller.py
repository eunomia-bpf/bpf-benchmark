from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,subprocess,sys,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers/dynptr-memory';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('existing_controls')
 commands=[
 ['python3','kprog/formal/tools/generate_arm64_helper_idents_spec.py','--check'],
 ['cc','-Wall','-Wextra','-O2','-Ikprog/formal','kprog/formal/oracles/test_arm64_helper_idents_host.c','-o',str(G/'identity-host')],
 [str(G/'identity-host')],
 ['cc','-include','kprog/formal/oracles/arm64_entry_environment_host.h','-DKPROG_TEST_EXCLUSIVE_FAILURE=0','-include','kprog/formal/oracles/arm64_exclusive_choice_host.h','-Wall','-Wextra','-O2','-Ikprog/formal','-Ikprog/arm64','-Ikprog','-Ivendor/libbpf/src','kprog/formal/oracles/test_arm64_helper_call_host.c','-o',str(G/'helper-abi-host')],
 [str(G/'helper-abi-host')],
 ['lake','build','KProgFormal.Arm64HelperIdents']]
 results=[]
 for i,cmd in enumerate(commands):
  cwd=R/'kprog/formal' if cmd[0]=='lake' else R
  with (G/f'control-{i}.log').open('w') as log:p=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
  results.append(dict(command=cmd,cwd=str(cwd),returncode=p.returncode))
  (G/'controls.json').write_text(json.dumps(results,indent=2)+'\n')
  if p.returncode:raise RuntimeError('Existing control failed: '+str(cmd))
 save('original_family_generation',controls=results)
 P=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full-paired-resources'
 rows=json.loads((P/'submissions.json').read_text())['programs'];rows=[r for r in rows if r['file']=='dynptr_fail.c']
 Q=P/'trusted-arm64-service-result';d=json.loads((Q/'summary.json').read_text());outer=tarfile.open(Q/d['archive'])
 sys.path.insert(0,str(R/'kprog'))
 spec=importlib.util.spec_from_file_location('arm_worker',R/'kprog/arm64/trusted_specializer.py');worker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=worker;spec.loader.exec_module(worker)
 linker=R/'kprog/x86/native_lab/native_link/target/release/native-link'
 observed=[]
 for row in rows:
  record={k:row.get(k) for k in ['file','program','expect','request_id','native_sha256','stage','diagnostic']};record['previous_stage']=record.pop('stage');out=G/'generated'/row['program']
  match=next((m for m in outer.getmembers() if m.name.endswith('/'+str(row.get('request_id'))+'.failure.tar.gz') or m.name.endswith('/'+str(row.get('request_id'))+'.success.tar.gz')),None)
  if match is None:
   record.update(stage='archived_request_input',diagnostic='Original row retains its resource outcome');observed.append(record);continue
  inner=tarfile.open(fileobj=io.BytesIO(outer.extractfile(match).read()))
  try:
   native=inner.extractfile('request/kernel.native.o').read();metadata=json.loads(inner.extractfile('request/generation.metadata.json').read())
   out.parent.mkdir(parents=True,exist_ok=True)
   artifact=worker.specialize(native,row['program'],metadata,out,linker);(out/'generation.metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');record.update(stage='generated_compiled',native_sha256=artifact['native_sha256'])
  except BaseException as e:record.update(stage='generation_or_compile_failed',diagnostic=str(e),traceback=traceback.format_exc())
  observed.append(record);(G/'generation.json').write_text(json.dumps(dict(programs=observed,counts=dict(collections.Counter(r['stage'] for r in observed))),indent=2)+'\n')
 paths=json.loads((G/'owned-paths.json').read_text());(G/'own-production.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--',*paths],cwd=R))
 pspec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(pspec);pspec.loader.exec_module(pub)
 source=pub.publish(paths,'Model ARM dynptr initialization from memory','arm-dynptr-memory-source')
 report=dict(utc=now(),source_publication=source,controls=results,generation=json.loads((G/'generation.json').read_text()),scope='Complete original dynptr_fail native family, archived input P and actual metadata; host generation and compilation',runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json'] and not p.name.endswith('.index'):tf.add(p,arcname=str(p.relative_to(G)))
  for p in paths:tf.add(R/p,arcname='source/'+p)
 (O/'README.md').write_text('Generic ARM dynptr initialization from memory\n\nHelper197 uses its actual four-argument kernel ABI: data pointer,64bit size,64bit flags and opaque dynptr destination. Paired helpers.c initializes all16opaque bytes on success and clears them on every error. The model captures destination before AAPCS clobbers and applies the existing shadow-tag transfer to those16bytes. Existing92row identity/C-ABI/Lean controls and the complete original81native-entry dynptr_fail family generation outcomes are captured. Source and all original annotations retain their bytes. Load-only QEMU verifier results follow the captured family queue. Runtime admission additions:0.\n')

 rec=pub.publish([str((O/n).relative_to(R)) for n in ['summary.json','inputs.tar.gz','README.md']],'Collect original ARM dynptr family after memory initialization support','arm-dynptr-memory-results')
 (G/'publication.json').write_text(json.dumps(dict(source=source,results=rec),indent=2)+'\n')
 save('finished',source_publication=source,publication=rec,counts=report['generation']['counts'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+source['commit']+' ARM generic helper197 memory initialization and existing92identity contract; result '+rec['commit']+' existing identity/164typed ABI/Lean controls and original dynptr_fail family generation '+json.dumps(report['generation']['counts'])+'. Exact P/metadata/C/B/compiler logs retained; stock verifier outcomes follow QEMU. Active full/app captured epochs retained. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
