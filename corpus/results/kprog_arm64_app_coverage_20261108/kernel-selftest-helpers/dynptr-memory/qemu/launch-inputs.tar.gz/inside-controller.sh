set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/bpf34/dynptr-memory/qemu/runtime /workspaces/repository/kprog/arm64/build/native-load-recovery/recovery
exec python3 /workspaces/.agent-state/kprog-lanes/A/bpf34/dynptr-memory/qemu/controller.py
