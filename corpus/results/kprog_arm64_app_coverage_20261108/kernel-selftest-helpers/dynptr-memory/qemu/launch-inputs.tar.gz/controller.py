from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers/dynptr-memory/qemu';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(t):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': '+t+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('queued_after_original_91helper_family')
 try:
  fd=os.pidfd_open(int((A/'bpf34/ringbuf-dynptr/qemu/controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 stage=R/'kprog/arm64/build/native-load-recovery/recovery'
 binaries={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
 for p in (F/'source').rglob('*'):
  if p.is_file() and p.name in binaries:shutil.copy2(stage/binaries[p.name],p)
 report=json.loads((F/'compile.json').read_text());(O/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Complete original ARM dynptr family with LOCAL memory initialization\n\nAll86original dynptr_fail annotations and81native entries retain original source/native bytes and the complete original map/BTF object. Every native request uses source0/load-only. The captured92helper model includes197from_mem and198/199/200ringbuf. Image/module/loader/linker are the privately copiedf1/e5recovery runtime. This successor follows the complete91helper family bypidfd, on2GiB12-15. Every actual generation/compiler/resource/verifier/installed outcome remains recorded. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','compile.json','launch-inputs.tar.gz']],'Replay the complete ARM catalog with all59 paired resource objects','arm-dynptr-memory-qemu-launch')
 save('actual_original_dynptr_family',publication=rec);notice('PUSHED '+rec['commit']+' complete original ARM dynptr_fail family with the original dynptr_fail resource object, original family native bytes, RAW helper context identity and paired upstream bpf_testmod. Memory2GiB/12-15. Original selftests/native annotations retained. Runtime admission additions0.')
 with (F/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','python3',str(F/'mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode','archive_sha256']}
  with tarfile.open(Q/j['archive']) as tf:
   n='run/out/submissions.json'
   if n in tf.getnames():
    data=tf.extractfile(n).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect the complete ARM paired-resource native catalog','arm-dynptr-memory-qemu-result')
 save('finished',publication=rec,**{k:v for k,v in report.items() if k!="utc"});notice('PUSHED '+rec['commit']+' complete original-resource ARM terminal '+json.dumps(report.get('counts'))+'. Every real P/B/maps/BTF/compiler/verifier row retained. Runtime admission additions0.')
 removed=[]
 for name in ['source','catalog','runtime']:
  root=F/name
  size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
  shutil.rmtree(root);removed.append(dict(path=str(root),bytes=size))
 (F/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=rec,retired=removed),indent=2)+'\n')
 notice('ARM dynptr family terminal '+rec['commit']+' private copies retired '+str(sum(r['bytes'] for r in removed))+'bytes. Canonical runtime/cache retained.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
