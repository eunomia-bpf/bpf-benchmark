from pathlib import Path
from io import BytesIO
from elftools.elf.elffile import ELFFile
import hashlib,importlib.util,json,subprocess,sys,traceback
R=Path('/workspaces/repository');E=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'kprog'))
spec=importlib.util.spec_from_file_location('arm_specializer',R/'kprog/arm64/trusted_specializer.py')
worker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=worker;spec.loader.exec_module(worker)
table=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftests/headers/programs.json'
rows=json.loads(table.read_text())['programs']
results=json.loads((E/'upstream.json').read_text())['programs']
for row in rows:
    if row['file'] not in {'verifier_const.c','verifier_mtu.c'} or row['body']!='c':
        continue
    if any(r['program']==row['program'] and r['stage']=='generated_compiled' for r in results):
        continue
    results=[r for r in results if r['program']!=row['program']]
    out=E/'upstream'/row['program'];out.mkdir(parents=True,exist_ok=True)
    record=dict(file=row['file'],program=row['program'],annotation=row['expect'],section=row['section'])
    try:
        native=R/'kprog/arm64/build/kernel-selftests-headers'/(Path(row['file']).stem+'.native.o')
        linker=R/'kprog/x86/native_lab/native_link/target/release/native-link'
        bpf=Path(row['bpf_object']);elf=ELFFile(BytesIO(bpf.read_bytes()));symtab=elf.get_section_by_name('.symtab')
        entries=[s.name for s in symtab.iter_symbols() if s['st_info']['type']=='STT_FUNC' and isinstance(s['st_shndx'],int) and elf.get_section(s['st_shndx']).name==row['section']]
        entry=row['program']
        if entry not in entries:
            entry,=entries
        record['entry']=entry
        command=[str(linker),'--input',str(native),'--symbol',entry,'--mode','resources','--output',str(out/'resources.json')]
        resource=subprocess.run(command,capture_output=True,text=True)
        (out/'resources-command.json').write_text(json.dumps(dict(command=command,returncode=resource.returncode,stdout=resource.stdout,stderr=resource.stderr),indent=2)+'\n')
        resource.check_returncode()
        symbols=json.loads((out/'resources.json').read_text())['symbols']
        maps=[]
        for name in symbols:
            sym=next(s for s in symtab.iter_symbols() if s.name==name and isinstance(s['st_shndx'],int))
            section=elf.get_section(sym['st_shndx'])
            maps.append(dict(name=name,map_type=2,key_size=4,value_size=int(section['sh_size']),max_entries=1,
                             map_flags=0 if section['sh_flags']&1 else 128,value_offset=int(sym['st_value'])-int(section['sh_addr'])))
        metadata=dict(prog_type=29 if row['section'].startswith('lsm') else 3,section=row['section'],maps=maps)
        (out/'input.json').write_text(json.dumps(dict(native=str(native),native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),bpf=str(bpf),bpf_sha256=hashlib.sha256(bpf.read_bytes()).hexdigest(),metadata=metadata,geometry_source='Matching BPF ELF allocated DATASEC size, writable flag and symbol offset'),indent=2)+'\n')
        artifact=worker.specialize(native.read_bytes(),entry,metadata,out/'generated',linker)
        record.update(stage='generated_compiled',artifact=artifact)
    except Exception as error:
        record.update(stage='generation_compile_error',error=str(error),traceback=traceback.format_exc())
    results.append(record)
    (E/'upstream.json').write_text(json.dumps(dict(scope='Original complete verifier_const and verifier_mtu C program populations; source specializer/compiler coverage',programs=results),indent=2)+'\n')
    print(json.dumps(record),flush=True)
