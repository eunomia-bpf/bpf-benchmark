from pathlib import Path
import collections,datetime,fcntl,hashlib,importlib.util,io,json,os,re,shutil,subprocess,sys,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers/void-kfunc';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
def notice(s):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': '+s+'\n')
def git(args,**kw):return subprocess.check_output(['git',*args],cwd=R,**kw)
def source_publish():
 env=os.environ|{'GIT_INDEX_FILE':str(G/'production.index')}
 with (A/'publication.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  while True:
   base=git(['rev-parse','HEAD'],text=True).strip();git(['read-tree',base],env=env)
   git(['apply','--cached',str(G/'own-production.diff')],env=env)
   git(['diff','--cached','--check',base],env=env)
   names=git(['diff','--cached','--name-only',base],env=env,text=True).splitlines()
   if set(names)!=set(json.loads((G/'owned-paths.json').read_text())):raise RuntimeError('own source commit scope differs')
   tree=git(['write-tree'],env=env,text=True).strip();commit=git(['commit-tree',tree,'-p',base,'-m','Model ARM zero-argument preempt and RCU kfunc calls'],env=env,text=True).strip()
   p=subprocess.run(['git','update-ref','refs/heads/master',commit,base],cwd=R,capture_output=True,text=True)
   if p.returncode==0:break
   if git(['rev-parse','HEAD'],text=True).strip()==base:raise RuntimeError(p.stderr)
  subprocess.run(['git','push','origin','HEAD:master'],cwd=R,check=True)
  remote=git(['ls-remote','origin','refs/heads/master'],text=True).split()[0]
  subprocess.run(['git','merge-base','--is-ancestor',commit,remote],cwd=R,check=True)
 return dict(commit=commit,paths=names,remote_ancestor_verified=True)
try:
 save('existing_controls_and_incremental_loader')
 commands=[
 ['python3','kprog/formal/tools/generate_arm64_helper_idents_spec.py','--check'],
 ['cc','-include','kprog/formal/oracles/arm64_entry_environment_host.h','-DKPROG_TEST_EXCLUSIVE_FAILURE=0','-include','kprog/formal/oracles/arm64_exclusive_choice_host.h','-Wall','-Wextra','-O2','-Ikprog/formal','-Ikprog/arm64','-Ikprog','-Ivendor/libbpf/src','kprog/formal/oracles/test_arm64_helper_call_host.c','-o',str(G/'helper-abi-host')],
 [str(G/'helper-abi-host')],
 ['cmake','--build','runner/build-arm64-llvmbpf','--target','native_loader','native_loader_shared','trusted-native-loader','trusted-service-client','--parallel','2']]
 controls=[]
 for i,cmd in enumerate(commands):
  with (G/f'control-{i}.log').open('w') as log:p=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
  controls.append(dict(command=cmd,returncode=p.returncode));(G/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
  if p.returncode:raise RuntimeError('existing control/build failed '+str(cmd))
 shutil.copytree(R/'kprog/arm64/build/native-load-recovery/recovery',G/'runtime',dirs_exist_ok=True)
 for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:shutil.copy2(R/'runner/build-arm64-llvmbpf/native_loader'/name,G/'runtime'/name)
 shutil.copy2(R/'runner/build-arm64-llvmbpf/native_loader/libnative_loader.a',G/'libnative_loader.a')
 save('original_complete_catalog_generation',controls=controls)
 P=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full-paired-resources';rows=json.loads((P/'submissions.json').read_text())['programs']
 Q=P/'trusted-arm64-service-result';d=json.loads((Q/'summary.json').read_text());inputs={}
 with tarfile.open(Q/d['archive'],'r|gz') as tf:
  for m in tf:
   hit=re.search(r'/(\d+)\.(?:failure|success)\.tar.gz$',m.name)
   if not hit:continue
   with tarfile.open(fileobj=io.BytesIO(tf.extractfile(m).read())) as q:
    native=q.extractfile('request/kernel.native.o').read()
    metadata=json.loads(q.extractfile('request/generation.metadata.json').read())
    inputs[int(hit[1])]=(native,metadata)
 sys.path.insert(0,str(R/'kprog'))
 spec=importlib.util.spec_from_file_location('arm_worker',R/'kprog/arm64/trusted_specializer.py');worker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=worker;spec.loader.exec_module(worker)
 observed=[];linker=R/'kprog/x86/native_lab/native_link/target/release/native-link'
 for row in rows:
  record={k:row.get(k) for k in ['file','program','expect','request_id','native_sha256','stage','diagnostic']};record['previous_stage']=record.pop('stage')
  pair=inputs.get(row.get('request_id'))
  if pair is None:record.update(stage='archived_resource_failed',diagnostic=row.get('error','Original resource creation outcome'))
  else:
   native,metadata=pair;out=G/'generated'/(Path(row['file']).stem+'__'+row['program'])
   try:
    out.parent.mkdir(parents=True,exist_ok=True)
    artifacts=worker.specialize(native,row['program'],metadata,out,linker)
    (out/'generation.metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    record.update(stage='generated_compiled',native_sha256=artifacts['native_sha256'])
   except BaseException as e:record.update(stage='generation_or_compile_failed',diagnostic=str(e),traceback=traceback.format_exc())
  observed.append(record);(G/'generation.json').write_text(json.dumps(dict(programs=observed,counts=dict(collections.Counter(r['stage'] for r in observed))),indent=2)+'\n')
 source=source_publish()
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 report=dict(utc=now(),source_publication=source,controls=controls,generation=json.loads((G/'generation.json').read_text()),runtime_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (G/'runtime').iterdir() if p.is_file()},scope='All380 original catalog entries; exact archived P/metadata, generation and compilation; original resource outcomes retained',runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json'] and not p.name.endswith('.index'):tf.add(p,arcname=str(p.relative_to(G)))
  for p in json.loads((G/'owned-paths.json').read_text()):tf.add(R/p,arcname='source/'+p)
 (O/'README.md').write_text('ARM zero-argument preempt and RCU kfunc calls\n\nThe generator emits actual typed __ksym calls for bpf_preempt_disable/enable and bpf_rcu_read_lock/unlock. The stock verifier sees each critical-section operation. The generic ARM call body preserves its real kernel effect and leaves the ABI void result unspecified, with existing AAPCS caller-clobber semantics. BL calls write the link; external B tail calls return through the actual restoredLR and existing finite return dispatch. The shared loader resolves these four symbols through its existing runtime-call registry and existing function-call relocation slots. Existing loader targets build incrementally; the active runtime stage retains its files. All380original native rows receive generation/compile or original resource outcomes from exact archived inputs. QEMU verifier/installation outcomes follow the captured family replay. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['summary.json','inputs.tar.gz','README.md']],'Collect ARM void-kfunc loader and complete original catalog compilation','arm-void-kfunc-results')
 (G/'publication.json').write_text(json.dumps(dict(source=source,results=rec),indent=2)+'\n')
 save('finished',source_publication=source,publication=rec,counts=report['generation']['counts'])
 notice('PUSHED '+source['commit']+' ARM preempt/RCU zeroargvoid kfunc model and existing shared runtime-symbol binding; results'+rec['commit']+' complete original380 generation '+json.dumps(report['generation']['counts'])+', existing ABI/loader build0. BL/B-tail and unspecifiedvoidresult preserved; stock QEMU outcomes follow. Active runtime/workload/source epochs retained; runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
