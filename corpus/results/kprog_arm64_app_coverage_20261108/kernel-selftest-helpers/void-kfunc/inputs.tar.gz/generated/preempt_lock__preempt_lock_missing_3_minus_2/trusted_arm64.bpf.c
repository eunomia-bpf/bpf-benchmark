#define ARM64_SIM_RET_CASES_20 
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BIAS 16LL
#define ARM64_SIM_STACK_BYTES 16U
#define ARM64_SIM_STACK_PAYLOAD_WORDS 1U
#define ARM64_SIM_L_STACK_PAYLOAD_LOAD(INDEX) (__a64_stack_payload[(((__u64)(INDEX) > 0ULL))])
#define ARM64_SIM_L_STACK_PAYLOAD_STORE(INDEX, VALUE) do { __a64_stack_payload[(((__u64)(INDEX) > 0ULL))] = (VALUE); } while (0)
#define ARM64_SIM_RETURN_CASES \
	case 0x8ULL: goto arm64_l_8; \
	case 0xcULL: goto arm64_l_c; \
	case 0x10ULL: goto arm64_l_10; \
	case 0x14ULL: goto arm64_l_14; \
	case 0x18ULL: goto arm64_l_18;
#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"

extern void bpf_preempt_disable(void) __ksym;
extern void bpf_preempt_enable(void) __ksym;
SEC("tc")
int trusted_arm64_arm64_sim_xdp(struct __sk_buff *ctx)
{
	ARM64_SIM_ENTRY_SKB(ctx);
	/* native subroutine preempt_lock_missing_3_minus_2 */
arm64_l_0:
	/* 0x0: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_4:
	/* 0x4: bl 0 <bpf_preempt_disable> */
	ARM64_SIM_A64_LINK(0x8ULL);
	ARM64_SIM_KFUNC_VOID_CALL(bpf_preempt_disable);
arm64_l_8:
	/* 0x8: bl 0 <bpf_preempt_disable> */
	ARM64_SIM_A64_LINK(0xcULL);
	ARM64_SIM_KFUNC_VOID_CALL(bpf_preempt_disable);
arm64_l_c:
	/* 0xc: bl 0 <bpf_preempt_disable> */
	ARM64_SIM_A64_LINK(0x10ULL);
	ARM64_SIM_KFUNC_VOID_CALL(bpf_preempt_disable);
arm64_l_10:
	/* 0x10: bl 0 <bpf_preempt_enable> */
	ARM64_SIM_A64_LINK(0x14ULL);
	ARM64_SIM_KFUNC_VOID_CALL(bpf_preempt_enable);
arm64_l_14:
	/* 0x14: bl 0 <bpf_preempt_enable> */
	ARM64_SIM_A64_LINK(0x18ULL);
	ARM64_SIM_KFUNC_VOID_CALL(bpf_preempt_enable);
arm64_l_18:
	/* 0x18: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c:
	/* 0x1c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_20:
	/* 0x20: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_20);
arm64_l_24:
	/* 0x24: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_28:
	/* 0x28: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
