#define ARM64_SIM_RET_CASES_28 
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BIAS 16LL
#define ARM64_SIM_STACK_BYTES 16U
#define ARM64_SIM_STACK_PAYLOAD_WORDS 1U
#define ARM64_SIM_L_STACK_PAYLOAD_LOAD(INDEX) (__a64_stack_payload[(((__u64)(INDEX) > 0ULL))])
#define ARM64_SIM_L_STACK_PAYLOAD_STORE(INDEX, VALUE) do { __a64_stack_payload[(((__u64)(INDEX) > 0ULL))] = (VALUE); } while (0)
#define ARM64_SIM_RETURN_CASES \
	case 0x20ULL: goto arm64_l_20;
#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"

static const __u8 __arm64_rodata_0[4] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x66, 0x6f, 0x6f, 0x00};
static const char __arm64_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__arm64_rodata_0\",\"native_symbol\":\"__arm64_section_Some(SectionIndex(7))_addend_0\",\"size\":4}]}";

SEC("fentry/trusted")
int trusted_arm64_arm64_sim_xdp(void *ctx)
{
	ARM64_SIM_ENTRY_RAW(ctx);
	/* native subroutine task_access_comm1 */
arm64_l_0:
	/* 0x0: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_4:
	/* 0x4: ldr x8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8:
	/* 0x8: adrp x2, 0 <task_access_comm1> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_c:
	/* 0xc: add x2, x2, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_10:
	/* 0x10: mov w9, #0xb6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 182ULL);
arm64_l_14:
	/* 0x14: mov w1, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 17ULL);
arm64_l_18:
	/* 0x18: add x0, x8, #0xaf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2800ULL);
arm64_l_1c:
	/* 0x1c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 182ULL: ARM64_SIM_A64_LINK(0x20ULL); ARM64_SIM_BPF_CALL_bpf_strncmp(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_20:
	/* 0x20: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_24:
	/* 0x24: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_28:
	/* 0x28: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_28);
arm64_l_2c:
	/* 0x2c: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_30:
	/* 0x30: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
