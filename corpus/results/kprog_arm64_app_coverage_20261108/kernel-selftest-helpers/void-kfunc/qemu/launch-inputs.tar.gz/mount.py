from pathlib import Path
import os,subprocess,sys
F=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((F/'source').rglob('*')):
 if p.is_file() and 'kernel-selftests-current' not in str(p):subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(F/'source'))],check=True)
stage=R/'kprog/arm64/build/native-load-recovery/recovery'
for source,target in [('native-link','kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link'),('libnative_loader.so','runner/build-arm64-llvmbpf/native_loader/libnative_loader.so'),('trusted-native-loader','runner/build-arm64-llvmbpf/native_loader/trusted-native-loader'),('trusted-service-client','runner/build-arm64-llvmbpf/native_loader/trusted-service-client')]:
 subprocess.run(['mount','--bind',str(stage/source),str(R/target)],check=True)
subprocess.run(['mount','--bind',str(F/'catalog'),str(R/'kprog/arm64/build/kernel-selftests-current')],check=True)
target=R/'kprog/arm64/build/kernel-selftest-runner-current/bpf34-full.py'
subprocess.run(['mount','--bind',str(F/'transport.py'),str(target)],check=True)
os.execv(sys.executable,[sys.executable,str(target),'host','control',str(R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers/void-kfunc/qemu')])
