set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kprog/libnativeloader/CMakeLists.txt /workspaces/repository/kprog/libnativeloader/CMakeLists.txt
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kprog/libnativeloader/src/native_loader.cpp /workspaces/repository/kprog/libnativeloader/src/native_loader.cpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kprog/libnativeloader/src/native_loader_manifest.hpp /workspaces/repository/kprog/libnativeloader/src/native_loader_manifest.hpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kprog/libnativeloader/include/native_loader.hpp /workspaces/repository/kprog/libnativeloader/include/native_loader.hpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kprog/trusted_loader.cpp /workspaces/repository/kprog/trusted_loader.cpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kprog/test/trusted_service_client.cpp /workspaces/repository/kprog/test/trusted_service_client.cpp
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kinsn/module/include/native_lab_exclusive.h /workspaces/repository/kinsn/module/include/native_lab_exclusive.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kinsn/module/include/native_lab_group.h /workspaces/repository/kinsn/module/include/native_lab_group.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kinsn/module/include/native_lab_input.h /workspaces/repository/kinsn/module/include/native_lab_input.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kinsn/module/include/native_lab_trusted.h /workspaces/repository/kinsn/module/include/native_lab_trusted.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kinsn/module/include/native_lab_binding.h /workspaces/repository/kinsn/module/include/native_lab_binding.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/runtime-source/kinsn/module/include/native_lab_trusted_wire.h /workspaces/repository/kinsn/module/include/native_lab_trusted_wire.h
exec make -f /workspaces/.agent-state/kprog-lanes/A/kernel-selftest-helpers/Makefile runtime
