from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');E=A/'kernel-selftest-helpers';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers';B=R/'kprog/arm64/build/kernel-selftest-helpers/loader'
def save(phase,**kw):
 (E/'runtime-status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=phase,**kw),indent=2)+'\n')
try:
 save('building_paired_ARM_loader',common_source='be91b11effefce61f88643b85237e21e99f8ec2d')
 with (E/'runtime.log').open('w') as log:
  p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(E/'inside-runtime.sh')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(make_exit=p.returncode,common_source='be91b11effefce61f88643b85237e21e99f8ec2d',arm_helper_source='a97b673c8234726bc0d5eadf7f4ad6248726dc04',source_sha256={str(p.relative_to(E/'runtime-source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (E/'runtime-source').rglob('*') if p.is_file()},binaries={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in B.glob('*') if p.is_file()},runtime_scope='Paired AArch64 loader/service build with public strtol and skb/XDP MTU resolution; captured application runtime files retain their bytes')
 (O/'runtime.json').write_text(json.dumps(report,indent=2)+'\n');(O/'runtime.log.gz').write_bytes(gzip.compress((E/'runtime.log').read_bytes(),mtime=0))
 with tarfile.open(O/'runtime-inputs.tar.gz','w:gz') as t:
  for name in ['runtime-source','Makefile','inside-runtime.sh','build-runtime.py']:t.add(E/name,arcname=name)
  if B.exists():t.add(B,arcname='loader')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['runtime.json','runtime.log.gz','runtime-inputs.tar.gz']],'Build paired ARM loader for Linux helper selftests','arm-kernel-selftest-helper-runtime')
 save('finished',make_exit=p.returncode,publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR R/C/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+rec['commit']+' paired ARM loader/service build Makeexit'+str(p.returncode)+' from common be91 helper105/163 resolution. ARM helper source a97b673c8; worker/client/DSO/static binaries and exact source in D8/kernel-selftest-helpers/runtime-inputs.tar.gz. Built files at kprog/arm64/build/kernel-selftest-helpers/loader. Original Image/module/native-context resources and captured BCC/Cilium epochs retain their files. R direct ARM annotation sweep can consume this worker. Runtime admission additions0.\n')
except BaseException as e:
 save('requires_continuation',error=str(e),traceback=traceback.format_exc())
 raise
