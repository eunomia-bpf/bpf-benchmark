from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=A/'design-only';F=D/'lse-input/bcc-queue';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/bcc-execution-queued';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=load('arm_lse_pub',A/'six-app-publish.py')
def save(phase,**kw):(F/'app-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
try:
 import select
 save('waiting_direct_context_safety',predecessor_pid=1671690)
 try:fd=os.pidfd_open(1671690)
 except ProcessLookupError:fd=None
 if fd is not None:select.select([fd],[],[]);os.close(fd)
 save('capturing_launch')
 setup=dict(utc=now(),runtime='e2d3a5ee89349608fb79f4d4d397fdfc683ff7a8',common_source_epoch='385d5095c0220a2599469c0b73f156d137d7abaa',arm_source='canonical500abe542 architectural fault bodies and LDADD',cpus='16-19',guest_vcpus=2,guest_memory_mib=2048,original_application_rows=23,source_pins={str(p.relative_to(F/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (F/'source').rglob('*') if p.is_file()},native_build=json.loads((D/'lse-input/bcc-build.json').read_text()),scope='Existing complete BCC two-start recipe and original program/map matching; original hot input plus real TCP/fsync/queued block I/O; owned ext4 virtio scratch device')
 (O/'launch.json').write_text(json.dumps(setup,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  t.add(F/'source',arcname='source')
  for n in ['inside.sh','transport.py','app-controller.py','Makefile','workload.py','launch-plan.json']:t.add(F/n,arcname=n)
  t.add(D/'lse-input/bcc-live-manifest.json',arcname='bcc-live-manifest.json')
  t.add(O/'input.py',arcname='input.py')
  t.add(R/'kprog/arm64/build/lse-native/bcc',arcname='native-bcc')
 (O/'README.md').write_text('Complete BCC real-event execution coverage\n\nThe original23-program eight-tool BCC two-start recipe retains its LSE native objects, paired five-step Image/module/loader and original four stressors. Each arm additionally runs8IPv4 and8IPv6 loopback TCP connections, fsync, AIO fsync/fdatasync and16MiB of512-byte queued libaio file writes. An owned256MiB ext4 virtio block image with none supplies real guest block-layer events. The guest has2vCPUs/2GiB on16-19. The native input, source, exact commands, image and raw phase counters accompany the cohort. The existing measurement and workload error handling remain current. QEMU durations provide functional evidence.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md','input.py']],'Run complete ARM BCC with real TCP fsync and block events','arm-bcc-queue-launch');save('actual_bcc_events',launch_publication=rec);notice('PUSHED '+rec['commit']+' complete BCC execution-input launch: all23 native application rows, original hot4stressors plus IPv4/IPv6 TCP, fsync and queued ext4 block I/O. Owned256MiB virtio disk,2vCPU/2GiB16-19; private shared3-family atomic source. Existing phase counters collect actual coverage; new admission checks0.')
 with (F/'app-driver.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','sh',str(F/'inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 result=O/'trusted-arm64-bcc-result';result.mkdir(exist_ok=True);(result/'driver.log.gz').write_bytes(gzip.compress((F/'app-driver.log').read_bytes(),mtime=0));paths=[result/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (result/'summary.json').exists():
  summary=json.loads((result/'summary.json').read_text());archive=result/summary['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((D/'app-coverage.py').read_text(),'arm_lse_coverage','exec'),scope);report['coverage']=scope['coverage'](summary,archive);paths.extend([result/'summary.json',archive])
 (result/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(result/'coverage.json');receipt=pub.publish([str(p.relative_to(R)) for p in paths],'Retain complete ARM BCC real-event workload and verifier results','arm-bcc-queue-result');save('finished',make_exit=p.returncode,publication=receipt);notice('PUSHED '+receipt['commit']+' complete ARM BCC real-event attempt Makeexit'+str(p.returncode)+'; request/verifier/workload receipts accompanycoverage.json.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
