from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=A/'design-only';F=D/'lse-input/bcc-queue';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/bcc-execution-queued';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=load('arm_lse_pub',A/'six-app-publish.py')
def save(phase,**kw):(F/'app-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
try:
 save('actual_bcc_events_libaio')
 with (F/'app-driver.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','sh',str(F/'inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 result=O/'trusted-arm64-bcc-result';result.mkdir(exist_ok=True);(result/'driver.log.gz').write_bytes(gzip.compress((F/'app-driver.log').read_bytes(),mtime=0));paths=[result/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (result/'summary.json').exists():
  summary=json.loads((result/'summary.json').read_text());archive=result/summary['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((D/'app-coverage.py').read_text(),'arm_lse_coverage','exec'),scope);report['coverage']=scope['coverage'](summary,archive);paths.extend([result/'summary.json',archive])
 (result/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(result/'coverage.json');receipt=pub.publish([str(p.relative_to(R)) for p in paths],'Retain complete ARM BCC real-event workload and verifier results','arm-bcc-queue-result');save('finished',make_exit=p.returncode,publication=receipt);notice('PUSHED '+receipt['commit']+' complete ARM BCC real-event attempt Makeexit'+str(p.returncode)+'; request/verifier/workload receipts accompanycoverage.json.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
