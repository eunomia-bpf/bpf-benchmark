/-- A retry base distinct from data/status retains its complete address,
including an SP base and every ordinary GPR base. -/
theorem retry_cycle_failed_base (width : Width)
    (acquire release sourceScalar sourceStack : Bool) (status value : Gpr)
    (base : Register) (increment displacement : Word) (s : State)
    (outsideValue : base.val ≠ value.val) (outsideStatus : base.val ≠ status.val) :
    memoryBase (retryCycleCore width acquire release true sourceScalar sourceStack
      status value base increment displacement s).state base = memoryBase s base := by
  by_cases general : base.val < 31
  · simpa only [memoryBase, general, ↓reduceDIte] using
      retry_cycle_failed_other_gpr width acquire release sourceScalar sourceStack
        status value ⟨base.val, general⟩ base increment displacement s outsideValue outsideStatus
  · have preserved := congrArg State.sp
      (retry_cycle_failed_frame width acquire release sourceScalar sourceStack
        status value base increment displacement s)
    simpa only [memoryBase, general, ↓reduceDIte] using preserved
