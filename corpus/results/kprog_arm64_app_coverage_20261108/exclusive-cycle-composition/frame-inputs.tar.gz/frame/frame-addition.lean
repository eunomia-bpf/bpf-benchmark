/-- A failed C-model iteration preserves the complete architectural frame
outside its data/status registers, reservation and program counter. The cycle
refinement transfers this equality to the canonical ISA under its premises. -/
theorem retry_cycle_failed_frame (width : Width)
    (acquire release sourceScalar sourceStack : Bool) (status value : Gpr)
    (base : Register) (increment displacement : Word) (s : State) :
    let result := retryCycleCore width acquire release true sourceScalar sourceStack
      status value base increment displacement s
    result.state = { s with gpr := result.state.gpr,
      exclusiveMonitor := result.state.exclusiveMonitor, pc := result.state.pc } := by
  unfold retryCycleCore retryPrefixCore
  simp_rw [Arm64Arithmetic.AluDispatch.raw_step_refines]
  unfold loadCore
  cases loaded : Arm64Memory.read (accessWidth width) s.memory
      (Arm64Memory.baseValue s base) with
  | error fault => rfl
  | ok pair =>
      rcases pair with ⟨word, event⟩
      by_cases monitor : (!s.exclusiveInputs.retainLocal || s.exclusiveInputs.virtualPass) = true
      · simp [continueWith, retrySuffixCore, storeCore, checkedState,
          Arm64Register.write_refines, arithmeticImmediateStep, writeData,
          step, branchStep, monitor]
      · simp [continueWith, retrySuffixCore, storeCore, checkedState,
          Arm64Register.write_refines, arithmeticImmediateStep, writeData,
          step, branchStep, monitor]

/-- Only the native data/status registers participate in a failed iteration's
GPR updates, including aliases between those two registers. -/
theorem retry_cycle_failed_other_gpr (width : Width)
    (acquire release sourceScalar sourceStack : Bool) (status value other : Gpr)
    (base : Register) (increment displacement : Word) (s : State)
    (outsideValue : other.val ≠ value.val) (outsideStatus : other.val ≠ status.val) :
    (retryCycleCore width acquire release true sourceScalar sourceStack
      status value base increment displacement s).state.gpr other = s.gpr other := by
  unfold retryCycleCore retryPrefixCore
  simp_rw [Arm64Arithmetic.AluDispatch.raw_step_refines]
  unfold loadCore
  cases loaded : Arm64Memory.read (accessWidth width) s.memory
      (Arm64Memory.baseValue s base) with
  | error fault => rfl
  | ok pair =>
      rcases pair with ⟨word, event⟩
      by_cases monitor : (!s.exclusiveInputs.retainLocal || s.exclusiveInputs.virtualPass) = true
      · simp [continueWith, retrySuffixCore, storeCore, checkedState,
          Arm64Register.write_refines, arithmeticImmediateStep, writeData,
          step, branchStep, monitor, writeReg, outsideValue, outsideStatus]
      · simp [continueWith, retrySuffixCore, storeCore, checkedState,
          Arm64Register.write_refines, arithmeticImmediateStep, writeData,
          step, branchStep, monitor, writeReg, outsideValue, outsideStatus]
