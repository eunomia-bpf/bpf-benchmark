from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=A/'selftests-arm64/headers';B=R/'kprog/arm64/build/kernel-selftests-headers';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftests/headers';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 import os,select
 save('waiting_predecessor', predecessor_pid=1454987)
 try: predecessor=os.pidfd_open(1454987)
 except ProcessLookupError: predecessor=None
 if predecessor is not None:
  try:select.select([predecessor],[],[])
  finally:os.close(predecessor)
 save('dumping_paired_kernel_btf')
 with (F/'include/vmlinux.h').open('w') as out:p=subprocess.run([str(R/'vendor/build/x86/bpftool/bin/bpftool'),'btf','dump','file','/workspaces/.agent-state/kprog-lanes/A/kfunc-kernel/cache/vmlinux','format','c'],stdout=out,stderr=subprocess.PIPE,text=True)
 (F/'btf.log').write_text(p.stderr);p.check_returncode();save('compiling_upstream_C')
 with (F/'compiler.log').open('w') as log:p=subprocess.run(['python3',str(F/'selftests.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (F/'compile.exit').write_text(str(p.returncode)+'\n');p.check_returncode();d=json.loads((B/'programs.json').read_text());rows=d['programs'];(O/'programs.json').write_text(json.dumps(d,indent=2)+'\n');(O/'commands.jsonl.gz').write_bytes(gzip.compress((F/'commands.jsonl').read_bytes(),mtime=0));(O/'compiler.log.gz').write_bytes(gzip.compress((F/'compiler.log').read_bytes(),mtime=0));manifest=dict(launch=json.loads((F/'launch.json').read_text()),counts=d['counts'],native_objects={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in B.glob('*.native.o')},bpf_objects={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in B.glob('*.bpf.o')},vmlinux_header_sha256=hashlib.sha256((F/'include/vmlinux.h').read_bytes()).hexdigest());(O/'compile.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as t:
  for n in ['upstream-harness.py','selftests.py','controller.py','launch.json','btf.log','include/vmlinux.h']:t.add(F/n,arcname=n)
  for p in sorted(B.glob('*')):
   if p.is_file():t.add(p,arcname='build/'+p.name)
  for p in sorted(set(x['path'] for x in rows)):t.add(p,arcname='upstream/progs/'+Path(p).name)
 (O/'README.md').write_text('ARM native compilation of annotated upstream kernel BPF selftests\n\nThe existing R enumeration and __failure/__success markers use upstream source files. The architecture port selects AArch64, the current default native ABI/reserved registers, the retained ARM sysroot and vmlinux.h dumped from the vmlinux paired with the e2d3 QEMU Image. Raw compiler commands and outcomes, all enumerated programs, built native/BPF objects and exact source inputs accompany this result. The compilation phase precedes kernel submission and annotation comparison. R retains ownership of the shared submission harness.\n\nMeasured counts: '+json.dumps(d['counts'],sort_keys=True)+'.\n')
 spec=importlib.util.spec_from_file_location('arm_selftests_pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);receipt=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','programs.json','commands.jsonl.gz','compiler.log.gz','compile.json','inputs.tar.gz']],'Compile the upstream annotated kernel C selftests for ARM','arm-kernel-selftests-headers');save('compiled',publication=receipt,counts=d['counts'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED '+receipt['commit']+' priority2a completeR-enumeration ARM compile port, counts='+json.dumps(d['counts'],sort_keys=True)+'. ExactpairedvmlinuxBTF/currentARMv8ABI/sysroot/nativeandBPFcompiler commands, alloriginalsourcesandbuiltobjects retained. ARM inputs at kprog/arm64/build/kernel-selftests-headers; Rsharedsubmissionharness retainsowner and consumes these inputs for annotation comparison. Canonicalselftestscode retainsRwriter.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
