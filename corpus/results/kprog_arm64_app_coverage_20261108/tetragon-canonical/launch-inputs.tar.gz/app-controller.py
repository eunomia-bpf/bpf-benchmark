from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=A/'design-only';F=A/'bitwise-lse/tetragon';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/tetragon-canonical';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=load('arm_lse_pub',A/'six-app-publish.py')
def save(phase,**kw):(F/'app-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
try:
 save('waiting_existing_cohorts', predecessor_pids=[1805312])
 import select
 for predecessor_pid in [1805312]:
  try:fd=os.pidfd_open(predecessor_pid)
  except ProcessLookupError:fd=None
  if fd is not None:
   try:select.select([fd],[],[])
   finally:os.close(fd)
 save('capturing_launch')
 manifest=json.loads((R/'kprog/arm64/build/app-verified-stage/tetragon/manifest.json').read_text())
 for row in manifest['objects']+manifest.get('data_objects',[]):
  original=Path(row['native_object'])
  row['native_object']=str((R/'kprog/arm64/build/app-verified-stage/tetragon'/original) if str(original).startswith('startup/') else (R/'kprog/arm64/build/lse-native/tetragon'/original.name))
 (F/'live-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 setup=dict(utc=now(),layout_scope='External destination classification preserves native memory operations and allocates private pointer payloads for private destinations',matched_baseline_max_fp_minus_offset=872,candidate_max_fp_minus_offset=488,candidate_payload_offsets=[-64],runtime='e2d3a5ee89349608fb79f4d4d397fdfc683ff7a8',common_source_epoch='385d5095c0220a2599469c0b73f156d137d7abaa',arm_source='canonical a8d17004c ARM model/generator plus helper82 and approved architectural fault predicates; same native P',cpus='16-19',guest_vcpus=8,guest_memory_mib=8192,original_manifest_rows=247,original_probe_rows=9,original_application_variant_rows=238,source_pins={str(p.relative_to(F/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (F/'source').rglob('*') if p.is_file()},native_build=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261108/lse-input/tetragon/build.json').read_text()),scope='Existing complete Tetragon two-start recipe and original program/map matching; compiler selects Armv8.1 LSE; current canonical simulator preserved')
 (O/'launch.json').write_text(json.dumps(setup,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  t.add(F/'source',arcname='source')
  for n in ['inside.sh','transport.py','app-controller.py','live-manifest.json','Makefile','build.py']:t.add(F/n,arcname=n)
  t.add(R/'kprog/arm64/build/lse-native/tetragon',arcname='native-tetragon')
 (O/'README.md').write_text('ARM Tetragon with Armv8.1 LSE native input and generic LSE atomic simulation\n\nThe complete upstream Tetragon native recipe uses the existing ABI flags plus -march=armv8.1-a+lse. The original247 manifest rows (9startup probes and238application variants) retain their source identity and map matching. The existing two-start recipe uses8vCPUs/8GiB on16-19 and the paired five-step runtime. The source snapshot carries canonical a8d17004c ARM LDADD/LDSET/LDCLR, helper82 and the approved four architectural fault predicates, plus precise private pointer payload geometry. The current canonical compiler flags and simulator remain at their published epoch. QEMU durations provide functional evidence.\n\nThe existing29 microprograms generate and compile with the candidate. Preliminary offline source attempts capture the real-section and original-map declaration setup frontiers; the application run supplies map metadata through the kernel request. The terminal replay publishes raw generated B, verifier and application-work results. Architectural O1/O2 coverage for the new operation belongs to the universal token proof work.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Run complete ARM Tetragon on canonical LSE and helper source','arm-tetragon-canonical-launch');save('actual_tetragon',launch_publication=rec);notice('PUSHED '+rec['commit']+' completeTetragon LSE candidate launch:original247manifestrows retained,including9probesand238applicationvariants,8vCPU/8GiB16-19 afterexistingcohortsclose. Pairedfive-step runtime andcapturedcanonicalgenericLDADDsource; runtimeadmissionadditions0.')
 with (F/'app-driver.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','sh',str(F/'inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 result=O/'trusted-arm64-tetragon-result';result.mkdir(exist_ok=True);(result/'driver.log.gz').write_bytes(gzip.compress((F/'app-driver.log').read_bytes(),mtime=0));paths=[result/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (result/'summary.json').exists():
  summary=json.loads((result/'summary.json').read_text());archive=result/summary['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((D/'app-coverage.py').read_text(),'arm_lse_coverage','exec'),scope);report['coverage']=scope['coverage'](summary,archive);paths.extend([result/'summary.json',archive])
 (result/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(result/'coverage.json');receipt=pub.publish([str(p.relative_to(R)) for p in paths],'Retain canonical ARM Tetragon workload and verifier results','arm-tetragon-canonical-result');save('finished',make_exit=p.returncode,publication=receipt);notice('PUSHED '+receipt['commit']+' completeARM Tetragon LSE attempt Makeexit'+str(p.returncode)+'; request/verifier/workload receipts accompanycoverage.json.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
