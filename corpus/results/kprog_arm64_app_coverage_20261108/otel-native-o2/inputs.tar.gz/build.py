from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');E=A/'design-only/otel-o2';B=R/'kprog/arm64/build/otel-o2';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/otel-native-o2';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(E/'build-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 cmd=['make','-C',str(R/'vendor/bpf'),'ARCH=arm64','CLANG='+str(E/'clang.py'),'NATIVE_OUT='+str(B/'native'),'NATIVE_STAGE_ROOT='+str(B/'stage'),'NATIVE_LINK='+str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'NATIVE_ARCH_CFLAGS=-mtune=neoverse-n1 -mgeneral-regs-only -mno-outline-atomics -ffixed-x18 -ffixed-x26 -ffixed-x27 -ffixed-x28 -march=armv8.1-a+lse','native-otel'];save('building_complete_native_input',command=cmd);(E/'Makefile.input').write_bytes((R/'vendor/bpf/Makefile').read_bytes())
 with (E/'build.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,command=cmd,compiler_wrapper=(E/'clang.py').read_text(),scope='Complete upstream OTel native build at one O2 profile, same ABI/helper/map source and reserved registers; observed stock BPF stack frontier motivates native frame geometry',objects=[],stack_usage=[])
 for q in sorted((B/'native/otel').glob('*.native.o')):report['objects'].append(dict(path=str(q.relative_to(R)),bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
 for q in sorted((B/'native/otel').glob('*.su')):
  for line in q.read_text().splitlines():report['stack_usage'].append(dict(file=q.name,record=line))
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n');(O/'build.log.gz').write_bytes(gzip.compress((E/'build.log').read_bytes(),mtime=0))
 with tarfile.open(O/'inputs.tar.gz','w:gz') as t:
  for n in ['build.py','clang.py','Makefile.input']:t.add(E/n,arcname=n)
  for q in sorted((B/'native/otel').glob('*')):
   if q.is_file() and q.suffix in ['.o','.su','.json']:t.add(q,arcname='native/'+q.name)
 (O/'README.md').write_text('Complete OTel native compiler O2 frame input\n\nThe complete upstream OTel native recipe uses one O2 profile with the retained AArch64 ABI/reserved registers and guest sysroot plus Armv8.1 LSE. The compiler applies O2 to every translation unit. Native objects and compiler-generated stack-usage records accompany the exact commands and full build output. The captured O3 perf_unwind_native source has a496byte native private arena plus64byte tags and8byte payload, reaching stock-verifier offset-576. This native-input change measures ordinary compiler frame geometry; the stock verifier evaluates fresh B in the complete application successor. QEMU timing provides functional evidence.\n\nMake exit '+str(p.returncode)+'; native objects '+str(len(report['objects']))+'.\n')
 spec=importlib.util.spec_from_file_location('arm_otel_o2_pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub);rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','build.json','build.log.gz','inputs.tar.gz']],'Build complete ARM OTel native input at O2','arm-otel-native-o2-input');save('built',make_exit=p.returncode,publication=rec,native_objects=len(report['objects']))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': PUSHED '+rec['commit']+' complete upstream OTel native O2 input, Makeexit'+str(p.returncode)+', objects'+str(len(report['objects']))+'. Single compilerprofile appliesallunits withsameARMABI/helper/maps/sysroot, plusLSE. Actual stockstack-576 frontier motivates nativeframegeometry; completeguest successor consumes freshP/B aftercurrentBCCevents releasesits2GiB. No newruntimeadmissionchecks.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
