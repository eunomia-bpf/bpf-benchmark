#!/usr/bin/env python3
import os,sys
root='/workspaces/repository'
args=sys.argv[1:]+['-O2','-fstack-usage','--sysroot='+root+'/kprog/arm64/build/app-runtime-v35/root','-I'+root+'/kprog/arm64/build/app-runtime-v35/root/usr/include/aarch64-linux-gnu','-I'+root+'/vendor/build/.bcc-libbpf/none/arm64/output']
os.execv('/usr/lib/llvm-18/bin/clang',['clang',*args])
