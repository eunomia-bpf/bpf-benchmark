from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=A/'design-only';F=D/'lse-input/cilium';O=R/'corpus/results/kprog_arm64_app_coverage_20261108/cilium-endpoint-replay';O.mkdir(exist_ok=True,parents=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=load('arm_lse_pub',A/'six-app-publish.py')
def save(phase,**kw):(F/'app-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
try:
 save('waiting_existing_cohorts', predecessor_pids=[1605924])
 import select
 for predecessor_pid in [1605924]:
  try:fd=os.pidfd_open(predecessor_pid)
  except ProcessLookupError:fd=None
  if fd is not None:
   try:select.select([fd],[],[])
   finally:os.close(fd)
 save('capturing_launch')
 manifest=json.loads((R/'kprog/arm64/build/app-verified-stage/cilium/manifest.json').read_text())
 for row in manifest['objects']+manifest.get('data_objects',[]):
  original=Path(row['native_object'])
  row['native_object']=str(R/'kprog/arm64/build/app-verified-stage/cilium'/original)
 (F/'live-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 setup=dict(utc=now(),runtime='e2d3a5ee89349608fb79f4d4d397fdfc683ff7a8',common_source_epoch='385d5095c0220a2599469c0b73f156d137d7abaa',arm_source='canonical48c989919 plus private LDSET/LDCLR shared atomic body',cpus='16-19',guest_vcpus=8,guest_memory_mib=8192,original_manifest_rows=len(manifest['objects']),source_pins={str(p.relative_to(D/'lse-input/tetragon/source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/'lse-input/tetragon/source').rglob('*') if p.is_file()},native_input='retained ARM Cilium native manifest',runner='async endpoint creation plus existing readiness waiter',scope='Existing complete Cilium two-start recipe and original program/map matching; retained compiler/native input; current canonical simulator preserved')
 (O/'launch.json').write_text(json.dumps(setup,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  t.add(D/'lse-input/tetragon/source',arcname='source')
  for n in ['inside.sh','transport.py','app-controller.py','live-manifest.json','Makefile','runner.py']:t.add(F/n,arcname=n)
  for p in sorted(set(row['native_object'] for row in manifest['objects']+manifest.get('data_objects',[]))):t.add(p,arcname='native/'+Path(p).name)
 (O/'README.md').write_text('ARM Cilium complete replay through asynchronous endpoint creation\n\nThe retained complete Cilium native manifest preserves its source identity and map matching. The runner requests asynchronous endpoint creation and uses the existing endpoint-readiness waiter. The existing two-start recipe uses8vCPUs/8GiB on16-19 and the paired five-step runtime. A private source snapshot carries the generic LDADD/LDSET/LDCLR instructions, old-value destination, address-before-writeback and memory-order selection. The current canonical compiler flags and simulator remain at their published epoch. QEMU durations provide functional evidence.\n\nThe existing29 microprograms generate and compile with the candidate. Preliminary offline source attempts capture the real-section and original-map declaration setup frontiers; the application run supplies map metadata through the kernel request. The terminal replay publishes raw generated B, verifier and application-work results. Architectural O1/O2 coverage for the new operation belongs to the universal token proof work.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Replay complete ARM Cilium with existing endpoint readiness waiting','arm-cilium-endpoint-launch');save('actual_cilium',launch_publication=rec);notice('PUSHED '+rec['commit']+' completeCilium replay launch:originalnativeobjects retained,asyncendpointcreation/existingreadinesswaiting,8vCPU/8GiB16-19 afterexistingcohortsclose. Pairedfive-step runtime andcapturedcanonicalgenericLDADDsource; runtimeadmissionadditions0.')
 with (F/'app-driver.log').open('w') as log:p=subprocess.run(['unshare','--mount','--propagation','private','sh',str(F/'inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 result=O/'trusted-arm64-cilium-result';result.mkdir(exist_ok=True);(result/'driver.log.gz').write_bytes(gzip.compress((F/'app-driver.log').read_bytes(),mtime=0));paths=[result/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (result/'summary.json').exists():
  summary=json.loads((result/'summary.json').read_text());archive=result/summary['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((D/'app-coverage.py').read_text(),'arm_lse_coverage','exec'),scope);report['coverage']=scope['coverage'](summary,archive);paths.extend([result/'summary.json',archive])
 (result/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(result/'coverage.json');receipt=pub.publish([str(p.relative_to(R)) for p in paths],'Retain whole ARM Cilium endpoint replay and verifier results','arm-cilium-endpoint-result');save('finished',make_exit=p.returncode,publication=receipt);notice('PUSHED '+receipt['commit']+' completeARM Cilium endpoint replay Makeexit'+str(p.returncode)+'; request/verifier/workload receipts accompanycoverage.json.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
